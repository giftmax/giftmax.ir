@echo off
chcp 65001 >nul
title HDMAX NetWatch - اجرا
color 0A
cd /d "%~dp0.."

echo ==========================================================
echo   HDMAX NetWatch Pro در حال اجراست...
echo   برای مشاهده: http://localhost:3000   (admin / admin)
echo   برای توقف: این پنجره را ببندید یا Ctrl+C بزنید
echo ==========================================================

REM اجرای روی همه کارت‌های شبکه تا از کلاینت‌های دیگر هم قابل دیدن باشد
start "" http://localhost:3000
call npx next start -H 0.0.0.0 -p 3000
pause
