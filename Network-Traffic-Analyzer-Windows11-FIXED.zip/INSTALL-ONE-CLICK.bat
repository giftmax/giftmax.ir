@echo off
title Network Traffic Analyzer - One Click Installer
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0INSTALL-ONE-CLICK.ps1"
if errorlevel 1 (
  echo.
  echo INSTALLATION FAILED. See the error above.
  pause
)
