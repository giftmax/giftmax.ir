@echo off
chcp 65001 >nul
title HDMAX NetWatch - نصب خودکار
color 0B
echo ==========================================================
echo   HDMAX NetWatch Pro - نصب خودکار (یکبار اجرا کافی است)
echo ==========================================================
cd /d "%~dp0.."

echo [1/5] بررسی Node.js...
where node >nul 2>nul
if errorlevel 1 (
  echo [X] Node.js یافت نشد! لطفاً ابتدا از https://nodejs.org نسخه LTS را نصب کنید و دوباره این فایل را اجرا نمایید.
  pause
  exit /b 1
)
node -v

echo [2/5] ایجاد فایل تنظیمات .env (در صورت نبودن)...
if not exist .env (
  echo DATABASE_URL=postgresql://postgres:postgres@127.0.0.1:5432/app_db> .env
  echo     ساخته شد.
) else (
  echo     موجود است.
)

echo [3/5] نصب وابستگی‌ها (npm install)...
call npm install --no-audit --no-fund
if errorlevel 1 goto :fail

echo [4/5] ساخت نسخه نهایی (npm run build)...
call npm run build
if errorlevel 1 goto :fail

echo [5/5] تلاش برای ساخت دیتابیس app_db (اختیاری)...
where psql >nul 2>nul
if not errorlevel 1 (
  psql -U postgres -c "CREATE DATABASE app_db;" >nul 2>nul
  echo     انجام شد (اگر از قبل بود، مشکلی نیست).
) else (
  echo     psql پیدا نشد — برنامه بدون دیتابیس هم کار می‌کند (حالت حافظه‌ای).
)

echo.
echo ==========================================================
echo   نصب کامل شد! حالا فایل 2-start.bat را اجرا کنید.
echo   سپس مرورگر: http://localhost:3000  (admin / admin)
echo ==========================================================
pause
exit /b 0

:fail
echo.
echo [X] خطا در نصب. خروجی بالا را بررسی کنید.
pause
exit /b 1
