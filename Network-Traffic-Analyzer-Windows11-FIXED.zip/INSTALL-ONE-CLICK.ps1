$ErrorActionPreference = "Stop"
Set-Location -LiteralPath $PSScriptRoot

Write-Host "==========================================" -ForegroundColor Cyan
Write-Host " Network Traffic Analyzer - AUTO INSTALL" -ForegroundColor Cyan
Write-Host "==========================================" -ForegroundColor Cyan

function Find-Exe($name) {
    $cmd = Get-Command $name -ErrorAction SilentlyContinue
    if ($cmd) { return $cmd.Source }
    $roots = @("$env:ProgramFiles\PostgreSQL", "${env:ProgramFiles(x86)}\PostgreSQL")
    foreach ($root in $roots) {
        if (Test-Path $root) {
            $hit = Get-ChildItem $root -Recurse -Filter $name -ErrorAction SilentlyContinue | Select-Object -First 1
            if ($hit) { return $hit.FullName }
        }
    }
    return $null
}

# Find/install Node.js
$node = Find-Exe "node.exe"
if (-not $node) {
    Write-Host "Node.js was not found. Trying to install Node.js LTS..." -ForegroundColor Yellow
    $winget = Get-Command winget -ErrorAction SilentlyContinue
    if (-not $winget) {
        throw "Node.js is not installed and winget is unavailable. Install Node.js LTS once, then run this installer again."
    }
    winget install --id OpenJS.NodeJS.LTS --exact --accept-source-agreements --accept-package-agreements
    $env:Path = [Environment]::GetEnvironmentVariable("Path","Machine") + ";" + [Environment]::GetEnvironmentVariable("Path","User")
    $node = Find-Exe "node.exe"
}
if (-not $node) { throw "Node.js installation failed." }

Write-Host "Node.js OK: $(& $node --version)" -ForegroundColor Green

# Find PostgreSQL
$psql = Find-Exe "psql.exe"
if (-not $psql) {
    throw "PostgreSQL was not found. Install PostgreSQL with user postgres and password hdmax, then run this installer again."
}

# Start PostgreSQL service
$pgServices = Get-Service -ErrorAction SilentlyContinue | Where-Object {
    $_.Name -match '^postgresql' -or $_.DisplayName -match 'PostgreSQL'
}
foreach ($svc in $pgServices) {
    if ($svc.Status -ne "Running") {
        try { Start-Service -Name $svc.Name -ErrorAction Stop } catch {}
    }
}

Write-Host "PostgreSQL OK." -ForegroundColor Green

# Create database if needed
$env:PGPASSWORD = "hdmax"
$exists = & $psql -h 127.0.0.1 -p 5432 -U postgres -d postgres -tAc "SELECT 1 FROM pg_database WHERE datname='app_db';" 2>$null
if ($LASTEXITCODE -ne 0) {
    Remove-Item Env:PGPASSWORD -ErrorAction SilentlyContinue
    throw "Could not connect to PostgreSQL using postgres/hdmax on port 5432."
}
if (($exists | Out-String).Trim() -ne "1") {
    & $psql -h 127.0.0.1 -p 5432 -U postgres -d postgres -c "CREATE DATABASE app_db;"
    if ($LASTEXITCODE -ne 0) {
        Remove-Item Env:PGPASSWORD -ErrorAction SilentlyContinue
        throw "Could not create database app_db."
    }
}
Remove-Item Env:PGPASSWORD -ErrorAction SilentlyContinue
Write-Host "Database app_db OK." -ForegroundColor Green

# Install dependencies
Write-Host "Running npm install..." -ForegroundColor Yellow
npm install
if ($LASTEXITCODE -ne 0) { throw "npm install failed." }

# Database schema
Write-Host "Updating database schema..." -ForegroundColor Yellow
npx drizzle-kit push
if ($LASTEXITCODE -ne 0) { throw "drizzle-kit push failed." }

# Build
Write-Host "Building application..." -ForegroundColor Yellow
npm run build
if ($LASTEXITCODE -ne 0) { throw "npm run build failed." }

# Launcher
$launcher = Join-Path $PSScriptRoot "START-NETWORK-MONITOR.ps1"
@'
Set-Location -LiteralPath $PSScriptRoot
$node = Get-Command node.exe -ErrorAction SilentlyContinue
if (-not $node) { $node = Get-ChildItem "$env:ProgramFiles\nodejs\node.exe" -ErrorAction SilentlyContinue | Select-Object -First 1 }
if (-not $node) { exit 1 }
Start-Process -FilePath $node.Source -ArgumentList "node_modules\next\dist\bin\next","start","-p","3000" -WorkingDirectory $PSScriptRoot -WindowStyle Hidden
Start-Sleep -Seconds 5
Start-Process "http://localhost:3000"
'@ | Set-Content -LiteralPath $launcher -Encoding ASCII

# Auto-start at Windows logon
$taskName = "Network Traffic Analyzer"
$action = New-ScheduledTaskAction -Execute "powershell.exe" -Argument "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$launcher`""
$trigger = New-ScheduledTaskTrigger -AtLogOn
$principal = New-ScheduledTaskPrincipal -UserId $env:USERNAME -LogonType Interactive -RunLevel LeastPrivilege
try {
    Register-ScheduledTask -TaskName $taskName -Action $action -Trigger $trigger -Principal $principal -Force | Out-Null
    Write-Host "Auto-start enabled." -ForegroundColor Green
} catch {
    Write-Host "Could not register auto-start task. You can still run START-NETWORK-MONITOR.ps1 manually." -ForegroundColor Yellow
}

Write-Host ""
Write-Host "INSTALLATION COMPLETE!" -ForegroundColor Green
Write-Host "Open: http://localhost:3000" -ForegroundColor Green
Write-Host ""
powershell.exe -NoProfile -ExecutionPolicy Bypass -File $launcher
