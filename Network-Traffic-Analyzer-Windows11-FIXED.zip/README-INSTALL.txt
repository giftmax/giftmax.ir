NETWORK TRAFFIC ANALYZER - ONE CLICK INSTALLER

Windows 11

1. Make sure PostgreSQL is installed.
2. PostgreSQL user: postgres
3. PostgreSQL password: hdmax
4. Double-click INSTALL-ONE-CLICK.bat
5. Wait until installation finishes.
6. The app will open at http://localhost:3000
7. Auto-start at Windows logon is configured automatically.

This installer uses ASCII-only PowerShell to avoid UTF-8/ANSI parser errors.
