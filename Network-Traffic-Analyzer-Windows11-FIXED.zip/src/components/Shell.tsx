"use client";

import { useEffect, useState, type ReactNode } from "react";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import {
  LayoutDashboard, Network, Server, Router, Waypoints, ShieldAlert, Radar,
  BarChart3, BookOpen, Activity, Zap, Flame, Database, DatabaseZap, FileText,
  Bell, Gauge, Globe2, Mail, FolderTree, ArchiveRestore, KeyRound, Settings,
  LogOut, Menu, X, Wifi, WifiOff, Timer, RadioTower, Antenna, Share2, HeartPulse, Sigma,
  type LucideIcon,
} from "lucide-react";
import { useSnap } from "@/lib/useEngine";
import { faTime } from "@/lib/format";

type Me = { id: number; username: string; role: string; perms: string[] } | null;

type NavItem = { href: string; label: string; icon: LucideIcon; perm: string };
type NavGroup = { title: string; items: NavItem[] };
const NAV: NavGroup[] = [
  {
    title: "پایش اصلی",
    items: [
      { href: "/", label: "داشبورد مدیریت", icon: LayoutDashboard, perm: "dashboard" },
      { href: "/watch", label: "پایش رنج‌ها", icon: Gauge, perm: "ranges" },
      { href: "/ranges", label: "محدوده‌های IP", icon: Network, perm: "ranges" },
      { href: "/servers", label: "سرورها و مجازی‌سازی", icon: Server, perm: "servers" },
      { href: "/devices", label: "تجهیزات شبکه", icon: Router, perm: "servers" },
      { href: "/tree", label: "درخت دامنه", icon: FolderTree, perm: "tree" },
      { href: "/fiber", label: "لبه فیبر مناطق", icon: RadioTower, perm: "servers" },
      { href: "/wireless", label: "سرویس‌های وایرلس", icon: Antenna, perm: "servers" },
    ],
  },
  {
    title: "شبکه و DNS",
    items: [
      { href: "/routes", label: "مسیر و ردیابی", icon: Waypoints, perm: "routes" },
      { href: "/routing", label: "نقشه مسیریابی", icon: Share2, perm: "routes" },
      { href: "/services", label: "پایداری سرویس‌ها", icon: HeartPulse, perm: "routes" },
      { href: "/snmp", label: "SNMP و نقش‌ها", icon: Network, perm: "servers" },
      { href: "/dns", label: "DNS و رنج پابلیک", icon: Radar, perm: "dns" },
    ],
  },
  {
    title: "امنیت و هوش تهدید",
    items: [
      { href: "/security", label: "مرکز امنیت", icon: ShieldAlert, perm: "security" },
      { href: "/iran", label: "رنج‌های ایران + تهدید", icon: Globe2, perm: "security" },
      { href: "/mail", label: "پایش ایمیل‌سرور", icon: Mail, perm: "security" },
    ],
  },
  {
    title: "داده و گزارش",
    items: [
      { href: "/reports", label: "گزارشات و آمار", icon: BarChart3, perm: "dashboard" },
      { href: "/analytics", label: "تحلیل SPL", icon: Sigma, perm: "dashboard" },
      { href: "/logs", label: "لاگ و Syslog", icon: FileText, perm: "logs" },
      { href: "/backup", label: "پشتیبان‌گیری", icon: ArchiveRestore, perm: "logs" },
    ],
  },
  {
    title: "سیستم",
    items: [
      { href: "/license", label: "لایسنس HDMAX", icon: KeyRound, perm: "license" },
      { href: "/settings", label: "تنظیمات و کاربران", icon: Settings, perm: "settings" },
      { href: "/guide", label: "راهنمای نصب (ویندوز)", icon: BookOpen, perm: "settings" },
    ],
  },
];

export default function Shell({ children }: { children: ReactNode }) {
  const path = usePathname();
  const router = useRouter();
  const { snap, connected } = useSnap();
  const [clock, setClock] = useState("");
  const [busy, setBusy] = useState<string | null>(null);
  const [me, setMe] = useState<Me>(null);
  const [authChecked, setAuthChecked] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [gate, setGate] = useState(true);

  const isLogin = path === "/login";

  useEffect(() => {
    const f = () => setClock(`${new Date().toLocaleDateString("fa-IR", { weekday: "long", month: "long", day: "numeric" })} — ${faTime(Date.now())}`);
    f();
    const iv = setInterval(f, 1000);
    return () => clearInterval(iv);
  }, []);

  useEffect(() => {
    if (isLogin) {
      setAuthChecked(true);
      return;
    }
    fetch("/api/auth")
      .then(async (r) => {
        if (r.status === 401) {
          router.replace("/login");
          return;
        }
        const j = await r.json();
        setMe(j.user ?? null);
        setAuthChecked(true);
      })
      .catch(() => setAuthChecked(true));
  }, [isLogin, router]);

  if (isLogin) return <>{children}</>;
  if (!authChecked) {
    return <div className="grid min-h-screen place-items-center"><div className="shimmer h-24 w-72" /></div>;
  }

  const can = (perm: string) => !!me && (me.role === "admin" || me.perms.includes("*") || me.perms.includes(perm));
  const lic = snap?.lic;
  const licAlarm = !!lic && (lic.state === "expired" || lic.state === "locked" || lic.state === "issued" || lic.syncDue);
  const licAlarmHard = !!lic && (lic.state === "expired" || lic.state === "locked");
  const net = snap?.net;

  const simulate = async (kind: string) => {
    setBusy(kind);
    try {
      await fetch("/api/simulate", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ kind }) });
    } finally {
      setTimeout(() => setBusy(null), 1500);
    }
  };
  const logout = async () => {
    await fetch("/api/auth", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ action: "logout" }) });
    router.replace("/login");
  };

  return (
    <div className="flex min-h-screen">
      {/* موبایل: دکمه همبرگر */}
      <button className="fixed right-3 top-3 z-50 grid h-10 w-10 place-items-center rounded-xl border border-slate-500/20 bg-[#0a0f1c]/90 text-slate-200 backdrop-blur lg:hidden" onClick={() => setMenuOpen(!menuOpen)} aria-label="منو">
        {menuOpen ? <X size={18} /> : <Menu size={18} />}
      </button>
      {menuOpen && <div className="fixed inset-0 z-40 bg-black/60 backdrop-blur-sm lg:hidden" onClick={() => setMenuOpen(false)} />}

      {/* سایدبار */}
      <aside className={`fixed inset-y-0 right-0 z-40 flex w-[232px] flex-col border-l border-slate-500/10 bg-[#070b14]/95 backdrop-blur-xl transition-transform duration-300 lg:translate-x-0 ${menuOpen ? "translate-x-0" : "translate-x-full"}`}>
        <div className="flex items-center gap-3 border-b border-slate-500/10 px-5 py-5">
          <span className="grid h-11 w-11 flex-none place-items-center rounded-2xl border border-cyan-400/40 bg-gradient-to-br from-cyan-400/25 to-violet-500/20 shadow-[0_0_24px_-6px_rgba(34,211,238,0.6)]">
            <Activity size={22} className="text-cyan-300" />
          </span>
          <div className="min-w-0">
            <div className="truncate text-[13.5px] font-extrabold tracking-tight leading-5">
              <span className="glow-text">HDMAX NetWatch Pro</span>
            </div>
            <div className="mt-0.5 text-[9.5px] leading-4 text-slate-500">سامانه جامع مانیتورینگ و پایش رخداد — مکس‌پلاس</div>
          </div>
        </div>
        <nav className="flex-1 space-y-4 overflow-y-auto p-3 pb-6">
          {NAV.map((g) => {
            const items = g.items.filter((n) => can(n.perm));
            if (!items.length) return null;
            return (
              <div key={g.title}>
                <div className="mb-1.5 px-3 text-[9.5px] font-bold uppercase tracking-wider text-slate-600">{g.title}</div>
                <div className="space-y-0.5">
                  {items.map((n) => {
                    const active = path === n.href || (n.href !== "/" && path.startsWith(n.href));
                    return (
                      <Link
                        key={n.href}
                        href={n.href}
                        onClick={() => setMenuOpen(false)}
                        className={`flex items-center gap-3 rounded-xl px-3.5 py-2 text-[12.5px] font-medium transition-all ${
                          active
                            ? "border border-cyan-400/30 bg-cyan-400/10 text-cyan-200 shadow-[inset_0_0_20px_-8px_rgba(34,211,238,0.5)]"
                            : "border border-transparent text-slate-400 hover:bg-slate-400/5 hover:text-slate-200"
                        }`}
                      >
                        <n.icon size={16} className={active ? "text-cyan-300" : "text-slate-500"} />
                        {n.label}
                      </Link>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </nav>
        <div className="space-y-2 border-t border-slate-500/10 p-3.5 text-[10.5px]">
          <div className="flex items-center justify-between text-slate-500">
            <span>موتور پایش</span>
            <span className="flex items-center gap-1.5 font-medium" style={{ color: connected ? "#34d399" : "#fb7185" }}>
              <i className={connected ? "live-dot" : "live-dot-red"} />
              {connected ? "زنده" : "قطع"}
            </span>
          </div>
          <div className="flex items-center justify-between text-slate-500">
            <span>دیتابیس</span>
            <span className="flex items-center gap-1 font-medium" style={{ color: snap?.dbReady ? "#34d399" : "#fbbf24" }}>
              {snap?.dbReady ? <DatabaseZap size={11} /> : <Database size={11} />}
              {snap?.dbReady ? "PostgreSQL" : snap ? "حافظه‌ای" : "—"}
            </span>
          </div>
          <div className="flex items-center justify-between text-slate-500">
            <span>چرخه نمونه</span>
            <span className="mono text-slate-300">{snap ? `${snap.tickMs / 1000}s` : "—"}</span>
          </div>
          <div className="rounded-lg border border-slate-500/15 bg-slate-500/5 p-2 text-center text-slate-400">{clock}</div>
          {me && (
            <button onClick={logout} className="flex w-full items-center justify-between rounded-lg border border-slate-500/15 bg-slate-500/5 px-2.5 py-1.5 text-slate-300 transition-colors hover:border-rose-400/30 hover:text-rose-300">
              <span className="flex items-center gap-1.5">کاربر: <b>{me.username}</b></span>
              <LogOut size={12} />
            </button>
          )}
        </div>
      </aside>

      {/* محتوا */}
      <div className="mr-0 flex min-h-screen flex-1 flex-col lg:mr-[232px]">
        <header className="sticky top-0 z-30 flex flex-wrap items-center justify-between gap-2 border-b border-slate-500/10 bg-[#05070e]/80 px-4 py-2.5 backdrop-blur-xl lg:px-6">
          <div className="flex flex-wrap items-center gap-2 text-[12px] text-slate-400">
            <span className="chip">
              <i className={connected ? "live-dot" : "live-dot-red"} />
              {connected ? "پایش لحظه‌ای فعال" : "در انتظار اتصال…"}
            </span>
            {/* وضعیت اینترنت */}
            {net && (
              <span className="chip" style={net.online ? { color: "#34d399", borderColor: "#34d39940", background: "#34d39910" } : { color: "#fb7185", borderColor: "#fb718540", background: "#fb718512" }}>
                {net.online ? <Wifi size={12} /> : <WifiOff size={12} />}
                {net.online ? `اینترنت وصل — ping 8.8.8.8: ${net.ping}ms` : "آفلاین — اینترنت وصل نیست"}
              </span>
            )}
            {snap?.sec.campaign && (
              <span className="chip animate-pulse" style={{ color: "#fb7185", borderColor: "#fb718555", background: "#fb718514" }}>
                <Flame size={12} /> حمله در حال وقوع
              </span>
            )}
          </div>
          <div className="flex flex-wrap items-center gap-2">
            {/* تایمر لایسنس */}
            {lic && lic.state !== "none" ? (
              <Link href="/license" className="chip !py-1.5" style={{ color: licAlarmHard ? "#fb7185" : lic.daysLeft <= 30 ? "#fbbf24" : "#34d399", borderColor: "currentColor" }}>
                <Timer size={12} />
                لایسنس: {lic.state === "expired" ? "منقضی‌شده" : lic.state === "locked" ? "قفل (نیازمند همگام‌سازی)" : `${lic.daysLeft} روز مانده`}
              </Link>
            ) : (
              <Link href="/license" className="chip !py-1.5 text-slate-400"><KeyRound size={12} /> بدون لایسنس — صدور</Link>
            )}
            {/* زنگ هشدار لایسنس */}
            {licAlarm && (
              <Link href="/license" className={`relative grid h-8 w-8 place-items-center rounded-xl border ${licAlarmHard ? "border-rose-400/50 bg-rose-400/10 text-rose-300" : "border-amber-400/50 bg-amber-400/10 text-amber-300"} animate-bounce`} title="هشدار لایسنس — برای همگام‌سازی/تمدید کلیک کنید">
                <Bell size={15} />
                <span className={`absolute -left-1 -top-1 h-2.5 w-2.5 rounded-full ${licAlarmHard ? "bg-rose-400" : "bg-amber-400"} animate-ping`} />
              </Link>
            )}
            <button onClick={() => simulate("spike")} disabled={busy === "spike"} className="btn btn-ghost !hidden !py-1.5 !text-[11.5px] xl:inline-flex" title="جهش مصرف نمایشی">
              <Zap size={13} /> {busy === "spike" ? "OK" : "جهش مصرف"}
            </button>
            <button onClick={() => simulate("attack")} disabled={busy === "attack"} className="btn btn-danger !hidden !py-1.5 !text-[11.5px] xl:inline-flex" title="حمله نمایشی">
              <Flame size={13} /> {busy === "attack" ? "…" : "شبیه‌سازی حمله"}
            </button>
          </div>
        </header>
        <main className="mx-auto w-full max-w-[1600px] flex-1 px-4 py-5 lg:px-6 lg:py-6">{children}</main>
        <footer className="border-t border-slate-500/10 px-6 py-3 text-center text-[10.5px] text-slate-600">
          HDMAX NetWatch Pro — سامانه جامع مانیتورینگ و پایش رخداد (مکس‌پلاس) • Node.js + SSE • نسخه ۲.۰
        </footer>
      </div>

      {/* گیت فعال‌سازی لایسنس — اولین اجرا */}
      {snap && lic && lic.state !== "active" && gate && (
        <div className="fixed inset-0 z-[70] grid place-items-center bg-black/75 p-4 backdrop-blur-md">
          <div className="glass fade-up w-full max-w-md p-7 text-center">
            <span className="mx-auto mb-4 grid h-14 w-14 place-items-center rounded-2xl border border-amber-400/40 bg-amber-400/10">
              <KeyRound size={26} className="text-amber-300" />
            </span>
            <h2 className="text-[16px] font-extrabold text-slate-100">فعال‌سازی لایسنس HDMAX</h2>
            <p className="mt-2 text-[12px] leading-6 text-slate-400">
              {lic.state === "none"
                ? "برای این نصب هنوز لایسنسی صادر نشده است. لطفاً ابتدا لایسنس را صادر و از طریق اینترنت و سایت giftmax.ir اصالت آن را تأیید کنید تا دسترسی کامل فعال شود."
                : lic.state === "issued"
                  ? "لایسنس صادر شده اما هنوز با سرور giftmax.ir همگام‌سازی و اصالت‌سنجی نشده — تا این زمان، سامانه فقط «قابل مشاهده» است (پایش زنده و لاگ فعال، ویرایش/ایجاد قفل)."
                  : lic.state === "locked"
                    ? "دوره همگام‌سازی ۴۵ روزه گذشته — برای بازکردن قفل، آنلاین شوید و همگام‌سازی کنید."
                    : "اعتبار لایسنس پایان یافته — برای فعال‌سازی مجدد، لایسنس جدید صادر کنید."}
            </p>
            <div className="mt-5 space-y-2">
              <Link href="/license" onClick={() => setGate(false)} className="btn w-full !py-3">
                <KeyRound size={16} /> رفتن به صدور / فعال‌سازی لایسنس
              </Link>
              <button onClick={() => setGate(false)} className="btn btn-ghost w-full">
                {lic.state === "none" ? "ادامه در حالت آزمایشی" : "ادامه به‌صورت فقط‌مشاهده"}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
