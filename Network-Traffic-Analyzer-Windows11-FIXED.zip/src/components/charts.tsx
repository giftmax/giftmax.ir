"use client";

import { useId, useMemo, useRef, useState, type ReactNode } from "react";
import { faTime, fmtRate } from "@/lib/format";

// ------------------ مسیر نرم Catmull-Rom ------------------
function smoothPath(pts: { x: number; y: number }[]): string {
  if (pts.length < 2) return pts.length ? `M ${pts[0].x} ${pts[0].y}` : "";
  let d = `M ${pts[0].x} ${pts[0].y}`;
  for (let i = 0; i < pts.length - 1; i++) {
    const p0 = pts[Math.max(0, i - 1)];
    const p1 = pts[i];
    const p2 = pts[i + 1];
    const p3 = pts[Math.min(pts.length - 1, i + 2)];
    const c1x = p1.x + (p2.x - p0.x) / 6;
    const c1y = p1.y + (p2.y - p0.y) / 6;
    const c2x = p2.x - (p3.x - p1.x) / 6;
    const c2y = p2.y - (p3.y - p1.y) / 6;
    d += ` C ${c1x} ${c1y} ${c2x} ${c2y} ${p2.x} ${p2.y}`;
  }
  return d;
}

// ------------------ نمودار زنده دو سری (دریافت/ارسال) ------------------
export interface LivePoint {
  t: number;
  a: number; // دریافت
  b?: number; // ارسال
}
export function LiveChart({
  data,
  colorA = "#22d3ee",
  colorB = "#a78bfa",
  labelA = "دریافت",
  labelB = "ارسال",
  height = 200,
  fmt = fmtRate,
  showB = true,
  extra,
  timeFmt = faTime,
  fill = true,
}: {
  data: LivePoint[];
  colorA?: string;
  colorB?: string;
  labelA?: string;
  labelB?: string;
  height?: number;
  fmt?: (v: number) => string;
  showB?: boolean;
  extra?: (i: number) => ReactNode;
  timeFmt?: (t: number) => string;
  fill?: boolean;
}) {
  const id = useId().replace(/:/g, "");
  const boxRef = useRef<HTMLDivElement>(null);
  const [hov, setHov] = useState<number | null>(null);

  const { lineA, areaA, lineB, areaB, max, pts } = useMemo(() => {
    const W = 100;
    const H = 100;
    const pad = 6;
    const n = data.length;
    if (n < 2) return { lineA: "", areaA: "", lineB: "", areaB: "", max: 1, pts: [] as { x: number; y: number }[] };
    let mx = 1;
    data.forEach((p) => {
      mx = Math.max(mx, p.a, showB ? p.b ?? 0 : 0);
    });
    mx *= 1.15;
    const px = data.map((p, i) => ({
      x: pad + (i / (n - 1)) * (W - pad * 2),
      y: H - pad - (p.a / mx) * (H - pad * 2),
    }));
    const py = data.map((p, i) => ({
      x: pad + (i / (n - 1)) * (W - pad * 2),
      y: H - pad - ((showB ? p.b ?? 0 : 0) / mx) * (H - pad * 2),
    }));
    const lA = smoothPath(px);
    const lB = showB ? smoothPath(py) : "";
    const aA = `${lA} L ${px[n - 1].x} ${H - pad} L ${px[0].x} ${H - pad} Z`;
    const aB = showB ? `${lB} L ${py[n - 1].x} ${H - pad} L ${py[0].x} ${H - pad} Z` : "";
    return { lineA: lA, areaA: aA, lineB: lB, areaB: aB, max: mx, pts: px };
  }, [data, showB]);

  const onMove = (e: React.MouseEvent) => {
    const rect = boxRef.current?.getBoundingClientRect();
    if (!rect || data.length < 2) return;
    const frac = (e.clientX - rect.left) / rect.width;
    const i = Math.round(frac * (data.length - 1));
    setHov(Math.max(0, Math.min(data.length - 1, i)));
  };

  const hp = hov != null ? data[hov] : null;
  const tipLeft = hov != null && pts.length ? (data.length > 1 ? (hov / (data.length - 1)) * 100 : 0) : 0;

  return (
    <div className="relative w-full select-none" ref={boxRef} onMouseMove={onMove} onMouseLeave={() => setHov(null)} dir="ltr">
      <svg width="100%" height={height} viewBox="0 0 100 100" preserveAspectRatio="none" className="overflow-visible">
        <defs>
          <linearGradient id={`ga${id}`} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor={colorA} stopOpacity="0.35" />
            <stop offset="100%" stopColor={colorA} stopOpacity="0" />
          </linearGradient>
          <linearGradient id={`gb${id}`} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor={colorB} stopOpacity="0.28" />
            <stop offset="100%" stopColor={colorB} stopOpacity="0" />
          </linearGradient>
        </defs>
        {[0.25, 0.5, 0.75].map((f) => (
          <line key={f} x1="6" x2="94" y1={6 + f * 88} y2={6 + f * 88} stroke="rgba(148,163,184,0.12)" strokeWidth="0.25" vectorEffect="non-scaling-stroke" />
        ))}
        {fill && showB && areaB && <path d={areaB} fill={`url(#gb${id})`} />}
        {fill && <path d={areaA} fill={`url(#ga${id})`} />}
        {showB && lineB && (
          <path d={lineB} fill="none" stroke={colorB} strokeWidth="1.6" vectorEffect="non-scaling-stroke" strokeLinejoin="round" strokeLinecap="round" opacity="0.95" />
        )}
        <path d={lineA} fill="none" stroke={colorA} strokeWidth="1.8" vectorEffect="non-scaling-stroke" strokeLinejoin="round" strokeLinecap="round" />
        {hov != null && pts[hov] && (
          <line x1={pts[hov].x} x2={pts[hov].x} y1="6" y2="94" stroke="rgba(230,236,247,0.35)" strokeWidth="0.4" vectorEffect="non-scaling-stroke" />
        )}
        {hov != null && pts[hov] && (
          <circle cx={pts[hov].x} cy={pts[hov].y} r="1.2" fill={colorA} stroke="#05070e" strokeWidth="0.5" vectorEffect="non-scaling-stroke" />
        )}
      </svg>
      <div className="absolute left-1 top-1 text-[10px] text-slate-500 mono" dir="ltr">
        {fmt(max / 1.15)}
      </div>
      {hp && hov != null && (
        <div
          className="pointer-events-none absolute z-20 w-56 rounded-xl border border-slate-500/25 bg-[#0b1120]/95 p-3 shadow-2xl backdrop-blur-md"
          style={{ left: tipLeft > 62 ? "auto" : `calc(${tipLeft}% + 8px)`, right: tipLeft > 62 ? `calc(${100 - tipLeft}% + 8px)` : "auto", top: 8 }}
          dir="rtl"
        >
          <div className="mb-1.5 flex items-center justify-between text-[11px] text-slate-400">
            <span>زمان</span>
            <span className="mono text-slate-200">{timeFmt(hp.t)}</span>
          </div>
          <div className="flex items-center justify-between text-[12px]">
            <span className="flex items-center gap-1.5">
              <i className="inline-block h-2 w-2 rounded-full" style={{ background: colorA }} />
              {labelA}
            </span>
            <b className="mono" style={{ color: colorA }}>{fmt(hp.a)}</b>
          </div>
          {showB && (
            <div className="mt-1 flex items-center justify-between text-[12px]">
              <span className="flex items-center gap-1.5">
                <i className="inline-block h-2 w-2 rounded-full" style={{ background: colorB }} />
                {labelB}
              </span>
              <b className="mono" style={{ color: colorB }}>{fmt(hp.b ?? 0)}</b>
            </div>
          )}
          {extra && (
            <div className="mt-2 border-t border-slate-500/20 pt-2 text-[11px] leading-5 text-slate-300">{extra(hov)}</div>
          )}
        </div>
      )}
    </div>
  );
}

// ------------------ اسپارک‌لاین مینیاتوری ------------------
export function Spark({ data, color = "#22d3ee", w = 96, h = 26, fill: doFill = true }: { data: number[]; color?: string; w?: number; h?: number; fill?: boolean }) {
  const id = useId().replace(/:/g, "");
  const d = useMemo(() => {
    if (data.length < 2) return { line: "", area: "" };
    const mx = Math.max(...data, 0.0001);
    const pts = data.map((v, i) => ({ x: (i / (data.length - 1)) * w, y: h - 2 - (v / mx) * (h - 4) }));
    const line = smoothPath(pts);
    return { line, area: `${line} L ${w} ${h} L 0 ${h} Z` };
  }, [data, w, h]);
  if (data.length < 2) return <div style={{ width: w, height: h }} className="rounded bg-slate-500/10" />;
  return (
    <svg width={w} height={h} viewBox={`0 0 ${w} ${h}`} className="overflow-visible">
      <defs>
        <linearGradient id={`s${id}`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={color} stopOpacity="0.4" />
          <stop offset="100%" stopColor={color} stopOpacity="0" />
        </linearGradient>
      </defs>
      {doFill && <path d={d.area} fill={`url(#s${id})`} />}
      <path d={d.line} fill="none" stroke={color} strokeWidth="1.5" vectorEffect="non-scaling-stroke" strokeLinecap="round" />
    </svg>
  );
}

// ------------------ دونات ------------------
export function Donut({ items, size = 116, thickness = 13 }: { items: { name: string; pct: number; color?: string }[]; size?: number; thickness?: number }) {
  const palette = ["#22d3ee", "#a78bfa", "#fbbf24", "#34d399", "#fb7185", "#60a5fa", "#f472b6"];
  const list = items.filter((x) => x.pct > 0).map((x, i) => ({ ...x, color: x.color || palette[i % palette.length] }));
  const total = list.reduce((a, x) => a + x.pct, 0) || 1;
  let acc = 0;
  const R = 15.9155;
  return (
    <div className="flex items-center gap-4">
      <svg width={size} height={size} viewBox="0 0 42 42" className="-rotate-90">
        <circle cx="21" cy="21" r={R} fill="none" stroke="rgba(148,163,184,0.12)" strokeWidth={thickness / 3.6} />
        {list.map((it, i) => {
          const frac = (it.pct / total) * 100;
          const el = (
            <circle
              key={i}
              cx="21"
              cy="21"
              r={R}
              fill="none"
              stroke={it.color}
              strokeWidth={thickness / 3.6}
              strokeDasharray={`${frac} ${100 - frac}`}
              strokeDashoffset={100 - acc + 25}
              strokeLinecap="butt"
            />
          );
          acc += frac;
          return el;
        })}
      </svg>
      <div className="space-y-1 text-[11px]">
        {list.map((it, i) => (
          <div key={i} className="flex items-center gap-2">
            <i className="inline-block h-2 w-2 rounded-sm" style={{ background: it.color }} />
            <span className="text-slate-400">{it.name}</span>
            <b className="mono text-slate-200">{Math.round((it.pct / total) * 100)}%</b>
          </div>
        ))}
      </div>
    </div>
  );
}
