"use client";

import type { ReactNode } from "react";
import Link from "next/link";
import {
  Network, Router, Server, MonitorSmartphone, ShieldAlert, Box, AppWindow,
  Flame, Layers, Cpu, Globe, type LucideIcon,
} from "lucide-react";
import { KIND_FA, SEV_FA } from "@/lib/format";

export const KIND_COLORS: Record<string, string> = {
  cisco: "#60a5fa", mikrotik: "#fb7185", switch: "#34d399", windows: "#38bdf8",
  esxi: "#fbbf24", vm: "#c084fc", server: "#a78bfa", firewall: "#f97316", other: "#94a3b8", host: "#94a3b8",
};

const KIND_ICONS: Record<string, LucideIcon> = {
  cisco: Network, mikrotik: Router, switch: Layers, windows: AppWindow,
  esxi: Cpu, vm: Box, server: Server, firewall: ShieldAlert, other: MonitorSmartphone, host: MonitorSmartphone,
};

export function KindIcon({ kind, size = 16, className }: { kind: string; size?: number; className?: string }) {
  const Icon = KIND_ICONS[kind] ?? MonitorSmartphone;
  return <Icon size={size} className={className} style={{ color: KIND_COLORS[kind] ?? "#94a3b8" }} />;
}

export function KindChip({ kind }: { kind: string }) {
  return (
    <span className="chip" style={{ color: KIND_COLORS[kind] ?? "#94a3b8", borderColor: `${KIND_COLORS[kind] ?? "#94a3b8"}44`, background: `${KIND_COLORS[kind] ?? "#94a3b8"}12` }}>
      <KindIcon kind={kind} size={12} />
      {KIND_FA[kind] ?? kind}
    </span>
  );
}

export const SEV_COLORS: Record<string, string> = {
  low: "#34d399", medium: "#fbbf24", high: "#fb923c", critical: "#fb7185",
};

export function SevBadge({ sev }: { sev: string }) {
  const c = SEV_COLORS[sev] ?? "#94a3b8";
  return (
    <span className="chip" style={{ color: c, borderColor: `${c}55`, background: `${c}14` }}>
      <Flame size={11} />
      {SEV_FA[sev] ?? sev}
    </span>
  );
}

export function Section({ title, sub, icon: Icon, action }: { title: string; sub?: string; icon?: LucideIcon; action?: ReactNode }) {
  return (
    <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
      <div className="flex items-center gap-3">
        {Icon && (
          <span className="grid h-10 w-10 place-items-center rounded-xl border border-cyan-400/25 bg-cyan-400/10 text-cyan-300">
            <Icon size={19} />
          </span>
        )}
        <div>
          <h2 className="text-[15px] font-bold text-slate-100">{title}</h2>
          {sub && <p className="mt-0.5 text-[11.5px] text-slate-500">{sub}</p>}
        </div>
      </div>
      {action}
    </div>
  );
}

export function PageHead({ title, sub, chips }: { title: string; sub: string; chips?: ReactNode }) {
  return (
    <div className="fade-up mb-6 flex flex-wrap items-end justify-between gap-4">
      <div>
        <h1 className="text-2xl font-extrabold tracking-tight">
          <span className="glow-text">{title}</span>
        </h1>
        <p className="mt-1.5 max-w-2xl text-[12.5px] leading-6 text-slate-400">{sub}</p>
      </div>
      {chips && <div className="flex flex-wrap items-center gap-2">{chips}</div>}
    </div>
  );
}

export function Stat({ icon: Icon, label, value, sub, color = "#22d3ee", href }: { icon: LucideIcon; label: string; value: ReactNode; sub?: ReactNode; color?: string; href?: string }) {
  const inner = (
    <div className={`glass ${href ? "glass-hover cursor-pointer" : ""} relative overflow-hidden p-4`}>
      <div className="absolute -left-6 -top-6 h-20 w-20 rounded-full blur-2xl" style={{ background: `${color}22` }} />
      <div className="flex items-center justify-between">
        <span className="grid h-9 w-9 place-items-center rounded-lg border" style={{ color, borderColor: `${color}44`, background: `${color}14` }}>
          <Icon size={17} />
        </span>
      </div>
      <div className="mt-3 text-[22px] font-extrabold leading-7 text-slate-50" dir="ltr" style={{ textAlign: "right" }}>
        {value}
      </div>
      <div className="mt-1 text-[11.5px] text-slate-400">{label}</div>
      {sub && <div className="mt-2 text-[11px] text-slate-500">{sub}</div>}
    </div>
  );
  return href ? <Link href={href}>{inner}</Link> : inner;
}

export function Empty({ text }: { text: string }) {
  return (
    <div className="glass flex flex-col items-center gap-3 p-10 text-center text-[13px] text-slate-500">
      <Globe size={26} className="text-slate-600" />
      {text}
    </div>
  );
}

export function Skeleton({ h = 120 }: { h?: number }) {
  return <div className="shimmer w-full" style={{ height: h }} />;
}

export function Toggle({ on, onChange, title }: { on: boolean; onChange: () => void; title?: string }) {
  return <button type="button" title={title} onClick={onChange} className={`toggle ${on ? "on" : ""}`} aria-pressed={on} />;
}
