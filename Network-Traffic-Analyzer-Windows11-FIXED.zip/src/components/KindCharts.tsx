"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { Server, Network, Router, ShieldHalf, MonitorCog, Eye, RadioTower, Antenna } from "lucide-react";
import { useSnap } from "@/lib/useEngine";
import { LiveChart, type LivePoint } from "@/components/charts";
import { Section } from "@/components/ui";
import { fmtRate, fmtInt } from "@/lib/format";

const GROUP_META: Record<string, { label: string; sub: string; color: string; icon: typeof Server }> = {
  servers: { label: "سرورها و ماشین‌های مجازی", sub: "سرور، ویندوز، ESXi و VM", color: "#a78bfa", icon: Server },
  switches: { label: "سوئیچ‌ها", sub: "سیسکو و سوئیچ‌های لایه توزیع/دسترسی", color: "#34d399", icon: Network },
  mikrotik: { label: "میکروتیک / روترها", sub: "روترهای لبه و گیت‌وی", color: "#fb7185", icon: Router },
  firewall: { label: "فایروال", sub: "دیواره آتش مرزی", color: "#fb923c", icon: ShieldHalf },
  fiber: { label: "لبه‌های فیبر مناطق", sub: "اپلینک فیبر شعب", color: "#e879f9", icon: RadioTower },
  wireless: { label: "رادیوهای وایرلس", sub: "میکروتیک‌های بی‌سیم", color: "#38bdf8", icon: Antenna },
};
const ORDER = ["servers", "switches", "mikrotik", "firewall", "fiber", "wireless"];

export default function KindCharts({ title = "پایش لحظه‌ای تجهیزات و سرورها — تفکیک‌شده بر اساس نوع" }: { title?: string }) {
  const { snap } = useSnap();
  const [hist, setHist] = useState<Record<string, LivePoint[]>>({});

  useEffect(() => {
    if (!snap) return;
    setHist((h) => {
      const nh = { ...h };
      for (const g of snap.kindAgg) {
        nh[g.key] = [...(nh[g.key] ?? []), { t: snap.t, a: g.i, b: g.o }].slice(-260);
      }
      return nh;
    });
  }, [snap]);

  if (!snap || !snap.kindAgg.length) return null;
  const groups = ORDER.map((k) => snap.kindAgg.find((g) => g.key === k)).filter((g): g is NonNullable<typeof g> => !!g);

  return (
    <div>
      <Section
        icon={MonitorCog}
        title={title}
        sub="هر نوع تجهیز نمودار مستقل دارد — زیر هر نمودار ۳ IP پرمصرف همان گروه (پهنای باند IP-Base)"
      />
      <div className="fade-up grid gap-4 lg:grid-cols-2 xl:grid-cols-3">
        {groups.map((g) => {
          const meta = GROUP_META[g.key] ?? { label: g.key, sub: "", color: "#94a3b8", icon: Server };
          const Icon = meta.icon;
          return (
            <div key={g.key} className="glass glass-hover p-4">
              <div className="mb-3 flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <span className="grid h-9 w-9 place-items-center rounded-xl border" style={{ color: meta.color, borderColor: `${meta.color}44`, background: `${meta.color}12` }}>
                    <Icon size={17} />
                  </span>
                  <div>
                    <div className="text-[13px] font-bold text-slate-100">{meta.label}</div>
                    <div className="text-[10.5px] text-slate-500">{meta.sub}</div>
                  </div>
                </div>
                <span className="chip !text-[10px]">
                  <i className="live-dot" />
                  {g.on}/{g.n} آنلاین
                </span>
              </div>
              <LiveChart data={hist[g.key] ?? []} height={140} colorA={meta.color} />
              <div className="mt-3 flex items-center justify-between text-[11px]">
                <span className="text-slate-500">مجموع لحظه‌ای</span>
                <b className="mono" style={{ color: meta.color }}>{fmtRate(g.i + g.o)}</b>
              </div>
              <div className="mt-2 space-y-1 border-t border-slate-500/10 pt-2">
                <div className="text-[10px] font-semibold text-slate-500">پرمصرف‌ترین IPها این گروه:</div>
                {g.top.map(([ip, rate]) => (
                  <div key={ip} className="flex items-center justify-between gap-2 text-[11px]">
                    <Link href={`/ip/${ip}`} className="mono text-cyan-300 hover:underline">{ip}</Link>
                    <div className="flex items-center gap-2">
                      <div className="progress-track w-20">
                        <div className="progress-fill" style={{ width: `${g.top[0] ? (rate / g.top[0][1]) * 100 : 0}%`, background: meta.color }} />
                      </div>
                      <b className="mono w-24 text-left text-slate-200" dir="ltr">{fmtRate(rate)}</b>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          );
        })}
      </div>
      <p className="mt-3 text-[11px] text-slate-600">
        {fmtInt(groups.reduce((a, g) => a + g.n, 0))} تجهیز پایش می‌شود —
        <Link href="/devices" className="mr-1 inline-flex items-center gap-1 text-cyan-400 hover:text-cyan-200"><Eye size={11} /> جزئیات در بخش تجهیزات</Link>
      </p>
    </div>
  );
}
