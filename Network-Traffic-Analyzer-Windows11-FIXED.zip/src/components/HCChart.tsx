"use client";

import { useMemo, useRef } from "react";
import Highcharts from "highcharts";
import HighchartsReact from "highcharts-react-official";
import { fmtRate, faTime } from "@/lib/format";

export interface HCSeries {
  name: string;
  color: string;
  data: [number, number][];
}

/** نمودار حرفه‌ای زنده بر پایه Highcharts — گرادیان، کراس‌هیر، تول‌تیپ سفارشی */
export default function HCSpline({
  series,
  height = 240,
  yFmt = fmtRate,
  tooltipExtra,
}: {
  series: HCSeries[];
  height?: number;
  yFmt?: (v: number) => string;
  tooltipExtra?: (index: number, t: number) => string;
}) {
  const chartRef = useRef<HighchartsReact.RefObject>(null);

  const options = useMemo<Highcharts.Options>(
    () => ({
      chart: {
        type: "areaspline",
        height,
        backgroundColor: "transparent",
        animation: false,
        style: { fontFamily: "Vazirmatn, JetBrains Mono" },
        spacing: [4, 0, 4, 0],
      },
      title: { text: undefined },
      credits: { enabled: false },
      accessibility: { enabled: false },
      xAxis: {
        type: "datetime",
        labels: { style: { color: "#64748b", fontSize: "9.5px" }, format: "{value:%H:%M:%S}" },
        lineColor: "rgba(148,163,184,0.15)",
        tickColor: "rgba(148,163,184,0.15)",
        crosshair: { color: "rgba(230,236,247,0.35)", dashStyle: "Dash" },
      },
      yAxis: {
        title: { text: undefined },
        gridLineColor: "rgba(148,163,184,0.1)",
        labels: {
          style: { color: "#64748b", fontSize: "9.5px" },
          formatter: function () {
            return yFmt(Number(this.value));
          },
        },
      },
      legend: {
        enabled: series.length > 1,
        itemStyle: { color: "#94a3b8", fontSize: "10px", fontWeight: "normal" },
        itemHoverStyle: { color: "#e6ecf7" },
      },
      plotOptions: {
        areaspline: {
          animation: false,
          marker: { enabled: false },
          lineWidth: 1.8,
          fillOpacity: 0.16,
          states: { hover: { lineWidthPlus: 0.5 } },
        },
      },
      tooltip: {
        shared: true,
        useHTML: true,
        backgroundColor: "rgba(11,17,32,0.96)",
        borderColor: "rgba(148,163,184,0.3)",
        borderRadius: 12,
        style: { color: "#e6ecf7", fontSize: "11.5px", direction: "rtl", fontFamily: "Vazirmatn" },
        formatter: function () {
          const pts = (this.points ?? []) as Highcharts.Point[];
          const t = Number(this.x);
          let html = `<div style="padding:2px 4px;min-width:190px"><div style="color:#94a3b8;font-size:10px;margin-bottom:4px;direction:ltr;text-align:left">${faTime(t)}</div>`;
          pts.forEach((p) => {
            html += `<div style="display:flex;justify-content:space-between;gap:14px"><span><span style="display:inline-block;width:8px;height:8px;border-radius:99px;background:${p.color as string};margin-inline-end:6px"></span>${p.series.name}</span><b style="direction:ltr;color:${p.color as string}">${yFmt(Number(p.y))}</b></div>`;
          });
          if (tooltipExtra && pts[0] != null) {
            const extra = tooltipExtra(pts[0].index, t);
            if (extra) html += `<div style="border-top:1px solid rgba(148,163,184,0.2);margin-top:6px;padding-top:5px">${extra}</div>`;
          }
          return html + "</div>";
        },
      },
      series: series.map(
        (s) =>
          ({
            type: "areaspline",
            name: s.name,
            color: s.color,
            data: s.data,
            turboThreshold: 5000,
            fillColor: {
              linearGradient: { x1: 0, y1: 0, x2: 0, y2: 1 },
              stops: [
                [0, Highcharts.color(s.color).setOpacity(0.32).get("rgba") as string],
                [1, Highcharts.color(s.color).setOpacity(0).get("rgba") as string],
              ],
            },
          }) as Highcharts.SeriesOptionsType,
      ),
    }),
    [series, height, yFmt, tooltipExtra],
  );

  return <div dir="ltr"><HighchartsReact highcharts={Highcharts} options={options} ref={chartRef} /></div>;
}
