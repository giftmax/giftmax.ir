import {
  pgTable,
  serial,
  text,
  integer,
  bigint,
  boolean,
  timestamp,
  uniqueIndex,
  index,
} from "drizzle-orm/pg-core";

/** محدوده‌های شبکه (رنج IP) */
export const ranges = pgTable("nm_ranges", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  cidr: text("cidr").notNull(),
  kind: text("kind").notNull().default("lan"), // lan | servers | dmz | wan | iot
  color: text("color").notNull().default("#22d3ee"),
  groupName: text("group_name").notNull().default(""), // نام بخش/منطقه — یک بخش می‌تواند چند رنج داشته باشد
  createdAt: timestamp("created_at", { withTimezone: false })
    .notNull()
    .defaultNow(),
});

/** تجهیزات: سوئیچ سیسکو، میکروتیک، سرور، ESXi، ماشین مجازی، ویندوز و... */
export const devices = pgTable("nm_devices", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  ip: text("ip").notNull(),
  kind: text("kind").notNull().default("server"),
  // cisco | mikrotik | switch | windows | esxi | vm | server | firewall | other
  rangeId: integer("range_id"),
  parentId: integer("parent_id"), // VM -> ESXi host
  isDomain: boolean("is_domain").notNull().default(false),
  snmp: boolean("snmp").notNull().default(true),
  wmi: boolean("wmi").notNull().default(false),
  ilo: boolean("ilo").notNull().default(false),
  community: text("community").notNull().default("public"),
  osVersion: text("os_version"),
  notes: text("notes"),
  createdAt: timestamp("created_at", { withTimezone: false })
    .notNull()
    .defaultNow(),
});

/** تجمیع ساعتی مصرف هر IP (برای نمودار ۲۴ ساعت) */
export const hourly = pgTable(
  "nm_hourly",
  {
    id: serial("id").primaryKey(),
    ip: text("ip").notNull(),
    ts: timestamp("ts", { withTimezone: false }).notNull(), // ابتدای ساعت
    bytesIn: bigint("bytes_in", { mode: "number" }).notNull().default(0),
    bytesOut: bigint("bytes_out", { mode: "number" }).notNull().default(0),
    sessions: integer("sessions").notNull().default(0),
    pkts: integer("pkts").notNull().default(0),
  },
  (t) => [
    uniqueIndex("nm_hourly_ip_ts_uq").on(t.ip, t.ts),
    index("nm_hourly_ts_idx").on(t.ts),
  ],
);

/** تجمیع روزانه مصرف هر IP (برای نمودار ۳۰ روز) */
export const daily = pgTable(
  "nm_daily",
  {
    id: serial("id").primaryKey(),
    ip: text("ip").notNull(),
    day: timestamp("day", { withTimezone: false }).notNull(), // ابتدای روز
    bytesIn: bigint("bytes_in", { mode: "number" }).notNull().default(0),
    bytesOut: bigint("bytes_out", { mode: "number" }).notNull().default(0),
    sessions: integer("sessions").notNull().default(0),
    pkts: integer("pkts").notNull().default(0),
  },
  (t) => [
    uniqueIndex("nm_daily_ip_day_uq").on(t.ip, t.day),
    index("nm_daily_day_idx").on(t.day),
  ],
);

/** رخدادهای امنیتی / تلاش‌های نفوذ */
export const events = pgTable(
  "nm_events",
  {
    id: serial("id").primaryKey(),
    ts: timestamp("ts", { withTimezone: false }).notNull().defaultNow(),
    srcIp: text("src_ip").notNull(),
    dstIp: text("dst_ip").notNull(),
    type: text("type").notNull(), // port-scan | brute-force | icmp-flood | anomaly | unauth-access | rate-limit
    severity: text("severity").notNull().default("medium"), // low | medium | high | critical
    action: text("action").notNull().default("blocked"),
    detail: text("detail"),
  },
  (t) => [index("nm_events_ts_idx").on(t.ts)],
);

/** تنظیمات کلید/مقدار (مسیر لاگ، بازه نگهداشت و...) */
export const settings = pgTable("nm_settings", {
  key: text("key").primaryKey(),
  value: text("value").notNull(),
});

/** کاربران سامانه */
export const users = pgTable("nm_users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull(),
  hash: text("hash").notNull(),
  role: text("role").notNull().default("operator"), // admin | operator
  perms: text("perms").notNull().default("[]"), // JSON array of tab keys
  active: boolean("active").notNull().default(true),
  createdAt: timestamp("created_at", { withTimezone: false }).notNull().defaultNow(),
});

/** رکورد لایسنس (تک‌ردیفه) */
export const license = pgTable("nm_license", {
  id: serial("id").primaryKey(),
  file: text("file").notNull(),
  content: text("content").notNull(),
  meta: text("meta").notNull(), // JSON LicenseMeta
  state: text("state").notNull().default("issued"), // issued | active | expired
  lastSync: timestamp("last_sync", { withTimezone: false }),
  createdAt: timestamp("created_at", { withTimezone: false }).notNull().defaultNow(),
});

/** رکوردهای DNS داخلی/خارجی و رنج پابلیک */
export const dnsRecords = pgTable("nm_dns", {
  id: serial("id").primaryKey(),
  scope: text("scope").notNull(), // internal | external | public
  ip: text("ip").notNull(),
  domain: text("domain").notNull().default(""),
  name: text("name").notNull().default(""),
  inUse: boolean("in_use").notNull().default(true),
  label: text("label").notNull().default(""), // نام رنج/گروه
  createdAt: timestamp("created_at", { withTimezone: false }).notNull().defaultNow(),
});

/** درخت دامنه */
export const treeNodes = pgTable("nm_tree", {
  id: serial("id").primaryKey(),
  parentId: integer("parent_id"),
  name: text("name").notNull(),
  kind: text("kind").notNull().default("branch"), // root | branch | leaf
  ips: text("ips").notNull().default("[]"), // JSON array of IPs
  createdAt: timestamp("created_at", { withTimezone: false }).notNull().defaultNow(),
});

/** نقش‌های SNMP (پروفایل گردآوری) */
export const snmpRoles = pgTable("nm_snmp_roles", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  deviceKind: text("device_kind").notNull().default("all"),
  version: text("version").notNull().default("v2c"), // v1 | v2c | v3
  user: text("user").notNull().default(""),
  authType: text("auth_type").notNull().default("SHA-256"),
  oids: text("oids").notNull().default("[]"), // JSON: گروه‌های OID
  acls: text("acls").notNull().default("[]"), // JSON: آدرس‌های مجاز
  enabled: boolean("enabled").notNull().default(true),
  createdAt: timestamp("created_at", { withTimezone: false }).notNull().defaultNow(),
});

/** قوانین Syslog انتخابی */
export const syslogRules = pgTable("nm_syslog_rules", {
  id: serial("id").primaryKey(),
  targetType: text("target_type").notNull(), // device | range | ip
  target: text("target").notNull(),
  direction: text("direction").notNull().default("in"), // in | out | both
  enabled: boolean("enabled").notNull().default(true),
  createdAt: timestamp("created_at", { withTimezone: false }).notNull().defaultNow(),
});

export type RangeRow = typeof ranges.$inferSelect;
export type DeviceRow = typeof devices.$inferSelect;
export type EventRow = typeof events.$inferSelect;
