import crypto from "node:crypto";
import os from "node:os";
import path from "node:path";
import { mkdir, readFile, writeFile } from "node:fs/promises";

// =====================================================================
//  احراز هویت داخلی — scrypt + نشست امضاشده با HMAC (کوکی httpOnly)
// =====================================================================

export interface SessionUser {
  id: number;
  username: string;
  role: string;
  perms: string[];
}

const COOKIE = "hdx_sess";
let cachedSecret: Buffer | null = null;

async function secret(): Promise<Buffer> {
  if (cachedSecret) return cachedSecret;
  const file = path.join(os.homedir(), "NadirNetWatch", "hdx.key");
  try {
    cachedSecret = Buffer.from((await readFile(file, "utf8")).trim(), "base64");
    if (cachedSecret.length !== 32) throw new Error("x");
  } catch {
    cachedSecret = crypto.randomBytes(32);
    await mkdir(path.dirname(file), { recursive: true });
    await writeFile(file, cachedSecret.toString("base64"), { mode: 0o600 });
  }
  return cachedSecret;
}

export function hashPassword(pw: string): string {
  const salt = crypto.randomBytes(16).toString("hex");
  const h = crypto.scryptSync(pw, salt, 64).toString("hex");
  return `scrypt$${salt}$${h}`;
}

export function verifyPassword(pw: string, stored: string): boolean {
  const [alg, salt, h] = stored.split("$");
  if (alg !== "scrypt" || !salt || !h) return false;
  const v = crypto.scryptSync(pw, salt, 64);
  const hv = Buffer.from(h, "hex");
  return v.length === hv.length && crypto.timingSafeEqual(v, hv);
}

export async function signSession(user: SessionUser, days = 3): Promise<string> {
  const payload = Buffer.from(JSON.stringify({ ...user, exp: Date.now() + days * 86_400_000 })).toString("base64url");
  const s = await secret();
  const sig = crypto.createHmac("sha256", s).update(payload).digest("base64url");
  return `${payload}.${sig}`;
}

export async function readSession(token: string | undefined): Promise<(SessionUser & { exp: number }) | null> {
  if (!token) return null;
  const [payload, sig] = token.split(".");
  if (!payload || !sig) return null;
  const s = await secret();
  const expect = crypto.createHmac("sha256", s).update(payload).digest("base64url");
  if (expect !== sig) return null;
  try {
    const u = JSON.parse(Buffer.from(payload, "base64url").toString("utf8")) as SessionUser & { exp: number };
    if (!u.exp || u.exp < Date.now()) return null;
    return u;
  } catch {
    return null;
  }
}

export function sessionFromRequest(req: Request): Promise<(SessionUser & { exp: number }) | null> {
  const cookie = req.headers.get("cookie") ?? "";
  const m = cookie.match(new RegExp(`(?:^|;\\s*)${COOKIE}=([^;]+)`));
  return readSession(m?.[1]);
}

export function setCookieHeader(token: string, days = 3): string {
  return `${COOKIE}=${token}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${days * 86400}`;
}

export function clearCookieHeader(): string {
  return `${COOKIE}=; Path=/; HttpOnly; Max-Age=0`;
}

/** تب‌های سیستم برای دسترسی تیک‌خور */
export const PERM_TABS = [
  { key: "dashboard", label: "داشبورد مدیریت" },
  { key: "ranges", label: "محدوده‌ها و پایش رنج‌ها" },
  { key: "servers", label: "سرورها و تجهیزات" },
  { key: "routes", label: "مسیر و ردیابی" },
  { key: "security", label: "مرکز امنیت و هوش تهدید" },
  { key: "dns", label: "DNS و رنج پابلیک" },
  { key: "tree", label: "درخت دامنه" },
  { key: "logs", label: "لاگ، Syslog و پشتیبان‌گیری" },
  { key: "license", label: "لایسنس" },
  { key: "settings", label: "تنظیمات و کاربران" },
  { key: "analytics", label: "تحلیل SPL و آمار" },
  { key: "snmp", label: "مدیریت SNMP" },
] as const;
