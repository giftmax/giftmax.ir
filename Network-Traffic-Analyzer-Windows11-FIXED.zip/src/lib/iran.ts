import { ipToInt } from "./format";

// =====================================================================
//  دیتاست رنج‌های IPv4 ایران (بر اساس ISP) — به‌روزرسانی هفتگی هنگام اتصال
// =====================================================================
export interface IranRange {
  isp: string;
  en: string;
  cidr: string;
  cls: string;
  ips: number;
}
export const IRAN_RANGES: IranRange[] = (
  [
    ["همراه اول (MCI)", "Mobile Communication Company", "5.208.0.0/12"],
    ["همراه اول (MCI)", "Mobile Communication Company", "37.254.0.0/15"],
    ["ایرانسل (MTN)", "MTN Irancell", "2.176.0.0/12"],
    ["ایرانسل (MTN)", "MTN Irancell", "37.129.0.0/16"],
    ["رایتل", "Rightel", "95.80.128.0/17"],
    ["رایتل", "Rightel", "92.42.48.0/21"],
    ["مخابرات ایران (TCI)", "Telecommunication Company of Iran", "2.144.0.0/14"],
    ["مخابرات ایران (TCI)", "Telecommunication Company of Iran", "5.22.0.0/17"],
    ["مخابرات ایران (TCI)", "Telecommunication Company of Iran", "78.38.0.0/15"],
    ["شاتل", "Shatel Group", "85.185.0.0/16"],
    ["شاتل", "Shatel Group", "94.182.0.0/15"],
    ["آسیاتک", "Asiatech", "79.127.0.0/17"],
    ["آسیاتک", "Asiatech", "188.245.0.0/16"],
    ["پارس‌آنلاین", "Pars Online", "91.98.0.0/15"],
    ["های‌وب (فناپ)", "HiWeb / FANAP", "185.120.120.0/22"],
    ["مبین‌نت", "MobinNet", "78.111.0.0/16"],
    ["زیتل", "Zi-Tel / TDLTE", "185.143.232.0/22"],
    ["پیشگامان", "Pishgaman/Tose'e", "5.190.0.0/16"],
    ["رایتل TL-LTE", "Rightel TD-LTE", "109.125.128.0/17"],
    ["شاتل موبایل", "Shatel Mobile", "185.94.96.0/22"],
  ] as [string, string, string][]
).map(([isp, en, cidr]) => {
  const bits = Number(cidr.split("/")[1]);
  const ips = 2 ** (32 - bits);
  return { isp, en, cidr, cls: bits <= 8 ? "A" : bits <= 16 ? "B" : "C", ips };
});

export function findIranIsp(ip: string): IranRange | null {
  const n = ipToInt(ip);
  if (n < 0) return null;
  for (const r of IRAN_RANGES) {
    const [baseS, bitsS] = r.cidr.split("/");
    const bits = Number(bitsS);
    const mask = (0xffffffff << (32 - bits)) >>> 0;
    if (((n & mask) >>> 0) === ((ipToInt(baseS) & mask) >>> 0)) return r;
  }
  return null;
}

// =====================================================================
//  دیتاست تحلیل حملات (Threat Intel) — تحلیل: چیست، چگونه، مبدأ/مقصد
// =====================================================================
export interface ThreatInfo {
  id: string;
  name: string;
  fa: string;
  cat: string;
  severity: string;
  how: string;
  src: string;
  dst: string;
  indicator: string;
  defense: string;
}
export const THREATS: ThreatInfo[] = [
  {
    id: "mirai", name: "Mirai Botnet", fa: "بات‌نت میرای", cat: "Botnet", severity: "critical",
    how: "اسکن گسترده پورت 23/2323، حدس رمزهای پیش‌فرض تجهیزات IoT/مودم‌ها و تبدیل آن‌ها به بات برای DDoS. پس از آلودگی به سرور C2 گزارش می‌دهد.",
    src: "IPهای آلوده جهانی/داخلی (اغلب مودم‌ها و دوربین‌ها)", dst: "پورت 23 و 2323 تجهیزات لبه شما",
    indicator: "اسکن سریع و ترتیبی Telnet از چند مبدأ", defense: "بستن Telnet روی اینترنت، تغییر رمز پیش‌فرض مودم‌ها، قانون Geo-blocking",
  },
  {
    id: "c2-beacon", name: "C2 Beaconing", fa: "ارتباط Beacon با سرور فرمان", cat: "C2", severity: "critical",
    how: "بدافزار داخل شبکه در بازه‌های زمانی منظم به آدرس ثابت خارجی درخواست‌های کوچک می‌فرستد تا فرمان بگیرد (Heartbeat).",
    src: "یک میزبان آلوده داخلی", dst: "دامنه/IP ثابت خارجی روی 443/80",
    indicator: "بسته‌های کوچک منظم با فاصله زمانی ثابت", defense: "جداسازی میزبان، DNS-filtering، بررسی egress",
  },
  {
    id: "rdp-brute", name: "RDP Brute-Force", fa: "بروت‌فورس RDP", cat: "Brute-Force", severity: "high",
    how: "تلاش‌های پی‌درپی ورود با دیکشنری رمز روی پورت 3389؛ در صورت موفقیت، نفوذ و اجرای باج‌افزار.",
    src: "معمولاً IPهای اجاره‌ای/هایجک‌شده (کشورهای مختلف)", dst: "سرورهای ویندوز با RDP باز روی اینترنت",
    indicator: "ده‌ها نشست ناموفق در دقیقه روی 3389", defense: "تنها از طریق VPN، MFA، حساب-قفل، تغییر پورت",
  },
  {
    id: "ssh-brute", name: "SSH Brute-Force", fa: "بروت‌فورس SSH", cat: "Brute-Force", severity: "high",
    how: "حدس گسترده رمز root/admin روی پورت 22 با ابزارهایی مثل Hydra؛ سپس نصب بک‌دور.",
    src: "سرورهای ابری آلوده", dst: "سرورهای لینوکسی با SSH باز",
    indicator: "تلاش‌های ورود نامعتبر مکرر در لاگ", defense: "Key-only login، Fail2ban، محدودسازی IP",
  },
  {
    id: "scan-syn", name: "SYN Port Scan", fa: "اسکن پورت SYN", cat: "Recon", severity: "medium",
    how: "ارسال SYN به پورت‌ها و تحلیل پاسخ برای نقشه‌برداری از سرویس‌های شما پیش از حمله اصلی.",
    src: "اسکنرهای خودکار (Shodan-گونه و بات‌ها)", dst: "کل رنج پابلیک شما",
    indicator: "یک SYN به هر پورت بدون تکمیل handshake", defense: "Rate-limit روی فایروال، Port-knocking، کمینه‌سازی سرویس‌ها",
  },
  {
    id: "icmp-flood", name: "ICMP/Smurf Flood", fa: "سیل ICMP (DDoS)", cat: "DDoS", severity: "high",
    how: "باریدن حجم عظیم Echo-request به سمت قربانی برای اشباع پهنای باند یا تجهیز لبه.",
    src: "شبکه بات‌ها (مبدأهای متعدد)", dst: "آدرس پابلیک شما یا رنج کامل",
    indicator: "افزایش ناگهانی ICMP و latency لبه", defense: "سهمیه ICMP در لبه، سرویس Anti-DDoS اپراتور",
  },
  {
    id: "exfil", name: "Data Exfiltration", fa: "خروج غیرمجاز داده", cat: "Exfil", severity: "critical",
    how: "ارسال تدریجی داده به مقصد خارجی در ساعات غیرکاری، پنهان در پروتکل‌های مجاز (443/DNS).",
    src: "میزبان آلوده یا کاربر خطرناک داخلی", dst: "فضای ابری/سرور خارجی خاص",
    indicator: "نسبت آپلود به دانلود بالا در شب", defense: "DLP، مانیتور egress، سهمیه ساعاتی",
  },
  {
    id: "snmp-abuse", name: "SNMP Enumeration", fa: "بهره‌برداری SNMP", cat: "Recon", severity: "medium",
    how: "خواندن community پیش‌فرض (public) برای کشف توپولوژی، اینترفیس‌ها، سرورها و رمزهای ضعیف.",
    src: "اسکنرهای خارجی یا مهاجم داخلی", dst: "سوئیچ‌ها/سرورها با SNMPv1/v2c باز",
    indicator: "درخواست‌های GetBulk پی‌درپی UDP/161", defense: "SNMPv3، ACL منبع، تغییر community",
  },
];
