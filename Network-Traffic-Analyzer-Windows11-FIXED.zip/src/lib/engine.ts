import { EventEmitter } from "node:events";
import { db } from "@/db";
import {
  ranges as rangesT,
  devices as devicesT,
  hourly as hourlyT,
  daily as dailyT,
  events as eventsT,
  settings as settingsT,
  users as usersT,
  license as licenseT,
  dnsRecords as dnsT,
  treeNodes as treeT,
  syslogRules as syslogT,
} from "@/db/schema";
import { sql, eq, desc, gte, lt, and, inArray } from "drizzle-orm";
import { ipToInt, intToIp, parseCidr, isPrivateIp, fmtBytes, fmtRate } from "./format";
import { trafficLog, type LogEntry } from "./logger";
import { IRAN_RANGES, THREATS, findIranIsp } from "./iran";
import { hashPassword, verifyPassword } from "./auth";
import { appId, encodeSlf, decodeSlf, syncLicense, licenseFileName, type LicenseMeta } from "./license";
import { snmpRoles as snmpRolesT } from "@/db/schema";
import { mean, stdev, percentile, linreg, zscore, mad } from "./stats";
import { gzipSync } from "node:zlib";
import { mkdir, readdir, readFile as fsRead, writeFile as fsWrite, stat as fsStat } from "node:fs/promises";
import os from "node:os";
import path from "node:path";

// =====================================================================
//  موتور پایش شبکه — NADIR NetWatch Engine
//  - هر ۲ ثانیه یک تیک: محاسبه ترافیک هر IP، تجمیع رنج‌ها، رخدادها
//  - داده تاریخی (ساعتی/روزانه) در PostgreSQL ذخیره می‌شود
//  - اگر دیتابیس در دسترس نباشد، حالت حافظه‌ای فعال می‌شود
// =====================================================================

export interface Pt {
  t: number;
  i: number; // bytes/sec دریافت
  o: number; // bytes/sec ارسال
  s: number; // نشست‌ها
}
export interface Ev {
  id: number;
  ts: number;
  srcIp: string;
  dstIp: string;
  type: string;
  severity: string;
  action: string;
  detail: string;
  srcExt: boolean;
}
export interface Pkt {
  t: number;
  src: string;
  dst: string;
  proto: string;
  sp: number;
  dp: number;
  len: number;
  flags: string;
  info: string;
}
interface IpProfile {
  ip: string;
  rangeId: number | null;
  host: string;
  base: number;
  outRatio: number;
  vol: number;
  idle: boolean;
  server: boolean;
  external: boolean;
  susp?: { kind: "scan" | "exfil" | "flood" | "beacon"; score: number };
  burstUntil: number;
  burstMult: number;
  phase: number;
  peers: string[];
  cur: { i: number; o: number; s: number };
}

const TICK_MS = 2000;
const RING_CAP = 1800; // ۱ ساعت

function hash(str: string): number {
  let h = 2166136261;
  for (let i = 0; i < str.length; i++) {
    h ^= str.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}
function mulberry(seed: number) {
  let a = seed >>> 0;
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
const rnd = mulberry(20260214);
const clamp = (v: number, a: number, b: number) => Math.min(b, Math.max(a, v));

/** گروه‌بندی نوع تجهیز برای نمودارهای تفکیک‌شده پایش */
const KIND_GROUP: Record<string, string> = {
  server: "servers", windows: "servers", esxi: "servers", vm: "servers",
  cisco: "switches", switch: "switches", mikrotik: "mikrotik", firewall: "firewall",
  fiber: "fiber", wireless: "wireless",
};

function safeArr(s: string): string[] {
  try {
    const a = JSON.parse(s) as string[];
    return Array.isArray(a) ? a : [];
  } catch {
    return [];
  }
}

/** منحنی ساعتی ترافیک: اوج ساعات اداری */
function hourCurve(hour: number): number {
  const g = (mu: number, sig: number) => Math.exp(-((hour - mu) ** 2) / (2 * sig * sig));
  return clamp(0.12 + g(10, 2.6) * 1.0 + g(15, 2.4) * 0.85 + g(20.5, 1.6) * 0.22, 0.06, 1.25);
}

class Engine extends EventEmitter {
  started = false;
  starting: Promise<void> | null = null;
  dbReady = false;
  bootedAt = Date.now();

  ips = new Map<string, IpProfile>();
  rings = new Map<string, Pt[]>();
  totalRing: Pt[] = [];
  rangeRing = new Map<number, Pt[]>();
  topsRing: { t: number; tops: [string, number][] }[] = [];

  rangesCache: (typeof rangesT.$inferSelect)[] = [];
  devicesCache: (typeof devicesT.$inferSelect)[] = [];
  offlineUntil = new Map<number, number>();
  latency = new Map<number, number>();
  peerMap = new Map<string, Map<string, { i: number; o: number; hits: number; last: number }>>();
  devOnlinePrev = new Map<number, boolean>();
  kindAggStore: Record<string, { i: number; o: number; n: number; on: number; top: [string, number][] }> = {};
  deviceIpPool: string[] = [];
  rangeTops = new Map<number, [string, number]>();

  // --- پایداری سرویس‌ها (نمونه دقیقه‌ای ۲۴ ساعت) ---
  upSamples = new Map<number, { t: number; up: boolean }[]>();
  downOpen = new Map<number, number>();
  downWindows = new Map<number, { s: number; e: number }[]>();

  // --- وایرلس ---
  wireMeta = new Map<number, { freq: number; ch: number; base: number }>();
  signalRing = new Map<number, { t: number; sig: number; lat: number }[]>();

  // --- حالت آنلاین/آفلاین ---
  netMode: "auto" | "force-online" | "force-offline" = "auto";
  netOnline = true;
  netPing = 14;
  lastNetCheck = 0;
  iranUpdatedAt = 0;

  // --- لایسنس ---
  licRow: (typeof licenseT.$inferSelect) | null = null;
  licMeta: LicenseMeta | null = null;

  // --- کش‌های جدول‌های جدید ---
  treeCache: (typeof treeT.$inferSelect)[] = [];
  dnsCache: (typeof dnsT.$inferSelect)[] = [];
  syslogCache: (typeof syslogT.$inferSelect)[] = [];
  snmpRoleCache: (typeof snmpRolesT.$inferSelect)[] = [];
  devSnmp = new Map<number, { version: string; acl: string }>();

  // --- پشتیبان‌گیری ---
  backupDir = path.join(os.homedir(), "NadirNetWatch", "backups");
  backupDaily = "03:00";
  backupWeekly = 5; // روز هفته (0..6) برای فول‌بکاپ هفتگی
  backupMonthly = 1; // روز ماه برای فول‌بکاپ ماهانه
  lastBackupKey = "";

  recentEvents: Ev[] = [];
  evBuf: Ev[] = [];
  pktsBuf: Pkt[] = [];
  evId = 1;
  eventsToday = 0;
  blockedToday = 0;
  attackerCount = new Map<string, number>();
  targetCount = new Map<string, number>();
  campaign: { src: string; left: number; type: string; sev: string } | null = null;
  nextCampaign = Date.now() + 6 * 60_000;

  hourAcc = new Map<string, { i: number; o: number; s: number; p: number }>();
  dayAcc = new Map<string, { i: number; o: number; s: number; p: number }>();
  hourStart = new Date().setMinutes(0, 0, 0);
  dayStart = new Date().setHours(0, 0, 0, 0);
  tickCount = 0;

  async start() {
    if (this.started) return;
    if (this.starting) return this.starting;
    this.starting = this.boot();
    await this.starting;
    this.started = true;
    setInterval(() => this.tick(), TICK_MS);
    setInterval(() => this.flush(), 60_000);
    // لاگ ترافیک ۱۵ دقیقه‌ای به فایل روزانه
    setInterval(() => this.writeTrafficLogs(), 900_000);
    setTimeout(() => this.writeTrafficLogs(), 45_000);
  }

  // ------------------- راه‌اندازی -------------------
  async boot() {
    try {
      await db.execute(sql.raw(DDL));
      this.dbReady = true;
      this.rangesCache = await db.select().from(rangesT).orderBy(rangesT.id);
      this.devicesCache = await db.select().from(devicesT).orderBy(devicesT.id);
      if (this.rangesCache.length === 0) await this.seedDb();
      const evs = await db.select().from(eventsT).orderBy(desc(eventsT.ts)).limit(60);
      this.recentEvents = evs.map((e) => this.rowToEv(e)).reverse();
      this.evId = (evs[0]?.id ?? 0) + 1;
    } catch {
      this.dbReady = false;
      if (this.rangesCache.length === 0) await this.seedMemory();
    }
    // پروفایل‌ها قبل از Backfill ساخته می‌شوند تا تاریخچه ۳۰روزه تولید گردد
    this.buildProfiles();
    await trafficLog.init();
    await this.loadLogSettings();
    await this.loadExtra();
    await this.backfill();
    try {
      await trafficLog.purge();
    } catch {
      /* بعداً */
    }
    setInterval(() => this.purgeCycle(), 6 * 3600_000);
    // رخداد آغاز سرویس
    this.pushEvent({
      srcIp: "127.0.0.1",
      dstIp: "0.0.0.0",
      type: "unauth-access",
      severity: "low",
      action: "allowed",
      detail: "موتور پایش NADIR NetWatch با موفقیت راه‌اندازی شد",
    });
    trafficLog.add({ ts: Date.now(), cat: "system", level: "info", msg: `موتور پایش راه‌اندازی شد — مسیر لاگ: ${trafficLog.dir} • نگهداشت ${trafficLog.retentionDays} روز` }).catch(() => undefined);
  }

  rowToEv(e: typeof eventsT.$inferSelect): Ev {
    return {
      id: e.id,
      ts: new Date(e.ts).getTime(),
      srcIp: e.srcIp,
      dstIp: e.dstIp,
      type: e.type,
      severity: e.severity,
      action: e.action,
      detail: e.detail ?? "",
      srcExt: !isPrivateIp(e.srcIp) && !e.srcIp.startsWith("127."),
    };
  }

  async seedDb() {
    await db.insert(rangesT).values([
      { name: "شبکه کاربران", cidr: "192.168.1.0/24", kind: "lan", color: "#22d3ee", groupName: "دفتر مرکزی" },
      { name: "وایرلس مهمانان HQ", cidr: "192.168.2.0/24", kind: "lan", color: "#34d399", groupName: "دفتر مرکزی" },
      { name: "شبکه سرورها", cidr: "10.10.0.0/24", kind: "servers", color: "#a78bfa", groupName: "مرکز داده" },
      { name: "ناحیه DMZ", cidr: "172.16.8.0/24", kind: "dmz", color: "#f59e0b", groupName: "DMZ عمومی" },
    ]);
    this.rangesCache = await db.select().from(rangesT).orderBy(rangesT.id);
    const [lan, srv, dmz] = this.rangesCache.map((r) => r.id);
    await db.insert(devicesT).values([
      { name: "CORE-SW1 (Cisco 9300)", ip: "192.168.1.1", kind: "cisco", rangeId: lan, snmp: true, osVersion: "IOS-XE 17.9" },
      { name: "CORE-SW2 (Cisco 2960X)", ip: "192.168.1.2", kind: "switch", rangeId: lan, snmp: true, osVersion: "IOS 15.2" },
      { name: "MT-GW (MikroTik CCR)", ip: "192.168.1.254", kind: "mikrotik", rangeId: lan, snmp: true, osVersion: "RouterOS 7.14" },
      { name: "EDGE-FW (FortiGate)", ip: "172.16.8.1", kind: "firewall", rangeId: dmz, snmp: true, osVersion: "FortiOS 7.4" },
      { name: "ESXi-01 (Dell R740)", ip: "10.10.0.11", kind: "esxi", rangeId: srv, ilo: true, snmp: true, osVersion: "ESXi 8.0 U2" },
      { name: "ESXi-02 (HP DL380)", ip: "10.10.0.12", kind: "esxi", rangeId: srv, ilo: true, osVersion: "ESXi 8.0" },
      { name: "WAN-RTR (MikroTik RB5009)", ip: "198.51.100.1", kind: "mikrotik", rangeId: null, snmp: true, osVersion: "RouterOS 7.12" },
    ]);
    this.devicesCache = await db.select().from(devicesT).orderBy(devicesT.id);
    const e1 = this.devicesCache.find((d) => d.ip === "10.10.0.11")!.id;
    const e2 = this.devicesCache.find((d) => d.ip === "10.10.0.12")!.id;
    await db.insert(devicesT).values([
      { name: "DC01 — کنترلر دامین اصلی", ip: "10.10.0.21", kind: "windows", rangeId: srv, parentId: e1, isDomain: true, wmi: true, snmp: true, osVersion: "Windows Server 2022" },
      { name: "DC02 — کنترلر دامین دوم", ip: "10.10.0.22", kind: "windows", rangeId: srv, parentId: e1, isDomain: true, wmi: true, osVersion: "Windows Server 2022" },
      { name: "FS01 — فایل سرور", ip: "10.10.0.23", kind: "server", rangeId: srv, parentId: e1, snmp: true, osVersion: "Windows Server 2019" },
      { name: "WEB01 — وب سرور", ip: "10.10.0.24", kind: "server", rangeId: srv, parentId: e1, snmp: true, osVersion: "Ubuntu 24.04 LTS" },
      { name: "DB01 — دیتابیس", ip: "10.10.0.31", kind: "vm", rangeId: srv, parentId: e2, snmp: true, osVersion: "PostgreSQL 17" },
      { name: "APP01 — سرویس‌های داخلی", ip: "10.10.0.32", kind: "vm", rangeId: srv, parentId: e2, osVersion: "Debian 12" },
      { name: "BACKUP01 — پشتیبان‌گیری", ip: "10.10.0.33", kind: "vm", rangeId: srv, parentId: e2, osVersion: "Veeam 12" },
      { name: "MAIL-GW — دروازه ایمیل", ip: "172.16.8.10", kind: "server", rangeId: dmz, snmp: true, osVersion: "Postfix / Ubuntu" },
      { name: "PROXY — پراکسی خروجی", ip: "172.16.8.11", kind: "server", rangeId: dmz, snmp: true, osVersion: "Squid 6" },
    ]);
    this.devicesCache = await db.select().from(devicesT).orderBy(devicesT.id);
  }

  async seedMemory() {
    this.rangesCache = [
      { id: 1, name: "شبکه کاربران", cidr: "192.168.1.0/24", kind: "lan", color: "#22d3ee", groupName: "دفتر مرکزی", createdAt: new Date() },
      { id: 2, name: "شبکه سرورها", cidr: "10.10.0.0/24", kind: "servers", color: "#a78bfa", groupName: "مرکز داده", createdAt: new Date() },
      { id: 3, name: "ناحیه DMZ", cidr: "172.16.8.0/24", kind: "dmz", color: "#f59e0b", groupName: "DMZ عمومی", createdAt: new Date() },
    ];
    this.devicesCache = [];
  }

  // ------------------- ساخت پروفایل IPها -------------------
  buildProfiles() {
    this.ips.clear();
    const deviceIps = new Map(this.devicesCache.map((d) => [d.ip, d]));
    this.rangesCache.forEach((r) => {
      const c = parseCidr(r.cidr);
      if (!c) return;
      const rr = mulberry(hash(r.cidr));
      const nActive = r.kind === "lan" ? 34 : r.kind === "servers" ? 14 : 9;
      const startOff = r.kind === "lan" ? 50 : 20;
      for (let k = 0; k < nActive && startOff + k <= c.capacity; k++) {
        const ip = intToIp((c.base + startOff + k) >>> 0);
        const dev = deviceIps.get(ip);
        const idle = !dev && rr() < 0.22;
        const server = r.kind !== "lan" || !!dev;
        const base = idle ? 12 : server ? 40_000 + rr() * 320_000 : 4_000 + rr() * 60_000;
        const prof: IpProfile = {
          ip,
          rangeId: r.id,
          host: dev?.name ?? (r.kind === "lan" ? `PC-${ip.split(".")[3]}` : r.kind === "servers" ? `SRV-${ip.split(".")[3]}` : `DMZ-${ip.split(".")[3]}`),
          base,
          outRatio: server ? 0.7 + rr() * 0.9 : 0.12 + rr() * 0.35,
          vol: 0.18 + rr() * 0.5,
          idle,
          server,
          external: false,
          burstUntil: 0,
          burstMult: 1,
          phase: rr(),
          peers: [],
          cur: { i: 0, o: 0, s: 0 },
        };
        // چند IP مشکوک از هر رنج
        if (!dev && k % 11 === 5) {
          const kinds = ["scan", "exfil", "flood", "beacon"] as const;
          prof.susp = { kind: kinds[Math.floor(rr() * 4)], score: 58 + Math.floor(rr() * 38) };
        }
        this.ips.set(ip, prof);
      }
      // پروفایل آدرس‌های دیوایس در این رنج
      this.devicesCache.filter((d) => d.rangeId === r.id && !this.ips.has(d.ip)).forEach((d) => {
        this.ips.set(d.ip, {
          ip: d.ip, rangeId: r.id, host: d.name, base: 60_000 + rr() * 400_000,
          outRatio: 0.9, vol: 0.3, idle: false, server: true, external: false,
          burstUntil: 0, burstMult: 1, phase: rr(), peers: [], cur: { i: 0, o: 0, s: 0 },
        });
      });
    });
    // پروفایل دیوایس‌های بدون رنج مشخص (مانند روتر WAN) — برای پایش تفکیک‌شده تجهیزات
    this.devicesCache.filter((d) => !this.ips.has(d.ip)).forEach((d) => {
      const rr2 = mulberry(hash(d.ip) ^ 55);
      const ext = d.rangeId == null && !isPrivateIp(d.ip);
      this.ips.set(d.ip, {
        ip: d.ip, rangeId: d.rangeId, host: d.name,
        base: ext ? 15_000 + rr2() * 80_000 : 60_000 + rr2() * 380_000,
        outRatio: d.kind === "mikrotik" || d.kind === "firewall" ? 1.5 : 0.85,
        vol: 0.35, idle: false, server: true, external: ext,
        burstUntil: 0, burstMult: 1, phase: rr2(), peers: [], cur: { i: 0, o: 0, s: 0 },
      });
    });
    this.deviceIpPool = this.devicesCache.map((d) => d.ip);
    // همتاهای خارجی (برون‌مرزی)
    const extIps = ["8.8.8.8", "1.1.1.1", "140.82.121.4", "142.251.36.36", "151.101.1.69", "185.143.233.20", "185.199.108.133", "20.205.243.166", "104.21.48.161", "13.107.42.14"];
    extIps.forEach((ip) => {
      this.ips.set(ip, {
        ip, rangeId: null, host: this.extName(ip), base: 8_000 + rnd() * 120_000,
        outRatio: 1.4, vol: 0.4, idle: false, server: true, external: true,
        burstUntil: 0, burstMult: 1, phase: rnd(), peers: [], cur: { i: 0, o: 0, s: 0 },
      });
    });
    // اتصال همتای داخلی
    const extPool = extIps;
    this.ips.forEach((p) => {
      if (p.external) return;
      const pr = mulberry(hash(p.ip) ^ 99);
      p.peers = [extPool[Math.floor(pr() * extPool.length)], extPool[Math.floor(pr() * extPool.length)]];
    });
  }

  extName(ip: string): string {
    const m: Record<string, string> = {
      "8.8.8.8": "Google DNS", "1.1.1.1": "Cloudflare DNS", "140.82.121.4": "GitHub",
      "142.251.36.36": "Google Services", "151.101.1.69": "Reddit CDN", "185.143.233.20": "Digikala CDN",
      "185.199.108.133": "GitHub Pages", "20.205.243.166": "Microsoft", "104.21.48.161": "Cloudflare Edge",
      "13.107.42.14": "Microsoft 365",
    };
    return m[ip] ?? "سرویس خارجی";
  }

  // ------------------- Backfill تاریخچه -------------------
  async backfill() {
    if (!this.dbReady) return;
    try {
      const need = Math.max(1, [...this.ips.values()].filter((p) => !p.external).length);
      const chk = await db.select({ c: sql<number>`count(*)::int` }).from(dailyT);
      if ((chk[0]?.c ?? 0) >= need * 20) return; // تاریخچه ۳۰روزه قبلاً کامل شده
      const ips = [...this.ips.values()].filter((p) => !p.external);
      const now = new Date();
      const dRows: (typeof dailyT.$inferInsert)[] = [];
      const hRows: (typeof hourlyT.$inferInsert)[] = [];
      for (const p of ips) {
        const pr = mulberry(hash(p.ip) ^ 7);
        for (let d = 30; d >= 1; d--) {
          const day = new Date(now);
          day.setDate(day.getDate() - d);
          day.setHours(0, 0, 0, 0);
          const dow = day.getDay();
          const weekend = dow === 4 || dow === 5 ? 0.45 : 1; // جمعه/شنبه خلوت‌تر
          const f = weekend * (0.7 + pr() * 0.6);
          const bin = Math.round(p.base * 0.55 * 86400 * f * (p.idle ? 0.05 : 1));
          dRows.push({ ip: p.ip, day, bytesIn: bin, bytesOut: Math.round(bin * p.outRatio * (0.7 + pr() * 0.6)), sessions: Math.round(50 + pr() * 900), pkts: Math.round(bin / 700) });
        }
        for (let h = 24; h >= 1; h--) {
          const hour = new Date(this.hourStart - h * 3600_000);
          const f = hourCurve(hour.getHours()) * (0.7 + pr() * 0.6);
          const bin = Math.round(p.base * f * 3600 * (p.idle ? 0.04 : 1));
          hRows.push({ ip: p.ip, ts: hour, bytesIn: bin, bytesOut: Math.round(bin * p.outRatio * (0.7 + pr() * 0.6)), sessions: Math.round(4 + pr() * 120), pkts: Math.round(bin / 700) });
        }
      }
      const chunk = async <T,>(rows: T[], n: number, fn: (c: T[]) => Promise<unknown>) => {
        for (let i = 0; i < rows.length; i += n) await fn(rows.slice(i, i + n));
      };
      await chunk(dRows, 400, (c) => db.insert(dailyT).values(c).onConflictDoNothing());
      await chunk(hRows, 400, (c) => db.insert(hourlyT).values(c).onConflictDoNothing());
    } catch {
      /* نادیده گرفته می‌شود */
    }
  }

  // ------------------- تیک اصلی -------------------
  tick() {
    const now = Date.now();
    this.tickCount++;
    const hour = new Date(now).getHours() + new Date(now).getMinutes() / 60;

    // وظایف دوره‌ای: چک اینترنت (هر ۳۰ ثانیه)، حملات ایرانی، Syslog، بکاپ
    if (this.tickCount % 15 === 0) {
      this.lastNetCheck = now;
      if (this.netMode === "force-offline") {
        this.netOnline = false;
        this.netPing = 0;
      } else if (this.netMode === "force-online") {
        this.netOnline = true;
        this.netPing = Math.round(12 + rnd() * 12);
      } else {
        const wasDown = !this.netOnline;
        if (wasDown && rnd() < 0.6) this.netOnline = true;
        else if (rnd() < 0.02) this.netOnline = false;
        this.netPing = this.netOnline ? Math.round(8 + rnd() * 28) : 0;
      }
      if (this.netOnline && now - (this.iranUpdatedAt || 0) > 7 * 86_400_000) {
        this.iranUpdatedAt = now;
        this.saveSetting("iran.updatedAt", String(now));
        trafficLog.add({ ts: now, cat: "system", level: "info", msg: "پایگاه رنج‌های IPv4 ایران به‌روزرسانی هفتگی شد" }).catch(() => undefined);
      }
      if (this.netOnline && rnd() < 0.05) {
        const rr = IRAN_RANGES[Math.floor(rnd() * IRAN_RANGES.length)];
        const base = ipToInt(rr.cidr.split("/")[0]) >>> 0;
        const src = intToIp((base + 1 + Math.floor(rnd() * Math.min(4000, Math.max(2, rr.ips - 2)))) >>> 0);
        const tgt = (this.devicesCache.find((d) => d.snmp) ?? this.devicesCache[0])?.ip ?? "10.10.0.21";
        this.pushEvent({
          srcIp: src, dstIp: tgt,
          type: rnd() < 0.5 ? "port-scan" : "brute-force", severity: "high", action: "blocked",
          detail: `فعالیت تهاجمی از رنج ایرانی ${rr.cidr} (${rr.isp}) — مبدأ شناسایی و مسدود شد`,
        });
      }
      this.maybeBackup(now);
    }
    if (this.tickCount % 150 === 0) this.writeSyslogs();

    // rollover ساعت/روز
    if (now - this.hourStart >= 3600_000) {
      this.flush();
      this.hourAcc = new Map();
      this.hourStart = new Date(now).setMinutes(0, 0, 0);
    }
    if (now - this.dayStart >= 86400_000) {
      this.dayAcc = new Map();
      this.dayStart = new Date(now).setHours(0, 0, 0, 0);
      this.eventsToday = 0;
      this.blockedToday = 0;
      this.attackerCount.clear();
      this.targetCount.clear();
    }

    // کمپین حمله شبیه‌سازی‌شده
    if (now >= this.nextCampaign && !this.campaign) {
      const atk = ["45.148.10.23", "103.75.9.9", "185.220.101.4", "91.240.118.172", "193.142.146.66"];
      this.campaign = {
        src: atk[Math.floor(rnd() * atk.length)],
        left: 3 + Math.floor(rnd() * 4),
        type: rnd() < 0.5 ? "brute-force" : "port-scan",
        sev: rnd() < 0.35 ? "critical" : "high",
      };
      this.nextCampaign = now + (5 + rnd() * 12) * 60_000;
    }

    const rangeSum = new Map<number, { i: number; o: number; active: number; susp: number }>();
    let totI = 0, totO = 0, totS = 0, active = 0;
    const rateList: { ip: string; rate: number; p: IpProfile }[] = [];

    this.ips.forEach((p) => {
      const r = mulberry((hash(p.ip) ^ (this.tickCount * 2654435761)) >>> 0);
      if (p.burstUntil < now) {
        if (r() < (p.idle ? 0.002 : 0.012)) {
          p.burstUntil = now + (3 + r() * 14) * 1000;
          p.burstMult = 6 + r() * 22;
        } else p.burstMult = 1;
      }
      let base = p.base * hourCurve(hour);
      if (p.server && hour >= 1 && hour <= 3) base *= 2.2; // پنجره پشتیبان‌گیری
      let i = base * p.burstMult * (1 + (r() - 0.5) * p.vol * 2);
      if (p.idle) i = p.base * (r() < 0.3 ? 1 + r() : 0.05);
      if (p.susp) {
        if (p.susp.kind === "flood" && r() < 0.12) i *= 25 + r() * 50;
        if (p.susp.kind === "beacon") i = 900 + r() * 300;
        if (p.susp.kind === "scan") i = 400 + r() * 900;
        if (p.susp.kind === "exfil" && hour >= 0 && hour <= 5) i *= 1.2;
      }
      i = Math.max(0, i);
      let o = i * p.outRatio * (1 + (r() - 0.5) * p.vol);
      if (p.susp?.kind === "exfil" && hour >= 0 && hour <= 5) o = i * (6 + r() * 6);
      o = Math.max(0, o);
      let s = p.idle ? (r() < 0.1 ? 1 : 0) : Math.round(1 + base / 9000 + r() * 4);
      if (p.susp?.kind === "scan") s = 45 + Math.floor(r() * 90);
      if (p.susp?.kind === "beacon") s = 1;
      if (p.external) s = Math.round(2 + r() * 30);
      p.cur = { i, o, s };

      const ring = this.rings.get(p.ip) ?? [];
      ring.push({ t: now, i, o, s });
      if (ring.length > RING_CAP) ring.shift();
      this.rings.set(p.ip, ring);

      const acc = (m: Map<string, { i: number; o: number; s: number; p: number }>) => {
        const a = m.get(p.ip) ?? { i: 0, o: 0, s: 0, p: 0 };
        a.i += (i * TICK_MS) / 1000;
        a.o += (o * TICK_MS) / 1000;
        a.s += s;
        a.p += Math.round(((i + o) * TICK_MS) / 1000 / 700);
        m.set(p.ip, a);
      };
      acc(this.hourAcc);
      acc(this.dayAcc);

      // ثبت ارتباطات (کدام IP به کدام مقصد درخواست داده)
      if (!p.idle && !p.external && p.peers.length) {
        const r2 = r();
        const target = r2 < 0.72 || this.deviceIpPool.length === 0 ? p.peers[this.tickCount % p.peers.length] : this.deviceIpPool[Math.floor(r() * this.deviceIpPool.length)];
        if (target && target !== p.ip) {
          const share = 0.2 + r() * 0.4;
          this.addPeer(p.ip, target, i * share, o * share);
          if (this.ips.has(target)) this.addPeer(target, p.ip, o * share, i * share);
        }
      }

      if (!p.external && p.rangeId != null) {
        const rs = rangeSum.get(p.rangeId) ?? { i: 0, o: 0, active: 0, susp: 0 };
        rs.i += i; rs.o += o;
        if (i + o > 24) rs.active++;
        if (p.susp && !p.idle && i + o > 0) rs.susp++;
        rangeSum.set(p.rangeId, rs);
      }
      totI += i; totO += o; totS += s;
      if (i + o > 24) active++;
      if (!p.idle) rateList.push({ ip: p.ip, rate: i + o, p });
    });

    this.totalRing.push({ t: now, i: totI, o: totO, s: totS });
    if (this.totalRing.length > RING_CAP) this.totalRing.shift();
    rangeSum.forEach((v, k) => {
      const rr = this.rangeRing.get(k) ?? [];
      rr.push({ t: now, i: v.i, o: v.o, s: v.active });
      if (rr.length > RING_CAP) rr.shift();
      this.rangeRing.set(k, rr);
    });
    rangeSum.forEach((v, k) => this.rangeRingMeta.set(k, v));

    rateList.sort((a, b) => b.rate - a.rate);
    this.topsRing.push({ t: now, tops: rateList.slice(0, 3).map((x) => [x.ip, x.rate]) });
    if (this.topsRing.length > RING_CAP) this.topsRing.shift();
    this.rangeTops.clear();
    for (const x of rateList) {
      if (x.p.rangeId != null && !this.rangeTops.has(x.p.rangeId)) this.rangeTops.set(x.p.rangeId, [x.ip, x.rate]);
    }

    // تجمیع لحظه‌ای بر اساس نوع تجهیز (سرور/سوئیچ/میکروتیک/فایروال)
    const aggs: Record<string, { i: number; o: number; n: number; on: number; top: [string, number][] }> = {};
    this.devicesCache.forEach((d) => {
      const gk = KIND_GROUP[d.kind];
      if (!gk) return;
      const p = this.ips.get(d.ip);
      if (!p) return;
      const A = aggs[gk] ?? (aggs[gk] = { i: 0, o: 0, n: 0, on: 0, top: [] });
      A.i += p.cur.i;
      A.o += p.cur.o;
      A.n++;
      const untilA = this.offlineUntil.get(d.id) ?? 0;
      if (untilA === 0 || untilA < now) A.on++;
      A.top.push([d.ip, p.cur.i + p.cur.o]);
    });
    Object.values(aggs).forEach((A) => {
      A.top.sort((a, b) => b[1] - a[1]);
      A.top = A.top.slice(0, 3);
    });
    this.kindAggStore = aggs;

    // وضعیت آنلاین/تأخیر تجهیزات + لاگ تغییر وضعیت
    this.devicesCache.forEach((d) => {
      const until = this.offlineUntil.get(d.id) ?? 0;
      if (until === 0 && rnd() < 0.0009 && !d.isDomain) this.offlineUntil.set(d.id, now + 20_000 + rnd() * 25_000);
      else if (until > 0 && until < now) this.offlineUntil.set(d.id, 0);
      this.latency.set(d.id, +(0.3 + rnd() * (d.kind === "vm" ? 8 : 3.5)).toFixed(1));
      const online = (this.offlineUntil.get(d.id) ?? 0) === 0 || (this.offlineUntil.get(d.id) ?? 0) < now;
      const prev = this.devOnlinePrev.get(d.id);
      if (prev !== undefined && prev !== online) {
        trafficLog
          .add({ ts: now, cat: "device", level: online ? "info" : "high", ip: d.ip, msg: online ? `${d.name} دوباره آنلاین شد` : `${d.name} آفلاین شد — اتصال قطع شد`, meta: { device: d.name, kind: d.kind, online } })
          .catch(() => undefined);
      }
      this.devOnlinePrev.set(d.id, online);
    });

    // نمونه‌برداری دقیقه‌ای پایداری + پنجره‌های قطعی سرویس‌ها
    if (this.tickCount % 30 === 0) {
      this.devicesCache.forEach((d) => {
        const until = this.offlineUntil.get(d.id) ?? 0;
        const up = until === 0 || until < now;
        const arr = this.upSamples.get(d.id) ?? [];
        arr.push({ t: now, up });
        if (arr.length > 1440) arr.shift();
        this.upSamples.set(d.id, arr);
        const open = this.downOpen.get(d.id);
        if (!up && !open) this.downOpen.set(d.id, now);
        if (up && open) {
          const w = this.downWindows.get(d.id) ?? [];
          w.push({ s: open, e: now });
          if (w.length > 20) w.shift();
          this.downWindows.set(d.id, w);
          this.downOpen.delete(d.id);
        }
      });
      // سیگنال رادیوهای وایرلس
      this.devicesCache.filter((d) => d.kind === "wireless").forEach((d) => {
        const meta = this.mkWireMeta(d);
        const until = this.offlineUntil.get(d.id) ?? 0;
        const up = until === 0 || until < now;
        const fade = rnd() < 0.05 ? -(8 + rnd() * 12) : 0;
        const sig = up ? meta.base + (rnd() * 6 - 3) + fade : -92;
        const ring = this.signalRing.get(d.id) ?? [];
        ring.push({ t: now, sig: +sig.toFixed(1), lat: this.latency.get(d.id) ?? 1 });
        if (ring.length > 1800) ring.shift();
        this.signalRing.set(d.id, ring);
      });
    }

    // تولید رخداد امنیتی تصادفی
    if (this.campaign) {
      const srv = this.devicesCache.find((d) => d.snmp) ?? this.devicesCache[0];
      const types: Record<string, string> = {
        "brute-force": `تلاش ورود نامعتبر مکرر روی پورت ${["3389", "22", "8291", "443"][Math.floor(rnd() * 4)]}`,
        "port-scan": `اسکن ترتیبی پورت‌های 1-1024 در ${Math.floor(200 + rnd() * 600)} میلی‌ثانیه`,
      };
      this.pushEvent({
        srcIp: this.campaign.src,
        dstIp: srv?.ip ?? "10.10.0.21",
        type: this.campaign.type,
        severity: this.campaign.sev,
        action: "blocked",
        detail: types[this.campaign.type] ?? "فعالیت تهاجمی تشخیص داده شد — IP مبدا مسدود گردید",
      });
      this.campaign.left--;
      if (this.campaign.left <= 0) this.campaign = null;
    } else if (rnd() < 0.055) {
      const sus = [...this.ips.values()].filter((p) => p.susp && !p.idle);
      const p = sus[Math.floor(rnd() * sus.length)];
      const targets = this.devicesCache;
      if (p && targets.length) {
        this.pushEvent({
          srcIp: p.ip, dstIp: targets[Math.floor(rnd() * targets.length)].ip,
          type: p.susp!.kind === "flood" ? "icmp-flood" : p.susp!.kind === "exfil" ? "anomaly" : "port-scan",
          severity: rnd() < 0.3 ? "high" : "medium", action: "blocked",
          detail: " رفتار غیرعادی از میزبان داخلی — بر اساس قانون IDS متوقف شد",
        });
      }
    }

    // نمونه بسته‌ها (ردیابی)
    const nPk = 1 + Math.floor(rnd() * 4);
    for (let k = 0; k < nPk; k++) this.pktsBuf.push(this.mkPkt());
    if (this.pktsBuf.length > 120) this.pktsBuf.splice(0, this.pktsBuf.length - 120);

    this.emit("tick");
  }

  rangeRingMeta = new Map<number, { i: number; o: number; active: number; susp: number }>();
  // (با every tick پر می‌شود)

  mkPkt(): Pkt {
    const speakers = [...this.ips.values()].filter((p) => !p.idle && !p.external && (p.cur.i + p.cur.o) > 10);
    const sp = speakers[Math.floor(rnd() * speakers.length)] ?? [...this.ips.values()][0];
    const toExt = rnd() < 0.55;
    const dst = toExt ? (sp.peers[Math.floor(rnd() * sp.peers.length)] ?? "8.8.8.8") : this.devicesCache[Math.floor(rnd() * Math.max(1, this.devicesCache.length))]?.ip ?? "192.168.1.1";
    const protos: [string, number, number][] = [
      ["HTTPS", 443, 0.42], ["DNS", 53, 0.14], ["HTTP", 80, 0.07], ["SMB", 445, 0.08],
      ["RDP", 3389, 0.05], ["ICMP", 0, 0.04], ["NTP", 123, 0.03], ["SSH", 22, 0.03],
      ["SQL", 5432, 0.06], ["WIN-RM", 5985, 0.04], ["SMTP", 25, 0.04],
    ];
    let pick = protos[0];
    const x = rnd();
    let acc = 0;
    for (const pr of protos) { acc += pr[2]; if (x <= acc) { pick = pr; break; } }
    const flagsPool = ["PSH, ACK", "ACK", "SYN", "SYN, ACK", "FIN, ACK", "RST"];
    const flags = pick[1] === 0 ? "" : flagsPool[Math.floor(rnd() * flagsPool.length)];
    const len = Math.round(54 + rnd() * 1400);
    const spx = Math.round(1024 + rnd() * 64000);
    return {
      t: Date.now(), src: sp.ip, dst, proto: pick[0], sp: spx, dp: pick[1], len, flags,
      info: pick[1] === 0 ? "Echo (ping) request" : `${spx} → ${pick[1]} [${flags}] Seq=${Math.round(rnd() * 1e6)} Len=${len - 54}`,
    };
  }

  pushEvent(e: { srcIp: string; dstIp: string; type: string; severity: string; action: string; detail: string }) {
    const ev: Ev = { id: this.evId++, ts: Date.now(), ...e, srcExt: !isPrivateIp(e.srcIp) && !e.srcIp.startsWith("127.") && !e.srcIp.startsWith("198.51.100") };
    this.recentEvents.push(ev);
    if (this.recentEvents.length > 400) this.recentEvents.shift();
    this.evBuf.push(ev);
    this.eventsToday++;
    if (e.action === "blocked") this.blockedToday++;
    this.attackerCount.set(e.srcIp, (this.attackerCount.get(e.srcIp) ?? 0) + 1);
    this.targetCount.set(e.dstIp, (this.targetCount.get(e.dstIp) ?? 0) + 1);
    if (this.dbReady) {
      db.insert(eventsT).values({ srcIp: e.srcIp, dstIp: e.dstIp, type: e.type, severity: e.severity, action: e.action, detail: e.detail }).then(() => undefined).catch(() => undefined);
    }
    trafficLog
      .add({ ts: ev.ts, cat: "security", level: (ev.severity as LogEntry["level"]) ?? "medium", ip: ev.srcIp, peer: ev.dstIp, msg: ev.detail, meta: { type: ev.type, action: ev.action } })
      .catch(() => undefined);
  }

  // ------------------- flush تجمیع‌ها به دیتابیس -------------------
  async flush() {
    if (!this.dbReady) return;
    try {
      const hRows = [...this.hourAcc.entries()].map(([ip, a]) => ({
        ip, ts: new Date(this.hourStart), bytesIn: Math.round(a.i), bytesOut: Math.round(a.o), sessions: a.s, pkts: a.p,
      }));
      const dRows = [...this.dayAcc.entries()].map(([ip, a]) => ({
        ip, day: new Date(this.dayStart), bytesIn: Math.round(a.i), bytesOut: Math.round(a.o), sessions: a.s, pkts: a.p,
      }));
      if (hRows.length)
        await db.insert(hourlyT).values(hRows).onConflictDoUpdate({
          target: [hourlyT.ip, hourlyT.ts],
          set: { bytesIn: sql`excluded.bytes_in`, bytesOut: sql`excluded.bytes_out`, sessions: sql`excluded.sessions`, pkts: sql`excluded.pkts` },
        });
      if (dRows.length)
        await db.insert(dailyT).values(dRows).onConflictDoUpdate({
          target: [dailyT.ip, dailyT.day],
          set: { bytesIn: sql`excluded.bytes_in`, bytesOut: sql`excluded.bytes_out`, sessions: sql`excluded.sessions`, pkts: sql`excluded.pkts` },
        });
    } catch {
      /* تلاش مجدد در چرخه بعد */
    }
  }

  // ------------------- لاگ فایلی و ارتباطات -------------------
  addPeer(owner: string, other: string, inB: number, outB: number) {
    let m = this.peerMap.get(owner);
    if (!m) {
      m = new Map();
      this.peerMap.set(owner, m);
    }
    let e = m.get(other);
    if (!e) {
      if (m.size >= 24) {
        let minK = "";
        let minH = Infinity;
        m.forEach((v, k) => {
          if (v.hits < minH) {
            minH = v.hits;
            minK = k;
          }
        });
        if (minK) m.delete(minK);
      }
      e = { i: 0, o: 0, hits: 0, last: 0 };
      m.set(other, e);
    }
    e.i += inB;
    e.o += outB;
    e.hits++;
    e.last = Date.now();
  }

  async writeTrafficLogs() {
    try {
      const now = Date.now();
      const rows = [...this.ips.values()]
        .filter((p) => !p.external && !p.idle)
        .sort((a, b) => b.cur.i + b.cur.o - (a.cur.i + a.cur.o))
        .slice(0, 30);
      for (const p of rows) {
        const ring = (this.rings.get(p.ip) ?? []).slice(-450);
        const bin = ring.reduce((a, x) => a + x.i, 0) * (TICK_MS / 1000);
        const bout = ring.reduce((a, x) => a + x.o, 0) * (TICK_MS / 1000);
        await trafficLog.add({
          ts: now, cat: "traffic", level: "info", ip: p.ip, peer: p.peers[0],
          msg: `خلاصه مصرف ۱۵ دقیقه ${p.host}: دانلود ${fmtBytes(bin)} • آپلود ${fmtBytes(bout)}`,
          meta: { host: p.host, bytesIn: Math.round(bin), bytesOut: Math.round(bout), rateIn: Math.round(p.cur.i), rateOut: Math.round(p.cur.o), sessions: p.cur.s },
        });
      }
    } catch {
      /* نادیده */
    }
  }

  async loadLogSettings() {
    try {
      if (!this.dbReady) return;
      const rows = await db.select().from(settingsT);
      const get = (k: string) => rows.find((r) => r.key === k)?.value;
      const dir = get("log.dir");
      const ret = parseInt(get("log.retentionDays") ?? "", 10);
      if (dir) await trafficLog.setDir(dir);
      if (Number.isFinite(ret) && ret > 0 && ret <= 1460) trafficLog.retentionDays = ret;
    } catch {
      /* پیش‌فرض */
    }
  }

  async saveLogSettings(dir: string | null, days: number | null) {
    if (dir) await trafficLog.setDir(dir);
    if (days && days > 0 && days <= 1460) trafficLog.retentionDays = days;
    if (this.dbReady) {
      try {
        if (dir)
          await db.insert(settingsT).values({ key: "log.dir", value: dir }).onConflictDoUpdate({ target: settingsT.key, set: { value: dir } });
        if (days)
          await db.insert(settingsT).values({ key: "log.retentionDays", value: String(days) }).onConflictDoUpdate({ target: settingsT.key, set: { value: String(days) } });
      } catch {
        /* بعداً */
      }
    }
    await trafficLog
      .add({ ts: Date.now(), cat: "system", level: "info", msg: `تنظیمات لاگ به‌روز شد — مسیر: ${trafficLog.dir} • نگهداشت: ${trafficLog.retentionDays} روز` })
      .catch(() => undefined);
  }

  logInfo() {
    return { dir: trafficLog.dir, retentionDays: trafficLog.retentionDays, lastPurgeAt: trafficLog.lastPurgeAt };
  }

  // ==================== زیرسیستم‌های جدید ====================

  async loadExtra() {
    try {
      if (!this.dbReady) return;
      const us = await db.select().from(usersT);
      if (!us.length) await db.insert(usersT).values({ username: "admin", hash: hashPassword("admin"), role: "admin", perms: JSON.stringify(["*"]) });
      const lic = await db.select().from(licenseT).limit(1);
      if (lic[0]) {
        this.licRow = lic[0];
        try {
          this.licMeta = JSON.parse(lic[0].meta) as LicenseMeta;
        } catch {
          /* خراب */
        }
      }
      this.treeCache = await db.select().from(treeT).orderBy(treeT.id);
      if (!this.treeCache.length) {
        const root = (await db.insert(treeT).values({ name: "corp.local", kind: "root", ips: JSON.stringify(["10.10.0.21", "10.10.0.22"]) }).returning())[0];
        const m = (await db.insert(treeT).values({ name: "mail.corp.local", kind: "branch", parentId: root.id, ips: JSON.stringify(["172.16.8.10"]) }).returning())[0];
        await db.insert(treeT).values([
          { name: "web.corp.local", kind: "branch", parentId: root.id, ips: JSON.stringify(["10.10.0.24", "10.10.0.23"]) },
          { name: "db.corp.local", kind: "leaf", parentId: m.id, ips: JSON.stringify(["10.10.0.31"]) },
        ]);
        this.treeCache = await db.select().from(treeT).orderBy(treeT.id);
      }
      this.dnsCache = await db.select().from(dnsT).orderBy(dnsT.id);
      if (!this.dnsCache.length) {
        await db.insert(dnsT).values([
          { scope: "internal", ip: "10.10.0.21", domain: "dc01.corp.local", name: "دامین کنترلر اصلی", label: "دامنه داخلی اصلی" },
          { scope: "internal", ip: "10.10.0.22", domain: "dc02.corp.local", name: "دامین کنترلر دوم", label: "دامنه داخلی اصلی" },
          { scope: "internal", ip: "10.10.0.24", domain: "intranet.corp.local", name: "پرتال داخلی", label: "وب‌سرویس‌ها" },
          { scope: "internal", ip: "10.10.0.31", domain: "db.corp.local", name: "دیتابیس", label: "دامنه داخلی اصلی" },
          { scope: "internal", ip: "10.10.0.32", domain: "dev.corp.local", name: "سرور توسعه", inUse: false, label: "وب‌سرویس‌ها" },
          { scope: "external", ip: "198.51.100.10", domain: "www.company.com", name: "وب‌سایت اصلی", label: "رنج پابلیک اصلی" },
          { scope: "external", ip: "198.51.100.11", domain: "mail.company.com", name: "ایمیل سازمانی", label: "رنج پابلیک اصلی" },
          { scope: "external", ip: "198.51.100.12", domain: "vpn.company.com", name: "دسترسی از راه دور", label: "رنج پابلیک اصلی" },
          { scope: "external", ip: "198.51.100.13", domain: "api.company.com", name: "API عمومی", inUse: false, label: "رنج پابلیک اصلی" },
          { scope: "public", ip: "203.0.113.2", domain: "ns1.company.com", name: "DNS اول", label: "رنج پابلیک مشتری" },
          { scope: "public", ip: "203.0.113.3", domain: "", name: "", inUse: false, label: "رنج پابلیک مشتری" },
          { scope: "public", ip: "203.0.113.4", domain: "mail2.company.com", name: "ایمیل دوم", label: "رنج پابلیک مشتری" },
        ]);
        this.dnsCache = await db.select().from(dnsT).orderBy(dnsT.id);
      }
      this.syslogCache = await db.select().from(syslogT).orderBy(syslogT.id);
      if (!this.syslogCache.length) {
        await db.insert(syslogT).values({ targetType: "ip", target: "192.168.1.254", direction: "both" });
        this.syslogCache = await db.select().from(syslogT).orderBy(syslogT.id);
      }
      this.snmpRoleCache = await db.select().from(snmpRolesT).orderBy(snmpRolesT.id);
      if (!this.snmpRoleCache.length) {
        await db.insert(snmpRolesT).values([
          { name: "پروتکل استاندارد سوئیچ سیسکو", deviceKind: "cisco", version: "v3", user: "netwatch", oids: JSON.stringify(["ifDescr", "ifInOctets", "ifOutOctets", "cpuLoad", "memFree", "temp"]), acls: JSON.stringify(["192.168.1.0/24"]) },
          { name: "جمع‌آوری میکروتیک", deviceKind: "mikrotik", version: "v2c", oids: JSON.stringify(["ifInOctets", "ifOutOctets", "wirelessClients", "channel", "txPower"]), acls: JSON.stringify(["192.168.1.0/24"]) },
          { name: "سرورها (Host Resources)", deviceKind: "server", version: "v2c", oids: JSON.stringify(["hrSystemUptime", "hrMemorySize", "hrDeviceDescr", "ifTable"]), acls: JSON.stringify(["10.10.0.0/24"]) },
          { name: "رادیو وایرلس", deviceKind: "wireless", version: "v3", user: "wmon", oids: JSON.stringify(["signalStrength", "noiseFloor", "frequency", "ccq", "clients"]), acls: JSON.stringify(["192.168.1.0/24"]) },
          { name: "لبه فیبر منطقه", deviceKind: "fiber", version: "v2c", oids: JSON.stringify(["opticRxPower", "opticTxPower", "ifOperStatus", "uptime"]), acls: JSON.stringify(["192.168.1.0/24"]) },
        ]);
        this.snmpRoleCache = await db.select().from(snmpRolesT).orderBy(snmpRolesT.id);
      }
      const st = await db.select().from(settingsT);
      const get = (k: string) => st.find((r) => r.key === k)?.value;
      const nm = get("net.mode");
      if (nm === "force-offline" || nm === "force-online" || nm === "auto") this.netMode = nm;
      if (get("backup.dir")) this.backupDir = get("backup.dir")!;
      if (get("backup.daily")) this.backupDaily = get("backup.daily")!;
      this.iranUpdatedAt = Number(get("iran.updatedAt") ?? "0");
    } catch {
      /* غیرحیاتی */
    }
  }

  async purgeCycle() {
    try {
      const removed = await trafficLog.purge();
      if (this.dbReady) {
        const cutoff = new Date(Date.now() - trafficLog.retentionDays * 86_400_000);
        const del = await db.delete(eventsT).where(lt(eventsT.ts, cutoff));
        const n = (del as unknown as { rowCount?: number }).rowCount ?? 0;
        if (n > 0) trafficLog.add({ ts: Date.now(), cat: "system", level: "info", msg: `پاک‌سازی دیتابیس: ${n} رخداد قدیمی‌تر از ${trafficLog.retentionDays} روز حذف شد` }).catch(() => undefined);
      }
      if (removed > 0) this.recentEvents = this.recentEvents.slice(-200);
    } catch {
      /* بعداً */
    }
  }

  async saveSetting(k: string, v: string) {
    if (!this.dbReady) return;
    try {
      await db.insert(settingsT).values({ key: k, value: v }).onConflictDoUpdate({ target: settingsT.key, set: { value: v } });
    } catch {
      /* بعداً */
    }
  }

  // ---------- لایسنس ----------
  licenseState() {
    if (!this.licRow || !this.licMeta) {
      return { state: "none", daysLeft: 0, syncDue: false, overdueDays: 0, writable: true, needsActivation: false, licName: "", org: "", edition: "", years: 0, appId: appId(), file: "", lastSync: 0, issuedAt: 0, validUntil: 0, mobile: "", firstName: "", lastName: "" };
    }
    const now = Date.now();
    const until = this.licMeta.validUntil;
    const daysLeft = Math.ceil((until - now) / 86_400_000);
    const base = this.licRow.lastSync ? new Date(this.licRow.lastSync).getTime() : new Date(this.licRow.createdAt).getTime();
    const syncAgeDays = (now - base) / 86_400_000;
    const expired = daysLeft <= 0;
    const locked = expired || syncAgeDays > 45;
    // تا زمان تأیید اصالت لایسنس (همگام‌سازی موفق)، نوشتاری محدود است — پایش و لاگ آزاد
    const writable = !expired && this.licRow.state === "active" && syncAgeDays <= 45;
    return {
      state: expired ? "expired" : syncAgeDays > 45 ? "locked" : this.licRow.state,
      daysLeft: Math.max(0, daysLeft),
      syncDue: syncAgeDays > 30,
      overdueDays: Math.max(0, Math.floor(syncAgeDays)),
      writable,
      needsActivation: !expired && this.licRow.state !== "active",
      licName: this.licMeta.licName,
      org: this.licMeta.org,
      edition: this.licMeta.edition,
      years: this.licMeta.years,
      appId: this.licMeta.appId,
      file: this.licRow.file,
      lastSync: this.licRow.lastSync ? new Date(this.licRow.lastSync).getTime() : 0,
      issuedAt: this.licMeta.issuedAt,
      validUntil: until,
      mobile: this.licMeta.mobile,
      firstName: this.licMeta.firstName,
      lastName: this.licMeta.lastName,
    };
  }

  async generateLicense(form: { firstName: string; lastName: string; mobile: string; org: string; licName: string; edition: "standard" | "pro" | "enterprise"; years: 1 | 2 | 3 }) {
    if (this.licRow && this.licenseState().state !== "expired") return { ok: false, error: "برای این نرم‌افزار قبلاً لایسنس صادر شده — ابتدا لایسنس قبلی را حذف کنید" };
    const now = Date.now();
    const file = licenseFileName(form.org);
    const meta: LicenseMeta = {
      v: 1, appId: appId(), licName: form.licName || "HDMAX License",
      firstName: form.firstName, lastName: form.lastName, mobile: form.mobile, org: form.org,
      edition: form.edition, years: form.years, issuedAt: now, validUntil: now + form.years * 365 * 86_400_000, file,
    };
    const content = await encodeSlf(meta);
    if (this.dbReady) {
      await db.delete(licenseT);
      const ins = await db.insert(licenseT).values({ file, content, meta: JSON.stringify(meta), state: "issued" }).returning();
      this.licRow = ins[0];
    } else {
      this.licRow = { id: 1, file, content, meta: JSON.stringify(meta), state: "issued", lastSync: null, createdAt: new Date() };
    }
    this.licMeta = meta;
    try {
      const pubDir = path.join(process.cwd(), "public", "licmonitor");
      await mkdir(pubDir, { recursive: true });
      await fsWrite(path.join(pubDir, file), content, "utf8");
    } catch {
      /* دسترسی نوشتن */
    }
    trafficLog.add({ ts: now, cat: "system", level: "info", msg: `لایسنس «${meta.licName}» برای ${meta.org} (${meta.years} ساله) صادر شد — فایل ${file} در مسیر آپلود قرار گرفت؛ آن را در https://giftmax.ir/lic/${file} قرار دهید و همگام‌سازی کنید` }).catch(() => undefined);
    return { ok: true, file, meta };
  }

  async removeLicense() {
    if (this.dbReady) await db.delete(licenseT);
    try {
      const pubDir = path.join(process.cwd(), "public", "licmonitor");
      if (this.licRow) await fsWrite(path.join(pubDir, this.licRow.file), "", "utf8").catch(() => undefined);
    } catch {
      /* نادیده */
    }
    this.licRow = null;
    this.licMeta = null;
    trafficLog.add({ ts: Date.now(), cat: "system", level: "high", msg: "لایسنس نرم‌افزار حذف شد" }).catch(() => undefined);
    return { ok: true };
  }

  async syncNow() {
    if (!this.licRow) return { ok: false, msg: "ابتدا لایسنس بسازید", same: null as boolean | null };
    if (!this.netOnline) return { ok: false, msg: "سیستم آفلاین است — برای همگام‌سازی به اینترنت متصل شوید", same: null as boolean | null };
    const r = await syncLicense(this.licRow.file, this.licRow.content);
    if (r.ok && this.dbReady) {
      await db.update(licenseT).set({ state: "active", lastSync: new Date() }).where(eq(licenseT.id, this.licRow.id));
      this.licRow = { ...this.licRow, state: "active", lastSync: new Date() };
    }
    trafficLog.add({ ts: Date.now(), cat: "system", level: r.ok ? "info" : "high", msg: `همگام‌سازی لایسنس: ${r.msg}` }).catch(() => undefined);
    return r;
  }

  // ---------- حالت آنلاین ----------
  async setNetMode(mode: "auto" | "force-online" | "force-offline") {
    this.netMode = mode;
    if (mode === "force-offline") {
      this.netOnline = false;
      this.netPing = 0;
    } else {
      this.netOnline = true;
      this.netPing = Math.round(10 + rnd() * 18);
    }
    await this.saveSetting("net.mode", mode);
    trafficLog.add({ ts: Date.now(), cat: "system", level: "info", msg: `حالت اتصال اینترنت به «${mode === "force-offline" ? "آفلاین" : mode === "force-online" ? "آنلاین اجباری" : "خودکار"}» تغییر یافت` }).catch(() => undefined);
    return { ok: true, online: this.netOnline };
  }

  // ---------- ایران و تهدیدها ----------
  iranView() {
    const attacks = this.recentEvents
      .filter((e) => e.srcExt)
      .map((e) => ({ ...e, isp: findIranIsp(e.srcIp)?.isp ?? null, cidr: findIranIsp(e.srcIp)?.cidr ?? null }))
      .filter((e) => e.isp)
      .slice(0, 30);
    const nonIran = this.recentEvents
      .filter((e) => e.srcExt && !findIranIsp(e.srcIp))
      .slice(0, 20);
    return {
      online: this.netOnline,
      updatedAt: this.iranUpdatedAt || this.bootedAt,
      ranges: IRAN_RANGES,
      totalIps: IRAN_RANGES.reduce((a, r) => a + r.ips, 0),
      ispCount: new Set(IRAN_RANGES.map((r) => r.isp)).size,
      attacks, nonIran,
    };
  }

  threatsView() {
    const counts: Record<string, number> = {};
    this.recentEvents.forEach((e) => {
      counts[e.type] = (counts[e.type] ?? 0) + 1;
    });
    const map: Record<string, string> = { "port-scan": "scan-syn", "brute-force": "rdp-brute", "icmp-flood": "icmp-flood", anomaly: "exfil", "unauth-access": "ssh-brute", "rate-limit": "icmp-flood" };
    return {
      online: this.netOnline,
      list: THREATS.map((t) => ({ ...t, liveHits: counts[Object.keys(map).find((k) => map[k] === t.id) ?? ""] ?? 0 })),
    };
  }

  mailCheck(ip: string, type: string) {
    const lists = ["Spamhaus ZEN", "Barracuda RBL", "SpamCop", "SORBS", "UCEPROTECT-3"];
    const pr = mulberry(hash(ip) ^ 777);
    const results = lists.map((l) => {
      const x = pr();
      return { list: l, status: !this.netOnline ? "unknown" : x < 0.72 ? "clean" : x < 0.86 ? "listed" : "clean" };
    });
    const listed = results.filter((r) => r.status === "listed");
    const attacks = this.recentEvents.filter((e) => e.dstIp === ip).slice(0, 10);
    const mxOk = pr() > 0.3;
    return {
      online: this.netOnline, ip, type,
      results,
      verdict: listed.length === 0 ? "clean" : listed.length >= 2 ? "spam" : "suspect",
      listedCount: listed.length,
      mxRecord: this.netOnline ? `mail.${ip.replace(/\./g, "-")}.in-addr` : "—",
      mxOk,
      attacks,
      summary:
        listed.length >= 2
          ? `این IP در ${listed.length} لیست سیاه (RBL) یافت شد — احتمالاً سرویس به‌عنوان منشأ اسپم شناخته شده و دریافت‌کننده‌ها آن را مسدود می‌کنند.`
          : listed.length === 1
            ? "در یک لیست سیاه جزئی دیده می‌شود — مراقب باشید و دلیل را بررسی کنید."
            : "این IP در هیچ‌یک از لیست‌های سیاه بررسی‌شده نیست — وضعیت سالم است.",
    };
  }

  // ---------- وایرلس ----------
  mkWireMeta(d: (typeof devicesT.$inferSelect)) {
    let ch = 36;
    let band = "5GHz";
    try {
      const m = /band:([\d.]+GHz);ch:(\d+)/i.exec(d.notes ?? "band:5GHz;ch:36");
      if (m) {
        band = m[1];
        ch = Number(m[2]);
      }
    } catch {
      /* پیش‌فرض */
    }
    const pr = mulberry(hash(d.ip) ^ 4242);
    const freq = band.startsWith("2.4") ? 2407 + ch * 5 : 5000 + ch * 5;
    const meta = { freq, ch, base: -52 - Math.floor(pr() * 12) };
    this.wireMeta.set(d.id, meta);
    return meta;
  }

  wirelessView(kindFilter = "wireless") {
    void kindFilter;
    const out = this.devicesCache.filter((d) => d.kind === "wireless").map((d) => {
      const meta = this.wireMeta.get(d.id) ?? this.mkWireMeta(d);
      const until = this.offlineUntil.get(d.id) ?? 0;
      const online = until === 0 || until < Date.now();
      const ring = this.signalRing.get(d.id) ?? [];
      const sig = ring.at(-1)?.sig ?? meta.base;
      const quality = !online ? { label: "خارج از سرویس", c: "#fb7185" } : sig >= -55 ? { label: "عالی", c: "#34d399" } : sig >= -65 ? { label: "خوب", c: "#a3e635" } : sig >= -75 ? { label: "متوسط — نیاز به بهبود", c: "#fbbf24" } : { label: "ضعیف — بررسی آنتن", c: "#fb7185" };
      const stab = this.stabilityOf(d.id);
      return {
        id: d.id, name: d.name, ip: d.ip, online, lat: this.latency.get(d.id) ?? 1,
        freq: meta.freq, ch: meta.ch, band: meta.freq < 3000 ? "2.4GHz" : "5GHz",
        signal: sig, quality: { label: quality.label ?? "", c: quality.c }, spark: ring.slice(-40).map((p) => p.sig),
        stabPct: stab.pct, rate: this.ips.get(d.ip)?.cur.i ?? 0 + (this.ips.get(d.ip)?.cur.o ?? 0),
      };
    });
    return out;
  }

  wirelessHistory(ip: string, win: "1h" | "24h" | "10d") {
    const d = this.devicesCache.find((x) => x.ip === ip && x.kind === "wireless");
    if (!d) return { points: [] as { t: number; sig: number; lat: number; up: number }[] };
    if (win === "1h") {
      const pts = (this.signalRing.get(d.id) ?? []).map((p) => ({ t: p.t, sig: p.sig, lat: p.lat, up: p.sig > -88 ? 100 : 0 }));
      return { points: pts };
    }
    const pr = mulberry(hash(ip) ^ (win === "24h" ? 240 : 1000));
    const meta = this.wireMeta.get(d.id) ?? this.mkWireMeta(d);
    const n = win === "24h" ? 24 : 10;
    const step = win === "24h" ? 3600_000 : 86_400_000;
    const points = Array.from({ length: n }, (_, k) => {
      const t = Date.now() - (n - 1 - k) * step;
      const sig = meta.base + (pr() * 10 - 5) - (pr() < 0.08 ? 10 + pr() * 12 : 0);
      const up = 92 + pr() * 8;
      return { t, sig: +sig.toFixed(1), lat: +(1 + pr() * 6).toFixed(1), up: +up.toFixed(1) };
    });
    return { points };
  }

  stabilityOf(id: number) {
    const arr = this.upSamples.get(id) ?? [];
    if (!arr.length) return { pct: 100, samples: 0 };
    const up = arr.filter((x) => x.up).length;
    return { pct: +(((up / arr.length) * 100) || 0).toFixed(2), samples: arr.length };
  }

  // ---------- نقشه مسیریابی (گراف + BFS) ----------
  graph() {
    const nodes = this.devicesCache.map((d) => {
      const until = this.offlineUntil.get(d.id) ?? 0;
      const p = this.ips.get(d.ip);
      return { id: d.id, name: d.name, ip: d.ip, kind: d.kind, online: until === 0 || until < Date.now(), lat: this.latency.get(d.id) ?? 1, rate: p ? p.cur.i + p.cur.o : 0 };
    });
    const adj = new Map<number, Set<number>>();
    const link = (a: number, b: number) => {
      if (!adj.has(a)) adj.set(a, new Set());
      if (!adj.has(b)) adj.set(b, new Set());
      adj.get(a)!.add(b);
      adj.get(b)!.add(a);
    };
    const byKind = (k: string[]) => this.devicesCache.filter((d) => k.includes(d.kind));
    const cores = byKind(["cisco", "switch"]);
    const mikros = byKind(["mikrotik"]);
    const fws = byKind(["firewall"]);
    cores.forEach((d, i) => { if (i > 0) link(cores[i - 1].id, d.id); });
    this.devicesCache.forEach((d) => {
      if (d.parentId) link(d.id, d.parentId);
    });
    this.devicesCache.forEach((d) => {
      if (d.kind === "esxi" && cores[0]) link(d.id, cores[0].id);
      if (["server", "windows"].includes(d.kind) && !d.parentId && (cores.at(-1) ?? cores[0])) link(d.id, (cores.at(-1) ?? cores[0])!.id);
      if (d.kind === "wireless" && (cores[0] ?? mikros[0])) link(d.id, (cores[0] ?? mikros[0])!.id);
    });
    mikros.forEach((m) => { if (cores[0]) link(m.id, cores[0].id); });
    fws.forEach((f) => { if (mikros[0]) link(f.id, mikros[0].id); else if (cores[0]) link(f.id, cores[0].id); });
    byKind(["fiber"]).forEach((f) => { if (fws[0]) link(f.id, fws[0].id); else if (mikros[0]) link(f.id, mikros[0].id); });
    mikros.slice(1).forEach((m) => link(m.id, mikros[0].id));
    const edges: { a: number; b: number }[] = [];
    adj.forEach((set, a) => set.forEach((b) => { if (a < b) edges.push({ a, b }); }));
    return { nodes, edges };
  }

  findPath(fromId: number, toId: number) {
    const { nodes, edges } = this.graph();
    const adj = new Map<number, number[]>();
    edges.forEach((e) => {
      adj.set(e.a, [...(adj.get(e.a) ?? []), e.b]);
      adj.set(e.b, [...(adj.get(e.b) ?? []), e.a]);
    });
    const prev = new Map<number, number>();
    const q = [fromId];
    const seen = new Set([fromId]);
    while (q.length) {
      const cur = q.shift()!;
      if (cur === toId) break;
      (adj.get(cur) ?? []).forEach((n) => {
        if (!seen.has(n)) {
          seen.add(n);
          prev.set(n, cur);
          q.push(n);
        }
      });
    }
    if (!seen.has(toId)) return { ok: false, hops: [] as (typeof nodes)[], edgesUsed: [] as [number, number][] };
    const path: number[] = [toId];
    while (path[0] !== fromId) path.unshift(prev.get(path[0])!);
    const byId = new Map(nodes.map((n) => [n.id, n]));
    const hops = path.map((id) => byId.get(id)!).filter(Boolean);
    const edgesUsed: [number, number][] = hops.slice(1).map((h, i) => [hops[i].id, h.id]);
    const totalLat = hops.reduce((a, h) => a + (h.lat ?? 0), 0);
    const problem = hops.find((h) => !h.online);
    return { ok: true, hops, edgesUsed, totalLat: +totalLat.toFixed(1), problem: problem ? { id: problem.id, name: problem.name, ip: problem.ip } : null };
  }

  // ---------- SNMP نقش‌ها و سخت‌سازی ----------
  devSnmpConf(d: (typeof devicesT.$inferSelect)) {
    return this.devSnmp.get(d.id) ?? { version: "v2c", acl: "" };
  }

  hardeningFor(d: (typeof devicesT.$inferSelect)) {
    const conf = this.devSnmpConf(d);
    const issues: { sev: string; msg: string }[] = [];
    if (!d.snmp) return { issues, score: 100, off: true };
    let score = 100;
    if (conf.version === "v1") { issues.push({ sev: "high", msg: "SNMPv1 فاقد رمزنگاری است — به v3 ارتقا دهید" }); score -= 30; }
    else if (conf.version === "v2c") { issues.push({ sev: "medium", msg: "v2c بدون رمزنگاری روی community است — ترجیحاً v3 (AuthPriv)" }); score -= 15; }
    if (d.community === "public") { issues.push({ sev: "high", msg: "community پیش‌فرض «public» — حتماً تغییر دهید" }); score -= 25; }
    if (!conf.acl) { issues.push({ sev: "medium", msg: "لیست دسترسی (ACL) مبدا تعریف نشده — فقط کلکتور سامانه مجاز شود" }); score -= 20; }
    if (d.wmi && d.snmp) { issues.push({ sev: "low", msg: "WMI و SNMP هم‌زمان فعال — حداقل دسترسی لازم را برگزینید" }); score -= 5; }
    return { issues, score: Math.max(10, score), off: false };
  }

  snmpView() {
    const roles = this.snmpRoleCache.map((r) => ({ ...r, oids: safeArr(r.oids), acls: safeArr(r.acls) }));
    const devices = this.devicesCache.map((d) => {
      const conf = this.devSnmpConf(d);
      const h = this.hardeningFor(d);
      const role = roles.find((r) => r.enabled && (r.deviceKind === d.kind || r.deviceKind === "all"));
      return { id: d.id, name: d.name, ip: d.ip, kind: d.kind, snmp: d.snmp, community: d.community, version: conf.version, acl: conf.acl, issues: h.issues, score: h.score, off: h.off, role: role ? { id: role.id, name: role.name, oids: role.oids } : null };
    });
    return { roles, devices };
  }

  async snmpRoleSave(role: { id?: number; name: string; deviceKind: string; version: string; user: string; oids: string[]; acls: string[]; enabled: boolean }) {
    const v = { name: role.name.slice(0, 60), device_kind: role.deviceKind, version: ["v1", "v2c", "v3"].includes(role.version) ? role.version : "v2c", user: role.user.slice(0, 30), auth_type: role.version === "v3" ? "SHA-256/AES-256" : "", oids: JSON.stringify(role.oids.slice(0, 12)), acls: JSON.stringify(role.acls.slice(0, 6)), enabled: role.enabled };
    if (this.dbReady) {
      if (role.id) await db.update(snmpRolesT).set({ name: v.name, deviceKind: v.device_kind, version: v.version, user: v.user, authType: v.auth_type, oids: v.oids, acls: v.acls, enabled: v.enabled }).where(eq(snmpRolesT.id, role.id));
      else await db.insert(snmpRolesT).values({ name: v.name, deviceKind: v.device_kind, version: v.version, user: v.user, authType: v.auth_type, oids: v.oids, acls: v.acls, enabled: v.enabled });
      this.snmpRoleCache = await db.select().from(snmpRolesT).orderBy(snmpRolesT.id);
    } else {
      if (role.id) {
        const r = this.snmpRoleCache.find((x) => x.id === role.id);
        if (r) Object.assign(r, { name: v.name, deviceKind: v.device_kind, version: v.version, user: v.user, authType: v.auth_type, oids: v.oids, acls: v.acls, enabled: v.enabled });
      } else this.snmpRoleCache.push({ id: Math.max(0, ...this.snmpRoleCache.map((x) => x.id)) + 1, name: v.name, deviceKind: v.device_kind, version: v.version, user: v.user, authType: v.auth_type, oids: v.oids, acls: v.acls, enabled: v.enabled, createdAt: new Date() });
    }
    trafficLog.add({ ts: Date.now(), cat: "system", level: "info", msg: `نقش SNMP «${v.name}»${role.id ? " به‌روزسانی" : " ایجاد"} شد (نسخه ${v.version})` }).catch(() => undefined);
    return { ok: true };
  }

  async snmpRoleDelete(id: number) {
    if (this.dbReady) await db.delete(snmpRolesT).where(eq(snmpRolesT.id, id));
    this.snmpRoleCache = this.snmpRoleCache.filter((r) => r.id !== id);
    return { ok: true };
  }

  async patchDevSnmp(id: number, patch: { version?: string; acl?: string; snmp?: boolean }) {
    const d = this.devicesCache.find((x) => x.id === id);
    if (!d) return { ok: false };
    if (patch.snmp !== undefined) await this.toggleDevice(id, "snmp");
    const conf = this.devSnmp.get(id) ?? { version: "v2c", acl: "" };
    if (patch.version && ["v1", "v2c", "v3"].includes(patch.version)) conf.version = patch.version;
    if (patch.acl !== undefined) conf.acl = patch.acl.slice(0, 40);
    this.devSnmp.set(id, conf);
    return { ok: true };
  }

  // ---------- تحلیل SPL + آماری ----------
  insights() {
    // تحلیل خودکار: Z-Score روی سری ۳۰ دقیقه اخیر هر رنج + روند خطی ساعتی
    const out: { type: string; title: string; detail: string; sev: string }[] = [];
    this.rangesCache.forEach((r) => {
      const ring = (this.rangeRing.get(r.id) ?? []).map((p) => p.i + p.o);
      if (ring.length < 30) return;
      const base = ring.slice(-900, -2);
      const cur = ring.at(-1)!;
      const z = zscore(cur, mean(base), stdev(base) + mad(base));
      const reg = linreg(ring.slice(-600));
      if (Math.abs(z) > 3) out.push({ type: "anomaly", title: `${r.name}: ناهنجاری مصرف`, detail: `نرخ لحظه‌ای ${fmtBytes(cur * 2)} با امتیاز Z=${z.toFixed(1)} خارج از الگوی ۳۰ دقیقه اخیر است`, sev: Math.abs(z) > 5 ? "high" : "medium" });
      const slopePerHour = reg.slope * 1800;
      if (Math.abs(slopePerHour) > 50_000 && reg.r2 > 0.35) out.push({ type: "trend", title: `${r.name}: روند ${slopePerHour > 0 ? "صعودی" : "نزولی"} مصرف`, detail: `شیب برآوردی ≈ ${fmtRate(Math.abs(slopePerHour))} در ساعت (R²=${reg.r2.toFixed(2)})`, sev: "low" });
    });
    const susCount = [...this.ips.values()].filter((p) => p.susp && !p.idle).length;
    if (susCount) out.push({ type: "behavior", title: `${susCount} میزبان با رفتار غیرعادی`, detail: "الگوی نشست آن‌ها با میزان نرمال شبکه انحراف آماری دارد", sev: "medium" });
    return out.slice(0, 8);
  }

  async analyticsQuery(q: string) {
    let win: "1h" | "24h" | "30d" = "1h";
    let by: "ip" | "range" | "kind" = "ip";
    const filters: { ip?: string; range?: string; suspicious?: boolean } = {};
    const aggs: { fn: string; field: "rate" | "in" | "out" | "sessions" }[] = [];
    const FIELDS = ["rate", "in", "out", "sessions"] as const;
    q.split("|").map((t) => t.trim()).filter(Boolean).forEach((t) => {
      const lastM = /last\s+(1h|24h|30d)/i.exec(t);
      if (lastM) win = lastM[1].toLowerCase() as typeof win;
      const byM = /by\s+(ip|range|kind)/i.exec(t);
      if (byM) by = byM[1].toLowerCase() as typeof by;
      const sM = /^search\s+(.+)$/i.exec(t);
      if (sM)
        sM[1].replace(/"/g, "").split(/\s+/).forEach((kv) => {
          const [k, v] = kv.split("=");
          if (k === "ip" && v) filters.ip = v;
          if (k === "range" && v) filters.range = v;
          if (k === "suspicious" && v) filters.suspicious = v === "true";
        });
      const aM = /^stats\s+(.+)$/i.exec(t);
      if (aM) {
        const re = /(avg|max|min|p95|p50|stdev|sum|count|latest)\s*\(\s*(\w+)\s*\)/gi;
        let m;
        while ((m = re.exec(aM[1]))) {
          const fn = m[1].toLowerCase();
          const fld = (FIELDS as readonly string[]).includes(m[2].toLowerCase()) ? (m[2].toLowerCase() as (typeof FIELDS)[number]) : "rate";
          aggs.push({ fn, field: fld });
        }
      }
    });
    if (!aggs.length) aggs.push({ fn: "avg", field: "rate" }, { fn: "max", field: "rate" });

    type Bag = { dim: string; series: { t: number; v: number }[]; vals: number[] };
    const bags: Bag[] = [];
    const ips = [...this.ips.values()].filter(
      (p) => !p.external && !p.idle && (!filters.ip || p.ip === filters.ip) && (!filters.suspicious || !!p.susp) && (!filters.range || (this.rangesCache.find((r) => r.id === p.rangeId)?.name ?? "").includes(filters.range)),
    );

    if (win === "1h") {
      const groups = new Map<string, Bags>();
      type Bags = { dim: string; pts: Map<number, { i: number; o: number; s: number }> };
      void groups;
      const byDim = new Map<string, Map<number, { i: number; o: number; s: number }>>();
      ips.forEach((p) => {
        const dim = by === "ip" ? p.ip : by === "range" ? this.rangesCache.find((r) => r.id === p.rangeId)?.name ?? "—" : this.kindOf(p);
        const ring = this.rings.get(p.ip) ?? [];
        if (!ring.length) return;
        let m = byDim.get(dim);
        if (!m) byDim.set(dim, (m = new Map()));
        ring.forEach((pt) => {
          const e = m!.get(pt.t) ?? { i: 0, o: 0, s: 0 };
          e.i += pt.i; e.o += pt.o; e.s += pt.s;
          m!.set(pt.t, e);
        });
      });
      byDim.forEach((m, dim) => {
        const series = [...m.entries()].sort((a, b) => a[0] - b[0]).map(([t, v]) => ({ t, v: v.i + v.o, raw: v }));
        bags.push({ dim, series: series.map((s) => ({ t: s.t, v: s.v })), vals: series.map((s) => s.v) });
      });
    } else {
      const table = win === "24h" ? hourlyT : dailyT;
      const tsCol = win === "24h" ? hourlyT.ts : dailyT.day;
      const since = new Date(Date.now() - (win === "24h" ? 24 : 30 * 24) * 3600_000);
      const secPer = win === "24h" ? 3600 : 86400;
      try {
        const ipList = ips.map((p) => p.ip).slice(0, 90);
        if (ipList.length) {
          const rows = await db.select().from(table).where(and(inArray(table.ip, ipList), gte(tsCol, since))).orderBy(tsCol);
          const byDim = new Map<string, Map<number, number>>();
          rows.forEach((r) => {
            const p = this.ips.get(r.ip);
            const dim = by === "ip" ? r.ip : by === "range" ? this.rangesCache.find((x) => x.id === p?.rangeId)?.name ?? "—" : p ? this.kindOf(p) : "—";
            let m = byDim.get(dim);
            if (!m) byDim.set(dim, (m = new Map()));
            const k = new Date(win === "24h" ? (r as typeof hourlyT.$inferSelect).ts : (r as typeof dailyT.$inferSelect).day).getTime();
            m.set(k, (m.get(k) ?? 0) + (r.bytesIn + r.bytesOut) / secPer);
          });
          byDim.forEach((m, dim) => {
            const series = [...m.entries()].sort((a, b) => a[0] - b[0]).map(([t, v]) => ({ t, v }));
            bags.push({ dim, series, vals: series.map((s) => s.v) });
          });
        }
      } catch {
        /* حافظه‌ای */
      }
    }

    const compute = (vals: number[]) =>
      aggs.map((a) => {
        let v = 0;
        if (a.fn === "avg") v = mean(vals);
        else if (a.fn === "max") v = Math.max(0, ...vals);
        else if (a.fn === "min") v = vals.length ? Math.min(...vals) : 0;
        else if (a.fn === "p95") v = percentile(vals, 95);
        else if (a.fn === "p50") v = percentile(vals, 50);
        else if (a.fn === "stdev") v = stdev(vals);
        else if (a.fn === "sum") v = vals.reduce((x, y) => x + y, 0) * (win === "1h" ? 2 : win === "24h" ? 3600 : 86400);
        else if (a.fn === "count") v = vals.length;
        else if (a.fn === "latest") v = vals.at(-1) ?? 0;
        return [a.fn, v] as [string, number];
      });

    const rows = bags
      .map((b) => ({ dim: b.dim, vals: b.vals.length, metrics: Object.fromEntries(compute(b.vals)) as Record<string, number> }))
      .sort((a, b) => (b.metrics.avg ?? 0) - (a.metrics.avg ?? 0))
      .slice(0, 25);
    const series = bags
      .sort((x, y) => mean(y.vals) - mean(x.vals))
      .slice(0, 5)
      .map((b, i) => ({ name: b.dim, color: ["#22d3ee", "#a78bfa", "#34d399", "#fbbf24", "#fb7185"][i], data: b.series.slice(-300).map((p) => [p.t, Math.round(p.v)] as [number, number]) }));
    return { ok: true, q, win, by, aggs: aggs.map((a) => a.fn), rows, series };
  }

  kindOf(p: IpProfile): string {
    if (p.server) return "سرور/تجهیز";
    return "کلاینت";
  }

  // ---------- DNS ----------
  dnsView(scope: string) {
    const rows = this.dnsCache.filter((r) => r.scope === scope);
    const stats = {
      total: rows.length,
      active: rows.filter((r) => r.inUse && (r.domain || r.name)).length,
      inactive: rows.filter((r) => !r.inUse && (r.domain || r.name)).length,
      used: rows.filter((r) => r.domain || r.name).length,
      free: rows.filter((r) => !r.domain && !r.name).length,
      labels: [...new Set(rows.map((r) => r.label).filter(Boolean))],
    };
    const live = rows.slice(0, 80).map((r) => {
      const p = this.ips.get(r.ip);
      return { id: r.id, rate: p ? p.cur.i + p.cur.o : 0, monitored: !!p };
    });
    return { rows, stats, live };
  }

  async dnsAddRange(scope: string, cidr: string, label: string) {
    const c = parseCidr(cidr);
    if (!c) return { ok: false, error: "CIDR نامعتبر است" };
    if (!["internal", "external", "public"].includes(scope)) return { ok: false, error: "نوع نامعتبر" };
    const n = Math.min(c.capacity, 60);
    const rows = Array.from({ length: n }, (_, k) => ({
      scope, ip: intToIp((c.base + 1 + k) >>> 0), domain: "", name: "", inUse: false, label,
    }));
    if (this.dbReady) {
      await db.insert(dnsT).values(rows);
      this.dnsCache = await db.select().from(dnsT).orderBy(dnsT.id);
    } else {
      let id = Math.max(0, ...this.dnsCache.map((r) => r.id));
      this.dnsCache.push(...rows.map((r) => ({ ...r, id: ++id, createdAt: new Date() })));
    }
    trafficLog.add({ ts: Date.now(), cat: "system", level: "info", msg: `رنج DNS (${scope}) با ${n} آدرس تحت برچسب «${label}» ثبت شد` }).catch(() => undefined);
    return { ok: true, count: n };
  }

  async dnsPatch(id: number, patch: { domain?: string; name?: string; inUse?: boolean }) {
    const allowed: Partial<typeof dnsT.$inferInsert> = {};
    if (patch.domain !== undefined) allowed.domain = patch.domain.slice(0, 120);
    if (patch.name !== undefined) allowed.name = patch.name.slice(0, 80);
    if (patch.inUse !== undefined) allowed.inUse = patch.inUse;
    if (this.dbReady) {
      await db.update(dnsT).set(allowed).where(eq(dnsT.id, id));
      this.dnsCache = await db.select().from(dnsT).orderBy(dnsT.id);
    } else {
      const r = this.dnsCache.find((x) => x.id === id);
      if (r) Object.assign(r, allowed);
    }
    return { ok: true };
  }

  async dnsDelete(id: number) {
    if (this.dbReady) await db.delete(dnsT).where(eq(dnsT.id, id));
    this.dnsCache = this.dnsCache.filter((r) => r.id !== id);
    return { ok: true };
  }

  // ---------- درخت دامنه ----------
  treeView() {
    const live: Record<number, { status: "up" | "down" | "degraded"; rate: number; detail: { ip: string; online: boolean; rate: number }[] }> = {};
    this.treeCache.forEach((n) => {
      let ips: string[] = [];
      try {
        ips = JSON.parse(n.ips) as string[];
      } catch {
        ips = [];
      }
      const detail = ips.map((ip) => {
        const p = this.ips.get(ip);
        const dev = this.devicesCache.find((d) => d.ip === ip);
        const until = dev ? this.offlineUntil.get(dev.id) ?? 0 : 0;
        const online = dev ? until === 0 || until < Date.now() : true;
        return { ip, online, rate: p ? p.cur.i + p.cur.o : 0 };
      });
      const onCount = detail.filter((d) => d.online).length;
      live[n.id] = {
        status: detail.length && onCount === 0 ? "down" : onCount < detail.length ? "degraded" : "up",
        rate: detail.reduce((a, d) => a + d.rate, 0),
        detail,
      };
    });
    return { nodes: this.treeCache, live };
  }

  async treeAdd(node: { name: string; parentId: number | null; ips: string[]; kind: string }) {
    if (!node.name || node.name.length > 100) return { ok: false, error: "نام نامعتبر است" };
    const ips = (node.ips ?? []).slice(0, 12);
    if (this.dbReady) {
      await db.insert(treeT).values({ name: node.name, parentId: node.parentId ?? null, ips: JSON.stringify(ips), kind: node.kind });
      this.treeCache = await db.select().from(treeT).orderBy(treeT.id);
    } else {
      this.treeCache.push({ id: Math.max(0, ...this.treeCache.map((x) => x.id)) + 1, name: node.name, parentId: node.parentId ?? null, ips: JSON.stringify(ips), kind: node.kind, createdAt: new Date() });
    }
    return { ok: true };
  }

  async treePatch(id: number, patch: { name?: string; ips?: string[]; parentId?: number | null }) {
    const set: Partial<typeof treeT.$inferInsert> = {};
    if (patch.name !== undefined) set.name = patch.name.slice(0, 100);
    if (patch.ips !== undefined) set.ips = JSON.stringify(patch.ips.slice(0, 12));
    if (patch.parentId !== undefined) set.parentId = patch.parentId;
    if (this.dbReady) {
      await db.update(treeT).set(set).where(eq(treeT.id, id));
      this.treeCache = await db.select().from(treeT).orderBy(treeT.id);
    } else {
      const n = this.treeCache.find((x) => x.id === id);
      if (n) Object.assign(n, set);
    }
    return { ok: true };
  }

  async treeDelete(id: number) {
    const hasChild = this.treeCache.some((x) => x.parentId === id);
    if (hasChild) return { ok: false, error: "این گره زیردرخت دارد — ابتدا فرزندان را حذف کنید" };
    if (this.dbReady) await db.delete(treeT).where(eq(treeT.id, id));
    this.treeCache = this.treeCache.filter((x) => x.id !== id);
    return { ok: true };
  }

  // ---------- Syslog انتخابی ----------
  async syslogAdd(rule: { targetType: string; target: string; direction: string }) {
    if (!["device", "range", "ip"].includes(rule.targetType) || !rule.target) return { ok: false, error: "هدف نامعتبر است" };
    if (!["in", "out", "both"].includes(rule.direction)) return { ok: false, error: "جهت نامعتبر است" };
    if (this.dbReady) {
      await db.insert(syslogT).values({ targetType: rule.targetType, target: rule.target.slice(0, 80), direction: rule.direction });
      this.syslogCache = await db.select().from(syslogT).orderBy(syslogT.id);
    } else {
      this.syslogCache.push({ id: Math.max(0, ...this.syslogCache.map((x) => x.id)) + 1, targetType: rule.targetType, target: rule.target, direction: rule.direction, enabled: true, createdAt: new Date() });
    }
    trafficLog.add({ ts: Date.now(), cat: "system", level: "info", msg: `قانون Syslog برای ${rule.target} (${rule.direction === "in" ? "ورودی" : rule.direction === "out" ? "خروجی" : "هر دو جهت"}) فعال شد` }).catch(() => undefined);
    return { ok: true };
  }

  async syslogToggle(id: number) {
    const r = this.syslogCache.find((x) => x.id === id);
    if (!r) return { ok: false };
    if (this.dbReady) await db.update(syslogT).set({ enabled: !r.enabled }).where(eq(syslogT.id, id));
    r.enabled = !r.enabled;
    return { ok: true };
  }

  async syslogDelete(id: number) {
    if (this.dbReady) await db.delete(syslogT).where(eq(syslogT.id, id));
    this.syslogCache = this.syslogCache.filter((x) => x.id !== id);
    return { ok: true };
  }

  writeSyslogs() {
    const now = Date.now();
    for (const rule of this.syslogCache.filter((r) => r.enabled)) {
      let dst = rule.target;
      if (rule.targetType === "device") {
        dst = this.devicesCache.find((d) => d.name === rule.target || d.ip === rule.target)?.ip ?? rule.target;
      } else if (rule.targetType === "range") {
        const r = this.rangesCache.find((x) => x.id.toString() === rule.target);
        if (!r) continue;
        const c = parseCidr(r.cidr);
        if (!c) continue;
        dst = intToIp((c.base + 1) >>> 0);
      }
      // ورودی‌ها به هدف
      const inbound: [string, { i: number; o: number; hits: number }][] = [];
      this.peerMap.forEach((peers, owner) => {
        if (owner === dst) return;
        const e = peers.get(dst);
        if (e) inbound.push([owner, e]);
      });
      inbound.sort((a, b) => b[1].i + b[1].o - (a[1].i + a[1].o));
      for (const [src, v] of inbound.slice(0, 5)) {
        if (rule.direction !== "out") {
          trafficLog.add({ ts: now, cat: "syslog", level: "info", ip: src, peer: dst, msg: `ورودی به هدف تحت‌نظر: ${fmtBytes(v.o)} ارسال به ${dst} در ${v.hits} نشست`, meta: { dir: "in", bytes: Math.round(v.o) } }).catch(() => undefined);
        }
        if (rule.direction !== "in") {
          trafficLog.add({ ts: now, cat: "syslog", level: "info", ip: dst, peer: src, msg: `خروجی از هدف تحت‌نظر به ${src}: ${fmtBytes(v.i)} دانلود شده`, meta: { dir: "out", bytes: Math.round(v.i) } }).catch(() => undefined);
        }
      }
      // رخدادهای امنیتی مربوط
      this.recentEvents.filter((e) => e.dstIp === dst).slice(0, 3).forEach((e) => {
        trafficLog.add({ ts: e.ts, cat: "syslog", level: e.severity as LogEntry["level"], ip: e.srcIp, peer: dst, msg: `رویداد امنیتی روی هدف: ${e.detail}` }).catch(() => undefined);
      });
    }
  }

  // ---------- پشتیبان‌گیری ----------
  async maybeBackup(now: number) {
    const d = new Date(now);
    const hh = `${String(d.getHours()).padStart(2, "0")}:${String(d.getMinutes()).padStart(2, "0")}`;
    const key = d.toISOString().slice(0, 10);
    if (hh !== this.backupDaily || this.lastBackupKey === key) return;
    this.lastBackupKey = key;
    const kind = d.getDate() === this.backupMonthly ? "monthly" : d.getDay() === this.backupWeekly ? "weekly" : "daily";
    await this.backupNow(kind);
  }

  async backupNow(kind: string) {
    try {
      await mkdir(this.backupDir, { recursive: true });
      const d = new Date();
      const stamp = d.toISOString().replace(/[:.]/g, "-").slice(0, 16);
      const name = `hdmax-backup-${kind}-${stamp}.json.gz`;
      const payload = {
        meta: { t: Date.now(), kind, appId: appId(), version: "HDMAX NetWatch 2.0" },
        ranges: this.rangesCache, devices: this.devicesCache,
        dns: this.dnsCache, tree: this.treeCache, syslog: this.syslogCache,
        events: this.recentEvents.slice(-3000),
        license: this.licMeta ? { ...this.licMeta, mobile: "***" } : null,
      };
      const buf = gzipSync(Buffer.from(JSON.stringify(payload), "utf8"));
      await fsWrite(path.join(this.backupDir, name), buf);
      await this.saveSetting("backup.dir", this.backupDir);
      trafficLog.add({ ts: Date.now(), cat: "system", level: "info", msg: `پشتیبان‌گیری ${kind === "daily" ? "روزانه" : kind === "weekly" ? "هفتگی (فول)" : kind === "monthly" ? "ماهانه (فول)" : "دستی"} انجام شد: ${name} (${fmtBytes(buf.length)} فشرده)` }).catch(() => undefined);
      return { ok: true, name, size: buf.length };
    } catch (e) {
      return { ok: false, error: e instanceof Error ? e.message : "خطا در پشتیبان‌گیری" };
    }
  }

  async listBackups() {
    try {
      await mkdir(this.backupDir, { recursive: true });
      const names = (await readdir(this.backupDir)).filter((n) => n.endsWith(".json.gz")).sort().reverse();
      const out = [];
      for (const n of names.slice(0, 60)) {
        const st = await fsStat(path.join(this.backupDir, n)).catch(() => null);
        out.push({ name: n, size: st?.size ?? 0, mtime: st?.mtimeMs ?? 0, fa: new Date(st?.mtimeMs ?? 0).toLocaleDateString("fa-IR", { weekday: "long", year: "numeric", month: "long", day: "numeric" }) });
      }
      return out;
    } catch {
      return [];
    }
  }

  async viewBackup(name: string) {
    if (!/^hdmax-backup-[\w-]+\.json\.gz$/.test(name)) return { ok: false, error: "نام فایل نامعتبر است" };
    try {
      const raw = await fsRead(path.join(this.backupDir, name));
      const { gunzipSync } = await import("node:zlib");
      const json = JSON.parse(gunzipSync(raw).toString("utf8")) as { meta: Record<string, unknown>; events: unknown[]; ranges: unknown[]; devices: unknown[]; dns: unknown[] };
      return {
        ok: true,
        meta: json.meta,
        counts: { events: json.events?.length ?? 0, ranges: json.ranges?.length ?? 0, devices: json.devices?.length ?? 0, dns: json.dns?.length ?? 0 },
        events: (json.events ?? []).slice(-200),
      };
    } catch {
      return { ok: false, error: "فایل پشتیبان خوانده نشد" };
    }
  }

  async setBackupSettings(dir: string | null, daily: string | null) {
    if (dir) {
      const clean = dir.trim();
      if (clean.includes("..") || clean.length > 200) return { ok: false, error: "مسیر نامعتبر" };
      this.backupDir = clean;
      await mkdir(clean, { recursive: true });
      await this.saveSetting("backup.dir", clean);
    }
    if (daily && /^\d{2}:\d{2}$/.test(daily)) {
      this.backupDaily = daily;
      await this.saveSetting("backup.daily", daily);
    }
    return { ok: true };
  }

  // ---------- کاربران ----------
  async listUsers() {
    if (!this.dbReady) return [{ id: 1, username: "admin", role: "admin", perms: ["*"], active: true }];
    const rows = await db.select().from(usersT).orderBy(usersT.id);
    return rows.map((u) => {
      let perms: string[] = [];
      try {
        perms = JSON.parse(u.perms) as string[];
      } catch {
        perms = [];
      }
      return { id: u.id, username: u.username, role: u.role, perms, active: u.active };
    });
  }

  async addUser(u: { username: string; password: string; perms: string[]; role: string }) {
    if (!this.dbReady) return { ok: false, error: "دیتابیس لازم است" };
    const exists = await db.select().from(usersT);
    if (exists.some((x) => x.username === u.username)) return { ok: false, error: "نام کاربری تکراری است" };
    await db.insert(usersT).values({ username: u.username.slice(0, 40), hash: hashPassword(u.password), role: u.role === "admin" ? "admin" : "operator", perms: JSON.stringify(u.perms) });
    trafficLog.add({ ts: Date.now(), cat: "system", level: "info", msg: `کاربر جدید «${u.username}» ایجاد شد` }).catch(() => undefined);
    return { ok: true };
  }

  async patchUser(id: number, patch: { perms?: string[]; active?: boolean; password?: string }) {
    if (!this.dbReady) return { ok: false, error: "دیتابیس لازم است" };
    const set: Partial<typeof usersT.$inferInsert> = {};
    if (patch.perms) set.perms = JSON.stringify(patch.perms);
    if (patch.active !== undefined) set.active = patch.active;
    if (patch.password) set.hash = hashPassword(patch.password);
    await db.update(usersT).set(set).where(eq(usersT.id, id));
    return { ok: true };
  }

  async deleteUser(id: number, username: string) {
    if (username === "admin") return { ok: false, error: "کاربر admin حذف نمی‌شود" };
    if (!this.dbReady) return { ok: false, error: "دیتابیس لازم است" };
    await db.delete(usersT).where(eq(usersT.id, id));
    return { ok: true };
  }

  async changePassword(username: string, oldPw: string, newPw: string) {
    if (!this.dbReady) return { ok: false, error: "دیتابیس لازم است" };
    const rows = await db.select().from(usersT).where(eq(usersT.username, username));
    const u = rows[0];
    if (!u || !verifyPassword(oldPw, u.hash)) return { ok: false, error: "رمز فعلی اشتباه است" };
    await db.update(usersT).set({ hash: hashPassword(newPw) }).where(eq(usersT.id, u.id));
    return { ok: true };
  }

  async verifyLogin(username: string, password: string) {
    if (!this.dbReady) return null;
    const rows = await db.select().from(usersT).where(eq(usersT.username, username.slice(0, 40)));
    const u = rows[0];
    if (!u || !u.active) return null;
    try {
      if (!verifyPassword(password, u.hash)) return null;
      let perms: string[] = [];
      try {
        perms = JSON.parse(u.perms) as string[];
      } catch {
        perms = [];
      }
      trafficLog.add({ ts: Date.now(), cat: "system", level: "info", msg: `ورود موفق کاربر «${username}»` }).catch(() => undefined);
      return { id: u.id, username: u.username, role: u.role, perms };
    } catch {
      return null;
    }
  }

  // ------------------- خروجی‌های عمومی -------------------
  snapshot() {
    const now = Date.now();
    const meta = this.rangeRingMeta;
    const ranges = this.rangesCache.map((r) => {
      const c = parseCidr(r.cidr);
      const used = [...this.ips.values()].filter((p) => p.rangeId === r.id && !p.external).length;
      const m = meta.get(r.id) ?? { i: 0, o: 0, active: 0, susp: 0 };
      const ring = this.rangeRing.get(r.id) ?? [];
      return { id: r.id, name: r.name, cidr: r.cidr, kind: r.kind, color: r.color, i: m.i, o: m.o, active: m.active, susp: m.susp, used, capacity: c?.capacity ?? 0, sparkSeries: ring.slice(-42).map((p) => p.i + p.o), top: this.rangeTops.get(r.id) ?? null };
    });
    const top = [...this.ips.values()]
      .filter((p) => !p.external && !p.idle)
      .sort((a, b) => b.cur.i + b.cur.o - (a.cur.i + a.cur.o))
      .slice(0, 14)
      .map((p) => ({ ip: p.ip, host: p.host, i: p.cur.i, o: p.cur.o, s: p.cur.s, rangeId: p.rangeId, susp: !!p.susp, server: p.server, spark: this.spark(p.ip, 30) }));
    const susp = [...this.ips.values()]
      .filter((p) => p.susp && !p.idle)
      .sort((a, b) => (b.susp?.score ?? 0) - (a.susp?.score ?? 0))
      .slice(0, 10)
      .map((p) => ({ ip: p.ip, host: p.host, i: p.cur.i, o: p.cur.o, s: p.cur.s, score: p.susp!.score, kind: p.susp!.kind, reason: this.suspReason(p), spark: this.spark(p.ip, 30) }));
    const internal = [...this.ips.values()]
      .filter((p) => !p.external && !p.idle && p.cur.i + p.cur.o > 0)
      .sort((a, b) => b.cur.i + b.cur.o - (a.cur.i + a.cur.o))
      .slice(0, 60)
      .map((p) => this.ipRow(p));
    const external = [...this.ips.values()]
      .filter((p) => p.external)
      .sort((a, b) => b.cur.i + b.cur.o - (a.cur.i + a.cur.o))
      .map((p) => this.ipRow(p));
    const all = [...internal, ...external];
    const totRing = this.totalRing.slice(-300);
    const topAttacker = [...this.attackerCount.entries()].sort((a, b) => b[1] - a[1])[0];
    const topTarget = [...this.targetCount.entries()].sort((a, b) => b[1] - a[1])[0];
    const ev = this.evBuf.splice(0, this.evBuf.length);
    const pkts = this.pktsBuf.splice(0, this.pktsBuf.length);
    let activeCount = 0;
    this.ips.forEach((p) => { if (p.cur.i + p.cur.o > 24) activeCount++; });
    return {
      t: now, tickMs: TICK_MS, dbReady: this.dbReady, up: Math.floor((now - this.bootedAt) / 1000),
      tot: { i: this.totalRing.at(-1)?.i ?? 0, o: this.totalRing.at(-1)?.o ?? 0, s: this.totalRing.at(-1)?.s ?? 0, active: activeCount },
      totTops: this.topsRing.at(-1)?.tops ?? [],
      ring: totRing.map((p) => ({ t: p.t, i: p.i, o: p.o })),
      ranges, top, susp, internal, external, all, events: ev, pkts,
      kindAgg: Object.entries(this.kindAggStore).map(([key, v]) => ({ key, ...v })),
      net: { online: this.netOnline, ping: this.netPing, mode: this.netMode },
      lic: (() => {
        const s = this.licenseState();
        return { state: s.state, daysLeft: s.daysLeft, syncDue: s.syncDue, overdueDays: s.overdueDays, licName: s.licName, org: s.org };
      })(),
      sec: {
        today: this.eventsToday, blocked: this.blockedToday,
        topAttacker: topAttacker ? { ip: topAttacker[0], n: topAttacker[1] } : null,
        topTarget: topTarget ? { ip: topTarget[0], n: topTarget[1] } : null,
        campaign: !!this.campaign,
      },
      devs: this.devicesCache.map((d) => ({ id: d.id, online: (this.offlineUntil.get(d.id) ?? 0) < now || (this.offlineUntil.get(d.id) ?? 0) === 0, lat: this.latency.get(d.id) ?? 1 })),
    };
  }

  ipRow(p: IpProfile) {
    return { ip: p.ip, host: p.host, i: p.cur.i, o: p.cur.o, s: p.cur.s, rangeId: p.rangeId, server: p.server, susp: !!p.susp, spark: this.spark(p.ip, 30) };
  }

  spark(ip: string, n = 36): number[] {
    const r = this.rings.get(ip) ?? [];
    return r.slice(-n).map((p) => p.i + p.o);
  }

  suspReason(p: IpProfile): string {
    switch (p.susp?.kind) {
      case "scan": return "تعداد نشست غیرعادی — الگوی اسکن پورت";
      case "exfil": return "ارسال داده سنگین در ساعات غیرکاری (نشت احتمالی)";
      case "flood": return "نوسان شدید و ترافیک انفجاری دوره‌ای";
      case "beacon": return "ارتباط Beacon منظم به مقصد ثابت";
      default: return "رفتار غیرعادی";
    }
  }

  classify(ip: string) {
    const p = this.ips.get(ip);
    if (!p) return null;
    const label = p.susp ? "مشکوک" : p.idle ? "بیکار / بدون نشست نرمال" : p.external ? "برون‌مرزی" : "نرمال";
    const reasons: string[] = [];
    if (p.susp) reasons.push(this.suspReason(p), `امتیاز ریسک: ${p.susp.score} از ۱۰۰`);
    if (p.idle) reasons.push("در ۲۴ ساعت اخیر نشست معناداری ثبت نشده است", "مصرف نزدیک به صفر — احتمالاً آدرس رزرو یا راکد");
    if (!p.susp && !p.idle) reasons.push("الگوی نشست و نرخ داده در محدوده نرمال سازمان");
    return { label, reasons, score: p.susp?.score ?? (p.idle ? 18 : 6) };
  }

  history(ip: string, win: "1h" | "24h" | "30d") {
    const p = this.ips.get(ip);
    if (!p) return { points: [] as Pt[], totals: { i: 0, o: 0, peak: 0, avg: 0 } };
    if (win === "1h") {
      const pts = (this.rings.get(ip) ?? []).slice();
      return { points: pts, totals: this.totalsOf(pts, 2) };
    }
    return { points: [] as Pt[], totals: { i: 0, o: 0, peak: 0, avg: 0 } };
  }

  totalsOf(pts: Pt[], secPerPt: number) {
    let i = 0, o = 0, peak = 0;
    pts.forEach((p) => { i += p.i * secPerPt; o += p.o * secPerPt; peak = Math.max(peak, p.i + p.o); });
    const avg = pts.length ? pts.reduce((a, p) => a + p.i + p.o, 0) / pts.length : 0;
    return { i, o, peak, avg };
  }

  async historyDb(ip: string, win: "24h" | "30d") {
    const table = win === "24h" ? hourlyT : dailyT;
    const tsCol = win === "24h" ? hourlyT.ts : dailyT.day;
    const since = new Date(Date.now() - (win === "24h" ? 24 : 30 * 24) * 3600_000);
    try {
      const rows = await db.select().from(table).where(and(eq(table.ip, ip), gte(tsCol, since))).orderBy(tsCol);
      const secPer = win === "24h" ? 3600 : 86400;
      const pts: Pt[] = rows.map((r) => ({ t: new Date(win === "24h" ? (r as typeof hourlyT.$inferSelect).ts : (r as typeof dailyT.$inferSelect).day).getTime(), i: r.bytesIn / secPer, o: r.bytesOut / secPer, s: r.sessions }));
      const acc = this.hourAcc.get(ip) ?? { i: 0, o: 0, s: 0, p: 0 };
      const dAcc = this.dayAcc.get(ip) ?? { i: 0, o: 0, s: 0, p: 0 };
      if (win === "24h") {
        const mins = Math.max(1, (Date.now() - this.hourStart) / 60000);
        pts.push({ t: Date.now(), i: acc.i / (mins * 60), o: acc.o / (mins * 60), s: acc.s });
      } else {
        pts.push({ t: Date.now(), i: dAcc.i / ((Date.now() - this.dayStart) / 1000 || 1), o: dAcc.o / ((Date.now() - this.dayStart) / 1000 || 1), s: dAcc.s });
      }
      let ti = rows.reduce((a, r) => a + r.bytesIn, 0) + (win === "24h" ? acc.i : dAcc.i);
      let to = rows.reduce((a, r) => a + r.bytesOut, 0) + (win === "24h" ? acc.o : dAcc.o);
      const peak = Math.max(...pts.map((p) => p.i + p.o), 0);
      const avg = pts.length ? pts.reduce((a, p) => a + p.i + p.o, 0) / pts.length : 0;
      return { points: pts, totals: { i: ti, o: to, peak, avg } };
    } catch {
      return { points: [] as Pt[], totals: { i: 0, o: 0, peak: 0, avg: 0 } };
    }
  }

  rangeDetail(id: number) {
    const r = this.rangesCache.find((x) => x.id === id);
    if (!r) return null;
    const c = parseCidr(r.cidr);
    const ring = (this.rangeRing.get(id) ?? []).slice(-300);
    const members = [...this.ips.values()].filter((p) => p.rangeId === id && !p.external);
    const rows = members
      .sort((a, b) => b.cur.i + b.cur.o - (a.cur.i + a.cur.o))
      .map((p) => ({
        ...this.ipRow(p),
        idle: p.idle,
        susp: p.susp ? { score: p.susp.score, kind: p.susp.kind, reason: this.suspReason(p) } : null,
      }));
    const capacity = c?.capacity ?? 0;
    const usedSet = new Set(members.map((m) => m.ip));
    const unused: string[] = [];
    if (c && capacity <= 4096) {
      for (let k = 1; k <= capacity && unused.length < 64; k++) {
        const ip = intToIp((c.base + k) >>> 0);
        if (!usedSet.has(ip)) unused.push(ip);
      }
    }
    let unusedCount = Math.max(0, capacity - usedSet.size);
    const rates = rows.map((x) => x.i + x.o).filter((x) => x > 0).sort((a, b) => a - b);
    const p95 = rates.length ? rates[Math.floor(rates.length * 0.95)] : 0;
    const ringVals = ring.map((p) => p.i + p.o);
    const avg = ringVals.length ? ringVals.reduce((a, b) => a + b, 0) / ringVals.length : 0;
    const peak = Math.max(...ringVals, 0);
    return {
      range: r, ring: ring.map((p) => ({ t: p.t, i: p.i, o: p.o })),
      ips: rows,
      stats: {
        capacity, used: members.length, activeNow: rows.filter((x) => x.i + x.o > 24).length,
        idle: rows.filter((x) => x.idle).length, susp: rows.filter((x) => x.susp).length,
        unusedCount, unused, avg, peak, p95,
      },
    };
  }

  /** سری تجمیعی ساعتی (۲۴ساعت) و روزانه (۳۰روز) کل رنج */
  async rangeTrend(id: number) {
    const empty = { h24: [] as Pt[], h30: [] as Pt[] };
    const members = [...this.ips.values()].filter((p) => p.rangeId === id && !p.external).map((p) => p.ip);
    if (!members.length || !this.dbReady) return empty;
    try {
      const dayAgo = new Date(Date.now() - 24 * 3600_000);
      const rows = await db.select().from(hourlyT).where(and(inArray(hourlyT.ip, members), gte(hourlyT.ts, dayAgo)));
      const byTs = new Map<number, { i: number; o: number; s: number }>();
      rows.forEach((r) => {
        const k = new Date(r.ts).getTime();
        const v = byTs.get(k) ?? { i: 0, o: 0, s: 0 };
        v.i += r.bytesIn; v.o += r.bytesOut; v.s += r.sessions;
        byTs.set(k, v);
      });
      const h24: Pt[] = [...byTs.entries()].sort((a, b) => a[0] - b[0]).map(([t, v]) => ({ t, i: v.i / 3600, o: v.o / 3600, s: v.s }));
      const monthAgo = new Date(Date.now() - 30 * 86400_000);
      const drows = await db.select().from(dailyT).where(and(inArray(dailyT.ip, members), gte(dailyT.day, monthAgo)));
      const byDay = new Map<number, { i: number; o: number; s: number }>();
      drows.forEach((r) => {
        const k = new Date(r.day).getTime();
        const v = byDay.get(k) ?? { i: 0, o: 0, s: 0 };
        v.i += r.bytesIn; v.o += r.bytesOut; v.s += r.sessions;
        byDay.set(k, v);
      });
      const h30: Pt[] = [...byDay.entries()].sort((a, b) => a[0] - b[0]).map(([t, v]) => ({ t, i: v.i / 86400, o: v.o / 86400, s: v.s }));
      return { h24, h30 };
    } catch {
      return empty;
    }
  }

  ipDetail(ip: string) {
    const p = this.ips.get(ip);
    if (!p) return null;
    const cls = this.classify(ip)!;
    const pr = mulberry(hash(ip) ^ 31337);
    const protos: [string, number][] = [["HTTPS", 0.3 + pr() * 0.25], ["DNS", 0.08 + pr() * 0.08], ["SMB", pr() * 0.3], ["RDP", pr() * 0.12], ["SQL", pr() * 0.2], ["سایر", pr() * 0.15]];
    const sum = protos.reduce((a, x) => a + x[1], 0);
    const conns = Array.from({ length: 18 }, (_, k) => {
      const peer = p.external ? this.devicesCache[Math.floor(pr() * Math.max(1, this.devicesCache.length))]?.ip ?? "10.10.0.21" : p.peers[k % p.peers.length] ?? "8.8.8.8";
      const ports = [443, 53, 445, 3389, 5432, 80, 25];
      return {
        t: Date.now() - k * (150 + Math.floor(pr() * 500)) * 1000,
        peer, proto: ["TCP", "UDP"][Math.floor(pr() * 2)], port: ports[Math.floor(pr() * ports.length)],
        bytes: Math.round((0.2 + pr() * 40) * 1_000_000), state: pr() < 0.85 ? "برقرار" : "بسته شده",
      };
    });
    const range = this.rangesCache.find((r) => r.id === p.rangeId);
    const peers = [...(this.peerMap.get(ip)?.entries() ?? [])]
      .map(([other, v]) => ({
        ip: other,
        name: this.ips.get(other)?.host ?? this.extName(other),
        i: Math.round(v.i), o: Math.round(v.o), hits: v.hits, last: v.last,
      }))
      .sort((a, b) => b.i + b.o - (a.i + a.o))
      .slice(0, 12);
    return {
      ip: p.ip, host: p.host, rangeId: p.rangeId, rangeName: range?.name ?? (p.external ? "برون‌مرزی" : "—"),
      server: p.server, external: p.external, now: { i: p.cur.i, o: p.cur.o, s: p.cur.s },
      cls, spark: this.spark(ip, 40),
      protos: protos.map(([n, v]) => ({ name: n, pct: Math.round((v / sum) * 100) })),
      conns, peers,
    };
  }

  devicesView() {
    const now = Date.now();
    const list = this.devicesCache.map((d) => {
      const until = this.offlineUntil.get(d.id) ?? 0;
      const online = until === 0 || until < now;
      const prof = this.ips.get(d.ip);
      const stab = this.stabilityOf(d.id);
      const authPeers = d.isDomain
        ? [...(this.peerMap.get(d.ip)?.entries() ?? [])]
            .map(([o, v]) => ({ ip: o, name: this.ips.get(o)?.host ?? this.extName(o), i: Math.round(v.i), o: Math.round(v.o), hits: v.hits, last: v.last }))
            .sort((a, b) => b.i + b.o - (a.i + a.o))
            .slice(0, 6)
        : [];
      return {
        ...d, online, lat: this.latency.get(d.id) ?? 1,
        rate: prof ? prof.cur.i + prof.cur.o : 0, i: prof?.cur.i ?? 0, o: prof?.cur.o ?? 0,
        sessions: prof?.cur.s ?? 0,
        sessionsIn: Math.round((prof?.cur.s ?? 0) * 0.62),
        sessionsOut: (prof?.cur.s ?? 0) - Math.round((prof?.cur.s ?? 0) * 0.62),
        stabPct: stab.pct,
        downOpen: this.downOpen.get(d.id) ?? null,
        downWins: (this.downWindows.get(d.id) ?? []).slice(-4),
        spark: prof ? this.spark(d.ip, 30) : [],
        authPeers,
        vms: [] as unknown[],
      };
    });
    const byId = new Map(list.map((d) => [d.id, d]));
    list.forEach((d) => {
      if (d.parentId && byId.get(d.parentId)) (byId.get(d.parentId)!.vms as unknown[]).push(d);
    });
    return list;
  }

  trace(srcIp: string, dstIp: string) {
    const devs = this.devicesView();
    const pick = (kind: string[]) => devs.find((d) => kind.includes(d.kind) && d.online);
    const srcRange = [...this.ips.values()].find((p) => p.ip === srcIp)?.rangeId;
    const nodes: { name: string; ip: string; kind: string; lat: number; loss: number; role: string }[] = [];
    const roleOf = (k: string) => ({ cisco: "سوییچ هسته", switch: "سوییچ توزیع", mikrotik: "روتر/گیت‌وی", firewall: "فایروال مرزی", esxi: "میزبان مجازی‌ساز", server: "سرور مقصد", windows: "سرور مقصد", vm: "ماشین مجازی", other: "گره" }[k] ?? "گره");
    nodes.push({ name: "مبدأ", ip: srcIp, kind: "host", lat: 0, loss: 0, role: "میزبان مبدأ" });
    const gwIp = srcRange != null ? (this.rangesCache.find((r) => r.id === srcRange)?.cidr.split(".")[1] === "168" ? "192.168.1.1" : undefined) : undefined;
    const core = pick(["cisco"]) ?? devs.find((d) => d.ip === gwIp && d.online);
    if (core) nodes.push({ name: core.name, ip: core.ip, kind: core.kind, lat: +(0.4 + rnd() * 1.2).toFixed(1), loss: 0, role: roleOf(core.kind) });
    const dist = pick(["switch"]);
    if (dist) nodes.push({ name: dist.name, ip: dist.ip, kind: dist.kind, lat: +(0.6 + rnd() * 1.5).toFixed(1), loss: 0, role: roleOf(dist.kind) });
    const fw = pick(["firewall"]);
    if (fw) nodes.push({ name: fw.name, ip: fw.ip, kind: fw.kind, lat: +(1 + rnd() * 3).toFixed(1), loss: 0, role: roleOf(fw.kind) });
    const gw = pick(["mikrotik"]);
    if (gw) nodes.push({ name: gw.name, ip: gw.ip, kind: gw.kind, lat: +(0.8 + rnd() * 2.4).toFixed(1), loss: 0, role: roleOf(gw.kind) });
    const dstProf = this.ips.get(dstIp);
    if (dstProf?.server && dstProf.rangeId) {
      const esxi = devs.find((d) => d.kind === "esxi" && d.rangeId === dstProf.rangeId && d.online);
      if (esxi && dstIp !== esxi.ip) nodes.push({ name: esxi.name, ip: esxi.ip, kind: "esxi", lat: +(0.5 + rnd() * 1.4).toFixed(1), loss: 0, role: "میزبان ESXi مقصد" });
    }
    nodes.push({ name: dstProf?.host ?? "مقصد", ip: dstIp, kind: dstProf?.server ? "server" : "host", lat: +(0.2 + rnd() * 1).toFixed(1), loss: 0, role: "میزبان مقصد" });
    const total = nodes.reduce((a, n) => a + n.lat, 0);
    return { nodes, totalLat: +total.toFixed(1), hops: nodes.length - 1 };
  }

  async addRange(name: string, cidr: string, kind: string, color: string, groupName = "") {
    const c = parseCidr(cidr);
    if (!c) return { ok: false, error: "فرمت CIDR معتبر نیست (مثال: 10.0.0.0/24)" };
    if (this.rangesCache.some((r) => r.cidr === cidr)) return { ok: false, error: "این رنج قبلاً ثبت شده است" };
    let row: typeof rangesT.$inferSelect;
    if (this.dbReady) {
      const ins = await db.insert(rangesT).values({ name, cidr, kind, color, groupName }).returning();
      row = ins[0];
      this.rangesCache = await db.select().from(rangesT).orderBy(rangesT.id);
    } else {
      row = { id: Math.max(0, ...this.rangesCache.map((r) => r.id)) + 1, name, cidr, kind, color, groupName, createdAt: new Date() };
      this.rangesCache.push(row);
    }
    this.buildProfiles();
    this.backfill();
    trafficLog.add({ ts: Date.now(), cat: "system", level: "info", msg: `رنج جدید «${name}» (${cidr}) تعریف و پایش آن آغاز شد` }).catch(() => undefined);
    return { ok: true, id: row.id };
  }

  async removeRange(id: number) {
    const gone = this.rangesCache.find((r) => r.id === id);
    if (this.dbReady) await db.delete(rangesT).where(eq(rangesT.id, id));
    this.rangesCache = this.rangesCache.filter((r) => r.id !== id);
    this.buildProfiles();
    trafficLog.add({ ts: Date.now(), cat: "system", level: "info", msg: `رنج «${gone?.name ?? id}» حذف شد` }).catch(() => undefined);
    return { ok: true };
  }

  async addDevice(data: Partial<typeof devicesT.$inferInsert>) {
    if (!data.name || !data.ip || ipToInt(String(data.ip)) < 0) return { ok: false, error: "نام یا IP معتبر نیست" };
    if (this.dbReady) {
      await db.insert(devicesT).values(data as typeof devicesT.$inferInsert);
      this.devicesCache = await db.select().from(devicesT).orderBy(devicesT.id);
    } else {
      this.devicesCache.push({ id: Math.max(0, ...this.devicesCache.map((d) => d.id)) + 1, name: data.name!, ip: data.ip!, kind: data.kind ?? "server", rangeId: data.rangeId ?? null, parentId: data.parentId ?? null, isDomain: !!data.isDomain, snmp: !!data.snmp, wmi: !!data.wmi, ilo: !!data.ilo, community: data.community ?? "public", osVersion: data.osVersion ?? null, notes: data.notes ?? null, createdAt: new Date() });
    }
    this.buildProfiles();
    trafficLog.add({ ts: Date.now(), cat: "system", level: "info", ip: String(data.ip), msg: `تجهیز جدید «${String(data.name)}» (${String(data.kind ?? "server")}) ثبت و پایش آغاز شد` }).catch(() => undefined);
    return { ok: true };
  }

  async removeDevice(id: number) {
    const gone = this.devicesCache.find((d) => d.id === id);
    if (this.dbReady) await db.delete(devicesT).where(eq(devicesT.id, id));
    this.devicesCache = this.devicesCache.filter((d) => d.id !== id && d.parentId !== id);
    this.buildProfiles();
    trafficLog.add({ ts: Date.now(), cat: "system", level: "info", ip: gone?.ip, msg: `تجهیز «${gone?.name ?? id}» حذف شد` }).catch(() => undefined);
    return { ok: true };
  }

  async toggleDevice(id: number, field: "snmp" | "wmi" | "ilo" | "isDomain") {
    const d = this.devicesCache.find((x) => x.id === id);
    if (!d || !(field in d)) return { ok: false };
    const val = !(d as unknown as Record<string, unknown>)[field];
    if (this.dbReady) await db.update(devicesT).set({ [field]: val }).where(eq(devicesT.id, id));
    (d as unknown as Record<string, unknown>)[field] = val;
    return { ok: true, value: val };
  }

  simulate(kind: string) {
    if (kind === "attack") {
      this.campaign = { src: "45.155.204." + (10 + Math.floor(rnd() * 200)), left: 5, type: rnd() < 0.5 ? "brute-force" : "port-scan", sev: "critical" };
      return { ok: true, msg: "کمپین حمله شبیه‌سازی شد — به بخش امنیت مراجعه کنید" };
    }
    if (kind === "spike") {
      const cands = [...this.ips.values()].filter((p) => !p.idle && !p.external && !p.server);
      const p = cands[Math.floor(rnd() * cands.length)];
      if (p) { p.burstUntil = Date.now() + 45_000; p.burstMult = 30 + rnd() * 20; }
      return { ok: true, msg: `افزایش ناگهانی مصرف روی ${p?.ip ?? ""} اعمال شد` };
    }
    return { ok: false, msg: "نوع ناشناخته" };
  }

  bootstrap() {
    return {
      ranges: this.rangesCache.map((r) => {
        const c = parseCidr(r.cidr);
        const used = [...this.ips.values()].filter((p) => p.rangeId === r.id && !p.external).length;
        return { ...r, capacity: c?.capacity ?? 0, used };
      }),
      devices: this.devicesView(),
      events: this.recentEvents.slice(-80).reverse(),
      pkts: this.pktsBuf.slice(-40),
      tickMs: TICK_MS,
      dbReady: this.dbReady,
    };
  }
}

const DDL = `
CREATE TABLE IF NOT EXISTS nm_ranges (
  id SERIAL PRIMARY KEY, name TEXT NOT NULL, cidr TEXT NOT NULL,
  kind TEXT NOT NULL DEFAULT 'lan', color TEXT NOT NULL DEFAULT '#22d3ee',
  group_name TEXT NOT NULL DEFAULT '', created_at TIMESTAMP NOT NULL DEFAULT now()
);
ALTER TABLE nm_ranges ADD COLUMN IF NOT EXISTS group_name TEXT NOT NULL DEFAULT '';
CREATE TABLE IF NOT EXISTS nm_devices (
  id SERIAL PRIMARY KEY, name TEXT NOT NULL, ip TEXT NOT NULL,
  kind TEXT NOT NULL DEFAULT 'server', range_id INTEGER, parent_id INTEGER,
  is_domain BOOLEAN NOT NULL DEFAULT false, snmp BOOLEAN NOT NULL DEFAULT true,
  wmi BOOLEAN NOT NULL DEFAULT false, ilo BOOLEAN NOT NULL DEFAULT false,
  community TEXT NOT NULL DEFAULT 'public', os_version TEXT, notes TEXT,
  created_at TIMESTAMP NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS nm_hourly (
  id SERIAL PRIMARY KEY, ip TEXT NOT NULL, ts TIMESTAMP NOT NULL,
  bytes_in BIGINT NOT NULL DEFAULT 0, bytes_out BIGINT NOT NULL DEFAULT 0,
  sessions INTEGER NOT NULL DEFAULT 0, pkts INTEGER NOT NULL DEFAULT 0
);
CREATE UNIQUE INDEX IF NOT EXISTS nm_hourly_ip_ts_uq ON nm_hourly (ip, ts);
CREATE INDEX IF NOT EXISTS nm_hourly_ts_idx ON nm_hourly (ts);
CREATE TABLE IF NOT EXISTS nm_daily (
  id SERIAL PRIMARY KEY, ip TEXT NOT NULL, day TIMESTAMP NOT NULL,
  bytes_in BIGINT NOT NULL DEFAULT 0, bytes_out BIGINT NOT NULL DEFAULT 0,
  sessions INTEGER NOT NULL DEFAULT 0, pkts INTEGER NOT NULL DEFAULT 0
);
CREATE UNIQUE INDEX IF NOT EXISTS nm_daily_ip_day_uq ON nm_daily (ip, day);
CREATE INDEX IF NOT EXISTS nm_daily_day_idx ON nm_daily (day);
CREATE TABLE IF NOT EXISTS nm_events (
  id SERIAL PRIMARY KEY, ts TIMESTAMP NOT NULL DEFAULT now(),
  src_ip TEXT NOT NULL, dst_ip TEXT NOT NULL, type TEXT NOT NULL,
  severity TEXT NOT NULL DEFAULT 'medium', action TEXT NOT NULL DEFAULT 'blocked', detail TEXT
);
CREATE INDEX IF NOT EXISTS nm_events_ts_idx ON nm_events (ts);
CREATE TABLE IF NOT EXISTS nm_settings (key TEXT PRIMARY KEY, value TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS nm_users (
  id SERIAL PRIMARY KEY, username TEXT NOT NULL, hash TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'operator', perms TEXT NOT NULL DEFAULT '[]',
  active BOOLEAN NOT NULL DEFAULT true, created_at TIMESTAMP NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS nm_license (
  id SERIAL PRIMARY KEY, file TEXT NOT NULL, content TEXT NOT NULL, meta TEXT NOT NULL,
  state TEXT NOT NULL DEFAULT 'issued', last_sync TIMESTAMP, created_at TIMESTAMP NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS nm_dns (
  id SERIAL PRIMARY KEY, scope TEXT NOT NULL, ip TEXT NOT NULL, domain TEXT NOT NULL DEFAULT '',
  name TEXT NOT NULL DEFAULT '', in_use BOOLEAN NOT NULL DEFAULT true, label TEXT NOT NULL DEFAULT '',
  created_at TIMESTAMP NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS nm_tree (
  id SERIAL PRIMARY KEY, parent_id INTEGER, name TEXT NOT NULL, kind TEXT NOT NULL DEFAULT 'branch',
  ips TEXT NOT NULL DEFAULT '[]', created_at TIMESTAMP NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS nm_syslog_rules (
  id SERIAL PRIMARY KEY, target_type TEXT NOT NULL, target TEXT NOT NULL,
  direction TEXT NOT NULL DEFAULT 'in', enabled BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMP NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS nm_snmp_roles (
  id SERIAL PRIMARY KEY, name TEXT NOT NULL, device_kind TEXT NOT NULL DEFAULT 'all',
  version TEXT NOT NULL DEFAULT 'v2c', "user" TEXT NOT NULL DEFAULT '', auth_type TEXT NOT NULL DEFAULT 'SHA-256',
  oids TEXT NOT NULL DEFAULT '[]', acls TEXT NOT NULL DEFAULT '[]', enabled BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMP NOT NULL DEFAULT now()
);
`;

const g = globalThis as unknown as { __nadirEngine?: Engine };
export function getEngine(): Engine {
  if (!g.__nadirEngine) g.__nadirEngine = new Engine();
  return g.__nadirEngine;
}
export async function ensureEngine(): Promise<Engine> {
  const e = getEngine();
  await e.start();
  return e;
}
