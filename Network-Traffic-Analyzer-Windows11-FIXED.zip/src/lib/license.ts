import crypto from "node:crypto";
import os from "node:os";
import path from "node:path";
import { mkdir, readFile, writeFile } from "node:fs/promises";

// =====================================================================
//  ماژول لایسنس HDMAX — فایل .slf با رمزنگاری AES-256-GCM + امضای HMAC
//  همگام‌سازی/اعتبارسنجی با https://giftmax.ir/lic/<file>.slf
// =====================================================================

const MAGIC = "HDMAX-SLF-1";
const SYNC_BASE = "https://giftmax.ir/lic/";

export interface LicenseMeta {
  v: number;
  appId: string;
  licName: string;
  firstName: string;
  lastName: string;
  mobile: string;
  org: string;
  edition: "standard" | "pro" | "enterprise";
  years: 1 | 2 | 3;
  issuedAt: number;
  validUntil: number;
  file: string;
}

let cachedKey: Buffer | null = null;

/** کلید محرمانه نصب — یکبار ساخته و کنار پروژه نگهداری می‌شود */
async function secretKey(): Promise<Buffer> {
  if (cachedKey) return cachedKey;
  const file = path.join(os.homedir(), "NadirNetWatch", "hdx.key");
  try {
    const b64 = (await readFile(file, "utf8")).trim();
    cachedKey = Buffer.from(b64, "base64");
    if (cachedKey.length !== 32) throw new Error("bad key");
  } catch {
    cachedKey = crypto.randomBytes(32);
    await mkdir(path.dirname(file), { recursive: true });
    await writeFile(file, cachedKey.toString("base64"), { mode: 0o600 });
  }
  return cachedKey;
}

/** شناسه یکتای نرم‌افزار بر اساس اثرانگشت ماشین */
export function appId(): string {
  const raw = crypto.createHash("sha256").update(`${os.hostname()}|${os.userInfo().username}|${os.platform()}|hdmax`).digest("hex").toUpperCase();
  return `HDX-${raw.slice(0, 4)}-${raw.slice(4, 8)}-${raw.slice(8, 12)}`;
}

/** رمزنگاری ۲۵۶ بیتی + قفل‌گذاری (obfuscate + AMAC) */
export async function encodeSlf(meta: LicenseMeta): Promise<string> {
  const key = await secretKey();
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv("aes-256-gcm", key, iv);
  const plain = Buffer.from(JSON.stringify(meta), "utf8");
  const enc = Buffer.concat([cipher.update(plain), cipher.final()]);
  const tag = cipher.getAuthTag();
  const blob = Buffer.concat([iv, tag, enc]).toString("base64url");
  const sig = crypto.createHmac("sha256", key).update(MAGIC + blob).digest("hex");
  // لایه قفل/مبهم‌سازی سطح فایل
  const payload = JSON.stringify({ magic: MAGIC, alg: "AES-256-GCM", kid: appId(), data: blob, sig });
  const locked = Buffer.from(payload).toString("base64url").split("").reverse().join("");
  return `-----BEGIN HDMAX LICENSE-----\n${locked}\n-----END HDMAX LICENSE-----\n`;
}

export async function decodeSlf(content: string): Promise<LicenseMeta> {
  const key = await secretKey();
  const m = content.match(/-----BEGIN HDMAX LICENSE-----\s*([\s\S]+?)\s*-----END HDMAX LICENSE-----/);
  if (!m) throw new Error("فرمت فایل .slf نامعتبر است");
  const payload = JSON.parse(Buffer.from(m[1].split("").reverse().join(""), "base64url").toString("utf8")) as { magic: string; data: string; sig: string };
  if (payload.magic !== MAGIC) throw new Error("امضای فایل نامعتبر است");
  const sig = crypto.createHmac("sha256", key).update(MAGIC + payload.data).digest("hex");
  if (sig !== payload.sig) throw new Error("فایل لایسنس دست‌کاری شده است");
  const buf = Buffer.from(payload.data, "base64url");
  const iv = buf.subarray(0, 12);
  const tag = buf.subarray(12, 28);
  const enc = buf.subarray(28);
  const decipher = crypto.createDecipheriv("aes-256-gcm", key, iv);
  decipher.setAuthTag(tag);
  const plain = Buffer.concat([decipher.update(enc), decipher.final()]).toString("utf8");
  return JSON.parse(plain) as LicenseMeta;
}

/** همگام‌سازی با مسیر رسمی giftmax.ir/lic/ — فایل باید دقیقاً یکسان باشد */
export async function syncLicense(file: string, localContent: string): Promise<{ ok: boolean; msg: string; same: boolean | null }> {
  try {
    const ctl = new AbortController();
    const t = setTimeout(() => ctl.abort(), 9000);
    const res = await fetch(SYNC_BASE + file, { signal: ctl.signal, cache: "no-store", headers: { "User-Agent": "HDMAX-LicenseSync/1.0" } });
    clearTimeout(t);
    if (!res.ok) return { ok: false, same: null, msg: `سرور همگام‌سازی پاسخ ${res.status} داد — فایل را در مسیر ${SYNC_BASE}${file} قرار دهید و دوباره تلاش کنید` };
    const remote = (await res.text()).trim();
    const same = remote === localContent.trim();
    return same
      ? { ok: true, same, msg: "همگام‌سازی موفق — فایل لایسنس با سرور رسمی یکسان است؛ اعتبار فعال شد" }
      : { ok: false, same, msg: "محتوای فایل روی سرور با لایسنس محلی یکسان نیست" };
  } catch {
    return { ok: false, same: null, msg: "اتصال به اینترنت/سرور giftmax.ir برقرار نشد — سیستم را آنلاین کنید و دوباره همگام‌سازی بزنید" };
  }
}

export function licenseFileName(org: string): string {
  const clean = (org || "hdmax").toLowerCase().replace(/[^a-z0-9\u0600-\u06FF]+/g, "").slice(0, 12) || "hdmax";
  return `${clean === "hdmax" ? "hdmax" : clean}.slf`;
}
