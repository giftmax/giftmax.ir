"use client";

import { useEffect, useRef, useState, useCallback } from "react";

// ---------- انواع داده کلاینت ----------
export type RangeSnap = {
  id: number; name: string; cidr: string; kind: string; color: string;
  i: number; o: number; active: number; susp: number; used: number; capacity: number;
  sparkSeries: number[]; top: [string, number] | null;
};
export type IpRow = {
  ip: string; host: string; i: number; o: number; s: number;
  rangeId: number | null; server: boolean; susp: boolean; spark: number[];
};
export type SuspRow = IpRow & { score: number; kind: string; reason: string };
export type Pt = { t: number; i: number; o: number };
export type EvOut = {
  id: number; ts: number; srcIp: string; dstIp: string; type: string;
  severity: string; action: string; detail: string; srcExt: boolean;
};
export type PktOut = {
  t: number; src: string; dst: string; proto: string; sp: number; dp: number;
  len: number; flags: string; info: string;
};
export type Snap = {
  t: number; tickMs: number; dbReady: boolean; up: number;
  tot: { i: number; o: number; s: number; active: number };
  totTops: [string, number][];
  ring: Pt[];
  ranges: RangeSnap[];
  top: IpRow[];
  susp: SuspRow[];
  internal: IpRow[];
  external: IpRow[];
  all: IpRow[];
  events: EvOut[];
  pkts: PktOut[];
  sec: {
    today: number; blocked: number;
    topAttacker: { ip: string; n: number } | null;
    topTarget: { ip: string; n: number } | null;
    campaign: boolean;
  };
  devs: { id: number; online: boolean; lat: number }[];
  kindAgg: { key: string; i: number; o: number; n: number; on: number; top: [string, number][] }[];
  net: { online: boolean; ping: number; mode: string };
  lic: { state: string; daysLeft: number; syncDue: boolean; overdueDays: number; licName: string; org: string };
};

// ---------- استور سراسری SSE (یک اتصال برای کل برنامه) ----------
let es: EventSource | null = null;
let snap: Snap | null = null;
let connected = false;
const subs = new Set<() => void>();

function notify() {
  subs.forEach((f) => f());
}

function ensure() {
  if (typeof window === "undefined" || es) return;
  const open = () => {
    try {
      es = new EventSource("/api/stream");
      es.onopen = () => {
        connected = true;
        notify();
      };
      es.onmessage = (ev) => {
        try {
          snap = JSON.parse(ev.data) as Snap;
        } catch {
          /* بسته نامعتبر */
        }
        notify();
      };
      es.onerror = () => {
        connected = false;
        notify();
        es?.close();
        es = null;
        setTimeout(open, 3000);
      };
    } catch {
      setTimeout(open, 3000);
    }
  };
  open();
}

export function useSnap(): { snap: Snap | null; connected: boolean } {
  const [, force] = useState(0);
  useEffect(() => {
    ensure();
    const f = () => force((x) => x + 1);
    subs.add(f);
    return () => {
      subs.delete(f);
    };
  }, []);
  return { snap, connected };
}

// ---------- هوک polling (آژاکس بدون رفرش) ----------
export function usePoll<T>(fn: () => Promise<T>, ms: number, deps: unknown[] = []) {
  const [data, setData] = useState<T | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const ref = useRef(fn);
  ref.current = fn;
  const reload = useCallback(async () => {
    try {
      setData(await ref.current());
      setErr(null);
    } catch (e) {
      setErr(e instanceof Error ? e.message : String(e));
    }
  }, []);
  useEffect(() => {
    let alive = true;
    const run = async () => {
      try {
        const d = await ref.current();
        if (alive) {
          setData(d);
          setErr(null);
        }
      } catch (e) {
        if (alive) setErr(e instanceof Error ? e.message : String(e));
      }
    };
    run();
    const iv = setInterval(run, ms);
    return () => {
      alive = false;
      clearInterval(iv);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [ms, ...deps]);
  return { data, err, reload };
}

// ---------- نگهداشت تاریخچه سمت کلاینت برای نمودار زنده ----------
export function useLiveAppend<T>(value: T | null, cap = 300): T[] {
  const ref = useRef<T[]>([]);
  const [, force] = useState(0);
  useEffect(() => {
    if (value == null) return;
    ref.current = [...ref.current, value].slice(-cap);
    force((x) => x + 1);
  }, [value, cap]);
  return ref.current;
}
