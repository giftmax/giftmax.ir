import { appendFile, mkdir, readdir, readFile, readFile as rf, stat, unlink, writeFile } from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import { gzipSync, gunzipSync } from "node:zlib";

// =====================================================================
//  لاگر فایلی روزانه — هر روز یک فایل جدا (JSONL) خارج از پوشه برنامه
//  - مسیر قابل تنظیم است و به‌صورت پیش‌فرض در پوشه کاربر نگهداری می‌شود
//  - پاک‌سازی خودکار قدیمی‌تر از بازه نگهداشت + فشرده‌سازی gzip روزهای قبل
// =====================================================================

export interface LogEntry {
  ts: number;
  cat: "traffic" | "security" | "device" | "system" | "syslog";
  level: "info" | "low" | "medium" | "high" | "critical";
  ip?: string;
  peer?: string;
  msg: string;
  meta?: Record<string, unknown>;
}

export interface LogFileInfo {
  name: string;
  date: string; // YYYY-MM-DD
  faDate: string; // تاریخ شمسی
  size: number;
  mtime: number;
  gz?: boolean;
}

const FILE_RE = /^netwatch-(\d{4})-(\d{2})-(\d{2})\.log(\.gz)?$/;

function pad(n: number) {
  return String(n).padStart(2, "0");
}

class TrafficLogger {
  dir: string;
  retentionDays = 90;
  lastPurgeAt = 0;
  ready = false;

  constructor() {
    this.dir = process.env.NADIR_LOG_DIR || path.join(os.homedir(), "NadirNetWatch", "logs");
  }

  async init() {
    try {
      await mkdir(this.dir, { recursive: true });
      this.ready = true;
    } catch {
      this.ready = false;
    }
  }

  fileName(d = new Date()): string {
    return `netwatch-${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}.log`;
  }

  async setDir(next: string) {
    const clean = next.trim();
    if (!clean || clean.includes("..") || clean.length > 200) throw new Error("مسیر نامعتبر است");
    await mkdir(clean, { recursive: true });
    this.dir = clean;
  }

  async add(e: LogEntry) {
    if (!this.ready) return;
    try {
      await appendFile(path.join(this.dir, this.fileName(new Date(e.ts))), JSON.stringify(e) + "\n", "utf8");
    } catch {
      /* دیسک مشکل دارد — نادیده */
    }
  }

  async list(): Promise<LogFileInfo[]> {
    if (!this.ready) await this.init();
    try {
      const names = (await readdir(this.dir)).filter((n) => FILE_RE.test(n)).sort().reverse();
      const out: LogFileInfo[] = [];
      for (const name of names) {
        const m = FILE_RE.exec(name)!;
        const st = await stat(path.join(this.dir, name)).catch(() => null);
        const dObj = new Date(Number(m[1]), Number(m[2]) - 1, Number(m[3]));
        out.push({
          name,
          date: `${m[1]}-${m[2]}-${m[3]}`,
          faDate: dObj.toLocaleDateString("fa-IR", { weekday: "long", year: "numeric", month: "long", day: "numeric" }),
          size: st?.size ?? 0,
          mtime: st?.mtimeMs ?? 0,
          gz: name.endsWith(".gz"),
        });
      }
      return out;
    } catch {
      return [];
    }
  }

  /** فشرده‌سازی فایل‌های روزهای گذشته (صرفه‌جویی حجم ذخیره‌سازی) */
  async rotateCompress(): Promise<number> {
    const today = this.fileName();
    let gz = 0;
    try {
      const names = (await readdir(this.dir)).filter((n) => /^netwatch-\d{4}-\d{2}-\d{2}\.log$/.test(n) && n !== today);
      for (const n of names) {
        const raw = await rf(path.join(this.dir, n), "utf8");
        await writeFile(path.join(this.dir, n + ".gz"), gzipSync(Buffer.from(raw, "utf8")));
        await unlink(path.join(this.dir, n));
        gz++;
      }
    } catch {
      /* نادیده */
    }
    return gz;
  }

  /** پاک‌سازی خودکار: قدیمی‌تر از بازه نگهداشت + سقوط خودکار به ۳۰ روز هنگام پر شدن فضا */
  quotaBytes = Math.round(1.8 * 1024 ** 3); // سهمیه حجم لاگ ≈ ۱.۸ گیگ

  async purge(days?: number): Promise<number> {
    const keepReq = days ?? this.retentionDays;
    let keep = keepReq;
    await this.rotateCompress();
    const totalNow = (await this.list()).reduce((a, f) => a + f.size, 0);
    if (totalNow > this.quotaBytes * 0.85 && keep > 30) keep = 30; // سقف فضا → نگه‌داشت فقط ۳۰ روز
    const cutoff = Date.now() - keep * 86_400_000;
    let removed = 0;
    const files = await this.list();
    for (const f of files) {
      if (new Date(f.date + "T00:00:00").getTime() < cutoff) {
        try {
          await unlink(path.join(this.dir, f.name));
          removed++;
        } catch {
          /* قفل است */
        }
      }
    }
    // اگر هنوز بالای سهمیه: قدیمی‌ترین‌ها تا رسیدن زیر سقف حذف شوند
    let total2 = 0;
    const rest = (await this.list()).sort((a, b) => (a.date < b.date ? -1 : 1));
    const remain: typeof rest = [];
    for (const f of rest) {
      total2 += f.size;
      remain.push(f);
    }
    let idx = 0;
    while (total2 > this.quotaBytes && idx < remain.length) {
      const f = remain[idx++];
      try {
        await unlink(path.join(this.dir, f.name));
        total2 -= f.size;
        removed++;
      } catch {
        break;
      }
    }
    this.lastPurgeAt = Date.now();
    if (removed > 0) {
      await this.add({ ts: Date.now(), cat: "system", level: "info", msg: `پاک‌سازی خودکار: ${removed} فایل لاگ (قدیمی‌تر از ${keep} روز${keep !== keepReq ? " — سقوط به ۳۰ روز به‌دلیل سقف فضا" : ""}) حذف شد` });
    }
    return removed;
  }

  validateName(name: string): boolean {
    return FILE_RE.test(name) && path.basename(name) === name;
  }

  async read(name: string, opts: { search?: string; dirOverride?: string; limit?: number } = {}) {
    if (!this.validateName(name)) throw new Error("نام فایل نامعتبر است");
    const base = opts.dirOverride ? this.validateDir(opts.dirOverride) : this.dir;
    const limit = Math.min(5000, opts.limit ?? 3000);
    const fileBuf = await readFile(path.join(base, name));
    const raw = name.endsWith(".gz") ? gunzipSync(fileBuf).toString("utf8") : fileBuf.toString("utf8");
    let lines = raw.split("\n").filter(Boolean);
    const total = lines.length;
    if (opts.search) {
      const s = opts.search.toLowerCase();
      lines = lines.filter((l) => l.toLowerCase().includes(s));
    }
    const picked = lines.slice(-limit);
    const entries: LogEntry[] = [];
    for (const l of picked) {
      try {
        entries.push(JSON.parse(l) as LogEntry);
      } catch {
        /* خط خراب */
      }
    }
    return { entries, total, matched: lines.length, truncated: lines.length > limit };
  }

  validateDir(d: string): string {
    const clean = d.trim();
    if (!clean || clean.includes("..") || clean.length > 200) throw new Error("مسیر نامعتبر است");
    return clean;
  }

  /** جستجوی IP در فایل‌های N روز اخیر — گروه‌بندی به تفکیک روز (شمسی) */
  async searchByIp(ip: string, days = 7) {
    const out: { date: string; faDate: string; name: string; entries: LogEntry[] }[] = [];
    const capDays = Math.min(120, Math.max(1, days));
    const available = new Set((await readdir(this.dir).catch(() => [] as string[])));
    for (let i = 0; i < capDays; i++) {
      const d = new Date(Date.now() - i * 86_400_000);
      const name = available.has(this.fileName(d)) ? this.fileName(d) : available.has(this.fileName(d) + ".gz") ? this.fileName(d) + ".gz" : null;
      if (!name) continue;
      try {
        const buf = await readFile(path.join(this.dir, name));
        const raw = name.endsWith(".gz") ? gunzipSync(buf).toString("utf8") : buf.toString("utf8");
        const hits: LogEntry[] = [];
        for (const l of raw.split("\n")) {
          if (!l || !l.includes(ip)) continue;
          try {
            const e = JSON.parse(l) as LogEntry;
            if (e.ip === ip || e.peer === ip || l.includes(ip)) hits.push(e);
          } catch {
            /* خراب */
          }
          if (hits.length >= 400) break;
        }
        if (hits.length) {
          out.push({
            date: `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`,
            faDate: d.toLocaleDateString("fa-IR", { weekday: "long", year: "numeric", month: "long", day: "numeric" }),
            name,
            entries: hits,
          });
        }
      } catch {
        /* آن روز فایل ندارد */
      }
    }
    return out;
  }
}

const g = globalThis as unknown as { __trafficLog?: TrafficLogger };
export const trafficLog: TrafficLogger = g.__trafficLog ?? (g.__trafficLog = new TrafficLogger());
