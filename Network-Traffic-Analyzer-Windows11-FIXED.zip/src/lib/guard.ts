import { getEngine } from "./engine";

// محدودکننده نرخ درخواست (دفاع در برابر فلود/تست نفوذ روی API)
const buckets = new Map<string, { c: number; reset: number }>();

export function clientIp(req: Request): string {
  const xff = req.headers.get("x-forwarded-for");
  if (xff) return xff.split(",")[0].trim();
  return req.headers.get("x-real-ip") ?? "127.0.0.1";
}

export function rateLimit(req: Request, bucket: string, limit = 40, windowMs = 10_000): Response | null {
  const ip = clientIp(req);
  const k = `${bucket}:${ip}`;
  const now = Date.now();
  let b = buckets.get(k);
  if (!b || b.reset < now) {
    b = { c: 0, reset: now + windowMs };
    buckets.set(k, b);
  }
  b.c++;
  if (b.c > limit) {
    try {
      getEngine().pushEvent({
        srcIp: ip,
        dstIp: `api/${bucket}`,
        type: "rate-limit",
        severity: "medium",
        action: "blocked",
        detail: `عبور از آستانه نرخ (${limit} درخواست در ${windowMs / 1000} ثانیه) — مبدأ محدود شد`,
      });
    } catch {
      /* انجین هنوز بالا نیامده */
    }
    return Response.json({ ok: false, error: "درخواست بیش از حد مجاز — لطفاً کمی بعد تلاش کنید" }, { status: 429 });
  }
  return null;
}

export function badInput(msg: string) {
  return Response.json({ ok: false, error: msg }, { status: 400 });
}

/** قفل لایسنس: پس از انقضا یا عدم همگام‌سازی، فقط مشاهده مجاز است */
export async function writeGuard(): Promise<Response | null> {
  try {
    const { ensureEngine } = await import("./engine");
    const eng = await ensureEngine();
    if (!eng.licenseState().writable) {
      return Response.json(
        { ok: false, locked: true, error: "اعتبار لایسنس پایان یافته یا نیاز به همگام‌سازی دارد — فقط مشاهده داشبورد و لاگ مجاز است. برای فعال‌سازی مجدد به بخش لایسنس بروید." },
        { status: 423 },
      );
    }
  } catch {
    /* عبور */
  }
  return null;
}
