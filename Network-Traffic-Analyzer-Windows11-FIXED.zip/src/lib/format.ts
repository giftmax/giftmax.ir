// ---------- فرمت نرخ (بیت بر ثانیه) ----------
export function fmtRate(bytesPerSec: number): string {
  const bits = Math.max(0, bytesPerSec) * 8;
  if (bits < 1e3) return `${bits.toFixed(0)} b/s`;
  if (bits < 1e6) return `${(bits / 1e3).toFixed(1)} Kb/s`;
  if (bits < 1e9) return `${(bits / 1e6).toFixed(2)} Mb/s`;
  return `${(bits / 1e9).toFixed(2)} Gb/s`;
}

// ---------- فرمت حجم (بایت) ----------
export function fmtBytes(bytes: number): string {
  const b = Math.max(0, bytes);
  if (b < 1024) return `${b.toFixed(0)} B`;
  if (b < 1024 ** 2) return `${(b / 1024).toFixed(1)} KB`;
  if (b < 1024 ** 3) return `${(b / 1024 ** 2).toFixed(2)} MB`;
  if (b < 1024 ** 4) return `${(b / 1024 ** 3).toFixed(2)} GB`;
  return `${(b / 1024 ** 4).toFixed(2)} TB`;
}

export function fmtInt(n: number): string {
  return Math.round(n).toLocaleString("en-US");
}

// ---------- زمان ----------
export function faTime(t: number | Date): string {
  return new Date(t).toLocaleTimeString("fa-IR", {
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
  });
}
export function faHM(t: number | Date): string {
  return new Date(t).toLocaleTimeString("fa-IR", {
    hour: "2-digit",
    minute: "2-digit",
  });
}
export function faDate(t: number | Date): string {
  return new Date(t).toLocaleDateString("fa-IR", { month: "2-digit", day: "2-digit" });
}
export function faDateTime(t: number | Date): string {
  return `${faDate(t)} ${faTime(t)}`;
}

// ---------- ابزارهای IP / CIDR ----------
export function ipToInt(ip: string): number {
  const p = ip.split(".").map((x) => parseInt(x, 10));
  if (p.length !== 4 || p.some((n) => Number.isNaN(n) || n < 0 || n > 255)) return -1;
  return (((p[0] << 24) >>> 0) + ((p[1] << 16) >>> 0) + ((p[2] << 8) >>> 0) + p[3]) >>> 0;
}

export function intToIp(n: number): string {
  return `${(n >>> 24) & 255}.${(n >>> 16) & 255}.${(n >>> 8) & 255}.${n & 255}`;
}

export function isValidIp(ip: string): boolean {
  return ipToInt(ip) >= 0;
}

export function parseCidr(cidr: string): { base: number; bits: number; capacity: number } | null {
  const m = /^(\d{1,3}(?:\.\d{1,3}){3})\/(\d{1,2})$/.exec(cidr.trim());
  if (!m) return null;
  const ip = ipToInt(m[1]);
  const bits = parseInt(m[2], 10);
  if (ip < 0 || bits < 8 || bits > 30) return null;
  const mask = (0xffffffff << (32 - bits)) >>> 0;
  const base = (ip & mask) >>> 0;
  const capacity = Math.max(0, 2 ** (32 - bits) - 2);
  return { base, bits, capacity };
}

export function isPrivateIp(ip: string): boolean {
  const n = ipToInt(ip);
  if (n < 0) return false;
  const a = (n >>> 24) & 255;
  const b = (n >>> 16) & 255;
  return a === 10 || a === 127 || (a === 172 && b >= 16 && b <= 31) || (a === 192 && b === 168);
}

// ---------- برچسب‌های فارسی ----------
export const KIND_FA: Record<string, string> = {
  cisco: "سیسکو",
  mikrotik: "میکروتیک",
  switch: "سوئیچ",
  windows: "سرور ویندوز",
  esxi: "میزبان ESXi",
  vm: "ماشین مجازی",
  server: "سرور",
  firewall: "فایروال",
  fiber: "لبه فیبر منطقه",
  wireless: "رادیو وایرلس",
  other: "سایر",
};

export const SEV_FA: Record<string, string> = {
  low: "کم",
  medium: "متوسط",
  high: "شدید",
  critical: "بحرانی",
};

export const EVT_FA: Record<string, string> = {
  "port-scan": "اسکن پورت",
  "brute-force": "حمله بروت‌فورس",
  "icmp-flood": "سیل ICMP",
  anomaly: "ناهنجاری ترافیک",
  "unauth-access": "تلاش دسترسی غیرمجاز",
  "rate-limit": "آسیب‌پذیری/فلود API",
};

export const RANGE_KIND_FA: Record<string, string> = {
  lan: "شبکه کاربران",
  servers: "شبکه سرورها",
  dmz: "DMZ",
  wan: "ارتباط بیرونی",
  iot: "اینترنت اشیا",
};
