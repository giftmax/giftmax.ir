// توابع آماری کلیدی (معادل NumPy/SciPy/Statsmodels) — پیاده‌سازی TypeScript

export function mean(a: number[]): number {
  return a.length ? a.reduce((x, y) => x + y, 0) / a.length : 0;
}
export function stdev(a: number[]): number {
  if (a.length < 2) return 0;
  const m = mean(a);
  return Math.sqrt(a.reduce((x, y) => x + (y - m) ** 2, 0) / (a.length - 1));
}
export function variance(a: number[]): number {
  return stdev(a) ** 2;
}
export function percentile(a: number[], p: number): number {
  if (!a.length) return 0;
  const s = [...a].sort((x, y) => x - y);
  const i = (s.length - 1) * (p / 100);
  const lo = Math.floor(i);
  const hi = Math.ceil(i);
  return s[lo] + (s[hi] - s[lo]) * (i - lo);
}
export function mad(a: number[]): number {
  // Median Absolute Deviation — ناهنجاری مقاوم
  const med = percentile(a, 50);
  return percentile(a.map((x) => Math.abs(x - med)), 50);
}
export function zscore(x: number, mu: number, sd: number): number {
  return sd < 1e-9 ? 0 : (x - mu) / sd;
}
/** روند خطی (حداقل مربعات) — شیب به ازای هر نقطه + ضریب تعیین R² */
export function linreg(y: number[]): { slope: number; intercept: number; r2: number } {
  const n = y.length;
  if (n < 3) return { slope: 0, intercept: mean(y), r2: 0 };
  const xs = Array.from({ length: n }, (_, i) => i);
  const mx = mean(xs);
  const my = mean(y);
  let num = 0;
  let den = 0;
  for (let i = 0; i < n; i++) {
    num += (xs[i] - mx) * (y[i] - my);
    den += (xs[i] - mx) ** 2;
  }
  const slope = den ? num / den : 0;
  const intercept = my - slope * mx;
  let ssRes = 0;
  let ssTot = 0;
  for (let i = 0; i < n; i++) {
    const yh = slope * xs[i] + intercept;
    ssRes += (y[i] - yh) ** 2;
    ssTot += (y[i] - my) ** 2;
  }
  return { slope, intercept, r2: ssTot ? Math.max(0, 1 - ssRes / ssTot) : 0 };
}
/** میانگین متحرک نمايي EWMA */
export function ewma(a: number[], alpha = 0.3): number[] {
  const out: number[] = [];
  let prev = a[0] ?? 0;
  a.forEach((x, i) => {
    prev = i === 0 ? x : alpha * x + (1 - alpha) * prev;
    out.push(prev);
  });
  return out;
}
export function autocorrLag1(a: number[]): number {
  // خودهمبستگی — برای تشخیص الگوی تناوبی/Bot Behavior
  const n = a.length;
  if (n < 5) return 0;
  const m = mean(a);
  let num = 0;
  let den = 0;
  for (let i = 1; i < n; i++) num += (a[i] - m) * (a[i - 1] - m);
  for (let i = 0; i < n; i++) den += (a[i] - m) ** 2;
  return den ? num / den : 0;
}
