"use client";

import { useState } from "react";
import { Globe2, ShieldAlert, Wifi, WifiOff, RefreshCcw, Crosshair, BookMarked } from "lucide-react";
import { usePoll } from "@/lib/useEngine";
import { PageHead, Section, Stat, Skeleton, SevBadge } from "@/components/ui";
import { SEV_FA, EVT_FA, faDateTime, faDate, fmtInt } from "@/lib/format";

type IranResp = {
  ok: boolean; online: boolean; updatedAt: number;
  ranges: { isp: string; en: string; cidr: string; cls: string; ips: number }[];
  totalIps: number; ispCount: number;
  attacks: { id: number; ts: number; srcIp: string; dstIp: string; type: string; severity: string; isp: string | null; cidr: string | null; detail: string }[];
  nonIran: { id: number; ts: number; srcIp: string; dstIp: string; type: string; severity: string; detail: string }[];
  threats: { id: string; name: string; fa: string; cat: string; severity: string; how: string; src: string; dst: string; indicator: string; defense: string; liveHits: number }[];
};

type Tab = "iran" | "threats" | "attacks";

export default function IranPage() {
  const { data } = usePoll<IranResp>(async () => (await fetch("/api/iran")).json(), 8000, []);
  const [tab, setTab] = useState<Tab>("iran");
  if (!data) return <div className="space-y-4"><Skeleton h={90} /><Skeleton h={260} /></div>;

  return (
    <div className="space-y-6">
      <PageHead
        title="رنج‌های IPv4 ایران و هوش تهدید"
        sub="به‌روزرسانی خودکار هفتگی پایگاه رنج‌ها هنگام اتصال اینترنت — نسبت‌دهی حملات به ISP ایرانی/خارجی و تحلیل روش حملات"
        chips={
          <>
            <span className="chip" style={data.online ? { color: "#34d399" } : { color: "#fb7185" }}>
              {data.online ? <Wifi size={12} /> : <WifiOff size={12} />} {data.online ? "آنلاین — دریافت شد" : "آفلاین"}
            </span>
            <span className="chip"><RefreshCcw size={12} /> آخرین به‌روزرسانی: {faDate(data.updatedAt)}</span>
          </>
        }
      />

      {!data.online && (
        <div className="glass fade-up border-r-4 border-amber-400/60 p-4 text-[12.5px] text-amber-200">
          سیستم آفلاین است — داده‌های کش‌شده نمایش داده می‌شود. با اتصال اینترنت، به‌روزرسانی هفتگی و شناسایی زنده فعال می‌شود.
        </div>
      )}

      <div className="fade-up grid grid-cols-2 gap-4 lg:grid-cols-4">
        <Stat icon={Globe2} label="رنج‌های IPv4 ایران" value={fmtInt(data.ranges.length)} color="#22d3ee" />
        <Stat icon={Globe2} label="اپراتورها (ISP)" value={fmtInt(data.ispCount)} color="#a78bfa" />
        <Stat icon={Globe2} label="مجموع آدرس‌های IPv4" value={fmtInt(data.totalIps)} color="#34d399" />
        <Stat icon={ShieldAlert} label="حمله از رنج‌های ایرانی" value={fmtInt(data.attacks.length)} color="#fb7185" sub="در نشست جاری پایش" />
      </div>

      <div className="fade-up fade-up-1 flex gap-1">
        {([["iran", "رنج‌های ایران"], ["threats", "تحلیل حملات (دیتاست)"], ["attacks", "حملات نسبت‌داده‌شده"]] as [Tab, string][]).map(([k, l]) => (
          <button key={k} className={`tab-btn !border ${tab === k ? "active" : "!border-slate-500/15"}`} onClick={() => setTab(k)}>{l}</button>
        ))}
      </div>

      {tab === "iran" && (
        <div className="glass fade-up fade-up-2 p-5">
          <Section icon={Globe2} title="پایگاه رنج‌های IPv4 ایران" sub="هر رنج نام اپراتور و کلاس خود را دارد — به‌روزرسانی خودکار هر ۷ روز" />
          <div className="scroll-thin max-h-[520px] overflow-auto">
            <table className="table-base">
              <thead><tr><th>اپراتور / ISP</th><th>نام انگلیسی</th><th>رنج (CIDR)</th><th>کلاس</th><th>تعداد IP</th><th>وضعیت</th></tr></thead>
              <tbody>
                {data.ranges.map((r) => (
                  <tr key={r.cidr}>
                    <td className="font-semibold text-slate-200">{r.isp}</td>
                    <td className="text-slate-500" dir="ltr">{r.en}</td>
                    <td className="mono text-cyan-300" dir="ltr">{r.cidr}</td>
                    <td><span className="chip !text-[10px]">کلاس {r.cls}</span></td>
                    <td className="mono text-slate-300" dir="ltr">{fmtInt(r.ips)}</td>
                    <td><span className="chip !text-[10px]" style={{ color: "#34d399", borderColor: "#34d39940", background: "#34d39910" }}>در حال بهره‌برداری</span></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {tab === "threats" && (
        <div className="fade-up fade-up-2 grid gap-4 md:grid-cols-2">
          {data.threats.map((t) => (
            <div key={t.id} className="glass p-5">
              <div className="mb-2 flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <BookMarked size={17} className="text-amber-300" />
                  <div>
                    <div className="text-[14px] font-bold text-slate-100">{t.fa}</div>
                    <div className="mono text-[10.5px] text-slate-500" dir="ltr">{t.name} — {t.cat}</div>
                  </div>
                </div>
                <SevBadge sev={SEV_FA[t.severity] ? t.severity : "medium"} />
              </div>
              <div className="space-y-2 text-[11.5px] leading-6 text-slate-300">
                <p><b className="text-slate-100">چگونه انجام می‌شود:</b> {t.how}</p>
                <div className="grid grid-cols-2 gap-2">
                  <div className="rounded-lg border border-slate-500/15 bg-slate-500/5 p-2"><div className="text-[10px] text-slate-500">منبع (مبدأ)</div><div className="mt-0.5 text-slate-200">{t.src}</div></div>
                  <div className="rounded-lg border border-slate-500/15 bg-slate-500/5 p-2"><div className="text-[10px] text-slate-500">مقصد</div><div className="mt-0.5 text-slate-200">{t.dst}</div></div>
                </div>
                <p><b className="text-rose-300">نشانه تشخیص:</b> {t.indicator}</p>
                <p><b className="text-emerald-300">دفاع:</b> {t.defense}</p>
              </div>
              {t.liveHits > 0 && (
                <div className="mt-3 chip" style={{ color: "#fb7185", borderColor: "#fb718540", background: "#fb718512" }}>
                  <ShieldAlert size={11} /> {fmtInt(t.liveHits)} مورد مشابه همین حمله، همین حالا در شبکه شما دیده شد
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      {tab === "attacks" && (
        <div className="grid gap-4 xl:grid-cols-2">
          <div className="glass fade-up fade-up-2 p-5">
            <Section icon={Crosshair} title="حملات از رنج‌های ایران" sub="مشخص است از کدام رنج و کدام شرکت آمده" />
            <div className="scroll-thin max-h-[430px] space-y-2 overflow-auto">
              {data.attacks.map((a) => (
                <div key={a.id} className="rounded-xl border border-rose-400/15 bg-rose-400/5 p-3 text-[11.5px]">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="mono font-bold text-rose-200">{a.srcIp}</span>
                    <span className="chip !text-[10px]" style={{ color: "#fbbf24", borderColor: "#fbbf2440", background: "#fbbf2410" }}>{a.isp}</span>
                    <span className="mono chip !text-[10px]" dir="ltr">{a.cidr}</span>
                  </div>
                  <div className="mt-1.5 text-slate-400">هدف: <span className="mono text-cyan-300">{a.dstIp}</span> — {EVT_FA[a.type] ?? a.type} — {faDateTime(a.ts)}</div>
                </div>
              ))}
              {!data.attacks.length && <p className="py-10 text-center text-slate-500">حمله‌ای از رنج‌های ایرانی در نشست جاری ثبت نشده است</p>}
            </div>
          </div>
          <div className="glass fade-up fade-up-3 p-5">
            <Section icon={Globe2} title="حملات خارج از رنج ایران" sub="مقصد داخلی هرکدام مشخص شده" />
            <div className="scroll-thin max-h-[430px] space-y-2 overflow-auto">
              {data.nonIran.map((a) => (
                <div key={a.id} className="rounded-xl border border-slate-500/15 bg-slate-500/5 p-3 text-[11.5px]">
                  <div className="flex items-center gap-2">
                    <span className="mono font-bold text-slate-200">{a.srcIp}</span>
                    <span className="chip !text-[10px]" style={{ color: "#fb7185", borderColor: "#fb718540", background: "#fb718512" }}>خارجی (غیر ایرانی)</span>
                  </div>
                  <div className="mt-1.5 text-slate-400">هدف در داخل شبکه: <span className="mono text-cyan-300">{a.dstIp}</span> — {EVT_FA[a.type] ?? a.type} — {faDateTime(a.ts)}</div>
                </div>
              ))}
              {!data.nonIran.length && <p className="py-10 text-center text-slate-500">موردی نیست</p>}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
