"use client";

import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import {
  ArrowDownWideNarrow, ArrowUpNarrowWide, Activity, Gauge, ShieldAlert, Radar,
  ListFilter, Eye, Download, Flame, CircleAlert,
} from "lucide-react";
import { useSnap, type EvOut, type IpRow } from "@/lib/useEngine";
import { Spark, type LivePoint } from "@/components/charts";
import HCSpline from "@/components/HCChart";
import { PageHead, Section, Stat, Empty, Skeleton } from "@/components/ui";
import KindCharts from "@/components/KindCharts";
import { fmtRate, fmtInt, faTime, RANGE_KIND_FA } from "@/lib/format";

type Tab = "internal" | "external" | "all";

export default function Home() {
  const { snap, connected } = useSnap();
  const [hist, setHist] = useState<LivePoint[]>([]);
  const topsRef = useRef<[string, number][][]>([]);
  const [events, setEvents] = useState<EvOut[]>([]);
  const seenRef = useRef<Set<number>>(new Set());
  const [tab, setTab] = useState<Tab>("internal");
  const [query, setQuery] = useState("");

  useEffect(() => {
    if (!snap) return;
    setHist((h) => [...h, { t: snap.t, a: snap.tot.i, b: snap.tot.o }].slice(-320));
    topsRef.current = [...topsRef.current, snap.totTops].slice(-320);
    if (snap.events.length) {
      const fresh = snap.events.filter((e) => !seenRef.current.has(e.id));
      fresh.forEach((e) => seenRef.current.add(e.id));
      if (fresh.length) setEvents((ev) => [...fresh.reverse(), ...ev].slice(0, 10));
    }
  }, [snap]);

  if (!snap || !connected) {
    return (
      <div className="space-y-5">
        <div className="shimmer h-24" />
        <div className="grid grid-cols-2 gap-4 lg:grid-cols-5">{[...Array(5)].map((_, i) => <Skeleton key={i} h={110} />)}</div>
        <Skeleton h={280} />
        <p className="text-center text-[12.5px] text-slate-500">در حال برقراری اتصال زنده با موتور پایش…</p>
      </div>
    );
  }

  const rangeColor = new Map(snap.ranges.map((r) => [r.id, r.color]));
  const rangeName = new Map(snap.ranges.map((r) => [r.id, r.name]));
  const rows = (tab === "internal" ? snap.internal : tab === "external" ? snap.external : snap.all).filter(
    (r) => !query || r.ip.includes(query) || r.host.includes(query),
  );

  const extra = (i: number) => {
    const tops = topsRef.current[i];
    if (!tops || !tops.length) return "";
    return `<div style="font-size:10px;color:#94a3b8;margin-bottom:3px">پرمصرف‌ترین IPها در این لحظه:</div>` + tops
      .map(
        ([ip, rate]) =>
          `<div style="display:flex;justify-content:space-between;gap:16px"><span style="direction:ltr;color:#67e8f9">${ip}</span><b style="direction:ltr;color:#e6ecf7">${fmtRate(rate)}</b></div>`,
      )
      .join("");
  };

  return (
    <div className="space-y-6">
      <PageHead
        title="داشبورد مدیریت شبکه"
        sub="پایش زنده و بدون رفرش جریان ترافیک تمام رنج‌های شبکه — هر تیک ۲ ثانیه از طریق اتصال WebSocket/SSE به‌روزرسانی می‌شود. روی نمودارها نگه دارید تا مصرف‌کننده هر نقطه را ببینید."
        chips={
          <>
            <span className="chip"><Radar size={12} /> رصد {snap.ranges.length} رنج</span>
            <span className="chip"><Activity size={12} /> {fmtInt(snap.tot.active)} IP فعال</span>
            <a className="chip hover:border-cyan-400/40 hover:text-cyan-300" href="/api/export?type=ips"><Download size={12} /> خروجی CSV مصرف</a>
          </>
        }
      />

      {/* KPI */}
      <div className="fade-up grid grid-cols-2 gap-4 md:grid-cols-3 xl:grid-cols-5">
        <Stat icon={ArrowDownWideNarrow} label="نرخ دریافت کل شبکه — زنده" value={fmtRate(snap.tot.i)} color="#22d3ee" sub={`${fmtInt(snap.all.length)} آدرس تحت رصد`} />
        <Stat icon={ArrowUpNarrowWide} label="نرخ ارسال کل شبکه — زنده" value={fmtRate(snap.tot.o)} color="#a78bfa" sub="تجمیع لحظه‌ای همه رنج‌ها" />
        <Stat icon={Gauge} label="نشست‌های هم‌زمان" value={fmtInt(snap.tot.s)} color="#34d399" sub="TCP/UDP برقرار" />
        <Stat icon={ShieldAlert} label="IPهای مشکوک" value={fmtInt(snap.susp.length)} color="#fb7185" href="/security" sub="بدون الگوی نشست نرمال" />
        <Stat icon={Flame} label="رخداد امنیتی امروز" value={fmtInt(snap.sec.today)} color="#fbbf24" href="/security" sub={`${fmtInt(snap.sec.blocked)} مورد مسدود شد`} />
      </div>

      {/* نمودار کل شبکه */}
      <div className="glass fade-up fade-up-1 p-5">
        <Section
          icon={Activity}
          title="جریان ترافیک کل شبکه — زنده"
          sub="ماوس را روی نقاط نمودار نگه دارید تا IPهای پرمصرف همان لحظه نمایش داده شود"
          action={
            <div className="flex items-center gap-3 text-[11px] text-slate-400">
              <span className="flex items-center gap-1.5"><i className="h-2 w-2 rounded-full bg-cyan-400" /> دریافت</span>
              <span className="flex items-center gap-1.5"><i className="h-2 w-2 rounded-full bg-violet-400" /> ارسال</span>
            </div>
          }
        />
        <HCSpline
          series={[
            { name: "دریافت", color: "#22d3ee", data: hist.map((p) => [p.t, p.a]) },
            { name: "ارسال", color: "#a78bfa", data: hist.map((p) => [p.t, p.b ?? 0]) },
          ]}
          height={240}
          tooltipExtra={extra}
        />
      </div>

      {/* کارت رنج‌ها */}
      <div>
        <Section icon={NetworkIcon} title="نمودار زنده هر رنج — تفکیک‌شده" sub="کلیک روی هر رنج: جدول IPها، تحلیل آماری و آدرس‌های خالی" />
        <div className="fade-up fade-up-2 grid gap-4 md:grid-cols-2 xl:grid-cols-3">
          {snap.ranges.map((r) => (
            <Link key={r.id} href={`/ranges/${r.id}`} className="glass glass-hover block p-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <i className="h-3 w-3 rounded-full" style={{ background: r.color, boxShadow: `0 0 12px ${r.color}` }} />
                  <div>
                    <div className="text-[13.5px] font-bold text-slate-100">{r.name}</div>
                    <div className="mono text-[10.5px] text-slate-500">{r.cidr}</div>
                  </div>
                </div>
                <span className="chip">{RANGE_KIND_FA[r.kind] ?? r.kind}</span>
              </div>
              <div className="mt-3 flex items-end justify-between gap-3" dir="ltr">
                <Spark data={r.sparkSeries ?? []} color={r.color} w={150} h={44} />
                <div className="text-left">
                  <div className="mono text-[15px] font-bold" style={{ color: r.color }}>{fmtRate(r.i + r.o)}</div>
                  <div className="mt-0.5 text-left text-[10px] text-slate-500">مجموع لحظه‌ای</div>
                </div>
              </div>
              <div className="mt-3 flex items-center justify-between border-t border-slate-500/10 pt-3 text-[11px] text-slate-400">
                <span>{r.active} فعال از {r.used} آدرس</span>
                {r.susp > 0 && (
                  <span className="flex items-center gap-1 text-rose-300"><CircleAlert size={12} /> {r.susp} مشکوک</span>
                )}
              </div>
            </Link>
          ))}
        </div>
      </div>

      {/* پایش تفکیک‌شده تجهیزات/سرورها */}
      <KindCharts />

      {/* جدول IPها + پنل‌های کناری */}
      <div className="grid gap-4 xl:grid-cols-3">
        <div className="glass fade-up fade-up-3 p-5 xl:col-span-2">
          <Section
            icon={ListFilter}
            title="رصد آدرس‌های IP"
            sub="داخل شبکه / خارج شبکه / نمای کلی — به‌روزرسانی خودکار"
            action={
              <div className="flex items-center gap-2">
                <input className="input !w-44 !py-1.5 !text-[11.5px]" placeholder="جستجوی IP یا نام…" value={query} onChange={(e) => setQuery(e.target.value)} />
                <div className="flex gap-1 rounded-xl border border-slate-500/15 p-1">
                  {([["internal", "داخل شبکه"], ["external", "خارج شبکه"], ["all", "نمای کلی"]] as [Tab, string][]).map(([k, l]) => (
                    <button key={k} className={`tab-btn !px-3 !py-1 !text-[11.5px] ${tab === k ? "active" : ""}`} onClick={() => setTab(k)}>{l}</button>
                  ))}
                </div>
              </div>
            }
          />
          <div className="scroll-thin max-h-[430px] overflow-auto">
            <table className="table-base">
              <thead>
                <tr>
                  <th>IP</th><th>میزبان</th><th>رنج</th><th>لحظه‌ای</th><th>دریافت</th><th>ارسال</th><th>نشست</th><th>وضعیت</th>
                </tr>
              </thead>
              <tbody>
                {rows.map((r) => (
                  <IpLine key={r.ip} r={r} color={rangeColor.get(r.rangeId ?? -1)} name={rangeName.get(r.rangeId ?? -1)} />
                ))}
                {!rows.length && (
                  <tr><td colSpan={8} className="py-8 text-center text-slate-500">موردی مطابق جستجو یافت نشد</td></tr>
                )}
              </tbody>
            </table>
          </div>
        </div>

        <div className="space-y-4">
          {/* مشکوک‌ها */}
          <div className="glass fade-up fade-up-3 p-5">
            <Section icon={ShieldAlert} title="آی‌پی‌های مشکوک — پهنای باند زنده" sub="نشست نرمال ندارند یا الگوی غیرعادی" action={<Link className="chip hover:text-rose-300" href="/security"><Eye size={11} /> مرکز امنیت</Link>} />
            <div className="space-y-3">
              {snap.susp.slice(0, 5).map((s) => (
                <Link key={s.ip} href={`/ip/${s.ip}`} className="block rounded-xl border border-rose-400/15 bg-rose-400/5 p-3 transition-colors hover:border-rose-400/40">
                  <div className="flex items-center justify-between text-[12px]">
                    <span className="mono font-bold text-rose-200">{s.ip}</span>
                    <span className="chip !text-[10px]" style={{ color: "#fb7185", borderColor: "#fb718540", background: "#fb718510" }}>ریسک {s.score}</span>
                  </div>
                  <div className="mt-1 text-[10.5px] leading-4 text-slate-400">{s.reason}</div>
                  <div className="mt-2 flex items-center justify-between" dir="ltr">
                    <Spark data={s.spark} color="#fb7185" w={110} h={26} />
                    <span className="mono text-[11.5px] font-bold text-rose-200">{fmtRate(s.i + s.o)}</span>
                  </div>
                </Link>
              ))}
              {!snap.susp.length && <Empty text="در حال حاضر رفتار مشکوکی شناسایی نشده است" />}
            </div>
          </div>

          {/* رخدادها */}
          <div className="glass fade-up fade-up-4 p-5">
            <Section icon={Flame} title="آخرین رخدادهای امنیتی" sub="زمان و مقصد دقیق هر تلاش" />
            <div className="space-y-2.5">
              {events.map((e) => (
                <div key={e.id} className="flex items-start gap-2.5 rounded-lg border border-slate-500/10 bg-slate-500/5 p-2.5 text-[11px]">
                  <Flame size={13} className="mt-0.5 flex-none text-amber-400" />
                  <div className="min-w-0">
                    <div className="flex flex-wrap items-center gap-x-2">
                      <span className="mono text-slate-200">{e.srcIp}</span>
                      <span className="text-slate-600">←</span>
                      <span className="mono text-rose-300">{e.dstIp}</span>
                    </div>
                    <div className="mt-0.5 text-slate-500">{faTime(e.ts)} — {e.action === "blocked" ? "مسدود شد" : "ثبت شد"}</div>
                  </div>
                </div>
              ))}
              {!events.length && <p className="py-4 text-center text-[11.5px] text-slate-500">هنوز رخدادی در این نشست ثبت نشده است</p>}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function IpLine({ r, color, name }: { r: IpRow; color?: string; name?: string }) {
  return (
    <tr>
      <td>
        <Link href={`/ip/${r.ip}`} className="mono font-semibold text-cyan-300 hover:text-cyan-100 hover:underline">{r.ip}</Link>
      </td>
      <td className="max-w-[160px] truncate text-slate-300">{r.host}</td>
      <td>
        {name ? (
          <span className="chip !text-[10px]" style={{ color, borderColor: `${color}44`, background: `${color}12` }}>{name}</span>
        ) : (
          <span className="chip !text-[10px]" style={{ color: "#fbbf24", borderColor: "#fbbf2440", background: "#fbbf2410" }}>برون‌مرزی</span>
        )}
      </td>
      <td dir="ltr"><Spark data={r.spark} color={r.susp ? "#fb7185" : "#22d3ee"} w={90} h={24} /></td>
      <td className="mono text-cyan-200">{fmtRate(r.i)}</td>
      <td className="mono text-violet-300">{fmtRate(r.o)}</td>
      <td className="mono text-slate-300">{r.s}</td>
      <td>
        {r.susp ? (
          <span className="chip !text-[10px]" style={{ color: "#fb7185", borderColor: "#fb718540", background: "#fb718512" }}>مشکوک</span>
        ) : (
          <span className="chip !text-[10px]" style={{ color: "#34d399", borderColor: "#34d39940", background: "#34d39910" }}>نرمال</span>
        )}
      </td>
    </tr>
  );
}

import { Network as NetworkIcon } from "lucide-react";
