"use client";

import { useState } from "react";
import { Mail, Search, ShieldCheck, ShieldAlert, AlertOctagon, WifiOff } from "lucide-react";
import { useSnap } from "@/lib/useEngine";
import { PageHead, Section, SevBadge } from "@/components/ui";
import { EVT_FA, faDateTime, fmtInt } from "@/lib/format";

type Res = {
  ok: boolean; online: boolean; ip: string; type: string;
  results: { list: string; status: string }[];
  verdict: string; listedCount: number; mxRecord: string; mxOk: boolean; summary: string;
  attacks: { id: number; ts: number; srcIp: string; dstIp: string; type: string; severity: string; detail: string }[];
};
const TYPE_FA: Record<string, string> = { exchange: "Microsoft Exchange", postfix: "Postfix / Linux", mdaemon: "MDaemon", kerio: "Kerio Connect", hmail: "hMailServer", zimbra: "Zimbra", other: "سایر" };

export default function MailPage() {
  const { snap } = useSnap();
  const [ip, setIp] = useState("172.16.8.10");
  const [type, setType] = useState("postfix");
  const [res, setRes] = useState<Res | null>(null);
  const [busy, setBusy] = useState(false);

  const check = async () => {
    setBusy(true);
    const r: Res = await (await fetch("/api/mail", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ ip, type }) })).json();
    setRes(r);
    setBusy(false);
  };

  const verdict = res ? (res.verdict === "clean" ? { label: "سالم — اسپم نیست", c: "#34d399", icon: ShieldCheck } : res.verdict === "suspect" ? { label: "مشکوک — در یک لیست", c: "#fbbf24", icon: ShieldAlert } : { label: "اسپم / لیست‌شده", c: "#fb7185", icon: AlertOctagon }) : null;

  return (
    <div className="space-y-6">
      <PageHead
        title="پایش ایمیل‌سرور"
        sub="IP ایمیل‌سرور و نوع سیستم ایمیل را وارد کنید — بررسی لیست‌های سیاه (RBL)، وضعیت اسپم/بلاک و حملات ثبت‌شده روی این سرور"
        chips={snap?.net && <span className="chip" style={snap.net.online ? { color: "#34d399" } : { color: "#fb7185" }}>{snap.net.online ? "آنلاین" : "آفلاین"}</span>}
      />

      {snap && !snap.net.online && (
        <div className="glass fade-up flex items-center gap-3 border-r-4 border-amber-400/60 p-4 text-[12.5px] text-amber-200">
          <WifiOff size={17} /> برای استعلام زنده RBL باید اینترنت وصل باشد — در حالت آفلاین نتایج «نامشخص» گزارش می‌شود.
        </div>
      )}

      <div className="glass fade-up p-5">
        <Section icon={Mail} title="استعلام وضعیت ایمیل‌سرور" />
        <div className="flex flex-wrap items-end gap-3">
          <div>
            <label className="mb-1.5 block text-[11px] text-slate-500">IP ایمیل‌سرور</label>
            <input className="input mono !w-60" dir="ltr" value={ip} onChange={(e) => setIp(e.target.value)} onKeyDown={(e) => e.key === "Enter" && check()} placeholder="172.16.8.10" />
          </div>
          <div>
            <label className="mb-1.5 block text-[11px] text-slate-500">نوع سیستم ایمیل</label>
            <select className="input !w-56" value={type} onChange={(e) => setType(e.target.value)}>
              {Object.entries(TYPE_FA).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
            </select>
          </div>
          <button className="btn !py-2.5" onClick={check} disabled={busy}><Search size={15} /> {busy ? "در حال استعلام…" : "بررسی اسپم/بلاک"}</button>
        </div>
      </div>

      {res && verdict && (
        <div className="space-y-4">
          <div className={`glass fade-up flex flex-wrap items-center gap-4 border-r-4 p-5`} style={{ borderRightColor: verdict.c }}>
            <verdict.icon size={26} style={{ color: verdict.c }} />
            <div className="flex-1">
              <div className="text-[15px] font-extrabold" style={{ color: verdict.c }}>{verdict.label}</div>
              <div className="mt-1 text-[12px] leading-6 text-slate-300">{res.summary}</div>
              <div className="mt-1 text-[11px] text-slate-500">
                ایمیل‌سرور: <span className="mono text-slate-300">{res.ip}</span> — {TYPE_FA[res.type]} — رکورد MX: <span className="mono" dir="ltr">{res.mxRecord}</span> {res.mxOk ? "(سالم)" : "(نیازمند بررسی)"}
              </div>
            </div>
            <div className="text-center">
              <div className="text-[26px] font-extrabold" style={{ color: verdict.c }} dir="ltr">{res.listedCount}/{res.results.length}</div>
              <div className="text-[10px] text-slate-500">لیست سیاه فعال</div>
            </div>
          </div>

          <div className="grid gap-4 xl:grid-cols-2">
            <div className="glass fade-up fade-up-1 p-5">
              <Section icon={ShieldAlert} title="نتایج استعلام RBL" sub="لیست‌های سیاه شناخته‌شده جهانی" />
              <div className="space-y-2">
                {res.results.map((r) => (
                  <div key={r.list} className="flex items-center justify-between rounded-xl border border-slate-500/15 bg-slate-500/5 px-3.5 py-2.5">
                    <span className="mono text-[12px] text-slate-200" dir="ltr">{r.list}</span>
                    {r.status === "clean" ? (
                      <span className="chip !text-[10px]" style={{ color: "#34d399", borderColor: "#34d39940", background: "#34d39910" }}>سالم (Not Listed)</span>
                    ) : r.status === "listed" ? (
                      <span className="chip !text-[10px]" style={{ color: "#fb7185", borderColor: "#fb718540", background: "#fb718512" }}>لیست‌شده!</span>
                    ) : (
                      <span className="chip !text-[10px]">نامشخص (آفلاین)</span>
                    )}
                  </div>
                ))}
              </div>
            </div>
            <div className="glass fade-up fade-up-2 p-5">
              <Section icon={AlertOctagon} title="حملات ثبت‌شده روی این ایمیل‌سرور" sub={`${fmtInt(res.attacks.length)} مورد در نشست جاری پایش`} />
              <div className="scroll-thin max-h-[300px] space-y-2 overflow-auto">
                {res.attacks.map((a) => (
                  <div key={a.id} className="rounded-xl border border-rose-400/15 bg-rose-400/5 p-3 text-[11.5px]">
                    <div className="flex items-center justify-between">
                      <span className="mono font-bold text-rose-200">{a.srcIp}</span>
                      <SevBadge sev={a.severity} />
                    </div>
                    <div className="mt-1 text-slate-400">{EVT_FA[a.type] ?? a.type} — {faDateTime(a.ts)}</div>
                  </div>
                ))}
                {!res.attacks.length && <p className="py-8 text-center text-slate-500">حمله‌ای روی این سرور در نشست جاری دیده نشده است</p>}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
