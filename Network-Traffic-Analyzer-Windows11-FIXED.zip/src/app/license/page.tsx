"use client";

import { useEffect, useState } from "react";
import {
  KeyRound, ShieldCheck, ShieldAlert, Timer, Download, RefreshCcw, Trash2, Copy, Check,
  Wifi, WifiOff, Building2, User, Phone, FileKey2, Info,
} from "lucide-react";
import { usePoll, useSnap } from "@/lib/useEngine";
import { PageHead, Section, Skeleton, Stat } from "@/components/ui";
import { faDateTime, faDate, fmtInt } from "@/lib/format";

type LicResp = {
  ok: boolean;
  lic: {
    state: string; daysLeft: number; syncDue: boolean; overdueDays: number; writable: boolean;
    licName: string; org: string; edition: string; years: number; appId: string; file: string;
    lastSync: number; issuedAt: number; validUntil: number; mobile: string; firstName: string; lastName: string;
  };
  appId: string;
  net: { online: boolean; ping: number; mode: string };
};

const STATE_FA: Record<string, { label: string; c: string }> = {
  none: { label: "بدون لایسنس", c: "#94a3b8" },
  issued: { label: "صادر شده — در انتظار همگام‌سازی", c: "#fbbf24" },
  active: { label: "فعال و معتبر", c: "#34d399" },
  expired: { label: "منقضی‌شده", c: "#fb7185" },
  locked: { label: "قفل — همگام‌سازی انجام نشده", c: "#fb7185" },
};
const EDITION_FA: Record<string, string> = { standard: "استاندارد", pro: "پیشرفته (Pro)", enterprise: "سازمانی (Enterprise)" };

function Countdown({ until }: { until: number }) {
  const [now, setNow] = useState(() => Date.now());
  useEffect(() => {
    const iv = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(iv);
  }, []);
  if (!until) return null;
  const ms = Math.max(0, until - now);
  const d = Math.floor(ms / 86_400_000);
  const h = Math.floor(ms / 3_600_000) % 24;
  const m = Math.floor(ms / 60_000) % 60;
  const s = Math.floor(ms / 1000) % 60;
  return (
    <div dir="ltr" className="grid grid-cols-4 gap-2">
      {([[d, "روز"], [h, "ساعت"], [m, "دقیقه"], [s, "ثانیه"]] as [number, string][]).map(([v, l]) => (
        <div key={l} className="rounded-xl border border-cyan-400/20 bg-cyan-400/5 p-2.5 text-center">
          <div className="mono text-[20px] font-extrabold leading-6 text-cyan-200">{String(v).padStart(2, "0")}</div>
          <div className="mt-0.5 text-[9.5px] text-slate-500">{l}</div>
        </div>
      ))}
    </div>
  );
}

export default function LicensePage() {
  const { snap } = useSnap();
  const { data, reload } = usePoll<LicResp>(async () => (await fetch("/api/license")).json(), 6000, []);
  const [form, setForm] = useState({ firstName: "", lastName: "", mobile: "", org: "", licName: "", edition: "pro", years: 1 });
  const [busy, setBusy] = useState("");
  const [msg, setMsg] = useState<{ t: "ok" | "err"; s: string } | null>(null);
  const [issuedFile, setIssuedFile] = useState("");
  const [copied, setCopied] = useState(false);

  if (!data) return <div className="space-y-4"><Skeleton h={90} /><Skeleton h={260} /></div>;

  const lic = data.lic;
  const st = STATE_FA[lic.state] ?? STATE_FA.none;
  const syncPath = `https://giftmax.ir/lic/${lic.file || form.org ? (lic.file || "hdmax.slf") : "hdmax.slf"}`;

  const gen = async () => {
    setBusy("gen");
    setMsg(null);
    const res = await (await fetch("/api/license", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ op: "generate", ...form }) })).json();
    setBusy("");
    if (res.ok) {
      setIssuedFile(res.file);
      setMsg({ t: "ok", s: `لایسنس با موفقیت صادر و در بخش بارگذاری قرار گرفت — فایل ${res.file} آماده دانلود است` });
      reload();
    } else setMsg({ t: "err", s: res.error ?? "خطا" });
  };

  const sync = async () => {
    setBusy("sync");
    setMsg(null);
    const res = await (await fetch("/api/license", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ op: "sync" }) })).json();
    setBusy("");
    setMsg({ t: res.ok ? "ok" : "err", s: res.msg });
    reload();
  };

  const del = async () => {
    if (!confirm("لایسنس حذف شود؟ دسترسی کامل فقط با لایسنس جدید برمی‌گردد.")) return;
    await fetch("/api/license", { method: "DELETE" });
    setIssuedFile("");
    setMsg({ t: "ok", s: "لایسنس حذف شد" });
    reload();
  };

  const copy = (txt: string) => {
    navigator.clipboard.writeText(txt).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 1200);
    });
  };

  return (
    <div className="space-y-6">
      <PageHead
        title="لایسنس HDMAX"
        sub="صدور لایسنس یکتا برای این نرم‌افزار (با شناسه یکتای سخت‌افزاری)، رمزنگاری‌شده با AES-256 و فایل .slf — سپس فایل را در مسیر رسمی giftmax.ir/lic قرار داده و همگام‌سازی می‌کنید"
        chips={
          <span className="chip" style={{ color: st.c, borderColor: `${st.c}55`, background: `${st.c}12` }}>
            {lic.state === "active" ? <ShieldCheck size={12} /> : <ShieldAlert size={12} />} {st.label}
          </span>
        }
      />

      {/* وضعیت اتصال */}
      <div className={`glass fade-up flex flex-wrap items-center gap-3 border-r-4 p-4`} style={{ borderRightColor: data.net.online ? "#34d399" : "#fb7185" }}>
        {data.net.online ? <Wifi size={18} className="text-emerald-400" /> : <WifiOff size={18} className="text-rose-400" />}
        <div className="text-[12.5px] text-slate-300">
          {data.net.online ? (
            <>سیستم <b className="text-emerald-300">آنلاین</b> است — پینگ 8.8.8.8: <span className="mono">{data.net.ping}ms</span> — همگام‌سازی لایسنس و دریافت هوش تهدید ممکن است.</>
          ) : (
            <>سیستم <b className="text-rose-300">آفلاین</b> است — برای اعتبارسنجی لایسنس باید به اینترنت (پینگ 8.8.8.8) وصل باشید. از «تنظیمات» حالت اتصال را تغییر دهید.</>
          )}
        </div>
        <span className="chip mr-auto mono !text-[10px]" dir="ltr">شناسه نرم‌افزار: {data.appId}</span>
      </div>

      {msg && (
        <div className={`glass fade-up border-r-4 p-4 text-[13px] ${msg.t === "ok" ? "border-emerald-400/60 text-emerald-200" : "border-rose-400/60 text-rose-200"}`}>{msg.s}</div>
      )}

      <div className="grid gap-4 xl:grid-cols-2">
        {/* وضعیت لایسنس فعلی */}
        <div className="glass fade-up fade-up-1 p-5">
          <Section icon={FileKey2} title="لایسنس فعلی" sub="مشخصات لایسنس غیرقابل ویرایش است — فقط با حذف، لایسنس جدید ساخته می‌شود" />
          {lic.state === "none" ? (
            <p className="py-8 text-center text-[12.5px] text-slate-500">هنوز لایسنسی صادر نشده — فرم صدور را کامل کنید</p>
          ) : (
            <div className="space-y-3">
              <div className="grid grid-cols-2 gap-2.5 text-[12px]">
                {[
                  ["نام لایسنس", lic.licName],
                  ["دارنده", `${lic.firstName} ${lic.lastName}`],
                  ["سازمان", lic.org],
                  ["نوع نسخه", EDITION_FA[lic.edition] ?? lic.edition],
                  ["اعتبار", `${lic.years} ساله`],
                  ["همراه", lic.mobile || "—"],
                  ["تاریخ صدور", lic.issuedAt ? faDate(lic.issuedAt) : "—"],
                  ["انقضا", lic.validUntil ? faDate(lic.validUntil) : "—"],
                  ["آخرین همگام‌سازی", lic.lastSync ? faDateTime(lic.lastSync) : "هرگز"],
                  ["فایل", lic.file],
                ].map(([k, v]) => (
                  <div key={k} className="rounded-xl border border-slate-500/15 bg-slate-500/5 p-2.5">
                    <div className="text-[10px] text-slate-500">{k}</div>
                    <div className="mono mt-0.5 truncate text-[12px] font-semibold text-slate-100" title={String(v)}>{v}</div>
                  </div>
                ))}
              </div>
              <div className="grid grid-cols-2 gap-3">
                <Stat icon={Timer} label="زمان باقی‌مانده اعتبار" value={lic.state === "expired" ? "پایان‌یافته" : `${fmtInt(lic.daysLeft)} روز`} color={lic.daysLeft <= 30 ? "#fbbf24" : "#34d399"} sub={lic.syncDue ? "نیاز به همگام‌سازی دوره‌ای" : "به‌روز"} />
                <Stat icon={ShieldCheck} label="وضعیت دسترسی" value={lic.writable ? "کامل" : "قفل (فقط مشاهده)"} color={lic.writable ? "#34d399" : "#fb7185"} sub={lic.writable ? "ایجاد/ویرایش/حذف فعال" : "فقط داشبورد و لاگ قابل مشاهده است"} />
              </div>
              {lic.validUntil > 0 && lic.state !== "expired" && (
                <div className="rounded-xl border border-slate-500/15 bg-black/20 p-3">
                  <div className="mb-2 text-center text-[10px] text-slate-500">شمارش معکوس لحظه‌ای تا پایان اعتبار</div>
                  <Countdown until={lic.validUntil} />
                </div>
              )}
              <div className="flex flex-wrap gap-1.5 text-[10px] text-slate-500">
                <span className="chip !text-[9.5px]">رمزنگاری AES-256-GCM</span>
                <span className="chip !text-[9.5px]">امضای HMAC-SHA256</span>
                <span className="chip !text-[9.5px]">قفل‌گذاری و مبهم‌سازی فایل (غیرقابل دیکد)</span>
              </div>
              <div className="flex flex-wrap gap-2 border-t border-slate-500/10 pt-4">
                {(issuedFile || lic.file) && (
                  <a className="btn" href={`/licmonitor/${issuedFile || lic.file}`} download={issuedFile || lic.file}>
                    <Download size={15} /> دانلود فایل {issuedFile || lic.file}
                  </a>
                )}
                <button className="btn" onClick={sync} disabled={busy === "sync" || !data.net.online} title={data.net.online ? "" : "نیاز به اتصال اینترنت"}>
                  <RefreshCcw size={15} className={busy === "sync" ? "animate-spin" : ""} /> {busy === "sync" ? "در حال همگام‌سازی…" : "همگام‌سازی و اعتبارسنجی"}
                </button>
                <button className="btn btn-danger" onClick={del}><Trash2 size={15} /> حذف لایسنس</button>
              </div>
              <div className="rounded-xl border border-cyan-400/20 bg-cyan-400/5 p-3 text-[11.5px] leading-6 text-cyan-100">
                <div className="mb-1 flex items-center gap-1.5 font-bold"><Info size={13} /> روند فعال‌سازی:</div>
                ۱) فایل <span className="mono" dir="ltr">{lic.file || "hdmax.slf"}</span> را دانلود و به مالک سامانه تحویل دهید تا در مسیر <button className="mono underline decoration-dotted" dir="ltr" onClick={() => copy(syncPath)}>{syncPath} {copied ? <Check size={11} className="inline text-emerald-300" /> : <Copy size={11} className="inline" />}</button> قرار دهد.
                ۲) سیستم را آنلاین کنید و «همگام‌سازی» را بزنید — اگر دو فایل کاملاً یکسان بودند، اعتبار فعال و لایسنس بنام دارنده ثبت می‌شود.
                ۳) هر ۳۰ تا ۴۵ روز یک بار به اینترنت وصل و همگام‌سازی کنید؛ در صورت فراموشی، زنگ هشدار بالای صفحه (گوشه چپ) نمایش و پس‌از مهلت، دسترسی به حالت «فقط مشاهده» تغییر می‌کند.
              </div>
            </div>
          )}
        </div>

        {/* فرم صدور */}
        <div className="glass fade-up fade-up-2 p-5">
          <Section icon={KeyRound} title="صدور لایسنس جدید" sub="شناسه نرم‌افزار به‌صورت خودکار داخل لایسنس ثبت می‌شود؛ هر نرم‌افزار فقط یک لایسنس فعال دارد" />
          <div className="mb-3 flex items-center justify-between rounded-xl border border-slate-500/15 bg-slate-500/5 px-3 py-2.5">
            <span className="text-[11px] text-slate-500">شناسه یکتای نرم‌افزار (Software ID)</span>
            <button className="mono flex items-center gap-1.5 text-[12px] font-bold text-cyan-300" dir="ltr" onClick={() => copy(data.appId)}>{data.appId} {copied ? <Check size={12} className="text-emerald-300" /> : <Copy size={12} />}</button>
          </div>
          <div className="grid gap-3 sm:grid-cols-2">
            <div className="relative"><User size={14} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500" /><input className="input !pr-9" placeholder="نام *" value={form.firstName} onChange={(e) => setForm({ ...form, firstName: e.target.value })} /></div>
            <div className="relative"><User size={14} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500" /><input className="input !pr-9" placeholder="نام خانوادگی *" value={form.lastName} onChange={(e) => setForm({ ...form, lastName: e.target.value })} /></div>
            <div className="relative"><Phone size={14} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500" /><input className="input mono !pr-9" dir="ltr" placeholder="شماره همراه 0912…" value={form.mobile} onChange={(e) => setForm({ ...form, mobile: e.target.value })} /></div>
            <div className="relative"><Building2 size={14} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500" /><input className="input !pr-9" placeholder="نام سازمان / شرکت *" value={form.org} onChange={(e) => setForm({ ...form, org: e.target.value })} /></div>
            <input className="input sm:col-span-2" placeholder="نام لایسنس (مثلاً لایسنس اصلی HDMAX)" value={form.licName} onChange={(e) => setForm({ ...form, licName: e.target.value })} />
            <div>
              <label className="mb-1.5 block text-[11px] text-slate-500">نوع نسخه</label>
              <select className="input" value={form.edition} onChange={(e) => setForm({ ...form, edition: e.target.value })}>
                <option value="standard">استاندارد</option>
                <option value="pro">پیشرفته (Pro)</option>
                <option value="enterprise">سازمانی (Enterprise)</option>
              </select>
            </div>
            <div>
              <label className="mb-1.5 block text-[11px] text-slate-500">مدت اعتبار (از زمان صدور)</label>
              <div className="flex gap-1.5">
                {[1, 2, 3].map((y) => (
                  <button key={y} type="button" onClick={() => setForm({ ...form, years: y })} className={`tab-btn flex-1 !border ${form.years === y ? "active" : "!border-slate-500/20"}`}>{y} ساله</button>
                ))}
              </div>
            </div>
          </div>
          <button className="btn mt-4 w-full !py-3" onClick={gen} disabled={busy === "gen" || (lic.state !== "none" && lic.state !== "expired")}>
            <KeyRound size={16} />
            {busy === "gen" ? "در حال رمزنگاری AES-256 و صدور…" : lic.state !== "none" && lic.state !== "expired" ? "لایسنس فعال موجود است — ابتدا حذف کنید" : "تولید لایسنس رمزنگاری‌شده (.slf)"}
          </button>
          {issuedFile && (
            <div className="mt-4 rounded-xl border border-emerald-400/30 bg-emerald-400/5 p-4 text-center">
              <ShieldCheck size={22} className="mx-auto mb-2 text-emerald-300" />
              <p className="text-[12.5px] text-emerald-200">لایسنس صادر و به‌صورت خودکار در بخش بارگذاری قرار گرفت:</p>
              <a className="btn mt-3" href={`/licmonitor/${issuedFile}`} download={issuedFile}><Download size={15} /> دانلود {issuedFile}</a>
              <p className="mono mt-2 text-[10.5px] text-slate-500" dir="ltr">قراردهی در: https://giftmax.ir/lic/{issuedFile}</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
