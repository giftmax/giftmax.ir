"use client";

import { useMemo, useState } from "react";
import Link from "next/link";
import { FolderTree, Plus, Trash2, Pencil, Check, X, CornerDownLeft, ServerCrash } from "lucide-react";
import { usePoll } from "@/lib/useEngine";
import { PageHead, Section, Skeleton } from "@/components/ui";
import { fmtRate } from "@/lib/format";

type Node = { id: number; parentId: number | null; name: string; kind: string; ips: string };
type Live = Record<number, { status: "up" | "down" | "degraded"; rate: number; detail: { ip: string; online: boolean; rate: number }[] }>;
type Resp = { ok: boolean; nodes: Node[]; live: Live };
type TraceNode = { name: string; ip: string; lat: number; role: string };
type Trace = { ok: boolean; nodes: TraceNode[]; hops: number; totalLat: number };

const STATUS_META: Record<string, { label: string; c: string; cls: string }> = {
  up: { label: "آنلاین", c: "#34d399", cls: "live-dot" },
  degraded: { label: "ناقص (بخشی آفلاین)", c: "#fbbf24", cls: "live-dot" },
  down: { label: "آفلاین", c: "#fb7185", cls: "live-dot-red" },
};

export default function TreePage() {
  const { data, reload } = usePoll<Resp>(async () => (await fetch("/api/tree")).json(), 3000, []);
  const [sel, setSel] = useState<number | null>(null);
  const [addForm, setAddForm] = useState({ name: "", parentId: "", ips: "", kind: "branch" });
  const [showAdd, setShowAdd] = useState(false);
  const [renaming, setRenaming] = useState(false);
  const [renameVal, setRenameVal] = useState("");
  const [newIp, setNewIp] = useState("");
  const [trace, setTrace] = useState<{ ip: string; t: Trace } | null>(null);
  const [msg, setMsg] = useState("");

  const nodes = data?.nodes ?? [];
  const byParent = useMemo(() => {
    const m = new Map<number | null, Node[]>();
    nodes.forEach((n) => {
      const k = n.parentId ?? null;
      m.set(k, [...(m.get(k) ?? []), n]);
    });
    return m;
  }, [nodes]);
  const roots = byParent.get(null) ?? nodes.filter((n) => n.parentId === null || !nodes.some((x) => x.id === n.parentId));
  const selected = nodes.find((n) => n.id === sel) ?? null;
  const selIps: string[] = selected ? safeIps(selected.ips) : [];

  function safeIps(s: string): string[] {
    try { return JSON.parse(s) as string[]; } catch { return []; }
  }

  const loadTrace = async (ip: string) => {
    setTrace({ ip, t: { ok: true, nodes: [], hops: 0, totalLat: 0 } });
    const t: Trace = await (await fetch(`/api/trace?src=192.168.1.1&dst=${encodeURIComponent(ip)}`)).json();
    setTrace({ ip, t });
  };

  const addNode = async () => {
    const ips = addForm.ips.split(/[,\s]+/).filter(Boolean);
    const res = await (await fetch("/api/tree", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ name: addForm.name, parentId: addForm.parentId ? Number(addForm.parentId) : null, ips, kind: addForm.kind }) })).json();
    if (res.ok) { setAddForm({ name: "", parentId: "", ips: "", kind: "branch" }); setShowAdd(false); reload(); } else setMsg(res.error ?? "خطا");
  };
  const rename = async () => {
    if (!selected) return;
    await fetch("/api/tree", { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id: selected.id, name: renameVal }) });
    setRenaming(false);
    reload();
  };
  const addIp = async () => {
    if (!selected || !newIp) return;
    await fetch("/api/tree", { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id: selected.id, ips: [...selIps, newIp] }) });
    setNewIp("");
    reload();
  };
  const delIp = async (ip: string) => {
    if (!selected) return;
    await fetch("/api/tree", { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id: selected.id, ips: selIps.filter((x) => x !== ip) }) });
    reload();
  };
  const delNode = async () => {
    if (!selected || !confirm(`گره «${selected.name}» حذف شود؟`)) return;
    const res = await (await fetch(`/api/tree?id=${selected.id}`, { method: "DELETE" })).json();
    if (res.ok) setSel(null); else setMsg(res.error ?? "خطا");
    reload();
  };

  if (!data) return <div className="space-y-4"><Skeleton h={90} /><Skeleton h={300} /></div>;

  return (
    <div className="space-y-6">
      <PageHead
        title="درخت دامنه‌ها و سرورها"
        sub="ریشه = دامنه اصلی — زیرشاخه‌ها با نام دلخواه و IPهای متصل — وضعیت آنلاین/آفلاین به‌صورت انیمیشنی؛ روی گره آفلاین نگه دارید تا Traceroute بگوید دقیقاً کجای مسیر گیر کرده"
        chips={<button className="btn !py-2" onClick={() => setShowAdd(!showAdd)}><Plus size={15} /> افزودن شاخه/برگ</button>}
      />

      {msg && <div className="glass fade-up p-3 text-[12px] text-amber-300">{msg}</div>}

      {showAdd && (
        <div className="glass fade-up p-5">
          <Section icon={Plus} title="گره جدید در درخت" sub="نام زیردامنه/بخش + والد + IPهای متعلق" />
          <div className="grid gap-3 md:grid-cols-4">
            <input className="input mono" dir="ltr" placeholder="mail.corp.local" value={addForm.name} onChange={(e) => setAddForm({ ...addForm, name: e.target.value })} />
            <select className="input" value={addForm.parentId} onChange={(e) => setAddForm({ ...addForm, parentId: e.target.value })}>
              <option value="">ریشه (بدون والد)</option>
              {nodes.map((n) => <option key={n.id} value={n.id}>زیرمجموعه: {n.name}</option>)}
            </select>
            <input className="input mono" dir="ltr" placeholder="IPها با ویرگول: 10.10.0.10, 10.10.0.11" value={addForm.ips} onChange={(e) => setAddForm({ ...addForm, ips: e.target.value })} />
            <select className="input" value={addForm.kind} onChange={(e) => setAddForm({ ...addForm, kind: e.target.value })}>
              <option value="branch">شاخه (زیردرخت‌دار)</option>
              <option value="leaf">برگ (انتها)</option>
            </select>
          </div>
          <div className="mt-3 flex gap-2">
            <button className="btn" onClick={addNode}>افزودن به درخت</button>
            <button className="btn btn-ghost" onClick={() => setShowAdd(false)}>انصراف</button>
          </div>
        </div>
      )}

      <div className="grid gap-4 xl:grid-cols-3">
        {/* درخت */}
        <div className="glass fade-up fade-up-1 overflow-x-auto p-5 xl:col-span-2">
          <Section icon={FolderTree} title="ساختار درختی" sub="کلیک روی گره = انتخاب و ویرایش — نگه‌داشتن ماوس روی «آفلاین» = Traceroute" />
          <div className="min-w-[560px] space-y-1 py-2">
            {roots.map((n) => (
              <TreeNode key={n.id} node={n} byParent={byParent} live={data.live} sel={sel} setSel={setSel} loadTrace={loadTrace} depth={0} />
            ))}
          </div>
        </div>

        {/* کارت ویرایش / جزئیات */}
        <div className="space-y-4">
          {trace && (
            <div className="glass fade-up border-rose-400/25 p-4">
              <div className="mb-2 flex items-center justify-between">
                <div className="flex items-center gap-2 text-[13px] font-bold text-slate-100"><ServerCrash size={16} className="text-rose-300" /> Traceroute به {trace.ip}</div>
                <button className="rounded-lg p-1 text-slate-500 hover:text-slate-200" onClick={() => setTrace(null)}><X size={14} /></button>
              </div>
              {!trace.t.nodes.length ? (
                <div className="shimmer h-16" />
              ) : (
                <div className="space-y-1.5 text-[11px]">
                  {trace.t.nodes.map((n, i) => (
                    <div key={i} className="flex items-center justify-between rounded-lg border border-slate-500/10 bg-slate-500/5 px-2.5 py-1.5">
                      <span className="flex items-center gap-2"><b className="mono w-5 text-slate-600">{i || "S"}</b> <span className="text-slate-300">{n.name}</span></span>
                      <span className="mono text-slate-400">{n.ip}</span>
                      <b className="mono text-emerald-300" dir="ltr">{n.lat}ms</b>
                    </div>
                  ))}
                  <div className="rounded-lg border border-rose-400/30 bg-rose-400/10 px-2.5 py-2 text-rose-200">
                    ✕ TimeOut — درخواست به <span className="mono">{trace.ip}</span> پاسخ نمی‌دهد؛ گیر در همین مقصد/آخرین گذرگاه بالاست. کابل/سرویس/فایروال آن گره را بررسی کنید.
                  </div>
                </div>
              )}
            </div>
          )}

          <div className="glass fade-up fade-up-2 p-5">
            <Section icon={Pencil} title="جزئیات و ویرایش گره" sub={selected ? `انتخاب‌شده: ${selected.name}` : "یک گره از درخت انتخاب کنید"} />
            {!selected ? (
              <p className="py-8 text-center text-[12px] text-slate-500">روی یکی از گره‌های درخت کلیک کنید</p>
            ) : (
              <div className="space-y-3">
                <div className="flex items-center gap-2">
                  {renaming ? (
                    <>
                      <input className="input mono !py-1.5 !text-[12px]" dir="ltr" value={renameVal} onChange={(e) => setRenameVal(e.target.value)} />
                      <button className="rounded-lg p-2 text-emerald-300 hover:bg-emerald-500/10" onClick={rename}><Check size={15} /></button>
                      <button className="rounded-lg p-2 text-slate-400" onClick={() => setRenaming(false)}><X size={15} /></button>
                    </>
                  ) : (
                    <>
                      <span className="mono flex-1 text-[14px] font-bold text-slate-100" dir="ltr">{selected.name}</span>
                      <button className="rounded-lg p-2 text-slate-400 hover:bg-cyan-500/10 hover:text-cyan-300" onClick={() => { setRenaming(true); setRenameVal(selected.name); }}><Pencil size={14} /></button>
                      <button className="rounded-lg p-2 text-slate-400 hover:bg-rose-500/10 hover:text-rose-300" onClick={delNode}><Trash2 size={14} /></button>
                    </>
                  )}
                </div>
                <div>
                  <div className="mb-1.5 text-[11px] text-slate-500">IPهای متصل به این گره ({selIps.length})</div>
                  <div className="flex flex-wrap gap-1.5">
                    {selIps.map((ip) => (
                      <span key={ip} className="chip mono !text-[10.5px] hover:!border-rose-400/40" dir="ltr">
                        <Link href={`/ip/${ip}`} className="text-cyan-300 hover:underline">{ip}</Link>
                        <button className="text-slate-500 hover:text-rose-300" onClick={() => delIp(ip)}><X size={11} /></button>
                      </span>
                    ))}
                  </div>
                  <div className="mt-2 flex gap-2">
                    <input className="input mono !py-1.5 !text-[11.5px]" dir="ltr" placeholder="افزودن IP…" value={newIp} onChange={(e) => setNewIp(e.target.value)} onKeyDown={(e) => e.key === "Enter" && addIp()} />
                    <button className="btn !py-1.5 !text-[11.5px]" onClick={addIp}><CornerDownLeft size={13} /> افزودن</button>
                  </div>
                </div>
                {data.live[selected.id] && (
                  <div className="rounded-xl border border-slate-500/15 bg-slate-500/5 p-3 text-[12px]">
                    <div className="flex items-center justify-between">
                      <span className="text-slate-400">وضعیت گره:</span>
                      <span className="chip" style={{ color: STATUS_META[data.live[selected.id].status].c, borderColor: `${STATUS_META[data.live[selected.id].status].c}44`, background: `${STATUS_META[data.live[selected.id].status].c}12` }}>
                        <i className={STATUS_META[data.live[selected.id].status].cls} /> {STATUS_META[data.live[selected.id].status].label}
                      </span>
                    </div>
                    <div className="mt-2 flex items-center justify-between">
                      <span className="text-slate-400">پهنای باند تجمیعی:</span>
                      <b className="mono text-cyan-200" dir="ltr">{fmtRate(data.live[selected.id].rate)}</b>
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

function TreeNode({
  node, byParent, live, sel, setSel, loadTrace, depth,
}: {
  node: Node; byParent: Map<number | null, Node[]>; live: Live; sel: number | null; setSel: (n: number) => void; loadTrace: (ip: string) => void; depth: number;
}) {
  const children = byParent.get(node.id) ?? [];
  const lv = live[node.id];
  const meta = STATUS_META[lv?.status ?? "up"];
  const ips: string[] = (() => { try { return JSON.parse(node.ips) as string[]; } catch { return []; } })();
  return (
    <div className={`${depth > 0 ? "mr-6 border-r border-slate-500/15 pr-4" : ""}`}>
      <button
        onClick={() => setSel(node.id)}
        className={`flex w-full items-center gap-3 rounded-xl border p-2.5 text-right transition-all ${sel === node.id ? "border-cyan-400/40 bg-cyan-400/10" : "border-transparent hover:border-slate-500/20 hover:bg-slate-500/5"}`}
      >
        <i className={`${meta.cls} flex-none`} style={meta.c === "#fbbf24" ? { background: "#fbbf24" } : {}} title={meta.label} />
        <span className="grid h-8 w-8 flex-none place-items-center rounded-lg border border-slate-500/20 bg-slate-500/5">
          <FolderTree size={14} className="text-slate-400" />
        </span>
        <span className="min-w-0 flex-1">
          <span className="mono block truncate text-[12.5px] font-bold text-slate-100" dir="ltr">{node.name}</span>
          <span className="mt-0.5 block text-[10px] text-slate-500">{node.kind === "root" ? "ریشه — دامنه اصلی" : node.kind === "leaf" ? "برگ" : "شاخه"} — {ips.length} IP — پهنای باند: <b className="mono text-slate-300" dir="ltr">{fmtRate(lv?.rate ?? 0)}</b></span>
        </span>
        {lv && lv.status !== "up" && (
          <span
            className="chip flex-none !text-[10px]"
            style={{ color: meta.c, borderColor: `${meta.c}44`, background: `${meta.c}12` }}
            onMouseEnter={() => { const off = lv.detail.find((d) => !d.online); if (off) loadTrace(off.ip); }}
          >
            {meta.label} — ماوس را نگه دارید
          </span>
        )}
      </button>
      {children.map((c) => (
        <TreeNode key={c.id} node={c} byParent={byParent} live={live} sel={sel} setSel={setSel} loadTrace={loadTrace} depth={depth + 1} />
      ))}
    </div>
  );
}
