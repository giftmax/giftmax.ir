"use client";

import { useState, type ReactNode } from "react";
import {
  BookOpen, Copy, Check, MonitorDown, Cog, Package, ShieldCheck, Wrench, Rocket, AlertCircle, FileBox,
} from "lucide-react";
import { PageHead, Section } from "@/components/ui";

function Code({ children, lang }: { children: string; lang?: string }) {
  const [ok, setOk] = useState(false);
  const copy = async () => {
    try {
      await navigator.clipboard.writeText(children);
      setOk(true);
      setTimeout(() => setOk(false), 1500);
    } catch { /* کپی دستی */ }
  };
  return (
    <div className="group relative overflow-hidden rounded-xl border border-slate-500/20 bg-black/50">
      <div className="flex items-center justify-between border-b border-slate-500/15 px-3 py-1.5">
        <span className="text-[10px] text-slate-500">{lang ?? "CMD / PowerShell"}</span>
        <button onClick={copy} className="flex items-center gap-1 text-[10.5px] text-slate-400 transition-colors hover:text-cyan-300">
          {ok ? <Check size={12} className="text-emerald-400" /> : <Copy size={12} />}
          {ok ? "کپی شد" : "کپی"}
        </button>
      </div>
      <pre className="mono overflow-x-auto p-3.5 text-[12px] leading-6 text-cyan-100" dir="ltr">{children}</pre>
    </div>
  );
}

function Step({ n, title, children }: { n: number; title: string; children: ReactNode }) {
  return (
    <div className="relative flex gap-4 pr-1">
      <div className="flex flex-none flex-col items-center">
        <span className="z-10 grid h-9 w-9 place-items-center rounded-full border border-cyan-400/50 bg-[#081120] text-[13px] font-extrabold text-cyan-300">{n}</span>
        <span className="mt-1 w-px flex-1 bg-gradient-to-b from-cyan-400/40 to-transparent" />
      </div>
      <div className="flex-1 space-y-3 pb-8">
        <h3 className="pt-1.5 text-[14px] font-bold text-slate-100">{title}</h3>
        <div className="space-y-3 text-[12.5px] leading-6.5 text-slate-300">{children}</div>
      </div>
    </div>
  );
}

function Note({ type, children }: { type: "info" | "warn"; children: ReactNode }) {
  return (
    <div className={`flex gap-2.5 rounded-xl border p-3.5 text-[12px] leading-6 ${type === "warn" ? "border-amber-400/25 bg-amber-400/5 text-amber-200" : "border-cyan-400/20 bg-cyan-400/5 text-cyan-100"}`}>
      {type === "warn" ? <AlertCircle size={16} className="mt-0.5 flex-none" /> : <ShieldCheck size={16} className="mt-0.5 flex-none" />}
      <div>{children}</div>
    </div>
  );
}

export default function GuidePage() {
  return (
    <div className="space-y-8">
      <PageHead
        title="راهنمای کامل نصب و راه‌اندازی روی ویندوز ۱۰"
        sub="این برنامه یک وب‌اپلیکیشن Node.js (Next.js) است که روی سیستم ویندوز شما اجرا می‌شود و با مرورگر باز می‌گردد — بدون نیاز به سرور ابری. سه روش اجرا: ۱) اجرای مستقیم، ۲) سرویس دائمی ویندوز، ۳) فایل EXE دسکتاپ."
      />

      <div className="glass fade-up border-r-4 border-emerald-400/60 p-4 text-[12.5px] leading-7 text-emerald-100">
        <b>سریع‌ترین راه (بدون تایپ دستور):</b> در پوشه پروژه پوشه‌ای به نام <span className="mono" dir="ltr">tools</span> هست — فقط با دابل‌کلیک اجرا کنید:
        <span className="mono mx-1 rounded bg-black/40 px-2 py-0.5" dir="ltr">tools\1-install.bat</span> (نصب کامل خودکار)، سپس
        <span className="mono mx-1 rounded bg-black/40 px-2 py-0.5" dir="ltr">tools\2-start.bat</span> (اجرا + باز شدن مرورگر) و برای اجرای دائمی
        <span className="mono mx-1 rounded bg-black/40 px-2 py-0.5" dir="ltr">tools\3-service.bat</span> (با راست‌کلیک Run as administrator).
        بعد از اجرا فقط آدرس <span className="mono" dir="ltr">http://localhost:3000</span> را در مرورگر باز کنید (admin / admin).
      </div>

      {/* روش ۱ */}
      <div className="glass fade-up p-6">
        <Section icon={MonitorDown} title="روش ۱ — اجرای مستقیم با Node.js (توصیه‌شده برای شروع)" sub="زمان تقریبی: ۱۰ دقیقه" />
        <div className="mt-2">
          <Step n={1} title="نصب Node.js نسخه LTS">
            <p>به سایت رسمی بروید و نسخه <b>LTS (20 یا 22)</b> ویندوز را دانلود و نصب کنید؛ هنگام نصب تیک «Add to PATH» فعال بماند:</p>
            <Code lang="آدرس دانلود">https://nodejs.org  →  دکمه سبز LTS  →  Windows Installer (.msi) 64-bit</Code>
            <Code lang="بررسی نصب در CMD">{`node -v\nnpm -v\n# باید چیزی شبیه v22.x.x نمایش داده شود`}</Code>
          </Step>
          <Step n={2} title="نصب PostgreSQL (اختیاری ولی توصیه‌شده)">
            <p>برای ذخیره دائمی نمودارهای ۲۴ساعت و ۳۰روز و لاگ امنیتی، PostgreSQL 16/17 را نصب کنید. رمز کاربر postgres را «postgres» گذاشته و پورت پیش‌فرض 5432 بماند:</p>
            <Code lang="آدرس دانلود">https://www.postgresql.org/download/windows/  →  EDB Installer</Code>
            <Code lang="ساخت دیتابیس (در CMD با مسیر psql)">{`"C:\\Program Files\\PostgreSQL\\17\\bin\\psql.exe" -U postgres -c "CREATE DATABASE app_db;"`}</Code>
            <Note type="info">اگر PostgreSQL نصب نکنید هم برنامه اجرا می‌شود، اما تاریخچه فقط در حافظه می‌ماند و با بستن برنامه پاک می‌شود.</Note>
          </Step>
          <Step n={3} title="کپی فایل‌های برنامه">
            <p>پوشه پروژه را در مسیر کوتاه و بدون فاصله کپی کنید، مثلاً <span className="mono" dir="ltr">C:\nadir\netwatch</span></p>
            <Code>{`mkdir C:\\nadir\\netwatch\n# محتویات پروژه را داخل این پوشه بریزید (شامل package.json و پوشه src)`}</Code>
          </Step>
          <Step n={4} title="ساخت فایل تنظیمات .env">
            <p>در ریشه پوشه پروژه فایلی به نام <span className="mono">.env</span> بسازید و این خط را داخل آن بنویسید:</p>
            <Code lang="فایل: C:\nadir\netwatch\.env">{`DATABASE_URL=postgresql://postgres:postgres@127.0.0.1:5432/app_db`}</Code>
          </Step>
          <Step n={5} title="نصب وابستگی‌ها (فقط بار اول)">
            <Code>{`cd C:\\nadir\\netwatch\nnpm install`}</Code>
          </Step>
          <Step n={6} title="ساخت نسخه نهایی (Build)">
            <Code>{`npm run build`}</Code>
            <Note type="info">در اولین اجرا، جداول دیتابیس به‌صورت خودکار ساخته و رنج‌ها و تاریخچه ۳۰روزه به‌صورت خودکار Seed می‌شوند.</Note>
          </Step>
          <Step n={7} title="اجرای برنامه">
            <Code>{`npm start\n# خروجی: ▲ Next.js Ready on http://localhost:3000`}</Code>
            <p>حالا مرورگر (Chrome/Edge) را باز کنید و به آدرس زیر بروید:</p>
            <Code lang="مرورگر">{`http://localhost:3000`}</Code>
            <p>برای مشاهده از کامپیوتر دیگر داخل شبکه همین سازمان، به‌جای localhost از آی‌پی سیستم خود استفاده کنید (مثلاً <span className="mono" dir="ltr">http://192.168.1.50:3000</span>) — فقط مرحله فایروال پایین صفحه را انجام دهید.</p>
          </Step>
        </div>
      </div>

      {/* روش ۲ */}
      <div className="glass fade-up fade-up-1 p-6">
        <Section icon={Cog} title="روش ۲ — اجرای دائمی به‌عنوان سرویس ویندوز (پیشنهاد برای اتاق سرور)" sub="با هر بار روشن‌شدن ویندوز، برنامه خودکار بالا می‌آید" />
        <div className="mt-2">
          <Step n={1} title="دانلود NSSM (مدیر سرویس رایگان)">
            <Code lang="آدرس دانلود">{`https://nssm.cc/download  →  nssm 2.24  →  استخراج در C:\\nadir\\nssm`}</Code>
          </Step>
          <Step n={2} title="ثبت سرویس">
            <Code lang="CMD با دسترسی Administrator">{`C:\\nadir\\nssm\\win64\\nssm.exe install NadirNetWatch "C:\\Program Files\\nodejs\\node.exe" "C:\\nadir\\netwatch\\node_modules\\next\\dist\\bin\\next" start\nC:\\nadir\\nssm\\win64\\nssm.exe set NadirNetWatch AppDirectory "C:\\nadir\\netwatch"\nC:\\nadir\\nssm\\win64\\nssm.exe start NadirNetWatch`}</Code>
          </Step>
          <Step n={3} title="بررسی و مدیریت سرویس">
            <Code>{`services.msc   →   NadirNetWatch   →   Startup type: Automatic\n# توقف/شروع:  nssm stop NadirNetWatch  /  nssm start NadirNetWatch`}</Code>
          </Step>
        </div>
      </div>

      {/* روش ۳ */}
      <div className="glass fade-up fade-up-2 p-6">
        <Section icon={FileBox} title="روش ۳ — ساخت فایل EXE دسکتاپ (Windows Desktop App)" sub="دو گزینه: الف) pkg برای EXE سروری بدون مرورگر، ب) Electron برای پنجره دسکتاپ شبیه اپ" />
        <div className="mt-2">
          <Step n={1} title="گزینه الف — EXE قابل‌حمل با pkg">
            <Code>{`npm i -g pkg\nnpm run build\npkg . --targets node20-win-x64 --output NadirNetWatch.exe\n# اجرا: دابل‌کلیک روی NadirNetWatch.exe سپس مرورگر → http://localhost:3000`}</Code>
          </Step>
          <Step n={2} title="گزینه ب — پنجره دسکتاپ با Electron">
            <Code lang="فایل desktop.js در ریشه پروژه">{`const { app, BrowserWindow } = require("electron");\nconst { spawn } = require("child_process");\nlet win;\napp.whenReady().then(() => {\n  spawn("npx", ["next", "start", "-p", "3000"], { cwd: __dirname, shell: true });\n  win = new BrowserWindow({ width: 1500, height: 940, autoHideMenuBar: true });\n  setTimeout(() => win.loadURL("http://localhost:3000"), 4000);\n});`}</Code>
            <Code>{`npm i -D electron electron-builder\nnpx electron desktop.js          # تست\nnpx electron-builder --win nsis  # خروجی نصبی: dist\\NadirNetWatch Setup.exe`}</Code>
          </Step>
          <Step n={3} title="میان‌بر روی دسکتاپ + اجرای خودکار با ویندوز">
            <Code lang="PowerShell">{`$ws = New-Object -ComObject WScript.Shell\n$s = $ws.CreateShortcut("$env:USERPROFILE\\Desktop\\Nadir NetWatch.lnk")\n$s.TargetPath = "http://localhost:3000"; $s.Save()\n# اجرای خودکار: shell:startup را اجرا و میان‌بر npm start را در آن بگذارید`}</Code>
          </Step>
        </div>
      </div>

      {/* فایروال و امنیت */}
      <div className="glass fade-up fade-up-3 p-6">
        <Section icon={ShieldCheck} title="باز کردن پورت در فایروال ویندوز + تنظیمات امنیتی" />
        <div className="grid gap-4 md:grid-cols-2">
          <div className="space-y-3">
            <p className="text-[12.5px] text-slate-300">۱) اگر می‌خواهید همکاران هم داشبورد را ببینند، پورت ۳۰۰۰ را باز کنید (CMD با دسترسی Administrator):</p>
            <Code>{`netsh advfirewall firewall add rule name="NadirNetWatch 3000" dir=in action=allow protocol=TCP localport=3000`}</Code>
            <Note type="warn">اگر فقط خودتان استفاده می‌کنید، پورت را باز نکنید؛ دسترسی محلی امن‌تر است. هدرهای امنیتی، Rate-Limit و اعتبارسنجی ورودی به‌صورت پیش‌فرض داخل برنامه فعال است.</Note>
          </div>
          <div className="space-y-3">
            <p className="text-[12.5px] text-slate-300">۲) تغییر پورت (مثلاً ۸۰۸۰):</p>
            <Code>{`npx next start -p 8080`}</Code>
            <p className="text-[12.5px] text-slate-300">۳) برای پایش <b>ترافیک واقعی</b> کارت شبکه (علاوه‌بر دیتاست توکار): درایور Npcap را نصب و روی سوئیچ شبکه، پورت مانیتور (SPAN/Mirror) فعال کنید — معماری برنامه برای اتصال SNMP واقعی و درایورهای کلکتور آماده است.</p>
            <Code lang="دانلود Npcap">{`https://npcap.com/#download`}</Code>
          </div>
        </div>
      </div>

      {/* عیب‌یابی */}
      <div className="glass fade-up fade-up-4 p-6">
        <Section icon={Wrench} title="عیب‌یابی سریع" />
        <div className="scroll-thin overflow-x-auto">
          <table className="table-base !text-[12px]">
            <thead><tr><th>خطا / علامت</th><th>علت</th><th>راه‌حل</th></tr></thead>
            <tbody>
              {[
                ["EADDRINUSE: port 3000", "پورت اشغال است", "برنامه دیگر را ببندید یا با ‎-p 8080 اجرا کنید"],
                ["دیتابیس متصل نیست (حالت حافظه‌ای)", "PostgreSQL خاموش/رمز اشتباه", "سرویس postgresql را start و رمز .env را چک کنید؛ برنامه همچنان کار می‌کند"],
                ["صفحه باز نمی‌شود", "Build انجام نشده", "npm run build سپس npm start"],
                ["node شناخته نمی‌شود", "PATH ست نشده", "Node.js را دوباره با تیک Add to PATH نصب کنید"],
                ["نمودارها توقف دارند", "قطع اتصال زنده", "نوار وضعیت بالای صفحه خودکار reconnect می‌کند؛ صفحه را رفرش کنید"],
              ].map((r) => (
                <tr key={r[0]}>
                  <td className="mono max-w-[220px] text-rose-300">{r[0]}</td>
                  <td className="text-slate-300">{r[1]}</td>
                  <td className="max-w-[360px] text-slate-400">{r[2]}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <Note type="info">
          <b>نکته:</b> هر سه روش از یک فایل پروژه استفاده می‌کنند؛ کافی است یک بار طبق روش ۱ اجرا کنید تا مطمئن شوید سالم است، بعد برای استفاده دائمی روش ۲ یا ۳ را فعال کنید. لاگ برنامه در همان پنجره CMD/سرویس قابل مشاهده است و سلامت سرویس از مسیر <span className="mono" dir="ltr">/api/health</span> پاسخ می‌دهد.
        </Note>
      </div>

      <div className="glass p-5 text-center">
        <Rocket size={20} className="mx-auto mb-2 text-cyan-300" />
        <p className="text-[12.5px] text-slate-300">پس از نصب، از منوی سمت راست: «محدوده‌های IP» → افزودن رنج‌های سازمان خود (تا ۱۰ رنج) — پایش بلافاصله آغاز می‌شود.</p>
        <p className="mt-2 text-[11px] text-slate-500 flex items-center justify-center gap-1.5"><Package size={12} /> نیازمندی‌ها: Windows 10 (64-bit) • Node.js ≥ 20 • 200MB فضای خالی • PostgreSQL (اختیاری)</p>
      </div>
      <BookOpen className="hidden" />
    </div>
  );
}
