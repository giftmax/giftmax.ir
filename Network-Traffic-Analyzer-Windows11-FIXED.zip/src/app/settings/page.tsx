"use client";

import { useEffect, useState } from "react";
import {
  Settings, Wifi, WifiOff, MonitorSmartphone, Users, Plus, Trash2, KeyRound, Save, UserCog, Globe,
} from "lucide-react";
import { usePoll, useSnap } from "@/lib/useEngine";
import { PageHead, Section, Skeleton, Toggle } from "@/components/ui";

type Me = { id: number; username: string; role: string; perms: string[] } | null;
type UsersResp = { ok: boolean; users: { id: number; username: string; role: string; perms: string[]; active: boolean }[]; tabs: { key: string; label: string }[] };

export default function SettingsPage() {
  const { snap } = useSnap();
  const [me, setMe] = useState<Me>(null);
  const { data: usersData, reload } = usePoll<UsersResp | null>(async () => {
    const r = await fetch("/api/auth/users");
    return r.ok ? await r.json() : null;
  }, 10000, []);
  const [modeMsg, setModeMsg] = useState("");
  const [pw, setPw] = useState({ old: "", next: "" });
  const [pwMsg, setPwMsg] = useState("");
  const [nu, setNu] = useState({ username: "", password: "", role: "operator", perms: [] as string[] });
  const [origin, setOrigin] = useState("");

  useEffect(() => {
    fetch("/api/auth").then(async (r) => { if (r.ok) setMe((await r.json()).user); });
    setOrigin(window.location.origin);
  }, []);

  const setMode = async (mode: string) => {
    const res = await (await fetch("/api/license", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ op: "mode", mode }) })).json();
    setModeMsg(res.ok ? (mode === "force-offline" ? "حالت آفلاین فعال شد — همه سرویس‌ها بدون اینترنت کار می‌کنند" : mode === "force-online" ? "اتصال به اینترنت فعال و تست پینگ 8.8.8.8 برقرار شد" : "حالت خودکار فعال شد") : "خطا");
  };

  const changePw = async () => {
    const res = await (await fetch("/api/auth", { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ oldPassword: pw.old, newPassword: pw.next }) })).json();
    setPwMsg(res.ok ? "رمز عبور با موفقیت تغییر کرد" : res.error ?? "خطا");
    if (res.ok) setPw({ old: "", next: "" });
  };

  const isAdmin = !!me && (me.role === "admin" || me.username === "admin");

  const addUser = async () => {
    const res = await (await fetch("/api/auth/users", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(nu) })).json();
    setPwMsg(res.ok ? `کاربر «${nu.username}» با دسترسی‌های تیک‌خور ساخته شد` : res.error ?? "خطا");
    if (res.ok) { setNu({ username: "", password: "", role: "operator", perms: [] }); reload(); }
  };
  const togglePerm = (p: string) => setNu((s) => ({ ...s, perms: s.perms.includes(p) ? s.perms.filter((x) => x !== p) : [...s.perms, p] }));
  const patchUser = async (id: number, patch: Record<string, unknown>) => {
    await fetch("/api/auth/users", { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id, ...patch }) });
    reload();
  };
  const delUser = async (id: number, username: string) => {
    if (!confirm(`کاربر «${username}» حذف شود؟`)) return;
    await fetch(`/api/auth/users?id=${id}&username=${encodeURIComponent(username)}`, { method: "DELETE" });
    reload();
  };

  const net = snap?.net;

  return (
    <div className="space-y-6">
      <PageHead title="تنظیمات و کاربران" sub="حالت اتصال اینترنت، دسترسی غیرمستقیم از کلاینت به سرور، تغییر رمز و مدیریت کاربران با دسترسی تیک‌خور" />

      <div className="grid gap-4 xl:grid-cols-2">
        {/* اتصال اینترنت */}
        <div className="glass fade-up p-5">
          <Section icon={net?.online ? Wifi : WifiOff} title="حالت اتصال سیستم (آنلاین/آفلاین)" sub="تست وصل‌بودن با پینگ 8.8.8.8 — انتخاب حالت با شماست" />
          <div className="mb-3 flex items-center gap-3">
            <span className="chip" style={net?.online ? { color: "#34d399" } : { color: "#fb7185" }}>
              {net?.online ? <Wifi size={12} /> : <WifiOff size={12} />}
              {net ? (net.online ? `وصل — ping: ${net.ping}ms` : "وصل نیست (آفلاین)") : "…"}
            </span>
          </div>
          <div className="flex flex-wrap gap-2">
            {([
              ["auto", "خودکار", "هر ۳۰ ثانیه پینگ 8.8.8.8 چک می‌شود"],
              ["force-online", "اتصال به اینترنت (آنلاین)", "هوش تهدید، رنج‌های ایران و همگام‌سازی لایسنس فعال"],
              ["force-offline", "بدون اینترنت (آفلاین)", "همه پایش‌ها محلی ادامه می‌یابد — لایسنس در حالت قفل دوره‌ای می‌ماند"],
            ] as const).map(([k, l, d]) => (
              <button key={k} onClick={() => setMode(k)} className={`tab-btn flex-1 !border !p-3 !text-right ${(net?.mode ?? "auto") === k ? "active" : "!border-slate-500/15"}`}>
                <div className="text-[12.5px] font-bold">{l}</div>
                <div className="mt-1 !text-[10px] font-normal leading-4 opacity-80">{d}</div>
              </button>
            ))}
          </div>
          {modeMsg && <p className="mt-3 text-[12px] text-emerald-300">{modeMsg}</p>}
        </div>

        {/* دسترسی از راه دور */}
        <div className="glass fade-up fade-up-1 p-5">
          <Section icon={MonitorSmartphone} title="دسترسی غیرمستقیم از کلاینت (Windows Server 2024)" sub="بدون نیاز به Node.js روی کلاینت — فقط مرورگر" />
          <div className="space-y-3 text-[12px] leading-6 text-slate-300">
            <p>۱) روی سرور ویندوز ۲۰۲۴، برنامه را روی همه کارت‌های شبکه اجرا کنید:</p>
            <p className="mono rounded-lg bg-black/40 p-2.5 text-[11px]" dir="ltr">npx next start -H 0.0.0.0 -p 3000</p>
            <p>۲) پورت را در فایروال سرور باز کنید:</p>
            <p className="mono rounded-lg bg-black/40 p-2.5 text-[11px]" dir="ltr">netsh advfirewall firewall add rule name="HDMAX 3000" dir=in action=allow protocol=TCP localport=3000</p>
            <p>۳) از هر کلاینت فقط آدرس سرور را در مرورگر بزنید:</p>
            <p className="mono rounded-lg bg-black/40 p-2.5 text-[11px]" dir="ltr">http://&lt;IP سرور&gt;:3000   →   مثلاً {origin || "http://192.168.1.10:3000"}</p>
            <p className="flex items-center gap-1.5 text-[11px] text-slate-500"><Globe size={12} /> آدرس فعلی شما: <span className="mono text-cyan-300" dir="ltr">{origin}</span></p>
          </div>
        </div>

        {/* تغییر رمز */}
        <div className="glass fade-up fade-up-2 p-5">
          <Section icon={KeyRound} title="تغییر رمز حساب من" sub={`کاربر فعلی: ${me?.username ?? "…"}`} />
          <div className="space-y-3">
            <input className="input" type="password" placeholder="رمز فعلی" value={pw.old} onChange={(e) => setPw({ ...pw, old: e.target.value })} autoComplete="current-password" />
            <input className="input" type="password" placeholder="رمز جدید (حداقل ۴ کاراکتر)" value={pw.next} onChange={(e) => setPw({ ...pw, next: e.target.value })} autoComplete="new-password" />
            <button className="btn" onClick={changePw}><Save size={14} /> ذخیره رمز جدید</button>
            {pwMsg && <p className="text-[12px] text-emerald-300">{pwMsg}</p>}
          </div>
        </div>

        {/* کاربران */}
        <div className="glass fade-up fade-up-3 p-5">
          <Section icon={Users} title="مدیریت کاربران" sub={isAdmin ? "تعریف کاربر جدید با دسترسی‌های تیک‌خور — admin همه بخش‌ها را می‌بیند" : "فقط مدیر (admin) به این بخش دسترسی دارد"} />
          {!isAdmin ? (
            <Skeleton h={80} />
          ) : !usersData ? (
            <Skeleton h={80} />
          ) : (
            <div className="space-y-4">
              <div className="scroll-thin max-h-56 space-y-2 overflow-auto">
                {usersData.users.map((u) => (
                  <div key={u.id} className="rounded-xl border border-slate-500/15 bg-slate-500/5 p-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <UserCog size={15} className="text-cyan-300" />
                        <b className="text-[13px] text-slate-100">{u.username}</b>
                        <span className="chip !text-[9.5px]">{u.role === "admin" ? "مدیر" : "اپراتور"}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-[10px] text-slate-500">فعال</span>
                        <Toggle on={u.active} onChange={() => patchUser(u.id, { active: !u.active })} />
                        {u.username !== "admin" && <button className="rounded-lg p-1.5 text-slate-500 hover:bg-rose-500/10 hover:text-rose-300" onClick={() => delUser(u.id, u.username)}><Trash2 size={14} /></button>}
                      </div>
                    </div>
                    <div className="mt-2 flex flex-wrap gap-1">
                      {u.role === "admin" ? (
                        <span className="chip !text-[9.5px] text-emerald-300">دسترسی کامل به همه تب‌ها</span>
                      ) : (
                        usersData.tabs.map((t) => (
                          <button key={t.key} onClick={() => patchUser(u.id, { perms: u.perms.includes(t.key) ? u.perms.filter((x) => x !== t.key) : [...u.perms, t.key] })} className={`chip !text-[9.5px] transition-all ${u.perms.includes(t.key) ? "!text-cyan-200 !border-cyan-400/50 !bg-cyan-400/10" : "opacity-50 hover:opacity-90"}`}>
                            {u.perms.includes(t.key) ? "✓ " : ""}{t.label}
                          </button>
                        ))
                      )}
                    </div>
                  </div>
                ))}
              </div>

              <div className="border-t border-slate-500/10 pt-4">
                <div className="mb-2.5 flex items-center gap-2 text-[12.5px] font-bold text-slate-100"><Plus size={15} className="text-cyan-300" /> کاربر جدید</div>
                <div className="grid gap-2.5 sm:grid-cols-2">
                  <input className="input" placeholder="نام کاربری" value={nu.username} onChange={(e) => setNu({ ...nu, username: e.target.value })} />
                  <input className="input" type="password" placeholder="رمز عبور" value={nu.password} onChange={(e) => setNu({ ...nu, password: e.target.value })} />
                </div>
                <div className="mt-2.5 flex items-center gap-2">
                  <button onClick={() => setNu({ ...nu, role: nu.role === "admin" ? "operator" : "admin" })} className={`tab-btn !border !text-[11px] ${nu.role === "admin" ? "active" : "!border-slate-500/20"}`}>
                    {nu.role === "admin" ? "مدیر (دسترسی کامل)" : "اپراتور (دسترسی تیک‌خور)"}
                  </button>
                  <span className="text-[10.5px] text-slate-500">در حالت اپراتور، تب‌های مجاز را تیک بزنید:</span>
                </div>
                {nu.role !== "admin" && (
                  <div className="mt-2 flex flex-wrap gap-1.5">
                    {usersData.tabs.map((t) => (
                      <button key={t.key} onClick={() => togglePerm(t.key)} className={`chip !text-[10px] transition-all ${nu.perms.includes(t.key) ? "!text-cyan-200 !border-cyan-400/50 !bg-cyan-400/10" : "opacity-60 hover:opacity-100"}`}>
                        {nu.perms.includes(t.key) ? "✓ " : ""}{t.label}
                      </button>
                    ))}
                  </div>
                )}
                <button className="btn mt-3" onClick={addUser}><Plus size={14} /> ایجاد کاربر</button>
              </div>
            </div>
          )}
        </div>
      </div>

      <div className="glass p-5">
        <div className="flex items-center gap-2 text-emerald-300"><Settings size={15} /><b className="text-[13px]">ریسپانسیو و سازگاری</b></div>
        <p className="mt-2 text-[11.5px] leading-6 text-slate-400">رابط کاربری برای مانیتورهای معمولی، واید و 4K بهینه‌سازی شده و روی تبلت و موبایل (منوی همبرگری بالای صفحه) نیز به‌درستی کار می‌کند — سازگار با Chrome، Edge، Firefox و Safari نسخه‌های جدید.</p>
      </div>
    </div>
  );
}
