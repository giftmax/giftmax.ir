import { ensureEngine } from "@/lib/engine";
import { rateLimit } from "@/lib/guard";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

// دانلود فایل لایسنس .slf — معادل محلی مسیر رسمی https://giftmax.ir/lic/<file>
export async function GET(req: Request, ctx: { params: Promise<{ file: string }> }) {
  const rl = rateLimit(req, "licmonitor", 20, 10_000);
  if (rl) return rl;
  const { file } = await ctx.params;
  const f = decodeURIComponent(file);
  if (!/^[\w\-.]{1,64}\.slf$/.test(f)) return new Response("نام فایل نامعتبر است", { status: 400 });
  const eng = await ensureEngine();
  if (eng.licRow && eng.licRow.file === f) {
    return new Response(eng.licRow.content, {
      headers: {
        "Content-Type": "application/octet-stream; charset=utf-8",
        "Content-Disposition": `attachment; filename="${f}"`,
        "Cache-Control": "no-store",
      },
    });
  }
  return new Response("لایسنسی با این نام ثبت نشده است", { status: 404 });
}
