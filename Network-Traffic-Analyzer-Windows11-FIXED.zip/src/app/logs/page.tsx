"use client";

import { Suspense, useEffect, useState } from "react";
import Link from "next/link";
import { useSearchParams } from "next/navigation";
import {
  FileText, FolderCog, Search, Eye, Trash2, CalendarDays, Save, Eraser, FileSearch, Activity, HardDrive, ListChecks, Plus, Power,
} from "lucide-react";
import { usePoll } from "@/lib/useEngine";
import { PageHead, Section, Skeleton, Empty } from "@/components/ui";
import { faDateTime, faTime, fmtBytes, fmtInt } from "@/lib/format";

type LogEntry = {
  ts: number; cat: string; level: string;
  ip?: string; peer?: string; msg: string;
  meta?: Record<string, unknown>;
};
type FileInfo = { name: string; date: string; faDate: string; size: number; mtime: number };
type LogsResp = {
  ok: boolean;
  settings: { dir: string; retentionDays: number; lastPurgeAt: number };
  files: FileInfo[];
  stats: { count: number; totalSize: number; oldest: FileInfo | null; newest: FileInfo | null };
};
type FileResp = { ok: boolean; name: string; faDate: string; dir: string; entries: LogEntry[]; total: number; matched: number; truncated: boolean; error?: string };
type SearchResp = { ok: boolean; ip: string; days: number; totalHits: number; dir: string; byDay: { date: string; faDate: string; name: string; entries: LogEntry[] }[] };

const CAT_META: Record<string, { label: string; color: string }> = {
  traffic: { label: "ترافیک", color: "#22d3ee" },
  security: { label: "امنیتی", color: "#fb7185" },
  device: { label: "تجهیز", color: "#fbbf24" },
  system: { label: "سیستم", color: "#34d399" },
  syslog: { label: "Syslog", color: "#c084fc" },
};
const LEVEL_META: Record<string, { label: string; color: string }> = {
  info: { label: "اطلاع", color: "#94a3b8" },
  low: { label: "کم", color: "#34d399" },
  medium: { label: "متوسط", color: "#fbbf24" },
  high: { label: "شدید", color: "#fb923c" },
  critical: { label: "بحرانی", color: "#fb7185" },
};

function MetaChip({ e }: { e: LogEntry }) {
  const m = e.meta ?? {};
  const parts: string[] = [];
  if (typeof m.bytesIn === "number") parts.push(`↓ ${fmtBytes(m.bytesIn)}`);
  if (typeof m.bytesOut === "number") parts.push(`↑ ${fmtBytes(m.bytesOut)}`);
  if (typeof m.sessions === "number") parts.push(`${m.sessions} نشست`);
  if (typeof m.type === "string") parts.push(String(m.type));
  if (typeof m.device === "string" && e.cat === "device") parts.push(String(m.device));
  if (!parts.length) return null;
  return <span className="mono text-[10.5px] text-slate-500" dir="ltr">{parts.join("  •  ")}</span>;
}

function EntryRow({ e }: { e: LogEntry }) {
  const cat = CAT_META[e.cat] ?? { label: e.cat, color: "#94a3b8" };
  const lvl = LEVEL_META[e.level] ?? LEVEL_META.info;
  return (
    <tr>
      <td className="mono text-slate-400">{faTime(e.ts)}</td>
      <td><span className="chip !text-[10px]" style={{ color: cat.color, borderColor: `${cat.color}40`, background: `${cat.color}10` }}>{cat.label}</span></td>
      <td><span className="chip !text-[10px] !py-0" style={{ color: lvl.color }}>{lvl.label}</span></td>
      <td>{e.ip ? <Link href={`/ip/${e.ip}`} className="mono text-cyan-300 hover:underline">{e.ip}</Link> : <span className="text-slate-600">—</span>}</td>
      <td>{e.peer ? <Link href={`/ip/${e.peer}`} className="mono text-violet-300 hover:underline">{e.peer}</Link> : <span className="text-slate-600">—</span>}</td>
      <td className="max-w-[420px]">
        <div className="truncate text-slate-300" title={e.msg}>{e.msg}</div>
        <MetaChip e={e} />
      </td>
    </tr>
  );
}

function LogsInner() {
  const sp = useSearchParams();
  const { data, reload } = usePoll<LogsResp>(async () => (await fetch("/api/logs")).json(), 15000, []);
  const [dir, setDir] = useState("");
  const [ret, setRet] = useState("90");
  const [unit, setUnit] = useState<"day" | "month">("day");
  const [msg, setMsg] = useState("");
  const [saving, setSaving] = useState(false);

  // نمایش فایل
  const [customDir, setCustomDir] = useState("");
  const [customName, setCustomName] = useState("");
  const [jumpDate, setJumpDate] = useState("");
  const [fileView, setFileView] = useState<FileResp | null>(null);
  const [fileLoading, setFileLoading] = useState(false);
  const [filter, setFilter] = useState("");

  // جستجوی IP
  const [qIp, setQIp] = useState(sp.get("ip") ?? "");
  const [qDays, setQDays] = useState("30");
  const [searchRes, setSearchRes] = useState<SearchResp | null>(null);
  const [searching, setSearching] = useState(false);

  useEffect(() => {
    if (data) setDir(data.settings.dir);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [data?.settings.dir]);
  useEffect(() => {
    if (sp.get("ip")) doSearch(sp.get("ip")!, qDays);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const save = async () => {
    setSaving(true);
    setMsg("");
    const days = unit === "month" ? Number(ret) * 30 : Number(ret);
    const res = await (await fetch("/api/logs", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ dir: dir || null, retentionDays: days }) })).json();
    setSaving(false);
    if (res.ok) { setMsg(`تنظیمات ذخیره شد — لاگ‌ها در «${res.settings.dir}» تا ${fmtInt(res.settings.retentionDays)} روز نگهداری می‌شوند`); reload(); }
    else setMsg(res.error ?? "خطا در ذخیره");
  };

  const purgeNow = async () => {
    const res = await (await fetch("/api/logs", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ op: "purge" }) })).json();
    setMsg(res.ok ? `پاک‌سازی انجام شد — ${fmtInt(res.removed)} فایل قدیمی حذف گردید` : "خطا");
    reload();
  };

  const openFile = async (name: string, dirOverride?: string) => {
    setFileLoading(true);
    setFileView(null);
    const url = `/api/logs/file?name=${encodeURIComponent(name)}${dirOverride ? `&dir=${encodeURIComponent(dirOverride)}` : ""}`;
    const res: FileResp = await (await fetch(url)).json();
    setFileView(res);
    setFileLoading(false);
    setFilter("");
  };

  const doSearch = async (ipArg?: string, daysArg?: string) => {
    const ip = (ipArg ?? qIp).trim();
    if (!ip) return;
    setSearching(true);
    setSearchRes(null);
    const res: SearchResp = await (await fetch(`/api/logs/search?ip=${encodeURIComponent(ip)}&days=${daysArg ?? qDays}`)).json();
    setSearchRes(res);
    setSearching(false);
  };

  const shownEntries = (fileView?.entries ?? []).filter(
    (e) => !filter || e.msg.includes(filter) || (e.ip ?? "").includes(filter) || (e.peer ?? "").includes(filter) || e.cat.includes(filter),
  );

  return (
    <div className="space-y-6">
      <PageHead
        title="لاگ و آرشیو روزانه"
        sub="هر روز یک فایل لاگ جدا تولید می‌شود (خارج از پوشه برنامه) — پاک‌سازی خودکار روزانه بر اساس بازه نگهداشت شما، نمایش با تاریخ شمسی، جستجوی IP و بازخوانی از مسیر دلخواه"
        chips={data ? <span className="chip mono" dir="ltr"><HardDrive size={12} /> {fmtBytes(data.stats.totalSize)} — {fmtInt(data.stats.count)} فایل</span> : undefined}
      />

      {/* تنظیمات */}
      <div className="glass fade-up p-5">
        <Section icon={FolderCog} title="تنظیمات مسیر و نگهداشت لاگ" sub="مسیر پیش‌فرض خارج از پوشه برنامه است؛ با ذخیره، بلافاصله اعمال و در دیتابیس ماندگار می‌شود" />
        {!data ? (
          <Skeleton h={90} />
        ) : (
          <>
            <div className="grid gap-3 md:grid-cols-4">
              <div className="md:col-span-3">
                <label className="mb-1.5 block text-[11px] text-slate-500">مسیر ذخیره‌سازی فایل‌های لاگ (پوشه)</label>
                <input className="input mono" dir="ltr" value={dir} onChange={(e) => setDir(e.target.value)} placeholder="C:\nadir-logs یا /var/nadir-logs" />
              </div>
              <div>
                <label className="mb-1.5 block text-[11px] text-slate-500">نگهداری لاگ تا</label>
                <div className="flex gap-2">
                  <input className="input mono !w-20" dir="ltr" value={ret} onChange={(e) => setRet(e.target.value.replace(/[^0-9]/g, ""))} />
                  <select className="input" value={unit} onChange={(e) => setUnit(e.target.value as "day" | "month")}>
                    <option value="day">روز</option>
                    <option value="month">ماه</option>
                  </select>
                </div>
              </div>
            </div>
            <div className="mt-3 flex flex-wrap items-center gap-2.5">
              <button className="btn !py-2" onClick={save} disabled={saving}><Save size={14} /> {saving ? "در حال ذخیره…" : "ذخیره تنظیمات"}</button>
              <button className="btn btn-ghost !py-2" onClick={purgeNow}><Eraser size={14} /> پاک‌سازی فوری لاگ‌های قدیمی</button>
              <span className="chip !text-[10.5px]">پاک‌سازی خودکار: روزانه + هر ۶ ساعت — قدیمی‌تر از {fmtInt(data.settings.retentionDays)} روز حذف می‌شود</span>
            </div>
            {msg && <p className="mt-3 text-[12px] text-emerald-300">{msg}</p>}
            <p className="mt-3 text-[11px] leading-5 text-slate-500">
              مسیر فعلی: <span className="mono text-slate-300" dir="ltr">{data.settings.dir}</span> — نام فایل هر روز: <span className="mono text-slate-300" dir="ltr">netwatch-YYYY-MM-DD.log</span>
            </p>
          </>
        )}
      </div>

      {/* جستجوی IP */}
      <div className="glass fade-up fade-up-1 p-5">
        <Section icon={FileSearch} title="جستجوی IP در لاگ‌ها" sub="آی‌پی را وارد کنید تا لاگ‌های آن در روزهای اخیر — گروه‌بندی‌شده با تاریخ شمسی — نمایش داده شود" />
        <div className="flex flex-wrap items-end gap-3">
          <div>
            <label className="mb-1.5 block text-[11px] text-slate-500">آدرس IP</label>
            <input className="input mono !w-56" dir="ltr" placeholder="192.168.1.55" value={qIp} onChange={(e) => setQIp(e.target.value)} onKeyDown={(e) => e.key === "Enter" && doSearch()} />
          </div>
          <div>
            <label className="mb-1.5 block text-[11px] text-slate-500">در بازه</label>
            <select className="input !w-36" value={qDays} onChange={(e) => setQDays(e.target.value)}>
              {[["7", "۷ روز اخیر"], ["14", "۱۴ روز اخیر"], ["30", "۳۰ روز اخیر"], ["90", "۳ ماه اخیر"], ["120", "۴ ماه اخیر"]].map(([v, l]) => (
                <option key={v} value={v}>{l}</option>
              ))}
            </select>
          </div>
          <button className="btn !py-2.5" onClick={() => doSearch()} disabled={searching}><Search size={14} /> {searching ? "در حال جستجو…" : "جستجو در لاگ‌ها"}</button>
          {qIp && (
            <Link href={`/ip/${qIp.trim()}`} className="btn btn-ghost !py-2.5"><Activity size={14} /> پایش لحظه‌ای این IP</Link>
          )}
        </div>

        {searchRes && (
          <div className="mt-5 space-y-4">
            {!searchRes.totalHits ? (
              <Empty text={`در ${fmtInt(searchRes.days)} روز اخیر لاگی برای ${searchRes.ip} یافت نشد`} />
            ) : (
              <>
                <p className="text-[12px] text-slate-400">{fmtInt(searchRes.totalHits)} رکورد در {searchRes.byDay.length} روز یافت شد:</p>
                {searchRes.byDay.map((d) => (
                  <div key={d.date} className="overflow-hidden rounded-xl border border-slate-500/15">
                    <button className="flex w-full items-center justify-between bg-slate-500/5 px-4 py-2.5" onClick={() => openFile(d.name, searchRes.dir ? undefined : undefined)}>
                      <span className="flex items-center gap-2 text-[12.5px] font-bold text-slate-100"><CalendarDays size={14} className="text-cyan-300" /> {d.faDate}</span>
                      <span className="chip !text-[10px]">{fmtInt(d.entries.length)} رکورد — {d.name}</span>
                    </button>
                    <div className="scroll-thin max-h-56 overflow-auto">
                      <table className="table-base !text-[11.5px]">
                        <tbody>
                          {d.entries.slice(0, 40).map((e, i) => <EntryRow key={`${d.date}-${i}`} e={e} />)}
                        </tbody>
                      </table>
                    </div>
                  </div>
                ))}
              </>
            )}
          </div>
        )}
      </div>

      {/* قوانین Syslog انتخابی */}
      <SyslogCard />

      {/* فایل‌های روزانه */}
      <div className="glass fade-up fade-up-2 p-5">
        <Section
          icon={FileText}
          title="فایل‌های لاگ روزانه (تاریخ شمسی)"
          sub={
            data?.stats?.newest && data?.stats?.oldest
              ? `بازه موجود برای ریستور: از ${data.stats.newest.faDate} تا ${data.stats.oldest.faDate} — شامل همه رویدادهای شبکه، حملات، اسنیفینگ و Syslog هر روز`
              : "روی هر روز کلیک کنید تا محتوای آن با جزئیات باز شود"
          }
          action={
            <div className="flex items-end gap-2">
              <div className="flex flex-col">
                <label className="mb-1 text-[10px] text-slate-500">پرش به یک تاریخ (میلادی):</label>
                <input type="date" className="input mono !w-44 !py-1.5 !text-[11px]" dir="ltr" value={jumpDate} onChange={(e) => setJumpDate(e.target.value)} />
              </div>
              <button
                className="btn btn-ghost !py-1.5 !text-[11.5px]"
                onClick={() => jumpDate && openFile(`netwatch-${jumpDate}.log`, customDir || undefined)}
                disabled={!jumpDate}
              >
                مشاهده کل لاگ همان روز
              </button>
            </div>
          }
        />
        <div className="mb-3 flex flex-wrap items-end gap-2">
          <input className="input mono !w-56 !py-1.5 !text-[11px]" dir="ltr" placeholder="مسیر پوشه پشتیبان (اختیاری)…" value={customDir} onChange={(e) => setCustomDir(e.target.value)} />
          <input className="input mono !w-56 !py-1.5 !text-[11px]" dir="ltr" placeholder="netwatch-2026-01-04.log" value={customName} onChange={(e) => setCustomName(e.target.value)} />
          <button className="btn btn-ghost !py-1.5 !text-[11.5px]" onClick={() => customName && openFile(customName, customDir || undefined)}>ریستور از مسیر دلخواه</button>
        </div>
        {!data ? (
          <Skeleton h={180} />
        ) : !data.files.length ? (
          <Empty text="هنوز فایل لاگی تولید نشده — چند دقیقه پس از پایش، فایل امروز ساخته می‌شود" />
        ) : (
          <div className="scroll-thin max-h-[300px] overflow-auto">
            <table className="table-base">
              <thead><tr><th>تاریخ (شمسی)</th><th>نام فایل</th><th>حجم</th><th>آخرین تغییر</th><th></th></tr></thead>
              <tbody>
                {data.files.map((f) => (
                  <tr key={f.name} className="cursor-pointer" onClick={() => openFile(f.name)}>
                    <td className="font-semibold text-slate-200">{f.faDate}</td>
                    <td className="mono text-cyan-300" dir="ltr">{f.name}</td>
                    <td className="mono text-slate-300" dir="ltr">{fmtBytes(f.size)}</td>
                    <td className="mono text-slate-400">{faDateTime(f.mtime)}</td>
                    <td><span className="chip hover:!border-cyan-400/40 hover:!text-cyan-300"><Eye size={11} /> مشاهده</span></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* نمایش محتوای فایل */}
      {(fileLoading || fileView) && (
        <div className="glass fade-up p-5">
          <Section
            icon={Eye}
            title={fileView ? `محتوای ${fileView.faDate}` : "در حال خواندن فایل…"}
            sub={fileView ? `${fileView.dir} — ${fileView.matched} رکورد ${fileView.truncated ? `(نمایش ۳۰۰۰ رکورد اخیر از ${fileView.total})` : ""}` : ""}
            action={
              fileView?.ok ? (
                <input className="input !w-64 !py-1.5 !text-[11.5px]" placeholder="فیلتر داخل لاگ (IP یا متن)…" value={filter} onChange={(e) => setFilter(e.target.value)} />
              ) : undefined
            }
          />
          {fileLoading ? (
            <Skeleton h={200} />
          ) : !fileView?.ok ? (
            <Empty text={fileView?.error ?? "فایل یافت نشد"} />
          ) : (
            <div className="scroll-thin max-h-[480px] overflow-auto">
              <table className="table-base !text-[11.5px]">
                <thead><tr><th>ساعت</th><th>دسته</th><th>سطح</th><th>IP</th><th>مقصد</th><th>پیام و جزئیات</th></tr></thead>
                <tbody>
                  {shownEntries.slice().reverse().map((e, i) => <EntryRow key={i} e={e} />)}
                  {!shownEntries.length && <tr><td colSpan={6} className="py-8 text-center text-slate-500">موردی مطابق فیلتر نیست</td></tr>}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      <div className="glass p-4 text-[11.5px] leading-6 text-slate-400">
        <span className="flex items-center gap-2"><Trash2 size={13} className="text-slate-500" /> سیاست حذف خودکار: هر روز و هر ۶ ساعت، فایل‌هایی که از بازه نگهداشت شما قدیمی‌تر هستند (پیش‌فرض ۹۰ روز ≈ ۳ ماه) برای همیشه حذف می‌شوند. برای تغییر، بالای صفحه «روز» یا «ماه» را انتخاب و ذخیره کنید؛ برای بازخوانی نسخه پشتیبان، مسیر پوشه و نام فایل را در بخش «بازخوانی از مسیر دلخواه» وارد کنید.</span>
      </div>
    </div>
  );
}

// ------------------- کارت قوانین Syslog انتخابی -------------------
type SyslogRule = { id: number; targetType: string; target: string; direction: string; enabled: boolean };
type SyslogResp = { ok: boolean; rules: SyslogRule[]; devices: { id: number; name: string; ip: string }[]; ranges: { id: number; name: string }[] };

function SyslogCard() {
  const { data, reload } = usePoll<SyslogResp>(async () => (await fetch("/api/syslog")).json(), 12000, []);
  const [form, setForm] = useState({ targetType: "device", target: "", direction: "in" });
  if (!data) return <Skeleton h={120} />;

  const add = async () => {
    await fetch("/api/syslog", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(form) });
    setForm({ ...form, target: "" });
    reload();
  };
  const toggle = async (id: number) => {
    await fetch("/api/syslog", { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id }) });
    reload();
  };
  const del = async (id: number) => {
    await fetch(`/api/syslog?id=${id}`, { method: "DELETE" });
    reload();
  };

  return (
    <div className="glass fade-up p-5">
      <Section
        icon={ListChecks}
        title="سامانه Syslog حرفه‌ای — ثبت لاگ انتخابی"
        sub="فقط لاگ‌های مهمِ ورودی (و در صورت نیاز خروجی) IPهای مختلف به دیوایس‌ها/رنج‌های منتخب شما ثبت می‌شود — حداکثر ۳ ماه نگهداشت و پاک‌سازی خودکار از فایل و دیتابیس"
      />
      <div className="flex flex-wrap items-end gap-2.5">
        <select className="input !w-36" value={form.targetType} onChange={(e) => setForm({ ...form, targetType: e.target.value, target: "" })}>
          <option value="device">دیوایس</option>
          <option value="range">رنج</option>
          <option value="ip">آی‌پی</option>
        </select>
        {form.targetType === "device" ? (
          <select className="input !w-64" value={form.target} onChange={(e) => setForm({ ...form, target: e.target.value })}>
            <option value="">انتخاب تجهیز…</option>
            {data.devices.map((d) => <option key={d.id} value={d.ip}>{d.name} — {d.ip}</option>)}
          </select>
        ) : form.targetType === "range" ? (
          <select className="input !w-64" value={form.target} onChange={(e) => setForm({ ...form, target: e.target.value })}>
            <option value="">انتخاب رنج…</option>
            {data.ranges.map((r) => <option key={r.id} value={String(r.id)}>{r.name}</option>)}
          </select>
        ) : (
          <input className="input mono !w-64" dir="ltr" placeholder="IP هدف — 10.10.0.21" value={form.target} onChange={(e) => setForm({ ...form, target: e.target.value })} />
        )}
        <select className="input !w-44" value={form.direction} onChange={(e) => setForm({ ...form, direction: e.target.value })}>
          <option value="in">فقط ورودی‌های هدف</option>
          <option value="out">فقط خروجی هدف</option>
          <option value="both">ورودی + خروجی</option>
        </select>
        <button className="btn !py-2.5" onClick={add} disabled={!form.target}><Plus size={15} /> فعال‌سازی ثبت</button>
      </div>
      <div className="mt-4 space-y-2">
        {data.rules.map((r) => (
          <div key={r.id} className="flex items-center justify-between gap-3 rounded-xl border border-slate-500/15 bg-slate-500/5 px-3.5 py-2.5">
            <div className="flex items-center gap-3 text-[12px]">
              <button className={`toggle ${r.enabled ? "on" : ""}`} onClick={() => toggle(r.id)} title="فعال/غیرفعال" />
              <span className="chip !text-[10px]">{r.targetType === "device" ? "دیوایس" : r.targetType === "range" ? "رنج" : "IP"}</span>
              <span className="mono font-bold text-cyan-300" dir="ltr">{r.target}</span>
              <span className="text-slate-400">{r.direction === "in" ? "فقط ورودی" : r.direction === "out" ? "فقط خروجی" : "هر دو جهت"} به این هدف لاگ شود</span>
            </div>
            <div className="flex items-center gap-2">
              <span className={`chip !text-[10px] ${r.enabled ? "" : "opacity-50"}`} style={r.enabled ? { color: "#34d399" } : {}}>
                <Power size={10} /> {r.enabled ? "در حال ثبت" : "متوقف"}
              </span>
              <button className="rounded-lg p-1.5 text-slate-500 hover:bg-rose-500/10 hover:text-rose-300" onClick={() => del(r.id)}><Trash2 size={14} /></button>
            </div>
          </div>
        ))}
        {!data.rules.length && <p className="py-4 text-center text-[12px] text-slate-500">قانونی تعریف نشده — هدف را انتخاب و «فعال‌سازی ثبت» را بزنید</p>}
      </div>
    </div>
  );
}

export default function LogsPage() {
  return (
    <Suspense fallback={<div className="space-y-4"><Skeleton h={80} /><Skeleton h={240} /></div>}>
      <LogsInner />
    </Suspense>
  );
}
