"use client";

import { useMemo } from "react";
import {
  ShieldAlert, ShieldCheck, Flame, Ban, Target, Crosshair, Lock, FileDown, AlertTriangle,
} from "lucide-react";
import { usePoll, useSnap, type EvOut } from "@/lib/useEngine";
import { LiveChart, type LivePoint } from "@/components/charts";
import { PageHead, Section, Stat, SevBadge, Skeleton } from "@/components/ui";
import { EVT_FA, faDateTime, fmtInt } from "@/lib/format";

export default function SecurityPage() {
  const { snap } = useSnap();
  const { data } = usePoll<{ ok: boolean; list: EvOut[]; sec: { today: number; blocked: number; topAttacker: { ip: string; n: number } | null; topTarget: { ip: string; n: number } | null } }>(
    async () => (await fetch("/api/security?limit=220")).json(), 5000, [],
  );

  // نمودار رخداد در دقیقه (۱ ساعت اخیر)
  const evChart = useMemo(() => {
    if (!data) return { points: [] as { x: number }[] as unknown as LivePoint[], max: 0 };
    const now = Date.now();
    const buckets = Array.from({ length: 30 }, (_, i) => ({ t: now - (29 - i) * 120_000, a: 0 }));
    data.list.forEach((e) => {
      const k = Math.floor((now - e.ts) / 120_000);
      if (k >= 0 && k < 30) buckets[29 - k].a++;
    });
    return { points: buckets, max: Math.max(...buckets.map((b) => b.a), 1) };
  }, [data]);

  if (!data) return <div className="space-y-4"><Skeleton h={90} /><Skeleton h={200} /><Skeleton h={320} /></div>;

  const list = data.list;
  const recent = list.filter((e) => Date.now() - e.ts < 10 * 60_000).length;
  const critical = list.filter((e) => e.severity === "critical" || e.severity === "high").length;
  const level = snap?.sec.campaign || recent >= 6 ? { label: "بحرانی — حمله فعال", c: "#fb7185", icon: ShieldAlert } : recent >= 2 ? { label: "هشدار — فعالیت مشکوک", c: "#fbbf24", icon: AlertTriangle } : { label: "آرام — تهدید فعالی رصد نشد", c: "#34d399", icon: ShieldCheck };
  const LevelIcon = level.icon;

  const attackers = Object.entries(list.reduce<Record<string, number>>((m, e) => { m[e.srcIp] = (m[e.srcIp] ?? 0) + 1; return m; }, {})).sort((a, b) => b[1] - a[1]).slice(0, 5);
  const targets = Object.entries(list.reduce<Record<string, number>>((m, e) => { m[e.dstIp] = (m[e.dstIp] ?? 0) + 1; return m; }, {})).sort((a, b) => b[1] - a[1]).slice(0, 5);

  return (
    <div className="space-y-6">
      <PageHead
        title="مرکز امنیت و پایش نفوذ"
        sub="هر تلاش نفوذ با تاریخ، ساعت دقیق و آی‌پی مورد حمله ثبت و لحظه‌ای نمایش داده می‌شود — سیاست دفاعی: مسدودسازی خودکار + Rate-Limit روی API"
        chips={<a className="chip hover:text-cyan-300" href="/api/export?type=events"><FileDown size={12} /> دانلود لاگ کامل (CSV)</a>}
      />

      <div className={`glass fade-up flex items-center gap-4 border-r-4 p-4`} style={{ borderRightColor: level.c }}>
        <span className="grid h-12 w-12 place-items-center rounded-2xl border" style={{ color: level.c, borderColor: `${level.c}44`, background: `${level.c}12` }}>
          <LevelIcon size={22} />
        </span>
        <div>
          <div className="text-[15px] font-extrabold" style={{ color: level.c }}>سطح تهدید: {level.label}</div>
          <div className="mt-0.5 text-[11.5px] text-slate-400">{recent} رخداد در ۱۰ دقیقه اخیر — {critical} رخداد با شدت بالا در نشست جاری</div>
        </div>
        {snap?.sec.campaign && <span className="mr-auto chip animate-pulse !text-[11px]" style={{ color: "#fb7185", borderColor: "#fb718555", background: "#fb718512" }}><Flame size={12} /> کمپین حمله در جریان است</span>}
      </div>

      <div className="fade-up grid grid-cols-2 gap-4 lg:grid-cols-4">
        <Stat icon={Flame} label="رخدادهای امروز" value={fmtInt(data.sec.today)} color="#fbbf24" />
        <Stat icon={Ban} label="مسدودشده امروز" value={fmtInt(data.sec.blocked)} color="#34d399" sub="اقدام خودکار فایروال/IDS" />
        <Stat icon={Crosshair} label="پرمکررترین مهاجم" value={data.sec.topAttacker?.ip ?? "—"} color="#fb7185" sub={data.sec.topAttacker ? `${data.sec.topAttacker.n} تلاش ثبت‌شده` : "موردی نیست"} />
        <Stat icon={Target} label="پرهدف‌ترین آی‌پی" value={data.sec.topTarget?.ip ?? "—"} color="#a78bfa" sub={data.sec.topTarget ? `${data.sec.topTarget.n} بار هدف قرار گرفت` : "موردی نیست"} />
      </div>

      <div className="grid gap-4 xl:grid-cols-3">
        <div className="glass fade-up fade-up-1 p-5 xl:col-span-2">
          <Section icon={Flame} title="رخدادهای امنیتی در یک ساعت اخیر" sub="شمارش تلاش‌ها در بازه‌های ۲ دقیقه‌ای" />
          <LiveChart data={evChart.points} height={180} fmt={(v) => `${Math.round(v)} رخداد`} showB={false} colorA="#fb7185" />
        </div>
        <div className="glass fade-up fade-up-2 space-y-4 p-5">
          <div>
            <div className="mb-2 text-[12.5px] font-bold text-slate-200">مهاجمان برتر</div>
            {attackers.map(([ip, n], i) => (
              <div key={ip} className="mb-1.5 flex items-center gap-2 text-[11.5px]">
                <span className="w-4 text-center text-slate-600">{i + 1}</span>
                <span className="mono text-rose-300">{ip}</span>
                <div className="progress-track flex-1"><div className="progress-fill" style={{ width: `${(n / (attackers[0]?.[1] || 1)) * 100}%`, background: "#fb7185" }} /></div>
                <b className="mono text-slate-300">{n}</b>
              </div>
            ))}
          </div>
          <div className="border-t border-slate-500/10 pt-3">
            <div className="mb-2 text-[12.5px] font-bold text-slate-200">اهداف پرتکرار</div>
            {targets.map(([ip, n], i) => (
              <div key={ip} className="mb-1.5 flex items-center gap-2 text-[11.5px]">
                <span className="w-4 text-center text-slate-600">{i + 1}</span>
                <span className="mono text-violet-300">{ip}</span>
                <div className="progress-track flex-1"><div className="progress-fill" style={{ width: `${(n / (targets[0]?.[1] || 1)) * 100}%`, background: "#a78bfa" }} /></div>
                <b className="mono text-slate-300">{n}</b>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="glass fade-up fade-up-3 p-5">
        <Section icon={ShieldAlert} title="لاگ کامل تلاش‌های نفوذ" sub="زمان دقیق، مبدأ (داخلی/خارجی)، آی‌پی مورد حمله و اقدام انجام‌شده" />
        <div className="scroll-thin max-h-[440px] overflow-auto">
          <table className="table-base">
            <thead><tr><th>تاریخ و زمان</th><th>مبدأ حمله</th><th>مقصد (IP مورد حمله)</th><th>نوع حمله</th><th>شدت</th><th>اقدام</th><th>جزئیات</th></tr></thead>
            <tbody>
              {list.map((e) => (
                <tr key={e.id}>
                  <td className="mono text-slate-300">{faDateTime(e.ts)}</td>
                  <td>
                    <div className="flex items-center gap-2">
                      <span className="mono font-semibold text-slate-200">{e.srcIp}</span>
                      <span className="chip !text-[9.5px] !py-0" style={e.srcExt ? { color: "#fb7185", borderColor: "#fb718540", background: "#fb718510" } : { color: "#fbbf24", borderColor: "#fbbf2440", background: "#fbbf2410" }}>
                        {e.srcExt ? "خارجی" : "داخلی"}
                      </span>
                    </div>
                  </td>
                  <td className="mono font-semibold text-rose-300">{e.dstIp}</td>
                  <td><span className="chip !text-[10px]" style={{ color: "#fbbf24", borderColor: "#fbbf2440", background: "#fbbf2410" }}>{EVT_FA[e.type] ?? e.type}</span></td>
                  <td><SevBadge sev={e.severity} /></td>
                  <td>{e.action === "blocked" ? <span className="chip !text-[10px]" style={{ color: "#34d399", borderColor: "#34d39940", background: "#34d39910" }}><Ban size={10} /> مسدود شد</span> : <span className="chip !text-[10px]">ثبت شد</span>}</td>
                  <td className="max-w-[300px] truncate text-slate-400" title={e.detail}>{e.detail}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <div className="glass fade-up fade-up-4 p-5">
        <div className="mb-3 flex items-center gap-2 text-emerald-300"><Lock size={16} /><b className="text-[14px]">لایه‌های دفاعی فعال روی همین نرم‌افزار</b></div>
        <div className="grid gap-3 text-[11.5px] text-slate-300 md:grid-cols-2 xl:grid-cols-4">
          {[
            ["Rate-Limiting روی API", "هر آدرس نقض‌کننده سهمیه، با زمان و IP در لاگ امنیتی ثبت و قطع می‌شود"],
            ["هدرهای امنیتی کامل", "CSP، X-Frame-Options، nosniff، Permissions-Policy و COOP"],
            ["اعتبارسنجی ورودی", "بررسی سخت‌گیرانه CIDR/IP/نوع روی تمام انتهای‌های mutating"],
            ["بدون وابستگی بیرونی حساس", "عدم نمایش خطاهای داخلی، خروجی خطای یکدست و لاگ‌محور"],
          ].map(([t, d]) => (
            <div key={t} className="rounded-xl border border-emerald-400/15 bg-emerald-400/5 p-3">
              <div className="mb-1 flex items-center gap-1.5 font-bold text-emerald-200"><ShieldCheck size={13} /> {t}</div>
              <div className="leading-5 text-slate-400">{d}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
