"use client";

import { useMemo, useState } from "react";
import Link from "next/link";
import {
  BarChart3, FileDown, ListX, TrendingUp, Boxes, CircleOff, ShieldAlert, CalendarClock, CalendarDays,
} from "lucide-react";
import { usePoll } from "@/lib/useEngine";
import { LiveChart } from "@/components/charts";
import { PageHead, Section, Skeleton, Empty } from "@/components/ui";
import { fmtRate, fmtBytes, fmtInt, faHM, faDate, RANGE_KIND_FA } from "@/lib/format";

type RangeRow = { id: number; name: string; cidr: string; kind: string; color: string; capacity: number; used: number };
type Detail = {
  ok: boolean;
  range: { id: number; name: string; cidr: string; kind: string; color: string };
  stats: { capacity: number; used: number; activeNow: number; idle: number; susp: number; unusedCount: number; unused: string[]; avg: number; peak: number; p95: number };
  ips: { ip: string; host: string; i: number; o: number; s: number; idle: boolean; susp: { score: number } | null }[];
  h24: { t: number; i: number; o: number }[];
  h30: { t: number; i: number; o: number }[];
};

export default function ReportsPage() {
  const { data: rangesData } = usePoll<{ ok: boolean; ranges: RangeRow[] }>(async () => (await fetch("/api/ranges")).json(), 10000, []);
  const [sel, setSel] = useState<number | null>(null);
  const current = sel ?? rangesData?.ranges[0]?.id ?? null;
  const { data: det } = usePoll<Detail | null>(
    async () => (current ? ((await (await fetch(`/api/ranges/${current}`)).json()) as Detail) : null),
    6000,
    [current],
  );

  // مجموع ۲۴ساعت و ۳۰روز همه رنج‌ها برای جدول مقایسه‌ای
  const { data: allTrends } = usePoll<Record<number, { in24: number; out24: number; in30: number; out30: number; unusedCount: number; used: number; capacity: number }>>(
    async () => {
      if (!rangesData) return {};
      const out: Record<number, { in24: number; out24: number; in30: number; out30: number; unusedCount: number; used: number; capacity: number }> = {};
      await Promise.all(
        rangesData.ranges.map(async (r) => {
          const d: Detail = await (await fetch(`/api/ranges/${r.id}`)).json();
          const s24 = (d.h24 ?? []).reduce((a, p) => ({ i: a.i + p.i * 3600, o: a.o + p.o * 3600 }), { i: 0, o: 0 });
          const s30 = (d.h30 ?? []).reduce((a, p) => ({ i: a.i + p.i * 86400, o: a.o + p.o * 86400 }), { i: 0, o: 0 });
          out[r.id] = { in24: s24.i, out24: s24.o, in30: s30.i, out30: s30.o, unusedCount: d.stats.unusedCount, used: d.stats.used, capacity: d.stats.capacity };
        }),
      );
      return out;
    },
    30000,
    [rangesData],
  );

  const topBy24 = useMemo(() => {
    if (!det) return [];
    return [...det.ips].sort((a, b) => b.i + b.o - (a.i + a.o)).slice(0, 6);
  }, [det]);

  if (!rangesData) return <div className="space-y-4"><Skeleton h={80} /><Skeleton h={240} /></div>;

  return (
    <div className="space-y-6">
      <PageHead
        title="گزارشات و تحلیل آماری رنج‌ها"
        sub="تحلیل مصرف ۲۴ ساعت و ۳۰ روز اخیر، آمار آدرس‌های خالی و بلااستفاده، و مقایسه رنج‌ها — همه بدون رفرش"
        chips={
          <>
            <a className="chip hover:text-cyan-300" href="/api/export?type=ips"><FileDown size={12} /> CSV مصرف IPها</a>
            <a className="chip hover:text-cyan-300" href="/api/export?type=daily"><FileDown size={12} /> CSV مصرف امروز</a>
            <a className="chip hover:text-cyan-300" href="/api/export?type=events"><FileDown size={12} /> CSV رخدادها</a>
          </>
        }
      />

      {/* انتخاب رنج */}
      <div className="fade-up fade-up-1 flex flex-wrap gap-2">
        {rangesData.ranges.map((r) => (
          <button key={r.id} className={`tab-btn !border ${current === r.id ? "active" : "!border-slate-500/15"}`} style={current === r.id ? { color: r.color, borderColor: `${r.color}55`, background: `${r.color}14` } : {}} onClick={() => setSel(r.id)}>
            {r.name} <span className="mono mr-1 text-[10px] opacity-70" dir="ltr">{r.cidr}</span>
          </button>
        ))}
      </div>

      {!det ? (
        <Skeleton h={280} />
      ) : !det.ok ? (
        <Empty text="رنج انتخاب‌شده یافت نشد یا حذف شده است" />
      ) : (
        <>
          <div className="fade-up grid grid-cols-2 gap-3 md:grid-cols-3 xl:grid-cols-6">
            {[
              { icon: Boxes, label: "ظرفیت آدرس", v: fmtInt(det.stats.capacity), c: "#60a5fa" },
              { icon: TrendingUp, label: "آدرس در حال استفاده", v: fmtInt(det.stats.used), c: det.range.color },
              { icon: ListX, label: "آدرس خالی (آزاد)", v: fmtInt(det.stats.unusedCount), c: "#94a3b8" },
              { icon: CircleOff, label: "بلااستفاده/بیکار", v: fmtInt(det.stats.idle), c: "#fbbf24" },
              { icon: ShieldAlert, label: "مشکوک", v: fmtInt(det.stats.susp), c: "#fb7185" },
              { icon: BarChart3, label: "ضریب اشغال", v: `${det.stats.capacity ? Math.round((det.stats.used / det.stats.capacity) * 100) : 0}%`, c: "#34d399" },
            ].map((s) => (
              <div key={s.label} className="glass p-3.5">
                <s.icon size={16} style={{ color: s.c }} />
                <div className="mt-2 text-[19px] font-extrabold text-slate-50" dir="ltr">{s.v}</div>
                <div className="text-[10.5px] text-slate-500">{s.label}</div>
              </div>
            ))}
          </div>

          <div className="grid gap-4 xl:grid-cols-2">
            <div className="glass fade-up fade-up-2 p-5">
              <Section icon={CalendarClock} title={`مصرف تجمیعی رنج — ۲۴ ساعت اخیر`} sub={det.range.cidr} />
              <LiveChart data={(det.h24 ?? []).map((p) => ({ t: p.t, a: p.i, b: p.o }))} height={200} timeFmt={faHM} colorA={det.range.color} />
            </div>
            <div className="glass fade-up fade-up-3 p-5">
              <Section icon={CalendarDays} title={`مصرف تجمیعی رنج — ۳۰ روز اخیر`} sub="مجموع دانلود/آپلود روزانه (میانگین نرخ)" />
              <LiveChart data={(det.h30 ?? []).map((p) => ({ t: p.t, a: p.i, b: p.o }))} height={200} timeFmt={faDate} colorA="#34d399" />
            </div>
          </div>

          <div className="grid gap-4 xl:grid-cols-2">
            <div className="glass fade-up fade-up-3 p-5">
              <Section icon={TrendingUp} title="پرمصرف‌ترین IPهای این رنج" sub="بر اساس نرخ لحظه‌ای" />
              <div className="space-y-2.5">
                {topBy24.map((x, i) => {
                  const mx = topBy24[0] ? topBy24[0].i + topBy24[0].o : 1;
                  return (
                    <Link href={`/ip/${x.ip}`} key={x.ip} className="flex items-center gap-3 rounded-lg border border-slate-500/10 bg-slate-500/5 p-2.5 transition-colors hover:border-cyan-400/30">
                      <span className="w-5 text-center text-[11px] text-slate-600">{i + 1}</span>
                      <span className="mono w-32 text-[12px] font-semibold text-cyan-300">{x.ip}</span>
                      <div className="progress-track flex-1"><div className="progress-fill" style={{ width: `${((x.i + x.o) / mx) * 100}%`, background: x.susp ? "#fb7185" : det.range.color }} /></div>
                      <b className="mono w-28 text-left text-[11px] text-slate-200" dir="ltr">{fmtRate(x.i + x.o)}</b>
                    </Link>
                  );
                })}
                {!topBy24.length && <Empty text="داده‌ای موجود نیست" />}
              </div>
            </div>

            <div className="glass fade-up fade-up-4 p-5">
              <Section icon={ListX} title={`آدرس‌های خالی رنج — ${fmtInt(det.stats.unusedCount)} مورد`} sub="نمونه آدرس‌های آزاد برای تخصیص" />
              <div className="scroll-thin grid max-h-[260px] grid-cols-2 gap-1.5 overflow-auto sm:grid-cols-3 lg:grid-cols-4">
                {det.stats.unused.map((ip) => (
                  <span key={ip} className="mono rounded-lg border border-slate-500/15 bg-slate-500/5 px-2 py-1.5 text-center text-[11px] text-slate-400">{ip}</span>
                ))}
              </div>
            </div>
          </div>
        </>
      )}

      <div className="glass fade-up fade-up-4 p-5">
        <Section icon={BarChart3} title="جدول مقایسه همه رنج‌ها" sub="حجم مصرف ۲۴ ساعت و ۳۰ روز + ظرفیت آدرس" />
        <div className="scroll-thin overflow-x-auto">
          <table className="table-base">
            <thead>
              <tr><th>رنج</th><th>CIDR</th><th>نوع</th><th>مصرف ۲۴ساعت ↓</th><th>مصرف ۲۴ساعت ↑</th><th>مصرف ۳۰روز ↓</th><th>مصرف ۳۰روز ↑</th><th>ظرفیت</th><th>خالی</th><th>اشغال</th></tr>
            </thead>
            <tbody>
              {rangesData.ranges.map((r) => {
                const t = allTrends?.[r.id];
                const occ = r.capacity ? Math.round((r.used / r.capacity) * 100) : 0;
                return (
                  <tr key={r.id}>
                    <td>
                      <Link href={`/ranges/${r.id}`} className="flex items-center gap-2 font-semibold text-slate-200 hover:text-cyan-200">
                        <i className="h-2.5 w-2.5 rounded-full" style={{ background: r.color }} /> {r.name}
                      </Link>
                    </td>
                    <td className="mono text-slate-400" dir="ltr">{r.cidr}</td>
                    <td><span className="chip !text-[10px]">{RANGE_KIND_FA[r.kind] ?? r.kind}</span></td>
                    <td className="mono text-cyan-200" dir="ltr">{t ? fmtBytes(t.in24) : "…"}</td>
                    <td className="mono text-violet-300" dir="ltr">{t ? fmtBytes(t.out24) : "…"}</td>
                    <td className="mono text-cyan-200" dir="ltr">{t ? fmtBytes(t.in30) : "…"}</td>
                    <td className="mono text-violet-300" dir="ltr">{t ? fmtBytes(t.out30) : "…"}</td>
                    <td className="mono text-slate-300">{fmtInt(r.capacity)}</td>
                    <td className="mono text-slate-300">{t ? fmtInt(t.unusedCount) : "…"}</td>
                    <td>
                      <div className="flex items-center gap-2">
                        <div className="progress-track w-20"><div className="progress-fill" style={{ width: `${occ}%`, background: r.color }} /></div>
                        <span className="mono text-[11px] text-slate-400">{occ}%</span>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
