"use client";

import { useMemo, useState } from "react";
import { Share2, LocateFixed, GitCommitHorizontal } from "lucide-react";
import { usePoll } from "@/lib/useEngine";
import { KindIcon } from "@/components/ui";
import { PageHead, Section, Skeleton } from "@/components/ui";
import { fmtRate } from "@/lib/format";

type GNode = { id: number; name: string; ip: string; kind: string; online: boolean; lat: number; rate: number };
type GEdge = { a: number; b: number };
type Graph = { ok: boolean; nodes: GNode[]; edges: GEdge[] };
type PathResp = { ok: boolean; hops: GNode[]; edgesUsed: [number, number][]; totalLat?: number; problem: { id: number; name: string; ip: string } | null };

const LAYERS: { key: string; label: string; kinds: string[] }[] = [
  { key: "wireless", label: "دسترسی بی‌سیم", kinds: ["wireless"] },
  { key: "access", label: "لایه دسترسی", kinds: ["switch", "cisco"] },
  { key: "servers", label: "سرورها", kinds: ["server", "windows", "esxi", "vm"] },
  { key: "mikrotik", label: "روترها", kinds: ["mikrotik"] },
  { key: "firewall", label: "فایروال", kinds: ["firewall"] },
  { key: "fiber", label: "لبه فیبر/خارج", kinds: ["fiber", "other"] },
];
const layerOf = (kind: string) => {
  const i = LAYERS.findIndex((l) => l.kinds.includes(kind));
  return i === -1 ? 1 : i;
};

export default function RoutingPage() {
  const { data } = usePoll<Graph>(async () => (await fetch("/api/routegraph")).json(), 4000, []);
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [path, setPath] = useState<PathResp | null>(null);
  const [findErr, setFindErr] = useState("");

  const pos = useMemo(() => {
    const m = new Map<number, { x: number; y: number }>();
    if (!data) return m;
    const byLayer = new Map<number, GNode[]>();
    data.nodes.forEach((n) => {
      const l = layerOf(n.kind);
      byLayer.set(l, [...(byLayer.get(l) ?? []), n]);
    });
    const W = 100;
    byLayer.forEach((list, l) => {
      list.forEach((n, i) => {
        const x = 8 + (l / Math.max(1, LAYERS.length - 1)) * (W - 16);
        const y = ((i + 1) / (list.length + 1)) * 92 + 4;
        m.set(n.id, { x, y });
      });
    });
    return m;
  }, [data]);

  if (!data) return <div className="space-y-4"><Skeleton h={90} /><Skeleton h={320} /></div>;

  const onPath = new Set(path?.edgesUsed?.map(([a, b]) => `${a}-${b}`) ?? []);
  const find = async () => {
    if (!from || !to || from === to) return;
    setFindErr("");
    setPath(null);
    const r = await fetch(`/api/routegraph?from=${from}&to=${to}`);
    if (r.ok) setPath(await r.json());
    else setFindErr("مسیری بین این دو گره یافت نشد");
  };
  const opts = data.nodes.map((n) => ({ id: n.id, label: `${n.name} — ${n.ip}` }));

  return (
    <div className="space-y-6">
      <PageHead
        title="نقشه مسیریابی شبکه"
        sub="گراف زنده توپولوژی با فلش‌های منحنی متحرک — مبدأ و مقصد را انتخاب کنید تا کوتاه‌ترین مسیر (الگوریتم BFS) محاسبه و برجسته شود؛ گره آفلاین محل گیر کردن را نشان می‌دهد"
        chips={<span className="chip"><GitCommitHorizontal size={12} /> الگوریتم کوتاه‌ترین مسیر + تحلیل آنلاین مسیر</span>}
      />

      <div className="glass fade-up flex flex-wrap items-end gap-3 p-4">
        <div>
          <label className="mb-1.5 block text-[11px] text-slate-500">مبدأ</label>
          <select className="input !w-64" value={from} onChange={(e) => setFrom(e.target.value)}>
            <option value="">انتخاب…</option>
            {opts.map((o) => <option key={o.id} value={o.id}>{o.label}</option>)}
          </select>
        </div>
        <div>
          <label className="mb-1.5 block text-[11px] text-slate-500">مقصد</label>
          <select className="input !w-64" value={to} onChange={(e) => setTo(e.target.value)}>
            <option value="">انتخاب…</option>
            {opts.map((o) => <option key={o.id} value={o.id}>{o.label}</option>)}
          </select>
        </div>
        <button className="btn" onClick={find} disabled={!from || !to || from === to}><LocateFixed size={15} /> یافتن کوتاه‌ترین مسیر</button>
        {path?.ok && (
          <span className="chip mono" dir="ltr">{path.hops.length - 1} hops • {path.totalLat}ms</span>
        )}
        {findErr && <span className="text-[12px] text-rose-300">{findErr}</span>}
      </div>

      <div className="grid gap-4 xl:grid-cols-4">
        <div className="glass fade-up fade-up-1 relative overflow-hidden p-4 xl:col-span-3">
          <Section icon={Share2} title="توپولوژی زنده" sub="رنگ گره: سبز=آنلاین • قرمز=آفلاین — فلش‌ها: جریان مسیر" />
          <div className="relative" dir="ltr" style={{ height: 480 }}>
            <svg viewBox="0 0 100 100" preserveAspectRatio="none" className="absolute inset-0 h-full w-full">
              {data.edges.map((e) => {
                const p1 = pos.get(e.a);
                const p2 = pos.get(e.b);
                if (!p1 || !p2) return null;
                const mx = (p1.x + p2.x) / 2;
                const d = `M ${p1.x} ${p1.y} C ${mx} ${p1.y}, ${mx} ${p2.y}, ${p2.x} ${p2.y}`;
                const target = data.nodes.find((n) => n.id === e.b);
                const highlighted = onPath.has(`${e.a}-${e.b}`) || onPath.has(`${e.b}-${e.a}`);
                return (
                  <path
                    key={`${e.a}-${e.b}`}
                    d={d}
                    fill="none"
                    strokeWidth={highlighted ? 0.9 : 0.35}
                    stroke={highlighted ? "#22d3ee" : target?.online ? "rgba(148,163,184,0.4)" : "rgba(251,113,133,0.5)"}
                    className="route-flow"
                    vectorEffect="non-scaling-stroke"
                  />
                );
              })}
            </svg>
            {data.nodes.map((n) => {
              const p = pos.get(n.id);
              if (!p) return null;
              const inPath = path?.hops?.some((h) => h.id === n.id);
              return (
                <div
                  key={n.id}
                  className="absolute -translate-x-1/2 -translate-y-1/2 text-center"
                  style={{ left: `${p.x}%`, top: `${p.y}%`, width: 118 }}
                  title={`${n.name} — ${n.ip} — ${n.online ? "آنلاین" : "آفلاین"} — ${fmtRate(n.rate)}`}
                >
                  <div
                    className={`mx-auto grid h-11 w-11 place-items-center rounded-2xl border backdrop-blur transition-all ${
                      n.online ? "border-emerald-400/50 bg-emerald-400/15" : "border-rose-400/60 bg-rose-400/20 animate-pulse"
                    } ${inPath ? "ring-2 ring-cyan-300 shadow-[0_0_18px_rgba(34,211,238,0.6)]" : ""}`}
                  >
                    <KindIcon kind={n.kind} size={19} />
                  </div>
                  <div className="mx-auto mt-1 max-w-[116px]">
                    <div className="truncate text-[9.5px] font-semibold text-slate-200">{n.name}</div>
                    <div className="mono truncate text-[8.5px]" style={{ color: n.online ? "#67e8f9" : "#fda4af" }}>{n.ip}</div>
                  </div>
                </div>
              );
            })}
            {/* برچسب لایه‌ها */}
            {LAYERS.map((l, i) => (
              <div key={l.key} className="absolute top-0 -translate-x-1/2 text-[9px] font-bold uppercase tracking-wider text-slate-600" style={{ left: `${8 + (i / (LAYERS.length - 1)) * 84}%` }}>
                {l.label}
              </div>
            ))}
          </div>
        </div>

        <div className="glass fade-up fade-up-2 p-5">
          <Section icon={LocateFixed} title="نتیجه مسیریابی" sub="هاب‌به‌هاب مسیر پیدا شده" />
          {!path ? (
            <p className="py-10 text-center text-[12px] text-slate-500">مبدأ و مقصد را انتخاب و «یافتن مسیر» را بزنید</p>
          ) : !path.ok ? (
            <p className="py-10 text-center text-[12px] text-rose-300">مسیری یافت نشد</p>
          ) : (
            <div className="space-y-2 text-[11.5px]">
              {path.hops.map((h, i) => (
                <div key={h.id} className={`flex items-center justify-between rounded-lg border px-2.5 py-2 ${h.online ? "border-slate-500/15 bg-slate-500/5" : "border-rose-400/40 bg-rose-400/10"}`}>
                  <span className="flex items-center gap-2">
                    <b className="mono w-5 text-center text-slate-600">{i || "S"}</b>
                    <KindIcon kind={h.kind} size={14} />
                    <span className="text-slate-200">{h.name}</span>
                  </span>
                  <span className="mono text-slate-400" dir="ltr">{h.ip}</span>
                </div>
              ))}
              {path.problem ? (
                <div className="rounded-lg border border-rose-400/40 bg-rose-400/10 p-2.5 text-rose-200">
                  ✕ گیر کردن در «{path.problem.name}» ({path.problem.ip}) — از این گره به بعد پینگ جواب نمی‌آید؛ ابتدا همین گره را بررسی کنید.
                </div>
              ) : (
                <div className="rounded-lg border border-emerald-400/30 bg-emerald-400/10 p-2.5 text-emerald-200">
                  ✓ مسیر کاملاً آنلاین و سالم است — تأخیر کل {path.totalLat}ms
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
