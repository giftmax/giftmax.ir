"use client";

import { useState } from "react";
import Link from "next/link";
import { useRouter as _u } from "next/navigation";
import { Router, Plus, Waypoints, Trash2, Cable } from "lucide-react";
import { useDevices, type Dev } from "@/app/servers/page";
import { Spark } from "@/components/charts";
import { PageHead, Section, Skeleton, KindChip, KindIcon, Toggle, Empty } from "@/components/ui";
import KindCharts from "@/components/KindCharts";
import { fmtRate, KIND_FA } from "@/lib/format";

const FILTERS = ["all", "cisco", "mikrotik", "switch", "firewall", "esxi", "windows", "server", "vm", "other"] as const;

export default function DevicesPage() {
  const { data, reload } = useDevices();
  const [filter, setFilter] = useState<(typeof FILTERS)[number]>("all");
  const [showForm, setShowForm] = useState(false);
  const [msg, setMsg] = useState("");
  const [form, setForm] = useState({ name: "", ip: "", kind: "cisco", snmp: true, wmi: false, ilo: false, community: "public", osVersion: "" });

  if (!data) return <div className="space-y-4"><Skeleton h={80} /><Skeleton h={260} /></div>;

  const devs = data.devices;
  const rows = devs.filter((d) => filter === "all" || d.kind === filter);

  const add = async () => {
    const res = await (await fetch("/api/devices", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ...form, rangeId: 1 }),
    })).json();
    if (res.ok) { setShowForm(false); setMsg(`تجهیز «${form.name}» ثبت شد — تب مخصوص ${KIND_FA[form.kind]} فعال است`); setForm({ name: "", ip: "", kind: "cisco", snmp: true, wmi: false, ilo: false, community: "public", osVersion: "" }); reload(); }
    else setMsg(res.error ?? "خطا");
  };
  const del = async (id: number) => {
    if (!confirm("تجهیز حذف شود؟")) return;
    await fetch(`/api/devices?id=${id}`, { method: "DELETE" });
    reload();
  };
  const toggle = async (id: number, field: string) => {
    await fetch("/api/devices", { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id, field }) });
    reload();
  };

  return (
    <div className="space-y-6">
      <PageHead
        title="تجهیزات شبکه"
        sub="هنگام ثبت، نوع تجهیز را مشخص کنید (سیسکو، میکروتیک، سوئیچ، فایروال، سرور…) تا تب و قواعد پایش مخصوص همان دسته فعال شود. دسترسی SNMP/WMI/iLO برای لاگ‌گیری عمیق قابل تعریف است."
        chips={<button className="btn !py-2" onClick={() => setShowForm(!showForm)}><Plus size={15} /> افزودن تجهیز</button>}
      />

      {msg && <div className="glass fade-up p-3 text-[12px] text-emerald-300">{msg}</div>}

      <KindCharts title="نمودارهای پایش زنده تفکیک‌شده — هر نوع تجهیز یک نمودار مستقل" />

      {showForm && (
        <div className="glass fade-up p-5">
          <Section icon={Plus} title="ثبت تجهیز جدید" sub="نوع تجهیز تعیین‌کننده دسته‌بندی تب‌ها و پارامترهای پایش است" />
          <div className="grid gap-3 md:grid-cols-3">
            <input className="input" placeholder="نام (مثلاً SW-ACC-04)" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
            <input className="input mono" dir="ltr" placeholder="IP مدیریتی — 192.168.1.4" value={form.ip} onChange={(e) => setForm({ ...form, ip: e.target.value })} />
            <select className="input" value={form.kind} onChange={(e) => setForm({ ...form, kind: e.target.value })}>
              {Object.entries(KIND_FA).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
            </select>
            <input className="input" placeholder="نسخه/مدل (IOS-XE 17.9 …)" value={form.osVersion} onChange={(e) => setForm({ ...form, osVersion: e.target.value })} />
            <input className="input mono" dir="ltr" placeholder="SNMP community" value={form.community} onChange={(e) => setForm({ ...form, community: e.target.value })} />
            <div className="flex flex-wrap items-center gap-4 text-[12px] text-slate-300">
              <label className="flex items-center gap-2">SNMP<Toggle on={form.snmp} onChange={() => setForm({ ...form, snmp: !form.snmp })} /></label>
              <label className="flex items-center gap-2">WMI<Toggle on={form.wmi} onChange={() => setForm({ ...form, wmi: !form.wmi })} /></label>
              <label className="flex items-center gap-2">iLO<Toggle on={form.ilo} onChange={() => setForm({ ...form, ilo: !form.ilo })} /></label>
            </div>
          </div>
          <div className="mt-4 flex gap-2">
            <button className="btn" onClick={add}>ثبت تجهیز</button>
            <button className="btn btn-ghost" onClick={() => setShowForm(false)}>انصراف</button>
          </div>
        </div>
      )}

      <div className="fade-up fade-up-1 flex flex-wrap gap-2">
        {FILTERS.map((f) => (
          <button key={f} className={`tab-btn !border !text-[12px] ${filter === f ? "active" : "!border-slate-500/15"}`} onClick={() => setFilter(f)}>
            {f === "all" ? `همه (${devs.length})` : `${KIND_FA[f]} (${devs.filter((d) => d.kind === f).length})`}
          </button>
        ))}
      </div>

      {!rows.length ? (
        <Empty text="تجهیزی در این دسته ثبت نشده است" />
      ) : (
        <div className="fade-up fade-up-2 grid gap-4 md:grid-cols-2 xl:grid-cols-3">
          {rows.map((d) => <DeviceCard key={d.id} d={d} onToggle={toggle} onDel={del} />)}
        </div>
      )}
    </div>
  );
}

function DeviceCard({ d, onToggle, onDel }: { d: Dev; onToggle: (id: number, f: string) => void; onDel: (id: number) => void }) {
  return (
    <div className="glass glass-hover p-4">
      <div className="flex items-start justify-between">
        <div className="flex items-center gap-3">
          <span className="grid h-11 w-11 place-items-center rounded-xl border border-slate-400/20 bg-slate-400/5"><KindIcon kind={d.kind} size={20} /></span>
          <div>
            <div className="text-[13.5px] font-bold text-slate-100">{d.name}</div>
            <div className="mono mt-0.5 text-[11px] text-slate-500">{d.ip}</div>
          </div>
        </div>
        <div className="flex items-center gap-1.5">
          <span className={`h-2.5 w-2.5 rounded-full ${d.online ? "bg-emerald-400" : "bg-rose-400"}`} title={d.online ? "آنلاین" : "آفلاین"} />
          <button onClick={() => onDel(d.id)} className="rounded-lg p-1.5 text-slate-600 hover:bg-rose-500/10 hover:text-rose-300"><Trash2 size={14} /></button>
        </div>
      </div>
      <div className="mt-2 flex items-center gap-2">
        <KindChip kind={d.kind} />
        {d.osVersion && <span className="chip !text-[10px]">{d.osVersion}</span>}
      </div>
      <div className="mt-3 flex items-end justify-between" dir="ltr">
        <Spark data={d.spark} color={d.online ? "#22d3ee" : "#64748b"} w={130} h={38} />
        <div className="text-left">
          <div className="mono text-[13px] font-bold text-cyan-200">{fmtRate(d.rate)}</div>
          <div className="text-[10px] text-slate-500">{d.online ? `تأخیر ${d.lat}ms` : "آفلاین"}</div>
        </div>
      </div>
      <div className="mt-3 flex items-center justify-between border-t border-slate-500/10 pt-3">
        <div className="flex items-center gap-3 text-[10.5px] text-slate-400">
          <span className="flex items-center gap-1.5">SNMP <Toggle on={d.snmp} onChange={() => onToggle(d.id, "snmp")} /></span>
          <span className="flex items-center gap-1.5">WMI <Toggle on={d.wmi} onChange={() => onToggle(d.id, "wmi")} /></span>
          <span className="flex items-center gap-1.5">iLO <Toggle on={d.ilo} onChange={() => onToggle(d.id, "ilo")} /></span>
        </div>
        <Link href={`/routes?to=${d.ip}&from=192.168.1.50`} className="chip hover:!border-cyan-400/40 hover:!text-cyan-300">
          <Waypoints size={11} /> مشاهده مسیر
        </Link>
      </div>
      <div className="mt-2 flex items-center gap-1.5 text-[10px] text-slate-600">
        <Cable size={11} /> community: <span className="mono">{d.community}</span>
      </div>
    </div>
  );
}
