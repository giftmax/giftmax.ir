"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Activity, Lock, User, LogIn } from "lucide-react";

export default function LoginPage() {
  const router = useRouter();
  const [u, setU] = useState("");
  const [p, setP] = useState("");
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setErr("");
    const res = await (await fetch("/api/auth", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ username: u, password: p }),
    })).json();
    setBusy(false);
    if (res.ok) {
      router.replace("/");
      router.refresh();
    } else setErr(res.error ?? "خطا در ورود");
  };

  return (
    <div className="grid min-h-screen place-items-center px-4">
      <div className="glass fade-up w-full max-w-sm p-7">
        <div className="mb-6 flex flex-col items-center gap-2 text-center">
          <span className="grid h-14 w-14 place-items-center rounded-2xl border border-cyan-400/40 bg-gradient-to-br from-cyan-400/25 to-violet-500/20 shadow-[0_0_30px_-6px_rgba(34,211,238,0.6)]">
            <Activity size={26} className="text-cyan-300" />
          </span>
          <h1 className="text-[17px] font-extrabold"><span className="glow-text">HDMAX NetWatch Pro</span></h1>
          <p className="text-[11px] text-slate-500">سامانه جامع مانیتورینگ و پایش رخداد و ثبت — مکس‌پلاس</p>
        </div>
        <form onSubmit={submit} className="space-y-3">
          <div className="relative">
            <User size={15} className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-500" />
            <input className="input !pr-10" placeholder="نام کاربری" value={u} onChange={(e) => setU(e.target.value)} autoFocus autoComplete="username" />
          </div>
          <div className="relative">
            <Lock size={15} className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-500" />
            <input className="input !pr-10" type="password" placeholder="رمز عبور" value={p} onChange={(e) => setP(e.target.value)} autoComplete="current-password" />
          </div>
          {err && <div className="rounded-xl border border-rose-400/30 bg-rose-400/10 px-3 py-2 text-[12px] text-rose-200">{err}</div>}
          <button className="btn w-full !py-2.5" disabled={busy}>
            <LogIn size={15} /> {busy ? "در حال بررسی…" : "ورود به سامانه"}
          </button>
        </form>
        <p className="mt-4 text-center text-[10.5px] text-slate-600">
          کاربر پیش‌فرض: <b className="mono text-slate-400">admin</b> / رمز: <b className="mono text-slate-400">admin</b> — پس از ورود از بخش «تنظیمات و کاربران» آن را تغییر دهید
        </p>
      </div>
    </div>
  );
}
