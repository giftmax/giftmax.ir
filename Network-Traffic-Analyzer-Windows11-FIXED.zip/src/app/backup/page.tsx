"use client";

import { useState } from "react";
import { ArchiveRestore, Save, Play, Eye, FolderOpen, CalendarClock, X, DatabaseBackup } from "lucide-react";
import { usePoll } from "@/lib/useEngine";
import { PageHead, Section, Skeleton, Empty } from "@/components/ui";
import { EVT_FA, faDateTime, faTime, fmtBytes, fmtInt } from "@/lib/format";

type Resp = { ok: boolean; files: { name: string; size: number; mtime: number; fa: string }[]; settings: { dir: string; daily: string; weekly: number; monthly: number } };
type View = { ok: boolean; meta?: Record<string, unknown>; counts?: { events: number; ranges: number; devices: number; dns: number }; events?: { ts: number; srcIp: string; dstIp: string; type: string; severity: string; detail: string }[]; error?: string };
const DOW = ["یکشنبه", "دوشنبه", "سه‌شنبه", "چهارشنبه", "پنجشنبه", "جمعه", "شنبه"];

export default function BackupPage() {
  const { data, reload } = usePoll<Resp>(async () => (await fetch("/api/backup")).json(), 12000, []);
  const [dir, setDir] = useState("");
  const [daily, setDaily] = useState("03:00");
  const [msg, setMsg] = useState("");
  const [busy, setBusy] = useState("");
  const [view, setView] = useState<View | null>(null);

  const save = async () => {
    const res = await (await fetch("/api/backup", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ dir: dir || null, daily }) })).json();
    setMsg(res.ok ? "تنظیمات پشتیبان‌گیری ذخیره شد" : res.error ?? "خطا");
    reload();
  };
  const run = async (kind: string) => {
    setBusy(kind);
    const res = await (await fetch("/api/backup", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ op: "run", kind }) })).json();
    setBusy("");
    setMsg(res.ok ? `پشتیبان‌گیری انجام شد: ${res.name} (${fmtBytes(res.size)} فشرده)` : res.error ?? "خطا");
    reload();
  };
  const openView = async (name: string) => {
    setView(null);
    const v: View = await (await fetch(`/api/backup?view=${encodeURIComponent(name)}`)).json();
    setView(v);
  };

  if (!data) return <div className="space-y-4"><Skeleton h={90} /><Skeleton h={240} /></div>;

  return (
    <div className="space-y-6">
      <PageHead
        title="پشتیبان‌گیری و بازیابی"
        sub="بکاپ خودکار روزانه در ساعت تنظیم‌شده + فول‌بکاپ هفتگی و ماهانه — فایل‌ها فشرده (gzip) هستند و قابل بازخوانی برای مشاهده لاگ‌ها"
        chips={<span className="chip mono" dir="ltr"><FolderOpen size={12} /> {data.settings.dir}</span>}
      />

      <div className="grid gap-4 xl:grid-cols-3">
        <div className="glass fade-up p-5">
          <Section icon={CalendarClock} title="زمان‌بندی و مسیر" />
          <div className="space-y-3">
            <div>
              <label className="mb-1.5 block text-[11px] text-slate-500">مسیر ذخیره پشتیبان‌ها</label>
              <input className="input mono" dir="ltr" value={dir || data.settings.dir} onChange={(e) => setDir(e.target.value)} />
            </div>
            <div>
              <label className="mb-1.5 block text-[11px] text-slate-500">ساعت پشتیبان روزانه</label>
              <input className="input mono !w-32" dir="ltr" value={daily || data.settings.daily} onChange={(e) => setDaily(e.target.value)} placeholder="03:00" />
            </div>
            <div className="rounded-xl border border-slate-500/15 bg-slate-500/5 p-3 text-[11px] leading-5 text-slate-400">
              روزانه: هر روز ساعت <b className="mono">{data.settings.daily}</b> • هفتگی (فول): روز <b>{DOW[data.settings.weekly]}</b> هر هفته • ماهانه (فول): روز <b>{data.settings.monthly}ام</b> هر ماه — حذف خودکار از دیتابیس طبق بازه نگهداشت لاگ (حداکثر ۳ ماه) انجام می‌شود.
            </div>
            <button className="btn" onClick={save}><Save size={14} /> ذخیره تنظیمات</button>
            {msg && <p className="text-[12px] text-emerald-300">{msg}</p>}
          </div>
        </div>

        <div className="glass fade-up fade-up-1 p-5">
          <Section icon={Play} title="پشتیبان فوری" sub="خروجی فشرده gzip شامل رنج‌ها، تجهیزات، DNS، درخت و رویدادها" />
          <div className="grid gap-2">
            <button className="btn justify-start" onClick={() => run("daily")} disabled={!!busy}><DatabaseBackup size={15} /> {busy === "daily" ? "…" : "پشتیبان روزانه (اکنون)"}</button>
            <button className="btn justify-start" onClick={() => run("weekly")} disabled={!!busy}><DatabaseBackup size={15} /> {busy === "weekly" ? "…" : "فول‌بکاپ هفتگی (اکنون)"}</button>
            <button className="btn justify-start" onClick={() => run("monthly")} disabled={!!busy}><DatabaseBackup size={15} /> {busy === "monthly" ? "…" : "فول‌بکاپ ماهانه (اکنون)"}</button>
          </div>
          <p className="mt-3 text-[10.5px] leading-5 text-slate-500">لاگ‌های روزهای قبل نیز به‌صورت خودکار با gzip فشرده می‌شوند تا حجم ذخیره‌سازی حداقل بماند.</p>
        </div>

        <div className="glass fade-up fade-up-2 p-5 xl:col-span-1">
          <Section icon={ArchiveRestore} title="فایل‌های پشتیبان" sub={`${fmtInt(data.files.length)} فایل موجود`} />
          <div className="scroll-thin max-h-[280px] space-y-2 overflow-auto">
            {data.files.map((f) => (
              <button key={f.name} onClick={() => openView(f.name)} className="flex w-full items-center justify-between gap-2 rounded-xl border border-slate-500/15 bg-slate-500/5 px-3 py-2 text-right transition-colors hover:border-cyan-400/30">
                <div className="min-w-0">
                  <div className="mono truncate text-[11px] text-cyan-300" dir="ltr">{f.name}</div>
                  <div className="mt-0.5 text-[10px] text-slate-500">{f.fa} — {faTime(f.mtime)}</div>
                </div>
                <span className="chip flex-none !text-[10px]" dir="ltr">{fmtBytes(f.size)}</span>
              </button>
            ))}
            {!data.files.length && <Empty text="هنوز نسخه پشتیبانی ساخته نشده — یکی از دکمه‌های «پشتیبان فوری» را بزنید" />}
          </div>
        </div>
      </div>

      {view && (
        <div className="glass fade-up p-5">
          <Section
            icon={Eye}
            title={view.ok ? "بازخوانی نسخه پشتیبان (نمایش لاگ‌ها)" : "خطا"}
            sub={view.ok ? `زمان تهیه: ${view.meta?.t ? faDateTime(Number(view.meta.t)) : "—"} — ${JSON.stringify(view.meta?.kind ?? "")}` : view.error}
            action={<button className="rounded-lg p-1.5 text-slate-500 hover:text-slate-200" onClick={() => setView(null)}><X size={16} /></button>}
          />
          {view.ok && view.counts && (
            <>
              <div className="mb-4 grid grid-cols-2 gap-2 md:grid-cols-4">
                {[["رویدادها", view.counts.events], ["رنج‌ها", view.counts.ranges], ["تجهیزات", view.counts.devices], ["رکورد DNS", view.counts.dns]].map(([l, v]) => (
                  <div key={String(l)} className="rounded-xl border border-slate-500/15 bg-slate-500/5 p-3 text-center">
                    <div className="text-[18px] font-extrabold text-cyan-200" dir="ltr">{fmtInt(Number(v))}</div>
                    <div className="text-[10.5px] text-slate-500">{String(l)}</div>
                  </div>
                ))}
              </div>
              <div className="scroll-thin max-h-[360px] overflow-auto">
                <table className="table-base !text-[11.5px]">
                  <thead><tr><th>زمان</th><th>مبدأ</th><th>مقصد</th><th>نوع</th><th>جزئیات</th></tr></thead>
                  <tbody>
                    {(view.events ?? []).slice().reverse().map((e, i) => (
                      <tr key={i}>
                        <td className="mono text-slate-400">{faDateTime(e.ts * 1000 || e.ts)}</td>
                        <td className="mono text-slate-200">{e.srcIp}</td>
                        <td className="mono text-rose-300">{e.dstIp}</td>
                        <td><span className="chip !text-[10px]">{EVT_FA[e.type] ?? e.type}</span></td>
                        <td className="max-w-[320px] truncate text-slate-400" title={e.detail}>{e.detail}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </>
          )}
        </div>
      )}
    </div>
  );
}
