"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { RadioTower, Plus, Activity, ServerCrash, X, Waves } from "lucide-react";
import { useDevices, type Dev } from "@/app/servers/page";
import { Spark } from "@/components/charts";
import { PageHead, Section, Skeleton, Empty } from "@/components/ui";
import { fmtRate, faHM } from "@/lib/format";

type TraceNode = { name: string; ip: string; lat: number; role: string };
type Trace = { ok: boolean; nodes: TraceNode[]; hops: number; totalLat: number };

export default function FiberPage() {
  const { data, reload } = useDevices();
  const [form, setForm] = useState({ name: "", ip: "" });
  const [showForm, setShowForm] = useState(false);
  const [msg, setMsg] = useState("");
  const [trace, setTrace] = useState<Record<string, Trace>>({});

  const fibers = (data?.devices ?? []).filter((d) => d.kind === "fiber");

  // Traceroute خودکار وقتی لبه آفلاین شد
  useEffect(() => {
    fibers.filter((f) => !f.online && !trace[f.ip]).forEach(async (f) => {
      try {
        const t: Trace = await (await fetch(`/api/trace?src=192.168.1.1&dst=${encodeURIComponent(f.ip)}`)).json();
        setTrace((s) => ({ ...s, [f.ip]: t }));
      } catch { /* بعداً */ }
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [data]);

  const add = async () => {
    if (!form.name || !form.ip) return;
    const res = await (await fetch("/api/devices", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name: `${form.name} (لبه فیبر)`, ip: form.ip, kind: "fiber", snmp: true }),
    })).json();
    if (res.ok) { setShowForm(false); setForm({ name: "", ip: "" }); setMsg("لبه فیبر منطقه ثبت و پایش آنی آغاز شد"); reload(); }
    else setMsg(res.error ?? "خطا");
  };

  if (!data) return <div className="space-y-4"><Skeleton h={90} /><Skeleton h={260} /></div>;

  return (
    <div className="space-y-6">
      <PageHead
        title="مانیتورینگ لبه فیبر مناطق"
        sub="پایش آنی آپلینک فیبر هر منطقه: سبز = پینگ برقرار، قرمز = قطع — به‌محض قطعی، Traceroute خودکار نشان می‌دهد دقیقاً در کدام گذرگاه TimeOut می‌دهد"
        chips={<button className="btn !py-2" onClick={() => setShowForm(!showForm)}><Plus size={15} /> افزودن لبه فیبر منطقه</button>}
      />

      {msg && <div className="glass fade-up p-3 text-[12px] text-emerald-300">{msg}</div>}

      {showForm && (
        <div className="glass fade-up p-5">
          <Section icon={Plus} title="ثبت دستگاه لبه فیبر منطقه" />
          <div className="flex flex-wrap items-end gap-3">
            <input className="input !w-64" placeholder="نام منطقه (مثلاً شعبه ونک)" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
            <input className="input mono !w-56" dir="ltr" placeholder="IP لبه — 10.25.0.1" value={form.ip} onChange={(e) => setForm({ ...form, ip: e.target.value })} />
            <button className="btn" onClick={add}>ثبت و آغاز پایش</button>
            <button className="btn btn-ghost" onClick={() => setShowForm(false)}>انصراف</button>
          </div>
        </div>
      )}

      {!fibers.length ? (
        <Empty text="هنوز لبه فیبری ثبت نشده — آی پی دستگاه لبه فیبر هر منطقه را وارد کنید تا پایش آنی (سبز/قرمز) فعال شود" />
      ) : (
        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
          {fibers.map((f) => (
            <FiberCard key={f.id} f={f} trace={trace[f.ip]} onCloseTrace={() => setTrace((s) => { const n = { ...s }; delete n[f.ip]; return n; })} />
          ))}
        </div>
      )}
    </div>
  );
}

function FiberCard({ f, trace, onCloseTrace }: { f: Dev; trace?: Trace; onCloseTrace: () => void }) {
  const [prevOnline, setPrevOnline] = useState(f.online);
  useEffect(() => { setPrevOnline(f.online); }, [f.online]);
  const restored = prevOnline !== f.online && f.online;
  const stab = f.stabPct ?? 100;

  return (
    <div className={`glass glass-hover relative overflow-hidden border-t-4 p-5`} style={{ borderTopColor: f.online ? "#34d399" : "#fb7185" }}>
      <div className="flex items-start justify-between">
        <div className="flex items-center gap-3">
          <span className={`relative grid h-12 w-12 place-items-center rounded-2xl border ${f.online ? "border-emerald-400/40 bg-emerald-400/10" : "border-rose-400/50 bg-rose-400/15"}`}>
            <RadioTower size={22} className={f.online ? "text-emerald-300" : "text-rose-300"} />
            <i className={`absolute -left-1 -top-1 ${f.online ? "live-dot" : "live-dot-red"}`} />
          </span>
          <div>
            <div className="text-[14px] font-bold text-slate-100">{f.name}</div>
            <Link href={`/ip/${f.ip}`} className="mono text-[11.5px] text-cyan-300 hover:underline">{f.ip}</Link>
            <div className="mt-0.5 text-[10px] text-slate-500">{f.online ? `پینگ: ${f.lat}ms` : "پاسخ پینگ قطع شد"}</div>
          </div>
        </div>
        <span className="chip" style={f.online ? { color: "#34d399", borderColor: "#34d39944", background: "#34d39910" } : { color: "#fb7185", borderColor: "#fb718544", background: "#fb718512" }}>
          {f.online ? "● سبز — برقرار" : "● قرمز — قطع"}
        </span>
      </div>

      <div className="mt-3 flex items-end justify-between" dir="ltr">
        <Spark data={f.spark} color={f.online ? "#e879f9" : "#64748b"} w={140} h={42} />
        <div className="text-left">
          <div className="mono text-[14px] font-bold text-fuchsia-200">{fmtRate(f.rate)}</div>
          <div className="text-[9.5px] text-slate-500">ترافیک لبه لحظه‌ای</div>
        </div>
      </div>

      <div className="mt-3 grid grid-cols-3 gap-1.5 text-center text-[10px]">
        <div className="rounded-lg border border-slate-500/15 bg-slate-500/5 p-2"><div className="text-slate-500">پایداری</div><div className={`mono mt-0.5 font-bold ${stab >= 99 ? "text-emerald-300" : stab >= 90 ? "text-amber-300" : "text-rose-300"}`} dir="ltr">{stab}%</div></div>
        <div className="rounded-lg border border-slate-500/15 bg-slate-500/5 p-2"><div className="text-slate-500">نشست ورودی</div><div className="mono mt-0.5 font-bold text-cyan-200" dir="ltr">{f.sessionsIn ?? "—"}</div></div>
        <div className="rounded-lg border border-slate-500/15 bg-slate-500/5 p-2"><div className="text-slate-500">نشست خروجی</div><div className="mono mt-0.5 font-bold text-violet-200" dir="ltr">{f.sessionsOut ?? "—"}</div></div>
      </div>

      {restored && (
        <div className="mt-2.5 rounded-lg border border-emerald-400/30 bg-emerald-400/10 p-2 text-center text-[11px] text-emerald-200">
          ✓ مسیر دوباره برقرار شد — پینگ {f.lat}ms
        </div>
      )}

      {!f.online && (
        <div className="mt-3 rounded-xl border border-rose-400/25 bg-rose-400/5 p-3">
          <div className="mb-2 flex items-center justify-between">
            <span className="flex items-center gap-1.5 text-[11.5px] font-bold text-rose-200"><ServerCrash size={13} /> Traceroute خودکار — محل گیر کردن:</span>
            <button onClick={onCloseTrace} className="rounded p-0.5 text-slate-500 hover:text-slate-200"><X size={13} /></button>
          </div>
          {!trace ? (
            <div className="shimmer h-14" />
          ) : (
            <div className="space-y-1 text-[10.5px]">
              {trace.nodes.map((n, i) => (
                <div key={i} className="flex items-center justify-between rounded-md border border-slate-500/10 bg-black/30 px-2 py-1">
                  <span className="text-slate-300">{i === 0 ? "🟢 مبدأ" : `${i}.`} {n.name}</span>
                  <span className="mono text-slate-400">{n.ip}</span>
                  <b className="mono text-emerald-300" dir="ltr">{n.lat}ms</b>
                </div>
              ))}
              <div className="rounded-md border border-rose-400/30 bg-rose-400/10 px-2 py-1.5 text-rose-200">
                ✕ TimeOut — از <span className="mono">{f.ip}</span> به بعد پاسخی نمی‌آید؛ مسیر تا آخرین گذرگاه بالا سالم است. اپلینک فیبر/تجهیز لبه منطقه را بررسی کنید.
              </div>
            </div>
          )}
        </div>
      )}

      {!!f.downWins?.length && (
        <div className="mt-2.5 text-[10px] text-slate-500">
          آخرین قطعی‌ها: {f.downWins.map((w, i) => <span key={i} className="chip mono ml-1 !text-[9px]">{faHM(w.s)} تا {faHM(w.e)}</span>)}
        </div>
      )}
      <div className="mt-2 flex items-center gap-1.5 text-[10px] text-slate-600"><Waves size={11} /> آپتایم ۹۹٫۹۹٪ ایده‌آل — زیر ۹۵٪ یعنی لینک منطقه نیازمند بررسی است</div>
    </div>
  );
}
