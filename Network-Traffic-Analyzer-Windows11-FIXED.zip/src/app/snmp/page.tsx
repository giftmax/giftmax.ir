"use client";

import { useState } from "react";
import { Network, Plus, Trash2, ShieldCheck, ShieldAlert, KeySquare, Pencil, Check, X } from "lucide-react";
import { usePoll } from "@/lib/useEngine";
import { PageHead, Section, Skeleton, KindChip, Toggle } from "@/components/ui";
import { KIND_FA, fmtInt } from "@/lib/format";

type Role = { id: number; name: string; deviceKind: string; version: string; user: string; authType: string; oids: string[]; acls: string[]; enabled: boolean };
type SDev = { id: number; name: string; ip: string; kind: string; snmp: boolean; community: string; version: string; acl: string; issues: { sev: string; msg: string }[]; score: number; off: boolean; role: { id: number; name: string; oids: string[] } | null };
type Resp = { ok: boolean; roles: Role[]; devices: SDev[] };

const OID_GROUPS = ["ifDescr", "ifInOctets", "ifOutOctets", "ifOperStatus", "uptime", "cpuLoad", "memFree", "hrSystemUptime", "hrMemorySize", "signalStrength", "noiseFloor", "wirelessClients", "channel", "txPower", "ccq", "opticRxPower", "opticTxPower", "temp", "ifTable", "hrDeviceDescr", "frequency", "clients"];

export default function SnmpPage() {
  const { data, reload } = usePoll<Resp>(async () => (await fetch("/api/snmp")).json(), 8000, []);
  const [editRole, setEditRole] = useState<Partial<Role> | null>(null);
  const [msg, setMsg] = useState("");
  const [busy, setBusy] = useState("");

  if (!data) return <div className="space-y-4"><Skeleton h={90} /><Skeleton h={300} /></div>;

  const saveRole = async () => {
    if (!editRole?.name) return;
    setBusy("role");
    const res = await (await fetch("/api/snmp", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(editRole) })).json();
    setBusy("");
    setMsg(res.ok ? `نقش SNMP «${editRole.name}» ذخیره شد و روی تجهیزات مطابق اعمال گردید` : res.error ?? "خطا");
    setEditRole(null);
    reload();
  };
  const delRole = async (id: number) => {
    await fetch(`/api/snmp?id=${id}`, { method: "DELETE" });
    reload();
  };
  const patchDev = async (id: number, patch: Record<string, unknown>) => {
    await fetch("/api/snmp", { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id, ...patch }) });
    reload();
  };

  const scoreColor = (s: number) => (s >= 80 ? "#34d399" : s >= 55 ? "#fbbf24" : "#fb7185");

  return (
    <div className="space-y-6">
      <PageHead
        title="مدیریت SNMP و نقش‌های گردآوری"
        sub="فعال‌سازی انتخابی SNMP برای هر تجهیز/سرور، نقش‌ها (Roles) با OID‌های اختصاصی هر نوع تجهیز، تغییر community، ارتقا به v3 و لیست دسترسی (ACL) — با امتیاز سخت‌سازی برای حداقل‌کردن آسیب‌پذیری"
        chips={<span className="chip"><Network size={12} /> Simple Network Management Protocol</span>}
      />
      {msg && <div className="glass fade-up p-3 text-[12px] text-emerald-300">{msg}</div>}

      {/* نقش‌ها */}
      <div className="glass fade-up p-5">
        <Section
          icon={KeySquare}
          title="نقش‌های SNMP (Roles)"
          sub="بر اساس نوع تجهیز، گروه‌های OID و نسخه پروتکل تعیین می‌کنند"
          action={<button className="btn !py-2 !text-[12px]" onClick={() => setEditRole({ name: "", deviceKind: "cisco", version: "v3", user: "netwatch", oids: ["ifInOctets", "ifOutOctets"], acls: ["192.168.1.0/24"], enabled: true })}><Plus size={14} /> نقش جدید</button>}
        />
        <div className="scroll-thin grid max-h-[300px] grid-cols-1 gap-3 overflow-auto md:grid-cols-2 xl:grid-cols-3">
          {data.roles.map((r) => (
            <div key={r.id} className={`rounded-xl border p-3.5 ${r.enabled ? "border-slate-500/15 bg-slate-500/5" : "border-slate-500/10 opacity-50"}`}>
              <div className="flex items-start justify-between">
                <div>
                  <div className="text-[12.5px] font-bold text-slate-100">{r.name}</div>
                  <div className="mt-0.5 text-[10px] text-slate-500">{KIND_FA[r.deviceKind] ?? "همه انواع"}</div>
                </div>
                <div className="flex items-center gap-1">
                  <button className="rounded-lg p-1.5 text-slate-500 hover:bg-cyan-500/10 hover:text-cyan-300" onClick={() => setEditRole(r)}><Pencil size={13} /></button>
                  <button className="rounded-lg p-1.5 text-slate-500 hover:bg-rose-500/10 hover:text-rose-300" onClick={() => delRole(r.id)}><Trash2 size={13} /></button>
                </div>
              </div>
              <div className="mt-2 flex flex-wrap gap-1">
                <span className="chip !text-[9.5px]" style={r.version === "v3" ? { color: "#34d399" } : { color: "#fbbf24" }}>{r.version === "v3" ? "v3 (AuthPriv)" : r.version}</span>
                {r.user && <span className="chip mono !text-[9.5px]" dir="ltr">user: {r.user}</span>}
                {r.acls.map((a) => <span key={a} className="chip mono !text-[9.5px]" dir="ltr">ACL: {a}</span>)}
              </div>
              <div className="mt-1.5 flex flex-wrap gap-1">
                {r.oids.map((o) => <span key={o} className="rounded bg-slate-500/10 px-1.5 py-0.5 text-[9px] text-slate-400 mono" dir="ltr">{o}</span>)}
              </div>
            </div>
          ))}
        </div>

        {editRole && (
          <div className="mt-4 rounded-xl border border-cyan-400/25 bg-cyan-400/5 p-4">
            <div className="mb-3 text-[13px] font-bold text-cyan-100">ویرایش/ایجاد نقش SNMP</div>
            <div className="grid gap-2.5 md:grid-cols-4">
              <input className="input" placeholder="نام نقش *" value={editRole.name ?? ""} onChange={(e) => setEditRole({ ...editRole, name: e.target.value })} />
              <select className="input" value={editRole.deviceKind ?? "all"} onChange={(e) => setEditRole({ ...editRole, deviceKind: e.target.value })}>
                <option value="all">همه انواع</option>
                {Object.entries(KIND_FA).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
              </select>
              <select className="input" value={editRole.version ?? "v2c"} onChange={(e) => setEditRole({ ...editRole, version: e.target.value })}>
                <option value="v3">v3 — توصیه‌شده (SHA-256/AES-256)</option>
                <option value="v2c">v2c — community</option>
                <option value="v1">v1 — نامناسب</option>
              </select>
              <input className="input mono" dir="ltr" placeholder="کاربر v3 (اختیاری)" value={editRole.user ?? ""} onChange={(e) => setEditRole({ ...editRole, user: e.target.value })} />
              <input className="input mono md:col-span-2" dir="ltr" placeholder="OIDها با ویرگول" value={(editRole.oids ?? []).join(", ")} onChange={(e) => setEditRole({ ...editRole, oids: e.target.value.split(",").map((x) => x.trim()).filter(Boolean) })} />
              <input className="input mono md:col-span-1" dir="ltr" placeholder="ACL مبدا: 192.168.1.0/24" value={(editRole.acls ?? []).join(", ")} onChange={(e) => setEditRole({ ...editRole, acls: e.target.value.split(",").map((x) => x.trim()).filter(Boolean) })} />
              <div className="flex items-center gap-2">
                <Toggle on={editRole.enabled !== false} onChange={() => setEditRole({ ...editRole, enabled: !(editRole.enabled !== false) })} />
                <span className="text-[11px] text-slate-400">فعال</span>
              </div>
            </div>
            <div className="mt-2 flex flex-wrap gap-1">
              {OID_GROUPS.map((o) => (
                <button key={o} className="chip mono !text-[9px] opacity-60 hover:opacity-100" onClick={() => setEditRole({ ...editRole, oids: [...new Set([...(editRole.oids ?? []), o])] })}>+{o}</button>
              ))}
            </div>
            <div className="mt-3 flex gap-2">
              <button className="btn" onClick={saveRole} disabled={busy === "role"}><Check size={14} /> {busy === "role" ? "ذخیره…" : "ذخیره نقش"}</button>
              <button className="btn btn-ghost" onClick={() => setEditRole(null)}><X size={14} /> انصراف</button>
            </div>
          </div>
        )}
      </div>

      {/* تجهیزات */}
      <div className="glass fade-up fade-up-1 p-5">
        <Section icon={ShieldCheck} title="تجهیزات — وضعیت SNMP و آسیب‌پذیری" sub="ستون «امتیاز سخت‌سازی»: ۱۰۰ یعنی بدون آسیب‌پذیری شناخته‌شده" />
        <div className="scroll-thin max-h-[480px] overflow-auto">
          <table className="table-base">
            <thead><tr><th>تجهیز</th><th>IP</th><th>نوع</th><th>SNMP</th><th>نسخه</th><th>Community</th><th>ACL مبدا</th><th>امتیاز</th><th>نقاط ضعف</th></tr></thead>
            <tbody>
              {data.devices.map((d) => (
                <tr key={d.id}>
                  <td className="max-w-[170px] truncate text-slate-200">{d.name}</td>
                  <td className="mono text-cyan-300">{d.ip}</td>
                  <td><KindChip kind={d.kind} /></td>
                  <td><Toggle on={d.snmp} onChange={() => patchDev(d.id, { snmp: !d.snmp })} /></td>
                  <td>
                    {d.off ? <span className="text-slate-600">—</span> : (
                      <select className="input !w-24 !py-1 !text-[10.5px]" value={d.version} onChange={(e) => patchDev(d.id, { version: e.target.value })}>
                        {["v1", "v2c", "v3"].map((v) => <option key={v} value={v}>{v}</option>)}
                      </select>
                    )}
                  </td>
                  <td className="mono text-[11px]" style={{ color: d.community === "public" ? "#fb7185" : "#34d399" }} dir="ltr">{d.community === "public" ? "public !" : "•••••"}</td>
                  <td>
                    {d.off ? <span className="text-slate-600">—</span> : (
                      <input className="input mono !w-36 !py-1 !text-[10.5px]" dir="ltr" defaultValue={d.acl} placeholder="192.168.1.0/24" onBlur={(e) => e.target.value !== d.acl && patchDev(d.id, { acl: e.target.value })} />
                    )}
                  </td>
                  <td>
                    <span className="chip mono" style={{ color: d.off ? "#94a3b8" : scoreColor(d.score), borderColor: "currentColor" }} dir="ltr">{d.off ? "خاموش" : `${d.score}/100`}</span>
                  </td>
                  <td className="max-w-[280px]">
                    {d.off ? <span className="text-[10.5px] text-emerald-300 flex items-center gap-1"><ShieldCheck size={12} /> بدون سطح حمله</span> : d.issues.length ? (
                      <div className="space-y-0.5">
                        {d.issues.map((i, k) => (
                          <div key={k} className="flex items-start gap-1.5 text-[10px] leading-4" style={{ color: i.sev === "high" ? "#fb7185" : i.sev === "medium" ? "#fbbf24" : "#94a3b8" }}>
                            <ShieldAlert size={10} className="mt-0.5 flex-none" /> {i.msg}
                          </div>
                        ))}
                      </div>
                    ) : (
                      <span className="text-[10.5px] text-emerald-300 flex items-center gap-1"><ShieldCheck size={12} /> سالم</span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <p className="mt-3 text-[11px] leading-5 text-slate-500">توصیه‌های سخت‌سازی که سامانه پایش و امتیازدهی می‌کند: حذف community پیش‌فرض، اجبار SNMPv3 با AuthPriv، محدود کردن مبدا کلکتور با ACL، حداقل‌بودن پروتکل‌های هم‌زمان (SNMP/WMI) و دیده‌بانی مخصوص به تزریق GetBulk.</p>
      </div>
    </div>
  );
}
