import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import Shell from "@/components/Shell";
import "./globals.css";

export const metadata: Metadata = {
  title: "NADIR NetWatch — مرکز پایش یکپارچه شبکه",
  description:
    "پایش لحظه‌ای پهنای باند رنج‌های IP، شناسایی IPهای مشکوک، مانیتورینگ سرورها و ESXi، رخدادهای امنیتی و ردیابی مسیر شبکه",
};

export const viewport: Viewport = {
  themeColor: "#05070e",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="fa" dir="rtl">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Vazirmatn:wght@300;400;500;600;700;800&family=JetBrains+Mono:wght@400;600&display=swap"
          rel="stylesheet"
        />
      </head>
      <body className="antialiased">
        <Shell>{children}</Shell>
      </body>
    </html>
  );
}
