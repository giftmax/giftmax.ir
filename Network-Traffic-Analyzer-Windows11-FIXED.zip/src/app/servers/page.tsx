"use client";

import { useState } from "react";
import Link from "next/link";
import { Server, Plus, ShieldCheck, Cpu, Box, KeyRound, Network, FolderTree, BadgeCheck } from "lucide-react";
import { usePoll } from "@/lib/useEngine";
import { LiveChart, Spark, type LivePoint } from "@/components/charts";
import { PageHead, Section, Skeleton, KindChip, Toggle, Empty } from "@/components/ui";
import { fmtRate, fmtInt, KIND_FA } from "@/lib/format";

export type Dev = {
  id: number; name: string; ip: string; kind: string; rangeId: number | null; parentId: number | null;
  isDomain: boolean; snmp: boolean; wmi: boolean; ilo: boolean; community: string; osVersion: string | null;
  online: boolean; lat: number; i: number; o: number; rate: number; spark: number[]; vms: Dev[];
  sessions?: number; sessionsIn?: number; sessionsOut?: number; stabPct?: number;
  downOpen?: number | null; downWins?: { s: number; e: number }[];
  authPeers?: { ip: string; name: string; i: number; o: number; hits: number; last: number }[];
};

export function useDevices() {
  return usePoll<{ ok: boolean; devices: Dev[] }>(async () => (await fetch("/api/devices")).json(), 3000, []);
}

export function OnlineDot({ online }: { online: boolean }) {
  return (
    <span className="chip !text-[10px]" style={online ? { color: "#34d399", borderColor: "#34d39940", background: "#34d39910" } : { color: "#fb7185", borderColor: "#fb718540", background: "#fb718512" }}>
      <i className={online ? "live-dot" : "live-dot-red"} />
      {online ? "آنلاین" : "آفلاین"}
    </span>
  );
}

export default function ServersPage() {
  const { data, reload } = useDevices();
  const [hist, setHist] = useState<LivePoint[]>([]);
  const [msg, setMsg] = useState("");
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ name: "", ip: "", kind: "server", parentId: "", isDomain: false, snmp: true, wmi: false, ilo: false, osVersion: "", nodeId: "" });
  const { data: treeData } = usePoll<{ ok: boolean; nodes: { id: number; parentId: number | null; name: string; ips: string }[] }>(async () => (await fetch("/api/tree")).json(), 15000, []);

  // نمودار تجمیعی سرورها
  const [prev, setPrev] = useState<string>("");
  if (data && JSON.stringify(data.devices.map((d) => Math.round(d.rate))) !== prev) {
    setPrev(JSON.stringify(data.devices.map((d) => Math.round(d.rate))));
    const servers = data.devices.filter((d) => ["server", "windows", "esxi", "vm"].includes(d.kind));
    const i = servers.reduce((a, d) => a + d.i, 0);
    const o = servers.reduce((a, d) => a + d.o, 0);
    setHist((h) => [...h, { t: Date.now(), a: i, b: o }].slice(-300));
  }

  if (!data) return <div className="space-y-4"><Skeleton h={90} /><Skeleton h={220} /><Skeleton h={260} /></div>;

  const devs = data.devices;
  const domains = devs.filter((d) => d.isDomain);
  const esxis = devs.filter((d) => d.kind === "esxi");
  const servers = devs.filter((d) => ["server", "windows", "vm"].includes(d.kind) && !d.isDomain);
  const onlineCount = devs.filter((d) => d.online).length;
  const esxiOpts = devs.filter((d) => d.kind === "esxi");

  const toggle = async (id: number, field: string) => {
    await fetch("/api/devices", { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id, field }) });
    reload();
  };
  const add = async () => {
    const res = await (await fetch("/api/devices", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ...form, parentId: form.parentId ? Number(form.parentId) : null, rangeId: 2 }),
    })).json();
    if (res.ok && form.nodeId) {
      const node = treeData?.nodes.find((n) => n.id === Number(form.nodeId));
      if (node) {
        let ips: string[] = [];
        try { ips = JSON.parse(node.ips) as string[]; } catch { ips = []; }
        if (!ips.includes(form.ip)) {
          await fetch("/api/tree", { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id: node.id, ips: [...ips, form.ip] }) });
        }
      }
    }
    if (res.ok) { setShowForm(false); setMsg("سرور افزوده شد و پایش آغاز گردید" + (form.nodeId ? " و به گره درخت دامنه متصل شد" : "")); setForm({ name: "", ip: "", kind: "server", parentId: "", isDomain: false, snmp: true, wmi: false, ilo: false, osVersion: "", nodeId: "" }); reload(); }
    else setMsg(res.error ?? "خطا");
  };
  const del = async (id: number) => {
    if (!confirm("این سرور حذف شود؟")) return;
    await fetch(`/api/devices?id=${id}`, { method: "DELETE" });
    reload();
  };

  return (
    <div className="space-y-6">
      <PageHead
        title="سرورها و مجازی‌سازی"
        sub="پایش آنلاین‌بودن کنترلرهای دامین، میزبان‌های ESXi و ماشین‌های مجازی — با امکان فعال‌سازی SNMP، WMI و iLO برای هر سرور"
        chips={
          <>
            <span className="chip" style={{ color: "#34d399" }}>{fmtInt(onlineCount)} آنلاین</span>
            <span className="chip" style={{ color: "#fb7185" }}>{fmtInt(devs.length - onlineCount)} آفلاین</span>
            <button className="btn !py-2" onClick={() => setShowForm(!showForm)}><Plus size={15} /> افزودن سرور</button>
          </>
        }
      />

      {msg && <div className="glass fade-up p-3 text-[12px] text-emerald-300">{msg}</div>}

      {showForm && (
        <div className="glass fade-up p-5">
          <Section icon={Plus} title="افزودن سرور / ماشین مجازی" sub="برای VM بودن، میزبان ESXi را انتخاب کنید" />
          <div className="grid gap-3 md:grid-cols-3">
            <input className="input" placeholder="نام (مثلاً DC03 — کنترلر دامین)" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
            <input className="input mono" dir="ltr" placeholder="IP — 10.10.0.40" value={form.ip} onChange={(e) => setForm({ ...form, ip: e.target.value })} />
            <input className="input" placeholder="سیستم‌عامل / نسخه (اختیاری)" value={form.osVersion} onChange={(e) => setForm({ ...form, osVersion: e.target.value })} />
            <select className="input" value={form.kind} onChange={(e) => setForm({ ...form, kind: e.target.value })}>
              {["server", "windows", "vm", "esxi"].map((k) => <option key={k} value={k}>{KIND_FA[k]}</option>)}
            </select>
            <select className="input" value={form.parentId} onChange={(e) => setForm({ ...form, parentId: e.target.value })} disabled={form.kind !== "vm"}>
              <option value="">میزبان ESXi (برای VM)…</option>
              {esxiOpts.map((x) => <option key={x.id} value={x.id}>{x.name}</option>)}
            </select>
            <select className="input" value={form.nodeId} onChange={(e) => setForm({ ...form, nodeId: e.target.value })}>
              <option value="">گره درخت دامنه (اختیاری)…</option>
              {(treeData?.nodes ?? []).map((n) => <option key={n.id} value={n.id}><FolderTree size={10} className="inline" /> {n.name}</option>)}
            </select>
            <div className="flex flex-wrap items-center gap-4 text-[12px] text-slate-300">
              <label className="flex items-center gap-2">دامین<Toggle on={form.isDomain} onChange={() => setForm({ ...form, isDomain: !form.isDomain })} /></label>
              <label className="flex items-center gap-2">SNMP<Toggle on={form.snmp} onChange={() => setForm({ ...form, snmp: !form.snmp })} /></label>
              <label className="flex items-center gap-2">WMI<Toggle on={form.wmi} onChange={() => setForm({ ...form, wmi: !form.wmi })} /></label>
              <label className="flex items-center gap-2">iLO<Toggle on={form.ilo} onChange={() => setForm({ ...form, ilo: !form.ilo })} /></label>
            </div>
          </div>
          <div className="mt-4 flex gap-2">
            <button className="btn" onClick={add}>ثبت و آغاز پایش</button>
            <button className="btn btn-ghost" onClick={() => setShowForm(false)}>انصراف</button>
          </div>
        </div>
      )}

      <div className="glass fade-up p-5">
        <Section icon={Network} title="پهنای باند تجمیعی سرورها — زنده" sub="مجموع ترافیک لحظه‌ای همه سرورها، ESXi و ماشین‌های مجازی" />
        <LiveChart data={hist} height={180} colorA="#a78bfa" colorB="#34d399" />
      </div>

      {/* دامین کنترلرها */}
      <div>
        <Section icon={ShieldCheck} title="کنترلرهای دامین — وضعیت آنلاین" sub="هارت‌بیت هر ۲ ثانیه — مسئول احراز هویت سازمان" />
        {domains.length ? (
          <div className="fade-up fade-up-1 grid gap-4 md:grid-cols-2 xl:grid-cols-3">
            {domains.map((d) => (
              <div key={d.id} className="glass glass-hover p-4">
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-2.5">
                    <span className={`grid h-10 w-10 place-items-center rounded-xl border ${d.online ? "border-emerald-400/30 bg-emerald-400/10 text-emerald-300" : "border-rose-400/30 bg-rose-400/10 text-rose-300"}`}>
                      <KeyRound size={17} />
                    </span>
                    <div>
                      <div className="text-[13.5px] font-bold text-slate-100">{d.name}</div>
                      <div className="mono text-[11px] text-slate-500">{d.ip}</div>
                    </div>
                  </div>
                  <OnlineDot online={d.online} />
                </div>
                <div className="mt-3 flex items-end justify-between" dir="ltr">
                  <Spark data={d.spark} color={d.online ? "#34d399" : "#fb7185"} w={140} h={40} />
                  <div className="text-left">
                    <div className="mono text-[13px] font-bold text-emerald-200">{fmtRate(d.rate)}</div>
                    <div className="mt-0.5 text-[10px] text-slate-500">تأخیر {d.lat}ms</div>
                  </div>
                </div>
                <div className="mt-3 flex items-center justify-between border-t border-slate-500/10 pt-3 text-[10.5px] text-slate-500">
                  <span>{d.osVersion ?? "—"}</span>
                  <span className="flex gap-1.5">
                    {d.snmp && <span className="chip !text-[9.5px] !py-0.5 text-cyan-300">SNMP</span>}
                    {d.wmi && <span className="chip !text-[9.5px] !py-0.5 text-sky-300">WMI</span>}
                    {d.ilo && <span className="chip !text-[9.5px] !py-0.5 text-amber-300">iLO</span>}
                  </span>
                </div>
                {!!d.authPeers?.length && (
                  <div className="mt-2.5 rounded-xl border border-emerald-400/15 bg-emerald-400/5 p-2.5">
                    <div className="mb-1.5 flex items-center gap-1.5 text-[10px] font-semibold text-emerald-300"><BadgeCheck size={11} /> متقاضیان احراز هویت Active Directory (IPهای وصل‌شونده به این سرور):</div>
                    <div className="flex flex-wrap gap-1.5">
                      {d.authPeers.map((p) => (
                        <Link key={p.ip} href={`/ip/${p.ip}`} className="chip mono !text-[9.5px] hover:!border-cyan-400/40" dir="ltr">
                          <span className="text-cyan-300">{p.ip}</span>
                          <span className="text-slate-500">{p.hits}×</span>
                        </Link>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        ) : (
          <Empty text="هنوز کنترلر دامینی ثبت نشده — از دکمه «افزودن سرور» با گزینه «دامین» اضافه کنید" />
        )}
      </div>

      {/* ESXi */}
      <div>
        <Section icon={Cpu} title="میزبان‌های ESXi و ماشین‌های مجازی" sub="پایش هر VM در کنار میزبان خود — ترافیک، وضعیت و تأخیر" />
        <div className="fade-up fade-up-2 grid gap-4 xl:grid-cols-2">
          {esxis.map((h) => (
            <div key={h.id} className="glass p-5">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <span className="grid h-11 w-11 place-items-center rounded-xl border border-amber-400/30 bg-amber-400/10 text-amber-300"><Cpu size={19} /></span>
                  <div>
                    <div className="text-[14px] font-bold text-slate-100">{h.name}</div>
                    <div className="mono text-[11px] text-slate-500">{h.ip} — {h.osVersion}</div>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <span className="chip !text-[10px]" title="دسترسی iLO/ILO را فعال/غیرفعال می‌کند">iLO <Toggle on={h.ilo} onChange={() => toggle(h.id, "ilo")} /></span>
                  <OnlineDot online={h.online} />
                </div>
              </div>
              <div className="mt-3 grid grid-cols-3 gap-2 text-center text-[11px]">
                <div className="rounded-lg border border-slate-500/15 bg-slate-500/5 p-2"><div className="text-slate-500">ترافیک میزبان</div><div className="mono mt-0.5 font-bold text-amber-200" dir="ltr">{fmtRate(h.rate)}</div></div>
                <div className="rounded-lg border border-slate-500/15 bg-slate-500/5 p-2"><div className="text-slate-500">تعداد VM</div><div className="mono mt-0.5 font-bold text-slate-100" dir="ltr">{h.vms.length}</div></div>
                <div className="rounded-lg border border-slate-500/15 bg-slate-500/5 p-2"><div className="text-slate-500">تأخیر</div><div className="mono mt-0.5 font-bold text-cyan-200" dir="ltr">{h.lat}ms</div></div>
              </div>
              <div className="mt-3 space-y-2">
                {h.vms.map((v) => (
                  <div key={v.id} className="flex items-center justify-between gap-3 rounded-xl border border-slate-500/12 bg-slate-500/5 px-3 py-2.5">
                    <div className="flex min-w-0 items-center gap-2.5">
                      <Box size={15} className="flex-none text-violet-300" />
                      <div className="min-w-0">
                        <div className="truncate text-[12px] font-semibold text-slate-200">{v.name}</div>
                        <div className="mono text-[10px] text-slate-500">{v.ip}</div>
                      </div>
                    </div>
                    <div dir="ltr"><Spark data={v.spark} color="#a78bfa" w={90} h={22} /></div>
                    <div className="flex items-center gap-2">
                      <span className="mono w-24 text-left text-[11px] font-semibold text-violet-200" dir="ltr">{fmtRate(v.rate)}</span>
                      <OnlineDot online={v.online} />
                    </div>
                  </div>
                ))}
                {!h.vms.length && <p className="py-2 text-center text-[11.5px] text-slate-600">ماشین مجازی‌ای روی این میزبان ثبت نشده است</p>}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* جدول همه سرورها */}
      <div className="glass fade-up fade-up-3 p-5">
        <Section icon={Server} title="همه سرورها — کنترل پروتکل‌های مدیریتی" sub="فعال‌سازی SNMP/WMI/iLO برای لاگ‌گیری عمیق (درخواست‌ها با آژاکس اعمال می‌شوند)" />
        <div className="scroll-thin overflow-x-auto">
          <table className="table-base">
            <thead><tr><th>سرور</th><th>IP</th><th>نوع</th><th>وضعیت</th><th>تأخیر</th><th>ترافیک زنده</th><th>SNMP</th><th>WMI</th><th>iLO</th><th>دامین</th><th></th></tr></thead>
            <tbody>
              {[...domains, ...servers].map((d) => (
                <tr key={d.id}>
                  <td className="max-w-[200px] truncate font-semibold text-slate-200">{d.name}</td>
                  <td className="mono text-cyan-300">{d.ip}</td>
                  <td><KindChip kind={d.kind} /></td>
                  <td><OnlineDot online={d.online} /></td>
                  <td className="mono text-slate-300">{d.online ? `${d.lat}ms` : "—"}</td>
                  <td className="mono text-slate-200" dir="ltr">{fmtRate(d.rate)}</td>
                  <td><Toggle on={d.snmp} onChange={() => toggle(d.id, "snmp")} title="SNMP" /></td>
                  <td><Toggle on={d.wmi} onChange={() => toggle(d.id, "wmi")} title="WMI" /></td>
                  <td><Toggle on={d.ilo} onChange={() => toggle(d.id, "ilo")} title="iLO" /></td>
                  <td><Toggle on={d.isDomain} onChange={() => toggle(d.id, "isDomain")} title="کنترلر دامین" /></td>
                  <td><button className="chip hover:!border-rose-400/40 hover:!text-rose-300" onClick={() => del(d.id)}>حذف</button></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
