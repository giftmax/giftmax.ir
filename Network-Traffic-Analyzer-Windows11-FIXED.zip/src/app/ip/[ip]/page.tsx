"use client";

import { useState } from "react";
import Link from "next/link";
import { useParams } from "next/navigation";
import {
  ArrowRight, ArrowDownWideNarrow, ArrowUpNarrowWide, ShieldAlert, ShieldCheck, CircleOff,
  Clock3, CalendarClock, CalendarDays, PlugZap, Sigma, TrendingUp, Globe, Users, FileSearch,
} from "lucide-react";
import { usePoll } from "@/lib/useEngine";
import { LiveChart, Spark, Donut } from "@/components/charts";
import { PageHead, Section, Skeleton, SevBadge } from "@/components/ui";
import { fmtRate, fmtBytes, fmtInt, faTime, faHM, faDate, faDateTime } from "@/lib/format";

type PtH = { t: number; i: number; o: number; s: number };
type Hist = { points: PtH[]; totals: { i: number; o: number; peak: number; avg: number } };
type Peer = { ip: string; name: string; i: number; o: number; hits: number; last: number };
type Resp = {
  ok: boolean;
  detail: {
    ip: string; host: string; rangeName: string; rangeId: number | null;
    server: boolean; external: boolean;
    now: { i: number; o: number; s: number };
    cls: { label: string; reasons: string[]; score: number };
    spark: number[];
    protos: { name: string; pct: number }[];
    conns: { t: number; peer: string; proto: string; port: number; bytes: number; state: string }[];
    peers?: Peer[];
  };
  h1h: Hist; h24: Hist; h30: Hist;
};

type Win = "1h" | "24h" | "30d";
const WINS: { k: Win; label: string; icon: typeof Clock3; timeFmt: (t: number) => string }[] = [
  { k: "1h", label: "۱ ساعت اخیر", icon: Clock3, timeFmt: faTime },
  { k: "24h", label: "۲۴ ساعت اخیر", icon: CalendarClock, timeFmt: faHM },
  { k: "30d", label: "۳۰ روز اخیر", icon: CalendarDays, timeFmt: faDate },
];

export default function IpPage() {
  const { ip } = useParams<{ ip: string }>();
  const { data, err } = usePoll<Resp>(async () => (await fetch(`/api/ip/${encodeURIComponent(ip)}`)).json(), 3000, [ip]);
  const [win, setWin] = useState<Win>("1h");

  if (!data) {
    return (
      <div className="space-y-4">
        <Skeleton h={80} /><Skeleton h={220} /><Skeleton h={260} />
        {err && <p className="text-center text-[12px] text-rose-300">{err}</p>}
      </div>
    );
  }
  if (!data.ok) return <div className="glass p-10 text-center text-slate-400">این IP یافت نشد یا پایش نمی‌شود.</div>;

  const d = data.detail;
  const hist: Hist = win === "1h" ? data.h1h : win === "24h" ? data.h24 : data.h30;
  const chart = hist.points.map((p) => ({ t: p.t, a: p.i, b: p.o }));
  const wcfg = WINS.find((w) => w.k === win)!;
  const statusColor = d.cls.label === "مشکوک" ? "#fb7185" : d.cls.label.startsWith("بیکار") ? "#fbbf24" : "#34d399";
  const StatusIcon = d.cls.label === "مشکوک" ? ShieldAlert : d.cls.label.startsWith("بیکار") ? CircleOff : ShieldCheck;

  return (
    <div className="space-y-6">
      <PageHead
        title={`رصد آدرس ${d.ip}`}
        sub={`${d.host} — عضو ${d.rangeName} • ${d.server ? "سرور/تجهیز" : "کلاینت"} ${d.external ? "• آدرس برون‌مرزی" : ""}`}
        chips={
          <>
            <Link href={d.rangeId ? `/ranges/${d.rangeId}` : "/"} className="chip hover:text-cyan-300"><ArrowRight size={12} /> بازگشت</Link>
            <span className="chip" style={{ color: statusColor, borderColor: `${statusColor}55`, background: `${statusColor}14` }}>
              <StatusIcon size={12} /> {d.cls.label} — ریسک {d.cls.score}
            </span>
          </>
        }
      />

      <div className="fade-up grid grid-cols-2 gap-3 lg:grid-cols-4">
        <div className="glass p-4"><div className="flex items-center gap-2 text-cyan-300"><ArrowDownWideNarrow size={15} /><span className="text-[11px] text-slate-400">دریافت لحظه‌ای</span></div><div className="mono mt-2 text-[20px] font-extrabold text-cyan-200" dir="ltr">{fmtRate(d.now.i)}</div></div>
        <div className="glass p-4"><div className="flex items-center gap-2 text-violet-300"><ArrowUpNarrowWide size={15} /><span className="text-[11px] text-slate-400">ارسال لحظه‌ای</span></div><div className="mono mt-2 text-[20px] font-extrabold text-violet-200" dir="ltr">{fmtRate(d.now.o)}</div></div>
        <div className="glass p-4"><div className="flex items-center gap-2 text-emerald-300"><PlugZap size={15} /><span className="text-[11px] text-slate-400">نشست‌های باز</span></div><div className="mono mt-2 text-[20px] font-extrabold text-emerald-200" dir="ltr">{fmtInt(d.now.s)}</div></div>
        <div className="glass flex items-center justify-between gap-2 p-4" dir="ltr"><Spark data={d.spark} color={statusColor} w={130} h={44} /></div>
      </div>

      <div className={`glass fade-up fade-up-1 border-r-4 p-4`} style={{ borderRightColor: statusColor }}>
        <div className="flex flex-wrap items-center gap-x-6 gap-y-1 text-[12px] text-slate-300">
          <b style={{ color: statusColor }}>ارزیابی behavioural</b>
          {d.cls.reasons.map((r, i) => <span key={i} className="text-slate-400">• {r}</span>)}
        </div>
      </div>

      <div className="glass fade-up fade-up-2 p-5">
        <Section
          icon={wcfg.icon}
          title={`پهنای باند ${d.host} — ${wcfg.label}`}
          sub="با هر تغییر، بدون رفرش به‌روز می‌شود — روی نقاط نگه دارید برای مقدار دقیق"
          action={
            <div className="flex gap-1 rounded-xl border border-slate-500/15 p-1">
              {WINS.map((w) => (
                <button key={w.k} className={`tab-btn !px-3.5 !py-1.5 !text-[11.5px] ${win === w.k ? "active" : ""}`} onClick={() => setWin(w.k)}>{w.label}</button>
              ))}
            </div>
          }
        />
        <LiveChart data={chart} height={250} timeFmt={wcfg.timeFmt} colorA={statusColor === "#34d399" ? "#22d3ee" : statusColor} />
        <div className="mt-4 grid grid-cols-2 gap-3 md:grid-cols-4">
          <div className="rounded-xl border border-slate-500/15 bg-slate-500/5 p-3"><div className="flex items-center gap-1.5 text-[10.5px] text-slate-500"><Sigma size={11} /> مجموع دانلود</div><div className="mono mt-1 text-[15px] font-bold text-cyan-200" dir="ltr">{fmtBytes(hist.totals.i)}</div></div>
          <div className="rounded-xl border border-slate-500/15 bg-slate-500/5 p-3"><div className="flex items-center gap-1.5 text-[10.5px] text-slate-500"><Sigma size={11} /> مجموع آپلود</div><div className="mono mt-1 text-[15px] font-bold text-violet-200" dir="ltr">{fmtBytes(hist.totals.o)}</div></div>
          <div className="rounded-xl border border-slate-500/15 bg-slate-500/5 p-3"><div className="flex items-center gap-1.5 text-[10.5px] text-slate-500"><TrendingUp size={11} /> پیک نرخ</div><div className="mono mt-1 text-[15px] font-bold text-amber-200" dir="ltr">{fmtRate(hist.totals.peak)}</div></div>
          <div className="rounded-xl border border-slate-500/15 bg-slate-500/5 p-3"><div className="flex items-center gap-1.5 text-[10.5px] text-slate-500"><Globe size={11} /> میانگین نرخ</div><div className="mono mt-1 text-[15px] font-bold text-emerald-200" dir="ltr">{fmtRate(hist.totals.avg)}</div></div>
        </div>
      </div>

      <div className="grid gap-4 lg:grid-cols-3">
        <div className="glass fade-up fade-up-3 p-5">
          <Section icon={PlugZap} title="ترکیب پروتکل‌ها" sub="سهم هر پروتکل از ترافیک" />
          <Donut items={d.protos} />
        </div>
        <div className="glass fade-up fade-up-4 p-5 lg:col-span-2">
          <Section icon={Clock3} title="لاگ اتصالات اخیر" sub="آخرین نشست‌های ثبت‌شده این آدرس" />
          <div className="scroll-thin max-h-[300px] overflow-auto">
            <table className="table-base">
              <thead><tr><th>زمان</th><th>سمت مقابل</th><th>پروتکل</th><th>پورت</th><th>حجم</th><th>وضعیت</th></tr></thead>
              <tbody>
                {d.conns.map((c, i) => (
                  <tr key={i}>
                    <td className="mono text-slate-400">{faDateTime(c.t)}</td>
                    <td className="mono text-cyan-300">{c.peer}</td>
                    <td><span className="chip !text-[10px]">{c.proto}</span></td>
                    <td className="mono text-slate-300">{c.port}</td>
                    <td className="mono text-slate-300">{fmtBytes(c.bytes)}</td>
                    <td>{c.state === "برقرار" ? <span className="chip !text-[10px]" style={{ color: "#34d399" }}>برقرار</span> : <span className="chip !text-[10px]">بسته شده</span>}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
      {/* IPهایی که با این آدرس ارتباط داشته‌اند */}
      <div className="glass fade-up fade-up-4 p-5">
        <Section
          icon={Users}
          title="آی‌پی‌هایی که با این آدرس درخواست/ارتباط داشته‌اند"
          sub="جهت حجم: دریافت این آدرس از طرف مقابل • ارسال این آدرس به طرف مقابل"
          action={
            <Link href={`/logs?ip=${d.ip}`} className="chip hover:!border-cyan-400/40 hover:!text-cyan-300">
              <FileSearch size={11} /> جستجوی لاگ این IP (تاریخ شمسی)
            </Link>
          }
        />
        {!d.peers?.length ? (
          <p className="py-6 text-center text-[12px] text-slate-500">هنوز ارتباطی ثبت نشده — چند لحظه دیگر نمونه‌ها تکمیل می‌شوند</p>
        ) : (
          <div className="scroll-thin max-h-[320px] overflow-auto">
            <table className="table-base">
              <thead><tr><th>طرف مقابل</th><th>نام میزبان</th><th>دریافت از او</th><th>ارسال به او</th><th>تعداد نشست</th><th>آخرین فعالیت</th><th></th></tr></thead>
              <tbody>
                {d.peers.map((p) => (
                  <tr key={p.ip}>
                    <td><Link href={`/ip/${p.ip}`} className="mono font-semibold text-cyan-300 hover:underline">{p.ip}</Link></td>
                    <td className="max-w-[170px] truncate text-slate-300">{p.name}</td>
                    <td className="mono text-cyan-200" dir="ltr">{fmtBytes(p.i)}</td>
                    <td className="mono text-violet-300" dir="ltr">{fmtBytes(p.o)}</td>
                    <td className="mono text-slate-300">{p.hits}</td>
                    <td className="mono text-slate-400">{faTime(p.last)}</td>
                    <td><Link href={`/ip/${p.ip}`} className="chip hover:!text-cyan-300">رصد</Link></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {d.cls.label === "مشکوک" && (
        <div className="glass border-rose-400/30 p-5">
          <div className="mb-2 flex items-center gap-2 text-rose-300"><ShieldAlert size={17} /><b className="text-[14px]">اقدام پیشنهادی امنیتی</b></div>
          <ul className="list-inside list-disc space-y-1 text-[12px] leading-6 text-slate-300">
            <li>این آدرس را در سوئیچ لبه قرنطینه (VLAN isolation) کنید.</li>
            <li>لاگ کامل نشست‌ها در بخش «لاگ اتصالات» و خروجی CSV قابل استخراج است.</li>
            <li>قانون مسدودسازی موقت روی فایروال مرزی برای مقصدهای غیرمعمول اعمال شد.</li>
          </ul>
        </div>
      )}
    </div>
  );
}
