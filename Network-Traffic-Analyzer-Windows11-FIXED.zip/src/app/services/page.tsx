"use client";

import { useEffect, useState } from "react";
import { HeartPulse, PlugZap, ArrowDownToLine, ArrowUpFromLine, ServerCrash, CheckCircle2 } from "lucide-react";
import { useDevices } from "@/app/servers/page";
import { Spark } from "@/components/charts";
import { PageHead, Section, Skeleton, KindChip } from "@/components/ui";
import { fmtRate, faHM } from "@/lib/format";

type Trace = { ok: boolean; nodes: { name: string; ip: string; lat: number }[]; hops: number; totalLat: number };
const WATCH_KINDS = ["mikrotik", "firewall", "server", "windows", "esxi", "fiber", "cisco", "switch"];

function stabColor(p: number) {
  return p >= 99.9 ? "#34d399" : p >= 99 ? "#a3e635" : p >= 90 ? "#fbbf24" : p >= 80 ? "#fb923c" : "#fb7185";
}

export default function ServicesPage() {
  const { data } = useDevices();
  const [trace, setTrace] = useState<Record<string, Trace>>({});

  const list = (data?.devices ?? []).filter((d) => WATCH_KINDS.includes(d.kind) || d.isDomain);

  // هنگام آفلاین شدن هر سرویس، به‌صورت خودکار مسیر را تحلیل کن
  useEffect(() => {
    list.filter((d) => !d.online && !trace[d.ip]).forEach(async (d) => {
      try {
        const t: Trace = await (await fetch(`/api/trace?src=192.168.1.1&dst=${encodeURIComponent(d.ip)}`)).json();
        setTrace((s) => ({ ...s, [d.ip]: t }));
      } catch { /* بعداً */ }
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [data]);

  if (!data) return <div className="space-y-4"><Skeleton h={90} /><Skeleton h={300} /></div>;

  const total = list.length;
  const up = list.filter((d) => d.online).length;

  return (
    <div className="space-y-6">
      <PageHead
        title="مانیتورینگ و پایداری سرویس‌ها"
        sub="نقشه شماتیک زنده: وضعیت آنلاین/آفلاین هر سرویس، نشست‌های ورودی/خروجی و درصد پایداری — هنگام قطعی، دقیقاً می‌گوید از کدام IP به بعد پاسخی نمی‌آید و پس از رفع، مسیر سالم را نمایش می‌دهد"
        chips={<span className="chip" style={{ color: "#34d399" }}>{up}/{total} سرویس آنلاین</span>}
      />

      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
        {list.map((d) => {
          const stab = d.stabPct ?? 100;
          const sc = stabColor(stab);
          const t = trace[d.ip];
          return (
            <div key={d.id} className={`glass glass-hover relative overflow-hidden p-4`}>
              <div className="absolute inset-y-0 right-0 w-1" style={{ background: d.online ? "#34d399" : "#fb7185" }} />
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-2.5">
                  <span className={`relative grid h-10 w-10 place-items-center rounded-xl border ${d.online ? "border-emerald-400/40 bg-emerald-400/10" : "border-rose-400/50 bg-rose-400/15"}`}>
                    <HeartPulse size={18} className={d.online ? "text-emerald-300" : "text-rose-300"} />
                    <i className={`absolute -left-1 -top-1 ${d.online ? "live-dot" : "live-dot-red"}`} />
                  </span>
                  <div>
                    <div className="max-w-[180px] truncate text-[13px] font-bold text-slate-100">{d.name}</div>
                    <div className="mono text-[10.5px] text-slate-500">{d.ip}</div>
                  </div>
                </div>
                <KindChip kind={d.kind} />
              </div>

              <div className="mt-3 flex items-center justify-between">
                <div dir="ltr"><Spark data={d.spark} color={d.online ? "#34d399" : "#64748b"} w={110} h={30} /></div>
                <div className="text-left">
                  <div className="mono text-[18px] font-extrabold" style={{ color: sc }} dir="ltr">{stab}%</div>
                  <div className="text-[9px] text-slate-500">پایداری (آپتایم)</div>
                </div>
              </div>

              <div className="mt-2.5 grid grid-cols-4 gap-1.5 text-center text-[9.5px]">
                <div className="rounded-lg border border-slate-500/10 bg-slate-500/5 p-1.5">
                  <div className="flex items-center justify-center gap-0.5 text-slate-500"><PlugZap size={10} /> ترافیک</div>
                  <b className="mono block text-[10.5px] text-slate-200" dir="ltr">{fmtRate(d.rate)}</b>
                </div>
                <div className="rounded-lg border border-slate-500/10 bg-slate-500/5 p-1.5">
                  <div className="flex items-center justify-center gap-0.5 text-slate-500"><ArrowDownToLine size={10} /> ورودی</div>
                  <b className="mono block text-[10.5px] text-cyan-300" dir="ltr">{d.sessionsIn ?? 0}</b>
                </div>
                <div className="rounded-lg border border-slate-500/10 bg-slate-500/5 p-1.5">
                  <div className="flex items-center justify-center gap-0.5 text-slate-500"><ArrowUpFromLine size={10} /> خروجی</div>
                  <b className="mono block text-[10.5px] text-violet-300" dir="ltr">{d.sessionsOut ?? 0}</b>
                </div>
                <div className="rounded-lg border border-slate-500/10 bg-slate-500/5 p-1.5">
                  <div className="text-slate-500">پینگ</div>
                  <b className="mono block text-[10.5px]" style={{ color: d.online ? "#34d399" : "#fb7185" }} dir="ltr">{d.online ? `${d.lat}ms` : "✕"}</b>
                </div>
              </div>

              {/* تایم‌لاین بازه‌های قطعی */}
              <div className="mt-2.5">
                {d.downOpen ? (
                  <div className="rounded-lg border border-rose-400/30 bg-rose-400/10 px-2.5 py-1.5 text-[10.5px] text-rose-200">
                    ⏱ در حال قطع از ساعت {faHM(d.downOpen)} تا اکنون
                  </div>
                ) : null}
                {!!d.downWins?.length && (
                  <div className="mt-1.5 flex flex-wrap items-center gap-1 text-[9.5px] text-slate-500">
                    آخرین قطعی‌ها:
                    {d.downWins.map((w, i) => (
                      <span key={i} className="chip mono !text-[9px]">{faHM(w.s)}–{faHM(w.e)}</span>
                    ))}
                  </div>
                )}
              </div>

              {!d.online && (
                <div className="mt-2.5 rounded-xl border border-rose-400/25 bg-rose-400/5 p-2.5 text-[10.5px]">
                  <div className="mb-1.5 flex items-center gap-1.5 font-bold text-rose-200"><ServerCrash size={12} /> تحلیل مسیر — محل توقف:</div>
                  {!t ? (
                    <div className="shimmer h-10" />
                  ) : (
                    <>
                      {t.nodes.slice(-3).map((n, i) => (
                        <div key={i} className="flex justify-between rounded-md border border-slate-500/10 bg-black/30 px-2 py-1">
                          <span className="text-slate-300">{n.name}</span><span className="mono text-slate-400">{n.ip}</span>
                        </div>
                      ))}
                      <div className="mt-1 rounded-md border border-rose-400/30 bg-rose-400/10 px-2 py-1.5 text-rose-200">
                        ✕ از <span className="mono">{d.ip}</span> به بعد جوابی/پینگی نمی‌آید — جهت بررسی اقدام شود.
                      </div>
                    </>
                  )}
                </div>
              )}
              {d.online && (d.downWins?.length || 0) > 0 && (
                <div className="mt-2 flex items-center gap-1.5 text-[10px] text-emerald-300"><CheckCircle2 size={11} /> مسیر پینگ برقرار است — بازیابی انجام شد</div>
              )}
            </div>
          );
        })}
      </div>
      <p className="pb-2 text-center text-[11px] text-slate-600">پایداری بر اساس نمونه‌گیری دقیقه‌ای وضعیت هر سرویس — ۱۰۰٪ یا ۹۹٫۹۹٪ یعنی بدون قطعشدگی در ۲۴ ساعت اخیر</p>
    </div>
  );
}
