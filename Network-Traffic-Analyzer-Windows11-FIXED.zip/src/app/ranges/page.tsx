"use client";

import { useState } from "react";
import Link from "next/link";
import { Network, Plus, Trash2, ChevronLeft, Boxes } from "lucide-react";
import { usePoll } from "@/lib/useEngine";
import { PageHead, Section, Skeleton, Empty } from "@/components/ui";
import { RANGE_KIND_FA, fmtInt } from "@/lib/format";

type RangeRow = { id: number; name: string; cidr: string; kind: string; color: string; capacity: number; used: number; groupName?: string };
const COLORS = ["#22d3ee", "#a78bfa", "#f59e0b", "#34d399", "#fb7185", "#60a5fa", "#f472b6"];

export default function RangesPage() {
  const { data, reload } = usePoll<{ ok: boolean; ranges: RangeRow[] }>(async () => (await fetch("/api/ranges")).json(), 5000, []);
  const [form, setForm] = useState({ name: "", cidr: "", kind: "lan", color: COLORS[0], group: "" });
  const [msg, setMsg] = useState("");
  const [saving, setSaving] = useState(false);
  const [showForm, setShowForm] = useState(false);

  const add = async () => {
    setSaving(true);
    setMsg("");
    const res = await (await fetch("/api/ranges", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(form) })).json();
    setSaving(false);
    if (res.ok) {
      setForm({ name: "", cidr: "", kind: "lan", color: COLORS[0], group: "" });
      setShowForm(false);
      setMsg("رنج با موفقیت افزوده شد و پروفایل آدرس‌های آن ساخته شد");
      reload();
    } else setMsg(res.error ?? "خطا در ثبت رنج");
  };

  const del = async (id: number) => {
    if (!confirm("این رنج و پروفایل آدرس‌هایش حذف شود؟")) return;
    await fetch(`/api/ranges?id=${id}`, { method: "DELETE" });
    reload();
  };

  return (
    <div className="space-y-6">
      <PageHead
        title="محدوده‌های IP (رنج‌ها)"
        sub="تا ۱۰ رنج شبکه تعریف کنید؛ موتور بلافاصله پروفایل آدرس‌های هر رنج را ساخته و پایش لحظه‌ای را آغاز می‌کند."
        chips={<button className="btn !py-2" onClick={() => setShowForm(!showForm)}><Plus size={15} /> افزودن رنج جدید</button>}
      />

      {showForm && (
        <div className="glass fade-up p-5">
          <Section icon={Plus} title="تعریف رنج جدید" sub="مثال: 10.20.0.0/24 — پایش برای ظرفیت کامل رنج انجام می‌شود" />
          <div className="grid gap-3 md:grid-cols-5">
            <input className="input" placeholder="نام رنج (مثلاً شبکه مالی)" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
            <input className="input mono" dir="ltr" placeholder="CIDR — 10.20.0.0/24" value={form.cidr} onChange={(e) => setForm({ ...form, cidr: e.target.value })} />
            <select className="input" value={form.kind} onChange={(e) => setForm({ ...form, kind: e.target.value })}>
              {Object.entries(RANGE_KIND_FA).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
            </select>
            <input
              className="input"
              placeholder="بخش/منطقه (اختیاری)"
              list="range-groups"
              value={form.group}
              onChange={(e) => setForm({ ...form, group: e.target.value })}
            />
            <datalist id="range-groups">
              {[...new Set((data?.ranges ?? []).map((r) => r.groupName).filter(Boolean))].map((g) => (
                <option key={String(g)} value={String(g)} />
              ))}
            </datalist>
            <div className="flex items-center gap-2">
              {COLORS.map((c) => (
                <button key={c} onClick={() => setForm({ ...form, color: c })} className="h-7 w-7 rounded-full border-2 transition-transform hover:scale-110" style={{ background: c, borderColor: form.color === c ? "#fff" : "transparent" }} aria-label={c} />
              ))}
            </div>
          </div>
          <p className="mt-2 text-[10.5px] text-slate-500">چند رنج می‌توانند در «یک بخش» باشند — کافی است نام بخش یکسان بدهید (مثلاً دو یا سه رنج برای دفتر مرکزی)</p>
          <div className="mt-4 flex items-center gap-3">
            <button className="btn" onClick={add} disabled={saving}>{saving ? "در حال ثبت…" : "ثبت و آغاز پایش"}</button>
            <button className="btn btn-ghost" onClick={() => setShowForm(false)}>انصراف</button>
            {msg && <span className="text-[12px] text-amber-300">{msg}</span>}
          </div>
        </div>
      )}
      {!showForm && msg && <div className="glass p-3 text-[12px] text-emerald-300">{msg}</div>}

      {!data ? (
        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">{[...Array(3)].map((_, i) => <Skeleton key={i} h={170} />)}</div>
      ) : !data.ranges.length ? (
        <Empty text="هنوز رنجی تعریف نشده است — با دکمه «افزودن رنج جدید» شروع کنید" />
      ) : (
        <div className="fade-up fade-up-1 grid gap-4 md:grid-cols-2 xl:grid-cols-3">
          {(() => {
            const by: Record<string, RangeRow[]> = {};
            data.ranges.forEach((x) => (by[x.groupName || "بدون بخش"] ??= []).push(x));
            return Object.entries(by).flatMap(([g, list]) => [
              <div key={"hdr-" + g} className="col-span-full mt-2 flex items-center gap-2 first:mt-0">
                <span className="chip !px-3 !py-1.5 !text-[11.5px]" style={{ color: "#a5f3fc", borderColor: "rgba(34,211,238,0.35)", background: "rgba(34,211,238,0.07)" }}>
                  {g === "بدون بخش" ? g : `بخش «${g}»`} — {list.length} رنج
                </span>
                <div className="h-px flex-1 bg-slate-500/10" />
              </div>,
              ...list.map((r) => {
            const pct = r.capacity ? Math.round((r.used / r.capacity) * 100) : 0;
            return (
              <div key={r.id} className="glass glass-hover relative overflow-hidden p-5">
                <div className="absolute inset-x-0 top-0 h-1" style={{ background: `linear-gradient(90deg, ${r.color}, transparent)` }} />
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <span className="grid h-11 w-11 place-items-center rounded-xl border" style={{ color: r.color, borderColor: `${r.color}44`, background: `${r.color}12` }}>
                      <Network size={19} />
                    </span>
                    <div>
                      <div className="text-[14px] font-bold text-slate-100">{r.name}</div>
                      <div className="mono mt-0.5 text-[11px] text-slate-500">{r.cidr}</div>
                    </div>
                  </div>
                  <button onClick={() => del(r.id)} className="rounded-lg p-2 text-slate-600 transition-colors hover:bg-rose-500/10 hover:text-rose-300" title="حذف رنج">
                    <Trash2 size={15} />
                  </button>
                </div>
                <div className="mt-4 space-y-2">
                  <div className="flex items-center justify-between text-[11.5px] text-slate-400">
                    <span className="flex items-center gap-1.5"><Boxes size={12} /> به‌کاررفته: {fmtInt(r.used)} از {fmtInt(r.capacity)} آدرس</span>
                    <b className="mono" style={{ color: r.color }}>{pct}%</b>
                  </div>
                  <div className="progress-track"><div className="progress-fill" style={{ width: `${Math.min(100, pct)}%`, background: r.color }} /></div>
                </div>
                <div className="mt-4 flex items-center justify-between">
                  <span className="chip">{RANGE_KIND_FA[r.kind] ?? r.kind}</span>
                  <Link href={`/ranges/${r.id}`} className="flex items-center gap-1 text-[12px] font-semibold text-cyan-300 hover:text-cyan-100">
                    پایش لحظه‌ای رنج <ChevronLeft size={14} />
                  </Link>
                </div>
              </div>
            );
          }),
            ]);
          })()}
        </div>
      )}
    </div>
  );
}
