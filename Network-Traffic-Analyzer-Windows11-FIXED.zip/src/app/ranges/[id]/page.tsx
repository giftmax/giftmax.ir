"use client";

import { useState } from "react";
import Link from "next/link";
import { useParams } from "next/navigation";
import {
  ArrowRight, Activity, Boxes, CircleOff, ShieldAlert, Gauge, TrendingUp, Sigma, ListX, ChevronDown, Eye,
} from "lucide-react";
import { usePoll, type IpRow } from "@/lib/useEngine";
import { LiveChart, Spark } from "@/components/charts";
import { PageHead, Section, Skeleton } from "@/components/ui";
import { fmtRate, fmtInt, faTime, RANGE_KIND_FA } from "@/lib/format";

type Detail = {
  ok: boolean;
  range: { id: number; name: string; cidr: string; kind: string; color: string };
  ring: { t: number; i: number; o: number }[];
  ips: (IpRow & { idle: boolean; susp: { score: number; kind: string; reason: string } | null })[];
  stats: {
    capacity: number; used: number; activeNow: number; idle: number; susp: number;
    unusedCount: number; unused: string[]; avg: number; peak: number; p95: number;
  };
};

export default function RangeDetailPage() {
  const { id } = useParams<{ id: string }>();
  const { data } = usePoll<Detail>(async () => (await fetch(`/api/ranges/${id}`)).json(), 3000, [id]);
  const [q, setQ] = useState("");
  const [showUnused, setShowUnused] = useState(false);

  if (!data) return <div className="space-y-4"><Skeleton h={90} /><Skeleton h={280} /><Skeleton h={300} /></div>;

  const { range: r, stats, ring, ips } = data;
  const rows = ips.filter((x) => !q || x.ip.includes(q) || x.host.includes(q));
  const chart = ring.map((p) => ({ t: p.t, a: p.i, b: p.o }));

  return (
    <div className="space-y-6">
      <PageHead
        title={r.name}
        sub={`پایش تفکیک‌شده ${r.cidr} — نرخ لحظه‌ای هر آدرس، تحلیل آماری و فهرست آدرس‌های خالی این رنج`}
        chips={
          <>
            <Link href="/ranges" className="chip hover:text-cyan-300"><ArrowRight size={12} /> بازگشت به رنج‌ها</Link>
            <span className="chip" style={{ color: r.color, borderColor: `${r.color}55`, background: `${r.color}12` }}>{RANGE_KIND_FA[r.kind] ?? r.kind}</span>
            <span className="chip mono" dir="ltr">{r.cidr}</span>
          </>
        }
      />

      <div className="fade-up grid grid-cols-2 gap-3 md:grid-cols-3 xl:grid-cols-6">
        {[
          { icon: Boxes, label: "ظرفیت رنج", value: fmtInt(stats.capacity), c: "#60a5fa" },
          { icon: Activity, label: "فعال هم‌اکنون", value: fmtInt(stats.activeNow), c: "#34d399" },
          { icon: TrendingUp, label: "آدرس به‌کاررفته", value: fmtInt(stats.used), c: r.color },
          { icon: CircleOff, label: "بیکار / بدون نشست", value: fmtInt(stats.idle), c: "#fbbf24" },
          { icon: ListX, label: "آدرس خالی", value: fmtInt(stats.unusedCount), c: "#94a3b8" },
          { icon: ShieldAlert, label: "مشکوک", value: fmtInt(stats.susp), c: "#fb7185" },
        ].map((s) => (
          <div key={s.label} className="glass p-3.5">
            <s.icon size={16} style={{ color: s.c }} />
            <div className="mt-2 text-[19px] font-extrabold text-slate-50" dir="ltr">{s.value}</div>
            <div className="text-[10.5px] text-slate-500">{s.label}</div>
          </div>
        ))}
      </div>

      <div className="glass fade-up fade-up-1 p-5">
        <Section
          icon={Activity}
          title={`نمودار زنده ترافیک رنج ${r.name}`}
          sub="تجمیع لحظه‌ای همه آدرس‌های این رنج — بدون رفرش هر تیک به‌روز می‌شود"
          action={<span className="chip mono" dir="ltr"><Gauge size={12} /> {fmtRate((ring.at(-1)?.i ?? 0) + (ring.at(-1)?.o ?? 0))}</span>}
        />
        <LiveChart data={chart} colorA={r.color} height={230} />
      </div>

      <div className="fade-up fade-up-2 grid grid-cols-2 gap-3 md:grid-cols-4">
        <div className="glass p-4"><div className="text-[11px] text-slate-500">میانگین مصرف رنج</div><div className="mono mt-1 text-[17px] font-bold text-cyan-200" dir="ltr">{fmtRate(stats.avg)}</div></div>
        <div className="glass p-4"><div className="text-[11px] text-slate-500">پیک مصرف</div><div className="mono mt-1 text-[17px] font-bold text-amber-200" dir="ltr">{fmtRate(stats.peak)}</div></div>
        <div className="glass p-4"><div className="text-[11px] text-slate-500">صدک ۹۵ (P95)</div><div className="mono mt-1 text-[17px] font-bold text-violet-200" dir="ltr">{fmtRate(stats.p95)}</div></div>
        <div className="glass p-4">
          <div className="text-[11px] text-slate-500">ضریب استفاده از آدرس</div>
          <div className="mt-1 flex items-center gap-2">
            <div className="progress-track flex-1"><div className="progress-fill" style={{ width: `${stats.capacity ? (stats.used / stats.capacity) * 100 : 0}%`, background: r.color }} /></div>
            <b className="mono text-[12px]" style={{ color: r.color }}>{stats.capacity ? Math.round((stats.used / stats.capacity) * 100) : 0}%</b>
          </div>
        </div>
      </div>

      <div className="glass fade-up fade-up-3 p-5">
        <Section
          icon={Sigma}
          title="جدول آدرس‌های این رنج"
          sub="مرتب‌شده بر اساس مصرف لحظه‌ای — کلیک روی هر IP: نمودار ۱ ساعت، ۲۴ ساعت و ۳۰ روز"
          action={<input className="input !w-52 !py-1.5 !text-[11.5px]" placeholder="جستجوی IP در این رنج…" value={q} onChange={(e) => setQ(e.target.value)} />}
        />
        <div className="scroll-thin max-h-[460px] overflow-auto">
          <table className="table-base">
            <thead><tr><th>IP</th><th>میزبان</th><th>روند لحظه‌ای</th><th>دریافت</th><th>ارسال</th><th>نشست</th><th>وضعیت</th><th></th></tr></thead>
            <tbody>
              {rows.map((x) => (
                <tr key={x.ip}>
                  <td><Link className="mono font-semibold text-cyan-300 hover:underline" href={`/ip/${x.ip}`}>{x.ip}</Link></td>
                  <td className="max-w-[180px] truncate text-slate-300">{x.host}</td>
                  <td dir="ltr"><Spark data={x.spark} color={x.susp ? "#fb7185" : x.idle ? "#fbbf24" : r.color} w={92} h={24} /></td>
                  <td className="mono text-cyan-200">{fmtRate(x.i)}</td>
                  <td className="mono text-violet-300">{fmtRate(x.o)}</td>
                  <td className="mono text-slate-300">{x.s}</td>
                  <td>
                    {x.susp ? (
                      <span className="chip !text-[10px]" style={{ color: "#fb7185", borderColor: "#fb718540", background: "#fb718512" }} title={x.susp.reason}>مشکوک ({x.susp.score})</span>
                    ) : x.idle ? (
                      <span className="chip !text-[10px]" style={{ color: "#fbbf24", borderColor: "#fbbf2440", background: "#fbbf2410" }}>بیکار</span>
                    ) : (
                      <span className="chip !text-[10px]" style={{ color: "#34d399", borderColor: "#34d39940", background: "#34d39910" }}>نرمال</span>
                    )}
                  </td>
                  <td><Link href={`/ip/${x.ip}`} className="chip hover:text-cyan-300"><Eye size={11} /> جزئیات</Link></td>
                </tr>
              ))}
              {!rows.length && <tr><td colSpan={8} className="py-8 text-center text-slate-500">موردی یافت نشد</td></tr>}
            </tbody>
          </table>
        </div>
      </div>

      <div className="glass fade-up fade-up-4 p-5">
        <button className="flex w-full items-center justify-between" onClick={() => setShowUnused(!showUnused)}>
          <div className="flex items-center gap-3">
            <span className="grid h-10 w-10 place-items-center rounded-xl border border-slate-400/25 bg-slate-400/10 text-slate-300"><ListX size={18} /></span>
            <div className="text-right">
              <div className="text-[14px] font-bold text-slate-100">آدرس‌های خالی / بلااستفاده این رنج</div>
              <div className="mt-0.5 text-[11.5px] text-slate-500">{fmtInt(stats.unusedCount)} آدرس خالی — مناسب برای گزارش ظرفیت آزاد</div>
            </div>
          </div>
          <ChevronDown size={18} className={`text-slate-400 transition-transform ${showUnused ? "rotate-180" : ""}`} />
        </button>
        {showUnused && (
          <div className="mt-4 grid grid-cols-2 gap-1.5 sm:grid-cols-4 lg:grid-cols-6">
            {stats.unused.map((ip) => (
              <span key={ip} className="mono rounded-lg border border-slate-500/15 bg-slate-500/5 px-2 py-1.5 text-center text-[11px] text-slate-400">{ip}</span>
            ))}
            {stats.unusedCount > stats.unused.length && (
              <span className="rounded-lg border border-slate-500/15 bg-slate-500/5 px-2 py-1.5 text-center text-[11px] text-slate-500">… و {fmtInt(stats.unusedCount - stats.unused.length)} آدرس دیگر</span>
            )}
          </div>
        )}
      </div>

      <p className="pb-2 text-center text-[11px] text-slate-600">آخرین نمونه: {ring.length ? faTime(ring.at(-1)!.t) : "—"} — این صفحه هر ۳ ثانیه با آژاکس به‌روز می‌شود</p>
    </div>
  );
}
