import { ensureEngine } from "@/lib/engine";
import { isValidIp } from "@/lib/format";
import { badInput, rateLimit } from "@/lib/guard";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const TYPES = ["exchange", "postfix", "mdaemon", "kerio", "hmail", "zimbra", "other"];

export async function POST(req: Request) {
  const rl = rateLimit(req, "mail", 15, 10_000);
  if (rl) return rl;
  let body: { ip?: string; type?: string };
  try {
    body = await req.json();
  } catch {
    return badInput("بدنه نامعتبر");
  }
  const ip = String(body.ip ?? "").trim();
  if (!isValidIp(ip)) return badInput("آدرس IP نامعتبر است");
  const type = TYPES.includes(String(body.type)) ? String(body.type) : "other";
  const eng = await ensureEngine();
  return Response.json({ ok: true, ...eng.mailCheck(ip, type) });
}
