import { ensureEngine } from "@/lib/engine";
import { badInput, rateLimit } from "@/lib/guard";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  const rl = rateLimit(req, "backup", 20, 10_000);
  if (rl) return rl;
  const eng = await ensureEngine();
  const view = new URL(req.url).searchParams.get("view");
  if (view) {
    const res = await eng.viewBackup(view);
    if (!res.ok) return badInput(res.error ?? "خطا");
    return Response.json(res);
  }
  const files = await eng.listBackups();
  return Response.json({
    ok: true,
    files,
    settings: { dir: eng.backupDir, daily: eng.backupDaily, weekly: eng.backupWeekly, monthly: eng.backupMonthly },
  });
}

export async function POST(req: Request) {
  const rl = rateLimit(req, "backup-post", 10, 10_000);
  if (rl) return rl;
  let body: { op?: string; kind?: string; dir?: string; daily?: string };
  try {
    body = await req.json();
  } catch {
    return badInput("بدنه نامعتبر");
  }
  const eng = await ensureEngine();
  if (body.op === "run") {
    const kind = ["daily", "weekly", "monthly", "manual"].includes(String(body.kind)) ? String(body.kind) : "manual";
    const res = await eng.backupNow(kind);
    if (!res.ok) return badInput(res.error ?? "خطا");
    return Response.json(res);
  }
  const res = await eng.setBackupSettings(body.dir ? String(body.dir) : null, body.daily ? String(body.daily) : null);
  if (!res.ok) return badInput(res.error ?? "خطا");
  return Response.json({ ok: true });
}
