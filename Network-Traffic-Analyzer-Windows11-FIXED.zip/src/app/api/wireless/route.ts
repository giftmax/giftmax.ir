import { ensureEngine } from "@/lib/engine";
import { isValidIp } from "@/lib/format";
import { badInput, rateLimit } from "@/lib/guard";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  const rl = rateLimit(req, "wireless", 40, 10_000);
  if (rl) return rl;
  const eng = await ensureEngine();
  const u = new URL(req.url);
  const ip = u.searchParams.get("ip");
  const win = u.searchParams.get("win");
  if (ip) {
    if (!isValidIp(ip)) return badInput("IP نامعتبر");
    const w = (["1h", "24h", "10d"].includes(String(win)) ? win : "1h") as "1h" | "24h" | "10d";
    return Response.json({ ok: true, ip, win: w, ...eng.wirelessHistory(ip, w) });
  }
  return Response.json({ ok: true, list: eng.wirelessView() });
}
