import { ensureEngine } from "@/lib/engine";
import { isValidIp } from "@/lib/format";
import { badInput, rateLimit } from "@/lib/guard";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  const rl = rateLimit(req, "tree", 40, 10_000);
  if (rl) return rl;
  const eng = await ensureEngine();
  return Response.json({ ok: true, ...eng.treeView() });
}

export async function POST(req: Request) {
  const rl = rateLimit(req, "tree-post", 15, 10_000);
  if (rl) return rl;
  let body: { name?: string; parentId?: number | null; kind?: string; ips?: string[] };
  try {
    body = await req.json();
  } catch {
    return badInput("بدنه نامعتبر");
  }
  const ips = (Array.isArray(body.ips) ? body.ips : []).filter((x) => isValidIp(String(x))).map(String);
  const eng = await ensureEngine();
  const res = await eng.treeAdd({
    name: String(body.name ?? "").trim(),
    parentId: body.parentId ? Number(body.parentId) : null,
    kind: body.kind === "leaf" ? "leaf" : "branch",
    ips,
  });
  if (!res.ok) return badInput(res.error ?? "خطا");
  return Response.json(res);
}

export async function PATCH(req: Request) {
  const rl = rateLimit(req, "tree-patch", 30, 10_000);
  if (rl) return rl;
  let body: { id?: number; name?: string; ips?: string[]; parentId?: number | null };
  try {
    body = await req.json();
  } catch {
    return badInput("بدنه نامعتبر");
  }
  const id = Number(body.id);
  if (!Number.isInteger(id)) return badInput("شناسه نامعتبر");
  const ips = Array.isArray(body.ips) ? body.ips.filter((x) => isValidIp(String(x))).map(String) : undefined;
  const eng = await ensureEngine();
  await eng.treePatch(id, { name: body.name ? String(body.name).trim() : undefined, ips, parentId: body.parentId === undefined ? undefined : body.parentId === null ? null : Number(body.parentId) });
  return Response.json({ ok: true });
}

export async function DELETE(req: Request) {
  const rl = rateLimit(req, "tree-del", 15, 10_000);
  if (rl) return rl;
  const id = Number(new URL(req.url).searchParams.get("id"));
  if (!Number.isInteger(id)) return badInput("شناسه نامعتبر");
  const eng = await ensureEngine();
  const res = await eng.treeDelete(id);
  if (!res.ok) return badInput(res.error ?? "خطا");
  return Response.json(res);
}
