import { ensureEngine } from "@/lib/engine";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET() {
  const eng = await ensureEngine();
  return Response.json({ ok: true, ...eng.bootstrap() });
}
