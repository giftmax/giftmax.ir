import { ensureEngine } from "@/lib/engine";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

// جریان زنده SSE — هر تیک (۲ ثانیه) یک اسنپ‌شات JSON
export async function GET() {
  const eng = await ensureEngine();
  const enc = new TextEncoder();
  let cleanup: () => void = () => undefined;

  const stream = new ReadableStream<Uint8Array>({
    start(controller) {
      let closed = false;
      const safeEnqueue = (chunk: string) => {
        if (closed) return;
        try {
          controller.enqueue(enc.encode(chunk));
        } catch {
          cleanup();
        }
      };
      const onTick = () => safeEnqueue(`data: ${JSON.stringify(eng.snapshot())}\n\n`);
      const ping = setInterval(() => safeEnqueue(`: ping ${Date.now()}\n\n`), 15000);
      cleanup = () => {
        if (closed) return;
        closed = true;
        clearInterval(ping);
        eng.off("tick", onTick);
        try {
          controller.close();
        } catch {
          /* بسته شده */
        }
      };
      safeEnqueue(`data: ${JSON.stringify(eng.snapshot())}\n\n`);
      eng.on("tick", onTick);
    },
    cancel() {
      cleanup();
    },
  });

  return new Response(stream, {
    headers: {
      "Content-Type": "text/event-stream; charset=utf-8",
      "Cache-Control": "no-cache, no-transform",
      Connection: "keep-alive",
      "X-Accel-Buffering": "no",
    },
  });
}
