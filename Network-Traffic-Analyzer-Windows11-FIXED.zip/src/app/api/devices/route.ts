import { ensureEngine } from "@/lib/engine";
import { isValidIp } from "@/lib/format";
import { badInput, rateLimit, writeGuard } from "@/lib/guard";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const KINDS = ["cisco", "mikrotik", "switch", "windows", "esxi", "vm", "server", "firewall", "fiber", "wireless", "other"];

export async function GET() {
  const eng = await ensureEngine();
  return Response.json({ ok: true, devices: eng.devicesView() });
}

export async function POST(req: Request) {
  const lw = await writeGuard();
  if (lw) return lw;
  const rl = rateLimit(req, "devices-post", 20, 10_000);
  if (rl) return rl;
  let body: Record<string, unknown>;
  try {
    body = await req.json();
  } catch {
    return badInput("بدنه JSON نامعتبر است");
  }
  const name = String(body.name ?? "").trim();
  const ip = String(body.ip ?? "").trim();
  if (name.length < 2 || name.length > 80) return badInput("نام تجهیز نامعتبر است");
  if (!isValidIp(ip)) return badInput("آدرس IP نامعتبر است");
  const kind = KINDS.includes(String(body.kind)) ? String(body.kind) : "server";
  const eng = await ensureEngine();
  const res = await eng.addDevice({
    name, ip, kind,
    rangeId: body.rangeId ? Number(body.rangeId) : null,
    parentId: body.parentId ? Number(body.parentId) : null,
    isDomain: !!body.isDomain,
    snmp: body.snmp !== false,
    wmi: !!body.wmi,
    ilo: !!body.ilo,
    community: String(body.community ?? "public").slice(0, 40),
    osVersion: body.osVersion ? String(body.osVersion).slice(0, 80) : null,
    notes: body.notes ? String(body.notes).slice(0, 160) : null,
  });
  if (!res.ok) return badInput(res.error ?? "خطا");
  return Response.json({ ok: true });
}

export async function PATCH(req: Request) {
  const rl = rateLimit(req, "devices-patch", 30, 10_000);
  if (rl) return rl;
  let body: { id?: number; field?: string };
  try {
    body = await req.json();
  } catch {
    return badInput("بدنه JSON نامعتبر است");
  }
  const id = Number(body.id);
  const field = String(body.field);
  if (!Number.isInteger(id) || !["snmp", "wmi", "ilo", "isDomain"].includes(field)) return badInput("ورودی نامعتبر است");
  const eng = await ensureEngine();
  const res = await eng.toggleDevice(id, field as "snmp" | "wmi" | "ilo" | "isDomain");
  return Response.json(res);
}

export async function DELETE(req: Request) {
  const rl = rateLimit(req, "devices-del", 10, 10_000);
  if (rl) return rl;
  const id = Number(new URL(req.url).searchParams.get("id"));
  if (!Number.isInteger(id) || id <= 0) return badInput("شناسه نامعتبر است");
  const eng = await ensureEngine();
  await eng.removeDevice(id);
  return Response.json({ ok: true });
}
