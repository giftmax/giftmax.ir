import { ensureEngine } from "@/lib/engine";
import { rateLimit } from "@/lib/guard";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  const rl = rateLimit(req, "security", 40, 10_000);
  if (rl) return rl;
  const limit = Math.min(400, Number(new URL(req.url).searchParams.get("limit") ?? 120) || 120);
  const eng = await ensureEngine();
  const list = eng.recentEvents.slice(-limit).reverse();
  const snap = eng.snapshot();
  return Response.json({ ok: true, list, sec: snap.sec });
}
