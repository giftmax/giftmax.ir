import { ensureEngine } from "@/lib/engine";
import { badInput, rateLimit, writeGuard } from "@/lib/guard";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  const lw = await writeGuard();
  if (lw) return lw;
  const rl = rateLimit(req, "simulate", 8, 10_000);
  if (rl) return rl;
  let body: { kind?: string };
  try {
    body = await req.json();
  } catch {
    return badInput("بدنه JSON نامعتبر است");
  }
  const kind = String(body.kind ?? "");
  if (!["attack", "spike"].includes(kind)) return badInput("نوع شبیه‌سازی نامعتبر است");
  const eng = await ensureEngine();
  return Response.json(eng.simulate(kind));
}
