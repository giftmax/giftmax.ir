import { ensureEngine } from "@/lib/engine";
import { badInput, rateLimit } from "@/lib/guard";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET() {
  const eng = await ensureEngine();
  return Response.json({ ok: true, rules: eng.syslogCache, devices: eng.devicesView().map((d) => ({ id: d.id, name: d.name, ip: d.ip })), ranges: eng.rangesCache.map((r) => ({ id: r.id, name: r.name })) });
}

export async function POST(req: Request) {
  const rl = rateLimit(req, "syslog", 15, 10_000);
  if (rl) return rl;
  let body: { targetType?: string; target?: string; direction?: string };
  try {
    body = await req.json();
  } catch {
    return badInput("بدنه نامعتبر");
  }
  const eng = await ensureEngine();
  const res = await eng.syslogAdd({ targetType: String(body.targetType ?? ""), target: String(body.target ?? "").trim(), direction: String(body.direction ?? "in") });
  if (!res.ok) return badInput(res.error ?? "خطا");
  return Response.json(res);
}

export async function PATCH(req: Request) {
  const rl = rateLimit(req, "syslog-patch", 20, 10_000);
  if (rl) return rl;
  let body: { id?: number };
  try {
    body = await req.json();
  } catch {
    return badInput("بدنه نامعتبر");
  }
  const eng = await ensureEngine();
  await eng.syslogToggle(Number(body.id));
  return Response.json({ ok: true });
}

export async function DELETE(req: Request) {
  const rl = rateLimit(req, "syslog-del", 15, 10_000);
  if (rl) return rl;
  const eng = await ensureEngine();
  await eng.syslogDelete(Number(new URL(req.url).searchParams.get("id")));
  return Response.json({ ok: true });
}
