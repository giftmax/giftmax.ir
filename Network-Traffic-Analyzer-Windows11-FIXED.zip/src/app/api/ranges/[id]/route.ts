import { ensureEngine } from "@/lib/engine";
import { badInput, rateLimit } from "@/lib/guard";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const rl = rateLimit(req, "range", 60, 10_000);
  if (rl) return rl;
  const { id } = await ctx.params;
  const n = Number(id);
  if (!Number.isInteger(n)) return badInput("شناسه نامعتبر است");
  const eng = await ensureEngine();
  const det = eng.rangeDetail(n);
  if (!det) return Response.json({ ok: false, error: "رنج یافت نشد" }, { status: 404 });
  const trend = await eng.rangeTrend(n);
  return Response.json({ ok: true, ...det, ...trend });
}
