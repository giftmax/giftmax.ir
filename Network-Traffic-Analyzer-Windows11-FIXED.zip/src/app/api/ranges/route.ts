import { ensureEngine } from "@/lib/engine";
import { parseCidr } from "@/lib/format";
import { badInput, rateLimit, writeGuard } from "@/lib/guard";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET() {
  const eng = await ensureEngine();
  return Response.json({ ok: true, ranges: eng.bootstrap().ranges });
}

export async function POST(req: Request) {
  const lw = await writeGuard();
  if (lw) return lw;
  const rl = rateLimit(req, "ranges-post", 20, 10_000);
  if (rl) return rl;
  let body: { name?: string; cidr?: string; kind?: string; color?: string };
  try {
    body = await req.json();
  } catch {
    return badInput("بدنه JSON نامعتبر است");
  }
  const name = String(body.name ?? "").trim();
  const cidr = String(body.cidr ?? "").trim();
  const kind = ["lan", "servers", "dmz", "wan", "iot"].includes(String(body.kind)) ? String(body.kind) : "lan";
  const color = /^#[0-9a-fA-F]{6}$/.test(String(body.color)) ? String(body.color) : "#22d3ee";
  const groupName = String((body as { group?: string }).group ?? "").trim().slice(0, 60);
  if (name.length < 2 || name.length > 60) return badInput("نام رنج باید بین ۲ تا ۶۰ کاراکتر باشد");
  if (!parseCidr(cidr)) return badInput("فرمت CIDR معتبر نیست — نمونه: 10.0.0.0/24");
  const eng = await ensureEngine();
  if (eng.rangesCache.length >= 10) return badInput("حداکثر ۱۰ رنج قابل تعریف است");
  const res = await eng.addRange(name, cidr, kind, color, groupName);
  if (!res.ok) return badInput(res.error ?? "خطا");
  return Response.json({ ok: true, id: res.id });
}

export async function DELETE(req: Request) {
  const lw = await writeGuard();
  if (lw) return lw;
  const rl = rateLimit(req, "ranges-del", 10, 10_000);
  if (rl) return rl;
  const id = Number(new URL(req.url).searchParams.get("id"));
  if (!Number.isInteger(id) || id <= 0) return badInput("شناسه نامعتبر است");
  const eng = await ensureEngine();
  await eng.removeRange(id);
  return Response.json({ ok: true });
}
