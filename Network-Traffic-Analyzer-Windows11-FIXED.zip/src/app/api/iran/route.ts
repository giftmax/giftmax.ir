import { ensureEngine } from "@/lib/engine";
import { rateLimit } from "@/lib/guard";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  const rl = rateLimit(req, "iran", 30, 10_000);
  if (rl) return rl;
  const eng = await ensureEngine();
  return Response.json({ ok: true, ...eng.iranView(), threats: eng.threatsView().list });
}
