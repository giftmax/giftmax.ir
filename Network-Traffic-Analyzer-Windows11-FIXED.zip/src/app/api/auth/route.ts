import { ensureEngine } from "@/lib/engine";
import { readSession, sessionFromRequest, setCookieHeader, signSession, clearCookieHeader } from "@/lib/auth";
import { badInput, rateLimit } from "@/lib/guard";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

// ورود / خروج (POST) و وضعیت جاری (GET)
export async function POST(req: Request) {
  const rl = rateLimit(req, "auth", 12, 60_000);
  if (rl) return rl;
  let body: { action?: string; username?: string; password?: string };
  try {
    body = await req.json();
  } catch {
    return badInput("بدنه JSON نامعتبر است");
  }
  const eng = await ensureEngine();
  if (body.action === "logout") {
    return new Response(JSON.stringify({ ok: true }), { headers: { "Set-Cookie": clearCookieHeader(), "Content-Type": "application/json" } });
  }
  const username = String(body.username ?? "").trim();
  const password = String(body.password ?? "");
  if (!username || !password) return badInput("نام کاربری و رمز الزامی است");
  const user = await eng.verifyLogin(username, password);
  if (!user) return Response.json({ ok: false, error: "نام کاربری یا رمز عبور اشتباه است" }, { status: 401 });
  const token = await signSession(user);
  return new Response(JSON.stringify({ ok: true, user }), {
    headers: { "Set-Cookie": setCookieHeader(token), "Content-Type": "application/json" },
  });
}

export async function GET(req: Request) {
  await ensureEngine();
  const u = await sessionFromRequest(req);
  if (!u) return Response.json({ ok: false, user: null }, { status: 401 });
  return Response.json({ ok: true, user: { id: u.id, username: u.username, role: u.role, perms: u.perms } });
}

// تغییر رمز خود کاربر
export async function PUT(req: Request) {
  const rl = rateLimit(req, "auth-pw", 10, 60_000);
  if (rl) return rl;
  const session = await sessionFromRequest(req);
  if (!session) return Response.json({ ok: false, error: "ابتدا وارد شوید" }, { status: 401 });
  let body: { oldPassword?: string; newPassword?: string };
  try {
    body = await req.json();
  } catch {
    return badInput("بدنه نامعتبر");
  }
  const np = String(body.newPassword ?? "");
  if (np.length < 4) return badInput("رمز جدید باید حداقل ۴ کاراکتر باشد");
  const eng = await ensureEngine();
  const res = await eng.changePassword(session.username, String(body.oldPassword ?? ""), np);
  if (!res.ok) return badInput(res.error ?? "خطا");
  return Response.json({ ok: true });
}

export { readSession };
