import { ensureEngine } from "@/lib/engine";
import { sessionFromRequest, PERM_TABS } from "@/lib/auth";
import { badInput, rateLimit } from "@/lib/guard";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

async function adminOnly(req: Request) {
  const s = await sessionFromRequest(req);
  return s && (s.role === "admin" || s.username === "admin") ? s : null;
}

export async function GET(req: Request) {
  if (!(await adminOnly(req))) return Response.json({ ok: false, error: "دسترسی مدیر لازم است" }, { status: 403 });
  const eng = await ensureEngine();
  return Response.json({ ok: true, users: await eng.listUsers(), tabs: PERM_TABS });
}

export async function POST(req: Request) {
  const rl = rateLimit(req, "users", 15, 60_000);
  if (rl) return rl;
  if (!(await adminOnly(req))) return Response.json({ ok: false, error: "دسترسی مدیر لازم است" }, { status: 403 });
  let body: { username?: string; password?: string; perms?: string[]; role?: string };
  try {
    body = await req.json();
  } catch {
    return badInput("بدنه نامعتبر");
  }
  const username = String(body.username ?? "").trim();
  const password = String(body.password ?? "");
  if (username.length < 3 || password.length < 4) return badInput("نام کاربری ≥۳ و رمز ≥۴ کاراکتر");
  const validKeys = new Set<string>(PERM_TABS.map((t) => t.key));
  const perms = (Array.isArray(body.perms) ? body.perms : []).filter((p) => validKeys.has(String(p))).map(String);
  const eng = await ensureEngine();
  const res = await eng.addUser({ username, password, perms, role: body.role === "admin" ? "admin" : "operator" });
  if (!res.ok) return badInput(res.error ?? "خطا");
  return Response.json({ ok: true });
}

export async function PATCH(req: Request) {
  if (!(await adminOnly(req))) return Response.json({ ok: false, error: "دسترسی مدیر لازم است" }, { status: 403 });
  let body: { id?: number; perms?: string[]; active?: boolean; password?: string };
  try {
    body = await req.json();
  } catch {
    return badInput("بدنه نامعتبر");
  }
  const id = Number(body.id);
  if (!Number.isInteger(id)) return badInput("شناسه نامعتبر");
  const eng = await ensureEngine();
  await eng.patchUser(id, { perms: body.perms, active: body.active, password: body.password });
  return Response.json({ ok: true });
}

export async function DELETE(req: Request) {
  if (!(await adminOnly(req))) return Response.json({ ok: false, error: "دسترسی مدیر لازم است" }, { status: 403 });
  const u = new URL(req.url);
  const id = Number(u.searchParams.get("id"));
  const username = String(u.searchParams.get("username") ?? "");
  const eng = await ensureEngine();
  const res = await eng.deleteUser(id, username);
  if (!res.ok) return badInput(res.error ?? "خطا");
  return Response.json({ ok: true });
}
