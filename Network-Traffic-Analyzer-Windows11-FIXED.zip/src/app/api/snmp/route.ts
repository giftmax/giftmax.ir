import { ensureEngine } from "@/lib/engine";
import { badInput, rateLimit, writeGuard } from "@/lib/guard";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  const rl = rateLimit(req, "snmp", 40, 10_000);
  if (rl) return rl;
  const eng = await ensureEngine();
  return Response.json({ ok: true, ...eng.snmpView() });
}

export async function POST(req: Request) {
  const lw = await writeGuard();
  if (lw) return lw;
  const rl = rateLimit(req, "snmp-role", 20, 10_000);
  if (rl) return rl;
  let body: { op?: string; id?: number; name?: string; deviceKind?: string; version?: string; user?: string; oids?: string[]; acls?: string[]; enabled?: boolean };
  try {
    body = await req.json();
  } catch {
    return badInput("بدنه نامعتبر");
  }
  const eng = await ensureEngine();
  const name = String(body.name ?? "").trim();
  if (name.length < 3) return badInput("نام نقش الزامی است (حداقل ۳ حرف)");
  const res = await eng.snmpRoleSave({
    id: body.id ? Number(body.id) : undefined,
    name,
    deviceKind: String(body.deviceKind ?? "all"),
    version: String(body.version ?? "v2c"),
    user: String(body.user ?? ""),
    oids: Array.isArray(body.oids) ? body.oids.map(String) : [],
    acls: Array.isArray(body.acls) ? body.acls.map(String) : [],
    enabled: body.enabled !== false,
  });
  return Response.json(res);
}

export async function PATCH(req: Request) {
  const lw = await writeGuard();
  if (lw) return lw;
  const rl = rateLimit(req, "snmp-dev", 30, 10_000);
  if (rl) return rl;
  let body: { id?: number; version?: string; acl?: string; snmp?: boolean };
  try {
    body = await req.json();
  } catch {
    return badInput("بدنه نامعتبر");
  }
  const eng = await ensureEngine();
  const res = await eng.patchDevSnmp(Number(body.id), { version: body.version ? String(body.version) : undefined, acl: body.acl !== undefined ? String(body.acl) : undefined, snmp: body.snmp });
  return Response.json(res);
}

export async function DELETE(req: Request) {
  const lw = await writeGuard();
  if (lw) return lw;
  const rl = rateLimit(req, "snmp-del", 10, 10_000);
  if (rl) return rl;
  const eng = await ensureEngine();
  await eng.snmpRoleDelete(Number(new URL(req.url).searchParams.get("id")));
  return Response.json({ ok: true });
}
