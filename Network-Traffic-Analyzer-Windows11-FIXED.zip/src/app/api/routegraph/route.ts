import { ensureEngine } from "@/lib/engine";
import { rateLimit, badInput } from "@/lib/guard";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  const rl = rateLimit(req, "routegraph", 40, 10_000);
  if (rl) return rl;
  const eng = await ensureEngine();
  const u = new URL(req.url);
  const from = Number(u.searchParams.get("from"));
  const to = Number(u.searchParams.get("to"));
  if (Number.isInteger(from) && Number.isInteger(to) && from > 0 && to > 0) {
    const path = eng.findPath(from, to);
    if (!path.ok) return badInput("مسیری بین این دو گره یافت نشد");
    return Response.json(path);
  }
  return Response.json({ ok: true, ...eng.graph() });
}
