import { ensureEngine } from "@/lib/engine";
import { EVT_FA, SEV_FA, faDateTime, fmtBytes } from "@/lib/format";
import { badInput, rateLimit } from "@/lib/guard";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  const rl = rateLimit(req, "export", 6, 10_000);
  if (rl) return rl;
  const u = new URL(req.url);
  const type = u.searchParams.get("type");
  const eng = await ensureEngine();
  let csv = "";
  let name = "export.csv";
  if (type === "events") {
    name = "security-events.csv";
    csv = "زمان,مبدا,مقصد,نوع,شدت,اقدام,جزئیات\n";
    for (const e of eng.recentEvents.slice(-500)) {
      csv += `${faDateTime(e.ts)},${e.srcIp},${e.dstIp},${EVT_FA[e.type] ?? e.type},${SEV_FA[e.severity] ?? e.severity},${e.action === "blocked" ? "مسدود شد" : "ثبت شد"},"${(e.detail ?? "").replace(/"/g, '""')}"\n`;
    }
  } else if (type === "ips") {
    name = "ip-usage.csv";
    csv = "IP,نام میزبان,رنج,نرخ دریافت (b/s),نرخ ارسال (b/s),نشست,وضعیت\n";
    const snap = eng.snapshot();
    for (const row of snap.all) {
      const r = eng.rangesCache.find((x) => x.id === row.rangeId);
      csv += `${row.ip},"${row.host}",${r?.name ?? "برون‌مرزی"},${row.i.toFixed(0)},${row.o.toFixed(0)},${row.s},${row.susp ? "مشکوک" : "نرمال"}\n`;
    }
  } else if (type === "daily") {
    name = "daily-usage.csv";
    csv = "IP,حجم دانلود,حجم آپلود,نشست‌ها\n";
    eng.dayAcc.forEach((v, ip) => {
      csv += `${ip},${fmtBytes(v.i)},${fmtBytes(v.o)},${v.s}\n`;
    });
  } else {
    return badInput("نوع خروجی نامعتبر است");
  }
  return new Response("\uFEFF" + csv, {
    headers: {
      "Content-Type": "text/csv; charset=utf-8",
      "Content-Disposition": `attachment; filename="${name}"`,
    },
  });
}
