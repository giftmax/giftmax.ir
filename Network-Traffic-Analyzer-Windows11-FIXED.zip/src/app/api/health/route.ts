import { ensureEngine } from "@/lib/engine";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET() {
  let engine = "starting";
  let db = false;
  try {
    const eng = await ensureEngine();
    engine = eng.started ? "running" : "starting";
    db = eng.dbReady;
  } catch {
    engine = "error";
  }
  return Response.json({ ok: true, engine, db, t: Date.now() });
}
