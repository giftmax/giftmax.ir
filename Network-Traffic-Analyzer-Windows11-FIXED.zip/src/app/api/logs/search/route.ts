import { ensureEngine } from "@/lib/engine";
import { trafficLog } from "@/lib/logger";
import { isValidIp } from "@/lib/format";
import { badInput, rateLimit } from "@/lib/guard";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

// جستجوی IP در لاگ‌های N روز اخیر — خروجی گروه‌بندی‌شده بر اساس تاریخ شمسی
export async function GET(req: Request) {
  const rl = rateLimit(req, "logs-search", 20, 10_000);
  if (rl) return rl;
  await ensureEngine();
  const u = new URL(req.url);
  const ip = (u.searchParams.get("ip") ?? "").trim();
  const days = Math.min(120, Math.max(1, Number(u.searchParams.get("days") ?? 7) || 7));
  if (!isValidIp(ip)) return badInput("آدرس IP نامعتبر است");
  const result = await trafficLog.searchByIp(ip, days);
  const total = result.reduce((a, r) => a + r.entries.length, 0);
  return Response.json({ ok: true, ip, days, totalHits: total, dir: trafficLog.dir, byDay: result });
}
