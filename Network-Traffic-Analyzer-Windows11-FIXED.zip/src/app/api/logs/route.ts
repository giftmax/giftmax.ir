import { ensureEngine } from "@/lib/engine";
import { trafficLog } from "@/lib/logger";
import { badInput, rateLimit } from "@/lib/guard";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

// تنظیمات + فهرست فایل‌های روزانه + آمار
export async function GET(req: Request) {
  const rl = rateLimit(req, "logs", 30, 10_000);
  if (rl) return rl;
  const eng = await ensureEngine();
  const files = await trafficLog.list();
  const totalSize = files.reduce((a, f) => a + f.size, 0);
  return Response.json({
    ok: true,
    settings: eng.logInfo(),
    files,
    stats: {
      count: files.length,
      totalSize,
      oldest: files.at(-1) ?? null,
      newest: files[0] ?? null,
    },
  });
}

// ذخیره تنظیمات (مسیر + بازه نگهداشت) یا پاک‌سازی فوری
export async function POST(req: Request) {
  const rl = rateLimit(req, "logs-settings", 12, 10_000);
  if (rl) return rl;
  let body: { op?: string; dir?: string | null; retentionDays?: number | null; unit?: string };
  try {
    body = await req.json();
  } catch {
    return badInput("بدنه JSON نامعتبر است");
  }
  const eng = await ensureEngine();
  if (body.op === "purge") {
    const removed = await trafficLog.purge();
    return Response.json({ ok: true, removed });
  }
  let days: number | null = null;
  if (body.retentionDays != null) {
    const n = Number(body.retentionDays);
    if (!Number.isFinite(n) || n < 1 || n > 1460) return badInput("بازه نگهداشت باید بین ۱ تا ۱۴۶۰ روز باشد");
    days = Math.round(n);
  }
  const dir = body.dir ? String(body.dir).trim() : null;
  try {
    await eng.saveLogSettings(dir, days);
  } catch (e) {
    return badInput(e instanceof Error ? e.message : "مسیر نامعتبر است");
  }
  return Response.json({ ok: true, settings: eng.logInfo() });
}
