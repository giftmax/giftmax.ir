import { ensureEngine } from "@/lib/engine";
import { trafficLog } from "@/lib/logger";
import { badInput, rateLimit } from "@/lib/guard";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

// خواندن یک فایل لاگ (با امکان فیلتر و مسیر دلخواه برای بازخوانی)
export async function GET(req: Request) {
  const rl = rateLimit(req, "logs-file", 30, 10_000);
  if (rl) return rl;
  await ensureEngine();
  const u = new URL(req.url);
  const name = u.searchParams.get("name") ?? "";
  const search = u.searchParams.get("search") ?? undefined;
  const dir = u.searchParams.get("dir") ?? undefined;
  try {
    const data = await trafficLog.read(name, { search, dirOverride: dir, limit: 3000 });
    const m = /^netwatch-(\d{4})-(\d{2})-(\d{2})\.log$/.exec(name);
    const faDate = m ? new Date(Number(m[1]), Number(m[2]) - 1, Number(m[3])).toLocaleDateString("fa-IR", { weekday: "long", year: "numeric", month: "long", day: "numeric" }) : name;
    return Response.json({ ok: true, name, faDate, dir: dir ?? trafficLog.dir, ...data });
  } catch (e) {
    const msg = e instanceof Error && "code" in e && (e as NodeJS.ErrnoException).code === "ENOENT" ? "فایل یافت نشد — مسیر و نام فایل را بررسی کنید" : (e instanceof Error ? e.message : "خطا در خواندن فایل");
    return Response.json({ ok: false, error: msg }, { status: 404 });
  }
}
