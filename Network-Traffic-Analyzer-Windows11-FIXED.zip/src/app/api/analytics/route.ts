import { ensureEngine } from "@/lib/engine";
import { badInput, rateLimit } from "@/lib/guard";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  const rl = rateLimit(req, "analytics", 25, 10_000);
  if (rl) return rl;
  let body: { q?: string };
  try {
    body = await req.json();
  } catch {
    return badInput("بدنه نامعتبر");
  }
  const q = String(body.q ?? "").slice(0, 300);
  if (!q) return badInput("کوئری خالی است");
  const eng = await ensureEngine();
  return Response.json(await eng.analyticsQuery(q));
}

export async function GET(req: Request) {
  const rl = rateLimit(req, "insights", 30, 10_000);
  if (rl) return rl;
  const eng = await ensureEngine();
  return Response.json({ ok: true, insights: eng.insights() });
}
