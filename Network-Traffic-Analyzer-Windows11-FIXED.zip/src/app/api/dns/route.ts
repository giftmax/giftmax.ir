import { ensureEngine } from "@/lib/engine";
import { badInput, rateLimit } from "@/lib/guard";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  const rl = rateLimit(req, "dns", 40, 10_000);
  if (rl) return rl;
  const scope = ["internal", "external", "public"].includes(new URL(req.url).searchParams.get("scope") ?? "")
    ? new URL(req.url).searchParams.get("scope")!
    : "internal";
  const eng = await ensureEngine();
  return Response.json({ ok: true, scope, ...eng.dnsView(scope) });
}

export async function POST(req: Request) {
  const rl = rateLimit(req, "dns-post", 15, 10_000);
  if (rl) return rl;
  let body: { scope?: string; cidr?: string; label?: string };
  try {
    body = await req.json();
  } catch {
    return badInput("بدنه نامعتبر");
  }
  const eng = await ensureEngine();
  const res = await eng.dnsAddRange(String(body.scope ?? ""), String(body.cidr ?? ""), String(body.label ?? "").slice(0, 60));
  if (!res.ok) return badInput(res.error ?? "خطا");
  return Response.json(res);
}

export async function PATCH(req: Request) {
  const rl = rateLimit(req, "dns-patch", 30, 10_000);
  if (rl) return rl;
  let body: { id?: number; domain?: string; name?: string; inUse?: boolean };
  try {
    body = await req.json();
  } catch {
    return badInput("بدنه نامعتبر");
  }
  const id = Number(body.id);
  if (!Number.isInteger(id)) return badInput("شناسه نامعتبر");
  const eng = await ensureEngine();
  await eng.dnsPatch(id, { domain: body.domain, name: body.name, inUse: body.inUse });
  return Response.json({ ok: true });
}

export async function DELETE(req: Request) {
  const rl = rateLimit(req, "dns-del", 15, 10_000);
  if (rl) return rl;
  const id = Number(new URL(req.url).searchParams.get("id"));
  if (!Number.isInteger(id)) return badInput("شناسه نامعتبر");
  const eng = await ensureEngine();
  await eng.dnsDelete(id);
  return Response.json({ ok: true });
}
