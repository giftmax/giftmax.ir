import { ensureEngine } from "@/lib/engine";
import { isValidIp } from "@/lib/format";
import { badInput, rateLimit } from "@/lib/guard";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  const rl = rateLimit(req, "trace", 40, 10_000);
  if (rl) return rl;
  const u = new URL(req.url);
  const src = u.searchParams.get("src") ?? "192.168.1.50";
  const dst = u.searchParams.get("dst") ?? "8.8.8.8";
  if (!isValidIp(src) || !isValidIp(dst)) return badInput("آدرس IP نامعتبر است");
  const eng = await ensureEngine();
  return Response.json({ ok: true, ...eng.trace(src, dst) });
}
