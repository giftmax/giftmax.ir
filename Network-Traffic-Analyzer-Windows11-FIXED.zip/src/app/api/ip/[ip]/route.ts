import { ensureEngine } from "@/lib/engine";
import { isValidIp } from "@/lib/format";
import { badInput, rateLimit } from "@/lib/guard";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(req: Request, ctx: { params: Promise<{ ip: string }> }) {
  const rl = rateLimit(req, "ip", 60, 10_000);
  if (rl) return rl;
  const { ip } = await ctx.params;
  const ipDec = decodeURIComponent(ip);
  if (!isValidIp(ipDec)) return badInput("آدرس IP نامعتبر است");
  const eng = await ensureEngine();
  const detail = eng.ipDetail(ipDec);
  if (!detail) return Response.json({ ok: false, error: "این IP در حال حاضر رصد نمی‌شود" }, { status: 404 });
  const h1h = eng.history(ipDec, "1h");
  const h24 = await eng.historyDb(ipDec, "24h");
  const h30 = await eng.historyDb(ipDec, "30d");
  return Response.json({ ok: true, detail, h1h, h24, h30, ring: eng.spark(ipDec, 300) });
}
