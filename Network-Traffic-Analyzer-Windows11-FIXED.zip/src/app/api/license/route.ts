import { ensureEngine } from "@/lib/engine";
import { appId } from "@/lib/license";
import { badInput, rateLimit } from "@/lib/guard";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET() {
  const eng = await ensureEngine();
  return Response.json({ ok: true, lic: eng.licenseState(), appId: appId(), net: { online: eng.netOnline, ping: eng.netPing, mode: eng.netMode } });
}

export async function POST(req: Request) {
  const rl = rateLimit(req, "license", 10, 60_000);
  if (rl) return rl;
  let body: Record<string, unknown>;
  try {
    body = await req.json();
  } catch {
    return badInput("بدنه JSON نامعتبر است");
  }
  const eng = await ensureEngine();
  const op = String(body.op ?? "generate");
  if (op === "sync") {
    const r = await eng.syncNow();
    return Response.json({ ok: r.ok, msg: r.msg, same: r.same, lic: eng.licenseState() });
  }
  if (op === "mode") {
    const mode = String(body.mode);
    if (!["auto", "force-online", "force-offline"].includes(mode)) return badInput("حالت نامعتبر");
    const r = await eng.setNetMode(mode as "auto" | "force-online" | "force-offline");
    return Response.json(r);
  }
  // تولید لایسنس
  const years = Number(body.years);
  const edition = String(body.edition);
  const payload = {
    firstName: String(body.firstName ?? "").trim().slice(0, 50),
    lastName: String(body.lastName ?? "").trim().slice(0, 50),
    mobile: String(body.mobile ?? "").trim().slice(0, 20),
    org: String(body.org ?? "").trim().slice(0, 80),
    licName: String(body.licName ?? "").trim().slice(0, 80),
    edition: (["standard", "pro", "enterprise"].includes(edition) ? edition : "pro") as "standard" | "pro" | "enterprise",
    years: ([1, 2, 3].includes(years) ? years : 1) as 1 | 2 | 3,
  };
  if (!payload.firstName || !payload.lastName || !payload.org) return badInput("نام، نام خانوادگی و نام سازمان الزامی است");
  const res = await eng.generateLicense(payload);
  if (!res.ok) return badInput(res.error ?? "خطا");
  return Response.json({ ok: true, file: res.file, meta: res.meta, lic: eng.licenseState() });
}

export async function DELETE(req: Request) {
  const rl = rateLimit(req, "license-del", 5, 60_000);
  if (rl) return rl;
  const eng = await ensureEngine();
  await eng.removeLicense();
  return Response.json({ ok: true });
}
