"use client";

import { useState } from "react";
import Link from "next/link";
import { Sigma, Play, Sparkles, BookOpen } from "lucide-react";
import { usePoll } from "@/lib/useEngine";
import HCSpline from "@/components/HCChart";
import { PageHead, Section, Skeleton } from "@/components/ui";
import { fmtRate, fmtBytes, fmtInt } from "@/lib/format";

type AggRow = { dim: string; vals: number; metrics: Record<string, number> };
type Result = {
  ok: boolean; q: string; win: string; by: string; aggs: string[];
  rows: AggRow[]; series: { name: string; color: string; data: [number, number][] }[];
};
type Insights = { ok: boolean; insights: { type: string; title: string; detail: string; sev: string }[] };

const SAMPLES = [
  "stats avg(rate) max(rate) p95(rate) by range last 1h",
  "stats avg(in) stdev(in) by ip last 1h",
  "search range=شبکه | stats max(rate) by ip last 1h",
  "search suspicious=true | stats avg(rate) count(rate) by ip last 1h",
  "stats avg(rate) p95(rate) stdev(rate) by range last 24h",
  "stats avg(rate) max(rate) by range last 30d",
  "search ip=10.10.0.21 | stats avg(rate) p95(rate) last 24h",
];
const AGG_FA: Record<string, string> = { avg: "میانگین", max: "بیشینه", min: "کمینه", p95: "صدک ۹۵", p50: "میانه", stdev: "انحراف معیار", sum: "جمع کل", count: "تعداد نمونه", latest: "آخرین مقدار" };
const SEV: Record<string, string> = { high: "#fb7185", medium: "#fbbf24", low: "#34d399" };

export default function AnalyticsPage() {
  const { data: ins } = usePoll<Insights>(async () => (await fetch("/api/analytics")).json(), 8000, []);
  const [q, setQ] = useState(SAMPLES[0]);
  const [res, setRes] = useState<Result | null>(null);
  const [busy, setBusy] = useState(false);

  const run = async (qq?: string) => {
    const query = qq ?? q;
    setQ(query);
    setBusy(true);
    const r: Result = await (await fetch("/api/analytics", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ q: query }) })).json();
    setRes(r);
    setBusy(false);
  };

  const metricFmt = (k: string) => (k === "count" || k === "vals" ? (v: number) => fmtInt(v) : k === "sum" ? fmtBytes : fmtRate);

  return (
    <div className="space-y-6">
      <PageHead
        title="تحلیل SPL و آمار زنده"
        sub="زبان پرس‌وجوی تحلیلی الهام‌گرفته از Splunk SPL + محاسبات آماری دقیق (میانگین، صدک، انحراف معیار، روند رگرسیون، Z-Score) — روی دیتای زنده و تاریخی ۲۴ساعت/۳۰روز"
        chips={
          <>
            <span className="chip"><Sigma size={12} /> stats · search · last · by</span>
            <span className="chip text-slate-500">Highcharts</span>
          </>
        }
      />

      {/* بینش خودکار */}
      {ins && ins.insights.length > 0 && (
        <div className="fade-up grid gap-3 md:grid-cols-2 xl:grid-cols-4">
          {ins.insights.map((i, k) => (
            <div key={k} className="glass border-r-4 p-3.5" style={{ borderRightColor: SEV[i.sev] ?? "#94a3b8" }}>
              <div className="flex items-center gap-1.5 text-[12px] font-bold text-slate-100"><Sparkles size={13} style={{ color: SEV[i.sev] }} /> {i.title}</div>
              <div className="mt-1.5 text-[11px] leading-5 text-slate-400">{i.detail}</div>
            </div>
          ))}
        </div>
      )}

      {/* نوار کوئری */}
      <div className="glass fade-up fade-up-1 p-5">
        <Section
          icon={Sigma}
          title="کنسول کوئری SPL"
          sub="فرمت: [search فیلد=مقدار] | stats fn(field) [by ip|range|kind] [last 1h|24h|30d] — توابع: avg max min p95 p50 stdev sum count latest"
        />
        <div className="flex flex-wrap items-center gap-2" dir="ltr">
          <input
            className="input mono flex-1 !text-[12.5px]"
            value={q}
            onChange={(e) => setQ(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && run()}
            placeholder="stats avg(rate) max(rate) p95(rate) by range last 1h"
            style={{ textAlign: "left", direction: "ltr" }}
          />
          <button className="btn !py-2.5" onClick={() => run()} disabled={busy}>
            <Play size={15} className={busy ? "animate-pulse" : ""} /> {busy ? "محاسبه…" : "اجرای کوئری"}
          </button>
        </div>
        <div className="mt-2.5 flex flex-wrap gap-1.5">
          {SAMPLES.map((s) => (
            <button key={s} onClick={() => run(s)} className="chip mono !text-[9.5px] hover:!border-cyan-400/40 hover:!text-cyan-300" dir="ltr">{s}</button>
          ))}
        </div>
      </div>

      {/* نتایج */}
      {res && (
        <div className="grid gap-4 xl:grid-cols-5">
          <div className="glass fade-up fade-up-2 p-5 xl:col-span-3">
            <Section
              icon={BookOpen}
              title={`نمودار سری‌های برتر — ${res.by === "ip" ? "به تفکیک IP" : res.by === "range" ? "به تفکیک رنج" : "به تفکیک نوع"}`}
              sub={`پنجره ${res.win === "1h" ? "۱ ساعت" : res.win === "24h" ? "۲۴ ساعت" : "۳۰ روز"} — ${res.series.length} سری`}
            />
            {res.series.length ? (
              <HCSpline series={res.series.map((s) => ({ name: s.name, color: s.color, data: s.data }))} height={280} />
            ) : (
              <p className="py-10 text-center text-slate-500">داده‌ای برای نمایش نیست</p>
            )}
          </div>
          <div className="glass fade-up fade-up-3 p-5 xl:col-span-2">
            <Section icon={Sigma} title="جدول نتایج آماری" sub={`${res.rows.length} ردیف — مرتب‌شده بر اساس میانگین`} />
            <div className="scroll-thin max-h-[300px] overflow-auto">
              <table className="table-base !text-[11.5px]">
                <thead>
                  <tr>
                    <th>{res.by === "ip" ? "IP" : res.by === "range" ? "رنج" : "نوع"}</th>
                    {res.aggs.map((a) => <th key={a}>{AGG_FA[a] ?? a}</th>)}
                    <th>نمونه</th>
                  </tr>
                </thead>
                <tbody>
                  {res.rows.map((r, i) => (
                    <tr key={i}>
                      <td className="mono max-w-[150px] truncate text-cyan-300" dir="ltr" title={r.dim}>
                        {res.by === "ip" ? <Link href={`/ip/${r.dim}`} className="hover:underline">{r.dim}</Link> : r.dim}
                      </td>
                      {res.aggs.map((a) => (
                        <td key={a} className="mono text-slate-200" dir="ltr">{metricFmt(a)(r.metrics[a] ?? 0)}</td>
                      ))}
                      <td className="mono text-slate-400" dir="ltr">{fmtInt(r.vals)}</td>
                    </tr>
                  ))}
                  {!res.rows.length && <tr><td colSpan={8} className="py-8 text-center text-slate-500">نتیجه‌ای برای این کوئری نیست</td></tr>}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}
      {!res && <Skeleton h={200} />}
    </div>
  );
}
