"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { Gauge, Pause, Play, X, RotateCcw, ChevronLeft, Clock3 } from "lucide-react";
import { useSnap, type RangeSnap } from "@/lib/useEngine";
import { LiveChart, type LivePoint } from "@/components/charts";
import { PageHead, Skeleton } from "@/components/ui";
import { fmtRate, fmtBytes, fmtInt, RANGE_KIND_FA, faHM, faDate } from "@/lib/format";

type Pt = LivePoint & { top: [string, number] | null };
type WinKey = "live" | "5m" | "30m" | "1h" | "2h" | "24h" | "30d";
const WINS: { k: WinKey; label: string; n: number }[] = [
  { k: "live", label: "زنده", n: 90 },
  { k: "5m", label: "۵ دقیقه", n: 150 },
  { k: "30m", label: "۳۰ دقیقه", n: 900 },
  { k: "1h", label: "۱ ساعت", n: 1800 },
  { k: "2h", label: "۲ ساعت", n: 3600 },
  { k: "24h", label: "۲۴ ساعت", n: 0 },
  { k: "30d", label: "۳۰ روز", n: 0 },
];
type Trend = { h24: { t: number; i: number; o: number }[]; h30: { t: number; i: number; o: number }[] };

export default function WatchPage() {
  const { snap, connected } = useSnap();
  const [hist, setHist] = useState<Record<number, Pt[]>>({});
  const [paused, setPaused] = useState<Record<number, boolean>>({});
  const [hidden, setHidden] = useState<number[]>([]);
  const [wins, setWins] = useState<Record<number, WinKey>>({});
  const [trend, setTrend] = useState<Record<number, Trend>>({});

  // انباشت تاریخچه سمت کلاینت (تا ۴ ساعت) برای هر رنج
  useEffect(() => {
    if (!snap) return;
    setHist((h) => {
      const nh = { ...h };
      for (const r of snap.ranges) {
        if (paused[r.id]) continue;
        nh[r.id] = [...(nh[r.id] ?? []), { t: snap.t, a: r.i, b: r.o, top: r.top }].slice(-7200);
      }
      return nh;
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [snap]);

  // دریافت روند ۲۴ساعت/۳۰روز فقط برای کارت‌هایی که آن پنجره را انتخاب کرده‌اند
  useEffect(() => {
    const need = Object.values(wins).some((w) => w === "24h" || w === "30d");
    if (!need || !snap?.ranges.length) return;
    let alive = true;
    const load = async () => {
      const ids = snap.ranges.filter((r) => wins[r.id] === "24h" || wins[r.id] === "30d").map((r) => r.id);
      const out: Record<number, Trend> = {};
      await Promise.all(
        ids.map(async (id) => {
          try {
            const d = await (await fetch(`/api/ranges/${id}`)).json();
            out[id] = { h24: d.h24 ?? [], h30: d.h30 ?? [] };
          } catch { /* بعداً */ }
        }),
      );
      if (alive) setTrend((t) => ({ ...t, ...out }));
    };
    load();
    const iv = setInterval(load, 12000);
    return () => { alive = false; clearInterval(iv); };
  }, [wins, snap?.ranges]);

  const hostMap = useMemo(() => {
    const m = new Map<string, string>();
    (snap?.all ?? []).forEach((x) => m.set(x.ip, x.host));
    return m;
  }, [snap?.all]);

  if (!snap) return <div className="space-y-4"><Skeleton h={90} /><Skeleton h={240} /></div>;

  const visible = snap.ranges.filter((r) => !hidden.includes(r.id));

  return (
    <div className="space-y-6">
      <PageHead
        title="پایش رنج‌ها — نمای کلی زنده"
        sub="هر رنج نمودار مینیمال مستقل با پنجره زمانی قابل تعویض (زنده تا ۳۰ روز) — روی هر نقطه نگه دارید: نام و پهنای باند پرمصرف‌ترین IP همان ثانیه دقیق نمایش داده می‌شود — بدون رفرش"
        chips={
          <>
            <span className="chip"><i className={connected ? "live-dot" : "live-dot-red"} /> {connected ? "اتصال زنده" : "قطع"}</span>
            {hidden.length > 0 && (
              <button className="chip hover:!border-cyan-400/40 hover:!text-cyan-300" onClick={() => setHidden([])}>
                <RotateCcw size={11} /> بازگردانی {hidden.length} نمودار بسته
              </button>
            )}
          </>
        }
      />

      {/* پنجره زمانی سراسری — اعمال به همه نمودارها */}
      <div className="glass fade-up flex flex-wrap items-center gap-2 p-3">
        <span className="text-[11.5px] font-semibold text-slate-400">پنجره زمانی همه نمودارها:</span>
        {WINS.map((w) => (
          <button
            key={w.k}
            className="tab-btn !border !px-3 !py-1 !text-[11px] !border-slate-500/15"
            onClick={() => setWins((s) => Object.fromEntries(snap.ranges.map((r) => [r.id, w.k] as [number, WinKey])))}
          >
            {w.label}
          </button>
        ))}
        <span className="text-[10px] text-slate-600">یا برای هر نمودار جداگانه انتخاب کنید — همچنین می‌توانید پایش هر رنج را متوقف یا نمودارش را ببندید</span>
      </div>

      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
        {visible.map((r) => (
          <WatchCard
            key={r.id}
            r={r}
            win={wins[r.id] ?? "live"}
            setWin={(w) => setWins((s) => ({ ...s, [r.id]: w }))}
            data={hist[r.id] ?? []}
            paused={!!paused[r.id]}
            onPause={() => setPaused((p) => ({ ...p, [r.id]: !p[r.id] }))}
            onClose={() => setHidden((h) => [...h, r.id])}
            trend={trend[r.id]}
            hostMap={hostMap}
            topIps={(snap.internal ?? []).filter((x) => x.rangeId === r.id).slice(0, 6)}
          />
        ))}
        {!visible.length && <p className="col-span-full glass p-10 text-center text-slate-500">همه نمودارها بسته شده‌اند — از بالای صفحه «بازگردانی» را بزنید</p>}
      </div>
    </div>
  );
}

function WatchCard({
  r, win, setWin, data, paused, onPause, onClose, trend, hostMap, topIps,
}: {
  r: RangeSnap; win: WinKey; setWin: (w: WinKey) => void;
  data: Pt[]; paused: boolean; onPause: () => void; onClose: () => void;
  trend?: Trend; hostMap: Map<string, string>;
  topIps: { ip: string; host: string; i: number; o: number }[];
}) {
  const wcfg = WINS.find((w) => w.k === win)!;
  let chart: Pt[];
  if (win === "24h") chart = (trend?.h24 ?? []).map((p) => ({ t: p.t, a: p.i, b: p.o, top: null }));
  else if (win === "30d") chart = (trend?.h30 ?? []).map((p) => ({ t: p.t, a: p.i, b: p.o, top: null }));
  else chart = data.slice(-wcfg.n);
  // جمع مصرف این پنجره (حجم دانلود/آپلود)
  const dt = win === "24h" ? 3600 : win === "30d" ? 86400 : 2;
  const totIn = chart.reduce((a, p) => a + p.a * dt, 0);
  const totOut = chart.reduce((a, p) => a + (p.b ?? 0) * dt, 0);

  const extra = (i: number) => {
    const p = chart[i];
    if (!p) return null;
    if (p.top) {
      const host = hostMap.get(p.top[0]);
      return (
        <div>
          <div className="text-[10.5px] font-semibold text-slate-400">پرمصرف‌ترین IP این لحظه در رنج:</div>
          <div className="mt-1 flex items-center justify-between gap-3">
            <span className="mono text-cyan-300">{p.top[0]}</span>
            <b className="mono text-slate-100">{fmtRate(p.top[1])}</b>
          </div>
          {host && <div className="mt-0.5 text-[10px] text-slate-500">{host}</div>}
        </div>
      );
    }
    return <span className="text-slate-500">جمع‌بندی ساعتی/روزانه — پنجره «زنده» را برای دیدن IP هر لحظه انتخاب کنید</span>;
  };

  return (
    <div className="glass glass-hover relative overflow-hidden p-4">
      <div className="absolute inset-x-0 top-0 h-0.5" style={{ background: `linear-gradient(90deg, ${r.color}, transparent)` }} />
      <div className="flex items-start justify-between">
        <div className="flex items-center gap-2.5">
          <i className="mt-1 h-2.5 w-2.5 flex-none rounded-full" style={{ background: r.color, boxShadow: `0 0 10px ${r.color}` }} />
          <div>
            <Link href={`/ranges/${r.id}`} className="group flex items-center gap-1 text-[13px] font-bold text-slate-100 hover:text-cyan-200">
              {r.name} <ChevronLeft size={13} className="opacity-0 transition-opacity group-hover:opacity-100" />
            </Link>
            <div className="mono mt-0.5 text-[10px] text-slate-500">{r.cidr} — {RANGE_KIND_FA[r.kind] ?? r.kind}</div>
          </div>
        </div>
        <div className="flex items-center gap-1">
          <button onClick={onPause} className={`rounded-lg p-1.5 transition-colors ${paused ? "bg-amber-500/15 text-amber-300" : "text-slate-500 hover:bg-slate-500/10 hover:text-slate-200"}`} title={paused ? "ادامه پایش" : "توقف پایش این رنج"}>
            {paused ? <Play size={13} /> : <Pause size={13} />}
          </button>
          <button onClick={onClose} className="rounded-lg p-1.5 text-slate-500 transition-colors hover:bg-rose-500/10 hover:text-rose-300" title="بستن نمودار"><X size={13} /></button>
        </div>
      </div>

      <div className="mt-2 flex items-end justify-between" dir="ltr">
        <div className="text-left">
          <div className="mono text-[16px] font-extrabold" style={{ color: r.color }}>{fmtRate(r.i + r.o)}</div>
          <div className="text-[9.5px] text-slate-500">مجموع لحظه‌ای ↓↑</div>
        </div>
        <div className="text-right text-[10px] leading-4 text-slate-500">
          {fmtInt(r.active)} فعال از {fmtInt(r.used)}<br />
          {r.susp > 0 && <span className="text-rose-300">{r.susp} مشکوک</span>}
        </div>
      </div>

      <div className="relative mt-2">
        <LiveChart
          data={chart}
          height={110}
          colorA={r.color}
          extra={extra}
          timeFmt={win === "30d" ? faDate : win === "24h" ? faHM : undefined}
        />
        {paused && (
          <div className="absolute inset-0 grid place-items-center rounded-xl bg-[#05070e]/70 backdrop-blur-[2px]">
            <span className="chip !text-[11px]" style={{ color: "#fbbf24", borderColor: "#fbbf2444", background: "#fbbf2412" }}><Pause size={12} /> پایش این رنج موقتاً متوقف است</span>
          </div>
        )}
      </div>

      <div className="mt-2 flex items-center justify-between gap-2 rounded-lg border border-slate-500/10 bg-slate-500/5 px-2.5 py-1.5 text-[9.5px] text-slate-400">
        <span>مجموع مصرف این پنجره:</span>
        <span className="mono" dir="ltr"><b className="text-cyan-300">↓{fmtBytes(totIn)}</b> <b className="text-violet-300">↑{fmtBytes(totOut)}</b></span>
      </div>

      <div className="mt-2 flex flex-wrap gap-1">
        {WINS.map((w) => (
          <button key={w.k} onClick={() => setWin(w.k)} className={`tab-btn !px-2 !py-0.5 !text-[9.5px] !border ${win === w.k ? "active" : "!border-slate-500/15"}`} style={win === w.k ? { color: r.color, borderColor: `${r.color}55`, background: `${r.color}12` } : {}}>
            {w.label}
          </button>
        ))}
      </div>

      <div className="mt-2.5 space-y-1 border-t border-slate-500/10 pt-2">
        <div className="flex items-center gap-1.5 text-[9.5px] font-semibold text-slate-500"><Clock3 size={10} /> بیشترین پهنای باند مصرفی لحظه‌ای این رنج:</div>
        {topIps.map((x) => (
          <div key={x.ip} className="flex items-center justify-between gap-2 text-[10.5px]">
            <Link href={`/ip/${x.ip}`} className="mono w-24 flex-none text-cyan-300 hover:underline">{x.ip}</Link>
            <div className="flex flex-1 items-center gap-1.5">
              <div className="progress-track flex-1"><div className="progress-fill" style={{ width: `${topIps[0] ? ((x.i + x.o) / (topIps[0].i + topIps[0].o)) * 100 : 0}%`, background: r.color }} /></div>
              <span className="mono w-16 flex-none text-left text-cyan-200" dir="ltr">↓{fmtRate(x.i)}</span>
              <span className="mono w-16 flex-none text-left text-violet-300" dir="ltr">↑{fmtRate(x.o)}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
