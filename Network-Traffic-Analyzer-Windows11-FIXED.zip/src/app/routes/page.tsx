"use client";

import { Suspense, useEffect, useMemo, useRef, useState } from "react";
import { useSearchParams } from "next/navigation";
import { Waypoints, Play, Pause, Terminal, GitCommitHorizontal, ArrowLeft, Search } from "lucide-react";
import { useDevices } from "@/app/servers/page";
import { useSnap, type PktOut } from "@/lib/useEngine";
import { KindIcon, PageHead, Section, Skeleton } from "@/components/ui";
import { faTime, fmtInt } from "@/lib/format";

type TraceNode = { name: string; ip: string; kind: string; lat: number; loss: number; role: string };
type Trace = { ok: boolean; nodes: TraceNode[]; totalLat: number; hops: number };

const PROTO_COLORS: Record<string, string> = {
  HTTPS: "#22d3ee", HTTP: "#60a5fa", DNS: "#34d399", SMB: "#a78bfa", RDP: "#f472b6",
  ICMP: "#fbbf24", NTP: "#94a3b8", SSH: "#fb923c", SQL: "#f87171", "WIN-RM": "#38bdf8", SMTP: "#c084fc",
};

function RoutesInner() {
  const sp = useSearchParams();
  const { data: devData } = useDevices();
  const { snap, connected } = useSnap();
  const [src, setSrc] = useState(sp.get("from") ?? "192.168.1.50");
  const [dst, setDst] = useState(sp.get("to") ?? "8.8.8.8");
  const [trace, setTrace] = useState<Trace | null>(null);
  const [textView, setTextView] = useState(false);
  const [pkts, setPkts] = useState<PktOut[]>([]);
  const [paused, setPaused] = useState(false);
  const [filter, setFilter] = useState("");
  const seenRef = useRef(0);

  useEffect(() => {
    if (sp.get("to")) setDst(sp.get("to")!);
    if (sp.get("from")) setSrc(sp.get("from")!);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    let alive = true;
    const run = async () => {
      try {
        const t: Trace = await (await fetch(`/api/trace?src=${encodeURIComponent(src)}&dst=${encodeURIComponent(dst)}`)).json();
        if (alive && t.ok) setTrace(t);
      } catch { /* بعداً */ }
    };
    run();
    const iv = setInterval(run, 2500);
    return () => { alive = false; clearInterval(iv); };
  }, [src, dst]);

  useEffect(() => {
    if (!snap || paused) return;
    const fresh = snap.pkts.filter((p) => p.t > seenRef.current);
    if (fresh.length) {
      seenRef.current = Math.max(...fresh.map((p) => p.t));
      setPkts((prev) => [...fresh.reverse(), ...prev].slice(0, 80));
    }
  }, [snap, paused]);

  const srcOpts = useMemo(() => {
    const fromSnap = (snap?.internal ?? []).slice(0, 10).map((x) => ({ ip: x.ip, name: x.host }));
    return fromSnap.length ? fromSnap : [{ ip: "192.168.1.50", name: "PC-50" }];
  }, [snap]);
  const dstOpts = useMemo(() => {
    const devs = (devData?.devices ?? []).map((d) => ({ ip: d.ip, name: d.name }));
    return [{ ip: "8.8.8.8", name: "Google DNS (خارجی)" }, ...devs];
  }, [devData]);

  const rows = pkts.filter((p) => !filter || p.proto.includes(filter.toUpperCase()) || p.src.includes(filter) || p.dst.includes(filter));

  return (
    <div className="space-y-6">
      <PageHead
        title="مسیر و ردیابی شبکه"
        sub="شماتیک زنده مسیر عبور ترافیک از مبدأ تا مقصد (سوئیچ‌ها، فایروال، روترها) به‌همراه فید زنده بسته‌ها به سبک Wireshark"
        chips={<span className="chip"><GitCommitHorizontal size={12} /> TraceRoute بصری</span>}
      />

      {/* انتخاب مبدأ/مقصد */}
      <div className="glass fade-up flex flex-wrap items-end gap-3 p-4">
        <div>
          <label className="mb-1.5 block text-[11px] text-slate-500">مبدأ (Source)</label>
          <select className="input mono !w-64" dir="ltr" value={src} onChange={(e) => setSrc(e.target.value)}>
            {!srcOpts.some((o) => o.ip === src) && <option value={src}>{src}</option>}
            {srcOpts.map((o) => <option key={o.ip} value={o.ip}>{o.ip} — {o.name}</option>)}
          </select>
        </div>
        <div className="pb-3 text-slate-500"><ArrowLeft size={17} /></div>
        <div>
          <label className="mb-1.5 block text-[11px] text-slate-500">مقصد (Destination)</label>
          <select className="input mono !w-72" dir="ltr" value={dst} onChange={(e) => setDst(e.target.value)}>
            {!dstOpts.some((o) => o.ip === dst) && <option value={dst}>{dst}</option>}
            {dstOpts.map((o) => <option key={o.ip} value={o.ip}>{o.ip} — {o.name}</option>)}
          </select>
        </div>
        <button className={`tab-btn !border ${textView ? "active" : "!border-slate-500/20"}`} onClick={() => setTextView(!textView)}>
          <Terminal size={13} className="ml-1 inline" /> نمای Tracert متنی
        </button>
        {trace && (
          <span className="chip mono" dir="ltr">{trace.hops} hops — {trace.totalLat}ms</span>
        )}
      </div>

      {/* شماتیک مسیر */}
      <div className="glass fade-up fade-up-1 overflow-x-auto p-6">
        <Section icon={Waypoints} title="شماتیک مسیر عبور بسته‌ها" sub="گره‌های زنده — جریان بسته‌ها با انیمیشن نمایش داده می‌شود" />
        {!trace ? (
          <Skeleton h={140} />
        ) : textView ? (
          <pre className="mono overflow-auto rounded-xl border border-slate-500/15 bg-black/40 p-4 text-[12px] leading-7 text-emerald-200" dir="ltr">
            {`Tracing route to ${dst} over a maximum of 30 hops:\n`}
            {trace.nodes.map((n, i) =>
              i === 0
                ? `\n  src                   ${n.ip}  (${n.name})`
                : `\n  ${String(i).padStart(3)}  ${String(n.lat + " ms").padStart(8)}  ${String((n.lat + 0.2).toFixed(1) + " ms").padStart(8)}  ${String((n.lat + 0.1).toFixed(1) + " ms").padStart(8)}  ${n.name} [${n.ip}]`,
            ).join("")}
            {`\n\nTrace complete — ${trace.hops} hops, total ${trace.totalLat} ms`}
          </pre>
        ) : (
          <div className="flex min-w-[900px] items-stretch justify-between gap-0 py-4" dir="ltr">
            {trace.nodes.map((n, i) => (
              <div key={i} className="flex flex-1 items-center">
                <div className="relative flex flex-col items-center text-center">
                  <span className="mb-2 grid h-6 w-6 place-items-center rounded-full border border-cyan-400/40 bg-cyan-400/10 text-[10px] font-bold text-cyan-300 mono">{i === 0 ? "S" : i === trace.nodes.length - 1 ? "D" : i}</span>
                  <div className={`grid h-14 w-14 place-items-center rounded-2xl border ${n.kind === "firewall" ? "border-orange-400/40 bg-orange-400/10" : n.kind === "host" ? "border-slate-400/30 bg-slate-400/10" : "border-cyan-400/30 bg-cyan-400/10"}`}>
                    <KindIcon kind={n.kind} size={24} />
                  </div>
                  <div className="mt-2 max-w-[130px] truncate text-[11px] font-semibold text-slate-200">{n.name}</div>
                  <div className="mono mt-0.5 text-[10px] text-cyan-300">{n.ip}</div>
                  <div className="mt-0.5 text-[9.5px] text-slate-500">{n.role}</div>
                  {i > 0 && <div className="mt-1 chip !text-[9.5px] !py-0" style={{ color: "#34d399" }}>{n.lat}ms</div>}
                </div>
                {i < trace.nodes.length - 1 && (
                  <svg className="mx-1 h-10 flex-1 min-w-14" viewBox="0 0 100 40" preserveAspectRatio="none">
                    <line x1="0" y1="20" x2="100" y2="20" stroke="rgba(34,211,238,0.55)" strokeWidth="1.4" className="route-flow" />
                    <polygon points="96,16 100,20 96,24" fill="rgba(34,211,238,0.8)" />
                  </svg>
                )}
              </div>
            ))}
          </div>
        )}
      </div>

      {/* فید بسته‌ها */}
      <div className="glass fade-up fade-up-2 p-5">
        <Section
          icon={Terminal}
          title="فید زنده بسته‌ها (Packet Capture)"
          sub={connected ? "نمونه‌برداری زنده از رابط مانیتور — مشابه خروجی Wireshark" : "اتصال زنده برقرار نشده"}
          action={
            <div className="flex items-center gap-2">
              <div className="relative">
                <Search size={13} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500" />
                <input className="input !w-52 !py-1.5 !pr-8 !text-[11.5px]" placeholder="فیلتر: proto/ip…" value={filter} onChange={(e) => setFilter(e.target.value)} />
              </div>
              <button className="btn btn-ghost !py-1.5 !text-[11.5px]" onClick={() => setPaused(!paused)}>
                {paused ? <Play size={13} /> : <Pause size={13} />} {paused ? "ادامه" : "توقف"}
              </button>
            </div>
          }
        />
        <div className="scroll-thin max-h-[380px] overflow-auto rounded-xl border border-slate-500/10 bg-black/30">
          <table className="table-base !text-[11.5px]">
            <thead><tr><th>#</th><th>زمان</th><th>مبدأ</th><th>مقصد</th><th>پروتکل</th><th>پورت‌ها</th><th>طول</th><th>اطلاعات</th></tr></thead>
            <tbody>
              {rows.map((p, i) => (
                <tr key={`${p.t}-${i}`} className="font-mono" dir="ltr">
                  <td className="text-slate-600">{fmtInt(rows.length - i)}</td>
                  <td className="text-slate-400">{faTime(p.t)}</td>
                  <td className="text-cyan-300">{p.src}</td>
                  <td className="text-violet-300">{p.dst}</td>
                  <td>
                    <span className="chip !text-[9.5px] !py-0" style={{ color: PROTO_COLORS[p.proto] ?? "#94a3b8", borderColor: `${PROTO_COLORS[p.proto] ?? "#94a3b8"}44`, background: `${PROTO_COLORS[p.proto] ?? "#94a3b8"}12` }}>{p.proto}</span>
                  </td>
                  <td className="text-slate-400">{p.sp} → {p.dp}</td>
                  <td className="text-slate-400">{p.len}</td>
                  <td className="max-w-[360px] truncate text-slate-500" title={p.info}>{p.info}</td>
                </tr>
              ))}
              {!rows.length && <tr><td colSpan={8} className="py-8 text-center text-slate-500">در انتظار بسته…</td></tr>}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

export default function RoutesPage() {
  return (
    <Suspense fallback={<div className="space-y-4"><Skeleton h={90} /><Skeleton h={240} /></div>}>
      <RoutesInner />
    </Suspense>
  );
}
