"use client";

import { useState } from "react";
import { Antenna, Plus, Signal, Wifi, WifiOff } from "lucide-react";
import { usePoll } from "@/lib/useEngine";
import { LiveChart, Spark } from "@/components/charts";
import { PageHead, Section, Skeleton, Empty } from "@/components/ui";
import { fmtRate, faHM, faDate, faDateTime } from "@/lib/format";

type WDev = {
  id: number; name: string; ip: string; online: boolean; lat: number;
  freq: number; ch: number; band: string; signal: number;
  quality: { label: string; c: string }; spark: number[]; stabPct: number; rate: number;
};
type HistPt = { t: number; sig: number; lat: number; up: number };
type Win = "1h" | "24h" | "10d";

export default function WirelessPage() {
  const { data, reload } = usePoll<{ ok: boolean; list: WDev[] }>(async () => (await fetch("/api/wireless")).json(), 3000, []);
  const [form, setForm] = useState({ name: "", ip: "", band: "5GHz", ch: "36" });
  const [showForm, setShowForm] = useState(false);
  const [wins, setWins] = useState<Record<number, Win>>({});
  const [hist, setHist] = useState<Record<number, HistPt[]>>({});
  const [msg, setMsg] = useState("");

  const add = async () => {
    if (!form.name || !form.ip) return;
    const res = await (await fetch("/api/devices", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name: `${form.name} (وایرلس)`, ip: form.ip, kind: "wireless", snmp: true, notes: `band:${form.band};ch:${form.ch}` }),
    })).json();
    if (res.ok) { setShowForm(false); setForm({ name: "", ip: "", band: "5GHz", ch: "36" }); setMsg("سرویس وایرلس ثبت شد"); reload(); }
    else setMsg(res.error ?? "خطا");
  };

  const loadHist = async (id: number, ip: string, w: Win) => {
    setWins((s) => ({ ...s, [id]: w }));
    const res = await (await fetch(`/api/wireless?ip=${encodeURIComponent(ip)}&win=${w}`)).json();
    if (res.ok) setHist((s) => ({ ...s, [id]: res.points }));
  };

  if (!data) return <div className="space-y-4"><Skeleton h={90} /><Skeleton h={280} /></div>;

  return (
    <div className="space-y-6">
      <PageHead
        title="سرویس‌های وایرلس (رادیو/میکروتیک)"
        sub="هر دستگاه وایرلس را با IP وارد کنید — فرکانس، کانال و قدرت سیگنال (dBm) زنده، ارزیابی کیفیت (عالی/خوب/نیاز به بهبود) و تحلیل ۱ ساعت، ۲۴ ساعت و ۱۰ روز اخیر"
        chips={<button className="btn !py-2" onClick={() => setShowForm(!showForm)}><Plus size={15} /> افزودن سرویس وایرلس</button>}
      />
      {msg && <div className="glass fade-up p-3 text-[12px] text-emerald-300">{msg}</div>}

      {showForm && (
        <div className="glass fade-up p-5">
          <Section icon={Plus} title="ثبت دستگاه/رادیو وایرلس" />
          <div className="flex flex-wrap items-end gap-3">
            <input className="input !w-60" placeholder="نام (مثلاً رادیو بام HQ)" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
            <input className="input mono !w-52" dir="ltr" placeholder="IP — 192.168.88.1" value={form.ip} onChange={(e) => setForm({ ...form, ip: e.target.value })} />
            <select className="input !w-36" value={form.band} onChange={(e) => setForm({ ...form, band: e.target.value, ch: e.target.value === "2.4GHz" ? "6" : "36" })}>
              <option value="5GHz">باند ۵ گیگاهرتز</option>
              <option value="2.4GHz">باند ۲.۴ گیگاهرتز</option>
            </select>
            <input className="input mono !w-28" dir="ltr" placeholder="کانال" value={form.ch} onChange={(e) => setForm({ ...form, ch: e.target.value.replace(/[^0-9]/g, "") })} />
            <button className="btn" onClick={add}>ثبت و پایش</button>
            <button className="btn btn-ghost" onClick={() => setShowForm(false)}>انصراف</button>
          </div>
        </div>
      )}

      {!data.list.length ? (
        <Empty text="هنوز سرویس وایرلسی ثبت نشده — IP روتر میکروتیک وایرلس‌دار را وارد کنید تا فرکانس و قدرت سیگنالش تحلیل شود" />
      ) : (
        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
          {data.list.map((d) => {
            const w = wins[d.id] ?? "1h";
            const pts = hist[d.id] ?? [];
            const chartData = pts.map((p) => ({ t: p.t, a: p.sig + 100 }));
            return (
              <div key={d.id} className="glass glass-hover p-4">
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-2.5">
                    <span className={`grid h-10 w-10 place-items-center rounded-xl border ${d.online ? "border-sky-400/40 bg-sky-400/10 text-sky-300" : "border-rose-400/40 bg-rose-400/10 text-rose-300"}`}>
                      <Antenna size={18} />
                    </span>
                    <div>
                      <div className="text-[13px] font-bold text-slate-100">{d.name}</div>
                      <div className="mono text-[10.5px] text-slate-500">{d.ip}</div>
                    </div>
                  </div>
                  <span className="chip !text-[10px]" style={d.online ? { color: "#34d399" } : { color: "#fb7185" }}>
                    {d.online ? <Wifi size={11} /> : <WifiOff size={11} />} {d.online ? `${d.lat}ms` : "قطع"}
                  </span>
                </div>

                <div className="mt-3 flex items-end justify-between rounded-xl border border-slate-500/15 bg-slate-500/5 p-3">
                  <div>
                    <div className="flex items-center gap-1.5 text-[10px] text-slate-500"><Signal size={11} /> قدرت سیگنال</div>
                    <div className="mono mt-1 text-[22px] font-extrabold leading-6" style={{ color: d.quality.c }} dir="ltr">{d.signal.toFixed(1)} dBm</div>
                  </div>
                  <span className="chip" style={{ color: d.quality.c, borderColor: `${d.quality.c}44`, background: `${d.quality.c}12` }}>{d.quality.label}</span>
                </div>

                <div className="mt-2 grid grid-cols-4 gap-1.5 text-center text-[9.5px] text-slate-500">
                  <div className="rounded-lg border border-slate-500/10 bg-slate-500/5 p-1.5">باند<br /><b className="mono text-[10.5px] text-slate-200" dir="ltr">{d.band}</b></div>
                  <div className="rounded-lg border border-slate-500/10 bg-slate-500/5 p-1.5">فرکانس<br /><b className="mono text-[10.5px] text-slate-200" dir="ltr">{d.freq}MHz</b></div>
                  <div className="rounded-lg border border-slate-500/10 bg-slate-500/5 p-1.5">کانال<br /><b className="mono text-[10.5px] text-slate-200" dir="ltr">{d.ch}</b></div>
                  <div className="rounded-lg border border-slate-500/10 bg-slate-500/5 p-1.5">پایداری<br /><b className="mono text-[10.5px]" style={{ color: d.stabPct >= 99 ? "#34d399" : "#fbbf24" }} dir="ltr">{d.stabPct}%</b></div>
                </div>

                <div className="mt-2 flex items-center justify-between text-[10.5px]" dir="ltr">
                  <Spark data={d.spark} color={d.quality.c} w={110} h={26} />
                  <span className="mono text-sky-200">{fmtRate(d.rate)}</span>
                </div>

                <div className="mt-2 flex gap-1">
                  {([["1h", "۱ ساعت"], ["24h", "۲۴ ساعت"], ["10d", "۱۰ روز"]] as [Win, string][]).map(([k, l]) => (
                    <button key={k} onClick={() => loadHist(d.id, d.ip, k)} className={`tab-btn !px-2.5 !py-0.5 !text-[9.5px] !border ${w === k ? "active" : "!border-slate-500/15"}`}>{l}</button>
                  ))}
                  <span className="mr-auto text-[9px] text-slate-600">نمودار مقیاس‌شده (dBm+۱۰۰)</span>
                </div>
                {pts.length > 1 && (
                  <div className="mt-1.5">
                    <LiveChart data={chartData} height={100} showB={false} colorA="#38bdf8" fmt={(v) => `${(v - 100).toFixed(1)} dBm`} timeFmt={w === "10d" ? faDate : faHM} />
                    <div className="mt-1 text-[9.5px] text-slate-500" dir="ltr">
                      میانگین آپتایم این بازه: <b className="text-emerald-300">{(pts.reduce((a, p) => a + p.up, 0) / pts.length).toFixed(1)}%</b>
                    </div>
                  </div>
                )}
                <div className="mt-1 text-[9.5px] text-slate-600">سیگنال ≥-۵۵ عالی، ≥-۶۵ خوب، ≥-۷۵ متوسط — کمتر یعنی آنتن/تنظیم کانال نیاز به بهبود دارد</div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
