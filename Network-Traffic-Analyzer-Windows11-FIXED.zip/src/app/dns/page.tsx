"use client";

import { useState } from "react";
import Link from "next/link";
import { Radar, Plus, FileDown, Printer, Trash2, Pencil, Check, X, Globe, Lock } from "lucide-react";
import { usePoll } from "@/lib/useEngine";
import { PageHead, Section, Skeleton, Toggle } from "@/components/ui";
import { fmtInt, fmtRate } from "@/lib/format";

type Row = { id: number; scope: string; ip: string; domain: string; name: string; inUse: boolean; label: string };
type Resp = { ok: boolean; scope: string; rows: Row[]; stats: { total: number; active: number; inactive: number; used: number; free: number; labels: string[] }; live: { id: number; rate: number; monitored: boolean }[] };
type Scope = "public" | "internal" | "external";
const SCOPE_META: Record<Scope, { label: string; desc: string; color: string }> = {
  public: { label: "رنج پابلیک (Valid)", desc: "کدام IP پابلیک خالی/استفاده است و چه نام/دامنه‌ای روی آن ست شده", color: "#60a5fa" },
  internal: { label: "DNS داخلی", desc: "دامنه‌ها و زیردامنه‌های داخلی روی IPهای سازمان", color: "#22d3ee" },
  external: { label: "DNS خارجی", desc: "دامنه‌های فعال روی رنج‌های بیرونی", color: "#a78bfa" },
};

export default function DnsPage() {
  const [scope, setScope] = useState<Scope>("internal");
  const { data, reload } = usePoll<Resp>(async () => (await fetch(`/api/dns?scope=${scope}`)).json(), 7000, [scope]);
  const [addCidr, setAddCidr] = useState("");
  const [addLabel, setAddLabel] = useState("");
  const [showAdd, setShowAdd] = useState(false);
  const [msg, setMsg] = useState("");
  const [editId, setEditId] = useState<number | null>(null);
  const [editVal, setEditVal] = useState({ domain: "", name: "" });

  const meta = SCOPE_META[scope];
  const liveMap = new Map((data?.live ?? []).map((l) => [l.id, l]));

  const addRange = async () => {
    const res = await (await fetch("/api/dns", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ scope, cidr: addCidr, label: addLabel || meta.label }) })).json();
    if (res.ok) { setMsg(`${res.count} آدرس به ${meta.label} اضافه شد — نام/دامنه هر کدام را ویرایش کنید`); setShowAdd(false); setAddCidr(""); reload(); }
    else setMsg(res.error ?? "خطا");
  };
  const saveEdit = async (id: number) => {
    await fetch("/api/dns", { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id, ...editVal }) });
    setEditId(null);
    reload();
  };
  const toggleUse = async (id: number, v: boolean) => {
    await fetch("/api/dns", { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id, inUse: v }) });
    reload();
  };
  const del = async (id: number) => {
    await fetch(`/api/dns?id=${id}`, { method: "DELETE" });
    reload();
  };

  const exportTxt = () => {
    if (!data) return;
    const lines = [
      `# ${meta.label} — خروجی ${new Date().toLocaleDateString("fa-IR")}`,
      `# تعداد: ${data.stats.total} | فعال: ${data.stats.active} | غیرفعال: ${data.stats.inactive} | آزاد: ${data.stats.free}`,
      "",
      ...data.rows.map((r) => `${r.ip}\t${r.domain || "-"}\t${r.name || "-"}\t${r.inUse ? "فعال/در حال بهره‌برداری" : r.domain || r.name ? "غیرفعال" : "آزاد"}`),
    ];
    const blob = new Blob(["\uFEFF" + lines.join("\n")], { type: "text/plain;charset=utf-8" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = `dns-${scope}-${Date.now()}.txt`;
    a.click();
  };
  const exportPdf = () => {
    if (!data) return;
    const w = window.open("", "_blank", "width=900,height=700");
    if (!w) return;
    w.document.write(`<html dir="rtl" lang="fa"><head><meta charset="utf-8"><title>${meta.label}</title><style>body{font-family:Tahoma;padding:24px;color:#111}h1{font-size:18px}table{border-collapse:collapse;width:100%;font-size:12px}td,th{border:1px solid #999;padding:6px 8px}th{background:#eee}</style></head><body>
      <h1>${meta.label} — ${new Date().toLocaleDateString("fa-IR")}</h1>
      <p>آدرس: ${data.stats.total} | فعال: ${data.stats.active} | غیرفعال: ${data.stats.inactive} | بهره‌برداری: ${data.stats.used} | آزاد: ${data.stats.free}</p>
      <table><thead><tr><th>IP</th><th>دامنه</th><th>نام سرور/توضیح</th><th>برچسب</th><th>وضعیت</th></tr></thead><tbody>
      ${data.rows.map((r) => `<tr><td>${r.ip}</td><td>${r.domain || "—"}</td><td>${r.name || "—"}</td><td>${r.label || "—"}</td><td>${r.inUse && (r.domain || r.name) ? "فعال" : r.domain || r.name ? "غیرفعال" : "آزاد"}</td></tr>`).join("")}
      </tbody></table><script>window.onload=()=>window.print()</script></body></html>`);
    w.document.close();
  };

  return (
    <div className="space-y-6">
      <PageHead
        title="DNS و رنج پابلیک"
        sub="پایش رنج‌ها برای یافتن آدرس‌های آزاد/استفاده‌شده، نام سرور و دامنه/زیردامنه ست‌شده روی هر IP — با خروجی TXT و PDF"
        chips={
          <>
            <button className="btn btn-ghost !py-2 !text-[12px]" onClick={exportTxt}><FileDown size={14} /> خروجی TXT</button>
            <button className="btn btn-ghost !py-2 !text-[12px]" onClick={exportPdf}><Printer size={14} /> خروجی PDF (چاپ)</button>
            <button className="btn !py-2 !text-[12px]" onClick={() => setShowAdd(!showAdd)}><Plus size={14} /> افزودن رنج</button>
          </>
        }
      />

      <div className="fade-up fade-up-1 grid gap-2 md:grid-cols-3">
        {(Object.keys(SCOPE_META) as Scope[]).map((k) => (
          <button key={k} onClick={() => setScope(k)} className={`glass p-4 text-right transition-all ${scope === k ? "border" : "opacity-70 hover:opacity-100"}`} style={scope === k ? { borderColor: `${SCOPE_META[k].color}66`, boxShadow: `0 0 30px -12px ${SCOPE_META[k].color}55` } : {}}>
            <div className="flex items-center gap-2.5">
              <span className="grid h-10 w-10 place-items-center rounded-xl border" style={{ color: SCOPE_META[k].color, borderColor: `${SCOPE_META[k].color}44`, background: `${SCOPE_META[k].color}12` }}>
                {k === "public" ? <Globe size={18} /> : k === "internal" ? <Lock size={18} /> : <Radar size={18} />}
              </span>
              <div>
                <div className="text-[13.5px] font-bold text-slate-100">{SCOPE_META[k].label}</div>
                <div className="mt-0.5 text-[10.5px] leading-4 text-slate-500">{SCOPE_META[k].desc}</div>
              </div>
            </div>
          </button>
        ))}
      </div>

      {showAdd && (
        <div className="glass fade-up p-5">
          <Section icon={Plus} title={`افزودن رنج به ${meta.label}`} sub="تا ۶۰ آدرس اول رنج ثبت می‌شود — سپس نام/دامنه هر آدرس را تکمیل کنید" />
          <div className="flex flex-wrap items-end gap-3">
            <input className="input mono !w-64" dir="ltr" placeholder="CIDR — 203.0.113.0/27" value={addCidr} onChange={(e) => setAddCidr(e.target.value)} />
            <input className="input !w-64" placeholder="برچسب رنج (مثلاً رنج پابلیک دفتر مرکزی)" value={addLabel} onChange={(e) => setAddLabel(e.target.value)} />
            <button className="btn" onClick={addRange}>ثبت و پایش</button>
            <button className="btn btn-ghost" onClick={() => setShowAdd(false)}>انصراف</button>
          </div>
        </div>
      )}
      {msg && <div className="glass fade-up p-3 text-[12px] text-emerald-300">{msg}</div>}

      {!data ? (
        <Skeleton h={300} />
      ) : (
        <>
          <div className="fade-up grid grid-cols-2 gap-3 md:grid-cols-5">
            {[
              ["کل آدرس‌ها", data.stats.total, "#60a5fa"], ["فعال/بهره‌برداری", data.stats.active, "#34d399"],
              ["غیرفعال", data.stats.inactive, "#fbbf24"], ["دارای نام/دامنه", data.stats.used, "#22d3ee"], ["آزاد/خالی", data.stats.free, "#94a3b8"],
            ].map(([l, v, c]) => (
              <div key={String(l)} className="glass p-3.5">
                <div className="text-[19px] font-extrabold" style={{ color: String(c) }} dir="ltr">{fmtInt(Number(v))}</div>
                <div className="text-[10.5px] text-slate-500">{String(l)}</div>
              </div>
            ))}
          </div>

          <div className="glass fade-up fade-up-2 p-5">
            <Section icon={Radar} title={`رکوردهای ${meta.label}`} sub="کلیک روی آیکون قلم برای ویرایش نام/دامنه" />
            <div className="scroll-thin max-h-[480px] overflow-auto">
              <table className="table-base">
                <thead><tr><th>IP</th><th>دامنه / زیردامنه</th><th>نام سرور / توضیح</th><th>برچسب رنج</th><th>ترافیک زنده</th><th>وضعیت</th><th></th></tr></thead>
                <tbody>
                  {data.rows.map((r) => {
                    const live = liveMap.get(r.id);
                    const editing = editId === r.id;
                    return (
                      <tr key={r.id}>
                        <td><Link href={`/ip/${r.ip}`} className="mono font-semibold text-cyan-300 hover:underline">{r.ip}</Link></td>
                        <td>
                          {editing ? (
                            <input className="input mono !w-48 !py-1 !text-[11px]" dir="ltr" value={editVal.domain} onChange={(e) => setEditVal({ ...editVal, domain: e.target.value })} placeholder="host.example.com" />
                          ) : (
                            <span className="mono text-slate-200">{r.domain || <span className="text-slate-600">—</span>}</span>
                          )}
                        </td>
                        <td>
                          {editing ? (
                            <input className="input !w-44 !py-1 !text-[11px]" value={editVal.name} onChange={(e) => setEditVal({ ...editVal, name: e.target.value })} placeholder="نام سرور…" />
                          ) : (
                            <span className="text-slate-300">{r.name || <span className="text-slate-600">—</span>}</span>
                          )}
                        </td>
                        <td><span className="chip !text-[10px]">{r.label || "—"}</span></td>
                        <td className="mono text-[11px] text-slate-300" dir="ltr">{live?.monitored ? fmtRate(live.rate) : "—"}</td>
                        <td>
                          <div className="flex items-center gap-2">
                            <Toggle on={r.inUse} onChange={() => toggleUse(r.id, !r.inUse)} />
                            <span className="chip !text-[10px]" style={r.inUse && (r.domain || r.name) ? { color: "#34d399" } : r.domain || r.name ? { color: "#fbbf24" } : { color: "#94a3b8" }}>
                              {r.inUse && (r.domain || r.name) ? "فعال" : r.domain || r.name ? "غیرفعال" : "آزاد"}
                            </span>
                          </div>
                        </td>
                        <td>
                          <div className="flex items-center gap-1">
                            {editing ? (
                              <>
                                <button className="rounded-lg p-1.5 text-emerald-300 hover:bg-emerald-500/10" onClick={() => saveEdit(r.id)}><Check size={14} /></button>
                                <button className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-500/10" onClick={() => setEditId(null)}><X size={14} /></button>
                              </>
                            ) : (
                              <>
                                <button className="rounded-lg p-1.5 text-slate-500 hover:bg-cyan-500/10 hover:text-cyan-300" onClick={() => { setEditId(r.id); setEditVal({ domain: r.domain, name: r.name }); }}><Pencil size={14} /></button>
                                <button className="rounded-lg p-1.5 text-slate-500 hover:bg-rose-500/10 hover:text-rose-300" onClick={() => del(r.id)}><Trash2 size={14} /></button>
                              </>
                            )}
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                  {!data.rows.length && <tr><td colSpan={7} className="py-10 text-center text-slate-500">هنوز آدرسی نیست — با «افزودن رنج» شروع کنید</td></tr>}
                </tbody>
              </table>
            </div>
          </div>
        </>
      )}
    </div>
  );
}
