@echo off
chcp 65001 >nul
title HDMAX NetWatch - نصب سرویس ویندوز (اجرای دائمی)
color 0E
cd /d "%~dp0.."

echo ==========================================================
echo   نصب HDMAX به‌عنوان سرویس ویندوز (با هر بار روشن‌شدن بالا می‌آید)
echo   نیازمند اجرا با دسترسی Administrator (راست‌کلیک - Run as administrator)
echo ==========================================================

REM اگر NSSM ندارید، از https://nssm.cc/download دانلود و مسیر را اینجا بگذارید
set NSSM=C:\nadir\nssm\win64\nssm.exe
set NODEDIR=C:\Program Files\nodejs

if not exist "%NSSM%" (
  echo [i] NSSM یافت نشد (%NSSM%). از nssm.cc دانلود و مسیر بالا را در همین فایل اصلاح کنید.
  pause
  exit /b 1
)

"%NSSM%" stop HDMAXNetWatch >nul 2>nul
"%NSSM%" remove HDMAXNetWatch confirm >nul 2>nul
"%NSSM%" install HDMAXNetWatch "%NODEDIR%\node.exe" "%cd%\node_modules\next\dist\bin\next" start -H 0.0.0.0 -p 3000
"%NSSM%" set HDMAXNetWatch AppDirectory "%cd%"
"%NSSM%" set HDMAXNetWatch DisplayName "HDMAX NetWatch Pro"
"%NSSM%" set HDMAXNetWatch Description "سامانه جامع مانیتورینگ و پایش رخداد شبکه - مکس‌پلاس"
"%NSSM%" set HDMAXNetWatch Start SERVICE_AUTO_START
"%NSSM%" start HDMAXNetWatch

echo.
echo ==========================================================
echo   سرویس نصب و اجرا شد! مدیریت: services.msc - HDMAXNetWatch
echo   آدرس دسترسی از هر کلاینت: http://[IP-سرور]:3000
echo ==========================================================
