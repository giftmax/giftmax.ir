<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>سبد خرید | گیفت مکس دیجیتال</title>
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link
            href="https://fonts.googleapis.com/css2?family=Vazirmatn:wght@300;400;500;600;700;800&display=swap"
            rel="stylesheet"
    />
    <link rel="stylesheet" href="assets/css/cart.css" />
</head>
<body>
<header class="site-header">
    <div class="site-header__bar">
        <div class="container">
            <div class="site-header__support">
                <span>پشتیبانی ۲۴ ساعته | فعال‌سازی آنی</span>
                <a href="tel:02175390" class="link">۰۲۱-۷۵۳۹۰</a>
            </div>
            <div class="site-header__auth">
                <a href="#" class="btn btn--ghost">ورود / ثبت‌نام</a>
                <a href="cart.html" class="btn btn--gradient">سبد خرید</a>
            </div>
        </div>
    </div>
    <div class="site-header__main">
        <div class="container">
            <button class="menu-toggle" id="menuToggle" aria-label="باز کردن منو">
                <span></span>
                <span></span>
                <span></span>
            </button>
            <a class="brand" href="index.php#top">
                <span class="brand__icon">🎁</span>
                <span class="brand__text">
              <strong>گیفت مکس دیجیتال</strong>
              <small>فروشگاه گیفت کارت اپل و سرویس‌های بین‌المللی</small>
            </span>
            </a>
            <nav class="primary-nav" id="primaryNav">
                <a href="index.php#overview">معرفی محصول</a>
                <a href="index.php#benefits">مزایا</a>
                <a href="index.php#guide">راهنمای فعال‌سازی</a>
                <a href="index.php#bundles">محصولات مرتبط</a>
                <a href="index.php#faq">سؤالات متداول</a>
                <a href="index.php#support">پشتیبانی</a>
            </nav>
            <div class="site-header__search">
                <button class="search-toggle" id="searchToggle" aria-label="جستجو">
                    <span class="icon-search"></span>
                    <span>جستجو</span>
                </button>
                <div class="search-panel" id="searchPanel">
                    <input type="text" placeholder="نام محصول یا ریجن مورد نظر را وارد کنید" />
                    <button class="btn btn--gradient">جستجو</button>
                </div>
            </div>
        </div>
    </div>
    <div class="mobile-nav" id="mobileNav">
        <a href="index.php#overview">معرفی محصول</a>
        <a href="index.php#benefits">مزایا</a>
        <a href="index.php#guide">راهنمای فعال‌سازی</a>
        <a href="index.php#bundles">محصولات مرتبط</a>
        <a href="index.php#faq">سؤالات متداول</a>
        <a href="index.php#support">پشتیبانی</a>
    </div>
</header>

<main class="cart-page">
    <section class="cart-hero">
        <div class="container">
            <nav aria-label="مسیر دسترسی" class="breadcrumbs">
                <ol>
                    <li><a href="index.php">خانه</a></li>
                    <li><a href="index.php#overview">گیفت کارت اپل</a></li>
                    <li aria-current="page">سبد خرید</li>
                </ol>
            </nav>
            <div class="cart-hero__content">
                <div>
                    <h1>سبد خرید شما</h1>
                    <p>
                        سفارش خود را مرور کنید، تعداد محصولات را تغییر دهید و در صورت داشتن کد تخفیف آن را اعمال کنید.
                        پرداخت شما از طریق درگاه‌های بانکی معتبر انجام می‌شود و کدها به صورت آنی تحویل داده خواهند شد.
                    </p>
                </div>
                <div class="cart-progress">
                    <div class="cart-progress__step active">
                        <span>۱</span>
                        <p>سبد خرید</p>
                    </div>
                    <div class="cart-progress__divider"></div>
                    <div class="cart-progress__step">
                        <span>۲</span>
                        <p>اطلاعات تماس</p>
                    </div>
                    <div class="cart-progress__divider"></div>
                    <div class="cart-progress__step">
                        <span>۳</span>
                        <p>پرداخت و دریافت کد</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="cart-board">
        <div class="container">
            <div class="cart-board__card">
                <div class="cart-board__orders">
                    <div class="cart-board__heading">
                        <div>
                            <h2>جزئیات سفارش</h2>
                            <p>محصولات خود را بررسی کنید، تعداد را تغییر دهید و در صورت نیاز آیتمی را حذف کنید.</p>
                        </div>
                        <span>قیمت‌ها به تومان</span>
                    </div>
                    <div class="cart-table">
                        <div class="cart-table__header">
                            <span>محصول</span>
                            <span>تعداد</span>
                            <span>قیمت واحد</span>
                            <span>قیمت کل</span>
                        </div>
                        <div class="cart-items">
                            <article class="cart-item" data-price="874000" data-discount="0">
                                <div class="cart-item__product">
                                    <div class="cart-item__media">
                                        <img src="images/products/telegram-premium.svg" alt="اشتراک تلگرام پریمیوم" />
                                    </div>
                                    <div class="cart-item__info">
                                        <div class="cart-item__title">
                                            <h3>اشتراک تلگرام پریمیوم ۳ ماهه</h3>
                                            <span class="badge badge--blue">تحویل آنی</span>
                                        </div>
                                        <p>فعال‌سازی مستقیم روی شماره موبایل • پشتیبانی فارسی • شامل راهنمای قدم‌به‌قدم</p>
                                    </div>
                                </div>
                                <div class="cart-item__quantity">
                                    <span>تعداد</span>
                                    <div class="quantity-control" data-quantity>
                                        <button type="button" class="quantity-control__btn" aria-label="کاهش تعداد">−</button>
                                        <input type="number" min="1" value="1" class="quantity-control__value" aria-label="تعداد" />
                                        <button type="button" class="quantity-control__btn" aria-label="افزایش تعداد">+</button>
                                    </div>
                                </div>
                                <div class="cart-item__unit">
                                    <span>قیمت واحد</span>
                                    <strong class="cart-item__price" data-item-price>۸۷۴,۰۰۰ تومان</strong>
                                </div>
                                <div class="cart-item__total">
                                    <span>مبلغ کل</span>
                                    <strong data-item-total>۸۷۴,۰۰۰ تومان</strong>
                                    <button type="button" class="cart-item__remove link link--danger" data-remove-item>حذف</button>
                                </div>
                            </article>

                            <article class="cart-item" data-price="497000" data-discount="20000">
                                <div class="cart-item__product">
                                    <div class="cart-item__media">
                                        <img src="images/products/apple-us.svg" alt="گیفت کارت اپل آمریکا" />
                                    </div>
                                    <div class="cart-item__info">
                                        <div class="cart-item__title">
                                            <h3>گیفت کارت اپل آمریکا ۱۰ دلاری</h3>
                                            <span class="badge badge--purple">تضمین اصالت</span>
                                        </div>
                                        <p>کد دیجیتال مناسب خرید اپلیکیشن، گیم و اشتراک Apple Music با پشتیبانی ۲۴ ساعته.</p>
                                    </div>
                                </div>
                                <div class="cart-item__quantity">
                                    <span>تعداد</span>
                                    <div class="quantity-control" data-quantity>
                                        <button type="button" class="quantity-control__btn" aria-label="کاهش تعداد">−</button>
                                        <input type="number" min="1" value="2" class="quantity-control__value" aria-label="تعداد" />
                                        <button type="button" class="quantity-control__btn" aria-label="افزایش تعداد">+</button>
                                    </div>
                                </div>
                                <div class="cart-item__unit">
                                    <span>قیمت واحد</span>
                                    <strong class="cart-item__price" data-item-price>۴۹۷,۰۰۰ تومان</strong>
                                </div>
                                <div class="cart-item__total">
                                    <span>مبلغ کل</span>
                                    <strong data-item-total>۹۹۴,۰۰۰ تومان</strong>
                                    <button type="button" class="cart-item__remove link link--danger" data-remove-item>حذف</button>
                                </div>
                            </article>
                        </div>
                    </div>
                    <p class="cart-empty" data-cart-empty hidden>
                        سبد خرید شما در حال حاضر خالی است. برای افزودن محصولات جدید به
                        <a href="index.php#bundles">فروشگاه گیفت مکس</a>
                        سر بزنید.
                    </p>
                    <div class="cart-board__footer">
                        <div class="cart-board__note">
                            <span class="icon-shield"></span>
                            <p>
                                تمام پرداخت‌ها با پروتکل‌های بانکی انجام می‌شود و در صورت بروز مشکل در فعال‌سازی، وجه شما بدون قید و شرط بازگشت
                                داده خواهد شد.
                            </p>
                        </div>
                        <a href="index.php#bundles" class="btn btn--outline">ادامه خرید</a>
                    </div>
                </div>

                <aside class="cart-board__invoice">
                    <div class="cart-board__heading cart-board__heading--invoice">
                        <div>
                            <h2>خلاصه صورت حساب</h2>
                            <p>مبالغ نهایی پس از اعمال تخفیف و کارمزد</p>
                        </div>
                        <span>تومان</span>
                    </div>
                    <div class="cart-summary">
                        <div class="summary-line">
                            <span>جمع جزء</span>
                            <strong data-summary="subtotal">۱,۸۶۸,۰۰۰ تومان</strong>
                        </div>
                        <div class="summary-line summary-line--success">
                            <span>تخفیف (کد تخفیف)</span>
                            <strong data-summary="discount">۴۰,۰۰۰ تومان</strong>
                        </div>
                        <div class="summary-line summary-line--muted">
                            <span>کارمزد درگاه</span>
                            <strong>۰ تومان</strong>
                        </div>
                        <div class="summary-total">
                            <span>مبلغ قابل پرداخت</span>
                            <strong data-summary="total">۱,۸۲۸,۰۰۰ تومان</strong>
                        </div>
                    </div>
                    <form class="coupon-form" data-coupon>
                        <label for="couponCode">کد تخفیف دارید؟</label>
                        <div class="coupon-form__field">
                            <input id="couponCode" type="text" placeholder="مثلاً GIFTMAX" autocomplete="off" />
                            <button type="submit" class="btn btn--ghost">اعمال</button>
                        </div>
                        <p class="coupon-form__hint">در حال حاضر کد تخفیف «WELCOME» فعال است.</p>
                    </form>
                    <div class="cart-invoice__options">
                        <label class="cart-option">
                            <input type="radio" name="paymentMethod" checked />
                            <div>
                                <strong>پرداخت آنلاین بانکی</strong>
                                <span>اتصال مستقیم به درگاه‌های امن شتاب و تحویل آنی کد</span>
                            </div>
                        </label>
                        <label class="cart-option">
                            <input type="radio" name="paymentMethod" />
                            <div>
                                <strong>استفاده از کیف پول</strong>
                                <span>موجودی شما: ۲۱۰,۰۰۰ تومان • امکان پرداخت تا سقف ۲۰٪ سفارش</span>
                            </div>
                        </label>
                    </div>
                    <button class="btn btn--gradient btn--block btn--lg cart-invoice__action" data-summary-action>
                        پرداخت آنلاین و دریافت آنی
                    </button>
                    <ul class="cart-advantages">
                        <li><span class="icon-chat"></span>پشتیبانی آنلاین و تلفنی ۲۴/۷</li>
                        <li><span class="icon-mail"></span>ارسال کد از طریق ایمیل، پیامک و پنل کاربری</li>
                        <li><span class="icon-refresh"></span>امکان استرداد در صورت بروز مشکل فعال‌سازی</li>
                    </ul>
                    <div class="cart-invoice__methods">
                        <h3>روش‌های پرداخت</h3>
                        <div class="payment-methods">
                            <span class="payment-methods__item">زرین‌پال</span>
                            <span class="payment-methods__item">آیدی‌پی</span>
                            <span class="payment-methods__item">کیف پول</span>
                        </div>
                    </div>
                </aside>
            </div>
        </div>
    </section>

    <section class="cart-support">
        <div class="container cart-support__grid">
            <div class="cart-support__card">
                <h2>سؤالی دارید؟</h2>
                <p>تیم پشتیبانی ما در تمام مراحل خرید همراه شماست. تیکت ثبت کنید یا مستقیماً تماس بگیرید.</p>
                <div class="cart-support__actions">
                    <a href="tel:02175390" class="btn btn--gradient">تماس مستقیم</a>
                    <a href="mailto:support@giftmaxdigital.ir" class="btn btn--outline">ثبت تیکت</a>
                </div>
            </div>
            <div class="cart-support__features">
                <div>
                    <span class="icon-doc"></span>
                    <div>
                        <h3>صدور فاکتور رسمی</h3>
                        <p>برای شرکت‌ها و سازمان‌ها امکان صدور فاکتور رسمی و قرارداد همکاری فراهم است.</p>
                    </div>
                </div>
                <div>
                    <span class="icon-gift"></span>
                    <div>
                        <h3>هدایای سفارشی</h3>
                        <p>در صورت خرید عمده، طرح بسته‌بندی و پیام اختصاصی برای شما آماده می‌کنیم.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>
</main>

<footer class="site-footer">
    <div class="container site-footer__grid">
        <div class="site-footer__brand">
            <span class="brand__icon">🎁</span>
            <div>
                <strong>گیفت مکس دیجیتال</strong>
                <p>مرجع تخصصی خرید گیفت کارت‌های اپل، پلی‌استیشن، ایکس‌باکس و سرویس‌های بین‌المللی با تحویل فوری.</p>
            </div>
            <form class="newsletter">
                <label for="newsletterEmail">برای اطلاع از تخفیف‌ها ایمیل خود را وارد کنید</label>
                <div class="newsletter__field">
                    <input id="newsletterEmail" type="email" placeholder="ایمیل شما" />
                    <button type="submit" class="btn btn--gradient">ثبت</button>
                </div>
            </form>
        </div>
        <div class="site-footer__links">
            <div>
                <h3>دسته‌بندی سریع</h3>
                <ul>
                    <li><a href="index.php#overview">گیفت کارت اپل</a></li>
                    <li><a href="index.php#bundles">گیفت کارت پلی‌استیشن</a></li>
                    <li><a href="index.php#bundles">گیفت کارت آمازون</a></li>
                    <li><a href="index.php#bundles">گیفت کارت استیم</a></li>
                </ul>
            </div>
            <div>
                <h3>راهنمای سریع</h3>
                <ul>
                    <li><a href="index.php#guide">آموزش ریدیم</a></li>
                    <li><a href="index.php#faq">خطاهای متداول</a></li>
                    <li><a href="index.php#support">پشتیبانی سازمانی</a></li>
                    <li><a href="#">قوانین و مقررات</a></li>
                </ul>
            </div>
            <div>
                <h3>ارتباط با ما</h3>
                <ul>
                    <li><a href="tel:02175390">۰۲۱-۷۵۳۹۰</a></li>
                    <li><a href="mailto:support@giftmaxdigital.ir">support@giftmaxdigital.ir</a></li>
                    <li>تهران، خیابان شریعتی، دفتر مرکزی گیفت مکس</li>
                </ul>
            </div>
        </div>
    </div>
    <div class="site-footer__bottom">
        <div class="container">
            <span>© ۱۴۰۳ گیفت مکس دیجیتال - تمامی حقوق محفوظ است.</span>
            <div class="footer-socials">
                <a href="#" aria-label="اینستاگرام">📸</a>
                <a href="#" aria-label="تلگرام">✈️</a>
                <a href="#" aria-label="توئیتر">🐦</a>
            </div>
        </div>
    </div>
</footer>

<script src="assets/js/cart.js"></script>
</body>
</html>