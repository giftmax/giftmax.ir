<?php
wp_head();
?>
<style>
    html{
        margin: 0px !important;
    }
</style>
<img src="<?=get_template_directory_uri()?>/assets/img/header-bottom404-2048x77.png" class="attachment-full size-full wp-image-585" alt="" sizes="(max-width: 2560px) 100vw, 2560px">
<div class="flex container-xl-w mx-auto justify-between" style="width: 849px;margin: 0px auto;transform: translate(0, 50%)">
    <div class="lg:w-40 flex flex-col gap-3 items-center">
        <img width="400" src="<?=get_template_directory_uri()?>/assets/img/Frame-1437255889.png" class="attachment-full size-full wp-image-836" alt="">
        <div style="width: 50%; height: 1px;background-color: #E7E8EA;margin: 3px 0"></div>
        <div style="color: #717171;font-size: 16px">
            <p>متاسفانه صفحه مورد نظر شما پیدا نشد.</p>
        </div>
        <div class="flex justify-center">
            <a href="<?=home_url()?>" style="background-color: #00D1B2;border-radius: 12px 12px 12px 12px;color: #FFF;box-shadow: none; text-decoration: none;font-size: 15px; line-height: 1; padding: 12px 24px;fill: #fff; text-align: center; transition: all .3s;">صفحه اصلی</a>
        </div>
    </div>
    <div class="lg:w-60">
        <img width="500" src="<?=get_template_directory_uri()?>/assets/img/Group-345093.png">
    </div>
</div>
<img src="<?=get_template_directory_uri()?>/assets/img/header-bottom404-2048x77.png" class="attachment-full size-full wp-image-585" alt="" style="position: absolute;bottom: 0;">
