<?php

define( 'GIFTMAX_PATH', get_template_directory() );
define( 'GIFTMAX_URI',  get_template_directory_uri() );
define( 'GIFTMAX__FILE', __FILE__ );
define( 'GIFTMAX__PATH', plugin_dir_path(GIFTMAX__FILE) );
define( 'GIFTMAX__URI',str_replace('\\','/',GIFTMAX__PATH));
date_default_timezone_set('Asia/Tehran');

require_once GIFTMAX_PATH . '/app/Autoloader.php';


\Giftmax\Autoloader::run( GIFTMAX_PATH . '/app', 'Giftmax' );

if ( class_exists( '\Giftmax\Theme' ) ) {
    \Giftmax\Theme::get_instance();
}
require_once GIFTMAX_PATH . '/core/common.php';

/**
 * Temporary emergency switch:
 * Skip WooCommerce email sending when server mail()/SMTP is broken.
 * Set to false (or remove block) after SMTP is configured.
 */
if ( ! defined( 'GIFTMAX_DISABLE_WC_EMAILS' ) ) {
    define( 'GIFTMAX_DISABLE_WC_EMAILS', true );
}

function giftmax_skip_wc_mail_callback() {
    return true;
}

add_filter( 'woocommerce_mail_callback', function ( $callback ) {
    if ( defined( 'GIFTMAX_DISABLE_WC_EMAILS' ) && GIFTMAX_DISABLE_WC_EMAILS ) {
        return 'giftmax_skip_wc_mail_callback';
    }
    return $callback;
}, 10, 1 );

function profile_rewrite_rule() {
    // قوانین profile
    add_rewrite_rule(
        '^profile/([^/]+)/?$',
        'index.php?pagename=profile&profile_tab=$matches[1]',
        'top'
    );

    add_rewrite_rule(
        '^profile/invoices/([0-9]+)/?$',
        'index.php?pagename=profile&profile_tab=invoices&order_id=$matches[1]',
        'top'
    );

    // قوانین ticket - با prefix متفاوت
    add_rewrite_rule(
        '^ticket/([^/]+)/?$',
        'index.php?pagename=ticket&ticket_tab=$matches[1]',
        'top'
    );

    add_rewrite_rule(
        '^ticket/id/([0-9]+)/?$',
        'index.php?pagename=ticket&ticket_tab=id&id=$matches[1]',
        'top'
    );
}
add_action( 'init', 'profile_rewrite_rule' );
function register_profile_query_var( $vars ) {
    $vars[] = 'profile_tab';
    $vars[] = 'ticket_tab';
    $vars[] = 'order_id';
    $vars[] = 'id';
    return $vars;
}
add_filter( 'query_vars', 'register_profile_query_var' );
add_action('wp_login', function($user_login, $user) {
    if ( WC()->session && WC()->cart ) {
        $guest_cart = WC()->session->get('cart', []);
        if ( ! empty($guest_cart) ) {
            foreach ( $guest_cart as $cart_item_key => $values ) {
                WC()->cart->add_to_cart(
                    $values['product_id'],
                    $values['quantity'],
                    $values['variation_id'] ?? 0,
                    $values['variation'] ?? [],
                    $values['cart_item_data'] ?? []
                );
            }
            WC()->cart->calculate_totals();
            WC()->session->set_customer_session_cookie(true);
        }
    }
}, 10, 2);

function giftmax_reset_checkout_session_state(): void {
    if ( ! function_exists( 'WC' ) ) {
        return;
    }

    if ( null === WC()->session ) {
        WC()->initialize_session();
    }

    if ( ! WC()->session ) {
        return;
    }

    foreach ( [
        'cart_locked',
        'cart_created_time',
        'rial_coupon',
        'wallet_dirty',
        'use_wallet',
        'wallet_discount',
        '_wallet_discount',
        '_use_wallet',
        'giftmax_payment_lock',
        'giftmax_payment_lock_until',
    ] as $key ) {
        WC()->session->__unset( $key );
    }

    WC()->session->set_customer_session_cookie( true );
}

function giftmax_release_reserved_cart_licences( $source = null ): void {

    global $wpdb;
    $db = \Giftmax\modules\Db::getLnstance();

    if ( $source instanceof WC_Order ) {

        foreach ( $source->get_items() as $item ) {

            $reserved = $item->get_meta('reserved_licence_ids', true);

            if ( empty($reserved) || ! is_array($reserved) ) {
                continue;
            }

            foreach ( array_unique($reserved) as $licence_id ) {
                $db->modify(
                        "UPDATE {$wpdb->prefix}product_licences
                     SET licence_status='available',
                         reserved_at=NULL, order_id=NULL
                     WHERE licence_id=:licence_id",
                        ['licence_id' => $licence_id]
                );
            }
        }

        return;
    }

    if ( ! function_exists('WC') ) {
        return;
    }

    if ( null === WC()->session ) {
        WC()->initialize_session();
    }

    if ( null === WC()->cart ) {
        WC()->cart = new WC_Cart();
    }

    foreach ( WC()->cart->get_cart() as $cart_item ) {

        if ( empty($cart_item['reserved_licence_ids']) ) {
            continue;
        }

        foreach ( array_unique($cart_item['reserved_licence_ids'] ) as $licence_id ) {

            $db->modify(
                    "UPDATE {$wpdb->prefix}product_licences
                 SET licence_status='available',
                     reserved_at=NULL, order_id=NULL
                 WHERE licence_id=:licence_id",
                    ['licence_id' => $licence_id]
            );
        }
    }
}
function giftmax_clear_wallet_state_after_cart_change(): void {
    giftmax_release_reserved_cart_licences();
    giftmax_reset_checkout_session_state();
}

add_action( 'woocommerce_cart_emptied', 'giftmax_clear_wallet_state_after_cart_change' );

add_action( 'woocommerce_order_status_cancelled', function ( $order_id ) {
    $order = wc_get_order( $order_id );
    if ( $order ) {
        giftmax_release_reserved_cart_licences( $order );
    }
    giftmax_reset_checkout_session_state();
}, 10, 1 );

add_action( 'woocommerce_order_status_failed', function ( $order_id ) {
    $order = wc_get_order( $order_id );
    if ( $order ) {
        giftmax_release_reserved_cart_licences( $order );
    }
    giftmax_reset_checkout_session_state();
}, 10, 1 );

add_action( 'woocommerce_order_status_completed', function () {
    giftmax_reset_checkout_session_state();
}, 10, 0 );
/**
 * 1. Reduce the cart total by the wallet amount
 */
/**
 * اعمال تخفیف کیف پول در WooCommerce
 */

add_action( 'woocommerce_cart_calculate_fees', 'giftmax_apply_wallet_discount', 20,1 );
function giftmax_apply_wallet_discount( $cart ) {

    if ( is_admin() && ! defined('DOING_AJAX') ) return;
    if ( ! is_user_logged_in() ) return;

    // جلوگیری از اجرای تکراری
    if ( did_action( 'woocommerce_cart_calculate_fees' ) > 1 ) return;


    if ( null === WC()->session ) WC()->initialize_session();
    if ( null === WC()->customer ) WC()->customer = new \WC_Customer(get_current_user_id(), true);
    if ( null === WC()->cart ) WC()->cart = new \WC_Cart();
    if ( ! WC()->session->get( 'use_wallet' ) ) return;

    $cart = WC()->cart;

    if ($cart->is_empty()) {
        return wp_send_json_error(['message' => 'سبد خرید خالی است']);
    }

    if (WC()->session->get('payment_type') != 'r') {
        WC()->session->set('wallet_discount', 0);
        foreach ($cart->get_fees() as $key => $fee) {
            if ($fee->name === 'Wallet discount') $cart->remove_fee($key);
        }
        $cart->calculate_totals();

        return;
    }

    global $wpdb;
    $user_id = get_current_user_id();
    $db = \Giftmax\modules\Db::getLnstance();
    $wallet = $db->first("SELECT * FROM {$wpdb->prefix}wallet WHERE user_id = :user_id", ['user_id' => $user_id]);

    if (!$wallet || $wallet['balance'] <= 0) {
        WC()->session->set( 'use_wallet', false );
        WC()->session->set('wallet_discount', 0);
        return wp_send_json_error(['message' => 'موجودی کافی نیست']);
    }

    $wallet_balance = floatval($wallet['balance']);


    foreach ($cart->get_fees() as $key => $fee) {
        if ($fee->name === 'Wallet discount') $cart->remove_fee($key);
    }

    if ( $wallet_balance <= 0 ) return;

    $subtotal = (float) $cart->get_subtotal();
    if ( $subtotal <= 0 ) return;

    $discount = min( $wallet_balance, $subtotal );
    WC()->session->set('wallet_discount', $discount);
    WC()->session->set( 'use_wallet', true );
    $cart->add_fee(
        __( 'Wallet Discount', 'giftmax' ),
        -$discount,
        false
    );
}
add_filter( 'woocommerce_cart_hash', 'giftmax_wallet_cart_hash', 10, 1 );
function giftmax_wallet_cart_hash( $hash ) {

    $dirty = WC()->session->get( 'wallet_dirty' );

    if ( $dirty ) {
        $hash .= '|' . $dirty;
    }

    return $hash;
}
add_action( 'woocommerce_init', function () {
    if ( WC()->session && null === WC()->session->get( 'use_wallet' ) ) {
        WC()->session->set( 'use_wallet', false );
    }
});

add_action( 'init', function () {
    register_post_status( 'wc-card-not-verified', array(
        'label'                     => 'تایید نشدن کارت',
        'public'                    => true,
        'exclude_from_search'       => false,
        'show_in_admin_all_list'    => true,
        'show_in_admin_status_list' => true,
        'label_count'               => _n_noop(
            'تایید نشدن کارت <span class="count">(%s)</span>',
            'تایید نشدن کارت <span class="count">(%s)</span>',
            'giftmax'
        ),
    ) );
} );

add_filter( 'wc_order_statuses', function ( $statuses ) {
    $new_statuses = array();
    foreach ( $statuses as $key => $label ) {
        $new_statuses[ $key ] = $label;
        if ( 'wc-failed' === $key ) {
            $new_statuses['wc-card-not-verified'] = 'تایید نشدن کارت';
        }
    }
    if ( ! isset( $new_statuses['wc-card-not-verified'] ) ) {
        $new_statuses['wc-card-not-verified'] = 'تایید نشدن کارت';
    }
    return $new_statuses;
} );

function giftmax_get_author_full_name($author_id = null) {
    $author_id = $author_id ?: get_the_author_meta('ID');
    $first = trim(get_the_author_meta('first_name', $author_id));
    $last = trim(get_the_author_meta('last_name', $author_id));
    if ($first || $last) {
        return trim($first . ' ' . $last);
    }
    $display = get_the_author_meta('display_name', $author_id);
    return $display ? $display : get_the_author();
}
function giftmax_term_en_name_add_field() {
    wp_nonce_field('giftmax_save_term_en_name', 'giftmax_term_en_nonce');
    ?>
    <div class="form-field term-group">
        <label for="giftmax_en_name"><?php esc_html_e('English Name', 'giftmax'); ?></label>
        <input type="text" id="giftmax_en_name" name="giftmax_en_name" value="" />
        <p><?php esc_html_e('Example: PlayStation', 'giftmax'); ?></p>
    </div>
    <?php
}

function giftmax_term_en_name_edit_field($term) {
    $en_name = (string) get_term_meta($term->term_id, 'giftmax_en_name', true);
    wp_nonce_field('giftmax_save_term_en_name', 'giftmax_term_en_nonce');
    ?>
    <tr class="form-field term-group-wrap">
        <th scope="row">
            <label for="giftmax_en_name"><?php esc_html_e('English Name', 'giftmax'); ?></label>
        </th>
        <td>
            <input type="text" id="giftmax_en_name" name="giftmax_en_name" value="<?php echo
            esc_attr($en_name); ?>" />
            <p class="description"><?php esc_html_e('Example: PlayStation', 'giftmax'); ?></p>
        </td>
    </tr>
    <?php
}

function giftmax_save_term_en_name($term_id) {
    if (
        !isset($_POST['giftmax_term_en_nonce']) ||
        !wp_verify_nonce(wp_unslash($_POST['giftmax_term_en_nonce']), 'giftmax_save_term_en_name')
    ) {
        return;
    }

    if (!current_user_can('manage_categories')) {
        return;
    }

    $en_name = isset($_POST['giftmax_en_name']) ?
        sanitize_text_field(wp_unslash($_POST['giftmax_en_name'])) : '';

    if ($en_name === '') {
        delete_term_meta($term_id, 'giftmax_en_name');
        return;
    }

    update_term_meta($term_id, 'giftmax_en_name', $en_name);
}

function giftmax_get_term_english_name($term) {
    $term_obj = $term;

    if (!($term_obj instanceof WP_Term)) {
        $term_obj = get_term($term_obj);
    }

    if (!$term_obj || is_wp_error($term_obj)) {
        return '';
    }

    $en_name = (string) get_term_meta($term_obj->term_id, 'giftmax_en_name', true);

    // اگر فیلد خالی بود، از slug استفاده می‌کنیم
    if ($en_name === '') {
        $en_name = str_replace('-', ' ', $term_obj->slug);
    }

    return $en_name;
}

add_action('category_add_form_fields', 'giftmax_term_en_name_add_field', 10);
add_action('category_edit_form_fields', 'giftmax_term_en_name_edit_field', 10, 1);
add_action('created_category', 'giftmax_save_term_en_name', 10, 1);
add_action('edited_category', 'giftmax_save_term_en_name', 10, 1);

add_action('product_cat_add_form_fields', 'giftmax_term_en_name_add_field', 10);
add_action('product_cat_edit_form_fields', 'giftmax_term_en_name_edit_field', 10, 1);
add_action('created_product_cat', 'giftmax_save_term_en_name', 10, 1);
add_action('edited_product_cat', 'giftmax_save_term_en_name', 10, 1);

class Custom_Menu_Walker extends Walker_Nav_Menu
{

    public $menu_location = '';

    function __construct($location)
    {
        $this->menu_location = $location;
    }

    function start_el(&$output, $item, $depth = 0, $args = [], $id = 0)
    {
        if (!$item || empty($item->title)) {
            return;
        }
        $title = $item->title;
        $url = esc_url($item->url);

        if ($this->menu_location === 'header-menu') {
            $output .= '<li class="bg-transparent zIndex-high">';
            $output .= '<span class="title"><a href="' . $url . '">' . $title . '</a></span>';
            $output .= '<span class="arrow dashicons dashicons-arrow-down-alt2"></span>';
            $output .= '</li>';
            return;
        }

        if ($this->menu_location === 'quick-access' || $this->menu_location === 'help-support') {
            $output .= '<li class="py-05"><a class="text-xs font-normal text-dark hover:text-blue-dark transition-colors block leading-xs flex align-items-center" href="' . $url . '">' . $title . '</a></li>';
            return;
        }
        if ($this->menu_location === 'footer-menu') {
            $output .= '<li class="p-2"><a class="text-gray hover:text-dark block text-2xs font-normal px-8 border rounded-sm leading-1 fpt-8 fpb-6 whitespace-nowrap" href="' . $url . '">' . $title . '</a></li>';
            return;
        }
        parent::start_el($output, $item, $depth, $args, $id);
    }
}
function create_seo_editor_role() {
    remove_role('seo_editor');

    add_role(
        'seo_editor',
        'SEO Editor(max)',
        array(
            'read'                   => true,
            'edit_posts'             => true,
            'edit_others_posts'      => true,
            'edit_published_posts'   => true,
            'edit_products'          => true,
            'edit_others_products'   => true,
            'edit_published_products'=> true,
            'edit_product_terms'     => true,
            'manage_categories'      => true,

            // --- دسترسی‌های عمداً حذف شده ---
            'delete_posts'           => false,
            'delete_others_posts'    => false,
            'delete_published_posts' => false,
            'delete_products'        => false,
            'delete_others_products' => false,
            'delete_published_products' => false,
            'publish_posts'          => false,
            'publish_products'       => false,
            'edit_shop_orders'       => false,
            'manage_options'         => false,

            'upload_files'           => true,
        )
    );
}

add_action('after_switch_theme', 'create_seo_editor_role');
add_action('init', 'create_seo_editor_role');
// اضافه کردن منوی کلیک راست سفارشی برای مدیر سایت
add_action('wp_footer', 'custom_admin_context_menu');
function custom_admin_context_menu() {
    if (!current_user_can('administrator')) {
        return;
    }
    ?>
    <div class="">

    </div>
    <script>
        if (typeof currentMenu === 'undefined') {
            var currentMenu = null;
        }
        if (typeof longPressTimer === 'undefined') {
            var longPressTimer;
        }
        function removeMenu() {
            if (currentMenu) {
                currentMenu.remove();
                currentMenu = null;
            }
        }
        function showMenu(x,y,id){
            if (currentMenu) {
                currentMenu.remove();
            }
            const container = document.querySelector('body');
            const div = document.createElement('div');
            div.className = 'bg-000 rounded-2 absolute w-[200px] zIndex-9998 flex flex-col';
            div.style.left = x + 'px';
            div.style.top = y + 'px';
            div.style.padding = '12px';
            div.innerHTML = `<a href="${wpApiSettingsGiftMax.home + '/wp-admin/post.php?post=' + id + '&action=edit'}" class="color-000 font-size-12 flex DSKd5" style="padding:9px" target="_blank">
            <svg viewBox="0 0 24 24" class="w-22 h-22" style="fill:#FFF"><path d="M12 2C10.0222 2 8.08879 2.58649 6.4443 3.6853C4.79981 4.78412 3.51809 6.3459 2.76121 8.17317C2.00433 10.0004 1.8063 12.0111 2.19215 13.9509C2.578 15.8907 3.53041 17.6725 4.92894 19.0711C6.32746 20.4696 8.10929 21.422 10.0491 21.8079C11.9889 22.1937 13.9996 21.9957 15.8268 21.2388C17.6541 20.4819 19.2159 19.2002 20.3147 17.5557C21.4135 15.9112 22 13.9778 22 12C22 10.6868 21.7413 9.38642 21.2388 8.17317C20.7363 6.95991 19.9997 5.85752 19.0711 4.92893C18.1425 4.00035 17.0401 3.26375 15.8268 2.7612C14.6136 2.25866 13.3132 2 12 2ZM12 20C10.4178 20 8.87104 19.5308 7.55544 18.6518C6.23985 17.7727 5.21447 16.5233 4.60897 15.0615C4.00347 13.5997 3.84504 11.9911 4.15372 10.4393C4.4624 8.88743 5.22433 7.46197 6.34315 6.34315C7.46197 5.22433 8.88743 4.4624 10.4393 4.15372C11.9911 3.84504 13.5997 4.00346 15.0615 4.60896C16.5233 5.21447 17.7727 6.23984 18.6518 7.55544C19.5308 8.87103 20 10.4177 20 12C20 14.1217 19.1572 16.1566 17.6569 17.6569C16.1566 19.1571 14.1217 20 12 20ZM12 10.5C11.7348 10.5 11.4804 10.6054 11.2929 10.7929C11.1054 10.9804 11 11.2348 11 11.5V16.5C11 16.7652 11.1054 17.0196 11.2929 17.2071C11.4804 17.3946 11.7348 17.5 12 17.5C12.2652 17.5 12.5196 17.3946 12.7071 17.2071C12.8947 17.0196 13 16.7652 13 16.5V11.5C13 11.2348 12.8947 10.9804 12.7071 10.7929C12.5196 10.6054 12.2652 10.5 12 10.5ZM13.25 8.25C13.25 8.94036 12.6904 9.5 12 9.5C11.3097 9.5 10.75 8.94036 10.75 8.25C10.75 7.55964 11.3097 7 12 7C12.6904 7 13.25 7.55964 13.25 8.25Z"></path></svg>
            <span class="mr-3">ویرایش محصول</span>
        </a>`;
            currentMenu = div;

            container.appendChild(div);

        }

        if (typeof isMobile === 'undefined') {
            var isMobile = /Android|iPhone|iPad|iPod|webOS/i.test(navigator.userAgent);
        }
        if (!isMobile) {
            $(document).on('contextmenu', '.act-percent-card,.product-hero__grid,.act-new-service-card,.act-special-carousel-card,.act-main-banner-content-box-carousel-card', function (e) {
                e.preventDefault();
                e.stopPropagation();
                const id = $(this).find('[data-product-id]').data('product-id');
                showMenu(e.pageX, e.pageY,id);
            })
        }else{
            $(document).on('touchstart', '.act-percent-card,.product-hero__grid,.act-new-service-card,.act-special-carousel-card,.act-main-banner-content-box-carousel-card', function (e) {
                const $this = $(this);
                const id = $this.find('[data-product-id]').data('product-id');

                if (!id) return;

                longPressTimer = setTimeout(function() {
                    removeMenu();
                    showMenu(e.clientX, e.clientY, id);

                    if (navigator.vibrate) {
                        navigator.vibrate(50);
                    }
                }, 800);
            });
            $(document).on('touchmove touchend', '.act-new-service-card, .act-special-carousel-card, .act-main-banner-content-box-carousel-card', function() {
                clearTimeout(longPressTimer);
            });
        }
        document.addEventListener('click', function(e) {
            if (currentMenu && !currentMenu.contains(e.target)) {
                removeMenu();
            }
        });
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape') {
                removeMenu();
            }
        });
        document.addEventListener('touchstart', function(e) {
            if (currentMenu && !currentMenu.contains(e.target)) {
                removeMenu();
            }
        });
        document.addEventListener('scroll', function(e) {
            removeMenu();
        }, true);
    </script>

    <style>
        .DSKd5:hover {
            background-color: #66666673;
            border-radius: 10px;
        }
    </style>
    <?php
}
add_action('init', 'product_short_link_rewrite');
function product_short_link_rewrite() {
    add_rewrite_rule(
        '^p/([0-9]+)/?$',
        'index.php?product_id=$matches[1]',
        'top'
    );
}

// 2. ثبت متغیر جدید در وردپرس
add_filter('query_vars', 'add_product_id_query_var');
function add_product_id_query_var($vars) {
    $vars[] = 'product_id';
    return $vars;
}

// 3. ریدایرکت به محصول اصلی
add_action('template_redirect', 'redirect_product_short_url');
function redirect_product_short_url() {
    $product_id = get_query_var('product_id');

    if ($product_id) {
        $product = wc_get_product(intval($product_id));

        if ($product && $product->is_visible()) {
            wp_redirect(get_permalink($product->get_id()), 301);
            exit;
        } else {
            // محصول پیدا نشد -> 404 واقعی
            global $wp_query;
            $wp_query->set_404();
            status_header(404);
            nocache_headers();
        }
    }
}

function allow_all_json_and_lottie_uploads($data, $file, $filename, $mimes) {
    $filetype = wp_check_filetype($filename, $mimes);

    // اگر پسوند فایل json بود، بررسی سخت‌گیرانه نوع فایل را دور بزن
    if ($filetype['ext'] === 'json') {
        $data['ext']  = 'json';
        $data['type'] = 'application/json';
    }

    return $data;
}
add_filter('wp_check_filetype_and_ext', 'allow_all_json_and_lottie_uploads', 10, 4);

// این بخش هم برای اطمینان از تعریف نوع مایک در رسانه است
add_filter('upload_mimes', function($mimes) {
    $mimes['json'] = 'application/json';
    $mimes['svg'] = 'image/svg+xml';
    $mimes['webp'] = 'image/webp';
    return $mimes;
});
define('MY_PRODUCT_SECURITY_PASSWORD', '$2y$10$2yUx.H0/EXHFsKDvwJGGXu0B/d38ttnT/ADnumzI/2TLsByoxN7Lq');
add_action('wp_ajax_giftmax_check_password', 'giftmax_check_password');
function giftmax_check_password(){
    if(!isset($_POST['password']) || empty($_POST['password'])){
        wp_send_json_error([
                'message'=>'رمز وارد نشده'
        ]);
    }
    $password = $_POST['password'];
    if(!password_verify($password, MY_PRODUCT_SECURITY_PASSWORD)){

        wp_send_json_error([
                'message'=>'رمز اشتباه است'
        ]);

    }
    $fingerprint = hash(
            'sha256',
            ($_SERVER['HTTP_USER_AGENT'] ?? '') .
            ($_SERVER['HTTP_ACCEPT_LANGUAGE'] ?? '') .
            ($_SERVER['HTTP_SEC_CH_UA_PLATFORM'] ?? '')
    );

    $token = hash_hmac(
            'sha256',
            $fingerprint,
            MY_PRODUCT_SECURITY_PASSWORD
    );
    set_transient(
            'giftmax_product_token_' . $token,
            true,
            30 * MINUTE_IN_SECONDS
    );
    setcookie(
            'my_product_access',
            $token,
            time() + (30 * MINUTE_IN_SECONDS),
            COOKIEPATH,
            COOKIE_DOMAIN,
            is_ssl(),
            false
    );
    wp_send_json_success();
}
add_filter('auth_cookie_expiration', function($expiration, $user_id, $remember) {
    return 5 * YEAR_IN_SECONDS;
}, 10, 3);
add_action('woocommerce_before_calculate_totals', 'update_cart_product_prices');

function update_cart_product_prices($cart) {

    if (is_admin() && !defined('DOING_AJAX')) {
        return;
    }

    if (did_action('woocommerce_before_calculate_totals') >= 2) {
        return;
    }

    foreach ($cart->get_cart() as $cart_item_key => $cart_item) {

        $product = $cart_item['data'];
        $new_price = $product->get_price();
        $product->set_price($new_price);
    }
}
add_filter('wp_check_filetype_and_ext', function ($data, $file, $filename, $mimes) {
    $ext = pathinfo($filename, PATHINFO_EXTENSION);

    if (strtolower($ext) === 'svg') {
        $data['ext'] = 'svg';
        $data['type'] = 'image/svg+xml';
    }

    return $data;
}, 10, 4);
function giftmax_yoast_persian_date_parts() {

    $timestamp = current_time('timestamp');

    $gy = (int) wp_date('Y', $timestamp);
    $gm = (int) wp_date('n', $timestamp);
    $gd = (int) wp_date('j', $timestamp);

    // تبدیل میلادی به شمسی
    $g_d_m = array(
            0,
            31,
            59,
            90,
            120,
            151,
            181,
            212,
            243,
            273,
            304,
            334
    );

    if ($gy > 1600) {
        $jy = 979;
        $gy -= 1600;
    } else {
        $jy = 0;
        $gy -= 621;
    }

    $gy2 = ($gm > 2) ? ($gy + 1) : $gy;

    $days = (365 * $gy)
            + (int)(($gy2 + 3) / 4)
            - (int)(($gy2 + 99) / 100)
            + (int)(($gy2 + 399) / 400)
            - 80
            + $gd
            + $g_d_m[$gm - 1];

    $jy += 33 * (int)($days / 12053);
    $days %= 12053;

    $jy += 4 * (int)($days / 1461);
    $days %= 1461;

    if ($days > 365) {
        $jy += (int)(($days - 1) / 365);
        $days = ($days - 1) % 365;
    }

    if ($days < 186) {
        $jm = 1 + (int)($days / 31);
        $jd = 1 + ($days % 31);
    } else {
        $jm = 7 + (int)(($days - 186) / 30);
        $jd = 1 + (($days - 186) % 30);
    }

    $months = array(
            1  => 'فروردین',
            2  => 'اردیبهشت',
            3  => 'خرداد',
            4  => 'تیر',
            5  => 'مرداد',
            6  => 'شهریور',
            7  => 'مهر',
            8  => 'آبان',
            9  => 'آذر',
            10 => 'دی',
            11 => 'بهمن',
            12 => 'اسفند',
    );

    return array(
            'day'   => $jd,
            'month' => $months[$jm],
            'year'  => $jy,
    );
}


/**
 * %%currentday%%
 */
add_filter('wpseo_replacements', function ($replacements) {

    $date = giftmax_yoast_persian_date_parts();

    if (isset($replacements['%%currentday%%'])) {
        $replacements['%%currentday%%'] = $date['day'];
    }

    return $replacements;

});


/**
 * %%currentmonth%%
 */
add_filter('wpseo_replacements', function ($replacements) {

    $date = giftmax_yoast_persian_date_parts();

    if (isset($replacements['%%currentmonth%%'])) {
        $replacements['%%currentmonth%%'] = $date['month'];
    }

    return $replacements;

});


/**
 * %%currentyear%%
 */
add_filter('wpseo_replacements', function ($replacements) {

    $date = giftmax_yoast_persian_date_parts();

    if (isset($replacements['%%currentyear%%'])) {
        $replacements['%%currentyear%%'] = $date['year'];
    }

    return $replacements;

});

add_action('init', function () {

    // فقط وقتی قالب فعلی فعال است
    if (get_template() !== 'giftmax') {
        return;
    }
    $request_path = trim(parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH), '/');
    // جلوگیری از دسترسی مستقیم به wp-login.php
    if ($request_path === 'wp-login.php') {
        status_header(404);
        nocache_headers();

        wp_die(
                'Not Found',
                '404',
                ['response' => 404]
        );
    }
});
add_action('template_redirect', function () {

    if (is_page('product-category') || trim($_SERVER['REQUEST_URI'], '/') === 'product-category') {
        wp_safe_redirect(wc_get_page_permalink('shop'), 301);
        exit;
    }

});