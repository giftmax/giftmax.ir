function setActive(btn) {
    const pagination = document.querySelector('.v10__Pagination');
    document.querySelector('.v10__Pagination-item.active')?.classList.remove('active');
    btn.classList.add('active');
    const btnRect = btn.getBoundingClientRect();
    const parentRect = pagination.getBoundingClientRect();
    const offsetX = btnRect.left - parentRect.left;
    pagination.style.setProperty('--x', `${offsetX}px`);
}
function setProgress(percent) {
    const circle = document.querySelector('.progress');
    const text = document.querySelector('.percent-text');
    const circumference = 2 * Math.PI * 90;
    const offset = circumference * (1 - percent / 100);
    circle.style.strokeDashoffset = offset;
    text.textContent = percent + '٪';
}
function isMobileDevice() {
    const userAgent = navigator.userAgent || navigator.vendor || window.opera;

    if (/android/i.test(userAgent)) return true;
    if (/iPhone|iPad|iPod/i.test(userAgent)) return true;

    const hasTouchScreen = ('ontouchstart' in window) ||
        (navigator.maxTouchPoints > 0) ||
        (navigator.msMaxTouchPoints > 0);

    return hasTouchScreen && window.innerWidth <= 768;
}
(function ($) {
    'use strict';
    window.initSwiper = function(sliderEl, options) {
        if (!sliderEl) return;

        if (sliderEl.swiper) {
            sliderEl.swiper.destroy(true, true);
        }

        return new Swiper(sliderEl, options);
    }
    window.uikit__collections_error = function (message,time=0) {
        const container = document.querySelector("#popper-root #snackbar-container");
        const div = document.createElement('div');
        div.className = "Snackbar__root-_963b0 Snackbar__bg--error-_533ca d-flex mb-2 p-4 jc-start flex-column Snackbar__root--open-_126cb";
        div.style = "opacity: 1; transform: translateY(100px);"
        div.innerHTML = `<div class="color-000 text-body-1 align-center">${message}</div>`
        container.appendChild(div);
        setTimeout(function () {
            div.style = "opacity: 1; transform: translateY(0px);"
        }, 10);
        setTimeout(function () {
            div.style = "opacity: 0; transform: translateY(100px);"
        }, 6000+time);
        setTimeout(function () {
            div.remove();
        }, 7000+time);
    }
    window.uikit__collections_success = function (message) {
        const container = document.querySelector("#popper-root #snackbar-container");
        const div = document.createElement('div');
        div.className = "Snackbar__root-_963b0 Snackbar__bg--success-UqXMB3 d-flex mb-2 p-4 jc-start flex-column Snackbar__root--open-_126cb";
        div.style = "opacity: 1; transform: translateY(100px);"
        div.innerHTML = `<div class="color-000 text-body-1 align-center">${message}</div>`
        container.appendChild(div);
        setTimeout(function () {
            div.style = "opacity: 1; transform: translateY(0px);"
        }, 10);
        setTimeout(function () {
            div.style = "opacity: 0; transform: translateY(100px);"
        }, 6000);
        setTimeout(function () {
            div.remove();
        }, 7000);
    }
    window.SAJ = function (url='', dataAjax = {},callback,p='v1',xhrFields = null) {
        const ajaxOptions = {
            url: `${wpApiSettingsGiftMax.root}api/${p}/${url}`,
            method: 'POST',
            dataType: 'json',
            data: dataAjax,
            beforeSend: function (xhr) {
                xhr.setRequestHeader('X-WP-Nonce', wpApiSettingsGiftMax.nonce);
            },
            success: function (response) {
                if (typeof callback === 'function') {
                    callback(response);
                }
            },
            error: function (jqXHR, exception) {
                if (jqXHR.responseJSON && jqXHR.responseJSON.code && jqXHR.responseJSON.code == "rest_cookie_invalid_nonce") {
                    window.location.reload();
                    return false;
                }else if (jqXHR.status === 0) {
                    uikit__collections_error('اینترنت شما قطع شده است!');
                } else if (jqXHR.status == 404) {
                    uikit__collections_error('Requested page not found. [404]');
                } else if (jqXHR.status == 500) {
                    uikit__collections_error('Internal Server Error [500].');
                } else if (exception === 'parsererror') {
                    uikit__collections_error('Requested JSON parse failed.');
                } else if (exception === 'timeout') {
                    uikit__collections_error('Time out error.');
                } else if (exception === 'abort') {
                    uikit__collections_error('Ajax request aborted.');
                } else {
                    uikit__collections_error(jqXHR.message);
                }
            }
        };
        if (xhrFields && typeof xhrFields === 'object') {
            ajaxOptions.xhrFields = xhrFields;
        }
        $.ajax(ajaxOptions);
    }
    window.uikit__card_settings_init = function () {
        const $cardSettings = $('.card-settings').first();
        if (!$cardSettings.length) return;

        $('.js-example-basic-single').select2({
            width: 'resolve',
            dir: 'rtl'
        });
        function initSelect2($element) {
            const isMultiSelect = $element.attr('multiple');
            const placeholder   = $element.attr('data-placeholder') || '';
            const inProductStep = $element.hasClass('js-in-product');

            const select2Config = {
                placeholder: placeholder,
                closeOnSelect: !isMultiSelect,
                allowClear: (isMultiSelect && inProductStep),
                width: 'resolve',
                dir: 'rtl',
                sorter: function (data) {
                    return data.sort(function (a, b) {
                        a = $(a).prop('selected');
                        b = $(b).prop('selected');
                        return b - a;
                    });
                }
            };

            // اگر المنت cardRegion هست، template عکس رو اضافه کن
            if ($element.attr('id') === 'cardRegion') {
                select2Config.templateResult = formatRegionOption;
                select2Config.templateSelection = formatRegionOption;
            }

            $element.select2(select2Config)
                .on('select2:opening', function () {
                    $('body').addClass('ui-select');
                })
                .on('select2:close', function () {
                    $('body').removeClass('ui-select');
                })
                .on('change', function () {
                    $(this).trigger('blur');
                });
        }
        function initSelect2($element) {
            const isMultiSelect = $element.attr('multiple');
            const placeholder   = $element.attr('data-placeholder') || '';
            const inProductStep = $element.hasClass('js-in-product');

            // تنظیمات پایه
            const select2Config = {
                placeholder: placeholder,
                closeOnSelect: !isMultiSelect,
                allowClear: (isMultiSelect && inProductStep),
                width: 'resolve',
                dir: 'rtl',
                sorter: function (data) {
                    return data.sort(function (a, b) {
                        a = $(a).prop('selected');
                        b = $(b).prop('selected');
                        return b - a;
                    });
                }
            };

            // اگر المنت cardRegion هست، template عکس رو اضافه کن
            if ($element.attr('id') === 'cardRegion') {
                select2Config.templateResult = formatRegionOption;
                select2Config.templateSelection = formatRegionOption;
            }

            $element.select2(select2Config)
                .on('select2:opening', function () {
                    $('body').addClass('ui-select');
                })
                .on('select2:close', function () {
                    $('body').removeClass('ui-select');
                })
                .on('change', function () {
                    $(this).trigger('blur');
                });
        }

// تابع فرمت کردن گزینه‌های ریجن با عکس
        function formatRegionOption(option) {
            if (!option.id) {
                return option.text;
            }
            const imageUrl = `${wpApiSettingsGiftMax.directory}/assets/flag/${option.id}.svg`;
            const $region = $(
                `<span style="display: flex; align-items: center; gap: 8px;">
            <img src="${imageUrl}" 
                 style="width: 24px; height: 24px; object-fit: cover; border-radius: 4px;" 
                 onerror="this.style.display='none'" />
            <span>${option.text}</span>
        </span>`
            );

            return $region;
        }
        let activeTab = $(".card-settings__tab--active").data('tab');

        const $cardType   = $('#cardType');
        const $cardRegion = $('#cardRegion');
        const $cardAmount = $('#cardAmount');
        const $priceBox   = $('#finalPrice');
        const $cart__action   = $('#card-settings__actions');
        const $cardPanel = $cardSettings.find('.card-settings__panel');
        const $tabs = $('.card-settings__tab');
        let isTabSwitching = false;

        function setLoading(isLoading) {
            $cardSettings.toggleClass('is-loading', !!isLoading);
        }

        function selectFirstOption($select) {
            const $firstOption = $select.find('option').filter(function () {
                return $(this).val() !== '';
            }).first();

            if (!$firstOption.length) return false;
            $select.val($firstOption.val()).trigger('change');
            return true;
        }
        function animatePanelSwitch(direction, onMiddle) {
            const outClass = direction === 'left'
                ? 'card-settings__panel--out-left'
                : 'card-settings__panel--out-right';
            const inClass = direction === 'left'
                ? 'card-settings__panel--in-left'
                : 'card-settings__panel--in-right';
            const outDuration = 180;
            const inDuration = 220;

            $cardPanel.removeClass('card-settings__panel--out-left card-settings__panel--out-right card-settings__panel--in-left card-settings__panel--in-right');
            $cardPanel.addClass('is-transitioning ' + outClass);

            window.setTimeout(function () {
                onMiddle();
                $cardPanel.removeClass(outClass).addClass(inClass);

                window.setTimeout(function () {
                    $cardPanel.removeClass('is-transitioning ' + inClass);
                    setLoading(false);
                    isTabSwitching = false;
                }, inDuration);
            }, outDuration);
        }

        function resetAll() {
            $cardType.html('<option value="">نوع کارت</option>');
            $cardRegion.html('<option value="">ریجن</option>');
            $cardAmount.html('<option value="">مبلغ</option>');
            $priceBox.html('<label>قیمت محصول</label><strong>-</strong>');
            $cart__action.html('');

            [$cardType, $cardRegion, $cardAmount].forEach($el => {
                if ($el.hasClass('select2-hidden-accessible')) {
                    $el.select2('destroy');
                }
                initSelect2($el);
            });
        }

        function loadTypes() {
            resetAll();
            if (!PRODUCTS[activeTab]) return;

            Object.entries(PRODUCTS[activeTab]).forEach(([key, item]) => {
                $cardType.append(
                    new Option(item.label, key)
                );
            });

            $cardType.select2('destroy');
            initSelect2($cardType);
            selectFirstOption($cardType);
        }

        $cardType.on('change', function () {
            $cardRegion.html('<option value="">ریجن</option>');
            $cardAmount.html('<option value="">مبلغ</option>');
            $priceBox.html('<label>قیمت محصول</label><strong>-</strong>');
            $cart__action.html('');

            const categoryData = PRODUCTS[activeTab]?.[this.value];
            if (!categoryData?.regions) return;
            Object.keys(categoryData.regions).forEach(regionCode => {
                const option = new Option(
                    categoryData.regions_meta[regionCode],
                    regionCode
                );

                $(option).attr('data-image', regionCode);


                $cardRegion.append(option);
            });



            $cardRegion.select2('destroy');
            initSelect2($cardRegion);
            selectFirstOption($cardRegion);
        });

        $cardRegion.on('change', function () {
            $cardAmount.html('<option value="">مبلغ</option>');
            $priceBox.html('<label>قیمت محصول</label><strong>-</strong>');
            $cart__action.html('');
            const items = PRODUCTS[activeTab]?.[$cardType.val()]?.regions?.[this.value];
            if (!items) return;

            items.forEach(item => {
                const option = new Option(item.title, item.price);
                option.dataset.productId = item.id; // 👈 ID محصول
                $cardAmount.append(option);
            });

            $cardAmount.select2('destroy');
            initSelect2($cardAmount);
            selectFirstOption($cardAmount);
        });

        $cardAmount.on('change', function () {
            const selectedOption = this.options[this.selectedIndex];
            if (!selectedOption) return;

            const price     = selectedOption.value;
            const productId = selectedOption.dataset.productId;

            $priceBox.html(`
        <label>قیمت محصول</label>
        <strong>${price} تومان</strong>
    `);
            if (window.location.pathname === '/' || window.location.pathname === '') {

                $cart__action.html(`   <button class="quick-btn act-special-carousel-card-buy-box-but Button-aca48" data-product-id="${productId}">
   <svg xmlns="http://www.w3.org/2000/svg" width="26" height="26" viewBox="0 0 26 26" fill="currentcolor">
                                                    <path d="M17.875 9.34916C17.4308 9.34916 17.0625 8.98083 17.0625 8.53666V7.04166C17.0625 5.90416 16.575 4.79916 15.73 4.03C14.8742 3.25 13.7692 2.8925 12.5992 3.00083C10.6492 3.185 8.9375 5.17833 8.9375 7.25833V8.30916C8.9375 8.75333 8.56917 9.12166 8.125 9.12166C7.68083 9.12166 7.3125 8.75333 7.3125 8.30916V7.2475C7.3125 4.33333 9.66333 1.64666 12.4475 1.37583C14.0725 1.22417 15.6325 1.73333 16.8242 2.8275C18.005 3.9 18.6875 5.43833 18.6875 7.04166V8.53666C18.6875 8.98083 18.3192 9.34916 17.875 9.34916Z"></path>
                                                    <path d="M16.2498 24.6457H9.7498C4.7448 24.6457 3.81314 22.3165 3.5748 20.0523L2.7623 13.5632C2.64314 12.3932 2.5998 10.714 3.7373 9.45734C4.7123 8.374 6.32647 7.854 8.66647 7.854H17.3331C19.684 7.854 21.2981 8.38484 22.2623 9.45734C23.389 10.714 23.3565 12.3932 23.2373 13.5415L22.4248 20.0523C22.1865 22.3165 21.2548 24.6457 16.2498 24.6457ZM8.66647 9.479C6.83564 9.479 5.57897 9.8365 4.9398 10.5515C4.40897 11.1365 4.23564 12.0357 4.37647 13.379L5.18897 19.8682C5.37314 21.6015 5.8498 23.0315 9.7498 23.0315H16.2498C20.1498 23.0315 20.6265 21.6123 20.8106 19.8898L21.6231 13.379C21.764 12.0573 21.5906 11.1582 21.0598 10.5623C20.4206 9.8365 19.164 9.479 17.3331 9.479H8.66647Z"></path>
                                                    <path d="M16.7045 14.2458C16.0979 14.2458 15.6104 13.7583 15.6104 13.1624C15.6104 12.5666 16.0979 12.0791 16.6937 12.0791C17.2895 12.0791 17.777 12.5666 17.777 13.1624C17.777 13.7583 17.3004 14.2458 16.7045 14.2458Z"></path>
                                                    <path d="M9.12151 14.2458C8.51484 14.2458 8.02734 13.7583 8.02734 13.1624C8.02734 12.5666 8.51484 12.0791 9.11068 12.0791C9.70651 12.0791 10.194 12.5666 10.194 13.1624C10.194 13.7583 9.71734 14.2458 9.12151 14.2458Z"></path>
                                                </svg>

                                                افزودن به سبد خرید
                                            </button>`);
            }else{
                $cart__action.html(`   <button class="quick-btn act-special-carousel-card-buy-box-but Button-aca49" data-product-id="${productId}">
   <svg xmlns="http://www.w3.org/2000/svg" width="26" height="26" viewBox="0 0 26 26" fill="currentcolor">
                                                    <path d="M17.875 9.34916C17.4308 9.34916 17.0625 8.98083 17.0625 8.53666V7.04166C17.0625 5.90416 16.575 4.79916 15.73 4.03C14.8742 3.25 13.7692 2.8925 12.5992 3.00083C10.6492 3.185 8.9375 5.17833 8.9375 7.25833V8.30916C8.9375 8.75333 8.56917 9.12166 8.125 9.12166C7.68083 9.12166 7.3125 8.75333 7.3125 8.30916V7.2475C7.3125 4.33333 9.66333 1.64666 12.4475 1.37583C14.0725 1.22417 15.6325 1.73333 16.8242 2.8275C18.005 3.9 18.6875 5.43833 18.6875 7.04166V8.53666C18.6875 8.98083 18.3192 9.34916 17.875 9.34916Z"></path>
                                                    <path d="M16.2498 24.6457H9.7498C4.7448 24.6457 3.81314 22.3165 3.5748 20.0523L2.7623 13.5632C2.64314 12.3932 2.5998 10.714 3.7373 9.45734C4.7123 8.374 6.32647 7.854 8.66647 7.854H17.3331C19.684 7.854 21.2981 8.38484 22.2623 9.45734C23.389 10.714 23.3565 12.3932 23.2373 13.5415L22.4248 20.0523C22.1865 22.3165 21.2548 24.6457 16.2498 24.6457ZM8.66647 9.479C6.83564 9.479 5.57897 9.8365 4.9398 10.5515C4.40897 11.1365 4.23564 12.0357 4.37647 13.379L5.18897 19.8682C5.37314 21.6015 5.8498 23.0315 9.7498 23.0315H16.2498C20.1498 23.0315 20.6265 21.6123 20.8106 19.8898L21.6231 13.379C21.764 12.0573 21.5906 11.1582 21.0598 10.5623C20.4206 9.8365 19.164 9.479 17.3331 9.479H8.66647Z"></path>
                                                    <path d="M16.7045 14.2458C16.0979 14.2458 15.6104 13.7583 15.6104 13.1624C15.6104 12.5666 16.0979 12.0791 16.6937 12.0791C17.2895 12.0791 17.777 12.5666 17.777 13.1624C17.777 13.7583 17.3004 14.2458 16.7045 14.2458Z"></path>
                                                    <path d="M9.12151 14.2458C8.51484 14.2458 8.02734 13.7583 8.02734 13.1624C8.02734 12.5666 8.51484 12.0791 9.11068 12.0791C9.70651 12.0791 10.194 12.5666 10.194 13.1624C10.194 13.7583 9.71734 14.2458 9.12151 14.2458Z"></path>
                                                </svg>

                                                افزودن به سبد خرید
                                            </button>`);
            }
        });


        // Tabs
        $tabs.on('click', function () {
            const newTab = $(this).data('tab');
            if (activeTab === newTab || isTabSwitching) return;

            const oldIndex = $tabs.index($tabs.filter('.card-settings__tab--active'));
            const newIndex = $tabs.index(this);
            const direction = newIndex > oldIndex ? 'left' : 'right';

            isTabSwitching = true;
            $tabs.removeClass('card-settings__tab--active');
            $(this).addClass('card-settings__tab--active');
            setLoading(true);

            animatePanelSwitch(direction, function () {
                activeTab = newTab;
                loadTypes();
            });
        });

        // init
        setLoading(false);
        resetAll();
        loadTypes();
    }
    window.priceChartModal = function () {
        function formatNumber(value) {
            return new Intl.NumberFormat('fa-IR').format(Math.round(value));
        }

        const chartContainer = document.getElementById('priceChart');
        if (!chartContainer) return;
        const chartData = JSON.parse(chartContainer.dataset.series || "{}");
        const points = chartData.points || [];
        function calculate24hChangeByTime(points) {

            const validPoints = points.filter(p => p.v >= 0);
            if (validPoints.length < 2) {
                return {
                    text: '۰%',
                    arrow: '',
                    colorClass: 'text-[#f59e0b]',
                    arrowClass: 'text-[#f59e0b]',
                    percent: 0,
                    isPositive: false,
                    isNegative: false,
                    isZero: true
                };
            }
            const currentPrice = validPoints[validPoints.length - 1].v;
            const yesterdayPrice = validPoints[validPoints.length - 2].v;
            const percent = ((currentPrice - yesterdayPrice) / yesterdayPrice) * 100;
            const absPercentRaw = Math.abs(percent);

            let absPercent;
            if (absPercentRaw > 0 && absPercentRaw < 0.01) {
                absPercent = 0.01;
            } else {
                absPercent = absPercentRaw;
            }

            const finalPercent = absPercent.toFixed(2);
            let colorClass = '';
            let arrowClass = '';
            let arrow = '';
            let text = '';

            if (percent > 0) {
                colorClass = 'text-[#027275]';
                arrowClass = 'text-[#027275]';
                arrow = '↑';
                text = `+${finalPercent}%`;
            } else if (percent < 0) {
                colorClass = 'text-[#e6123d]';
                arrowClass = 'text-[#e6123d]';
                arrow = '↓';
                text = `${finalPercent}%`;
            } else {
                colorClass = 'text-[#f59e0b]';
                arrowClass = 'text-[#f59e0b]';
                arrow = '';
                text = '۰%';
            }

            return {
                text: text,
                arrow: arrow,
                colorClass: colorClass,
                arrowClass: arrowClass,
                percent: absPercent,
                isPositive: percent > 0,
                isNegative: percent < 0,
                isZero: percent === 0,
            };
        }
        const change = calculate24hChangeByTime(points);

        const changePercentEl = document.querySelector('.change-percent');
        if (changePercentEl) {
            const span = document.createElement('span');
            span.innerText = change.text;
            span.className = `text-[12px] md:text-[14px] font-semibold cursor-pointer ${change.colorClass}`;
            changePercentEl.appendChild(span);
            const div = document.createElement('div');
            div.innerHTML = change.arrow;
            div.className = change.arrowClass;
            changePercentEl.appendChild(div);

        }

        const seriesData = points.map(p => p.v);
        const categories = points.map(p => p.label_2 || p.label || p.t);

        const options = {
            chart: {
                type: 'area',
                height: 200,
                width: '100%',
                toolbar: { show: false },
                zoom: { enabled: false },
                background: 'rgb(242, 243, 245)',
                fontFamily: 'PeydaFaNumWeb'
            },
            dataLabels: { enabled: false },
            stroke: {
                curve: 'smooth',
                width: 1,
                colors: ['#027275']
            },
            fill: {
                type: 'gradient',
                gradient: {
                    shadeIntensity: 1,
                    opacityFrom: 0.5,
                    opacityTo: 0.1,
                    stops: [0, 85, 100],
                    colorStops: [
                        { offset: 0, color: '#027275', opacity: 0.3 },
                        { offset: 85, color: '#E5ECEB', opacity: 0.3 },
                        { offset: 100, color: '#E5ECEB', opacity: 0.3 }
                    ]
                }
            },
            grid: {
                show: true,
                borderColor: '#dedfe0',
                strokeDashArray: 0,
                position: 'back',
                xaxis: { lines: { show: false } },
                yaxis: { lines: { show: true } }
            },
            xaxis: {
                categories: categories,
                tickAmount: 5,
                labels: {
                    show: true,
                    offsetX: 8,
                    offsetY: 0,
                    style: {
                        colors: '#a2a2a2',
                        fontSize: '11px',
                        fontFamily: 'PeydaFaNumWeb',
                        fontWeight: 400
                    },
                    rotate: 0,
                    hideOverlappingLabels: true
                },
                tooltip: {
                    enabled: false
                },
                axisBorder: { show: false },
                axisTicks: { show: false }
            },
            yaxis: {
                labels: {
                    show: true,
                    offsetX: -50,
                    style: {
                        colors: '#a2a2a2',
                        fontSize: '11px',
                        fontFamily: 'PeydaFaNumWeb',
                        fontWeight: 400
                    },
                    formatter: function(value) {
                        return formatNumber(value);
                    }
                },
                title: { text: undefined }
            },
            tooltip: {
                enabled: true,
                theme: 'dark',
                custom: function({ series, seriesIndex, dataPointIndex, w }) {
                   const value = series[seriesIndex][dataPointIndex];
                   const point = categories[dataPointIndex];
                    return `
                        <div style="background: #333333; color: white; padding: 8px 12px; border-radius: 8px; font-size: 12px; font-family: PeydaFaNumWeb, sans-serif; border: none; box-shadow: none; display: flex; flex-direction: column; align-items: center; gap: 3px;">
                            <div style="display: flex; gap: 3px;">
                                <span>تومان</span>
                                <span>${formatNumber(value)}</span>
                            </div>
                            <div style="font-size: 10px; color: #D1D1D1; direction: rtl;">${point}</div>
                        </div>
                    `;
                }
            },
            series: [{
                name: 'قیمت',
                data: seriesData,
                type: 'area'
            }],
            markers: {
                size: 0,
                colors: ['#027275'],
                strokeColors: '#ffffff',
                strokeWidth: 2,
                hover: {
                    size: 6,
                    sizeOffset: 3
                }
            },
            legend: { show: false },
            noData: { text: undefined }
        };

        chartContainer.innerHTML = '';
        const chart = new ApexCharts(chartContainer, options);
        chart.render();

    }
// در ابتدای فایل یا قبل از تعریف تابع
    window.cartCleanupExecuted = false;

    window.startCartTimer = function () {
        let isCleanedUp = false;
        let intervalId = null;

        SAJ('getCartTimer', {}, function (data) {
            let time = data.data.remaining;

            const timerEls = document.querySelectorAll('[data-cart-timer]');
            if (!timerEls || timerEls.length === 0) return;

            if (intervalId) {
                clearInterval(intervalId);
            }

            intervalId = setInterval(() => {
                const minutes = Math.floor(time / 60);
                const seconds = time % 60;
                const timeText = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
                timerEls.forEach((el) => {
                    el.textContent = timeText;
                });
                time--;

                if (time < 0 && !isCleanedUp) {
                    isCleanedUp = true;
                    clearInterval(intervalId);
                    intervalId = null;

                    // فقط یکبار اجرا شود
                    if (!window.cartCleanupExecuted) {
                        window.cartCleanupExecuted = true;
                        performCartCleanup();
                    }
                }
            }, 1000);
        });
    };

    function performCartCleanup() {
        uikit__collections_error("سبد خرید شما حذف شد");

        const el = document.querySelector('.SJf5G');
        if (el) {
            if (!el.classList.contains('hidden')) {
                el.classList.add("hidden");
            }
            el.textContent = 0;
        }

        const mobileCart = document.querySelector('.mobileCart');
        if (mobileCart) {
            closePup($(".mobileCart"));
        }

        const countCart = document.querySelectorAll(".w-1\\/5")[2]?.querySelector("a div span");
        if (countCart) {
            countCart.remove();
            window.cart = '';
        }

        if (document.getElementById('user-cart')) {
            document.getElementById('user-cart').innerHTML = '';
        } else if (document.querySelector('[data-status="ibc"]')) {
            const modalRoot = document.querySelector('[data-status="ibc"]').closest(
                '.ModalComponent__root-YwCAMP.ModalComponent__root--desktop-JzGyNl.ModalComponent__animation-JkgpfL.ModalComponent__root--open-i5pSf7.ModalComponent__root--open__desktop-x1XDzU'
            );
            $('[data-status="ibc"]').css('transform', 'translateY(400%)');
            setTimeout(function () {
                modalRoot.remove();
                document.body.classList.toggle('lock-body-scroll');
            }, 100);
        }

        if (document.querySelector(".widget-shop-cart")) {
            document.querySelector(".widget-shop-cart").innerHTML =
                '<div class="p-24 text-center text-gray">سبد خرید خالی است</div>';
        }
    }
    window.bannerHandler = function ($scope) {
        // ===== Scroll Down Button =====
        const scrollBtn = $scope.find(".act-main-banner-content-scroll-down")[0];
        if (scrollBtn) {
            scrollBtn.addEventListener("click", function (e) {
                e.preventDefault();
                const btnTop = scrollBtn.getBoundingClientRect().top + window.scrollY;
                const scrollTarget = btnTop + 50;
                window.scrollTo({
                    top: scrollTarget,
                    behavior: "smooth"
                });
            });
        }

        // ===== Banner Swiper =====
        const bannerCarousel = $scope.find(".act-main-banner-content-box-carousel-main")[0];
        if (bannerCarousel && !bannerCarousel.swiper) {
             initSwiper(bannerCarousel, {
                slidesPerView: 1,
                speed: 600,
                autoplay: {
                    delay: 4500,
                    disableOnInteraction: false,
                },
                navigation: {
                    nextEl: ".act-main-banner-content-box-carousel-head-but-next",
                    prevEl: ".act-main-banner-content-box-carousel-head-but-prev",
                },
            });
        }

    }
    window.amazingProduct = function (){
            function specialCarouselHandler($scope) {

                const listEl = $scope.find(".act-special-carousel-main-list-carousel");
                const carouselItems = $scope.find(".act-special-carousel-main-carousel-box");

                if (!listEl.length || !carouselItems.length) return;

                function initListSwiper() {
                    const isMobile = window.innerWidth <= 768;

                    const prev = listEl.data("swiper-instance");
                    if (prev) {
                        prev.destroy(true, true);
                        listEl.removeData("swiper-instance");
                    }
                    const instance = initSwiper(listEl[0], {
                        slidesPerView: "auto",
                        spaceBetween: 8,
                        direction: isMobile ? "horizontal" : "vertical",
                        mousewheel: !isMobile
                            ? { forceToAxis: true, releaseOnEdges: true }
                            : false,
                        navigation: {
                            nextEl: $scope.find(".act-special-carousel-main-list-next")[0],
                            prevEl: $scope.find(".act-special-carousel-main-list-prev")[0],
                        }
                    });

                    listEl.data("swiper-instance", instance);
                }

                initListSwiper();

                if (!listEl.data("resize-binded")) {
                    listEl.data("resize-binded", true);

                    $(window).on("resize.sc-" + $scope[0].dataset.id, function () {
                        clearTimeout(listEl.data("resize-timer"));
                        const t = setTimeout(() => initListSwiper(), 150);
                        listEl.data("resize-timer", t);
                    });
                }

                //---------------------------------------------------
                // 2) همه Carousel ها را تک&zwnj;به&zwnj;تک init کن
                //---------------------------------------------------
                carouselItems.each(function () {
                    const item = $(this);
                    const carouselEl = item.find(".act-special-carousel-main-carousel");

                    if (!carouselEl.length) return;

                    if (!carouselEl.data("swiper-initialized")) {
                        carouselEl.data("swiper-initialized", true);

                        const instance = initSwiper(carouselEl[0], {
                            slidesPerView: "auto",
                            spaceBetween: 8,
                            freeMode: true,
                            navigation: {
                                nextEl: $scope.find(".act-special-carousel-head-nav-buts-next")[0],
                                prevEl: $scope.find(".act-special-carousel-head-nav-buts-prev")[0],
                            }
                        });

                        carouselEl.data("swiper-instance", instance);
                    }
                });

                //---------------------------------------------------
                // 3) تب&zwnj;ها — فعال&zwnj;سازی هماهنگ
                //---------------------------------------------------
                const heads = $scope.find(".act-special-carousel-main-list-carousel-item");
                const panes = carouselItems;

                if (heads.length && panes.length) {

                    heads.removeClass("active");
                    panes.removeClass("active");

                    heads.eq(0).addClass("active");
                    panes.eq(0).addClass("active");

                    heads.each(function (i) {
                        $(this).off("mouseover.sc").on("mouseover.sc", function () {

                            heads.removeClass("active");
                            panes.removeClass("active");

                            heads.eq(i).addClass("active");
                            panes.eq(i).addClass("active");
                        });
                    });
                }
            }


        $(".act-special-carousel-1st").each(function () {
            const widget = $(this).closest(".container-xl-w");
            if (widget.length) {
                specialCarouselHandler(widget);
            }
        });



    }
    window.timersh = function (){
        const timers = document.querySelectorAll('.special-offers-timer');

        timers.forEach(timer => {

            const dueDateStr = timer.dataset.dueDate;
            if (!dueDateStr) return;

            const dueTime = new Date(dueDateStr.replace(' ', 'T')).getTime();

            const daysEl    = timer.querySelector('.sp-days');
            const hoursEl   = timer.querySelector('.sp-hours');
            const minutesEl = timer.querySelector('.sp-minutes');
            const secondsEl = timer.querySelector('.sp-seconds');

            function update() {
                const now = Date.now();
                let diff = Math.floor((dueTime - now) / 1000);

                if (diff <= 0) {
                    // تایمر تمام شد → حذف اسلاید
                    const slide = timer.closest('.swiper-slide');
                    if (slide) {
                        slide.style.opacity = '0';
                        setTimeout(() => slide.remove(), 300);
                    }
                    clearInterval(interval);
                    return;
                }

                const days = Math.floor(diff / 86400);
                diff %= 86400;
                const hours = Math.floor(diff / 3600);
                diff %= 3600;
                const minutes = Math.floor(diff / 60);
                const seconds = diff % 60;

                if (daysEl)    daysEl.textContent    = days;
                if (hoursEl)   hoursEl.textContent   = hours.toString().padStart(2, '0');
                if (minutesEl) minutesEl.textContent = minutes.toString().padStart(2, '0');
                if (secondsEl) secondsEl.textContent = seconds.toString().padStart(2, '0');
            }

            update();
            const interval = setInterval(update, 1000);
        });
    }
    window.timerlpt = function (){
        const timers = document.querySelectorAll('.style_ProductPromotionTimeline__timer__zS6ZA');
        timers.forEach(timer => {
            if (timer.dataset.time) {
                return;
            }
                const dueDateStr = timer.textContent;
                if (!dueDateStr) return;

                const dueTime = new Date(dueDateStr.replace(' ', 'T')).getTime();
                let interval;

                function update() {
                    const now = Date.now();
                    let diff = Math.floor((dueTime - now) / 1000);

                    if (diff <= 0) {
                        const slide = timer;
                        if (slide) {
                            slide.style.opacity = '0';
                            setTimeout(() => slide.remove(), 300);
                        }
                        clearInterval(interval);
                        return;
                    }

                    const days = Math.floor(diff / 86400);
                    diff %= 86400;
                    const hours = Math.floor(diff / 3600);
                    diff %= 3600;
                    const minutes = Math.floor(diff / 60);
                    const seconds = diff % 60;
                    const dayStr = days > 0 ? ` : ${days.toString().padStart(2, '0')} ` : '';

                    const timerText =
                        `${seconds.toString().padStart(2, '0')} : ` +
                        `${minutes.toString().padStart(2, '0')} : ` +
                        `${hours.toString().padStart(2, '0')} ` +
                        `${dayStr}`;

                    timer.textContent = timerText;
                }

                update();
                interval = setInterval(update, 1000);
            timer.dataset.time = true;
            });
    }
    window.timerlpts = function (){
        const timers = document.querySelectorAll('.style_ProductPromotionTimeline__timer__zS6ZA1');
        timers.forEach(timer => {

            const dueDateStr = timer.textContent;
            if (!dueDateStr) return;
            let formattedDate = dueDateStr.replace(/\//g, '-'); // تبدیل / به -
            formattedDate = formattedDate.replace(' ', 'T'); // تبدیل فاصله به T
            const dueTime = new Date(formattedDate).getTime();

            let interval;

            function update() {
                const now = Date.now();
                let diff = Math.floor((dueTime - now) / 1000);

                if (diff <= 0) {
                    const slide = timer;
                    if (slide) {
                        slide.style.opacity = '0';
                        setTimeout(() => slide.remove(), 300);
                    }
                    clearInterval(interval);
                    return;
                }

                const days = Math.floor(diff / 86400);
                diff %= 86400;
                const hours = Math.floor(diff / 3600);
                diff %= 3600;
                const minutes = Math.floor(diff / 60);
                const seconds = diff % 60;
                const dayStr = days > 0 ? ` : ${days.toString().padStart(2, '0')}` : '';

                const timerText = `${seconds.toString().padStart(2, '0')} : ${minutes.toString().padStart(2, '0')} : ${hours.toString().padStart(2, '0')} ${dayStr}`;

                timer.textContent = timerText;
            }

            update();
            interval = setInterval(update, 1000);
        });
    }
    window.timerpsh = function (){
        const timers = document.querySelectorAll('.product-offers-timer');

        timers.forEach(timer => {

            const dueDateStr = timer.dataset.dueDate;
            if (!dueDateStr) return;

            const dueTime = new Date(dueDateStr.replace(' ', 'T')).getTime();
            const control = timer.querySelectorAll(".countdown-section");
            const daysEl    = control[0].querySelector('.countdown-amount');
            const hoursEl   = control[1].querySelector('.countdown-amount');
            const minutesEl = control[2].querySelector('.countdown-amount');
            const secondsEl = control[3].querySelector('.countdown-amount');

            function update() {
                const now = Date.now();
                let diff = Math.floor((dueTime - now) / 1000);

                if (diff <= 0) {
                    // تایمر تمام شد → حذف اسلاید
                    const slide = timer.closest('.swiper-slide');
                    if (slide) {
                        slide.style.opacity = '0';
                        setTimeout(() => slide.remove(), 300);
                    }
                    clearInterval(interval);
                    return;
                }

                const days = Math.floor(diff / 86400);
                diff %= 86400;
                const hours = Math.floor(diff / 3600);
                diff %= 3600;
                const minutes = Math.floor(diff / 60);
                const seconds = diff % 60;

                if (daysEl)    daysEl.textContent    = days;
                if (hoursEl)   hoursEl.textContent   = hours.toString().padStart(2, '0');
                if (minutesEl) minutesEl.textContent = minutes.toString().padStart(2, '0');
                if (secondsEl) secondsEl.textContent = seconds.toString().padStart(2, '0');
            }

            update();
            const interval = setInterval(update, 1000);
        });
    }
    window.actFaqHandler = function ($scope){
        const faqItems = $scope.find('.act-faq-item');

        faqItems.each(function (index) {
            const item = $(this);
            const question = item.find('.act-questions')[0];
            const answer = item.find('.act-answer')[0];

            if (!question || !answer) return;

            const uniqueId = `act-faq-${index + 1}`;
            question.setAttribute('data-bs-target', `#${uniqueId}`);
            question.setAttribute('aria-controls', uniqueId);
            answer.id = uniqueId;

            if (index ===0) {
                item.addClass('collapsed');
                question.classList.remove('collapsed');
                question.setAttribute('aria-expanded', 'true');
                answer.classList.add('show');
            } else {
                item.removeClass('collapsed');
                question.classList.add('collapsed');
                question.setAttribute('aria-expanded', 'false');
                answer.classList.remove('show');
            }
        });
    }
    window.header = function (){
        $('.bakala').children('ul').children().addClass('bg-transparent zIndex-high');
        /*$('.bakala').children('ul').append('<div class="animationDivInnerNav d-none"></div>');

        $('.bakala').children('ul').children('li').on('mouseenter', function() {
            $('.animationDivInnerNav').removeClass('d-none');
            $('.animationDivInnerNav').css('width', $(this).width() + 'px');
            let a, b;
            if (typeof($(this).position().left) !== 'undefined') {
                a = parseInt($(this).position().left);
                if (typeof($(this).css('marginLeft')) !== 'undefined') {
                    a += parseInt($(this).css('marginLeft'));
                }
                if (typeof($(this).css('padding-left')) !== 'undefined') {
                    a += parseInt($(this).css('padding-left'));
                }
                $('.animationDivInnerNav').css('left', a + 'px');
            } else {
                b = parseInt($(this).position().right);
                if (typeof($(this).css('marginRight')) !== 'undefined') {
                    b += parseInt($(this).css('marginRight'));
                }
                if (typeof($(this).css('padding-right')) !== 'undefined') {
                    b += parseInt($(this).css('padding-right'));
                }
                $('.animationDivInnerNav').css('right', b + 'px');
            }
        });

        $('.bakala').children('ul').children('li').on('mouseleave', function() {
            $('.animationDivInnerNav').addClass('d-none');
        });
         */
    }
    window.updateCart = function(cartKey, qty, $input,button,gatewayApi) {
        console.log(cartKey, qty, $input,button,gatewayApi);
        $.ajax({
            url: `${wpApiSettingsGiftMax.root}api/v1/UpdateCartQty`,
            method: 'POST',
            dataType: 'json',
            data: {
                cart_item_key: cartKey,
                quantity: qty,
                gateway:gatewayApi
            },
            beforeSend: function (xhr) {
                xhr.setRequestHeader('X-WP-Nonce', wpApiSettingsGiftMax.nonce);
            },
            success: function (response) {
                if (response.success) {
                    if (response.data.action == 'cart_empty'){
                        if (document.getElementById('user-cart')) {
                            document.getElementById('user-cart').innerHTML = '';
                        } else if (document.querySelector('[data-status="ibc"]')) {
                            const modalRoot = document.querySelector('[data-status="ibc"]').closest(
                                '.ModalComponent__root-YwCAMP.ModalComponent__root--desktop-JzGyNl.ModalComponent__animation-JkgpfL.ModalComponent__root--open-i5pSf7.ModalComponent__root--open__desktop-x1XDzU'
                            );
                            $('[data-status="ibc"]').css('transform', 'translateY(400%)');
                            setTimeout(function () {
                                modalRoot.remove();
                                document.body.classList.toggle('lock-body-scroll');
                            }, 100);
                        }
                        const el = document.querySelector('.SJf5G');
                        if (el){
                            if (!el.classList.contains('hidden')){
                                el.classList.toggle("hidden")
                            }
                            el.textContent = 0;
                        }
                        if(document.querySelector(".mobileCart")){
                            closePup($(".mobileCart"))
                        }
                        const countCart = document.querySelectorAll(".w-1\\/5")[2].querySelector("a div span");
                        if (countCart) {
                            countCart.remove();
                            window.cart = '';
                        }
                        if (document.querySelector(".widget-shop-cart")){
                            document.querySelector(".widget-shop-cart").innerHTML = '<div class="p-24 text-center text-gray">سبد خرید خالی است</div>';
                        }
                        return;
                    }

                    const item = response.data.item;
                    const row  = $(`tr[data-mini-item="${response.data.cart_item_key}"]`);
                    row.find('.font-size-13.text-lg.font-bold.text-dark.tracking-tighter.pt-2.inline-block').text(item.final_total);

                    if (item.original_total) {
                        row.find('.ml-6.font-size-13text-sm.font-bold.text-red.opacity-85.tracking-tighter.mb-2.block.line-through').text(item.original_total);
                    }

                    $(document.body).trigger('wc_fragment_refresh');
                    $input.html(response.data.new_quantity);
                    renderMiniCart(response.data.mini);
                    $("[data-summary=\"subtotal\"] span").text(response.data.cart.subtotal);
                    $("[data-summary=\"discount\"] span").text(response.data.cart.discount);
                    $("[data-summary=\"total\"] span").text(response.data.cart.total);
                    $("#total_points").text(response.data.total_points);
                    const count = Number(response?.data?.mini?.items_count ?? 0);

                    document.querySelectorAll('.SJf5G, .SJf5GS').forEach((el) => {
                        el.textContent = count;
                        el.classList.toggle('hidden', count <= 0);
                    });
                    const countCart = document.querySelectorAll(".w-1\\/5")[2].querySelector("a div span");
                    if (countCart) {
                        countCart.textContent = count;
                    }else{
                        const span = document.createElement("span");
                        span.className = 'absolute bg-white shadow-[0_0_0_1_1461e2] text-4xs colr-1461e2 min-w-20 leading-1 rounded-pill right-full -mr-12 -bottom-1 px-5 font-bold text-center pt-4 pb-1 tracking-ultratight dir-ltr';
                        span.innerHTML = count;
                        document.querySelectorAll(".w-1\\/5")[2].querySelector("a div").appendChild(span);
                    }
                }else{
                    uikit__collections_error(response.data.message);
                    $input.html(qty-1);
                }
                button.prop('disabled', false);
                $(".before\\:loading").removeClass("is-loading");
                $(".before\\:loading > div").css('filter', 'blur(0px)');
            },
            error: function (jqXHR, exception) {
                if (jqXHR.status === 0) {
                    uikit__collections_error('اینترنت شما قطع شده است!');
                } else if (jqXHR.status == 404) {
                    uikit__collections_error('Requested page not found. [404]');
                } else if (jqXHR.status == 500) {
                    uikit__collections_error('Internal Server Error [500].');
                } else if (exception === 'parsererror') {
                    uikit__collections_error('Requested JSON parse failed.');
                } else if (exception === 'timeout') {
                    uikit__collections_error('Time out error.');
                } else if (exception === 'abort') {
                    uikit__collections_error('Ajax request aborted.');
                } else {
                    uikit__collections_error(jqXHR.message);
                }
            }, complete() {
                $input.prop('disabled', false);
            }
        });
    }
    window.updateCartByProduct = function(productId, qty, $qtyBox, button,gatewayApi,mini=0) {

        $.ajax({
            url: `${wpApiSettingsGiftMax.root}api/v2/updateCartQty`,
            method: 'POST',
            dataType: 'json',
            data: {
                product_id: productId,
                quantity: qty,
                gateway:gatewayApi
            },
            beforeSend: function (xhr) {
                xhr.setRequestHeader('X-WP-Nonce', wpApiSettingsGiftMax.nonce);
            },
            success: function (response) {
                button.prop('disabled', false);
                if(response.success) {
                    if (response.data.action == 'cart_empty') {
                        if (document.getElementById('user-cart')) {
                            document.getElementById('user-cart').innerHTML = '';
                        } else if (document.querySelector('[data-status="ibc"]')) {
                            const modalRoot = document.querySelector('[data-status="ibc"]').closest(
                                '.ModalComponent__root-YwCAMP.ModalComponent__root--desktop-JzGyNl.ModalComponent__animation-JkgpfL.ModalComponent__root--open-i5pSf7.ModalComponent__root--open__desktop-x1XDzU'
                            );
                            $('[data-status="ibc"]').css('transform', 'translateY(400%)');
                            setTimeout(function () {
                                modalRoot.remove();
                                document.body.classList.toggle('lock-body-scroll');
                            }, 100);
                        }
                        const el = document.querySelector('.SJf5G');
                        if (el) {
                            if (!el.classList.contains('hidden')) {
                                el.classList.toggle("hidden")
                            }
                            el.textContent = 0;
                        }
                        if($(".mobileCart").length !=0){
                            closePup($(".mobileCart"))
                        }
                        const countCart = document.querySelectorAll(".w-1\\/5")[2].querySelector("a div");
                        if (countCart) {
                            countCart.remove();
                            window.cart = '';
                        }
                        if (document.querySelector(".widget-shop-cart")) {
                            document.querySelector(".widget-shop-cart").innerHTML = '<div class="p-24 text-center text-gray">سبد خرید خالی است</div>';
                        }
                        return;
                    }
                        $(document.body).trigger('wc_fragment_refresh');
                        $qtyBox.html(response.data.new_quantity);
                    if (document.getElementById("total_points")) {
                        $("#total_points").text(response.data.total_points);
                    }
                    renderMiniCart(response.data.mini);
                    if (mini == 1) {
                        const item = response.data.item;
                        const row = $(`tr[data-mini-item="${response.data.cart_item_key}"]`);
                        row.find('[data-mini-qty]').text(response.data.new_quantity);
                        const $deleteBtn = row.find('[data-mini-decrease]');
                        if (response.data.new_quantity < 2) {
                            $deleteBtn.find('i').removeClass('icon-minus text-[9px] text-gray bg-white shadow-sm block text-center rounded-sm w-28 h-28 !leading-[28px]');
                            $deleteBtn.find('i').addClass('icon-delete text-xs text-red-dark text-opacity-90 bg-white shadow-sm block text-center rounded-sm w-28 h-28 !leading-[28px]');
                        }
                        if (response.data.new_quantity <= 0) {
                            row.remove();
                        }
                        row.find('.font-size-13.text-lg.font-bold.text-dark.tracking-tighter.pt-2.inline-block').text(item.final_total);
                        if (item.original_total) {
                            row.find('.ml-6.font-size-13text-sm.font-bold.text-red.opacity-85.tracking-tighter.mb-2.block.line-through').text(item.original_total);
                        }
                        $("[data-summary=\"subtotal\"] span").text(response.data.cart.subtotal);
                        $("[data-summary=\"discount\"] span").text(response.data.cart.discount);
                        $("[data-summary=\"total\"] span").text(response.data.cart.total);
                        $(".before\\:loading").removeClass("is-loading");
                        $(".before\\:loading > div").css('filter', 'blur(0px)');
                    }
                }else{
                    uikit__collections_error(response.data.message);
                    $qtyBox.html(qty - 1);
                    $(".before\\:loading").removeClass("is-loading");
                    $(".before\\:loading > div").css('filter', 'blur(0px)');
                }
            },
            error: function (jqXHR, exception) {
                if (jqXHR.status === 0) {
                    uikit__collections_error('اینترنت شما قطع شده است!');
                } else if (jqXHR.status == 404) {
                    uikit__collections_error('Requested page not found. [404]');
                } else if (jqXHR.status == 500) {
                    uikit__collections_error('Internal Server Error [500].');
                } else if (exception === 'parsererror') {
                    uikit__collections_error('Requested JSON parse failed.');
                } else if (exception === 'timeout') {
                    uikit__collections_error('Time out error.');
                } else if (exception === 'abort') {
                    uikit__collections_error('Ajax request aborted.');
                } else {
                    uikit__collections_error(jqXHR.message);
                }
            }, complete() {
                $qtyBox.prop('disabled', false);
            }
        });
    }
    window.slider = function ($scope){
        const sliderEl = $scope.find(".new-service-box-swiper");
        if (!sliderEl.length) return;

        if (sliderEl.data("swiper-initialized")) return;
        sliderEl.data("swiper-initialized", true);

        new Swiper(sliderEl[0], {
            slidesPerView: "auto",
            freeMode: true,
            navigation: {
                nextEl: $scope.find(".act-new-service-carousel-head-but-l")[0],
                prevEl: $scope.find(".act-new-service-carousel-head-but-r")[0],
            },
        });

        const leftBtn = $scope.find('.act-new-service-carousel-head-but-l').get(0);
        const box     = sliderEl.get(0);

        if (leftBtn && box) {
            const observer = new MutationObserver(() => {
                if (leftBtn.classList.contains('swiper-button-disabled')) {
                    box.classList.add('taheshe');
                } else {
                    box.classList.remove('taheshe');
                }
            });

            observer.observe(leftBtn, { attributes: true, attributeFilter: ['class'] });
        }
    }
    window.sliderPercent = function ($scope){
        const sliderEl = $scope.find(".percent-box-swiper");
        if (!sliderEl.length) return;

        if (sliderEl.data("swiper-initialized")) return;
        sliderEl.data("swiper-initialized", true);

        new Swiper(sliderEl[0], {
            slidesPerView: "auto",
            freeMode: true,
            navigation: {
                nextEl: $scope.find(".act-percent-but-l")[0],
                prevEl: $scope.find(".act-percent-but-r")[0],
            },
        });

        const leftBtn = $scope.find('.act-percent-but-l').get(0);
        const box     = sliderEl.get(0);

        if (leftBtn && box) {
            const observer = new MutationObserver(() => {
                if (leftBtn.classList.contains('swiper-button-disabled')) {
                    box.classList.add('taheshe');
                } else {
                    box.classList.remove('taheshe');
                }
            });

            observer.observe(leftBtn, { attributes: true, attributeFilter: ['class'] });
        }
    }
    window.sliderBlog = function ($scope){
        const sliderEl = $scope.find(".new-blog-swiper");
        if (!sliderEl.length) return;

        // جلوگیری از دوباره مقداردهی
        if (sliderEl.data("swiper-initialized")) return;
        sliderEl.data("swiper-initialized", true);

        // راه‌اندازی Swiper
        new Swiper(sliderEl[0], {
            slidesPerView: "auto",
            spaceBetween: 4,
            freeMode: true,
            navigation: {
                nextEl: $scope.find(".act-blog-head-but-l")[0],
                prevEl: $scope.find(".act-blog-head-but-r")[0],
            },
        });

        const leftBtn = $scope.find('.act-blog-head-but-l').get(0);
        const box     = sliderEl.get(0);

        if (leftBtn && box) {
            const observer = new MutationObserver(() => {
                if (leftBtn.classList.contains('swiper-button-disabled')) {
                    box.classList.add('taheshe');
                } else {
                    box.classList.remove('taheshe');
                }
            });

            observer.observe(leftBtn, { attributes: true, attributeFilter: ['class'] });
        }
    }
    window.bankCardsSwiper = function (){
        const sliderEl = document.querySelector('.bank-cards-swiper');
        if (!sliderEl) return;
        initSwiper(sliderEl, {
            direction: 'vertical',
            slidesPerView: 2,
            feeMode: true,
            spaceBetween: 0,
            speed: 520,
            autoplay: {
                delay: 2500,
                disableOnInteraction: false,
                pauseOnMouseEnter: false,
            },
            allowTouchMove: true,
            grabCursor: true,
            resistanceRatio: 0.6
        });
    }
    window.supportedBrandsSwiper = function (){
        const sliderEl = document.querySelector('.supported__brands');
        if (!sliderEl) return;

        initSwiper(sliderEl, {
            slidesPerView: "auto",
            spaceBetween: 4,
            loop: true,
            speed: 3000,
            rtl: true,

            autoplay: {
                delay: 0,
                disableOnInteraction: false,
                pauseOnMouseEnter: false,
            },

            allowTouchMove: true,
            grabCursor: true,
            resistanceRatio: 0.6
        });
    }
    window.BlogsSwiper = function (){
        const sliderEl = document.querySelector('.swiper-blogs');
        if (!sliderEl) return;
        const isMobile = window.innerWidth <= 768;

        new Swiper(sliderEl, {
            slidesPerView: 'auto',
            loop: true,

            autoplay: {
                delay: 0,
                disableOnInteraction: false,
                pauseOnMouseEnter: true,
                reverseDirection: false,
            },

            speed: 5000,
            spaceBetween: 20,

            navigation: false,
            pagination: false,

            observer: true,
            observeParents: true
        });
    }
    window.PostSwiper = function (){
        const sliderEl = document.querySelector('.swiper-post-_card');
        if (!sliderEl) return;

        initSwiper(sliderEl, {
            slidesPerView: 1,
            speed: 520,
            loop: true,
            autoplay: {
                delay: 5000,
                disableOnInteraction: false,
            },
            allowTouchMove: false,
            navigation: false,
            pagination: false
        });
    }
    window.initThemeScripts = function (){
        let number = '',verify = true;
        let hash,url;
        bannerHandler($(document));
        timersh();
        timerlpt();
        timerlpts();
        amazingProduct();
        cartCleanupExecuted = false;
        startCartTimer();
        slider($(document));
        sliderPercent($(document));
        sliderBlog($(document));
        bankCardsSwiper();
        sliderIndex();
        supportedBrandsSwiper();
        paymentButton();
        initGpRating(document);
        timerpsh();
        uikit__card_settings_init();
        priceChartModal();
        ps();
        readALat();
        selectRegion();
        BlogsSwiper();
        tabpro();
        coin();
        nAlert();
        Tooltip();
        const btn = document.getElementById('go-to-blabla');
        const threshold = 100; // 100 پیکسل
        if (btn) {
            function checkScroll() {
                const scrollTop = window.pageYOffset || document.documentElement.scrollTop;

                if (scrollTop > threshold) {
                    btn.classList.add('visible');
                } else {
                    btn.classList.remove('visible');
                }
            }

            window.addEventListener('scroll', checkScroll);
            checkScroll();
        }
        const djde6s5 = document.querySelector(".djde6s5");
        if (djde6s5 && djde6s5.clientHeight > 29) {
            djde6s5.height = '29px';
            djde6s5.querySelector('ul').classList.remove('flex-wrap');
            const div = document.createElement('div');
            div.className = "bg-gradient-to-r from-white from-50% pr-60 absolute left-0 top-0 pointer-events-none";
            div.innerHTML = `<button type="button" class="btn group px-8 border border-light bg-light hover:bg-primary hover:border-transparent hover:bg-opacity-15 block rounded-sm text-2xs leading-1 pt-8 pb-6 pointer-events-auto Buton-df96"> <span className="text-dark opacity-75 group-hover:opacity-100 group-hover:text-primary-dark transition-all">بیشتر...</span> </button>`;
            djde6s5.appendChild(div);
        }
        const lottieContainers = document.querySelectorAll('.lottie-container');

        lottieContainers.forEach(container => {
            const animationPath = container.getAttribute('data-lottie-url');

            if (animationPath) {
                lottie.loadAnimation({
                    container: container, // المانی که انیمیشن در آن قرار می‌گیرد
                    renderer: 'svg',       // نوع رندر (svg بهترین گزینه است)
                    loop: true,            // تکرار انیمیشن
                    autoplay: true,        // اجرای خودکار
                    path: animationPath    // آدرس فایل JSON آپلود شده
                });
                container.setAttribute('data-lottie-url', '');
            }
        });
        const items = document.querySelectorAll('.v10__Pagination-item');
        if (items.length > 0) {
            const defaultActive = document.querySelector('.v10__Pagination-item.active') || items[0];
            setActive(defaultActive);
        }
        const previewEl = document.createElement('div');
        previewEl.id = 'card-preview';
        document.body.appendChild(previewEl);

        document.querySelectorAll('.bank-card').forEach(card => {
            card.addEventListener('mouseenter', () => {
                const rect = card.getBoundingClientRect();

                // کپی کردن محتوای کارت داخل پیش‌نمایش
                previewEl.innerHTML = card.querySelector(".V10-3-Bank").outerHTML;

                // قرار دادن دقیق روی مختصات کارت اصلی
                previewEl.style.top = `${rect.top}px`;
                previewEl.style.left = `${rect.left}px`;
                previewEl.style.width = `${rect.width}px`;
                previewEl.style.height = `${rect.height}px`;

                previewEl.classList.add('active');
            });

            card.addEventListener('mouseleave', () => {
                previewEl.classList.remove('active');
            });
        });
    }
    window.hasNegativeSign = function(expression) {
        return expression.includes("-");
    }
    window.creatCoin = function (nameCoin,dayChange,dayChangeValue,dayClose,time,svg,ctr='#swiper-wrapper-coin',cls="swiper-slide",d=0){
        let storyCoin,svgCoin;
        if (!hasNegativeSign(dayChange)) {
            storyCoin = "text-headline-xSmall text-txt-success-default";
            svgCoin = "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"16\" height=\"16\" viewBox=\"0 0 20 20\" fill=\"none\"><path d=\"M16.6667 10.8333V6.66667H12.5\" stroke=\"#087233\" stroke-width=\"1.5\" stroke-miterlimit=\"10\" stroke-linecap=\"round\" stroke-linejoin=\"round\"></path><path d=\"M3.3335 13.3333L7.50016 9.16667L10.8335 12.5L16.6668 6.66667\" stroke=\"#087233\" stroke-width=\"1.5\" stroke-miterlimit=\"10\" stroke-linecap=\"round\" stroke-linejoin=\"round\"></path></svg>";
        } else {
            storyCoin = "text-headline-xSmall text-txt-error-default";
            svgCoin = "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"16\" height=\"16\" viewBox=\"0 0 20 20\" fill=\"none\" style=\"transform: scaleY(-1);\"><path d=\"M16.6667 10.8333V6.66667H12.5\" stroke=\"#DE3730\" stroke-width=\"1.5\" stroke-miterlimit=\"10\" stroke-linecap=\"round\" stroke-linejoin=\"round\"></path><path d=\"M3.3335 13.3333L7.50016 9.16667L10.8335 12.5L16.6668 6.66667\" stroke=\"#DE3730\" stroke-width=\"1.5\" stroke-miterlimit=\"10\" stroke-linecap=\"round\" stroke-linejoin=\"round\"></path></svg>";
        }
        let usd = '';
        if(d==1){
            usd = `<div class="absolute h-8 w-8 child:rounded-circle child:bg-green_2 top-4 right-4"> <div class="animate-ping absolute inset-x-0 inset-y-0 opacity-75"></div> <div class="relative h-full w-full"></div> </div>`;
        }
        const container = document.querySelector(ctr);
        const div = document.createElement("div");
        let img;
        if (svg){
            img = `<img src="${wpApiSettingsGiftMax.directory}/assets/img/svg/${svg}.svg" class="size-coin">`;
        }else {
            img = '';
        }
        div.className = cls;
        if (isMobileDevice()){
            div.innerHTML = `<div class="flex justify-between flex-col"> <div class="flex justify-between flex-col"> <div class="flex justify-between items-center"> <div class="flex justify-between items-center"> ${img} <div>${nameCoin}</div> </div> <div class="relative"> ${usd} <div class="card-time font-12-400" style="${d == 1 ? 'margin-right: 18px' : ''}">${time}</div> </div> </div> <div class="storyCoin" dir="ltr"> ${Number(dayClose).toLocaleString("fa-IR")} <svg style="width: 16px;height: 16px;fill: #424750;"> <path fill-rule="evenodd" d="M3.057 1.742L3.821 1l.78.75-.776.741-.768-.749zm3.23 2.48c0 .622-.16 1.111-.478 1.467-.201.221-.462.39-.783.505a3.251 3.251 0 01-1.083.163h-.555c-.421 0-.801-.074-1.139-.223a2.045 2.045 0 01-.9-.738A2.238 2.238 0 011 4.148c0-.059.001-.117.004-.176.03-.55.204-1.158.525-1.827l1.095.484c-.257.532-.397 1-.419 1.403-.002.04-.004.08-.004.12 0 .252.055.458.166.618a.887.887 0 00.5.354c.085.028.178.048.278.06.079.01.16.014.243.014h.555c.458 0 .769-.081.933-.244.14-.139.21-.383.21-.731V2.02h1.2v2.202zm5.433 3.184l-.72-.7.709-.706.735.707-.724.7zm-2.856.308c.542 0 .973.19 1.293.569.297.346.445.777.445 1.293v.364h.18v-.004h.41c.221 0 .377-.028.467-.084.093-.055.14-.14.14-.258v-.069c.004-.243.017-1.044 0-1.115L13 8.05v1.574a1.4 1.4 0 01-.287.863c-.306.405-.804.607-1.495.607h-.627c-.061.733-.434 1.257-1.117 1.573-.267.122-.58.21-.937.265a5.845 5.845 0 01-.914.067v-1.159c.612 0 1.072-.082 1.38-.247.25-.132.376-.298.376-.499h-.515c-.436 0-.807-.113-1.113-.339-.367-.273-.55-.667-.55-1.18 0-.488.122-.901.367-1.24.296-.415.728-.622 1.296-.622zm.533 2.226v-.364c0-.217-.048-.389-.143-.516a.464.464 0 00-.39-.187.478.478 0 00-.396.187.705.705 0 00-.136.449.65.65 0 00.003.067c.008.125.066.22.177.283.093.054.21.08.352.08h.533zM9.5 6.707l.72.7.724-.7L10.209 6l-.709.707zm-6.694 4.888h.03c.433-.01.745-.106.937-.29.024.012.065.035.12.068l.074.039.081.042c.135.073.261.133.379.18.345.146.67.22.977.22a1.216 1.216 0 00.87-.34c.3-.285.449-.714.449-1.286a2.19 2.19 0 00-.335-1.145c-.299-.457-.732-.685-1.3-.685-.502 0-.916.192-1.242.575-.113.132-.21.284-.294.456-.032.062-.06.125-.084.191a.504.504 0 00-.03.078 1.67 1.67 0 00-.022.06c-.103.309-.171.485-.205.53-.072.09-.214.14-.427.147-.123-.005-.209-.03-.256-.076-.057-.054-.085-.153-.085-.297V7l-1.201-.5v3.562c0 .261.048.496.143.703.071.158.168.296.29.413.123.118.266.211.43.28.198.084.42.13.665.136v.001h.036zm2.752-1.014a.778.778 0 00.044-.353.868.868 0 00-.165-.47c-.1-.134-.217-.201-.35-.201-.18 0-.33.103-.447.31-.042.071-.08.158-.114.262a2.434 2.434 0 00-.04.12l-.015.053-.015.046c.142.118.323.216.544.293.18.062.325.092.433.092.044 0 .086-.05.125-.152z" clip-rule="evenodd"></path> </svg> </div> </div> <div class="flex justify-between align-items-center flex-col"> <div class="percent-change-wrapper ${storyCoin} font-12-500 rounded-2 order-2 order-xl-1 justify-between w-full"> ${svgCoin} <span><span>(${Math.abs(dayChange)}%)</span><span>${Number(Math.abs(dayChangeValue)).toLocaleString("fa-IR")}</span></span></div> </div> </div>`;
        }else {
            div.innerHTML = `<div class="flex justify-between flex-col"><div class="flex justify-between"><div class="flex justify-between items-center">${img}<div>${nameCoin}</div></div><div class="storyCoin" dir="ltr">${Number(dayClose).toLocaleString("fa-IR")}<svg style="width: 16px;height: 16px;fill: #424750;"><path fill-rule="evenodd" d="M3.057 1.742L3.821 1l.78.75-.776.741-.768-.749zm3.23 2.48c0 .622-.16 1.111-.478 1.467-.201.221-.462.39-.783.505a3.251 3.251 0 01-1.083.163h-.555c-.421 0-.801-.074-1.139-.223a2.045 2.045 0 01-.9-.738A2.238 2.238 0 011 4.148c0-.059.001-.117.004-.176.03-.55.204-1.158.525-1.827l1.095.484c-.257.532-.397 1-.419 1.403-.002.04-.004.08-.004.12 0 .252.055.458.166.618a.887.887 0 00.5.354c.085.028.178.048.278.06.079.01.16.014.243.014h.555c.458 0 .769-.081.933-.244.14-.139.21-.383.21-.731V2.02h1.2v2.202zm5.433 3.184l-.72-.7.709-.706.735.707-.724.7zm-2.856.308c.542 0 .973.19 1.293.569.297.346.445.777.445 1.293v.364h.18v-.004h.41c.221 0 .377-.028.467-.084.093-.055.14-.14.14-.258v-.069c.004-.243.017-1.044 0-1.115L13 8.05v1.574a1.4 1.4 0 01-.287.863c-.306.405-.804.607-1.495.607h-.627c-.061.733-.434 1.257-1.117 1.573-.267.122-.58.21-.937.265a5.845 5.845 0 01-.914.067v-1.159c.612 0 1.072-.082 1.38-.247.25-.132.376-.298.376-.499h-.515c-.436 0-.807-.113-1.113-.339-.367-.273-.55-.667-.55-1.18 0-.488.122-.901.367-1.24.296-.415.728-.622 1.296-.622zm.533 2.226v-.364c0-.217-.048-.389-.143-.516a.464.464 0 00-.39-.187.478.478 0 00-.396.187.705.705 0 00-.136.449.65.65 0 00.003.067c.008.125.066.22.177.283.093.054.21.08.352.08h.533zM9.5 6.707l.72.7.724-.7L10.209 6l-.709.707zm-6.694 4.888h.03c.433-.01.745-.106.937-.29.024.012.065.035.12.068l.074.039.081.042c.135.073.261.133.379.18.345.146.67.22.977.22a1.216 1.216 0 00.87-.34c.3-.285.449-.714.449-1.286a2.19 2.19 0 00-.335-1.145c-.299-.457-.732-.685-1.3-.685-.502 0-.916.192-1.242.575-.113.132-.21.284-.294.456-.032.062-.06.125-.084.191a.504.504 0 00-.03.078 1.67 1.67 0 00-.022.06c-.103.309-.171.485-.205.53-.072.09-.214.14-.427.147-.123-.005-.209-.03-.256-.076-.057-.054-.085-.153-.085-.297V7l-1.201-.5v3.562c0 .261.048.496.143.703.071.158.168.296.29.413.123.118.266.211.43.28.198.084.42.13.665.136v.001h.036zm2.752-1.014a.778.778 0 00.044-.353.868.868 0 00-.165-.47c-.1-.134-.217-.201-.35-.201-.18 0-.33.103-.447.31-.042.071-.08.158-.114.262a2.434 2.434 0 00-.04.12l-.015.053-.015.046c.142.118.323.216.544.293.18.062.325.092.433.092.044 0 .086-.05.125-.152z" clip-rule="evenodd"></path></svg></div></div><div class="flex justify-between align-items-center"><div class="relative">${usd}<div class="card-time font-12-400" style="${d == 1 ? 'margin-right: 18px' : ''}">${time}</div></div><div class="percent-change-wrapper ${storyCoin} font-12-500 rounded-2 order-2 order-xl-1">${svgCoin}<span class="line-height-0"><span class="mr-1 ">(${Math.abs(dayChange)}%)</span><span>${Number(Math.abs(dayChangeValue)).toLocaleString("fa-IR")}</span></span></div></div></div>`;
        }
        container.appendChild(div);
    }
    window.coin = function (){
        SAJ('stats',{},function (res){
            if (document.querySelector(".usdtiri")) {
                if(document.querySelector(".usdtiri").classList.contains('d-none')){
                    document.querySelector(".usdtiri").classList.remove('d-none');
                }
                document.querySelector(".usdtiri").innerHTML = ``;
                creatCoin(`دلار`,res[1]['dayChange'],res[1]['dayChangeValue'],res[1]['dayClose'],res[1]['time'],'usd','.usdtiri', 'w-full c-coin__box flex justify-between flex-col',1);
            }
            if (document.querySelector(".usdtirim")) {
                if(document.querySelector(".usdtirim").classList.contains('d-none')){
                    document.querySelector(".usdtirim").classList.remove('d-none');
                }
                document.querySelector("#swiper-coin").innerHTML = ``;
                creatCoin(`دلار`,res[1]['dayChange'],res[1]['dayChangeValue'],res[1]['dayClose'],res[1]['time'],'usd','#swiper-coin', 'swiper-slide c-coin__box flex justify-between flex-col',1);
                creatCoin(`تتر`,res[0]['dayChange'],res[0]['dayChangeValue'],res[0]['dayClose'],res[0]['time'],'usdt.7ddba3a2','#swiper-coin','swiper-slide c-coin__box flex justify-between flex-col');
                creatCoin(`یورو`,res[2]['dayChange'],res[2]['dayChangeValue'],res[2]['dayClose'],res[2]['time'],'eu','#swiper-coin','swiper-slide c-coin__box flex justify-between flex-col');
                creatCoin(`پوند`,res[3]['dayChange'],res[3]['dayChangeValue'],res[3]['dayClose'],res[3]['time'],'uk','#swiper-coin','swiper-slide c-coin__box flex justify-between flex-col');
                creatCoin(`یوآن چین`,res[4]['dayChange'],res[4]['dayChangeValue'],res[4]['dayClose'],res[4]['time'],'cn','#swiper-coin','swiper-slide c-coin__box flex justify-between flex-col');

            }
            if (document.querySelector("#swiper-wrapper-coin")) {
                if (document.querySelector(".header-extra__list").classList.contains('d-none')) {
                    document.querySelector(".header-extra__list").classList.remove('d-none');
                }
                creatCoin(`تتر`, res[0]['dayChange'], res[0]['dayChangeValue'], res[0]['dayClose'], res[0]['time'], 'usdt.7ddba3a2', '#swiper-wrapper-coin', 'swiper-slide c-coin__box flex justify-between flex-col');
                creatCoin(`یورو`, res[2]['dayChange'], res[2]['dayChangeValue'], res[2]['dayClose'], res[2]['time'], 'eu', '#swiper-wrapper-coin', 'swiper-slide c-coin__box flex justify-between flex-col');
                creatCoin(`پوند`, res[3]['dayChange'], res[3]['dayChangeValue'], res[3]['dayClose'], res[3]['time'], 'uk', '#swiper-wrapper-coin', 'swiper-slide c-coin__box flex justify-between flex-col');
                creatCoin(`یوآن`, res[4]['dayChange'], res[4]['dayChangeValue'], res[4]['dayClose'], res[4]['time'], 'cn', '#swiper-wrapper-coin', 'swiper-slide c-coin__box flex justify-between flex-col');
            }
            swiperCoin();
        });
    }
    window.Tooltip = function (){
        const tooltipster = document.querySelectorAll('.js-dk-wiki-trigger');
        tooltipster.forEach(index=>{
            var textTooltip = index.dataset.tooltip;
            index.classList.add('wiki','wiki__holder');
            const tooltip = document.createElement("div");
            tooltip.className = 'wiki__container js-dk-wiki is-black';
            tooltip.innerHTML = `<div class="wiki__arrow"></div><p class="wiki__text">${textTooltip}</p>`
            index.appendChild(tooltip);
        });
    }
    window.swiperCoin = function (){
        if (isMobileDevice()) {
            const bannerCarousel = $(document).find(".usdtirim")[0];
            if (bannerCarousel) {
                initSwiper(bannerCarousel, {
                    slidesPerView: "auto",
                    autoplay: {
                        delay: 6000,
                    },
                });
            }
        }else{
            const bannerCarousel = $(document).find(".swiper-coin")[0];
            if (bannerCarousel) {
                initSwiper(bannerCarousel, {
                    slidesPerView: 3,
                    autoplay: {
                        delay: 6000,
                    },
                });
            }
        }
    }
    window.closePup = function (closeBtn){
        const modalRoot = closeBtn.closest(
            '.ModalComponent__root-YwCAMP.ModalComponent__root--desktop-JzGyNl.ModalComponent__animation-JkgpfL.ModalComponent__root--open-i5pSf7.ModalComponent__root--open__desktop-x1XDzU'
        );
        closeBtn.closest('.ModalComponent__content-XqD1rL').css('transform', 'translateY(400%)');
        setTimeout(function () {
            modalRoot.remove();
            document.body.classList.toggle('lock-body-scroll');
        }, 100);
    }
    window.paymentButton = function (){
        localStorage.setItem('selectedButton', 'zibal');
        const buttons = document.querySelectorAll('.Button-p4');
        buttons.forEach(button => {
            button.addEventListener('click', function() {
                buttons.forEach(btn => {
                    console.log(btn);
                    btn.querySelector('i').className = 'w-20 h-20 text-center rounded-circle bg-gray bg-opacity-15 text-4xs pl-1 ml-4 !leading-[22px] icon-check transition-colors text-transparent';
                });
                console.log(this);
                localStorage.setItem('selectedButton', button.dataset.gateway);
                this.querySelector('i').className = "w-20 h-20 text-center rounded-circle text-4xs pl-1 ml-4 !leading-[22px] icon-check transition-colors text-white bg-green bg-opacity-100";
            });
        });
    }
    window.renderMiniCart = function (data){
        window.cart = data;
        let container = document.querySelector('.widget-shop-cart');

        if (!container) return;

        container.innerHTML = '';
        const div = document.createElement('div');
        div.className = 'flex flex-col overflow-hidden max-h-[480px]';
        div.innerHTML = `<div class="p-24 grow overflow-y-auto minimal-scrollbar"></div><div class="px-24 py-16 flex items-center border-t border-gray-300 shrink-0"><div class="grow leading-xs pst-4"></div><a class="btn btn-primary rounded whitespace-nowrap mr-12 Cart-gd445">ثبت سفارش</a></div>`
        container.appendChild(div);
        container = document.querySelector('.widget-shop-cart .p-24.grow');
        cart.items.forEach(item => {

            const hasDiscount = item.price_regular > item.price_sale;
            const leftButton = item.qty > 1
                ? `
        <button type="button" class="pl-6 btn-minus" data-product-id="${item.product_id}">
            <i class="icon-minus text-[9px] text-gray bg-white shadow-sm block text-center rounded-sm w-28 h-28 !leading-[28px]"></i>
        </button>
      `
                : `
        <button type="button" class="pl-6 btn-minus" data-product-id="${item.product_id}">
            <i class="icon-delete text-xs text-red-dark w-24 h-24 bg-white shadow-sm block !leading-[24px] text-center rounded-sm"></i>
        </button>
      `;
            container.insertAdjacentHTML('beforeend', `
            <div class="flex items-start pb-20 mb-20 border-b border-gray-300 last:!mb-0 last:!pb-0 last:!border-none" data-product-id="${item.product_id}">
                <div class="pt-3 pb-1 grow leading-xs">
                     <a class="text-sm text-dark font-bold tracking-tight">${item.name}</a>
                    <div class="flex items-center mt-6 min-h-[38px]">
                        <div class="leading-1 pt-2 grow">

                            ${hasDiscount ? `
                                <span class="text-sm font-bold text-red-darker opacity-85 tracking-tighter mb-2 block line-through">
                                    ${item.price_regular}
                                </span>
                            ` : ''}

                            <div class="text-2xs text-gray font-medium tracking-tight">
                                <span class="text-larger font-bold text-dark tracking-tighter pt-2 inline-block">
                                    ${item.price_sale}
                                </span>
                                تومان
                            </div>
                        </div>
                        <div class="rounded bg-light w-104 h-36 flex flex-row-reverse transition-opacity">
                        ${leftButton}
                        <div class="grow text-center flex flex-col justify-center leading-1">
                        <div class="pt-2 text-dark font-bold tracking-tighter text-sm after:loading after:border-blue transition-colors after:text-3xs text-qty">${item.qty}</div></div>
                        <button type="button" class="pr-6 btn-plus" data-product-id="${item.product_id}">
                        <i class="w-24 h-24 bg-white shadow-sm text-gray rounded-sm icon-plus text-[9px] block !leading-[24px] text-center"></i></button>
                        </div>
                    </div>
                </div>
            </div>
        `);
        });

        updateCartFooter(cart);
    }
    window.updateCartFooter = function (cart){
        const footer = document.querySelector('.widget-shop-cart .border-t');

        if (!footer) return;

        const hasDiscount = cart.discount > 0;

        footer.querySelector('.grow').innerHTML = `
        <div class="text-2xs font-medium text-gray">مبلغ قابل پرداخت</div>
        <div class="flex items-center mt-2 flex-wrap">

            ${hasDiscount ? `
                <span class="ml-6 text-sm font-bold text-red-darker opacity-85 tracking-tighter pt-2 inline-block line-through">
                    ${cart.subtotal}
                </span>
            ` : ''}

            <div class="text-2xs text-gray font-medium tracking-tight">
                <span class="text-lg font-bold text-dark tracking-tighter pt-2 inline-block">
                    ${cart.total}
                </span>
                تومان
            </div>
        </div>
        <div class="mt-8 text-2xs text-gray font-medium tracking-tight" data-timer-container="">
             <span class="text-dark font-bold">زمان باقی مانده:</span>
             <span class="inline-block min-w-[52px] text-dark" data-cart-timer=""></span>
        </div>
    `;
        startCartTimer();
    }
    window.renderProducts = function(region) {
        const container = document.querySelector('.pb-24.lg\\:pb-28.lg\\:pt-6');
        container.innerHTML = '';
        if (typeof window.productsByRegion === 'string') {
            window.productsByRegion = JSON.parse(window.productsByRegion);
        }
        const products = window.productsByRegion[region] || [];
        if (products.length === 0) {
            // نمایش پیام خالی بودن
            const emptyDiv = document.createElement('div');
            emptyDiv.className = 'flex justify-between items-center py-20';
            emptyDiv.innerHTML = `
        <div class="flex justify-between items-center w-full flex-col">
            <img class="" src="${wpApiSettingsGiftMax.directory}/assets/img/ticket_img.png" alt="empty">
            <p class="text-body2-strong py-20">محصولی در این ریجن موجود نمیباشد!</p>
        </div>
    `;
            container.appendChild(emptyDiv);
            return;
        }

        products.forEach(p => {
            const priceNumber = Number(p.final_price.replace(/,/g, ''));
            const priceSale = Number(p.sale.replace(/,/g, ''));

            const div = document.createElement('div');
            div.className = 'pb-20 mb-20 border-b border-gray-300 last:!mb-0 last:!pb-0 last:!border-none';
            div.dataset.productId = p.id;
            div.innerHTML = `
        <div class="flex items-start">
            <div class="text-sm text-dark font-bold tracking-tight leading-[22px] grow">${p.title}</div>
        </div>
        <div class="flex items-center mt-6 min-h-[38px] justify-between">
        <button type="button" class="btn-ajax after:border-blue Button-bfa48" data-product-id="${p.id}"> افزودن به سبد </button>
        <div class="leading-1 pt-2">
        ${priceSale > 0 ? `<span class="ml-6 text-sm font-bold text-red-darker opacity-85 tracking-tighter mb-2 block line-through">${p.regular}</span>` :''}
         <div class="text-2xs text-gray font-medium tracking-tight">
            ${priceNumber > 0
                ? `<span class="text-larger font-bold text-dark tracking-tighter pt-2 inline-block">${p.final_price}</span> تومان`
                : '<div class="act-product-price-free">رایگان</div>'}
        </div>
       </div>
      </div>
       
    `;
            container.appendChild(div);
        });
    }
    window.initGpRating = function (root) {
        const scope = root || document;
        const ratingList = scope.querySelector('.act-rating-list');
        const select = scope.querySelector('#rating');
        const ratingLabel = scope.querySelector('.act-rating-max-label');

        if (!ratingList || !select) return;
        if (ratingList.dataset.gpRatingBound === '1') return; // جلوگیری از بایند دوباره
        ratingList.dataset.gpRatingBound = '1';

        const items = ratingList.querySelectorAll('li');

        items.forEach(function (item) {
            item.addEventListener('click', function (e) {
                e.preventDefault();

                items.forEach(function (li) {
                    li.classList.remove('active');
                });

                this.classList.add('active');

                const val = this.getAttribute('data-value');
                select.value = val;

                if (ratingLabel) ratingLabel.textContent = val + '.0';
            });
        });

        const defaultValue = '5';
        select.value = defaultValue;
        const defaultItem = ratingList.querySelector('li[data-value="' + defaultValue + '"]');
        if (defaultItem) {
            defaultItem.classList.add('active');
            if (ratingLabel) ratingLabel.textContent = defaultValue + '.0';
        }
    }
    window.timerUpdate = function (){
        const timerEl = document.getElementById('timer_upload');
        if (!timerEl) return;
        const minutes = Number(timerEl.dataset.timer);
        if (Number.isNaN(minutes) || minutes < 0) return;
        const endMs = Date.now() + minutes * 60 * 1000;
        const render = () => {
            const remainingMs = Math.max(0, endMs - Date.now());
            const m = Math.floor(remainingMs / (60 * 1000));
            const s = Math.floor((remainingMs % (60 * 1000)) / 1000);
            if (m > 0) {
                timerEl.textContent = `${m} دقیقه ${s} ثانیه`;
            } else {
                timerEl.textContent = `${s} ثانیه`;
            }
        };
        const tick = () => {
            if (Date.now() >= endMs) {
                timerEl.textContent = `0 دقیقه`;
                uikit__collections_error("زمان به پایان رسید");
                clearInterval(interval);
                ajaxLoad(window.location.href, false);
                return;
            }
            render();
        };
        render();
        const interval = setInterval(tick, 1000);
    }
    window.ps = function (){
        const slider = document.querySelector('.product‑slider');
        if (slider) {

            const childCount = slider.children.length;

            const step = -20;
            const positions = Array.from(
                {length: childCount},
                (_, i) => step * (i)
            );
            positions.push(0);
            let idx = 0;
            setInterval(() => {
                slider.style.transform = `translateY(${positions[idx]}px)`;
                idx = (idx + 1) % positions.length;
            }, 2900)
        }
        const slider2 = document.querySelector('.product_slider');
        if (slider2) {
            const childCount = slider2.children.length;

            const step = -20;
            const positions = Array.from(
                {length: childCount},
                (_, i) => step * (i)
            );
            positions.push(0);
            let idx = 0;
            setInterval(() => {
                slider2.style.transform = `translateY(${positions[idx]}px)`;
                idx = (idx + 1) % positions.length;
            }, 2900)
        }
        const slider_mobile = document.querySelector('.product_slider-mobile');
        if (slider_mobile) {
            const childCount = slider_mobile.children.length;

            const step = -36;
            const positions = Array.from(
                {length: childCount},
                (_, i) => step * (i)
            );
            positions.push(0);
            let idx = 0;
            setInterval(() => {
                slider_mobile.style.transform = `translateY(${positions[idx]}px)`;
                idx = (idx + 1) % positions.length;
            }, 2900)
        }
    }
    window.tabpro = function (){
        const tabs = document.querySelectorAll(".gp-tab-btn");
        if (tabs.length > 0){
            tabs.forEach(function (tab) {
                document.querySelector(`#${tab.dataset.target}`).style.display = 'none';
            })
            tabs[0].classList.add('active');
            document.querySelector(`#${tabs[0].dataset.target}`).style.display = 'block';
        }
    }
    window.readALat = function (){
        const SJD83s = document.querySelector('.SJD83s');
        if (SJD83s && SJD83s.offsetHeight > 338 ){
            const div = document.createElement('div');
            SJD83s.classList.add('relative', 'overflow-hidden'); // Added quotes around each class
            SJD83s.classList.add('h-[400px]');
            SJD83s.querySelector('.content-main').classList.add('absolute', 'top-0', 'right-0', 'p-18');
            SJD83s.querySelector('.content-main').classList.add('h-[338px]');
            div.className = 'absolute w-full right-0 bottom-0 lg:pb-16 lg:mr-16 before:h-[116px] lg:before:h-[164px] before:w-full before:absolute before:right-0 before:bottom-0 before:pointer-events-none before:bg-gradient-to-t before:from-20% lg:before:from-35% before:from-white';
            div.innerHTML = `<button type="button" class="btn flex !text-primary-dark px-0 py-2 lg:py-8 items-center !bg-transparent relative z-[2] Button-ral12"><span class="font-bold text-sm ml-12 pt-4">بیشتر بخوانید</span><i class="icon-angle-down w-24 h-24 flex items-center justify-center bg-primary bg-opacity-20 text-[9px] rounded-sm pt-2"></i></button>`;
            SJD83s.appendChild(div);
        }
        const din = document.querySelector('.act-comment-box-discription');
        if (din && din.offsetHeight > 338 ){
            const div = document.createElement('div');
            din.classList.add('relative', 'overflow-hidden'); // Added quotes around each class
            din.classList.add('h-[400px]');
            din.querySelector('.act-comment-box__din').classList.add('absolute', 'top-0', 'right-0', 'p-18', 'pb-0');
            din.querySelector('.act-comment-box__din').classList.add('h-[338px]');
            div.className = 'absolute w-full right-0 bottom-0 lg:pb-16 before:h-[116px] lg:before:h-[164px] before:w-full before:absolute before:right-0 before:bottom-0 before:pointer-events-none before:bg-gradient-to-t before:from-20% lg:before:from-35% before:from-white';
            div.innerHTML = `<button type="button" class="btn flex !text-primary-dark px-0 py-2 lg:py-8 items-center !bg-transparent relative z-[2] Button-ral13"><span class="font-bold text-sm ml-12 pt-4">بیشتر بخوانید</span><i class="icon-angle-down w-24 h-24 flex items-center justify-center bg-primary bg-opacity-20 text-[9px] rounded-sm pt-2"></i></button>`;
            din.appendChild(div);
        }
    }
    window.sliderIndex = function (){
        const swiperBanner = document.querySelector('.swiper-banner');
        if (swiperBanner){
            new Swiper(swiperBanner, {
                slidesPerView: 1,
                spaceBetween: 5,
                effect: 'fade',
                autoplay: {
                    delay: 4500,
                    disableOnInteraction: false,
                },
                fadeEffect: {
                    crossFade: true
                },
                loop:true,
                pagination: {
                    el: '.swiper-pagination-banner',
                    clickable:true,
                },
                navigation: {
                    nextEl: '.swiper-button-next-banner',
                    prevEl: '.swiper-button-prev-banner',
                },
            });
        }
    }
    window.selectRegion = function (){
        const select_region = document.querySelector(".c-box__ceWU4d");
        if(select_region) {
            new Swiper(select_region, {
                slidesPerView: 'auto',
                spaceBetween: 5,
                navigation: {
                    nextEl: '.swiper-button-next-region',
                    prevEl: '.swiper-button-prev-region',
                },
            });
        }
    }
    window.updataPrice = function (id){
        const counterElements = document.querySelectorAll(id);
        function startCounter(element) {
            const target = parseInt(element.getAttribute('data-target'));
            if (isNaN(target)) return;

            const duration = 2000;
            const step = Math.ceil(target / (duration / 16));
            let current = 0;
            const timer = setInterval(() => {
                current += step;
                if (current >= target) {
                    current = target;
                    clearInterval(timer);
                }
                element.textContent = current.toLocaleString();
            }, 16);
        }
        counterElements.forEach(counter => {
            startCounter(counter);
        });
    }
    window.sktPrice = function (){
        const priceValue = document.querySelectorAll('#priceValue');
        if (priceValue && priceValue.length > 0){
            const ids = [...new Set([...priceValue].map(el => el.dataset.id))];
            if (ids && ids.length > 0) {
                SAJ('prices', {ids: ids}, function (data) {
                    priceValue.forEach(el => {
                        const id = el.dataset.id;
                        const newPrice = data[id];
                        const currentPrice = el.dataset.target;
                        if (newPrice && newPrice != currentPrice) {
                            el.dataset.target = newPrice;
                            updataPrice(`[data-id="${id}"]`);
                        }
                    });
                }, 'v2');
            }
        }
    }
    window.nAlert = function (){
        SAJ('alert',{},function (res){
           if (res.data.status) {
               if (res.data.records != null) {
                   const container = document.querySelector(".toast-container");
                   container.innerHTML = `<div class="toast-item-wrapper toast-animation-v2-enter-done" data-id="${res.data.records}"><div class="sc-4324465a-0 JioWZ toast-item successful" role="alert" aria-atomic="true"><div class="icon-wrapper"><svg class="icon icon-show-nofit" viewBox="0 0 24 25" width="1em" height="1em" focusable="false" aria-hidden="true" style="width: 1em; height: 1em;"><path d="M23.19 12.2c-.04-.08-.83-1.84-2.6-3.6C18.24 6.24 15.27 5 12 5S5.76 6.24 3.4 8.6c-1.76 1.76-2.56 3.53-2.59 3.6q-.06.15-.06.3 0 .16.06.3c.04.08.83 1.84 2.6 3.6C5.76 18.77 8.73 20 12 20s6.24-1.24 8.6-3.6c1.76-1.76 2.55-3.52 2.59-3.6q.06-.14.06-.3t-.06-.3M12 18.5q-4.34 0-7.5-3.12Q3.23 14.1 2.35 12.5 3.22 10.9 4.51 9.62 7.65 6.5 12 6.5t7.5 3.12q1.28 1.28 2.16 2.88c-.68 1.26-3.62 6-9.66 6M12 8C11.11 8 10.24 8.26 9.5 8.76Q8.37 9.53 7.84 10.78C7.5 11.6 7.41 12.5 7.6 13.38s.6 1.67 1.23 2.3 1.43 1.06 2.3 1.23C12 17.1 12.9 17 13.72 16.66S15.25 15.74 15.74 15c.5-.74.76-1.61.76-2.5 0-1.2-.48-2.34-1.32-3.18S13.2 8 12 8m0 7.5Q11.09 15.49 10.33 15 9.6 14.47 9.23 13.64 8.88 12.8 9.06 11.9q.18-.88.82-1.53Q10.52 9.75 11.4 9.56q.9-.18 1.74.17t1.34 1.1Q15 11.6 15 12.5c0 .8-.32 1.56-.88 2.12S12.8 15.5 12 15.5"></path></svg></div><div class="toast-body"><span class="sc-2d9072c2-1 fbzXBE body-text toast-message"><span>یک اعلان جدید ثبت شده</span></span></div><div class="toast-actions"><button class="dVEnfZ close-button icon-button" type="button"><svg class="aparat-icon icon icon-close icon-start" viewBox="0 0 24 25" width="1em" height="1em" focusable="false" style="width: 1em; height: 1em;"><path d="M18.8 18.3q.09.1.15.23Q19 18.67 19 18.8q0 .14-.05.27-.06.12-.16.22t-.22.16T18.3 19.5t-.27-.05Q17.91 19.39 17.8 19.29L12 13.5l-5.8 5.8q-.21.2-.5.2T5.2 19.3 5 18.8t.2-.5l5.81-5.8L5.21 6.7Q5 6.49 5 6.2T5.2 5.7Q5.42 5.5 5.7 5.5t.5.2l5.8 5.81 5.8-5.8Q18.01 5.5 18.3 5.5t.5.2T19 6.2t-.2.5l-5.81 5.8z"></path></svg></button></div></div></div>`;
               }
           } else{
               uikit__collections_error(res.message);
           }
        });
    }
})(jQuery);
function loaderHTML() {
    return `
    <div class="flex items-center justify-center" style="height:24px">
        <div class="flex gap-1">
            <span class="w-1.5 h-1.5 bg-gray-400 rounded-full animate-pulse"></span>
            <span class="w-1.5 h-1.5 bg-gray-500 rounded-full animate-pulse"></span>
            <span class="w-1.5 h-1.5 bg-gray-600 rounded-full animate-pulse"></span>
        </div>
    </div>`;
}
function extractDataFromInputsAndTextarea() {
    var data = {};

    if ($('input[name="firstName"]').length > 0) {
        var firstName = $('input[name="firstName"]').val();
        data.name = firstName;
    }

    if ($('input[name="lastName"]').length > 0) {
        var lastName = $('input[name="lastName"]').val();
        data.lastName = lastName;
    }


    if ($('input[name="userName"]').length > 0) {
        var userName = $('input[name="userName"]').val();
        data.userName = userName;
    }

    return data;
}
function formatPrice(num) {
    num = num.toString().replace(/\D/g, '');
    if (!num) return '';
    return Number(num).toLocaleString('en-US');
}
function unformatPrice(str) {
    return parseInt(str.toString().replace(/,/g, '')) || 0;
}
$(function () {
    const coupons = document.querySelector('.my-coupons-slider');
    if (coupons){
        initSwiper( coupons, {
            slidesPerView: "auto",
            spaceBetween: 1,
            loop: true,
            speed: 3300,
            rtl: false,

            autoplay: {
                delay: 4500,
                disableOnInteraction: false,
            },

            allowTouchMove: true,
            grabCursor: true,
            resistanceRatio: 0.6
        });
    }
    var intervalId,timeoutId;
    let refreshTimeout = null;
    let isClean = true;
    bannerHandler($(document));
    timersh();
    timerlpt();
    timerlpts();
    timerpsh();
    slider($(document));
    sliderPercent($(document));
    sliderBlog($(document));
    amazingProduct();
    /*header();*/
    Tooltip();
    actFaqHandler($(document));
    startCartTimer();
    swiperCoin();
    sliderIndex();
    coin();
    setInterval(function (){
        coin();
    },30000);
    setInterval(function (){
        sktPrice();
    },60000);
    paymentButton();
    bankCardsSwiper();
    PostSwiper();
    BlogsSwiper();
    supportedBrandsSwiper();
    uikit__card_settings_init();
    priceChartModal();
    ps();
    initGpRating(document);
    readALat();
    selectRegion();
    tabpro();
    nAlert();
    const previewEl = document.createElement('div');
    previewEl.id = 'card-preview';
    document.body.appendChild(previewEl);

    document.querySelectorAll('.bank-card').forEach(card => {
        card.addEventListener('mouseenter', () => {
            const rect = card.getBoundingClientRect();

            // کپی کردن محتوای کارت داخل پیش‌نمایش
            previewEl.innerHTML = card.querySelector(".V10-3-Bank").outerHTML;

            // قرار دادن دقیق روی مختصات کارت اصلی
            previewEl.style.top = `${rect.top}px`;
            previewEl.style.left = `${rect.left}px`;
            previewEl.style.width = `${rect.width}px`;
            previewEl.style.height = `${rect.height}px`;

            previewEl.classList.add('active');
        });

        card.addEventListener('mouseleave', () => {
            previewEl.classList.remove('active');
        });
    });
    $(document).on("click",".btn_mo-ripple.haschild",function () {
        if ($(this).hasClass("active")) {
            $(this).removeClass("active");
            $(this).parent().parent().find(".submenu:eq(0)").animate(
                {
                    right: "-300px",
                },
                "fast"
            );
        } else {
            $(this).addClass("active");
            $(this).parent().parent().find(".submenu:eq(0)").animate(
                {
                    right: "0",
                },
                "fast"
            );
            setTimeout(function (){
                document.querySelector('.main-navbar').scrollTo({
                    top: 0,
                    behavior: 'smooth'
                });
            },300)
        }
        return false;
    });
    $(document).on("click",".go-back",function () {
        $(this).parent().parent().find(".next").removeClass("active");
        $(this).parent().animate(
            {
                right: "-300px",
            },
            "fast"
        );
    });
    $(document).on("click", ".header-search .input-prepend .input-prepend-back", (function() {
            window.matchMedia("(max-width: 1200px)").matches && ($(".header-search").removeClass("header-search--laptop"),
                $(".main-navbar").removeClass("main-navbar-hide"));
        }
    ));
    $(document).on("click", ".header-search .search-field.form-field", (function() {
            if (window.matchMedia("(max-width: 1200px)").matches) {
                $(".header-search").addClass("header-search--laptop"),
                    $(".main-navbar").addClass("main-navbar-hide");
                var t = $("body").find(".rtl-dimmer")
                    , n = $("body").find(".overlayBody");
                t.length && (t.toggleClass("d-none"),
                    n.toggleClass("d-none"))
            }
            window.matchMedia("(min-width: 1200px)").matches && $(".header-search-result").hasClass("show") && "" == $(this).val() && $(".main-navbar").css("pointer-events", "none"),
            $(".header-search-result").hasClass("show") && "" == $(this).val() && $(".header-search").addClass("header-search--active"),
            "" !== $(this).val() && $(".header-search").addClass("header-search--active")
        }
    ))
    const body = document.body;

    document.addEventListener("click", function (e) {

        if (e.target.closest(".toggle-responsive-menu.btn.btn-md")) {
            e.preventDefault();
            body.classList.add("show-responsive-menu");
            return;
        }
        if (e.target.closest(".rtl-dimmer")) {
            e.preventDefault();
            body.classList.remove("show-responsive-menu");
            return;
        }
    });
    function startCountdown() {
        intervalId = setInterval(function () {
            countdown--;
            var minutes = Math.floor(countdown / 60);
            var seconds = countdown % 60;


            if (document.getElementById('timer')) {
                document.getElementById('timer').textContent = (minutes < 10 ? '0' : '') + minutes + ':' + (seconds < 10 ? '0' : '') + seconds;
            } else {
                clearInterval(intervalId);
                return; // توقف شمارنده اگر تگ timer وجود نداشته باشد
            }
            if (countdown === 0) {
                clearInterval(intervalId);
                var buttonAudio = '';
                if ($(".W3wYIMoFtWvsJZI8nfye").data('otp')){
                    buttonAudio = `<button type="button" class="relative d-flex ai-center user-select-none uikit-atomic-ButtonBase-ButtonBase-module__btn--vgnTU text-button-2 uikit-atomic-ButtonBase-ButtonBase-module__btn--text--lIZMT uikit-atomic-ButtonBase-ButtonBase-module__btn--primary--BJ1BU radius uikit-atomic-Button-Button-module__Button__medium--lj91O uikit-atomic-Button-Button-module__Button__textPrimary--65Ubg H5b50Hekz31U6Dqz5lES uikit-atomic-Button-Button-module__Button--TibOa Button-rta20" data-testid="button-wrapper"><div class="d-flex ai-center jc-center relative grow-1">دریافت کد صوتی</div></button>`;
                }
                $('.d-flex.mt-5.jc-center').html(`<button type=\"button\" class=\"relative d-flex ai-center user-select-none uikit-atomic-ButtonBase-ButtonBase-module__btn--vgnTU text-button-2 uikit-atomic-ButtonBase-ButtonBase-module__btn--text--lIZMT uikit-atomic-ButtonBase-ButtonBase-module__btn--primary--BJ1BU radius uikit-atomic-Button-Button-module__Button__medium--lj91O uikit-atomic-Button-Button-module__Button__textPrimary--65Ubg H5b50Hekz31U6Dqz5lES uikit-atomic-Button-Button-module__Button--TibOa Button-rt19\" data-testid=\"button-wrapper\"><div class=\"d-flex ai-center jc-center relative grow-1\">دریافت مجدد رمز یک&zwnj;بار مصرف </div></button>${buttonAudio}`);
            }
        }, 1000);
    }
    $('.bk_menu .bakala>ul>li>.bakala-tab-menu-items>ul.level>li').mouseenter(function () {
        $(this).parent().find('li').removeClass("active");
        $(this).addClass("active");
    });
    $('.cateqory-product .submenu-trigger>ul>li').mouseenter(function () {
        $(this).parent().find('li').removeClass("active");
        $(this).addClass("active");
    });

    let timer = null;

   $(document).on('input','.search-field', function() {
        const keyword = this.value.trim();

        if (keyword.length > 0) {
            $('.search-field__remove').css('display', 'block');
        } else {
            $('.search-field__remove').css('display', 'none');
        }

        clearTimeout(timer);

        if (keyword.length < 2) {
            $('.header-search-result--first').removeClass('active').innerHTML = '';
            $('.c-spinner').removeClass('displayClass');
            return;
        }

        timer = setTimeout(function() {
            $('.c-spinner').addClass('displayClass');
            SAJ('search',{keyword: keyword},function (data){
                $('.c-spinner').removeClass('displayClass');
                if (data.success) {
                    $('.header-search-result--first').html(data.data.html);
                    $('.header-search-result--first').addClass('show');
                }
            })
        }, 400);

    });


    $(document).on('click','.search-field__remove,.header-search-result__products a,.header-search-result__list-item a', function(e) {
        e.preventDefault();
        clearTimeout(timer);

        $(".search-field").value = "";
        $('.header-search-result--first').innerHTML = '';
        document.querySelector('.header-search-result--first')?.classList.remove('active');
        $('.c-spinner').removeClass('displayClass');
        document.querySelector('.header-search-result--first')?.classList.toggle('show');
        $('.search-field__remove').css('display', 'none');
        $(".search-field").focus();
        if (body.classList.contains('show-responsive-menu')) {
            body.classList.remove('show-responsive-menu')
        }
    });
    $(document).on('click', '.Button-rt19', function (e) {
        e.preventDefault();
        e.stopPropagation()
        countdown = 120;
        var data = extractDataFromInputsAndTextarea();
        SAJ('login-otp', data,function (res){
            if(res.status) {
                uikit__collections_success("ارسال شد");
            }else{
                uikit__collections_error(res.message);
            }
        });
        $('.d-flex.mt-5.jc-center').html("<div class=\"d-flex text-body-2 color-text-high-emphasis pNnwhoGegGWZnsiA5MNB\"> <div class=\"HRmXflgj_cRoqQlYQ4AI\"> <div class=\"text-body2-strong color-brand-primary-700 SKjYxAE5y1LPRcDIO0Ax\"> <span id=\"timer\">02:00</span> </div> </div> مانده تا دریافت مجدد </div>");
        clearInterval(intervalId);
        startCountdown();
        return false;
    });
    $(document).on('click', '.Button-rta20', function (e) {
        e.preventDefault();
        e.stopPropagation()
        countdown = 120;
        var data = extractDataFromInputsAndTextarea();
        SAJ('login-otp-audio', data,function (res){
            if(res.status) {
                uikit__collections_success("ارسال شد");
            }else{
                uikit__collections_error(res.message);
            }
        });
        $('.d-flex.mt-5.jc-center').html("<div class=\"d-flex text-body-2 color-text-high-emphasis pNnwhoGegGWZnsiA5MNB\"> <div class=\"HRmXflgj_cRoqQlYQ4AI\"> <div class=\"text-body2-strong color-brand-primary-700 SKjYxAE5y1LPRcDIO0Ax\"> <span id=\"timer\">02:00</span> </div> </div> مانده تا دریافت مجدد </div>");
        clearInterval(intervalId);
        startCountdown();
        return false;
    });
    $(document).on('click', '.Buton-df96', function (e) {
        e.preventDefault();

        const $wrapper = $(this).closest('.overflow-hidden');
        const $ul = $wrapper.find('ul');

        $(this).closest('.pointer-events-none').remove();

        $wrapper.css('height', 'auto');
        $ul.addClass('flex-wrap');
        $ul.append(`
        <li class="p-2 ui-close-btn">
            <button type="button" class="btn group px-8 border border-light bg-light hover:bg-primary hover:border-transparent hover:bg-opacity-15 block rounded-sm text-2xs leading-1 pt-8">
                <span class="text-dark opacity-75 group-hover:opacity-100 group-hover:text-primary-dark transition-all">بستن</span>
            </button>
        </li>
    `);
    });
    $(document).on('click', '.ui-close-btn button', function (e) {
        e.preventDefault();

        const $ul = $(this).closest('ul');
        const $wrapper = $ul.closest('.relative');

        // حذف flex-wrap
        $ul.removeClass('flex-wrap');

        // حذف دکمه بستن
        $(this).closest('.ui-close-btn').remove();

        // بازگرداندن حالت اولیه wrapper
        $wrapper
            .css('height', '29px')
            .append(`
            <div class="bg-gradient-to-r from-white from-50% pr-60 absolute left-0 top-0 pointer-events-none">
                <button type="button" class="btn group px-8 border border-light bg-light hover:bg-primary hover:border-transparent hover:bg-opacity-15 block rounded-sm text-2xs leading-1 pt-8 pb-6 pointer-events-auto Buton-df96">
                    <span class="text-dark opacity-75 group-hover:opacity-100 group-hover:text-primary-dark transition-all">بیشتر...</span>
                </button>
            </div>
        `);
    });

    $(document).on('click', '.Button-au46', function (e) {
        e.preventDefault();
        const button = $(this);
        const body_element = document.querySelector(".js-layout-main-content");
        button.className = "relative d-flex ai-center user-select-none uikit-atomic-ButtonBase-ButtonBase-module__btn--vgnTU text-button-1 uikit-atomic-ButtonBase-ButtonBase-module__btn--large--z9tJZ uikit-atomic-ButtonBase-ButtonBase-module__btn--primary--BJ1BU radius uikit-atomic-Button-Button-module__Button__large--eW66c uikit-atomic-Button-Button-module__Button__filledPrimary--isBw3 w-100 uikit-atomic-Button-Button-module__Button--TibOa";
        button.html("<div class=\"d-flex ai-center jc-center relative grow-1\"><div class=\"uikit-atomic-Button-Button-module__Loading--jNJ_Z\" data-testid=\"button-loading\"><div></div></div></div>")
        var form = document.querySelector('.d-flex.flex-column.flex-1');
        var formData = new FormData(form);
        var dataObj = {};
        formData.forEach(function(value, key) {
            dataObj[key] = value.trim();
        });
        const load = document.createElement("div");
        load.className = 'lottie-check';
        load.innerHTML = `<div class="lottie-container" data-lottie-url="${wpApiSettingsGiftMax.directory}/assets/img/wsl/load.json"></div>`;
        document.body.append(load);
        const lottieContainers = document.querySelectorAll('.lottie-container');

        lottieContainers.forEach(container => {
            const animationPath = container.getAttribute('data-lottie-url');

            if (animationPath) {
                lottie.loadAnimation({
                    container: container, // المانی که انیمیشن در آن قرار می‌گیرد
                    renderer: 'svg',       // نوع رندر (svg بهترین گزینه است)
                    loop: true,            // تکرار انیمیشن
                    autoplay: true,        // اجرای خودکار
                    path: animationPath    // آدرس فایل JSON آپلود شده
                });
                container.setAttribute('data-lottie-url', '');
            }

        });
        SAJ('register',dataObj,function (data) {
            button.html("<div class=\"d-flex ai-center jc-center relative grow-1\">تایید</div>");
            if (data.status == false){
                setTimeout(function (){
                    document.querySelector(".lottie-check").remove();
                    uikit__collections_error(data.message);
                    setTimeout(function (){
                        if (data.Isreload){
                            window.location.reload();
                        }
                    },800)
                },1500);
            }else {
                setTimeout(function (){
                    document.querySelector(".lottie-check").innerHTML = `<div class="lottie-container" style="padding: 13px" data-lottie-url="${wpApiSettingsGiftMax.directory}/assets/img/wsl/check.json"></div>`;
                    const lottieContainers = document.querySelectorAll('.lottie-container');
                    lottieContainers.forEach(container => {
                        const animationPath = container.getAttribute('data-lottie-url');

                        if (animationPath) {
                            lottie.loadAnimation({
                                container: container, // المانی که انیمیشن در آن قرار می‌گیرد
                                renderer: 'svg',       // نوع رندر (svg بهترین گزینه است)
                                loop: true,            // تکرار انیمیشن
                                autoplay: true,        // اجرای خودکار
                                path: animationPath    // آدرس فایل JSON آپلود شده
                            });
                            container.setAttribute('data-lottie-url', '');
                        }

                    });
                    setTimeout(function (){
                        uikit__collections_success("ثبت نام شما با موفقیت تکمیل شد.");
                        document.querySelector(".lottie-check").remove();
                        const body_element = document.querySelector(".js-layout-main-content");
                        body_element.innerHTML = (data.html);
                    },5000)
                },3000)
            }
        });
    })
    $(document).on('click', '.Button-sp21', function (e) {
        e.preventDefault();
        var password = $("input[name=\"password\"]").val();
        if(password.length <=7){
            uikit__collections_error("تعداد کارکتر های ورودی کمتر از حد مجاز هستند")
            return false;
        }
        const button = $(this);
        const body_element = document.querySelector(".js-layout-main-content");
        button.className = "relative d-flex ai-center user-select-none uikit-atomic-ButtonBase-ButtonBase-module__btn--vgnTU text-button-1 uikit-atomic-ButtonBase-ButtonBase-module__btn--large--z9tJZ uikit-atomic-ButtonBase-ButtonBase-module__btn--primary--BJ1BU radius uikit-atomic-Button-Button-module__Button__large--eW66c uikit-atomic-Button-Button-module__Button__filledPrimary--isBw3 w-100 uikit-atomic-Button-Button-module__Button--TibOa";
        button.html("<div class=\"d-flex ai-center jc-center relative grow-1\"><div class=\"uikit-atomic-Button-Button-module__Loading--jNJ_Z\" data-testid=\"button-loading\"><div></div></div></div>")
        var form = document.querySelector('.d-flex.flex-column.flex-1');
        var formData = new FormData(form);
        var dataObj = {};
        formData.forEach(function(value, key) {
            dataObj[key] = value;
        });
        const passwordLottie = document.createElement("div");
        passwordLottie.className = 'lottie-check';
        passwordLottie.innerHTML = `<div class="lottie-container" data-lottie-url="${wpApiSettingsGiftMax.directory}/assets/img/wsl/password.json"></div>`;
        document.body.append(passwordLottie);
        const lottieContainers = document.querySelectorAll('.lottie-container');

        lottieContainers.forEach(container => {
            const animationPath = container.getAttribute('data-lottie-url');

            if (animationPath) {
                lottie.loadAnimation({
                    container: container, // المانی که انیمیشن در آن قرار می‌گیرد
                    renderer: 'svg',       // نوع رندر (svg بهترین گزینه است)
                    loop: true,            // تکرار انیمیشن
                    autoplay: true,        // اجرای خودکار
                    path: animationPath    // آدرس فایل JSON آپلود شده
                });
                container.setAttribute('data-lottie-url', '');
            }

        });
        SAJ('setPassword',dataObj,function (data) {
            setTimeout(function (){
                document.querySelector(".lottie-check").remove();
                button.html("<div class=\"d-flex ai-center jc-center relative grow-1\">تایید</div>");
                if (!data.status){
                    uikit__collections_error(data.message);
                    setTimeout(function (){
                        if (data.Isreload){
                            window.location.reload();
                        }
                    },1000);
                }else {
                    if (data.url){
                        uikit__collections_success("رمز با موفقیت ثبت شده در حال تغییر مسیر...");
                        setTimeout(function (){
                            if (data.url) {
                                location.href = data.url;
                            }
                        },1000)
                    }
                }
            },5000)
        },'v1');
    })
    $(document).on('click', '.Button-lr54', function (e) {
        e.preventDefault();
        var number = $("input[name=\"userName\"]").val();
        if(number.length <=10){
            uikit__collections_error("تعداد کارکتر های ورودی کمتر از حد مجاز هستند")
            return false;
        }
        if(number.length >=12){
            uikit__collections_error("تعداد کارکتر های ورودی بیشتر از حد مجاز هستند")
            return false;
        }
        const body_element = document.querySelector(".js-layout-main-content");
        const button = $(this);
        button.className = "relative d-flex ai-center user-select-none uikit-atomic-ButtonBase-ButtonBase-module__btn--vgnTU text-button-1 uikit-atomic-ButtonBase-ButtonBase-module__btn--large--z9tJZ uikit-atomic-ButtonBase-ButtonBase-module__btn--primary--BJ1BU radius uikit-atomic-Button-Button-module__Button__large--eW66c uikit-atomic-Button-Button-module__Button__filledPrimary--isBw3 w-100 uikit-atomic-Button-Button-module__Button--TibOa";
        button.html("<div class=\"d-flex ai-center jc-center relative grow-1\"><div class=\"uikit-atomic-Button-Button-module__Loading--jNJ_Z\" data-testid=\"button-loading\"><div></div></div></div>")
        var form = document.querySelector('.d-flex.flex-column.flex-1');
        var formData = new FormData(form);
        fetch(`${wpApiSettingsGiftMax.root}api/v1/login`, {
            method: 'POST',
            body: formData,

        })
            .then(response => response.json())
            .then(data => {
                button.html("<div class=\"d-flex ai-center jc-center relative grow-1\">تایید</div>");
                if(data.url){
                    location.href = data.url;
                }
                body_element.innerHTML = (data.html);
                var countdown = 120;
                function startCountdown() {
                    intervalId = setInterval(function() {
                        countdown--;
                        var minutes = Math.floor(countdown / 60);
                        var seconds = countdown % 60;


                        if (document.getElementById('timer')) {
                            document.getElementById('timer').textContent = (minutes < 10 ? '0' : '') + minutes + ':' + (seconds < 10 ? '0' : '') + seconds;
                        } else {
                            clearInterval(intervalId);
                            console.log('Timer tag not found. Stopping countdown.');
                            return;
                        }
                        if (countdown === 0) {
                            clearInterval(intervalId);
                            var buttonAudio = '';
                            if ($(".W3wYIMoFtWvsJZI8nfye").data('otp')){
                                buttonAudio = `<button type="button" class="relative d-flex ai-center user-select-none uikit-atomic-ButtonBase-ButtonBase-module__btn--vgnTU text-button-2 uikit-atomic-ButtonBase-ButtonBase-module__btn--text--lIZMT uikit-atomic-ButtonBase-ButtonBase-module__btn--primary--BJ1BU radius uikit-atomic-Button-Button-module__Button__medium--lj91O uikit-atomic-Button-Button-module__Button__textPrimary--65Ubg H5b50Hekz31U6Dqz5lES uikit-atomic-Button-Button-module__Button--TibOa Button-rta20" data-testid="button-wrapper"><div class="d-flex ai-center jc-center relative grow-1">دریافت کد صوتی</div></button>`;
                            }
                            $('.d-flex.mt-5.jc-center').html(`<button type=\"button\" class=\"relative d-flex ai-center user-select-none uikit-atomic-ButtonBase-ButtonBase-module__btn--vgnTU text-button-2 uikit-atomic-ButtonBase-ButtonBase-module__btn--text--lIZMT uikit-atomic-ButtonBase-ButtonBase-module__btn--primary--BJ1BU radius uikit-atomic-Button-Button-module__Button__medium--lj91O uikit-atomic-Button-Button-module__Button__textPrimary--65Ubg H5b50Hekz31U6Dqz5lES uikit-atomic-Button-Button-module__Button--TibOa Button-rt19\" data-testid=\"button-wrapper\"><div class=\"d-flex ai-center jc-center relative grow-1\">دریافت مجدد رمز یک&zwnj;بار مصرف </div></button>${buttonAudio}`);
                        }
                    }, 1000);
                }
                startCountdown();

            });
    });
    $(document).on('click', '.Button-cp41', function (e) {
        e.preventDefault();
        var number = $("input[name=\"userName\"]").val();
        var PassWord = $("input[name=\"PassWord\"]").val();
        if(number.length <=10){
            window.location.reload();
            return false;
        }
        if (PassWord.length <= 7){
            uikit__collections_error("تعداد کارکتر های رمز کمتر از حداقل کمتر است!");
        }
        const body_element = document.querySelector(".js-layout-main-content");
        const button = $(this);
        button.className = "relative d-flex ai-center user-select-none uikit-atomic-ButtonBase-ButtonBase-module__btn--vgnTU text-button-1 uikit-atomic-ButtonBase-ButtonBase-module__btn--large--z9tJZ uikit-atomic-ButtonBase-ButtonBase-module__btn--primary--BJ1BU radius uikit-atomic-Button-Button-module__Button__large--eW66c uikit-atomic-Button-Button-module__Button__filledPrimary--isBw3 w-100 uikit-atomic-Button-Button-module__Button--TibOa";
        button.html("<div class=\"d-flex ai-center jc-center relative grow-1\"><div class=\"uikit-atomic-Button-Button-module__Loading--jNJ_Z\" data-testid=\"button-loading\"><div></div></div></div>")
        SAJ('pass',{userName:number,PassWord:PassWord},function (res){
            button.html("<div class=\"d-flex ai-center jc-center relative grow-1\">تایید</div>");
            if (res.status) {
                if (res.url) {
                    uikit__collections_success("شما با موفقیت ثبت نام شدید");
                    location.href = res.url;
                }
                body_element.innerHTML = (data.html);
            }else{
                uikit__collections_error("رمز عبور اشتباه هست");
            }
        },'v1');
    });
    $(document).on('click', '.Button-cfl19', function (e) {
        e.preventDefault();
        const button = $(this);
        var number = $("input[name=\"userName\"]").val();
        if(number.length <=10){
            window.location.reload();
            return false;
        }
        const body_element = document.querySelector(".js-layout-main-content");
        button.className = "relative d-flex ai-center user-select-none uikit-atomic-ButtonBase-ButtonBase-module__btn--vgnTU text-button-1 uikit-atomic-ButtonBase-ButtonBase-module__btn--large--z9tJZ uikit-atomic-ButtonBase-ButtonBase-module__btn--primary--BJ1BU radius uikit-atomic-Button-Button-module__Button__large--eW66c uikit-atomic-Button-Button-module__Button__filledPrimary--isBw3 w-100 uikit-atomic-Button-Button-module__Button--TibOa";
        button.html("<div class=\"d-flex ai-center jc-center relative grow-1\"><div class=\"uikit-atomic-Button-Button-module__Loading--jNJ_Z\" data-testid=\"button-loading\"><div style='border-color: #000 transparent'></div></div></div>")
        SAJ('lotp',{userName:number},function (data){
            button.html("<div class=\"d-flex ai-center jc-center relative grow-1\">تایید</div>");
            body_element.innerHTML = (data.html);
            var countdown = 120;
            function startCountdown() {
                intervalId = setInterval(function() {
                    countdown--;
                    var minutes = Math.floor(countdown / 60);
                    var seconds = countdown % 60;


                    if (document.getElementById('timer')) {
                        document.getElementById('timer').textContent = (minutes < 10 ? '0' : '') + minutes + ':' + (seconds < 10 ? '0' : '') + seconds;
                    } else {
                        clearInterval(intervalId);
                        console.log('Timer tag not found. Stopping countdown.');
                        return;
                    }
                    if (countdown === 0) {
                        clearInterval(intervalId);
                        var buttonAudio = '';
                        if ($(".W3wYIMoFtWvsJZI8nfye").data('otp')){
                            buttonAudio = `<button type="button" class="relative d-flex ai-center user-select-none uikit-atomic-ButtonBase-ButtonBase-module__btn--vgnTU text-button-2 uikit-atomic-ButtonBase-ButtonBase-module__btn--text--lIZMT uikit-atomic-ButtonBase-ButtonBase-module__btn--primary--BJ1BU radius uikit-atomic-Button-Button-module__Button__medium--lj91O uikit-atomic-Button-Button-module__Button__textPrimary--65Ubg H5b50Hekz31U6Dqz5lES uikit-atomic-Button-Button-module__Button--TibOa Button-rta20" data-testid="button-wrapper"><div class="d-flex ai-center jc-center relative grow-1">دریافت کد صوتی</div></button>`;
                        }
                        $('.d-flex.mt-5.jc-center').html(`<button type=\"button\" class=\"relative d-flex ai-center user-select-none uikit-atomic-ButtonBase-ButtonBase-module__btn--vgnTU text-button-2 uikit-atomic-ButtonBase-ButtonBase-module__btn--text--lIZMT uikit-atomic-ButtonBase-ButtonBase-module__btn--primary--BJ1BU radius uikit-atomic-Button-Button-module__Button__medium--lj91O uikit-atomic-Button-Button-module__Button__textPrimary--65Ubg H5b50Hekz31U6Dqz5lES uikit-atomic-Button-Button-module__Button--TibOa Button-rt19\" data-testid=\"button-wrapper\"><div class=\"d-flex ai-center jc-center relative grow-1\">دریافت مجدد رمز یک&zwnj;بار مصرف </div></button>${buttonAudio}`);
                    }
                }, 1000);
            }
            startCountdown();
            if ('OTPCredential' in window) {
                const controller = new AbortController();
                navigator.credentials.get({
                    otp: {
                        transport: ['sms']
                    },
                    signal: controller.signal
                })
                    .then(otp => {
                        const input = document.querySelector('._input_87tyg_11');
                        if (input) {
                            input.value = otp.code;
                            input.dispatchEvent(new Event('input', {
                                bubbles: true
                            }));
                            input.dispatchEvent(new Event('change', {
                                bubbles: true
                            }));
                        }
                    })
                    .catch(err => {
                        console.log(err);
                    });
            }
        });
    });
    function detectBankImageBg2(cardNumber,v) {
        cardNumber = cardNumber.replace(/\D/g, '');
        if (cardNumber.length < 6) return false;

        const bin = cardNumber.substring(0, 6);

        const banks = {
            '603799': {img:`/assets/banks/bg/bmi/${v}.svg`,color:null,positionText:'86',Box:{x:8,y:116,color:"#000"}},
            '589210': {img:`/assets/banks/bg/sph/${v}.svg`,color:null,positionText:'60',Box:{x:6,y:95,color:"#000"}},
            '207177': {img:`/assets/banks/bg/all/${v}.svg`,color:null,positionText:'83',Box:{x:6,y:122,color:"#000"}},
            '627648': {img:`/assets/banks/bg/all/${v}.svg`,color:null,positionText:'83',Box:{x:6,y:122,color:"#000"}},
            '627961': {img:`/assets/banks/bg/all/${v}.svg`,color:null,positionText:'83',Box:{x:6,y:122,color:"#000"}},
            '603770': {img:`/assets/banks/bg/bki/${v}.svg`,color:null,positionText:'80',Box:{x:6,y:117,color:"#000"}},
            '639217': {img:`/assets/banks/bg/bki/${v}.svg`,color:null,positionText:'80',Box:{x:6,y:117,color:"#000"}},
            '628023': {img:`/assets/banks/bg/msk/${v}.svg`,color:null,positionText:'89',Box:{x:8,y:130,color:"#000"}},
            '627760': {img:`/assets/banks/bg/pst/${v}.svg`,color:null,positionText:'87',Box:{x:5,y:121,color:"#000"}},
            '502908': {img:`/assets/banks/bg/all/${v}.svg`,color:null,positionText:'83',Box:{x:6,y:123,color:"#000"}},
            '603769': {img:`/assets/banks/bg/bsi/${v}.svg`,color:null,positionText:'84',Box:{x:6,y:124,color:"#000"}},
            '610433': {img:`/assets/banks/bg/mlt/${v}.svg`,color:"#FFF",positionText:'85',Box:{x:9,y:128,color:"#FFF"}},
            '991975': {img:`/assets/banks/bg/mlt/${v}.svg`,color:"#FFF",positionText:'85',Box:{x:9,y:128,color:"#FFF"}},
            '589463': {img:`/assets/banks/bg/rfh/${v}.svg`,color:null,positionText:'65',Box:{x:6,y:101,color:"#000"}},
            '627353': {img:`/assets/banks/bg/all/${v}.svg`,color:null,positionText:'83',Box:{x:6,y:122,color:"#000"}},
            '585983': {img:`/assets/banks/bg/all/${v}.svg`,color:null,positionText:'83',Box:{x:6,y:122,color:"#000"}},

            // بانک‌های خصوصی
            '627412': {img:`/assets/banks/bg/enb/${v}.svg`,color:"#FFF",positionText:'79',Box:{x:9,y:129,color:"#FFF"}},
            '622106': {img:`/assets/banks/bg/prs/${v}.svg`,color:null,positionText:'92',Box:{x:9,y:130,color:"#000"}},
            '639194': {img:`/assets/banks/bg/prs/${v}.svg`,color:null,positionText:'92',Box:{x:9,y:130,color:"#000"}},
            '627884': {img:`/assets/banks/bg/prs/${v}.svg`,color:null,positionText:'92',Box:{x:9,y:130,color:"#000"}},
            '502229': {img:`/assets/banks/bg/bpi/${v}.svg`,color:"#FFF",positionText:'65',Box:{x:9,y:113,color:"#FFF"}},
            '639347': {img:`/assets/banks/bg/bpi/${v}.svg`,color:"#FFF",positionText:'65',Box:{x:9,y:113,color:"#FFF"}},
            '627488': {img:`/assets/banks/bg/kar/${v}.svg`,color:"#FFF",positionText:'65',Box:{x:9,y:113,color:"#FFF"}},
            '502910': {img:`/assets/banks/bg/kar/${v}.svg`,color:"#FFF",positionText:'65',Box:{x:9,y:113,color:"#FFF"}},
            '621986': {img:`/assets/banks/bg/sb24/${v}.svg`,color:null,positionText:'65',Box:{x:9,y:128,color:"#000"}},
            '639346': {img:`/assets/banks/bg/sina/${v}.svg`,color:null,positionText:'72',Box:{x:8,y:126,color:"#000"}},
            '639607': {img:`/assets/banks/bg/sbn/${v}.svg`,color:null,positionText:'77',Box:{x:6,y:126,color:"#000"}},
            '636214': {img:`/assets/banks/bg/all/${v}.svg`,color:null,positionText:'83',Box:{x:6,y:122,color:"#000"}},
            '504706': {img:`/assets/banks/bg/shahr/${v}.svg`,color:null,positionText:'63',Box:{x:6,y:104,color:"#000"}},
            '502806': {img:`/assets/banks/bg/shahr/${v}.svg`,color:null,positionText:'63',Box:{x:6,y:104,color:"#000"}},
            '502938': {img:`/assets/banks/bg/day/${v}.svg`,color:null,positionText:'75',Box:{x:6,y:122,color:"#000"}},
            '639599': {img:`/assets/banks/bg/sph/${v}.svg`,color:null,positionText:'60',Box:{x:6,y:95,color:"#000"}},
            '636949': {img:`/assets/banks/bg/sph/${v}.svg`,color:null,positionText:'60',Box:{x:6,y:95,color:"#000"}},
            '505416': {img:`/assets/banks/bg/tour/${v}.svg`,color:null,positionText:'54',Box:{x:9,y:117,color:"#fff"}},
            '585947': {img:`/assets/banks/bg/kme/${v}.svg`,color:null,positionText:'73',Box:{x:7,y:122,color:"#000"}},

            '627381': {img:`/assets/banks/bg/sph/${v}.svg`,color:null,positionText:'60',Box:{x:6,y:95,color:"#000"}},
            '505785': {img:`/assets/banks/bg/izb/${v}.svg`,color:null,positionText:'70',Box:{x:6,y:117,color:"#000"}},
            '636795': {img:`/assets/banks/bg/all/${v}.svg`,color:null,positionText:'83',Box:{x:6,y:122,color:"#000"}},
            '606373': {img:`/assets/banks/bg/qmb/${v}.svg`,color:null,positionText:'70',Box:{x:6,y:122,color:"#000"}},
            '504172': {img:`/assets/banks/bg/rqb/${v}.svg`,color:null,positionText:'70',Box:{x:6,y:119,color:"#000"}},
            '505801': {img:`/assets/banks/bg/sph/${v}.svg`,color:null,positionText:'60',Box:{x:6,y:95,color:"#000"}},
            '639370': {img:`/assets/banks/bg/sph/${v}.svg`,color:null,positionText:'60',Box:{x:6,y:95,color:"#000"}},
            '606256': {img:`/assets/banks/bg/all/${v}.svg`,color:null,positionText:'83',Box:{x:6,y:122,color:"#000"}},
            '507677': {img:`/assets/banks/bg/all/${v}.svg`,color:null,positionText:'83',Box:{x:6,y:122,color:"#000"}},
            '581874': {img:`/assets/banks/bg/all/${v}.svg`,color:null,positionText:'83',Box:{x:6,y:122,color:"#000"}},
        };

        return banks[bin] || false;
    }

    $(document).on('input','._wrap_87tyg_1._input_pjp0p_66 ._input_87tyg_11', function (e) {
        const otpWrap = document.querySelector('._wrap_87tyg_1._input_pjp0p_66');
        if (!otpWrap) return;

        const hiddenInput = otpWrap.querySelector('input._input_87tyg_11');
        if (otpWrap.classList.contains('_error_87tyg_52')) {
            hiddenInput.value ='';
            updateDisplay();

        }else{
            hiddenInput.value = e.target.value.replace(/\D/g, '').slice(0, 6);
        }
        otpWrap.classList.remove('_error_87tyg_52');
        if (hiddenInput.value.length === 6) {
            e.preventDefault();
            const method = $(this).data('method');
            const wrapper = document.querySelector('._wrap_87tyg_1');
            if (!document.querySelector('.tick-icon')) {
                const tick = document.createElement('div');
                tick.className = 'tick-icon';
                wrapper.appendChild(tick);
            }
            wrapper.classList.add('is-complete');
            hiddenInput.disabled = true;

            if(method === 'login') {
                const body_element = document.querySelector(".js-layout-main-content");
                var form = document.querySelector('.d-flex.flex-column.flex-1');
                var formData = new FormData(form);
                var dataObj = {};
                formData.forEach(function(value, key) {
                    dataObj[key] = value;
                });
                dataObj["otp"] = hiddenInput.value;
                SAJ('otp', dataObj, function (data) {
                    hiddenInput.disabled = false;
                    if (data.status == false) {
                        wrapper.classList.remove('is-complete');
                        otpWrap.classList.add('_error_87tyg_52');
                        uikit__collections_error(data.message);
                    } else {
                        setTimeout(() => {
                            wrapper.classList.add('is-verifying');
                            setTimeout(function () {
                                if (data.url) {
                                    location.href = data.url;
                                }
                                if (data.html) {
                                    body_element.innerHTML = data.html;
                                }
                                $('.js-example-basic-single').select2({
                                    width: 'resolve',
                                    dir: 'rtl'
                                });

                                const input = document.querySelector('input[name="CardNumber"]');
                                let lastBankImage = null;
                                input.addEventListener('input', function (e) {
                                    let value = this.value.replace(/\D/g, '').substring(0, 16);
                                    const newImage = detectBankImageBg2(value,'v1');
                                    const Box = document.querySelector(".bV40_bank");
                                    if (newImage) {
                                        $(".bV40_bank .numberCard").html(this.value);
                                        $(".bV40_bank").animate({
                                            height: "248px"
                                        }, 100, function () {
                                            setTimeout(function (){
                                                $(".bV40_bank").css("height", "auto");
                                            },1000)
                                        });
                                        const newSrc = wpApiSettingsGiftMax.directory + newImage.img;
                                        if (!lastBankImage) {
                                            if(newImage.color != null) {
                                                $(".bV40_bank .numberCard").css({
                                                    color: newImage.color,
                                                    bottom: (parseFloat(newImage.positionText)) + "px"
                                                });
                                            }else{
                                                $(".bV40_bank .numberCard").css({
                                                    color:"#241a06",
                                                    bottom: (parseFloat(newImage.positionText)) + "px"
                                                });
                                            }
                                            $(".bV40_bank .number-user,.bV40_bank .birthday-user,.bV40_bank .national__code-user").css({
                                                color: newImage.Box.color,
                                                bottom: (parseFloat(newImage.Box.y)) + "px"
                                            });
                                            $(".bV40_bank .full__name-user").css({
                                                color: newImage.Box.color,
                                                right: newImage.Box.x + "%",
                                                bottom: (parseFloat(newImage.Box.y)) + "px"
                                            });
                                            const img = document.createElement("img");
                                            img.src = newSrc;
                                            img.className = "transition-opacity-0.2 animation-out"
                                            Box.appendChild(img);
                                            lastBankImage = newSrc;
                                            setTimeout(function () {
                                                img.classList.remove("animation-out");
                                                img.classList.add("animation-in");
                                            },1);
                                            setTimeout(function (){
                                                img.className = '';
                                            },210)
                                        }
                                        else if (lastBankImage !== newSrc) {
                                            const img = Box.querySelector("img");
                                            if(newImage.color != null) {
                                                $(".bV40_bank .numberCard").css({
                                                    color: newImage.color,
                                                    bottom: newImage.positionText + "px"
                                                });
                                            }else{
                                                $(".bV40_bank .numberCard").css({
                                                color:"#241a06",
                                                    bottom: newImage.positionText + "px"
                                                });
                                            }
                                            $(".bV40_bank .number-user,.bV40_bank .birthday-user,.bV40_bank .national__code-user").css({
                                                color: newImage.Box.color,
                                                bottom: (parseFloat(newImage.Box.y)) + "px"
                                            });
                                            $(".bV40_bank .full__name-user").css({
                                                color: newImage.Box.color,
                                                right: newImage.Box.x + "%",
                                                bottom: (parseFloat(newImage.Box.y)) + "px"
                                            });
                                            if (img) {
                                                img.src = newSrc; // smooth replace بدون flicker
                                            } else {
                                                const img = document.createElement("img");
                                                img.src = newSrc;
                                                Box.appendChild(img);
                                            }

                                            lastBankImage = newSrc;
                                        }
                                    }
                                    else {
                                        if (Box.querySelector("img")) {
                                            const img = Box.querySelector("img");
                                            img.classList.add("transition-opacity-0.2");
                                            img.classList.add("animation-out");
                                            setTimeout(function (){
                                                img.remove();
                                            },210)
                                        }
                                        if (!document.querySelector('.bV40_bank').classList.contains("normal")) {
                                            $(".bV40_bank").animate({
                                                height: "0px"
                                            }, 300);
                                        }
                                        lastBankImage = null;
                                    }
                                    let formatted = value.match(/.{1,4}/g);
                                    formatted = formatted ? formatted.join('-') : '';

                                    const cursorPosition = this.selectionStart;
                                    const oldLength = this.value.length;

                                    this.value = formatted;

                                    const newLength = formatted.length;
                                    const diff = newLength - oldLength;

                                    this.setSelectionRange(
                                        cursorPosition + diff,
                                        cursorPosition + diff
                                    );
                                });
                            }, 500);
                        }, 1000);
                    }
                });
            }
            else if(method === 'verify_card') {
                const body_element = document.querySelector(".js-layout-main-content");
                var form = document.querySelector('.d-flex.flex-column.flex-1');
                var formData = new FormData(form);
                var dataObj = {};
                formData.forEach(function(value, key) {
                    dataObj[key] = value;
                });
                dataObj["otp"] = hiddenInput.value;
                SAJ('card-otp', dataObj, function (data) {
                    hiddenInput.disabled = false;
                    if (data.status == false) {
                        wrapper.classList.remove('is-complete');
                        otpWrap.classList.add('_error_87tyg_52');
                        uikit__collections_error(data.message);
                        setTimeout(function () {
                            if (data.Isreload) {
                                window.location.reload();
                            }
                        }, 800)
                    } else {
                        setTimeout(() => {
                            wrapper.classList.add('is-verifying');
                            setTimeout(function () {
                                if (data.url) {
                                    location.href = data.url;
                                }
                                if (data.html) {
                                    body_element.innerHTML = data.html;
                                }
                            }, 1000);
                        }, 1500);
                    }
                });
            }
            else if(method === 'cart'){
                var otp = $("._input_87tyg_11").val();
                var drg = $("input[name='drg']").val();
                if (otp.length ==0 ){
                    uikit__collections_error("کد را هنوز وارد نکرده اید");
                    return false;
                }
                if (drg.length<=0){
                    uikit__collections_error("فرم اعتبار ندارد");
                    closePup($("._input_87tyg_11"));
                    return ;
                }

                SAJ('verifyCard',{drg:drg,otp:otp},function (res){
                    hiddenInput.disabled = false;
                    if (res.status) {
                        setTimeout(() => {
                            wrapper.classList.add('is-verifying');
                            setTimeout(function () {
                                setProgress(100);
                                setTimeout(function (){
                                    uikit__collections_success("شماره تلفن تایید شد،وکارت به لیست کارت های شما اضافه شد");
                                    const container = document.querySelector(".toast-container");
                                    const div = document.createElement("div");
                                    div.className = "toast-item-wrapper toast-animation-v2-enter-done";
                                    const textAlarm = `کارت با موفقیت اضافه شد. چون این کارت متعلق به شما نیست، برای هر پرداخت نیاز به تأیید کارت با کد OTP خواهید داشت. <br> <span style="font-weight: bold;">کاربران ویژه از این قانون مستثنی هستند</span>`;
                                    div.innerHTML = `<div class="sc-4324465a-0 JioWZ toast-item successful" role="alert" aria-atomic="true"><div class="icon-wrapper"><svg class="icon" viewBox="0 0 24 25" width="1em" height="1em" focusable="false" aria-hidden="true" style="width: 1em; height: 1em;"><path d="M12 3C10.07 3 8.19 3.57 6.58 4.64S3.73 7.24 3 9.02s-.93 3.74-.55 5.63c.37 1.9 1.3 3.63 2.67 5C6.47 21 8.2 21.93 10.1 22.3s3.85.19 5.63-.55 3.3-1.99 4.38-3.6c1.07-1.6 1.64-3.48 1.64-5.41 0-2.59-1.03-5.06-2.86-6.9C17.06 4.04 14.6 3 12 3m0 18C10.37 21 8.77 20.52 7.42 19.61 6.06 18.71 5 17.41 4.38 15.91 3.75 14.4 3.59 12.74 3.9 11.14S5 8.07 6.17 6.92C7.32 5.76 8.79 4.98 10.39 4.66s3.26-.16 4.77.47c1.5.62 2.8 1.68 3.7 3.04.9 1.35 1.39 2.95 1.39 4.58 0 2.19-.87 4.28-2.42 5.83S14.2 21 12 21m1.5-3.75q0 .31-.22.53T12.75 18q-.62-.01-1.06-.44Q11.25 17.12 11.25 16.5v-3.75q-.31 0-.53-.22Q10.51 12.31 10.5 12q0-.31.22-.53.22-.21.53-.22.62.01 1.06.44.43.44.44 1.06v3.75q.31 0 .53.22.21.22.22.53m-3-8.62Q10.5 8.28 10.69 8t.5-.41q.33-.13.65-.07.34.07.58.31.25.25.3.58.07.32-.06.65-.12.31-.41.5-.29.18-.62.19-.47 0-.8-.33Q10.5 9.1 10.5 8.62"></path></svg></div><div class="toast-body"><span class="sc-2d9072c2-1 fbzXBE body-text toast-message"><span>${textAlarm}</span></span></div><div class="toast-actions"><button class="dVEnfZ close-button icon-button" type="button"><svg class="aparat-icon icon icon-close icon-start" viewBox="0 0 24 25" width="1em" height="1em" focusable="false" style="width: 1em; height: 1em;"><path d="M18.8 18.3q.09.1.15.23Q19 18.67 19 18.8q0 .14-.05.27-.06.12-.16.22t-.22.16T18.3 19.5t-.27-.05Q17.91 19.39 17.8 19.29L12 13.5l-5.8 5.8q-.21.2-.5.2T5.2 19.3 5 18.8t.2-.5l5.81-5.8L5.21 6.7Q5 6.49 5 6.2T5.2 5.7Q5.42 5.5 5.7 5.5t.5.2l5.8 5.81 5.8-5.8Q18.01 5.5 18.3 5.5t.5.2T19 6.2t-.2.5l-5.81 5.8z"></path></svg></button></div></div>`;
                                    container.appendChild(div);
                                    closePup($("._input_87tyg_11"));
                                    if (document.querySelector(".card-grid--swiper")) {
                                        const boxshopCart = document.querySelector(".card-grid--swiper");
                                        if (boxshopCart.querySelector(".flex.justify-center.align-items-center.px-\\[10px\\]")) {
                                            boxshopCart.querySelector(".flex.justify-center.align-items-center.px-\\[10px\\]").remove();
                                        }
                                        if(boxshopCart.querySelector(".bank-cards-swiper")){
                                            boxshopCart.querySelector(".bank-cards-swiper").remove();
                                        }
                                        const div = document.createElement('div');
                                        div.className = 'bank-cards-swiper';
                                        let box = '<div class="swiper-wrapper">';
                                        res.card.forEach(item=>{
                                            box += ` <div class="swiper-slide"><article class="bank-card">${item.htmlV2}${item.html}</article></div>`;
                                        });
                                        box += '</div>';
                                        div.innerHTML = box;
                                        boxshopCart.appendChild(div);
                                        document.querySelector(".profile-bpp").innerHTML = res.card.length;
                                        bankCardsSwiper();
                                        const lottieContainers = document.querySelectorAll('.lottie-container');
                                        lottieContainers.forEach(container => {
                                            const animationPath = container.getAttribute('data-lottie-url');

                                            if (animationPath) {
                                                lottie.loadAnimation({
                                                    container: container, // المانی که انیمیشن در آن قرار می‌گیرد
                                                    renderer: 'svg',       // نوع رندر (svg بهترین گزینه است)
                                                    loop: true,            // تکرار انیمیشن
                                                    autoplay: true,        // اجرای خودکار
                                                    path: animationPath    // آدرس فایل JSON آپلود شده
                                                });
                                                container.setAttribute('data-lottie-url', '');
                                            }

                                        });
                                    }
                                    if (document.querySelector(".bank-cards__account")) {
                                        const bankCard = document.querySelector(".bank-cards__account");
                                        if (document.querySelector(".bank-cards__account > div.flex")) {
                                            document.querySelector(".bank-cards__account > div.flex").remove();
                                        }
                                        if(bankCard.querySelector(".bank-cards__list")){
                                            bankCard.querySelector(".bank-cards__list").remove();
                                        }
                                        const div = document.createElement('div');
                                        div.className = 'bank-cards__list';
                                        let article = '';
                                        res.card.forEach(item=>{
                                            article += `<article class="bank-card__account"><div class="box">
                                    <div class="bank-card__top">
                                    <span class="bank-card__bank">${item.name}</span> </div>
                                    <h3 class="bank-card__number">${item.card_number}</h3>
                                    <div class="bank-card__meta">
                                                                        <span>دارنده کارت:  ${item.fullName}</span>
                                                                    </div>
                                </div>
                                ${item.html}</article>`;
                                        });
                                        div.innerHTML = article;
                                        bankCard.appendChild(div);
                                    }
                                },1000)
                            }, 500);
                        }, 1000);
                    }else{
                        if (res.closed){
                            closePup($("._input_87tyg_11"));
                        }
                        wrapper.classList.remove('is-complete');
                        otpWrap.classList.add('_error_87tyg_52');
                        uikit__collections_error(res.message);
                    }
                },'v2')
            }
            else if(method === 'order'){
                const modalContent = document.querySelector('.ModalComponent__content-XqD1rL');

                if (!modalContent) {
                    closePup($("._input_87tyg_11"));
                    uikit__collections_error("فرم معتبر نیست");
                    return ;
                }

                const inputs = modalContent.querySelectorAll('input[type="text"], input[type="hidden"],select.js-example-basic-single');
                const data = {};

                inputs.forEach(input => {
                    const name = input.getAttribute('name');
                    const value = input.value;
                    if (name) {
                        data[name] = value;
                    }
                });
                SAJ('verifyCard',{data},function (res){
                    hiddenInput.disabled = false;
                    setProgress(res.percent);
                    if (res.close){
                        closePup($("._input_87tyg_11"));
                    }
                    if (res.status) {
                        wrapper.classList.add('is-verifying');
                        uikit__collections_success("سفارش شما با موفقیت تأیید گردید. تا لحظاتی دیگر به صفحه سفارش هدایت خواهید شد. شکیبا باشید.")
                        const container = document.querySelector(".toast-container");
                        const div = document.createElement("div");
                        div.className = "toast-item-wrapper toast-animation-v2-enter-done";
                        const textAlarm = `برای راحتی خود به حساب ویژه ارتقا دهید <br> <span style="font-weight: bold;">کاربران ویژه نیازی به تایید کارت ندارن</span>`;
                        div.innerHTML = `<div class="sc-4324465a-0 JioWZ toast-item successful" role="alert" aria-atomic="true"><div class="icon-wrapper"><svg class="icon" viewBox="0 0 24 25" width="1em" height="1em" focusable="false" aria-hidden="true" style="width: 1em; height: 1em;"><path d="M12 3C10.07 3 8.19 3.57 6.58 4.64S3.73 7.24 3 9.02s-.93 3.74-.55 5.63c.37 1.9 1.3 3.63 2.67 5C6.47 21 8.2 21.93 10.1 22.3s3.85.19 5.63-.55 3.3-1.99 4.38-3.6c1.07-1.6 1.64-3.48 1.64-5.41 0-2.59-1.03-5.06-2.86-6.9C17.06 4.04 14.6 3 12 3m0 18C10.37 21 8.77 20.52 7.42 19.61 6.06 18.71 5 17.41 4.38 15.91 3.75 14.4 3.59 12.74 3.9 11.14S5 8.07 6.17 6.92C7.32 5.76 8.79 4.98 10.39 4.66s3.26-.16 4.77.47c1.5.62 2.8 1.68 3.7 3.04.9 1.35 1.39 2.95 1.39 4.58 0 2.19-.87 4.28-2.42 5.83S14.2 21 12 21m1.5-3.75q0 .31-.22.53T12.75 18q-.62-.01-1.06-.44Q11.25 17.12 11.25 16.5v-3.75q-.31 0-.53-.22Q10.51 12.31 10.5 12q0-.31.22-.53.22-.21.53-.22.62.01 1.06.44.43.44.44 1.06v3.75q.31 0 .53.22.21.22.22.53m-3-8.62Q10.5 8.28 10.69 8t.5-.41q.33-.13.65-.07.34.07.58.31.25.25.3.58.07.32-.06.65-.12.31-.41.5-.29.18-.62.19-.47 0-.8-.33Q10.5 9.1 10.5 8.62"></path></svg></div><div class="toast-body"><span class="sc-2d9072c2-1 fbzXBE body-text toast-message"><span>${textAlarm}</span></span></div><div class="toast-actions"><button class="dVEnfZ close-button icon-button" type="button"><svg class="aparat-icon icon icon-close icon-start" viewBox="0 0 24 25" width="1em" height="1em" focusable="false" style="width: 1em; height: 1em;"><path d="M18.8 18.3q.09.1.15.23Q19 18.67 19 18.8q0 .14-.05.27-.06.12-.16.22t-.22.16T18.3 19.5t-.27-.05Q17.91 19.39 17.8 19.29L12 13.5l-5.8 5.8q-.21.2-.5.2T5.2 19.3 5 18.8t.2-.5l5.81-5.8L5.21 6.7Q5 6.49 5 6.2T5.2 5.7Q5.42 5.5 5.7 5.5t.5.2l5.8 5.81 5.8-5.8Q18.01 5.5 18.3 5.5t.5.2T19 6.2t-.2.5l-5.81 5.8z"></path></svg></button></div></div>`;
                        container.appendChild(div);
                        setTimeout(() => {
                            setTimeout(function () {
                                if (res.url){
                                    setTimeout(function (){
                                        window.location.href = res.url;
                                    },1100);
                                }
                            }, 500);
                        }, 1000);
                    }else {
                        wrapper.classList.remove('is-complete');
                        otpWrap.classList.add('_error_87tyg_52');
                        uikit__collections_error(res.message);
                    }
                },'v2')
            }
            else if(method === 'cartOtp'){
                const modalContent = document.querySelector('.ModalComponent__content-XqD1rL');

                if (!modalContent) {
                    closePup($("._input_87tyg_11"));
                    uikit__collections_error("فرم معتبر نیست");
                    return ;
                }

                var otp = $("._input_87tyg_11").val();
                var hash = $("input[name='hash']").val();
                SAJ('verifyCard',{hash:hash,otp:otp},function (res){
                    hiddenInput.disabled = false;
                    setProgress(100);
                    if (res.close){
                        closePup($("._input_87tyg_11"));
                    }
                    if (res.status) {
                        wrapper.classList.add('is-verifying');
                        setTimeout(() => {
                            uikit__collections_success("کارت با موفقیت تایید شد.")
                            const container = document.querySelector(".toast-container");
                            const div = document.createElement("div");
                            div.className = "toast-item-wrapper toast-animation-v2-enter-done";
                            const textAlarm = `این تأیید فقط یک بار لازمه. از این به بعد راحت با کارتت خرید کن.`;
                            div.innerHTML = `<div class="sc-4324465a-0 JioWZ toast-item successful" role="alert" aria-atomic="true"><div class="icon-wrapper"><svg class="icon" viewBox="0 0 24 25" width="1em" height="1em" focusable="false" aria-hidden="true" style="width: 1em; height: 1em;"><path d="M12 3C10.07 3 8.19 3.57 6.58 4.64S3.73 7.24 3 9.02s-.93 3.74-.55 5.63c.37 1.9 1.3 3.63 2.67 5C6.47 21 8.2 21.93 10.1 22.3s3.85.19 5.63-.55 3.3-1.99 4.38-3.6c1.07-1.6 1.64-3.48 1.64-5.41 0-2.59-1.03-5.06-2.86-6.9C17.06 4.04 14.6 3 12 3m0 18C10.37 21 8.77 20.52 7.42 19.61 6.06 18.71 5 17.41 4.38 15.91 3.75 14.4 3.59 12.74 3.9 11.14S5 8.07 6.17 6.92C7.32 5.76 8.79 4.98 10.39 4.66s3.26-.16 4.77.47c1.5.62 2.8 1.68 3.7 3.04.9 1.35 1.39 2.95 1.39 4.58 0 2.19-.87 4.28-2.42 5.83S14.2 21 12 21m1.5-3.75q0 .31-.22.53T12.75 18q-.62-.01-1.06-.44Q11.25 17.12 11.25 16.5v-3.75q-.31 0-.53-.22Q10.51 12.31 10.5 12q0-.31.22-.53.22-.21.53-.22.62.01 1.06.44.43.44.44 1.06v3.75q.31 0 .53.22.21.22.22.53m-3-8.62Q10.5 8.28 10.69 8t.5-.41q.33-.13.65-.07.34.07.58.31.25.25.3.58.07.32-.06.65-.12.31-.41.5-.29.18-.62.19-.47 0-.8-.33Q10.5 9.1 10.5 8.62"></path></svg></div><div class="toast-body"><span class="sc-2d9072c2-1 fbzXBE body-text toast-message"><span>${textAlarm}</span></span></div><div class="toast-actions"><button class="dVEnfZ close-button icon-button" type="button"><svg class="aparat-icon icon icon-close icon-start" viewBox="0 0 24 25" width="1em" height="1em" focusable="false" style="width: 1em; height: 1em;"><path d="M18.8 18.3q.09.1.15.23Q19 18.67 19 18.8q0 .14-.05.27-.06.12-.16.22t-.22.16T18.3 19.5t-.27-.05Q17.91 19.39 17.8 19.29L12 13.5l-5.8 5.8q-.21.2-.5.2T5.2 19.3 5 18.8t.2-.5l5.81-5.8L5.21 6.7Q5 6.49 5 6.2T5.2 5.7Q5.42 5.5 5.7 5.5t.5.2l5.8 5.81 5.8-5.8Q18.01 5.5 18.3 5.5t.5.2T19 6.2t-.2.5l-5.81 5.8z"></path></svg></button></div></div>`;
                            container.appendChild(div);
                            closePup($("._input_87tyg_11"));
                            if (document.querySelector(".card-grid--swiper")) {
                                const boxshopCart = document.querySelector(".card-grid--swiper");
                                if (boxshopCart.querySelector(".flex.justify-center.align-items-center.px-\\[10px\\]")) {
                                    boxshopCart.querySelector(".flex.justify-center.align-items-center.px-\\[10px\\]").remove();
                                }
                                if(boxshopCart.querySelector(".bank-cards-swiper")){
                                    boxshopCart.querySelector(".bank-cards-swiper").remove();
                                }
                                const div = document.createElement('div');
                                div.className = 'bank-cards-swiper';
                                let box = '<div class="swiper-wrapper">';
                                res.card.forEach(item=>{
                                    box += ` <div class="swiper-slide"><article class="bank-card">${item.htmlV2}${item.html}</article></div>`;
                                });
                                box += '</div>';
                                div.innerHTML = box;
                                boxshopCart.appendChild(div);
                                document.querySelector(".profile-bpp").innerHTML = res.card.length;
                                bankCardsSwiper();
                                const lottieContainers = document.querySelectorAll('.lottie-container');
                                lottieContainers.forEach(container => {
                                    const animationPath = container.getAttribute('data-lottie-url');

                                    if (animationPath) {
                                        lottie.loadAnimation({
                                            container: container, // المانی که انیمیشن در آن قرار می‌گیرد
                                            renderer: 'svg',       // نوع رندر (svg بهترین گزینه است)
                                            loop: true,            // تکرار انیمیشن
                                            autoplay: true,        // اجرای خودکار
                                            path: animationPath    // آدرس فایل JSON آپلود شده
                                        });
                                        container.setAttribute('data-lottie-url', '');
                                    }

                                });
                            }
                            if (document.querySelector(".bank-cards__account")) {
                                const bankCard = document.querySelector(".bank-cards__account");
                                if (document.querySelector(".bank-cards__account > div.flex")) {
                                    document.querySelector(".bank-cards__account > div.flex").remove();
                                }
                                if(bankCard.querySelector(".bank-cards__list")){
                                    bankCard.querySelector(".bank-cards__list").remove();
                                }
                                const div = document.createElement('div');
                                div.className = 'bank-cards__list';
                                let article = '';
                                res.card.forEach(item=>{
                                    article += `<article class="bank-card__account"><div class="box">
                                    <div class="bank-card__top">
                                    <span class="bank-card__bank">${item.name}</span> </div>
                                    <h3 class="bank-card__number">${item.card_number}</h3>
                                    <div class="bank-card__meta">
                                                                        <span>دارنده کارت:  ${item.fullName}</span>
                                                                    </div>
                                </div>
                                ${item.html}</article>`;
                                });
                                div.innerHTML = article;
                                bankCard.appendChild(div);
                            }
                        }, 1000);
                    }else {
                        wrapper.classList.remove('is-complete');
                        otpWrap.classList.add('_error_87tyg_52');
                        uikit__collections_error(res.message);
                    }
                },'v2')
            }
        }
        updateDisplay();
    });
    $(document).on('focus','._wrap_87tyg_1._input_pjp0p_66 ._input_87tyg_11',function (e){
        updateDisplay();
    });
    $(document).on('blur','._wrap_87tyg_1._input_pjp0p_66 ._input_87tyg_11',function (e){
        updateDisplay();
    });
    $(document).on('click','._wrap_87tyg_1._input_pjp0p_66',function (e){
        const otpWrap = document.querySelector('._wrap_87tyg_1._input_pjp0p_66');
        const hiddenInput = otpWrap.querySelector('input._input_87tyg_11');
        hiddenInput.focus()
    });
    function updateDisplay() {
        const otpWrap = document.querySelector('._wrap_87tyg_1._input_pjp0p_66');
        if(!otpWrap){
            return;
        }
        const hiddenInput = otpWrap.querySelector('input._input_87tyg_11');
        const digitElements = otpWrap.querySelectorAll('._digit_87tyg_33');

        const value = hiddenInput.value;
        const activeIndex = value.length;

        digitElements.forEach((digit, index) => {
            const span = digit.querySelector('span');
            const prevContent = span.textContent;
            const newContent = value[index] || '';

            if (index === activeIndex && document.activeElement === hiddenInput) {
                digit.classList.add('_is_active');
            } else {
                digit.classList.remove('_is_active');
            }

            if (newContent !== '' && prevContent === '') {
                span.textContent = newContent;
                digit.classList.add('_has_value');
            } else if (newContent === '') {
                span.textContent = '';
                digit.classList.remove('_has_value');
            }
            const caret = digit.querySelector('._caret_87tyg_86');
            if (index === activeIndex && document.activeElement === hiddenInput) {
                if (!caret) {
                    digit.innerHTML = `<span></span><div class="_caret_87tyg_86"></div>`;
                }
            } else {
                if (caret) caret.remove();
            }
        });
    }
    $(document).on('click', '#popper-root [data-testid=\"close-wrapper\"]', function (e) {
        e.preventDefault();
        const closeBtn = $(this);
        const modalRoot = closeBtn.closest(
            '.ModalComponent__root-YwCAMP.ModalComponent__root--desktop-JzGyNl.ModalComponent__animation-JkgpfL.ModalComponent__root--open-i5pSf7.ModalComponent__root--open__desktop-x1XDzU'
        );
        closeBtn.closest('.ModalComponent__content-XqD1rL').css('transform', 'translateY(400%)');
        setTimeout(function () {
            modalRoot.remove();
            document.body.classList.toggle('lock-body-scroll');
        }, 100);
    });
    $(document).on('click', '.Button-cu46', function (e) {
        e.preventDefault();
        const container = document.querySelector("#modal-root .ModalComponent__root-YwCAMP.ModalComponent__root--desktop-JzGyNl.ModalComponent__animation-JkgpfL.ModalComponent__root--open-i5pSf7.ModalComponent__root--open__desktop-x1XDzU");
        container.classList.remove("hidden");
        setTimeout(function() {
            $("#modal-root .ModalComponent__content-XqD1rL.ModalComponent__animation-JkgpfL.ModalComponent__content--desktop-o5IbOt.ModalComponent__content--border-md-4G9biy.overflow-auto").css('transform', 'translateY(50%)');
            document.body.classList.toggle("lock-body-scroll");
        }, 100);
    })
    $(document).on('click', '#modal-root [data-testid=\"close-wrapper\"]', function (e) {
        e.preventDefault();
        $("#modal-root .ModalComponent__content-XqD1rL.ModalComponent__animation-JkgpfL.ModalComponent__content--desktop-o5IbOt.ModalComponent__content--border-md-4G9biy.overflow-auto").css('transform', 'translateY(400%)');
        setTimeout(function() {
            const container = document.querySelector("#modal-root .ModalComponent__root-YwCAMP.ModalComponent__root--desktop-JzGyNl.ModalComponent__animation-JkgpfL.ModalComponent__root--open-i5pSf7.ModalComponent__root--open__desktop-x1XDzU");
            container.classList.add("hidden");
            document.body.classList.toggle("lock-body-scroll");
        }, 100);
    });
    $(document).on('click', ".Button-aca48", function (e) {
        e.preventDefault();
        e.stopPropagation();
        var productID = $(this).data('product-id');
        const button = $(this);
        const originalHTML = button.html();
        button.prop('disabled', true);
        button.html(`<div class="d-flex ai-center jc-center relative grow-1"> <div class="uikit-atomic-Button-Button-module__Loading--jNJ_Z" data-testid="button-loading"> <div></div> </div> </div>`);
        SAJ('addCart', { product_id: productID },
            function(res) {
                if (res.status) {
                    uikit__collections_success("با موفقیت به سبد شما اضافه شد");
                    if (res.delivery){
                        document.body.classList.toggle("lock-body-scroll");
                        const contienr = document.querySelector("#popper-root");
                        const div = document.createElement("div");
                        div.className = 'absolute';
                        div.innerHTML = `<div class="ModalComponent__root-YwCAMP ModalComponent__root--desktop-JzGyNl ModalComponent__animation-JkgpfL ModalComponent__root--open-i5pSf7 ModalComponent__root--open__desktop-x1XDzU"><div class="ModalComponent__content-XqD1rL ModalComponent__animation-JkgpfL ModalComponent__content--desktop-o5IbOt ModalComponent__content--border-md-4G9biy overflow-auto " style="transform: translateY(50%);"> <div class="ModalComponent__header-l62jh_"><div class="d-flex ai-center AppHeader__headerBorder-sqCler  jc-between ProfileModal__header-QU8G4w"> <p class="text-h5 color-n-700 text-h5 text-color-neutral-700">محصول پیش فروش</p> <div class="d-flex pointer pointer mr-2" data-testid="close-wrapper"> <svg style="width: 24px; height: 24px; fill: var(--color-icon-high-emphasis);"> <path d="M12 11.0537C12 11.0537 16.2827 6.77342 17.8617 5.19523C18.1221 4.93492 18.5443 4.93492 18.8047 5.19523C19.0651 5.45553 19.0651 5.87753 18.8047 6.13783C17.2257 7.71602 12.9391 12 12.9391 12C12.9391 12 17.2257 16.284 18.8047 17.8622C19.0651 18.1225 19.0651 18.5445 18.8047 18.8047C18.5443 19.0651 18.1221 19.0651 17.8617 18.8048C16.2827 17.2266 12 12.9463 12 12.9463C12 12.9463 7.7173 17.2266 6.1383 18.8048C5.8779 19.0651 5.4557 19.0651 5.1953 18.8048C4.9349 18.5445 4.9349 18.1225 5.1953 17.8622C6.7743 16.284 11.0609 12 11.0609 12C11.0609 12 6.7743 7.71602 5.1953 6.13783C4.9349 5.87753 4.9349 5.45552 5.1953 5.19533C5.4557 4.93493 5.8779 4.93492 6.1383 5.19523C7.7173 6.77342 12 11.0537 12 11.0537Z"></path> </svg></div> </div> </div> <div class="uModalComponent__body-WvxQuY ModalComponent__body--default-sYpvC3"> <div class="d-flex flex-column gap-y-5"> <div> <div class="text-body-1 color-n-700"><p>نکته:</p><p>این محصول جز محصولات پیش فروش هست و <span style=" color: red; font-weight: bold; ">تحویل آنی</span> را شامل نمی شود، و در ${res.deliveryTime} ساعت بعد از ثبت سفارش لایسنس آن به شما تحویل داده میشود</p></div> </div>  </div> </div><div class="grow-1"></div><div class="ModalComponent__footerContainer-rb1vEj"><div class="ProfileModal__footer-IVQdrc"> <button class="relative d-flex ai-center user-select-none btn-wc51H8 text-button-2 btn--primary-uiqWij radius Button__medium-gIvke_ Button__filledPrimary-OvgwGb ProfileBase__button-jvi4aR ProfileBase__button__modal-O3kjhU Button-pp45" data-testid="button-wrapper" type="button"><div class="d-flex ai-center jc-center relative grow-1">متوجه شدم</div></button></div></div></div></div>`
                        contienr.appendChild(div);
                    }
                    renderMiniCart(res.cart);
                    const el = document.querySelector('.SJf5G');
                    if (el){
                        if (el.classList.contains('hidden')){
                            el.classList.toggle("hidden")
                        }
                        el.textContent = res.cart.items_count;
                    }
                    const countCart = document.querySelectorAll(".w-1\\/5")[2].querySelector("a div span");
                    if (countCart) {
                        countCart.textContent = res.cart.items_count;
                    }else{
                        const span = document.createElement("span");
                        span.className = 'absolute bg-white shadow-[0_0_0_1_1461e2] text-4xs colr-1461e2 min-w-20 leading-1 rounded-pill right-full -mr-12 -bottom-1 px-5 font-bold text-center pt-4 pb-1 tracking-ultratight dir-ltr';
                        span.innerHTML = res.cart.items_count;
                        document.querySelectorAll(".w-1\\/5")[2].querySelector("a div").appendChild(span);
                    }
                    if (refreshTimeout) {
                        clearTimeout(refreshTimeout);
                    }
                    SAJ('cart', {}, function (res) {
                        if (res.status) {
                            if (!res.ig) {
                                uikit__collections_error("ابتدا وارد شوید");
                            }
                            $("#user-cart").html(`<div class="act-new-service-carousel-head d-flex align-items-center justify-content-between"> <svg xmlns="http://www.w3.org/2000/svg" width="1281" height="75" viewBox="0 0 1281 75" fill="none" class="act-new-service-carousel-head-svg"> <path d="M1280.47 0.5H1000.91C986.771 0.5 979.703 0.5 973.764 2.99163C969.027 4.9789 964.838 8.07733 961.551 12.025C957.43 16.9747 955.361 23.7331 951.224 37.25C947.086 50.7669 945.017 57.5253 940.896 62.475C937.609 66.4227 933.42 69.5211 928.683 71.5084C922.744 74 915.676 74 901.54 74H412.882C399.847 74 393.329 74 387.813 71.8926C382.12 69.7177 377.167 65.9625 373.536 61.0686C370.017 56.3267 368.257 50.0512 364.737 37.5C361.217 24.9488 359.457 18.6733 355.938 13.9314C352.307 9.0375 347.353 5.2823 341.661 3.10737C336.145 1 329.627 1 316.592 1H0" stroke="url(#paint0_linear_29_20094)"></path> <defs> <linearGradient id="paint0_linear_29_20094" x1="29.4736" y1="0.500002" x2="1213.79" y2="-28.0511" gradientUnits="userSpaceOnUse"> <stop stop-color="#0B61FF" stop-opacity="0"></stop> <stop offset="0.5" stop-color="#0B61FF"></stop> <stop offset="1" stop-color="#0B61FF" stop-opacity="0"></stop> </linearGradient> </defs> </svg> <div class="act-our-services-carousel-head-title"> <div class="act-our-services-carousel-head-title-divs"> <div class="act-our-services-carousel-head-title-div1"></div> <div class="act-our-services-carousel-head-title-div2"></div> </div> <div class="act-our-services-carousel-head-title-content"> <h5>سبد <strong>خرید</strong> شمـــــا</h5> <p>YOUR SHOPPING CART</p> </div> </div> </div>` + res.html).closest('section').addClass('mt-18');
                            bankCardsSwiper();
                            startCartTimer();
                            const lottieContainers = document.querySelectorAll('.lottie-container');

                            lottieContainers.forEach(container => {
                                const animationPath = container.getAttribute('data-lottie-url');

                                if (animationPath) {
                                    lottie.loadAnimation({
                                        container: container, // المانی که انیمیشن در آن قرار می‌گیرد
                                        renderer: 'svg',       // نوع رندر (svg بهترین گزینه است)
                                        loop: true,            // تکرار انیمیشن
                                        autoplay: true,        // اجرای خودکار
                                        path: animationPath    // آدرس فایل JSON آپلود شده
                                    });
                                    container.setAttribute('data-lottie-url', '');
                                }

                            });
                            paymentButton();
                            supportedBrandsSwiper();
                        }
                    });

                    const btnTop = document.getElementById('user-cart').getBoundingClientRect().top + window.scrollY;
                    window.scrollTo({
                        top: btnTop - 80,
                        behavior: "smooth"
                    });
                    if(!res.available){
                       const divBox = button.closest('div');
                       const divAvailable = document.createElement('div');
                       divAvailable.className = "inaJSDge8";
                       divAvailable.innerHTML = "ناموجود";
                       divBox[0].appendChild(divAvailable);
                       button.remove();
                    }
                    const previewEl = document.createElement('div');
                    previewEl.id = 'card-preview';
                    document.body.appendChild(previewEl);

                    document.querySelectorAll('.bank-card').forEach(card => {
                        card.addEventListener('mouseenter', () => {
                            const rect = card.getBoundingClientRect();

                            // کپی کردن محتوای کارت داخل پیش‌نمایش
                            previewEl.innerHTML = card.querySelector(".V10-3-Bank").outerHTML;

                            // قرار دادن دقیق روی مختصات کارت اصلی
                            previewEl.style.top = `${rect.top}px`;
                            previewEl.style.left = `${rect.left}px`;
                            previewEl.style.width = `${rect.width}px`;
                            previewEl.style.height = `${rect.height}px`;

                            previewEl.classList.add('active');
                        });

                        card.addEventListener('mouseleave', () => {
                            previewEl.classList.remove('active');
                        });
                    });
                } else{
                    uikit__collections_error(res.message)
                }
                button.html(originalHTML);
                button.prop('disabled', false);
            },'v1',{ withCredentials: true })
    });
    $(document).on('click', ".Button-ac13", function (e) {
        e.preventDefault();
        e.stopPropagation();
        var productID = $(this).data('product-id');
        const button = $(this);
        const originalHTML = button.html();
        button.prop('disabled', true);
        button.html(`<div class="d-flex ai-center jc-center relative grow-1"> <div class="uikit-atomic-Button-Button-module__Loading--jNJ_Z" data-testid="button-loading"> <div style="border-color: #000 transparent"></div> </div> </div>`);
        SAJ('addCart', { product_id: productID },
            function(res) {
                if (res.status) {
                    const el = document.querySelector('.SJf5G');
                    if (el){
                        if (el.classList.contains('hidden')){
                            el.classList.toggle("hidden")
                        }
                        el.textContent = res.cart.items_count;
                    }
                    const countCart = document.querySelectorAll(".w-1\\/5")[2].querySelector("a div span");
                    if (countCart) {
                        countCart.textContent = res.cart.items_count;
                    }else{
                        const span = document.createElement("span");
                        span.className = 'absolute bg-white shadow-[0_0_0_1_1461e2] text-4xs colr-1461e2 min-w-20 leading-1 rounded-pill right-full -mr-12 -bottom-1 px-5 font-bold text-center pt-4 pb-1 tracking-ultratight dir-ltr';
                        span.innerHTML = res.cart.items_count;
                        document.querySelectorAll(".w-1\\/5")[2].querySelector("a div").appendChild(span);
                    }
                    renderMiniCart(res.cart);
                    uikit__collections_success("با موفقیت به سبد شما اضافه شد");
                    const isMobile = isMobileDevice() || res.im ? 'Button-scm54' : 'Button-sc4';
                    document.body.classList.toggle("lock-body-scroll");
                    const contienr = document.querySelector("#popper-root");
                    const div = document.createElement("div");
                    let notif = '';
                    if (res.delivery) {
                        notif = `<div class="color-n-500 text-caption uikit-collections--FAf2Q block w-full">این محصول جز محصولات پیش فروش هست و <span style=" color: red; font-weight: bold; ">تحویل آنی</span> را شامل نمی شود، و در ${res.deliveryTime} ساعت بعداز ثبت سفارش لایسنس آن به شما تحویل داده میشود</div>`;
                    }
                    div.className = 'absolute';
                    div.innerHTML = `<div class="ModalComponent__root-YwCAMP ModalComponent__root--desktop-JzGyNl ModalComponent__animation-JkgpfL ModalComponent__root--open-i5pSf7 ModalComponent__root--open__desktop-x1XDzU"><div class="ModalComponent__content-XqD1rL ModalComponent__animation-JkgpfL ModalComponent__content--desktop-o5IbOt ModalComponent__content--border-md-4G9biy overflow-auto " style="transform: translateY(50%);"> <div class="ModalComponent__header-l62jh_"><div class="d-flex ai-center AppHeader__headerBorder-sqCler  jc-between ProfileModal__header-QU8G4w"> <p class="text-h5 color-n-700 text-h5 text-color-neutral-700">این محصول به سبد خرید اضافه شد!</p> <div class="d-flex pointer pointer mr-2" data-testid="close-wrapper"> <svg style="width: 24px; height: 24px; fill: var(--color-icon-high-emphasis);"> <path d="M12 11.0537C12 11.0537 16.2827 6.77342 17.8617 5.19523C18.1221 4.93492 18.5443 4.93492 18.8047 5.19523C19.0651 5.45553 19.0651 5.87753 18.8047 6.13783C17.2257 7.71602 12.9391 12 12.9391 12C12.9391 12 17.2257 16.284 18.8047 17.8622C19.0651 18.1225 19.0651 18.5445 18.8047 18.8047C18.5443 19.0651 18.1221 19.0651 17.8617 18.8048C16.2827 17.2266 12 12.9463 12 12.9463C12 12.9463 7.7173 17.2266 6.1383 18.8048C5.8779 19.0651 5.4557 19.0651 5.1953 18.8048C4.9349 18.5445 4.9349 18.1225 5.1953 17.8622C6.7743 16.284 11.0609 12 11.0609 12C11.0609 12 6.7743 7.71602 5.1953 6.13783C4.9349 5.87753 4.9349 5.45552 5.1953 5.19533C5.4557 4.93493 5.8779 4.93492 6.1383 5.19523C7.7173 6.77342 12 11.0537 12 11.0537Z"></path> </svg></div> </div> </div> <div class="uModalComponent__body-WvxQuY ModalComponent__body--default-sYpvC3"> <div class="p-28"><div class="flex flex-row-reverse items-start"><div class="mr-20"><div class="flex justify-end"><img alt="${res.product.name}" loading="lazy" decoding="async" width="140" class="shrink-0 rounded block" src="${res.product.image}" style="color: transparent"></div></div><div class="pt-4 grow leading-xs self-center overflow-htridden"><span class="text-sm text-dark font-bold tracking-tight">${res.product.name}</span><div class="rounded bg-light w-104 h-36 flex flex-row-reverse transition-opacity mt-8" data-product-id="${productID}"><button type="button" class="pl-6 mini-quantity__btn" data-product-mini-decrease><i class="${res.product.qty ==1 ? 'icon-delete text-xs text-red-dark text-opacity-90 w-24 h-24 bg-white shadow-sm block !leading-[24px] text-center rounded-sm':'w-24 h-24 !leading-[24px] icon-minus text-[9px] text-gray bg-white shadow-sm block text-center rounded-sm w-28 h-28 !leading-[28px]'}"></i></button><div class="grow text-center flex flex-col justify-center leading-1"><div class="pt-2 text-dark font-bold tracking-tighter text-sm after:loading after:border-blue transition-colors after:text-3xs" data-product-mini-qty="">${res.product.qty}</div></div><button type="button" class="pr-6 mini-quantity__btn" data-product-mini-increase=""><i class="w-24 h-24 bg-white shadow-sm text-gray rounded-sm icon-plus text-[9px] block !leading-[24px] text-center"></i></button></div></div></div></div>${notif}</div><div class="grow-1"></div><div class="ModalComponent__footerContainer-rb1vEj"><div class="ProfileModal__footer-IVQdrc"> <button class="btn btn-primary w-full rounded ${isMobile}" data-testid="button-wrapper" type="button" style=" width: 100%; "><div class="d-flex ai-center jc-center relative grow-1">برو به سبد خرید</div></button></div> </div></div></div>`
                    contienr.appendChild(div);
                    if(!res.available){
                        let divBox = '';
                        if(button.closest('[aria-labelledby="pricing"]').length != 0) {
                            divBox = button.closest('[aria-labelledby="pricing"]')
                            const divAvailable = document.createElement('div');
                            const ButtonAlert = document.createElement('button');
                            divAvailable.className = "product_isNot_available";
                            divAvailable.innerHTML = "این کالا فعلا موجود نیست!";
                            ButtonAlert.className = "btn btn--outline btn--block mb-2 Button-stock-alert-toggle";
                            ButtonAlert.innerHTML = "<svg style=\"width: 24px;height: 24px;fill: #6c3bff;\"><path fill-rule=\"evenodd\" d=\"M3.667 13.886A2.001 2.001 0 005 12V9a7 7 0 0114 0v3c0 .854.54 1.606 1.333 1.886a1 1 0 01.667.943V19a1 1 0 01-1 1H4a1 1 0 01-1-1v-4.17a1 1 0 01.667-.944zM19 18v-2.535A4 4 0 0117 12V9A5 5 0 007 9v3a4 4 0 01-2 3.465V18h14zm-7 5c-1.385 0-2.563-.835-3-2h6c-.437 1.165-1.615 2-3 2zm6.02-19.262l1.504-1.318a9.964 9.964 0 012.477 6.589h-2a7.964 7.964 0 00-1.981-5.27zM4 9.008c0-1.966.711-3.82 1.981-5.27L4.477 2.42A9.964 9.964 0 002 9.009h2z\" clip-rule=\"evenodd\"></path></svg>وقتی موجود شد خبرم کن";
                            ButtonAlert.dataset.productId = productID;
                            ButtonAlert.dataset.defaultMobile = window.user.mobile;
                            divBox[0].insertBefore(ButtonAlert,divBox[0].firstChild);
                            divBox[0].insertBefore(divAvailable,divBox[0].firstChild);
                        }
                        if(document.querySelector("#app > main > section.container-xl-w.mx-auto.flex.mt-18.sGsfe5 > div.lg\\:w-25 > div > div > div:nth-child(2)").length != 0){
                            divBox= document.querySelector("#app > main > section.container-xl-w.mx-auto.flex.mt-18.sGsfe5 > div.lg\\:w-25 > div > div > div:nth-child(2)")
                            const ButtonAlert = document.createElement('button');
                            ButtonAlert.className = "btn btn--outline btn--block mb-2 Button-stock-alert-toggle";
                            ButtonAlert.innerHTML = "<svg style=\"width: 24px;height: 24px;fill: #6c3bff;\"><path fill-rule=\"evenodd\" d=\"M3.667 13.886A2.001 2.001 0 005 12V9a7 7 0 0114 0v3c0 .854.54 1.606 1.333 1.886a1 1 0 01.667.943V19a1 1 0 01-1 1H4a1 1 0 01-1-1v-4.17a1 1 0 01.667-.944zM19 18v-2.535A4 4 0 0117 12V9A5 5 0 007 9v3a4 4 0 01-2 3.465V18h14zm-7 5c-1.385 0-2.563-.835-3-2h6c-.437 1.165-1.615 2-3 2zm6.02-19.262l1.504-1.318a9.964 9.964 0 012.477 6.589h-2a7.964 7.964 0 00-1.981-5.27zM4 9.008c0-1.966.711-3.82 1.981-5.27L4.477 2.42A9.964 9.964 0 002 9.009h2z\" clip-rule=\"evenodd\"></path></svg>وقتی موجود شد خبرم کن";
                            ButtonAlert.dataset.productId = productID;
                            ButtonAlert.dataset.defaultMobile = window.user.mobile;
                            const children = divBox.children;
                            const lastIndex = children.length - 1;
                            if (children[lastIndex]) children[lastIndex].remove();
                            if (children[lastIndex - 1]) children[lastIndex - 1].remove();
                            divBox.appendChild(ButtonAlert);
                        }
                        if(button.closest('.lg\\:w-50.flex.align-items-center.ai-start').length != 0){
                            console.log(button.closest('.lg\\:w-50.flex.align-items-center.ai-start'));
                            divBox= button.closest('.lg\\:w-50.flex.align-items-center.ai-start');
                            const ButtonAlert = document.createElement('button');
                            ButtonAlert.className = "fjfYr25 Button-stock-alert-toggle";
                            ButtonAlert.innerHTML = "وقتی موجود شد خبرم کن";
                            ButtonAlert.style = "color: #6c3bff !important;";
                            ButtonAlert.dataset.productId = productID;
                            ButtonAlert.dataset.defaultMobile = window.user.mobile;
                            divBox[0].insertBefore(ButtonAlert,divBox[0].firstChild);

                        }
                        button.remove();
                    }
                } else{
                    uikit__collections_error(res.message)
                }
                button.html(originalHTML);
                button.prop('disabled', false);
            },'v1',{ withCredentials: true })
    });
    $(document).on('click', ".Category-al74", function () {
        var term_id = $(this).data('category-id');
        const container = document.getElementById('LoadCategory');
        const btnTop = container.getBoundingClientRect().top + window.scrollY;
        window.scrollTo({
            top: btnTop-185,
            behavior: "smooth"
        });
        if(document.querySelector('.fhDGSJDF')) {
            const fhDGSJDF = document.querySelector('.fhDGSJDF');
            fhDGSJDF.innerHTML = `<div> <div class="act-new-service-card "> <div class="act-new-service-card-inner"> <div> <div class="act-new-service-card-inner-top"> <div class="act-new-service-card-inner-top-img-box" style=" width: 100%; "> <div class="skeleton rounded-sm" style=" height: 135px; border-radius: 16px; "></div> </div> <div class="act-new-service-card-inner-top-txt-box"> <div class="skeleton w-[200px] h-15 rounded-pill"></div> <div class="flex justify-between"> <div class="flex"> <div class="skeleton w-104 h-36 rounded"></div> </div> <div class="skeleton w-104 h-36 rounded"></div> </div> <div class="skeleton w-92 h-14 rounded-pill"></div> </div> </div> </div> <div> <div class="act-product-card-footer"> <div class="skeleton w-104 h-36 rounded"></div> <div class="skeleton h-36 rounded" style=" width: 70px; "></div> </div> <div class="skeleton h-48 rounded mt-3"></div> </div> <div class="act-product-card-actions"><p class="pre-sale__actions"></p></div> </div> </div> </div><div> <div class="act-new-service-card "> <div class="act-new-service-card-inner"> <div> <div class="act-new-service-card-inner-top"> <div class="act-new-service-card-inner-top-img-box" style=" width: 100%; "> <div class="skeleton rounded-sm" style=" height: 135px; border-radius: 16px; "></div> </div> <div class="act-new-service-card-inner-top-txt-box"> <div class="skeleton w-[200px] h-15 rounded-pill"></div> <div class="flex justify-between"> <div class="flex"> <div class="skeleton w-104 h-36 rounded"></div> </div> <div class="skeleton w-104 h-36 rounded"></div> </div> <div class="skeleton w-92 h-14 rounded-pill"></div> </div> </div> </div> <div> <div class="act-product-card-footer"> <div class="skeleton w-104 h-36 rounded"></div> <div class="skeleton h-36 rounded" style=" width: 70px; "></div> </div> <div class="skeleton h-48 rounded mt-3"></div> </div> <div class="act-product-card-actions"><p class="pre-sale__actions"></p></div> </div> </div> </div><div> <div class="act-new-service-card "> <div class="act-new-service-card-inner"> <div> <div class="act-new-service-card-inner-top"> <div class="act-new-service-card-inner-top-img-box" style=" width: 100%; "> <div class="skeleton rounded-sm" style=" height: 135px; border-radius: 16px; "></div> </div> <div class="act-new-service-card-inner-top-txt-box"> <div class="skeleton w-[200px] h-15 rounded-pill"></div> <div class="flex justify-between"> <div class="flex"> <div class="skeleton w-104 h-36 rounded"></div> </div> <div class="skeleton w-104 h-36 rounded"></div> </div> <div class="skeleton w-92 h-14 rounded-pill"></div> </div> </div> </div> <div> <div class="act-product-card-footer"> <div class="skeleton w-104 h-36 rounded"></div> <div class="skeleton h-36 rounded" style=" width: 70px; "></div> </div> <div class="skeleton h-48 rounded mt-3"></div> </div> <div class="act-product-card-actions"><p class="pre-sale__actions"></p></div> </div> </div> </div><div> <div class="act-new-service-card "> <div class="act-new-service-card-inner"> <div> <div class="act-new-service-card-inner-top"> <div class="act-new-service-card-inner-top-img-box" style=" width: 100%; "> <div class="skeleton rounded-sm" style=" height: 135px; border-radius: 16px; "></div> </div> <div class="act-new-service-card-inner-top-txt-box"> <div class="skeleton w-[200px] h-15 rounded-pill"></div> <div class="flex justify-between"> <div class="flex"> <div class="skeleton w-104 h-36 rounded"></div> </div> <div class="skeleton w-104 h-36 rounded"></div> </div> <div class="skeleton w-92 h-14 rounded-pill"></div> </div> </div> </div> <div> <div class="act-product-card-footer"> <div class="skeleton w-104 h-36 rounded"></div> <div class="skeleton h-36 rounded" style=" width: 70px; "></div> </div> <div class="skeleton h-48 rounded mt-3"></div> </div> <div class="act-product-card-actions"><p class="pre-sale__actions"></p></div> </div> </div> </div><div> <div class="act-new-service-card "> <div class="act-new-service-card-inner"> <div> <div class="act-new-service-card-inner-top"> <div class="act-new-service-card-inner-top-img-box" style=" width: 100%; "> <div class="skeleton rounded-sm" style=" height: 135px; border-radius: 16px; "></div> </div> <div class="act-new-service-card-inner-top-txt-box"> <div class="skeleton w-[200px] h-15 rounded-pill"></div> <div class="flex justify-between"> <div class="flex"> <div class="skeleton w-104 h-36 rounded"></div> </div> <div class="skeleton w-104 h-36 rounded"></div> </div> <div class="skeleton w-92 h-14 rounded-pill"></div> </div> </div> </div> <div> <div class="act-product-card-footer"> <div class="skeleton w-104 h-36 rounded"></div> <div class="skeleton h-36 rounded" style=" width: 70px; "></div> </div> <div class="skeleton h-48 rounded mt-3"></div> </div> <div class="act-product-card-actions"><p class="pre-sale__actions"></p></div> </div> </div> </div>`;
        }
        setTimeout(function (){
            SAJ('LoadCategory', { term_id: term_id },
                function(res) {
                    if (res.description != "") {
                        document.body.classList.toggle("lock-body-scroll");
                        const contienr = document.querySelector("#popper-root");
                        const div = document.createElement("div");
                        div.className = 'absolute';
                        div.innerHTML = `<div class="ModalComponent__root-YwCAMP ModalComponent__root--desktop-JzGyNl ModalComponent__animation-JkgpfL ModalComponent__root--open-i5pSf7 ModalComponent__root--open__desktop-x1XDzU"><div class="ModalComponent__content-XqD1rL ModalComponent__animation-JkgpfL ModalComponent__content--desktop-o5IbOt ModalComponent__content--border-md-4G9biy overflow-auto " style="transform: translateY(50%);"> <div class="ModalComponent__header-l62jh_"><div class="d-flex ai-center AppHeader__headerBorder-sqCler  jc-between ProfileModal__header-QU8G4w"> <p class="text-h5 color-n-700 text-h5 text-color-neutral-700">توجه</p> <div class="d-flex pointer pointer mr-2" data-testid="close-wrapper"> <svg style="width: 24px; height: 24px; fill: var(--color-icon-high-emphasis);"> <path d="M12 11.0537C12 11.0537 16.2827 6.77342 17.8617 5.19523C18.1221 4.93492 18.5443 4.93492 18.8047 5.19523C19.0651 5.45553 19.0651 5.87753 18.8047 6.13783C17.2257 7.71602 12.9391 12 12.9391 12C12.9391 12 17.2257 16.284 18.8047 17.8622C19.0651 18.1225 19.0651 18.5445 18.8047 18.8047C18.5443 19.0651 18.1221 19.0651 17.8617 18.8048C16.2827 17.2266 12 12.9463 12 12.9463C12 12.9463 7.7173 17.2266 6.1383 18.8048C5.8779 19.0651 5.4557 19.0651 5.1953 18.8048C4.9349 18.5445 4.9349 18.1225 5.1953 17.8622C6.7743 16.284 11.0609 12 11.0609 12C11.0609 12 6.7743 7.71602 5.1953 6.13783C4.9349 5.87753 4.9349 5.45552 5.1953 5.19533C5.4557 4.93493 5.8779 4.93492 6.1383 5.19523C7.7173 6.77342 12 11.0537 12 11.0537Z"></path> </svg></div> </div> </div> <div class="uModalComponent__body-WvxQuY ModalComponent__body--default-sYpvC3"> <div class="d-flex flex-column gap-y-5"> <div> <div class="text-body-1 color-n-700"><p>${res.description}</p></div> </div>  </div> </div><div class="grow-1"></div><div class="ModalComponent__footerContainer-rb1vEj"><div class="ProfileModal__footer-IVQdrc"> <button class="relative d-flex ai-center user-select-none btn-wc51H8 text-button-2 btn--primary-uiqWij radius Button__medium-gIvke_ Button__filledPrimary-OvgwGb ProfileBase__button-jvi4aR ProfileBase__button__modal-O3kjhU Button-pp45" data-testid="button-wrapper" type="button"><div class="d-flex ai-center jc-center relative grow-1">متوجه شدم</div></button></div></div></div></div>`
                        contienr.appendChild(div);
                    }
                    container.innerHTML = res.html;
                    timerlpt();
                    selectRegion();
                    Tooltip();
                    timerlpts();
                })
        },200)
    });
    $(document).on('click','.Button-pcu48',function (){
        var total = $("[data-summary=\"total\"] span").text();
        if (vip || gatewayApi === 'd' || total==0){
            const selectedGateway = localStorage.getItem('selectedButton');
            SAJ('payment',{ gateway: selectedGateway},function (res){
                if (res.status){
                    window.location.href = res.url;
                }else {
                    uikit__collections_error(res.message);
                }
                button.html(originalHTML);
                button.prop('disabled', false);
            })
        }else {
            document.body.classList.toggle("lock-body-scroll");
            const contienr = document.querySelector("#popper-root");
            const div = document.createElement("div");
            div.className = 'absolute';
            div.innerHTML = `<div class="ModalComponent__root-YwCAMP ModalComponent__root--desktop-JzGyNl ModalComponent__animation-JkgpfL ModalComponent__root--open-i5pSf7 ModalComponent__root--open__desktop-x1XDzU"> <div class="ModalComponent__content-XqD1rL ModalComponent__animation-JkgpfL ModalComponent__content--desktop-o5IbOt ModalComponent__content--border-md-4G9biy overflow-auto " style="transform: translateY(50%);"> <div class="ModalComponent__header-l62jh_"> <div class="d-flex ai-center AppHeader__headerBorder-sqCler  jc-between ProfileModal__header-QU8G4w"><p class="text-h5 color-n-700 text-h5 text-color-neutral-700">انتخاب کارت از بیین کارت های تایید شده</p> <div class="d-flex pointer pointer mr-2" data-testid="close-wrapper"> <svg style="width: 24px; height: 24px; fill: var(--color-icon-high-emphasis);"> <path d="M12 11.0537C12 11.0537 16.2827 6.77342 17.8617 5.19523C18.1221 4.93492 18.5443 4.93492 18.8047 5.19523C19.0651 5.45553 19.0651 5.87753 18.8047 6.13783C17.2257 7.71602 12.9391 12 12.9391 12C12.9391 12 17.2257 16.284 18.8047 17.8622C19.0651 18.1225 19.0651 18.5445 18.8047 18.8047C18.5443 19.0651 18.1221 19.0651 17.8617 18.8048C16.2827 17.2266 12 12.9463 12 12.9463C12 12.9463 7.7173 17.2266 6.1383 18.8048C5.8779 19.0651 5.4557 19.0651 5.1953 18.8048C4.9349 18.5445 4.9349 18.1225 5.1953 17.8622C6.7743 16.284 11.0609 12 11.0609 12C11.0609 12 6.7743 7.71602 5.1953 6.13783C4.9349 5.87753 4.9349 5.45552 5.1953 5.19533C5.4557 4.93493 5.8779 4.93492 6.1383 5.19523C7.7173 6.77342 12 11.0537 12 11.0537Z"></path> </svg> </div> </div> </div> <div class="uModalComponent__body-WvxQuY ModalComponent__body--default-sYpvC3"> <div class="Hint--primary-mwFS2H Hint__padding-nRd4K4 radius Hint__iconStart-bpg5ZO" data-testid="hint-wrapper"> <div class="d-flex ai-center"> <div class="d-flex Hint__titleSlot-yPP6H0" data-testid="icon-wrapper"> <svg style="width: 24px; height: 24px; fill: #1ab1d4;"> <path d="M2 12c0 5.523 4.477 10 10 10s10-4.477 10-10c0-5.523-4.477-10-10-10s-10 4.477-10 10zM12 7c0.552 0 1 0.448 1 1s-0.448 1-1 1c-0.552 0-1-0.448-1-1s0.448-1 1-1zM10 10h3v7h-2v-5h-1v-2z"></path> </svg> </div> <span class="mr-2 text-body-1 color-brand-primary-700 Hint__padding--title-AHG0eM">جهت جلو گیری از فیشینگ و خطرات احتمالی پرداخت آنلاین،قبل از پرداخت سفارش شماره کارت خود را وارد کنید.لازم به ذکر هست تحویل آنی فقط شامل شماره کارت هایی میشوند که کارت به نام خود شما باشند باقی کارت ها باید تایید بشوند</span> </div> </div> <div class="d-flex Container-mirV2w mb-4 Container--withBorder-OdFFhL"> <div class="ProfileLayout__tab-rvmH7A TabItem-CWkOsT TabItem__active-AZcc4O text-subtitle-strong"> پرداخت با کارت های ثبت شده </div> </div> <div id="cartUser"> <div class="d-flex ai-center jc-center relative grow-1"> <div class="uikit-atomic-Button-Button-module__Loading--jNJ_Z" data-testid="button-loading"> <div style="border-color: #000000 transparent;"></div> </div> </div> </div> </div> <div class="grow-1"></div> <div class="ModalComponent__footerContainer-rb1vEj"> <div class="ProfileModal__footer-IVQdrc"> <button class="relative d-flex ai-center user-select-none btn-wc51H8 text-button-2 btn--primary-uiqWij radius Button__medium-gIvke_ Button__filledPrimary-OvgwGb ProfileBase__button-jvi4aR ProfileBase__button__modal-O3kjhU Button-cc54" data-testid="button-wrapper" type="button"> <div class="d-flex ai-center jc-center relative grow-1">پرداخت</div> </button> </div> </div> </div> </div>`;
            contienr.appendChild(div);
            SAJ('userCart', {}, function (res) {
                $("#cartUser").html(res.html);
                const lottieContainers = document.querySelectorAll('.lottie-container');

                lottieContainers.forEach(container => {
                    const animationPath = container.getAttribute('data-lottie-url');

                    if (animationPath) {
                        lottie.loadAnimation({
                            container: container, // المانی که انیمیشن در آن قرار می‌گیرد
                            renderer: 'svg',       // نوع رندر (svg بهترین گزینه است)
                            loop: true,            // تکرار انیمیشن
                            autoplay: true,        // اجرای خودکار
                            path: animationPath    // آدرس فایل JSON آپلود شده
                        });
                        container.setAttribute('data-lottie-url', '');
                    }
                });
            }, 'v2')
        }
    })

    $(document).on('click', '.Button-cc54', function () {
        const selectedGateway = localStorage.getItem('selectedButton');
        const button = $(this);
        const originalHTML = button.html();
        button.prop('disabled', true);
        button.html(`<div class="d-flex ai-center jc-center relative grow-1"> <div class="uikit-atomic-Button-Button-module__Loading--jNJ_Z" data-testid="button-loading"> <div></div> </div> </div>`);
        SAJ('payment', {gateway: selectedGateway}, function (res) {
            if (res.status) {
                window.location.href = res.url;
                closePup(button);
                uikit__collections_success("در حال انتقال به درگاه پرداخت");
            } else {
                uikit__collections_error(res.message);
            }
            button.html(originalHTML);
            button.prop('disabled', false);
        })
    });
    let gatewayApi = 'r';
    $(document).on('click', '.Button-pr44', function (e) {
        gatewayApi = 'r';
        const gateway = document.querySelector(".gateway-row");
        if (!$(this).hasClass('active')){
            $(".before\\:loading").addClass("is-loading").css('filter', 'blur(0px)');
            $(".before\\:loading > div").css('filter', 'blur(1px)');
            localStorage.setItem('selectedButton', 'zibal');
            SAJ('PaymentMethods',{method:'r'},function (response){
                document.querySelectorAll(".before\\:loading .flex.items-center.leading-xs")[2].style = '';
                document.querySelectorAll(".before\\:loading .flex.items-center.leading-xs")[4].style = '';
                if(document.getElementById('usdDollar')){
                    document.getElementById('usdDollar').remove();
                }
                document.querySelector(".supported__brands").classList.toggle("hidden");
                $(".before\\:loading").removeClass("is-loading");
                $(".before\\:loading > div").css('filter', 'blur(0px)');
                if (response.summary) {
                    $('[data-summary="subtotal"]').html(response.summary.subtotal);
                    $('[data-summary="discount"]').html(response.summary.discount);
                    $('[data-summary="total"]').html(response.summary.total);
                }
            })
            gateway.innerHTML = `<button type="button" class="border-l w-full text-right border-gray-300 last:!border-l-0 py-16 px-14 flex items-center Button-p4" data-gateway="zibal"> <div class="pt-2 grow leading-1 tracking-tight"> <span class="block text-xs text-dark font-bold">پرداخت آنلاین</span> <span class="block text-2xs font-normal text-dark mt-8">درگاه پرداخت زیبال</span> </div> <i class="w-20 h-20 text-center rounded-circle text-4xs pl-1 ml-4 !leading-[22px] icon-check transition-colors text-white bg-green bg-opacity-100"></i> </button><button type="button" class="border-l w-full text-right border-gray-300 last:!border-l-0 py-16 px-14 flex items-center Button-p4" data-gateway="sdf"> <div class="pt-2 grow leading-1 tracking-tight"> <span class="block text-xs text-dark font-bold">پرداخت آنلاین</span> <span class="block text-2xs font-normal text-dark mt-8">درگاه پرداخت واندار</span> </div> <i class="w-20 h-20 text-center rounded-circle bg-gray bg-opacity-15 text-4xs pl-1 ml-4 !leading-[22px] icon-check text-transparent transition-colors"></i> </button>`;
            $(".Button-pu44").toggleClass('active');
            $(this).toggleClass('active');
        }
    });
    $(document).on('click', '.Button-pu44', function (e) {
        gatewayApi = 'd';
        const gateway = document.querySelector(".gateway-row");
        if (!$(this).hasClass('active')){
            $(".before\\:loading").addClass("is-loading").css('filter', 'blur(0px)');
            $(".before\\:loading > div").css('filter', 'blur(1px)');
            localStorage.setItem('selectedButton', 'Payment4');
            SAJ('PaymentMethods',{method:'u'},function (response){
                document.querySelector(".supported__brands").classList.toggle("hidden");
                $(".before\\:loading").removeClass("is-loading");
                $(".before\\:loading > div").css('filter', 'blur(0px)');
                if (response.summary) {
                    $('[data-summary="subtotal"]').html(response.summary.subtotal);
                    $('[data-summary="discount"]').html(response.summary.discount);
                    $('[data-summary="total"]').html(response.summary.total);
                    const target = document.querySelectorAll(".before\\:loading .flex.items-center.leading-xs")[2];

                    if (target) {
                        const newElement = document.createElement('div');
                        newElement.className = "flex items-center leading-xs";
                        newElement.innerHTML = `<span class="grow text-xs tracking-tight font-medium text-dark pt-1">قیمت دلار(آخرین بروزسانی مال ${response.summary.update_dollar} قبل است)</span><div class="text-2xs text-gray font-medium tracking-tight">${response.summary.dollar}</div>`
                        newElement.id = 'usdDollar';
                        target.insertAdjacentElement('afterend', newElement);
                    }
                    document.querySelectorAll(".before\\:loading .flex.items-center.leading-xs")[2].style = 'display:none';
                    document.querySelectorAll(".before\\:loading .flex.items-center.leading-xs")[4].style = 'display:none';

                }
            })
            gateway.innerHTML = `<button type="button" class="border-b w-full text-right border-gray-300 last:!border-b-0 py-16 px-14 flex items-center Button-p5" data-gateway="Payment4"> <div class="pt-2 grow leading-1 tracking-tight"> <span class="block text-xs text-dark font-bold">پرداخت دلاری</span> <span class="block text-2xs font-normal text-dark mt-8">Payment4</span> </div> <i class="w-20 h-20 text-center rounded-circle text-4xs pl-1 ml-4 !leading-[22px] icon-check transition-colors text-white bg-green bg-opacity-100"></i> </button>`;
            $(".Button-pr44").toggleClass('active');
            $(this).toggleClass('active');
        }
    });
    $(document).on('click', '[data-mini-decrease]', function () {
        const $line   = $(this).closest('[data-mini-item]');
        const $input  = $line.find('[data-mini-qty]');
        const $deleteBtn = $line.find('[data-mini-decrease]');
        const cartKey = $line.data('mini-item');
        let qty = parseInt($input.html()) || 1;
        const button = $(this);
        button.prop('disabled', true);
        $(".before\\:loading").addClass("is-loading").css('filter', 'blur(0px)');
        $(".before\\:loading > div").css('filter', 'blur(1px)');

        qty--;
        if (qty < 2) {
            $deleteBtn.find('i').removeClass('icon-minus text-[9px] text-gray bg-white shadow-sm block text-center rounded-sm w-28 h-28 !leading-[28px]');
            $deleteBtn.find('i').addClass('icon-delete text-xs text-red-dark text-opacity-90 bg-white shadow-sm block text-center rounded-sm w-28 h-28 !leading-[28px]');
        }

        if (qty <= 0) {
            $line.remove();
        }
        $input.html(`<div class="d-flex ai-center jc-center relative grow-1"><div class="flex items-center justify-center"><div class="flex items-center justify-around" style="width: 24px; height: 24px;"><div class="rounded-circle styles_Loading__circle1__K7HNJ" style="width: 6px;height: 6px;background: rgb(156,156,156);"></div><div class="rounded-circle styles_Loading__circle2__jpl_q" style="width: 6px;height: 6px;background: rgb(129,129,129);"></div><div class="rounded-circle styles_Loading__circle3__otcH4" style="width: 6px;height: 6px;background: rgb(92,92,92);"></div></div></div> </div>`);

        updateCart(cartKey, qty, $input,button,gatewayApi);
    });

    $(document).on('click', '[data-mini-increase]', function () {
        const $line   = $(this).closest('[data-mini-item]');
        const $input  = $line.find('[data-mini-qty]');
        const $deleteBtn = $line.find('[data-mini-decrease]');
        const cartKey = $line.data('mini-item');
        let qty = parseInt($input.html()) || 1;
        const button = $(this);
        button.prop('disabled', true);
        $(".before\\:loading").addClass("is-loading").css('filter', 'blur(0px)');
        $(".before\\:loading > div").css('filter', 'blur(1px)');

        qty++;

        if (qty > 1) {
            $deleteBtn.find('i').removeClass('icon-delete text-xs text-red-dark text-opacity-90 bg-white shadow-sm block text-center rounded-sm w-28 h-28 !leading-[28px]');
            $deleteBtn.find('i').addClass('icon-minus text-[9px] text-gray bg-white shadow-sm block text-center rounded-sm w-28 h-28 !leading-[28px]');
        }
        $input.html(`<div class="d-flex ai-center jc-center relative grow-1"><div class="flex items-center justify-center"><div class="flex items-center justify-around" style="width: 24px; height: 24px;"><div class="rounded-circle styles_Loading__circle1__K7HNJ" style="width: 6px;height: 6px;background: rgb(156,156,156);"></div><div class="rounded-circle styles_Loading__circle2__jpl_q" style="width: 6px;height: 6px;background: rgb(129,129,129);"></div><div class="rounded-circle styles_Loading__circle3__otcH4" style="width: 6px;height: 6px;background: rgb(92,92,92);"></div></div></div> </div>`);
        console.log(cartKey, qty, $input,button,gatewayApi);
        updateCart(cartKey, qty, $input,button,gatewayApi);
    });
    $(document).on('click', '.C-item__blog', function (e) {
        e.preventDefault();
        const container =  document.querySelector(".act-blogs-carousel-wrapper");
        container.innerHTML = `<div class="act-blogs-first-box"> <div class="act-blog-first-card"> <a class="act-blog-card"> <div class="act-blog-card-inner"> <div class="act-blog-card-img-box"> <div class="skeleton rounded-sm" style="height: 119px;border-radius: 16px;"></div> </div> <div class="act-blog-card-content"> <div class="skeleton w-[200px] h-15 rounded-pill"></div> <div class="act-blog-card-footer"> <div class="skeleton w-104 h-15 rounded-pill"></div> </div> </div> </div> </a> </div> <div class="act-blog-first-card"> <a class="act-blog-card"> <div class="act-blog-card-inner"> <div class="act-blog-card-img-box"> <div class="skeleton rounded-sm" style="height: 119px;border-radius: 16px;"></div> <span class="act-blog-card-img-box-label">md431</span></div> <div class="act-blog-card-content"> <div class="skeleton w-[200px] h-15 rounded-pill"></div> <div class="act-blog-card-text">کمی زرنگ باشی بد نیست</div> <div class="act-blog-card-footer"> <div class="skeleton w-104 h-15 rounded-pill"></div> <div class="act-blog-card-link"> <svg xmlns="http://www.w3.org/2000/svg" width="26" height="26" viewBox="0 0 26 26" fill="currentcolor"> <path d="M15.0559 8.6175C14.9551 8.71827 14.8173 8.78191 14.6582 8.78191L8.7821 8.78191L8.7821 14.658C8.7821 14.9656 8.52755 15.2201 8.21996 15.2201C7.91236 15.2201 7.6578 14.9656 7.6578 14.658L7.6578 8.21976C7.6578 7.91216 7.91236 7.65761 8.21995 7.65761L14.6582 7.65761C14.9658 7.65761 15.2203 7.91216 15.2203 8.21976C15.2256 8.37355 15.1567 8.51674 15.0559 8.6175Z"></path> <path d="M17.6333 17.6332C17.4159 17.8506 17.0553 17.8506 16.8379 17.6332L7.9124 8.7077C7.69496 8.49027 7.69496 8.12964 7.9124 7.91221C8.12983 7.69477 8.49046 7.69477 8.70789 7.91221L17.6333 16.8377C17.8508 17.0551 17.8508 17.4157 17.6333 17.6332Z"></path> </svg> </div> </div> </div> </div> </a> </div></div><a class="act-blog-card"> <div class="act-blog-card-inner"> <div class="act-blog-card-img-box"> <div class="skeleton rounded-sm" style="height: 158px;border-radius: 16px;"></div> <span class="act-blog-card-img-box-label" style=" background-color: transparent; "><div class="skeleton rounded-pill" style=" width: 81px; height: 29px; "></div></span> </div> <div class="act-blog-card-content w-full"> <h4 class="act-product-title"><div class="skeleton w-[200px] h-15 rounded-pill"></div></h4> <div class="act-blog-card-text"><div class="skeleton rounded-pill" style="height: 22px;margin-bottom: 10px;"></div><div class="skeleton w-[200px] h-15 rounded-pill"></div></div> </div>  </div> </a><div class="act-blogs-carousel"> <div class="act-blogs-carousel-wrapper"><div class="act-blogs-last-box">  <div class="act-blog-last-card"> <a class="act-blog-card"> <div class="act-blog-card-inner"> <div class="act-blog-card-img-box"> <div class="skeleton rounded-sm" style="height: 72px;border-radius: 16px;"></div> </div> <div class="act-blog-card-content"> <div class="skeleton w-[200px] h-15 rounded-pill"></div> <div class="act-blog-card-footer"> <div class="act-blog-card-footer-read-time"><div class="skeleton w-104 rounded-pill" style=" height: 11px; margin-top: 10px; "></div></div> </div> </div> </div> </a> </div><div class="act-blog-last-card"> <a class="act-blog-card"> <div class="act-blog-card-inner"> <div class="act-blog-card-img-box"> <div class="skeleton rounded-sm" style="height: 72px;border-radius: 16px;"></div> </div> <div class="act-blog-card-content"> <div class="skeleton w-[200px] h-15 rounded-pill"></div> <div class="act-blog-card-footer"> <div class="act-blog-card-footer-read-time"><div class="skeleton w-104 rounded-pill" style=" height: 11px; margin-top: 10px; "></div></div> </div> </div> </div> </a> </div><div class="act-blog-last-card"> <a class="act-blog-card"> <div class="act-blog-card-inner"> <div class="act-blog-card-img-box"> <div class="skeleton rounded-sm" style="height: 72px;border-radius: 16px;"></div> </div> <div class="act-blog-card-content"> <div class="skeleton w-[200px] h-15 rounded-pill"></div> <div class="act-blog-card-footer"> <div class="act-blog-card-footer-read-time"><div class="skeleton w-104 rounded-pill" style=" height: 11px; margin-top: 10px; "></div></div> </div> </div> </div> </a> </div></div></div> </div>`;
        const button = $(this);
        setTimeout(function (){
            SAJ('posts', {category: button.data('cat')}, function (res) {
                container.innerHTML = res.html;
                const box =  document.querySelector(".act-blogs-1st");
                box.querySelector('.act-our-services-carousel-head-title-content-title h5').innerHTML = `<strong>${res.name}</strong>`;
                box.querySelector('.act-our-services-carousel-head-title-content p').innerHTML = res.name_en;
                box.querySelector('.act-blogs-head-content-box a').href = res.link;

            });
        },200)
});
    $(document).on('click', '.Button-lp56', function (e) {
        document.body.classList.toggle("lock-body-scroll");
        const contienr = document.querySelector("#popper-root");
        const div = document.createElement("div");
        div.className = 'absolute';
        div.innerHTML = `<div class="ModalComponent__root-YwCAMP ModalComponent__root--desktop-JzGyNl ModalComponent__animation-JkgpfL ModalComponent__root--open-i5pSf7 ModalComponent__root--open__desktop-x1XDzU"><div class="ModalComponent__content-XqD1rL ModalComponent__animation-JkgpfL ModalComponent__content--desktop-o5IbOt ModalComponent__content--border-md-4G9biy overflow-auto " style="transform: translateY(50%);"> <div class="ModalComponent__header-l62jh_"><div class="d-flex ai-center AppHeader__headerBorder-sqCler  jc-between ProfileModal__header-QU8G4w"> <p class="text-h5 color-n-700 text-h5 text-color-neutral-700">تایید تلفن ثابت</p> <div class="d-flex pointer pointer mr-2" data-testid="close-wrapper"> <svg style="width: 24px; height: 24px; fill: var(--color-icon-high-emphasis);"> <path d="M12 11.0537C12 11.0537 16.2827 6.77342 17.8617 5.19523C18.1221 4.93492 18.5443 4.93492 18.8047 5.19523C19.0651 5.45553 19.0651 5.87753 18.8047 6.13783C17.2257 7.71602 12.9391 12 12.9391 12C12.9391 12 17.2257 16.284 18.8047 17.8622C19.0651 18.1225 19.0651 18.5445 18.8047 18.8047C18.5443 19.0651 18.1221 19.0651 17.8617 18.8048C16.2827 17.2266 12 12.9463 12 12.9463C12 12.9463 7.7173 17.2266 6.1383 18.8048C5.8779 19.0651 5.4557 19.0651 5.1953 18.8048C4.9349 18.5445 4.9349 18.1225 5.1953 17.8622C6.7743 16.284 11.0609 12 11.0609 12C11.0609 12 6.7743 7.71602 5.1953 6.13783C4.9349 5.87753 4.9349 5.45552 5.1953 5.19533C5.4557 4.93493 5.8779 4.93492 6.1383 5.19523C7.7173 6.77342 12 11.0537 12 11.0537Z"></path> </svg></div> </div> </div> <div class="uModalComponent__body-WvxQuY ModalComponent__body--default-sYpvC3"> <label class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--L7bcQ uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--normal--A6Ntt text-body-1 color-n-700 w-100"><p class="mb-2 color-n-700 text-body-1 mb-2" data-testid="form-label">شماره تلفن ثابت خود را وارد کنید </p><div class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame__input-container--D5edN px-2 d-flex ai-center"><section class="grow-1 text-body-2-c"><input class="px-2 TextField__input-_5fbdd text-subtitle w-100 TextField-e58168" type="text" name="value" placeholder="031123456789"></section></div></label> </div><div class="grow-1"></div><div class="ModalComponent__footerContainer-rb1vEj"><div class="ProfileModal__footer-IVQdrc"> <button class="relative d-flex ai-center user-select-none btn-wc51H8 text-button-2 btn--primary-uiqWij radius Button__medium-gIvke_ Button__filledPrimary-OvgwGb ProfileBase__button-jvi4aR ProfileBase__button__modal-O3kjhU Button-on45" data-testid="button-wrapper" type="button"><div class="d-flex ai-center jc-center relative grow-1">تایید</div></button></div> </div></div></div>`
        contienr.appendChild(div);
    });
    $(document).on('click', '.Button-on45', function (e) {
        e.preventDefault();
        e.stopPropagation();
        const button = $(this);
        var value = $("input[name='value']").val();
        if (value.length ==0 || value.length > 11){
            uikit__collections_error("تعداد کاراکتر درست نیست");
            return false;
        }
        SAJ('landline-phone',{value:value},function (res){
            if (res.status) {
                document.querySelector("#popper-root .ModalComponent__root-YwCAMP.ModalComponent__root--desktop-JzGyNl.ModalComponent__animation-JkgpfL.ModalComponent__root--open-i5pSf7.ModalComponent__root--open__desktop-x1XDzU").innerHTML = `<div class="ModalComponent__content-XqD1rL ModalComponent__animation-JkgpfL ModalComponent__content--desktop-o5IbOt ModalComponent__content--border-md-4G9biy overflow-auto " style="transform: translateY(50%);"> <div class="ModalComponent__header-l62jh_"><div class="d-flex ai-center AppHeader__headerBorder-sqCler  jc-between ProfileModal__header-QU8G4w"> <p class="text-h5 color-n-700 text-h5 text-color-neutral-700">تایید تلفن ثابت</p> <div class="d-flex pointer pointer mr-2" data-testid="close-wrapper"> <svg style="width: 24px; height: 24px; fill: var(--color-icon-high-emphasis);"> <path d="M12 11.0537C12 11.0537 16.2827 6.77342 17.8617 5.19523C18.1221 4.93492 18.5443 4.93492 18.8047 5.19523C19.0651 5.45553 19.0651 5.87753 18.8047 6.13783C17.2257 7.71602 12.9391 12 12.9391 12C12.9391 12 17.2257 16.284 18.8047 17.8622C19.0651 18.1225 19.0651 18.5445 18.8047 18.8047C18.5443 19.0651 18.1221 19.0651 17.8617 18.8048C16.2827 17.2266 12 12.9463 12 12.9463C12 12.9463 7.7173 17.2266 6.1383 18.8048C5.8779 19.0651 5.4557 19.0651 5.1953 18.8048C4.9349 18.5445 4.9349 18.1225 5.1953 17.8622C6.7743 16.284 11.0609 12 11.0609 12C11.0609 12 6.7743 7.71602 5.1953 6.13783C4.9349 5.87753 4.9349 5.45552 5.1953 5.19533C5.4557 4.93493 5.8779 4.93492 6.1383 5.19523C7.7173 6.77342 12 11.0537 12 11.0537Z"></path> </svg></div> </div> </div> <div class="uModalComponent__body-WvxQuY ModalComponent__body--default-sYpvC3"> <label class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--L7bcQ uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--normal--A6Ntt text-body-1 color-n-700 w-100"><p class="mb-2 color-n-700 text-body-1 mb-2" data-testid="form-label">کد otp را وارد کنید</p><div class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame__input-container--D5edN px-2 d-flex ai-center"><section class="grow-1 text-body-2-c"><input class="px-2 TextField__input-_5fbdd text-subtitle w-100 TextField-e58168" type="number" name="otp"><input class="hidden" type="text" name="value" value="${value}"></section></div></label> </div><div class="grow-1"></div><div class="ModalComponent__footerContainer-rb1vEj"><div class="ProfileModal__footer-IVQdrc"> <button class="relative d-flex ai-center user-select-none btn-wc51H8 text-button-2 btn--primary-uiqWij radius Button__medium-gIvke_ Button__filledPrimary-OvgwGb ProfileBase__button-jvi4aR ProfileBase__button__modal-O3kjhU Button-oo45" data-testid="button-wrapper" type="button"><div class="d-flex ai-center jc-center relative grow-1">تایید</div></button></div> </div></div>`;
            }else {
                if(res.close){
                    closePup(button);
                }
                uikit__collections_error(res.message);
            }
        },'v2')
    });
    $(document).on('click', '.Button-con45', function (e) {
        e.preventDefault();
        e.stopPropagation();
        const button = $(this);
        const originalHTML = button.html();
        button.html(`<div class="d-flex ai-center jc-center relative grow-1"> <div class="uikit-atomic-Button-Button-module__Loading--jNJ_Z" data-testid="button-loading"> <div></div> </div> </div>`);
        var value = $("input[name='value']").val();
        if (value.length ==0 || value.length > 11){
            uikit__collections_error("تعداد کاراکتر درست نیست");
            return false;
        }
        SAJ('landline-phone',{value:value},function (res){
            button.html(originalHTML);
            if (res.status) {
                document.querySelector(".verification-vb65").innerHTML = `<label class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--L7bcQ uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--normal--A6Ntt text-body-1 color-n-700 w-100"><p class="mb-2 color-n-700 text-body-1 mb-2" data-testid="form-label">کد otp را وارد کنید</p><div class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame__input-container--D5edN px-2 d-flex ai-center"><section class="grow-1 text-body-2-c"><input class="px-2 TextField__input-_5fbdd text-subtitle w-100 TextField-e58168" type="number" name="otp"><input class="hidden" type="text" name="value" value="${value}"></section></div></label><div class="d-flex justify-end mt-3"> <button class="relative d-flex ai-center user-select-none btn-wc51H8 text-button-2 btn--primary-uiqWij radius Button__medium-gIvke_ Button__filledPrimary-OvgwGb ProfileBase__button-jvi4aR ProfileBase__button__modal-O3kjhU Button-coo45" data-testid="button-wrapper" type="button" style="width: 25%"><div class="d-flex ai-center jc-center relative grow-1">تایید</div></button></div>`;
            }else {
                uikit__collections_error(res.message);
            }
        },'v2')
    });
    $(document).on('click', '.Button-coo45', function (e) {
        e.preventDefault();
        e.stopPropagation();
        const button = $(this);
        const originalHTML = button.html();
        button.html(`<div class="d-flex ai-center jc-center relative grow-1"> <div class="uikit-atomic-Button-Button-module__Loading--jNJ_Z" data-testid="button-loading"> <div></div> </div> </div>`);
        var otp = $("input[name='otp']").val();
        var value = $("input[name='value']").val();
        if (otp.length ==0 ){
            uikit__collections_error("کد را هنوز وارد نکرده اید");
            return false;
        }
        SAJ('otp',{value:value,otp:otp},function (res){
            button.html(originalHTML);
            if (res.status) {
                uikit__collections_success("شماره تلفن ثابت تایید شد");
                ajaxLoad(window.location.href, true);
                setTimeout(function (){
                    timerUpdate();
                },1000);
            }else{
                if (res.closed){
                    ajaxLoad(window.location.href, false);
                }
                uikit__collections_error(res.message);
            }
        },'v2')
    });
    $(document).on('click', '.Button-oo45', function (e) {
        e.preventDefault();
        e.stopPropagation();
        var button = $(this);
        var otp = $("input[name='otp']").val();
        var value = $("input[name='value']").val();
        if (otp.length ==0 ){
            uikit__collections_error("کد را هنوز وارد نکرده اید");
            return false;
        }
        SAJ('otp',{value:value,otp:otp},function (res){
            if (res.status) {
                uikit__collections_success("شماره تلفن ثابت تایید شد");
                closePup(button);
            }else{
                if (res.closed){
                    closePup(button);
                }
                uikit__collections_error(res.message);
            }
        },'v2')
    });
    $(document).on('click', '.act-filter-link', function(e){
        e.preventDefault();
        e.stopPropagation();

        const box  = document.querySelector('.act-shop-products-grid.act-cols-2');
        box.innerHTML = `<div class="act-new-service-card"> <div class="act-new-service-card-inner"> <div> <div class="act-new-service-card-inner-top"> <div class="act-new-service-card-inner-top-img-box" style=" width: 100%; "> <div class="skeleton rounded-sm" style=" height: 135px; border-radius: 16px; "></div> </div> <div class="act-new-service-card-inner-top-txt-box"> <div class="skeleton w-[200px] h-15 rounded-pill"></div> <div class="flex justify-between"> <div class="flex"> <div class="skeleton w-104 h-36 rounded"></div> </div> <div class="skeleton w-104 h-36 rounded"></div> </div> <div class="skeleton w-92 h-14 rounded-pill"></div> </div> </div> </div> <div> <div class="act-product-card-footer"> <div class="skeleton w-104 h-36 rounded"></div> <div class="skeleton h-36 rounded" style=" width: 70px; "></div> </div> <div class="skeleton h-48 rounded mt-3"></div> </div> </div> </div><div class="act-new-service-card"> <div class="act-new-service-card-inner"> <div> <div class="act-new-service-card-inner-top"> <div class="act-new-service-card-inner-top-img-box" style=" width: 100%; "> <div class="skeleton rounded-sm" style=" height: 135px; border-radius: 16px; "></div> </div> <div class="act-new-service-card-inner-top-txt-box"> <div class="skeleton w-[200px] h-15 rounded-pill"></div> <div class="flex justify-between"> <div class="flex"> <div class="skeleton w-104 h-36 rounded"></div> </div> <div class="skeleton w-104 h-36 rounded"></div> </div> <div class="skeleton w-92 h-14 rounded-pill"></div> </div> </div> </div> <div> <div class="act-product-card-footer"> <div class="skeleton w-104 h-36 rounded"></div> <div class="skeleton h-36 rounded" style=" width: 70px; "></div> </div> <div class="skeleton h-48 rounded mt-3"></div> </div> </div> </div><div class="act-new-service-card"> <div class="act-new-service-card-inner"> <div> <div class="act-new-service-card-inner-top"> <div class="act-new-service-card-inner-top-img-box" style=" width: 100%; "> <div class="skeleton rounded-sm" style=" height: 135px; border-radius: 16px; "></div> </div> <div class="act-new-service-card-inner-top-txt-box"> <div class="skeleton w-[200px] h-15 rounded-pill"></div> <div class="flex justify-between"> <div class="flex"> <div class="skeleton w-104 h-36 rounded"></div> </div> <div class="skeleton w-104 h-36 rounded"></div> </div> <div class="skeleton w-92 h-14 rounded-pill"></div> </div> </div> </div> <div> <div class="act-product-card-footer"> <div class="skeleton w-104 h-36 rounded"></div> <div class="skeleton h-36 rounded" style=" width: 70px; "></div> </div> <div class="skeleton h-48 rounded mt-3"></div> </div> </div> </div><div class="act-new-service-card"> <div class="act-new-service-card-inner"> <div> <div class="act-new-service-card-inner-top"> <div class="act-new-service-card-inner-top-img-box" style=" width: 100%; "> <div class="skeleton rounded-sm" style=" height: 135px; border-radius: 16px; "></div> </div> <div class="act-new-service-card-inner-top-txt-box"> <div class="skeleton w-[200px] h-15 rounded-pill"></div> <div class="flex justify-between"> <div class="flex"> <div class="skeleton w-104 h-36 rounded"></div> </div> <div class="skeleton w-104 h-36 rounded"></div> </div> <div class="skeleton w-92 h-14 rounded-pill"></div> </div> </div> </div> <div> <div class="act-product-card-footer"> <div class="skeleton w-104 h-36 rounded"></div> <div class="skeleton h-36 rounded" style=" width: 70px; "></div> </div> <div class="skeleton h-48 rounded mt-3"></div> </div> </div> </div>`;

        const $el  = $(this);
        $el.toggleClass('active');
        const id = $("#main_id").data('id');
        const key = $("#main_id").data('key');
        const newFilters = {};
        $('.act-filter-link.active').each(function(){
            const s = $(this).data('id');
            if (!newFilters['id']) newFilters['id'] = [];
            newFilters['id'].push(s);
        });
        $('.act-filter-region.active').each(function(){
            const s = $(this).data('id');
            if (!newFilters['region']) newFilters['region'] = [];
            newFilters['region'].push(s);
        });
        var min_price = unformatPrice($(".act-price-from").val());
        var max_price = unformatPrice($(".act-price-to").val());
        if (!isNaN(id)) {
            SAJ('filters', {
                newFilters: newFilters,
                id: id,
                min_price: min_price,
                max_price: max_price
            }, function (res) {
                if (res.status) {
                    $(".flex.flex-col.gap-6").html(res.html);
                    timerlpt();
                    Tooltip();
                    timerlpts();
                }
            }, 'v2')
        }else if(key){
            SAJ('filters', {
                newFilters: newFilters,
                key: key,
                min_price: min_price,
                max_price: max_price
            }, function (res) {
                if (res.status) {
                    $(".flex.flex-col.gap-6").html(res.html);
                    timerlpt();
                    Tooltip();
                    timerlpts();
                }
            }, 'v2')
        }
    });
    $(document).on('click', '.act-filter-region', function(e){
        e.preventDefault();
        e.stopPropagation();

        const box  = document.querySelector('.act-shop-products-grid.act-cols-2');
        box.innerHTML = `<div class="act-new-service-card"> <div class="act-new-service-card-inner"> <div> <div class="act-new-service-card-inner-top"> <div class="act-new-service-card-inner-top-img-box" style=" width: 100%; "> <div class="skeleton rounded-sm" style=" height: 135px; border-radius: 16px; "></div> </div> <div class="act-new-service-card-inner-top-txt-box"> <div class="skeleton w-[200px] h-15 rounded-pill"></div> <div class="flex justify-between"> <div class="flex"> <div class="skeleton w-104 h-36 rounded"></div> </div> <div class="skeleton w-104 h-36 rounded"></div> </div> <div class="skeleton w-92 h-14 rounded-pill"></div> </div> </div> </div> <div> <div class="act-product-card-footer"> <div class="skeleton w-104 h-36 rounded"></div> <div class="skeleton h-36 rounded" style=" width: 70px; "></div> </div> <div class="skeleton h-48 rounded mt-3"></div> </div> </div> </div><div class="act-new-service-card"> <div class="act-new-service-card-inner"> <div> <div class="act-new-service-card-inner-top"> <div class="act-new-service-card-inner-top-img-box" style=" width: 100%; "> <div class="skeleton rounded-sm" style=" height: 135px; border-radius: 16px; "></div> </div> <div class="act-new-service-card-inner-top-txt-box"> <div class="skeleton w-[200px] h-15 rounded-pill"></div> <div class="flex justify-between"> <div class="flex"> <div class="skeleton w-104 h-36 rounded"></div> </div> <div class="skeleton w-104 h-36 rounded"></div> </div> <div class="skeleton w-92 h-14 rounded-pill"></div> </div> </div> </div> <div> <div class="act-product-card-footer"> <div class="skeleton w-104 h-36 rounded"></div> <div class="skeleton h-36 rounded" style=" width: 70px; "></div> </div> <div class="skeleton h-48 rounded mt-3"></div> </div> </div> </div><div class="act-new-service-card"> <div class="act-new-service-card-inner"> <div> <div class="act-new-service-card-inner-top"> <div class="act-new-service-card-inner-top-img-box" style=" width: 100%; "> <div class="skeleton rounded-sm" style=" height: 135px; border-radius: 16px; "></div> </div> <div class="act-new-service-card-inner-top-txt-box"> <div class="skeleton w-[200px] h-15 rounded-pill"></div> <div class="flex justify-between"> <div class="flex"> <div class="skeleton w-104 h-36 rounded"></div> </div> <div class="skeleton w-104 h-36 rounded"></div> </div> <div class="skeleton w-92 h-14 rounded-pill"></div> </div> </div> </div> <div> <div class="act-product-card-footer"> <div class="skeleton w-104 h-36 rounded"></div> <div class="skeleton h-36 rounded" style=" width: 70px; "></div> </div> <div class="skeleton h-48 rounded mt-3"></div> </div> </div> </div><div class="act-new-service-card"> <div class="act-new-service-card-inner"> <div> <div class="act-new-service-card-inner-top"> <div class="act-new-service-card-inner-top-img-box" style=" width: 100%; "> <div class="skeleton rounded-sm" style=" height: 135px; border-radius: 16px; "></div> </div> <div class="act-new-service-card-inner-top-txt-box"> <div class="skeleton w-[200px] h-15 rounded-pill"></div> <div class="flex justify-between"> <div class="flex"> <div class="skeleton w-104 h-36 rounded"></div> </div> <div class="skeleton w-104 h-36 rounded"></div> </div> <div class="skeleton w-92 h-14 rounded-pill"></div> </div> </div> </div> <div> <div class="act-product-card-footer"> <div class="skeleton w-104 h-36 rounded"></div> <div class="skeleton h-36 rounded" style=" width: 70px; "></div> </div> <div class="skeleton h-48 rounded mt-3"></div> </div> </div> </div>`;
        const $el  = $(this);
        $el.toggleClass('active');
        $(`.button-ac45[data-id='${$el.data("id")}']`).toggleClass('active');
        const id = $("#main_id").data('id');
        const key = $("#main_id").data('key');
        const newFilters = {};
        $('.act-filter-region.active').each(function(){
            const s = $(this).data('id');
            if (!newFilters['region']) newFilters['region'] = [];
            newFilters['region'].push(s);
        });
        var min_price = unformatPrice($(".act-price-from").val());
        var max_price = unformatPrice($(".act-price-to").val());
        if (!isNaN(id)){
            SAJ('filters',{newFilters:newFilters,id:id,min_price:min_price,max_price:max_price},function (res){
                if (res.status){
                    $(".flex.flex-col.gap-6").html(res.html);
                    timerlpt();
                    Tooltip();
                    timerlpts();
                }
            },'v2')
        }else if(key){
            SAJ('filters',{newFilters:newFilters,key:key,min_price:min_price,max_price:max_price},function (res){
                if (res.status){
                    $(".flex.flex-col.gap-6").html(res.html);
                    timerlpt();
                    Tooltip();
                    timerlpts();
                }
            },'v2')
        }
    });
    $(document).on('click', '.button-ac85', function(e){
        e.preventDefault();
        e.stopPropagation();

        const box  = document.querySelector('.act-shop-products-grid.act-cols-2');
        box.innerHTML = `<div class="act-new-service-card"> <div class="act-new-service-card-inner"> <div> <div class="act-new-service-card-inner-top"> <div class="act-new-service-card-inner-top-img-box" style=" width: 100%; "> <div class="skeleton rounded-sm" style=" height: 135px; border-radius: 16px; "></div> </div> <div class="act-new-service-card-inner-top-txt-box"> <div class="skeleton w-[200px] h-15 rounded-pill"></div> <div class="flex justify-between"> <div class="flex"> <div class="skeleton w-104 h-36 rounded"></div> </div> <div class="skeleton w-104 h-36 rounded"></div> </div> <div class="skeleton w-92 h-14 rounded-pill"></div> </div> </div> </div> <div> <div class="act-product-card-footer"> <div class="skeleton w-104 h-36 rounded"></div> <div class="skeleton h-36 rounded" style=" width: 70px; "></div> </div> <div class="skeleton h-48 rounded mt-3"></div> </div> </div> </div><div class="act-new-service-card"> <div class="act-new-service-card-inner"> <div> <div class="act-new-service-card-inner-top"> <div class="act-new-service-card-inner-top-img-box" style=" width: 100%; "> <div class="skeleton rounded-sm" style=" height: 135px; border-radius: 16px; "></div> </div> <div class="act-new-service-card-inner-top-txt-box"> <div class="skeleton w-[200px] h-15 rounded-pill"></div> <div class="flex justify-between"> <div class="flex"> <div class="skeleton w-104 h-36 rounded"></div> </div> <div class="skeleton w-104 h-36 rounded"></div> </div> <div class="skeleton w-92 h-14 rounded-pill"></div> </div> </div> </div> <div> <div class="act-product-card-footer"> <div class="skeleton w-104 h-36 rounded"></div> <div class="skeleton h-36 rounded" style=" width: 70px; "></div> </div> <div class="skeleton h-48 rounded mt-3"></div> </div> </div> </div><div class="act-new-service-card"> <div class="act-new-service-card-inner"> <div> <div class="act-new-service-card-inner-top"> <div class="act-new-service-card-inner-top-img-box" style=" width: 100%; "> <div class="skeleton rounded-sm" style=" height: 135px; border-radius: 16px; "></div> </div> <div class="act-new-service-card-inner-top-txt-box"> <div class="skeleton w-[200px] h-15 rounded-pill"></div> <div class="flex justify-between"> <div class="flex"> <div class="skeleton w-104 h-36 rounded"></div> </div> <div class="skeleton w-104 h-36 rounded"></div> </div> <div class="skeleton w-92 h-14 rounded-pill"></div> </div> </div> </div> <div> <div class="act-product-card-footer"> <div class="skeleton w-104 h-36 rounded"></div> <div class="skeleton h-36 rounded" style=" width: 70px; "></div> </div> <div class="skeleton h-48 rounded mt-3"></div> </div> </div> </div><div class="act-new-service-card"> <div class="act-new-service-card-inner"> <div> <div class="act-new-service-card-inner-top"> <div class="act-new-service-card-inner-top-img-box" style=" width: 100%; "> <div class="skeleton rounded-sm" style=" height: 135px; border-radius: 16px; "></div> </div> <div class="act-new-service-card-inner-top-txt-box"> <div class="skeleton w-[200px] h-15 rounded-pill"></div> <div class="flex justify-between"> <div class="flex"> <div class="skeleton w-104 h-36 rounded"></div> </div> <div class="skeleton w-104 h-36 rounded"></div> </div> <div class="skeleton w-92 h-14 rounded-pill"></div> </div> </div> </div> <div> <div class="act-product-card-footer"> <div class="skeleton w-104 h-36 rounded"></div> <div class="skeleton h-36 rounded" style=" width: 70px; "></div> </div> <div class="skeleton h-48 rounded mt-3"></div> </div> </div> </div>`;
        const $el  = $(this);
        $el.toggleClass('active');
        $(`.act-filter-region[data-id='${$el.data("id")}']`).toggleClass('active');
        const id = $("#main_id").data('id');
        const key = $("#main_id").data('key');
        const newFilters = {};
        $('.act-filter-region.active').each(function(){
            const s = $(this).data('id');
            if (!newFilters['region']) newFilters['region'] = [];
            newFilters['region'].push(s);
        });
        var min_price = unformatPrice($(".act-price-from").val());
        var max_price = unformatPrice($(".act-price-to").val());
        if (!isNaN(id)){
            SAJ('filters',{newFilters:newFilters,id:id,min_price:min_price,max_price:max_price},function (res){
                if (res.status){
                    $(".flex.flex-col.gap-6").html(res.html);
                    timerlpt();
                    Tooltip();
                    timerlpts();
                }
            },'v2')
        }else if(key){
            SAJ('filters',{newFilters:newFilters,key:key,min_price:min_price,max_price:max_price},function (res){
                if (res.status){
                    $(".flex.flex-col.gap-6").html(res.html);
                    timerlpt();
                    Tooltip();
                    timerlpts();
                }
            },'v2')
        }
    });
    $(document).on('click', '.a--page-numbers', function(e){
        e.preventDefault();
        e.stopPropagation();

        const page = $(this).data('page');
        if (page) {
            const box  = document.querySelector('.act-shop-products-grid.act-cols-2');
            box.innerHTML = `<div class="act-new-service-card"> <div class="act-new-service-card-inner"> <div> <div class="act-new-service-card-inner-top"> <div class="act-new-service-card-inner-top-img-box" style=" width: 100%; "> <div class="skeleton rounded-sm" style=" height: 135px; border-radius: 16px; "></div> </div> <div class="act-new-service-card-inner-top-txt-box"> <div class="skeleton w-[200px] h-15 rounded-pill"></div> <div class="flex justify-between"> <div class="flex"> <div class="skeleton w-104 h-36 rounded"></div> </div> <div class="skeleton w-104 h-36 rounded"></div> </div> <div class="skeleton w-92 h-14 rounded-pill"></div> </div> </div> </div> <div> <div class="act-product-card-footer"> <div class="skeleton w-104 h-36 rounded"></div> <div class="skeleton h-36 rounded" style=" width: 70px; "></div> </div> <div class="skeleton h-48 rounded mt-3"></div> </div> </div> </div><div class="act-new-service-card"> <div class="act-new-service-card-inner"> <div> <div class="act-new-service-card-inner-top"> <div class="act-new-service-card-inner-top-img-box" style=" width: 100%; "> <div class="skeleton rounded-sm" style=" height: 135px; border-radius: 16px; "></div> </div> <div class="act-new-service-card-inner-top-txt-box"> <div class="skeleton w-[200px] h-15 rounded-pill"></div> <div class="flex justify-between"> <div class="flex"> <div class="skeleton w-104 h-36 rounded"></div> </div> <div class="skeleton w-104 h-36 rounded"></div> </div> <div class="skeleton w-92 h-14 rounded-pill"></div> </div> </div> </div> <div> <div class="act-product-card-footer"> <div class="skeleton w-104 h-36 rounded"></div> <div class="skeleton h-36 rounded" style=" width: 70px; "></div> </div> <div class="skeleton h-48 rounded mt-3"></div> </div> </div> </div><div class="act-new-service-card"> <div class="act-new-service-card-inner"> <div> <div class="act-new-service-card-inner-top"> <div class="act-new-service-card-inner-top-img-box" style=" width: 100%; "> <div class="skeleton rounded-sm" style=" height: 135px; border-radius: 16px; "></div> </div> <div class="act-new-service-card-inner-top-txt-box"> <div class="skeleton w-[200px] h-15 rounded-pill"></div> <div class="flex justify-between"> <div class="flex"> <div class="skeleton w-104 h-36 rounded"></div> </div> <div class="skeleton w-104 h-36 rounded"></div> </div> <div class="skeleton w-92 h-14 rounded-pill"></div> </div> </div> </div> <div> <div class="act-product-card-footer"> <div class="skeleton w-104 h-36 rounded"></div> <div class="skeleton h-36 rounded" style=" width: 70px; "></div> </div> <div class="skeleton h-48 rounded mt-3"></div> </div> </div> </div><div class="act-new-service-card"> <div class="act-new-service-card-inner"> <div> <div class="act-new-service-card-inner-top"> <div class="act-new-service-card-inner-top-img-box" style=" width: 100%; "> <div class="skeleton rounded-sm" style=" height: 135px; border-radius: 16px; "></div> </div> <div class="act-new-service-card-inner-top-txt-box"> <div class="skeleton w-[200px] h-15 rounded-pill"></div> <div class="flex justify-between"> <div class="flex"> <div class="skeleton w-104 h-36 rounded"></div> </div> <div class="skeleton w-104 h-36 rounded"></div> </div> <div class="skeleton w-92 h-14 rounded-pill"></div> </div> </div> </div> <div> <div class="act-product-card-footer"> <div class="skeleton w-104 h-36 rounded"></div> <div class="skeleton h-36 rounded" style=" width: 70px; "></div> </div> <div class="skeleton h-48 rounded mt-3"></div> </div> </div> </div>`;            const newFilters = {};
            $('.act-filter-link.active').each(function () {
                const s = $(this).data('id');
                if (!newFilters['id']) newFilters['id'] = [];
                newFilters['id'].push(s);
            });
            $('.act-filter-region.active').each(function(){
                const s = $(this).data('id');
                if (!newFilters['region']) newFilters['region'] = [];
                newFilters['region'].push(s);
            });
            var min_price = unformatPrice($(".act-price-from").val());
            var max_price = unformatPrice($(".act-price-to").val());
            const key = $("#main_id").data('key');
            console.log(key);
            if (key) {
                SAJ('filters', {
                    newFilters: newFilters,
                    page: page,
                    key: key,
                    min_price: min_price,
                    max_price: max_price
                }, function (res) {
                    if (res.status) {
                        $(".flex.flex-col.gap-6").html(res.html);
                        timerlpt();
                        Tooltip();
                        timerlpts();
                    }
                }, 'v2')
            }else{
                SAJ('filters', {
                    newFilters: newFilters,
                    page: page,
                    min_price: min_price,
                    max_price: max_price
                }, function (res) {
                    if (res.status) {
                        $(".flex.flex-col.gap-6").html(res.html);
                        timerlpt();
                        Tooltip();
                        timerlpts();
                    }
                }, 'v2')
            }
        }
    });
    $(document).on('input','.act-price-from, .act-price-to', function(e){
        e.preventDefault();
        e.stopPropagation();
        const cursorPos = this.selectionStart;
        const raw = unformatPrice($(this).val());
        $(this).val(formatPrice(raw));
        this.setSelectionRange(cursorPos, cursorPos);
        clearTimeout(timeoutId);
        timeoutId = setTimeout(function(){
            const box  = document.querySelector('.act-shop-products-grid.act-cols-2');
            box.innerHTML = `<div class="act-new-service-card"> <div class="act-new-service-card-inner"> <div> <div class="act-new-service-card-inner-top"> <div class="act-new-service-card-inner-top-img-box" style=" width: 100%; "> <div class="skeleton rounded-sm" style=" height: 135px; border-radius: 16px; "></div> </div> <div class="act-new-service-card-inner-top-txt-box"> <div class="skeleton w-[200px] h-15 rounded-pill"></div> <div class="flex justify-between"> <div class="flex"> <div class="skeleton w-104 h-36 rounded"></div> </div> <div class="skeleton w-104 h-36 rounded"></div> </div> <div class="skeleton w-92 h-14 rounded-pill"></div> </div> </div> </div> <div> <div class="act-product-card-footer"> <div class="skeleton w-104 h-36 rounded"></div> <div class="skeleton h-36 rounded" style=" width: 70px; "></div> </div> <div class="skeleton h-48 rounded mt-3"></div> </div> </div> </div><div class="act-new-service-card"> <div class="act-new-service-card-inner"> <div> <div class="act-new-service-card-inner-top"> <div class="act-new-service-card-inner-top-img-box" style=" width: 100%; "> <div class="skeleton rounded-sm" style=" height: 135px; border-radius: 16px; "></div> </div> <div class="act-new-service-card-inner-top-txt-box"> <div class="skeleton w-[200px] h-15 rounded-pill"></div> <div class="flex justify-between"> <div class="flex"> <div class="skeleton w-104 h-36 rounded"></div> </div> <div class="skeleton w-104 h-36 rounded"></div> </div> <div class="skeleton w-92 h-14 rounded-pill"></div> </div> </div> </div> <div> <div class="act-product-card-footer"> <div class="skeleton w-104 h-36 rounded"></div> <div class="skeleton h-36 rounded" style=" width: 70px; "></div> </div> <div class="skeleton h-48 rounded mt-3"></div> </div> </div> </div><div class="act-new-service-card"> <div class="act-new-service-card-inner"> <div> <div class="act-new-service-card-inner-top"> <div class="act-new-service-card-inner-top-img-box" style=" width: 100%; "> <div class="skeleton rounded-sm" style=" height: 135px; border-radius: 16px; "></div> </div> <div class="act-new-service-card-inner-top-txt-box"> <div class="skeleton w-[200px] h-15 rounded-pill"></div> <div class="flex justify-between"> <div class="flex"> <div class="skeleton w-104 h-36 rounded"></div> </div> <div class="skeleton w-104 h-36 rounded"></div> </div> <div class="skeleton w-92 h-14 rounded-pill"></div> </div> </div> </div> <div> <div class="act-product-card-footer"> <div class="skeleton w-104 h-36 rounded"></div> <div class="skeleton h-36 rounded" style=" width: 70px; "></div> </div> <div class="skeleton h-48 rounded mt-3"></div> </div> </div> </div><div class="act-new-service-card"> <div class="act-new-service-card-inner"> <div> <div class="act-new-service-card-inner-top"> <div class="act-new-service-card-inner-top-img-box" style=" width: 100%; "> <div class="skeleton rounded-sm" style=" height: 135px; border-radius: 16px; "></div> </div> <div class="act-new-service-card-inner-top-txt-box"> <div class="skeleton w-[200px] h-15 rounded-pill"></div> <div class="flex justify-between"> <div class="flex"> <div class="skeleton w-104 h-36 rounded"></div> </div> <div class="skeleton w-104 h-36 rounded"></div> </div> <div class="skeleton w-92 h-14 rounded-pill"></div> </div> </div> </div> <div> <div class="act-product-card-footer"> <div class="skeleton w-104 h-36 rounded"></div> <div class="skeleton h-36 rounded" style=" width: 70px; "></div> </div> <div class="skeleton h-48 rounded mt-3"></div> </div> </div> </div>`;
            const id = $("#main_id").data('id');
            const key = $("#main_id").data('key');
            const newFilters = {};
            $('.act-filter-link.active').each(function(){
                const s = $(this).data('id');
                if (!newFilters['id']) newFilters['id'] = [];
                newFilters['id'].push(s);
            });
            $('.act-filter-region.active').each(function(){
                const s = $(this).data('id');
                if (!newFilters['region']) newFilters['region'] = [];
                newFilters['region'].push(s);
            });
            var min_price = unformatPrice($(".act-price-from").val());
            var max_price = unformatPrice($(".act-price-to").val());
            if (!isNaN(id)){
                SAJ('filters',{newFilters:newFilters,id:id,min_price:min_price,max_price:max_price},function (res){
                    if (res.status){
                        $(".flex.flex-col.gap-6").html(res.html);
                        timerlpt();
                        Tooltip();
                        timerlpts();
                    }
                },'v2')
            }else if (key){
                SAJ('filters',{newFilters:newFilters,key:key,min_price:min_price,max_price:max_price},function (res){
                    if (res.status){
                        $(".flex.flex-col.gap-6").html(res.html);
                        timerlpt();
                        Tooltip();
                        timerlpts();
                    }
                },'v2')
            }
        }, 500);

    });

    $(document).on('click','.act-price-reset', function(e){
        e.preventDefault();
        e.stopPropagation();

        const box  = document.querySelector('.act-shop-products-grid.act-cols-2');
        box.innerHTML = `<div class="act-new-service-card"> <div class="act-new-service-card-inner"> <div> <div class="act-new-service-card-inner-top"> <div class="act-new-service-card-inner-top-img-box" style=" width: 100%; "> <div class="skeleton rounded-sm" style=" height: 135px; border-radius: 16px; "></div> </div> <div class="act-new-service-card-inner-top-txt-box"> <div class="skeleton w-[200px] h-15 rounded-pill"></div> <div class="flex justify-between"> <div class="flex"> <div class="skeleton w-104 h-36 rounded"></div> </div> <div class="skeleton w-104 h-36 rounded"></div> </div> <div class="skeleton w-92 h-14 rounded-pill"></div> </div> </div> </div> <div> <div class="act-product-card-footer"> <div class="skeleton w-104 h-36 rounded"></div> <div class="skeleton h-36 rounded" style=" width: 70px; "></div> </div> <div class="skeleton h-48 rounded mt-3"></div> </div> </div> </div><div class="act-new-service-card"> <div class="act-new-service-card-inner"> <div> <div class="act-new-service-card-inner-top"> <div class="act-new-service-card-inner-top-img-box" style=" width: 100%; "> <div class="skeleton rounded-sm" style=" height: 135px; border-radius: 16px; "></div> </div> <div class="act-new-service-card-inner-top-txt-box"> <div class="skeleton w-[200px] h-15 rounded-pill"></div> <div class="flex justify-between"> <div class="flex"> <div class="skeleton w-104 h-36 rounded"></div> </div> <div class="skeleton w-104 h-36 rounded"></div> </div> <div class="skeleton w-92 h-14 rounded-pill"></div> </div> </div> </div> <div> <div class="act-product-card-footer"> <div class="skeleton w-104 h-36 rounded"></div> <div class="skeleton h-36 rounded" style=" width: 70px; "></div> </div> <div class="skeleton h-48 rounded mt-3"></div> </div> </div> </div><div class="act-new-service-card"> <div class="act-new-service-card-inner"> <div> <div class="act-new-service-card-inner-top"> <div class="act-new-service-card-inner-top-img-box" style=" width: 100%; "> <div class="skeleton rounded-sm" style=" height: 135px; border-radius: 16px; "></div> </div> <div class="act-new-service-card-inner-top-txt-box"> <div class="skeleton w-[200px] h-15 rounded-pill"></div> <div class="flex justify-between"> <div class="flex"> <div class="skeleton w-104 h-36 rounded"></div> </div> <div class="skeleton w-104 h-36 rounded"></div> </div> <div class="skeleton w-92 h-14 rounded-pill"></div> </div> </div> </div> <div> <div class="act-product-card-footer"> <div class="skeleton w-104 h-36 rounded"></div> <div class="skeleton h-36 rounded" style=" width: 70px; "></div> </div> <div class="skeleton h-48 rounded mt-3"></div> </div> </div> </div><div class="act-new-service-card"> <div class="act-new-service-card-inner"> <div> <div class="act-new-service-card-inner-top"> <div class="act-new-service-card-inner-top-img-box" style=" width: 100%; "> <div class="skeleton rounded-sm" style=" height: 135px; border-radius: 16px; "></div> </div> <div class="act-new-service-card-inner-top-txt-box"> <div class="skeleton w-[200px] h-15 rounded-pill"></div> <div class="flex justify-between"> <div class="flex"> <div class="skeleton w-104 h-36 rounded"></div> </div> <div class="skeleton w-104 h-36 rounded"></div> </div> <div class="skeleton w-92 h-14 rounded-pill"></div> </div> </div> </div> <div> <div class="act-product-card-footer"> <div class="skeleton w-104 h-36 rounded"></div> <div class="skeleton h-36 rounded" style=" width: 70px; "></div> </div> <div class="skeleton h-48 rounded mt-3"></div> </div> </div> </div>`;

        $('.act-price-from').val(formatPrice(0));
        $('.act-price-to').val(formatPrice(32500000));
        const id = $("#main_id").data('id');
        const key = $("#main_id").data('key');
        const newFilters = {};
        $('.act-filter-link.active').each(function(){
            const s = $(this).data('id');
            if (!newFilters['id']) newFilters['id'] = [];
            newFilters['id'].push(s);
        });
        $('.act-filter-region.active').each(function(){
            const s = $(this).data('id');
            if (!newFilters['region']) newFilters['region'] = [];
            newFilters['region'].push(s);
        });
        var min_price = unformatPrice($(".act-price-from").val());
        var max_price = unformatPrice($(".act-price-to").val());
        if (!isNaN(id)){
            SAJ('filters',{newFilters:newFilters,id:id,min_price:min_price,max_price:max_price},function (res){
                if (res.status){
                    $(".flex.flex-col.gap-6").html(res.html);
                    timerlpt();
                    Tooltip();
                    timerlpts();
                }
            },'v2')
        }else if (key){
            SAJ('filters',{newFilters:newFilters,key:key,min_price:min_price,max_price:max_price},function (res){
                if (res.status){
                    $(".flex.flex-col.gap-6").html(res.html);
                    timerlpt();
                    Tooltip();
                    timerlpts();
                }
            },'v2')
        }
    });
    $(document).on('click', '.header-dashboard .inner', function(event) {
        event.stopPropagation();
        event.preventDefault();
        const verification = window.user.type ? '' : `<li>
                        <a class="flex items-center leading-2 tracking-tight relative transition-colors py-5 px-16 text-gray hover:text-dark link-ds54" href="${wpApiSettingsGiftMax.home}/profile/verification">
                        <div class="flex items-center justify-center w-24 h-24 ml-10 -mr-4"><i class="opacity-90 icon-verify text-[21px] pt-1"></i></div>
                        <span class="pt-4 grow font-normal text-sm">احراز هویت</span>
                        </a>
                        </li>`;
        const contienr = document.querySelector("#popper-root");
        const div = document.createElement("div");
        div.className = 'absolute';
        div.innerHTML = `<div class="bg-n-000 overflow-y-hidden radius-md Popper__popper-_MjEue Popper__popper--sm-O6ws1M shadow-modal border-200 FilterChips__zIndex-HJBa6n Popper__popper--animated-active-c4re2j" style=""><div class="bg_while overflow-auto menuUser" style="transform: translateY(50%);"><div class="pos-sticky top-0 bg_while z-1 d-flex jc-between ai-center py-2 px-4 FilterChips__cardHeader-r0RCCF"> <div class="flex items-center pt-24 pb-8"><div class="text-secondary font-bold tracking-tighter text-normal leading-xs pt-4">${window.user.fullName}</div><div class="badge text-2xs rounded-pill font-normal px-14 mr-8 inline-block">کاربر <span class="font-medium"> ${window.user.access} </span></div></div> <div class="d-flex pointer  pointer" data-testid="close-wrapper-_app"> <svg style="width: 24px; height: 24px; fill: var(--color-icon-high-emphasis);"> <path d="M12 11.0537C12 11.0537 16.2827 6.77342 17.8617 5.19523C18.1221 4.93492 18.5443 4.93492 18.8047 5.19523C19.0651 5.45553 19.0651 5.87753 18.8047 6.13783C17.2257 7.71602 12.9391 12 12.9391 12C12.9391 12 17.2257 16.284 18.8047 17.8622C19.0651 18.1225 19.0651 18.5445 18.8047 18.8047C18.5443 19.0651 18.1221 19.0651 17.8617 18.8048C16.2827 17.2266 12 12.9463 12 12.9463C12 12.9463 7.7173 17.2266 6.1383 18.8048C5.8779 19.0651 5.4557 19.0651 5.1953 18.8048C4.9349 18.5445 4.9349 18.1225 5.1953 17.8622C6.7743 16.284 11.0609 12 11.0609 12C11.0609 12 6.7743 7.71602 5.1953 6.13783C4.9349 5.87753 4.9349 5.45552 5.1953 5.19533C5.4557 4.93493 5.8779 4.93492 6.1383 5.19523C7.7173 6.77342 12 11.0537 12 11.0537Z"></path> </svg></div> </div><div class="py-2 cardBodyDesktop-FZT9Y2"> 
            <div class="h-fit-content">
                <ul class="pb-16 grow overflow-y-auto"><li>
                <a class="flex items-center leading-2 tracking-tight relative transition-colors py-5 px-16 text-gray hover:text-dark link-ds54" href="${wpApiSettingsGiftMax.home}/profile">
                <div class="flex items-center justify-center w-24 h-24 ml-10 -mr-4"><i class="opacity-90 icon-menu2 text-lg"></i></div>
                <span class="grow font-normal text-sm">داشبورد</span>
                </a>
                </li>
                <li>
                <a class="flex items-center leading-2 tracking-tight relative transition-colors py-5 px-16 text-gray hover:text-dark link-ds54" href="${wpApiSettingsGiftMax.home}/profile/orders">
                <div class="flex items-center justify-center w-24 h-24 ml-10 -mr-4"><i class="opacity-90 text-xl icon icon-order pb-2"></i></div>
                <span class="grow font-normal text-sm">سفارش های من</span>
                </a>
                </li>
                <li>
                <a class="flex items-center leading-2 tracking-tight relative transition-colors py-5 px-16 text-gray hover:text-dark link-ds54 !text-secondary" href="${wpApiSettingsGiftMax.home}/profile/list">
                <div class="flex items-center justify-center w-24 h-24 ml-10 -mr-4">
                <svg viewBox="0 0 24 24" style="width: 18px; fill: none; stroke: #000000a6; display: flex; justify-content: center; align-items: center; line-height: normal;">
                            <path d="M12.62 20.81C12.28 20.93 11.72 20.93 11.38 20.81C8.48 19.82 2 15.69 2 8.68998C2 5.59998 4.49 3.09998 7.56 3.09998C9.38 3.09998 10.99 3.97998 12 5.33998C13.01 3.97998 14.63 3.09998 16.44 3.09998C19.51 3.09998 22 5.59998 22 8.68998C22 15.69 15.52 19.82 12.62 20.81Z" fill="none" stroke="inherit" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                        </svg>
                        </div>
                        <span class="grow font-normal text-sm">لیست علاقه مندی ها</span>
                        </a>
                        </li>
                        <li>
                        <a class="flex items-center leading-2 tracking-tight relative transition-colors py-5 px-16 text-gray hover:text-dark link-ds54" href="${wpApiSettingsGiftMax.home}/profile/deliveries">
                        <div class="flex items-center justify-center w-24 h-24 ml-10 -mr-4"><i class="opacity-90 icon-flash text-[19px] pb-1"></i></div>
                        <span class="grow font-normal text-sm">کدهای تحویل&zwnj;شده</span>
                        </a>
                        </li>
                        <li>
                        <li>
                        <a class="flex items-center leading-2 tracking-tight relative transition-colors py-5 px-16 text-gray hover:text-dark link-ds54" href="${wpApiSettingsGiftMax.home}/profile/post">
                        <div class="flex items-center justify-center w-24 h-24 ml-10 -mr-4"><i class="opacity-90 icon-document text-[19px] pb-1"></i></div>
                        <span class="grow font-normal text-sm">ارسال مقاله</span>
                        </a>
                        </li>
                        <li>
                        <a class="flex items-center leading-2 tracking-tight relative transition-colors py-5 px-16 text-gray hover:text-dark link-ds54" href="${wpApiSettingsGiftMax.home}/profile/wallet">
                        <div class="flex items-center justify-center w-24 h-24 ml-10 -mr-4"><i class="opacity-90 icon-wallet text-[21px] pb-1"></i></div>
                        <span class="grow font-normal text-sm">کیف پول و امتیاز</span>
                        <span class="leading-1">
                        <div class="text-larger font-bold text-primary-dark tracking-tighter">  ${window.user.points} <span class="text-2xs text-gray font-medium">امتیاز</span></div>
                        </span>
                        </a>
                        </li>
                        <li>
                        <a class="flex items-center leading-2 tracking-tight relative transition-colors py-5 px-16 text-gray hover:text-dark link-ds54" href="${wpApiSettingsGiftMax.home}/ticket">
                        <div class="flex items-center justify-center w-24 h-24 ml-10 -mr-4"><i class="opacity-90 text-xl icon-support pt-2"></i></div>
                        <span class="grow font-normal text-sm">پشتیبانی</span>
                        </a>
                        </li>
                        ${verification}
                        <li>
                        <a class="flex items-center leading-2 tracking-tight relative transition-colors py-5 px-16 text-gray hover:text-dark link-ds54" href="${wpApiSettingsGiftMax.home}/profile/coupons">
                        <div class="flex items-center justify-center w-24 h-24 ml-10 -mr-4"><i class="opacity-90 text-xl icon-gift"></i></div>
                        <span class="grow font-normal text-sm">کد های تخفیف</span>
                        </a>
                        </li>
                           <li>
                        <a class="flex items-center leading-2 tracking-tight relative transition-colors py-5 px-16 text-gray hover:text-dark link-ds54" href="${wpApiSettingsGiftMax.home}/profile/cards">
                        <div class="flex items-center justify-center w-24 h-24 ml-10 -mr-4"><i class="opacity-90 text-xl icon-card"></i></div>
                        <span class="grow font-normal text-sm">کارت&zwnj;های بانکی</span>
                        </a>
                        </li>
                        <li>
                        <a class="flex items-center leading-2 tracking-tight relative transition-colors py-5 px-16 text-gray hover:text-dark link-ds54" href="${wpApiSettingsGiftMax.home}/profile/user">
                        <div class="flex items-center justify-center w-24 h-24 ml-10 -mr-4"><i class="opacity-90 text-xl icon-user-o"></i></div>
                        <span class="grow font-normal text-sm">تنظیمات حساب کاربری</span>
                        </a>
                        </li>
                         <li>
                        <a class="flex items-center leading-2 tracking-tight relative transition-colors py-5 px-16 text-gray hover:text-dark link-ds54" href="${wpApiSettingsGiftMax.logout}">
                        <div class="flex items-center justify-center w-24 h-24 ml-10 -mr-4"><i class="opacity-90 text-xl icon-logout"></i></div>
                        <span class="grow font-normal text-sm">خروج از حساب</span>
                        </a>
                        </li>
                        </ul>
            </div>  </div></div></div>`
        contienr.appendChild(div);
        setTimeout(function () {
            var innerElement = document.querySelector('.menuUser');
            if (innerElement) {
                innerElement.style.transform = 'translateY(0%)'; // تنظیم transform
            }
        }, 20);
    });
    $(document).on('click', ".Button-aca49", function () {
        var productID = $(this).data('product-id');
        const button = $(this);
        const originalHTML = button.html();
        button.prop('disabled', true);
        button.html(`<div class="d-flex ai-center jc-center relative grow-1"> <div class="uikit-atomic-Button-Button-module__Loading--jNJ_Z" data-testid="button-loading"> <div style="border-color: #FFF transparent;"></div> </div> </div>`);
        SAJ('addCart', { product_id: productID },
            function(res) {
                if (res.status) {
                    const el = document.querySelector('.SJf5G');
                    if (el){
                        if (el.classList.contains('hidden')){
                            el.classList.toggle("hidden")
                        }
                        el.textContent = res.cart.items_count;
                    }
                    const countCart = document.querySelectorAll(".w-1\\/5")[2].querySelector("a div span");
                    if (countCart) {
                        countCart.textContent = res.cart.items_count;
                    }else{
                        const span = document.createElement("span");
                        span.className = 'absolute bg-white shadow-[0_0_0_1_1461e2] text-4xs colr-1461e2 min-w-20 leading-1 rounded-pill right-full -mr-12 -bottom-1 px-5 font-bold text-center pt-4 pb-1 tracking-ultratight dir-ltr';
                        span.innerHTML = res.cart.items_count;
                        document.querySelectorAll(".w-1\\/5")[2].querySelector("a div").appendChild(span);
                    }
                    renderMiniCart(res.cart);
                    uikit__collections_success("با موفقیت به سبد شما اضافه شد");
                    const isMobile = isMobileDevice() || res.im ? 'Button-scm54' : 'Button-sc4';
                    document.body.classList.toggle("lock-body-scroll");
                    const contienr = document.querySelector("#popper-root");
                    const div = document.createElement("div");
                    let notif = '';
                    if (res.delivery) {
                        notif = `<div class="color-n-500 text-caption uikit-collections--FAf2Q block w-full">این محصول جز محصولات پیش فروش هست و <span style=" color: red; font-weight: bold; ">تحویل آنی</span> را شامل نمی شود، و در ${res.deliveryTime} ساعت بعداز ثبت سفارش لایسنس آن به شما تحویل داده میشود</div>`;
                    }
                    div.className = 'absolute';
                    div.innerHTML = `<div class="ModalComponent__root-YwCAMP ModalComponent__root--desktop-JzGyNl ModalComponent__animation-JkgpfL ModalComponent__root--open-i5pSf7 ModalComponent__root--open__desktop-x1XDzU"><div class="ModalComponent__content-XqD1rL ModalComponent__animation-JkgpfL ModalComponent__content--desktop-o5IbOt ModalComponent__content--border-md-4G9biy overflow-auto " style="transform: translateY(50%);"> <div class="ModalComponent__header-l62jh_"><div class="d-flex ai-center AppHeader__headerBorder-sqCler  jc-between ProfileModal__header-QU8G4w"> <p class="text-h5 color-n-700 text-h5 text-color-neutral-700">این محصول به سبد خرید اضافه شد!</p> <div class="d-flex pointer pointer mr-2" data-testid="close-wrapper"> <svg style="width: 24px; height: 24px; fill: var(--color-icon-high-emphasis);"> <path d="M12 11.0537C12 11.0537 16.2827 6.77342 17.8617 5.19523C18.1221 4.93492 18.5443 4.93492 18.8047 5.19523C19.0651 5.45553 19.0651 5.87753 18.8047 6.13783C17.2257 7.71602 12.9391 12 12.9391 12C12.9391 12 17.2257 16.284 18.8047 17.8622C19.0651 18.1225 19.0651 18.5445 18.8047 18.8047C18.5443 19.0651 18.1221 19.0651 17.8617 18.8048C16.2827 17.2266 12 12.9463 12 12.9463C12 12.9463 7.7173 17.2266 6.1383 18.8048C5.8779 19.0651 5.4557 19.0651 5.1953 18.8048C4.9349 18.5445 4.9349 18.1225 5.1953 17.8622C6.7743 16.284 11.0609 12 11.0609 12C11.0609 12 6.7743 7.71602 5.1953 6.13783C4.9349 5.87753 4.9349 5.45552 5.1953 5.19533C5.4557 4.93493 5.8779 4.93492 6.1383 5.19523C7.7173 6.77342 12 11.0537 12 11.0537Z"></path> </svg></div> </div> </div> <div class="uModalComponent__body-WvxQuY ModalComponent__body--default-sYpvC3"> <div class="p-28"><div class="flex flex-row-reverse items-start"><div class="mr-20"><div class="flex justify-end"><img alt="${res.product.name}" loading="lazy" decoding="async" width="140" class="shrink-0 rounded block" src="${res.product.image}" style="color: transparent"></div></div><div class="pt-4 grow leading-xs self-center overflow-htridden"><span class="text-sm text-dark font-bold tracking-tight">${res.product.name}</span><div class="rounded bg-light w-104 h-36 flex flex-row-reverse transition-opacity mt-8" data-product-id="${productID}"><button type="button" class="pl-6 mini-quantity__btn" data-product-mini-decrease><i class="${res.product.qty ==1 ? 'icon-delete text-xs text-red-dark text-opacity-90 w-24 h-24 bg-white shadow-sm block !leading-[24px] text-center rounded-sm':'w-24 h-24 !leading-[24px] icon-minus text-[9px] text-gray bg-white shadow-sm block text-center rounded-sm w-28 h-28 !leading-[28px]'}"></i></button><div class="grow text-center flex flex-col justify-center leading-1"><div class="pt-2 text-dark font-bold tracking-tighter text-sm after:loading after:border-blue transition-colors after:text-3xs" data-product-mini-qty="">${res.product.qty}</div></div><button type="button" class="pr-6 mini-quantity__btn" data-product-mini-increase=""><i class="w-24 h-24 bg-white shadow-sm text-gray rounded-sm icon-plus text-[9px] block !leading-[24px] text-center"></i></button></div></div></div></div>${notif}</div><div class="grow-1"></div><div class="ModalComponent__footerContainer-rb1vEj"><div class="ProfileModal__footer-IVQdrc"> <button class="btn btn-primary w-full rounded ${isMobile}" data-testid="button-wrapper" type="button" style=" width: 100%; "><div class="d-flex ai-center jc-center relative grow-1">برو به سبد خرید</div></button></div> </div></div></div>`
                    contienr.appendChild(div);
                    if(!res.available){
                        const divBox = button.closest('div');
                        const divAvailable = document.createElement('div');
                        divAvailable.className = "inaJSDge8";
                        divAvailable.innerHTML = "ناموجود";
                        divBox[0].appendChild(divAvailable);
                        button.remove();
                    }
                }else {
                    uikit__collections_error(res.message)
                }
                button.html(originalHTML);
                button.prop('disabled', false);
            },'v1',{withCredentials: true})
    });
    $(document).on('click','.gp-tab-btn', function(){
        var target = $(this).data('target');
        const tabs = document.querySelectorAll(".gp-tab-btn");
        if (tabs){
            tabs.forEach(function (tab) {
                document.querySelector(`#${tab.dataset.target}`).style.display = 'none';
            })
        }
        document.querySelector(`#${target}`).style.display = 'block';
        $('.gp-tab-btn').removeClass('active');
        $(this).addClass('active');
    });
    $(document).on('submit','#commentform', function(){
        const button = $(".act-btn.act-sabt-didgah");
        const originalHTML = button.html();
        const comment = $("#comment").val();
        if (comment.length <= 0){
            uikit__collections_error("دیدگاهی وارد نشده هنوز");
            return false;
        }
        button.prop('disabled', true);
        button.html(`<div class="d-flex ai-center jc-center relative grow-1"> <div class="uikit-atomic-Button-Button-module__Loading--jNJ_Z" data-testid="button-loading"> <div></div> </div> </div>`);
        const product_id = $("#comment_post_ID").val();
        const rating = $("#rating").val();
        const points = [];

        $(".div__point .style-df__dkd4 p").each(function () {
            const pointText = ($(this).text() || '').trim();
            if (pointText.length > 0) {
                points.push(pointText);
            }
        });

        SAJ('comment',{product_id:product_id,comment:comment,rating:rating,points:points},function (d){
            if (d.status === true || d.status === 'ok'){
                uikit__collections_success(d.message);
                $("#comment").val('');
                $("input[name='point']").val('');
                $(".div__point").empty();
            }else {
                uikit__collections_error(d.message);
            }
            button.html(originalHTML);
            button.prop('disabled', false);
        })
        return false;
    });
    $(document).on("click",'.Button-bf54',function (){
        const button = $(this);
        const originalHTML = button.html();
        button.prop('disabled', true);
        button.html(`<div class="d-flex ai-center jc-center relative grow-1"> <div class="uikit-atomic-Button-Button-module__Loading--jNJ_Z" data-testid="button-loading"> <div style="border-color: #000000 transparent; border-radius: 70%; "></div> </div> </div>`);
        SAJ('selectCategory',{},function (res){
            button.html(originalHTML);
            button.prop('disabled', false);
            if (res.status) {
                document.body.classList.toggle("lock-body-scroll");
                const contienr = document.querySelector("#popper-root");
                const div = document.createElement("div");
                div.className = 'absolute';
                div.innerHTML = `<div class="ModalComponent__root-YwCAMP ModalComponent__root--desktop-JzGyNl ModalComponent__animation-JkgpfL ModalComponent__root--open-i5pSf7 ModalComponent__root--open__desktop-x1XDzU"><div class="ModalComponent__content-XqD1rL ModalComponent__animation-JkgpfL ModalComponent__content--desktop-o5IbOt ModalComponent__content--border-md-4G9biy overflow-auto " style="transform: translateY(50%);"> <div class="ModalComponent__header-l62jh_"><div class="d-flex ai-center AppHeader__headerBorder-sqCler  jc-between ProfileModal__header-QU8G4w"> <p class="text-h5 color-n-700 text-h5 text-color-neutral-700">انتخاب دسته بندی</p> <div class="d-flex pointer pointer mr-2" data-testid="close-wrapper"> <svg style="width: 24px; height: 24px; fill: var(--color-icon-high-emphasis);"> <path d="M12 11.0537C12 11.0537 16.2827 6.77342 17.8617 5.19523C18.1221 4.93492 18.5443 4.93492 18.8047 5.19523C19.0651 5.45553 19.0651 5.87753 18.8047 6.13783C17.2257 7.71602 12.9391 12 12.9391 12C12.9391 12 17.2257 16.284 18.8047 17.8622C19.0651 18.1225 19.0651 18.5445 18.8047 18.8047C18.5443 19.0651 18.1221 19.0651 17.8617 18.8048C16.2827 17.2266 12 12.9463 12 12.9463C12 12.9463 7.7173 17.2266 6.1383 18.8048C5.8779 19.0651 5.4557 19.0651 5.1953 18.8048C4.9349 18.5445 4.9349 18.1225 5.1953 17.8622C6.7743 16.284 11.0609 12 11.0609 12C11.0609 12 6.7743 7.71602 5.1953 6.13783C4.9349 5.87753 4.9349 5.45552 5.1953 5.19533C5.4557 4.93493 5.8779 4.93492 6.1383 5.19523C7.7173 6.77342 12 11.0537 12 11.0537Z"></path> </svg></div> </div> </div> <div class="uModalComponent__body-WvxQuY ModalComponent__body--default-sYpvC3"> ${res.html} </div><div class="grow-1"></div></div></div>`
                contienr.appendChild(div);
            }else{
                uikit__collections_error("مشکلی پیش آمده دوباره تلاش کنید");
            }
        },'v2')
    })
    $(document).on("click",'.Button-bf14',function (){
        document.body.classList.toggle("lock-body-scroll");
        const contienr = document.querySelector("#popper-root");
        const div = document.createElement("div");
        div.className = 'absolute';
        div.innerHTML = `<div class="ModalComponent__root-YwCAMP ModalComponent__root--desktop-JzGyNl ModalComponent__animation-JkgpfL ModalComponent__root--open-i5pSf7 ModalComponent__root--open__desktop-x1XDzU"><div class="ModalComponent__content-XqD1rL ModalComponent__animation-JkgpfL ModalComponent__content--desktop-o5IbOt ModalComponent__content--border-md-4G9biy overflow-auto " style="transform: translateY(50%);"> <div class="ModalComponent__header-l62jh_"><div class="d-flex ai-center AppHeader__headerBorder-sqCler  jc-between ProfileModal__header-QU8G4w"> <p class="text-h5 color-n-700 text-h5 text-color-neutral-700">انتخاب دسته بندی</p> <div class="d-flex pointer pointer mr-2" data-testid="close-wrapper"> <svg style="width: 24px; height: 24px; fill: var(--color-icon-high-emphasis);"> <path d="M12 11.0537C12 11.0537 16.2827 6.77342 17.8617 5.19523C18.1221 4.93492 18.5443 4.93492 18.8047 5.19523C19.0651 5.45553 19.0651 5.87753 18.8047 6.13783C17.2257 7.71602 12.9391 12 12.9391 12C12.9391 12 17.2257 16.284 18.8047 17.8622C19.0651 18.1225 19.0651 18.5445 18.8047 18.8047C18.5443 19.0651 18.1221 19.0651 17.8617 18.8048C16.2827 17.2266 12 12.9463 12 12.9463C12 12.9463 7.7173 17.2266 6.1383 18.8048C5.8779 19.0651 5.4557 19.0651 5.1953 18.8048C4.9349 18.5445 4.9349 18.1225 5.1953 17.8622C6.7743 16.284 11.0609 12 11.0609 12C11.0609 12 6.7743 7.71602 5.1953 6.13783C4.9349 5.87753 4.9349 5.45552 5.1953 5.19533C5.4557 4.93493 5.8779 4.93492 6.1383 5.19523C7.7173 6.77342 12 11.0537 12 11.0537Z"></path> </svg></div> </div> </div> <div class="uModalComponent__body-WvxQuY ModalComponent__body--default-sYpvC3" id="catPup"> <div class="grid grid-cols-1 2xs:grid-cols-2 gap-4 2xs:gap-6"> <div class="flex items-center p-8 border skeleton h-25"> </div><div class="flex items-center p-8 border skeleton h-25"> </div><div class="flex items-center p-8 border skeleton h-25"> </div><div class="flex items-center p-8 border skeleton h-25"> </div><div class="flex items-center p-8 border skeleton h-25"> </div><div class="flex items-center p-8 border skeleton h-25"> </div><div class="flex items-center p-8 border skeleton h-25"> </div> <div class="flex items-center p-8 border skeleton h-25"> </div><div class="flex items-center p-8 border skeleton h-25"> </div><div class="flex items-center p-8 border skeleton h-25"> </div><div class="flex items-center p-8 border skeleton h-25"> </div><div class="flex items-center p-8 border skeleton h-25"> </div><div class="flex items-center p-8 border skeleton h-25"> </div><div class="flex items-center p-8 border skeleton h-25"> </div><div class="flex items-center p-8 border skeleton h-25"> </div><div class="flex items-center p-8 border skeleton h-25"> </div><div class="flex items-center p-8 border skeleton h-25"> </div><div class="flex items-center p-8 border skeleton h-25"> </div><div class="flex items-center p-8 border skeleton h-25"> </div><div class="flex items-center p-8 border skeleton h-25"> </div><div class="flex items-center p-8 border skeleton h-25"> </div><div class="flex items-center p-8 border skeleton h-25"> </div><div class="flex items-center p-8 border skeleton h-25"> </div><div class="flex items-center p-8 border skeleton h-25"> </div><div class="flex items-center p-8 border skeleton h-25"> </div><div class="flex items-center p-8 border skeleton h-25"> </div><div class="flex items-center p-8 border skeleton h-25"> </div><div class="flex items-center p-8 border skeleton h-25"> </div><div class="flex items-center p-8 border skeleton h-25"> </div><div class="flex items-center p-8 border skeleton h-25"> </div><div class="flex items-center p-8 border skeleton h-25"> </div><div class="flex items-center p-8 border skeleton h-25"> </div></div> </div><div class="grow-1"></div></div></div>`
        contienr.appendChild(div);
        SAJ('selectCategory',{},function (res){
            if (res.status) {
                document.querySelector("#catPup").innerHTML = res.html;
            }else{
                uikit__collections_error("مشکلی پیش آمده دوباره تلاش کنید");
            }
        },'v2')
    })
    $(document).on("click",".Category-bf54",function (){
        var term_id = $(this).data('category-id');
        document.querySelector(".ModalComponent__content-XqD1rL").innerHTML = `<div class="ModalComponent__header-l62jh_"><div class="d-flex ai-center AppHeader__headerBorder-sqCler  jc-between ProfileModal__header-QU8G4w"> <p class="text-h5 color-n-700 text-h5 text-color-neutral-700">انتخاب محصول</p> <div class="d-flex pointer pointer mr-2" data-testid="close-wrapper"> <svg style="width: 24px; height: 24px; fill: var(--color-icon-high-emphasis);"> <path d="M12 11.0537C12 11.0537 16.2827 6.77342 17.8617 5.19523C18.1221 4.93492 18.5443 4.93492 18.8047 5.19523C19.0651 5.45553 19.0651 5.87753 18.8047 6.13783C17.2257 7.71602 12.9391 12 12.9391 12C12.9391 12 17.2257 16.284 18.8047 17.8622C19.0651 18.1225 19.0651 18.5445 18.8047 18.8047C18.5443 19.0651 18.1221 19.0651 17.8617 18.8048C16.2827 17.2266 12 12.9463 12 12.9463C12 12.9463 7.7173 17.2266 6.1383 18.8048C5.8779 19.0651 5.4557 19.0651 5.1953 18.8048C4.9349 18.5445 4.9349 18.1225 5.1953 17.8622C6.7743 16.284 11.0609 12 11.0609 12C11.0609 12 6.7743 7.71602 5.1953 6.13783C4.9349 5.87753 4.9349 5.45552 5.1953 5.19533C5.4557 4.93493 5.8779 4.93492 6.1383 5.19523C7.7173 6.77342 12 11.0537 12 11.0537Z"></path> </svg></div> </div> </div><div class="uModalComponent__body-WvxQuY ModalComponent__body--default-sYpvC3">                     <div class="flex flex-col h-full"><div class="flex items-center justify-between mb-10 lg:mb-16 px-16 lg:px-28"><div class="skeleton w-120 h-16 rounded-pill"></div><div class="skeleton w-48 h-48 rounded-sm"></div></div><div class="grow overflow-y-auto simple-scrollbar"><div class="px-16 lg:px-28 pb-20"><div class="skeleton h-68 rounded mb-10 lg:mb-16"></div><div class="skeleton h-48 rounded"></div></div><div class="pb-24 lg:pb-28 lg:pt-6 px-16 lg:px-28"><div class="pb-20 mb-20 border-b border-gray-300 last:!mb-0 last:!pb-0 last:!border-none"><div class="pt-4 pb-3"><div class="skeleton w-[200px] h-15 rounded-pill"></div></div><div class="flex items-center mt-4 min-h-[38px] justify-between"><div class="skeleton w-92 h-14 rounded-pill"></div><div class="skeleton w-104 h-36 rounded"></div></div></div><div class="pb-20 mb-20 border-b border-gray-300 last:!mb-0 last:!pb-0 last:!border-none"><div class="pt-4 pb-3"><div class="skeleton w-[200px] h-15 rounded-pill"></div></div><div class="flex items-center mt-4 min-h-[38px] justify-between"><div class="skeleton w-92 h-14 rounded-pill"></div><div class="skeleton w-104 h-36 rounded"></div></div></div><div class="pb-20 mb-20 border-b border-gray-300 last:!mb-0 last:!pb-0 last:!border-none"><div class="pt-4 pb-3"><div class="skeleton w-[200px] h-15 rounded-pill"></div></div><div class="flex items-center mt-4 min-h-[38px] justify-between"><div class="skeleton w-92 h-14 rounded-pill"></div><div class="skeleton w-104 h-36 rounded"></div></div></div><div class="pb-20 mb-20 border-b border-gray-300 last:!mb-0 last:!pb-0 last:!border-none"><div class="pt-4 pb-3"><div class="skeleton w-[200px] h-15 rounded-pill"></div></div><div class="flex items-center mt-4 min-h-[38px] justify-between"><div class="skeleton w-92 h-14 rounded-pill"></div><div class="skeleton w-104 h-36 rounded"></div></div></div></div></div></div> </div>` ;
        SAJ('compact', { term_id: term_id },function (res){
            if (res.status) {
                document.querySelector(".ModalComponent__content-XqD1rL").innerHTML = `<div class="ModalComponent__header-l62jh_"><div class="d-flex ai-center AppHeader__headerBorder-sqCler  jc-between ProfileModal__header-QU8G4w"> <p class="text-h5 color-n-700 text-h5 text-color-neutral-700">انتخاب محصول</p> <div class="d-flex pointer pointer mr-2" data-testid="close-wrapper"> <svg style="width: 24px; height: 24px; fill: var(--color-icon-high-emphasis);"> <path d="M12 11.0537C12 11.0537 16.2827 6.77342 17.8617 5.19523C18.1221 4.93492 18.5443 4.93492 18.8047 5.19523C19.0651 5.45553 19.0651 5.87753 18.8047 6.13783C17.2257 7.71602 12.9391 12 12.9391 12C12.9391 12 17.2257 16.284 18.8047 17.8622C19.0651 18.1225 19.0651 18.5445 18.8047 18.8047C18.5443 19.0651 18.1221 19.0651 17.8617 18.8048C16.2827 17.2266 12 12.9463 12 12.9463C12 12.9463 7.7173 17.2266 6.1383 18.8048C5.8779 19.0651 5.4557 19.0651 5.1953 18.8048C4.9349 18.5445 4.9349 18.1225 5.1953 17.8622C6.7743 16.284 11.0609 12 11.0609 12C11.0609 12 6.7743 7.71602 5.1953 6.13783C4.9349 5.87753 4.9349 5.45552 5.1953 5.19533C5.4557 4.93493 5.8779 4.93492 6.1383 5.19523C7.7173 6.77342 12 11.0537 12 11.0537Z"></path> </svg></div> </div> </div> <div class="uModalComponent__body-WvxQuY ModalComponent__body--default-sYpvC3"> ${res.html} </div><div class="grow-1"></div><div class="ModalComponent__footerContainer-rb1vEj Button-bfn54 ${(res.cart) ? '' : 'hidden'}"><div class="ProfileModal__footer-IVQdrc Button-bfn64"> <button class="relative d-flex ai-center user-select-none btn-wc51H8 text-button-2 btn--primary-uiqWij radius Button__medium-gIvke_ Button__filledPrimary-OvgwGb lg:w-100 ProfileBase__button__modal-O3kjhU" data-testid="button-wrapper" type="button" style=" width: 100%; "><div class="d-flex ai-center jc-center relative grow-1">مرحله بعدی</div></button></div> </div>`;
                window.productsByRegion = res.productsByRegion;

                const $dropdownBtn = $('button.btn.border.\\!bg-white.rounded.flex.items-center.\\!text-dark.w-full.py-11.lg\\:py-10.px-16');
                const $dropdownMenu = $('.dropdown-menu');

                // باز/بسته کردن منو با کلیک روی دکمه اصلی
                $dropdownBtn.off('click').on('click', function(e) {
                    e.stopPropagation();
                    $dropdownMenu.toggleClass('active show');
                });

                // جلوگیری از بسته شدن منو وقتی روی خود منو کلیک شد
                $dropdownMenu.off('click').on('click', function(e) {
                    e.stopPropagation();
                });

                // کلیک روی صفحه منو بسته شود
                $(document).off('click.regionDropdown').on('click.regionDropdown', function() {
                    $dropdownMenu.removeClass('active show');
                });

                // کلیک روی هر ریجن
                $dropdownMenu.find('.Button-cse54').off('click').on('click', function(e) {
                    e.preventDefault();
                    e.stopPropagation();

                    const region = $(this).data('region');
                    const regionName = $(this).find('span').text();

                    window.selectedRegion = region;

                    $dropdownBtn.find('img').attr('src', `${wpApiSettingsGiftMax.directory}/assets/flag/${region}.svg`);
                    $dropdownBtn.find('span').text(`ریجن انتخاب شده: ${regionName}`);

                    // منو بسته شود
                    $dropdownMenu.removeClass('active show');

                    // بارگذاری محصولات ریجن انتخاب شده
                    renderProducts(region);
                });

            }
            },'v2')
    })
    $(document).on('click', ".Button-bfa48", function () {
        var productID = $(this).data('product-id');
        const button = $(this);
        button.prop('disabled', true);
        button.toggleClass('is-loading');
        SAJ('addCart', { product_id: productID },
            function(res) {
                if (res.status) {
                    if ($(".Button-bfn54")[0].classList.contains("hidden")){
                        $(".Button-bfn54")[0].classList.toggle("hidden")
                    }
                    renderMiniCart(res.cart);
                    const el = document.querySelector('.SJf5G');
                    if (el){
                        if (el.classList.contains('hidden')){
                            el.classList.toggle("hidden")
                        }
                        el.textContent = res.cart.items_count;
                    }
                    const countCart = document.querySelectorAll(".w-1\\/5")[2].querySelector("a div span");
                    if (countCart) {
                        countCart.textContent = res.cart.items_count;
                    }else{
                        const span = document.createElement("span");
                        span.className = 'absolute bg-white shadow-[0_0_0_1_1461e2] text-4xs colr-1461e2 min-w-20 leading-1 rounded-pill right-full -mr-12 -bottom-1 px-5 font-bold text-center pt-4 pb-1 tracking-ultratight dir-ltr';
                        span.innerHTML = res.cart.items_count;
                        document.querySelectorAll(".w-1\\/5")[2].querySelector("a div").appendChild(span);
                    }
                    const container = button.closest(".flex.items-center.mt-6.justify-between");
                    const div = document.createElement("div");
                    div.className = "rounded bg-light w-104 h-36 flex flex-row-reverse transition-opacity";
                    div.innerHTML =`<button type="button" class="pl-6 mini-quantity__btn" data-ajax-mini-decrease=""><i class="icon-delete text-xs text-red-dark text-opacity-90 w-24 h-24 bg-white shadow-sm block !leading-[24px] text-center rounded-sm"></i></button><div class="grow text-center flex flex-col justify-center leading-1"><div class="pt-2 text-dark font-bold tracking-tighter text-sm after:loading after:border-blue transition-colors after:text-3xs" data-ajax-mini-qty="">1</div></div><button type="button" class="pr-6 mini-quantity__btn" data-ajax-mini-increase=""><i class="w-24 h-24 bg-white shadow-sm text-gray rounded-sm icon-plus text-[9px] block !leading-[24px] text-center"></i></button>`;
                    container.prepend(div);
                    button.remove();

                } else{
                    uikit__collections_error(res.message)
                }
                button.toggleClass('is-loading');
                button.prop('disabled', false);
            },'v1',{ withCredentials: true })
    });
    $(document).on('click', ".Button-bfn64", function (e) {
        const button = $(this);
        button.prop('disabled', true);
        button.toggleClass('is-loading');
        SAJ('getCart', {},
            function(res) {
                if (res.status) {
                    if (res.redirect) {
                        window.location.href = res.url;
                    }else{
                        document.querySelector(".ModalComponent__content-XqD1rL").innerHTML = `<div class="ModalComponent__header-l62jh_"><div class="d-flex ai-center AppHeader__headerBorder-sqCler  jc-between ProfileModal__header-QU8G4w"> <p class="text-h5 color-n-700 text-h5 text-color-neutral-700">انتخاب محصول</p> <div class="d-flex pointer pointer mr-2" data-testid="close-wrapper"> <svg style="width: 24px; height: 24px; fill: var(--color-icon-high-emphasis);"> <path d="M12 11.0537C12 11.0537 16.2827 6.77342 17.8617 5.19523C18.1221 4.93492 18.5443 4.93492 18.8047 5.19523C19.0651 5.45553 19.0651 5.87753 18.8047 6.13783C17.2257 7.71602 12.9391 12 12.9391 12C12.9391 12 17.2257 16.284 18.8047 17.8622C19.0651 18.1225 19.0651 18.5445 18.8047 18.8047C18.5443 19.0651 18.1221 19.0651 17.8617 18.8048C16.2827 17.2266 12 12.9463 12 12.9463C12 12.9463 7.7173 17.2266 6.1383 18.8048C5.8779 19.0651 5.4557 19.0651 5.1953 18.8048C4.9349 18.5445 4.9349 18.1225 5.1953 17.8622C6.7743 16.284 11.0609 12 11.0609 12C11.0609 12 6.7743 7.71602 5.1953 6.13783C4.9349 5.87753 4.9349 5.45552 5.1953 5.19533C5.4557 4.93493 5.8779 4.93492 6.1383 5.19523C7.7173 6.77342 12 11.0537 12 11.0537Z"></path> </svg></div> </div> </div> <div class="uModalComponent__body-WvxQuY ModalComponent__body--default-sYpvC3"> ${res.html} </div><div class="grow-1"></div><div class="ModalComponent__footerContainer-rb1vEj"><div class="ProfileModal__footer-IVQdrc"> <button class="relative d-flex ai-center user-select-none btn-wc51H8 text-button-2 btn--primary-uiqWij radius Button__medium-gIvke_ Button__filledPrimary-OvgwGb lg:w-100 ProfileBase__button__modal-O3kjhU btn-ajax Button-bfe54" data-testid="button-wrapper" type="button" style=" width: 100%; "><div class="d-flex ai-center jc-center relative grow-1">پرداخت</div></button></div> </div>`;
                        localStorage.setItem('selectedButtonFast', 'zibal');
                        const buttons = document.querySelectorAll('.Button-p5');
                        buttons.forEach((button,index) => {
                            button.addEventListener('click', function() {
                                buttons.forEach(btn => {
                                    btn.querySelector('i').className = 'w-20 h-20 text-center rounded-circle bg-gray bg-opacity-15 text-4xs pl-1 ml-4 !leading-[22px] icon-check transition-colors text-transparent';
                                });
                                localStorage.setItem('selectedButtonFast', button.dataset.gateway);
                                this.querySelector('i').className = "w-20 h-20 text-center rounded-circle text-4xs pl-1 ml-4 !leading-[22px] icon-check transition-colors text-white bg-green bg-opacity-100";
                                if(button.dataset.gateway === 'Payment4'){
                                    document.querySelectorAll(".ModalComponent__content-XqD1rL .flex.items-center.leading-xs")[2].style = 'display:none';
                                    document.querySelectorAll(".ModalComponent__content-XqD1rL .flex.items-center.leading-xs")[3].style = 'display:none';
                                }else{
                                    document.querySelectorAll(".ModalComponent__content-XqD1rL .flex.items-center.leading-xs")[2].style = '';
                                    document.querySelectorAll(".ModalComponent__content-XqD1rL .flex.items-center.leading-xs")[3].style = '';
                                }
                            });
                        });
                    }
                } else{
                    uikit__collections_error(res.message)
                }
                button.toggleClass('is-loading');
                button.prop('disabled', false);
            },'v2')
    });
    $(document).on('click',".Button-bfe54",function (){
        let selectedButton = localStorage.getItem('selectedButtonFast');
        const button = $(this);
        button.prop('disabled', true);
        button.toggleClass('is-loading');

        SAJ('payment',{ gateway: selectedButton},function (res){
            if (res.status){
                window.location.href = res.url;
            }else {
                uikit__collections_error(res.message);
            }
            button.toggleClass('is-loading');
            button.prop('disabled', false);
        })
    })
    $(document).on('click', '[data-ajax-mini-decrease]', function () {

        const $item   = $(this).closest('[data-product-id]');
        const productId = $item.data('product-id');
        const $qtyBox = $item.find('[data-ajax-mini-qty]');
        const $deleteBtn = $(this);

        let qty = parseInt($qtyBox.text()) || 1;
        const button = $(this);
        button.prop('disabled', true);

        qty--;

        if (qty < 2) {
            $deleteBtn.find('i').removeClass('icon-minus text-[9px] text-gray bg-white shadow-sm block text-center rounded-sm w-28 h-28 !leading-[28px]');
            $deleteBtn.find('i').addClass('icon-delete text-xs text-red-dark text-opacity-90 bg-white shadow-sm block text-center rounded-sm w-28 h-28 !leading-[28px]');
        }

        if (qty <= 0) {
            $item.find(".rounded.bg-light.w-104.h-36.flex.flex-row-reverse.transition-opacity").remove();
            const AddtoCart = document.createElement("button");
            AddtoCart.className = "btn-ajax after:border-blue Button-bfa48";
            AddtoCart.dataset.productId = productId;
            AddtoCart.innerHTML =`افزودن به سبد`;
            $item.find(".flex.items-center.mt-6.min-h-\\[38px\\].justify-between").prepend(AddtoCart);
        }
        $qtyBox.html(`<div class="d-flex ai-center jc-center relative grow-1"><div class="flex items-center justify-center"><div class="flex items-center justify-around" style="width: 24px; height: 24px;"><div class="rounded-circle styles_Loading__circle1__K7HNJ" style="width: 6px;height: 6px;background: rgb(156,156,156);"></div><div class="rounded-circle styles_Loading__circle2__jpl_q" style="width: 6px;height: 6px;background: rgb(129,129,129);"></div><div class="rounded-circle styles_Loading__circle3__otcH4" style="width: 6px;height: 6px;background: rgb(92,92,92);"></div></div></div> </div>`);


        updateCartByProduct(productId, qty, $qtyBox, button);
    });
    $(document).on('click', '[data-ajax-mini-increase]', function () {

        const $item   = $(this).closest('[data-product-id]');
        const productId = $item.data('product-id');
        const $qtyBox = $item.find('[data-ajax-mini-qty]');
        const $deleteBtn = $item.find('[data-ajax-mini-decrease]');

        let qty = parseInt($qtyBox.text()) || 1;
        const button = $(this);
        button.prop('disabled', true);

        qty++;

        if (qty > 1) {
            $deleteBtn.find('i').removeClass('icon-delete text-xs text-red-dark text-opacity-90 bg-white shadow-sm block text-center rounded-sm w-28 h-28 !leading-[28px]');
            $deleteBtn.find('i').addClass('icon-minus text-[9px] text-gray bg-white shadow-sm block text-center rounded-sm w-28 h-28 !leading-[28px]');
        }
        $qtyBox.html(`<div class="d-flex ai-center jc-center relative grow-1"><div class="flex items-center justify-center"><div class="flex items-center justify-around" style="width: 24px; height: 24px;"><div class="rounded-circle styles_Loading__circle1__K7HNJ" style="width: 6px;height: 6px;background: rgb(156,156,156);"></div><div class="rounded-circle styles_Loading__circle2__jpl_q" style="width: 6px;height: 6px;background: rgb(129,129,129);"></div><div class="rounded-circle styles_Loading__circle3__otcH4" style="width: 6px;height: 6px;background: rgb(92,92,92);"></div></div></div> </div>`);


        updateCartByProduct(productId, qty, $qtyBox, button);
    });
    $(document).on('click', '.btn-plus', function () {

        const $item   = $(this).closest("div");
        const productId = $(this).data('product-id');
        const $qtyBox = $item.find('.text-qty');
        const $deleteBtn = $item.find('.btn-minus');

        let qty = parseInt($qtyBox.text()) || 1;
        const button = $(this);
        button.prop('disabled', true);

        qty++;

        if (qty > 1) {
            $deleteBtn.find('i').removeClass('icon-delete text-xs text-red-dark text-opacity-90 bg-white shadow-sm block text-center rounded-sm w-28 h-28 !leading-[28px]');
            $deleteBtn.find('i').addClass('icon-minus text-[9px] text-gray bg-white shadow-sm block text-center rounded-sm w-28 h-28 !leading-[28px]');
        }
        $qtyBox.html(`<div class="d-flex ai-center jc-center relative grow-1"><div class="flex items-center justify-center"><div class="flex items-center justify-around" style="width: 24px; height: 24px;"><div class="rounded-circle styles_Loading__circle1__K7HNJ" style="width: 6px;height: 6px;background: rgb(156,156,156);"></div><div class="rounded-circle styles_Loading__circle2__jpl_q" style="width: 6px;height: 6px;background: rgb(129,129,129);"></div><div class="rounded-circle styles_Loading__circle3__otcH4" style="width: 6px;height: 6px;background: rgb(92,92,92);"></div></div></div> </div>`);


        updateCartByProduct(productId, qty, $qtyBox, button,gatewayApi,1);
    });
    $(document).on('click', '.btn-minus', function () {

        const $item   = $(this).closest("div");
        const productId = $(this).data('product-id');
        const $qtyBox = $item.find('.text-qty');
        const $deleteBtn = $item.find('.btn-minus');

        let qty = parseInt($qtyBox.text()) || 1;
        const button = $(this);
        button.prop('disabled', true);

        qty--;

        if (qty < 2) {
            $deleteBtn.find('i').removeClass('icon-minus text-[9px] text-gray bg-white shadow-sm block text-center rounded-sm w-28 h-28 !leading-[28px]');
            $deleteBtn.find('i').addClass('icon-delete text-xs text-red-dark text-opacity-90 bg-white shadow-sm block text-center rounded-sm w-28 h-28 !leading-[28px]');
        }
        console.log(qty);

        if (qty <= 0) {
            const div = document.createElement("div");
            div.className = "alert alert-primary alert-sm font-normal";
            div.innerHTML =`محصول از سبد خرید شما حذف شد!`;
            $item.closest(".uModalComponent__body-WvxQuY.ModalComponent__body--default-sYpvC3 .p-28").prepend(div);
            $item.closest(".flex.flex-row-reverse.items-start").remove();
        }
        $qtyBox.html(`<div class="d-flex ai-center jc-center relative grow-1"><div class="flex items-center justify-center"><div class="flex items-center justify-around" style="width: 24px; height: 24px;"><div class="rounded-circle styles_Loading__circle1__K7HNJ" style="width: 6px;height: 6px;background: rgb(156,156,156);"></div><div class="rounded-circle styles_Loading__circle2__jpl_q" style="width: 6px;height: 6px;background: rgb(129,129,129);"></div><div class="rounded-circle styles_Loading__circle3__otcH4" style="width: 6px;height: 6px;background: rgb(92,92,92);"></div></div></div> </div>`);
        updateCartByProduct(productId, qty, $qtyBox, button,gatewayApi,1);
    });
    $(document).on('click', '[data-product-mini-decrease]', function () {

        const $item   = $(this).closest('[data-product-id]');
        const productId = $item.data('product-id');
        const $qtyBox = $item.find('[data-product-mini-qty]');
        const $deleteBtn = $item.find('[data-product-mini-decrease]');

        let qty = parseInt($qtyBox.text()) || 1;
        const button = $(this);
        button.prop('disabled', true);

        qty--;

        if (qty < 2) {
            $deleteBtn.find('i').removeClass('icon-minus text-[9px] text-gray bg-white shadow-sm block text-center rounded-sm w-28 h-28 !leading-[28px]');
            $deleteBtn.find('i').addClass('icon-delete text-xs text-red-dark text-opacity-90 bg-white shadow-sm block text-center rounded-sm w-28 h-28 !leading-[28px]');
        }
        console.log(qty);

        if (qty <= 0) {
            const div = document.createElement("div");
            div.className = "alert alert-primary alert-sm font-normal";
            div.innerHTML =`محصول از سبد خرید شما حذف شد!`;
            $item.closest(".uModalComponent__body-WvxQuY.ModalComponent__body--default-sYpvC3 .p-28").prepend(div);
            $item.closest(".flex.flex-row-reverse.items-start").remove();
            document.querySelector(".Button-sc4").remove();
            setTimeout(function (){
                closePup($("[data-testid=\"close-wrapper\"]"));
            },300)
        }
        $qtyBox.html(`<div class="d-flex ai-center jc-center relative grow-1"><div class="flex items-center justify-center"><div class="flex items-center justify-around" style="width: 24px; height: 24px;"><div class="rounded-circle styles_Loading__circle1__K7HNJ" style="width: 6px;height: 6px;background: rgb(156,156,156);"></div><div class="rounded-circle styles_Loading__circle2__jpl_q" style="width: 6px;height: 6px;background: rgb(129,129,129);"></div><div class="rounded-circle styles_Loading__circle3__otcH4" style="width: 6px;height: 6px;background: rgb(92,92,92);"></div></div></div> </div>`);

        updateCartByProduct(productId, qty, $qtyBox, button);
    });
    $(document).on('click', '[data-product-mini-increase]', function () {

        const $item   = $(this).closest('[data-product-id]');
        const productId = $item.data('product-id');
        const $qtyBox = $item.find('[data-product-mini-qty]');
        const $deleteBtn = $item.find('[data-product-mini-decrease]');

        let qty = parseInt($qtyBox.text()) || 1;
        const button = $(this);
        button.prop('disabled', true);

        qty++;

        if (qty > 1) {
            $deleteBtn.find('i').removeClass('icon-delete text-xs text-red-dark text-opacity-90 bg-white shadow-sm block text-center rounded-sm w-28 h-28 !leading-[28px]');
            $deleteBtn.find('i').addClass('icon-minus text-[9px] text-gray bg-white shadow-sm block text-center rounded-sm w-28 h-28 !leading-[28px]');
        }
        $qtyBox.html(`<div class="d-flex ai-center jc-center relative grow-1"><div class="flex items-center justify-center"><div class="flex items-center justify-around" style="width: 24px; height: 24px;"><div class="rounded-circle styles_Loading__circle1__K7HNJ" style="width: 6px;height: 6px;background: rgb(156,156,156);"></div><div class="rounded-circle styles_Loading__circle2__jpl_q" style="width: 6px;height: 6px;background: rgb(129,129,129);"></div><div class="rounded-circle styles_Loading__circle3__otcH4" style="width: 6px;height: 6px;background: rgb(92,92,92);"></div></div></div> </div>`);


        updateCartByProduct(productId, qty, $qtyBox, button);
    });
    $(document).on('click','.Button-cc59',function (){
        if (gatewayApi != 'r'){
            uikit__collections_error("کد تخفیف فقط برای پرداخت ریالی است")
            return;
        }
        document.body.classList.toggle("lock-body-scroll");
        const contienr = document.querySelector("#popper-root");
        const div = document.createElement("div");
        div.className = 'absolute';
        div.innerHTML = `<div class="ModalComponent__root-YwCAMP ModalComponent__root--desktop-JzGyNl ModalComponent__animation-JkgpfL ModalComponent__root--open-i5pSf7 ModalComponent__root--open__desktop-x1XDzU"><div class="ModalComponent__content-XqD1rL ModalComponent__animation-JkgpfL ModalComponent__content--desktop-o5IbOt ModalComponent__content--border-md-4G9biy overflow-auto " style="transform: translateY(50%);"> <div class="ModalComponent__header-l62jh_"><div class="d-flex ai-center AppHeader__headerBorder-sqCler  jc-between ProfileModal__header-QU8G4w"> <p class="text-h5 color-n-700 text-h5 text-color-neutral-700">کد تخفیف</p> <div class="d-flex pointer pointer mr-2" data-testid="close-wrapper"> <svg style="width: 24px; height: 24px; fill: var(--color-icon-high-emphasis);"> <path d="M12 11.0537C12 11.0537 16.2827 6.77342 17.8617 5.19523C18.1221 4.93492 18.5443 4.93492 18.8047 5.19523C19.0651 5.45553 19.0651 5.87753 18.8047 6.13783C17.2257 7.71602 12.9391 12 12.9391 12C12.9391 12 17.2257 16.284 18.8047 17.8622C19.0651 18.1225 19.0651 18.5445 18.8047 18.8047C18.5443 19.0651 18.1221 19.0651 17.8617 18.8048C16.2827 17.2266 12 12.9463 12 12.9463C12 12.9463 7.7173 17.2266 6.1383 18.8048C5.8779 19.0651 5.4557 19.0651 5.1953 18.8048C4.9349 18.5445 4.9349 18.1225 5.1953 17.8622C6.7743 16.284 11.0609 12 11.0609 12C11.0609 12 6.7743 7.71602 5.1953 6.13783C4.9349 5.87753 4.9349 5.45552 5.1953 5.19533C5.4557 4.93493 5.8779 4.93492 6.1383 5.19523C7.7173 6.77342 12 11.0537 12 11.0537Z"></path> </svg></div> </div> </div> <div class="uModalComponent__body-WvxQuY ModalComponent__body--default-sYpvC3"> <label class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--L7bcQ uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--normal--A6Ntt text-body-1 color-n-700 w-100"><p class="mb-2 color-n-700 text-body-1 mb-2" data-testid="form-label">کد تخفیف کد را وارد کنید</p><div class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame__input-container--D5edN px-2 d-flex ai-center"><section class="grow-1 text-body-2-c"><input class="px-2 TextField__input-_5fbdd text-subtitle w-100 TextField-e58168" type="text" name="discount"></section></div></label> </div><div class="grow-1"></div><div class="ModalComponent__footerContainer-rb1vEj"><div class="ProfileModal__footer-IVQdrc"> <button class="relative d-flex ai-center user-select-none btn-wc51H8 text-button-2 btn--primary-uiqWij radius Button__medium-gIvke_ Button__filledPrimary-OvgwGb ProfileBase__button-jvi4aR ProfileBase__button__modal-O3kjhU Button-dc684" data-testid="button-wrapper" type="button"><div class="d-flex ai-center jc-center relative grow-1">تایید</div></button></div> </div></div></div>`
        contienr.appendChild(div);
    })
    $(document).on('click', '.Button-dc684', function (e) {
        e.preventDefault();

        const button = $(this);
        const originalHTML = button.html();
        button.prop('disabled', true);
        button.html(`<div class="d-flex ai-center jc-center relative grow-1"> <div class="uikit-atomic-Button-Button-module__Loading--jNJ_Z" data-testid="button-loading"> <div></div> </div> </div>`);
        const couponCode = $("input[name=\"discount\"]").val();

        if (!couponCode) {
            uikit__collections_error('لطفاً کد تخفیف را وارد کنید');
            return;
        }
        $.ajax({
            url: `${wpApiSettingsGiftMax.root}api/v1/coupon`,
            method: 'POST',
            dataType: 'json',
            data: {coupon: couponCode},
            beforeSend: function (xhr) {
                xhr.setRequestHeader('X-WP-Nonce', wpApiSettingsGiftMax.nonce);
            },
            success: function (response) {
                button.html(originalHTML);
                button.prop('disabled', false);
                if (!response.status) {
                    uikit__collections_error(response.data.message || 'کد تخفیف نامعتبر است');
                    return;
                }
                uikit__collections_success(response.message);
                closePup(button);
                if (response.summary) {
                    $('[data-summary="subtotal"] span').text(response.summary.subtotal);
                    $('[data-summary="discount"] span').text(response.summary.discount);
                    $('[data-summary="total"] span').text(response.summary.total);
                }
            },
            error: function (jqXHR, exception) {
                if (jqXHR.status === 0) {
                    uikit__collections_error('اینترنت شما قطع شده است!');
                } else if (jqXHR.status == 404) {
                    uikit__collections_error('Requested page not found. [404]');
                } else if (jqXHR.status == 500) {
                    uikit__collections_error('Internal Server Error [500].');
                } else if (exception === 'parsererror') {
                    uikit__collections_error('Requested JSON parse failed.');
                } else if (exception === 'timeout') {
                    uikit__collections_error('Time out error.');
                } else if (exception === 'abort') {
                    uikit__collections_error('Ajax request aborted.');
                } else {
                    uikit__collections_error(jqXHR.message);
                }
            }
        });
    });
    $(document).on('click', '.Button-sc4', function (e) {
        const button = $(this);
        const originalHTML = button.html();
        button.prop('disabled', true);
        button.html(`<div class="d-flex ai-center jc-center relative grow-1"> <div class="uikit-atomic-Button-Button-module__Loading--jNJ_Z" data-testid="button-loading"> <div></div> </div> </div>`);
        SAJ('pupCart',{},function (res){
            if (!res.status){
                uikit__collections_error("ابتدا وارد شوید");
                closePup(button);
            }else{
                button.closest('.ModalComponent__content-XqD1rL.ModalComponent__animation-JkgpfL.ModalComponent__content--desktop-o5IbOt.ModalComponent__content--border-md-4G9biy.overflow-auto').attr('data-status', 'ibc').css({
                    'transform': 'translateY(50%)',
                    'width': '1506px',
                    'max-height': '95vh'
                });
                button.closest('.ModalComponent__content-XqD1rL').find('.uModalComponent__body-WvxQuY').html(res.html);
                button.closest('.ModalComponent__content-XqD1rL').find('.ModalComponent__header-l62jh_ p').text("سبد خرید");
                button.closest('.ModalComponent__footerContainer-rb1vEj').html(`<div class="ProfileModal__footer-IVQdrc"> <button class="relative d-flex ai-center user-select-none btn-wc51H8 text-button-2 btn--primary-uiqWij radius Button__medium-gIvke_ Button__filledPrimary-OvgwGb ProfileBase__button-jvi4aR ProfileBase__button__modal-O3kjhU Button-pp45" data-testid="button-wrapper" type="button" style="background-color: #d41a1a !important;border-color: #d41a1a;"><div class="d-flex ai-center jc-center relative grow-1">بستن</div></button></div>`);
                bankCardsSwiper();
                startCartTimer();
                supportedBrandsSwiper();
                paymentButton();
                window.vip = res.v;
                const lottieContainers = document.querySelectorAll('.lottie-container');

                lottieContainers.forEach(container => {
                    const animationPath = container.getAttribute('data-lottie-url');

                    if (animationPath) {
                        lottie.loadAnimation({
                            container: container, // المانی که انیمیشن در آن قرار می‌گیرد
                            renderer: 'svg',       // نوع رندر (svg بهترین گزینه است)
                            loop: true,            // تکرار انیمیشن
                            autoplay: true,        // اجرای خودکار
                            path: animationPath    // آدرس فایل JSON آپلود شده
                        });
                        container.setAttribute('data-lottie-url', '');
                    }

                });
            }
            const previewEl = document.createElement('div');
            previewEl.id = 'card-preview';
            document.body.appendChild(previewEl);

            document.querySelectorAll('.bank-card').forEach(card => {
                card.addEventListener('mouseenter', () => {
                    const rect = card.getBoundingClientRect();

                    // کپی کردن محتوای کارت داخل پیش‌نمایش
                    previewEl.innerHTML = card.querySelector(".V10-3-Bank").outerHTML;

                    // قرار دادن دقیق روی مختصات کارت اصلی
                    previewEl.style.top = `${rect.top}px`;
                    previewEl.style.left = `${rect.left}px`;
                    previewEl.style.width = `${rect.width}px`;
                    previewEl.style.height = `${rect.height}px`;

                    previewEl.classList.add('active');
                });

                card.addEventListener('mouseleave', () => {
                    previewEl.classList.remove('active');
                });
            });
            button.html(originalHTML);
            button.prop('disabled', false);
        },'v2')
    });
    $(document).on('click', '.Cart-gd445', function (e) {
        e.preventDefault();
        e.stopPropagation();
        const el = document.querySelector('.SJf5G');
        if (el && !el.classList.contains('hidden')) {
            if (window.location.pathname === '/' || window.location.pathname === '') {
                const btnTop = document.getElementById('user-cart').getBoundingClientRect().top + window.scrollY;
                window.scrollTo({
                    top: btnTop - 80,
                    behavior: "smooth"
                });
            } else {
                const button = $(this);
                const originalHTML = button.html();
                button.prop('disabled', true);
                button.html(`<div class="d-flex ai-center jc-center relative grow-1"> <div class="uikit-atomic-Button-Button-module__Loading--jNJ_Z" data-testid="button-loading"> <div style="border-color: #000000 transparent;"></div> </div> </div>`);
                SAJ('pupCart', {}, function (res) {
                    if (!res.status) {
                        uikit__collections_error("ابتدا وارد شوید");
                        closePup(button);
                    } else {
                        document.body.classList.add("lock-body-scroll");
                        if (res.empty){
                            const el = document.querySelector('.SJf5G');
                            if (el){
                                if (!el.classList.contains('hidden')){
                                    el.classList.toggle("hidden")
                                }
                                el.textContent = 0;
                            }
                        }
                        if($(".mobileCart").length !=0){
                            closePup($(".mobileCart"))
                        }
                        const countCart = document.querySelectorAll(".w-1\\/5")[2].querySelector("a div");
                        if (countCart) {
                            countCart.remove();
                            window.cart = '';
                        }
                        const contienr = document.querySelector("#popper-root");
                        const div = document.createElement("div");
                        div.className = 'absolute';
                        div.innerHTML = `<div class="ModalComponent__root-YwCAMP ModalComponent__root--desktop-JzGyNl ModalComponent__animation-JkgpfL ModalComponent__root--open-i5pSf7 ModalComponent__root--open__desktop-x1XDzU"><div class="ModalComponent__content-XqD1rL ModalComponent__animation-JkgpfL ModalComponent__content--desktop-o5IbOt ModalComponent__content--border-md-4G9biy overflow-auto" data-status="ibc" style="transform: translateY(50%);width: 1506px;max-height: 95vh;"> <div class="ModalComponent__header-l62jh_"><div class="d-flex ai-center AppHeader__headerBorder-sqCler  jc-between ProfileModal__header-QU8G4w"> <p class="text-h5 color-n-700 text-h5 text-color-neutral-700">سبد خرید</p> <div class="d-flex pointer pointer mr-2" data-testid="close-wrapper"> <svg style="width: 24px; height: 24px; fill: var(--color-icon-high-emphasis);"> <path d="M12 11.0537C12 11.0537 16.2827 6.77342 17.8617 5.19523C18.1221 4.93492 18.5443 4.93492 18.8047 5.19523C19.0651 5.45553 19.0651 5.87753 18.8047 6.13783C17.2257 7.71602 12.9391 12 12.9391 12C12.9391 12 17.2257 16.284 18.8047 17.8622C19.0651 18.1225 19.0651 18.5445 18.8047 18.8047C18.5443 19.0651 18.1221 19.0651 17.8617 18.8048C16.2827 17.2266 12 12.9463 12 12.9463C12 12.9463 7.7173 17.2266 6.1383 18.8048C5.8779 19.0651 5.4557 19.0651 5.1953 18.8048C4.9349 18.5445 4.9349 18.1225 5.1953 17.8622C6.7743 16.284 11.0609 12 11.0609 12C11.0609 12 6.7743 7.71602 5.1953 6.13783C4.9349 5.87753 4.9349 5.45552 5.1953 5.19533C5.4557 4.93493 5.8779 4.93492 6.1383 5.19523C7.7173 6.77342 12 11.0537 12 11.0537Z"></path> </svg></div> </div> </div> <div class="uModalComponent__body-WvxQuY ModalComponent__body--default-sYpvC3">${res.html}</div><div class="grow-1"></div><div class="ModalComponent__footerContainer-rb1vEj"><div class="ProfileModal__footer-IVQdrc"> <button class="relative d-flex ai-center user-select-none btn-wc51H8 text-button-2 btn--primary-uiqWij radius Button__medium-gIvke_ Button__filledPrimary-OvgwGb ProfileBase__button-jvi4aR ProfileBase__button__modal-O3kjhU Button-pp45" data-testid="button-wrapper" type="button" style="background-color: #d41a1a !important;border-color: #d41a1a;"><div class="d-flex ai-center jc-center relative grow-1">بستن</div></button></div></div></div></div>`;
                        contienr.appendChild(div);
                        startCartTimer();
                        bankCardsSwiper();
                        supportedBrandsSwiper();
                        window.vip = res.v;
                        const lottieContainers = document.querySelectorAll('.lottie-container');

                        lottieContainers.forEach(container => {
                            const animationPath = container.getAttribute('data-lottie-url');

                            if (animationPath) {
                                lottie.loadAnimation({
                                    container: container, // المانی که انیمیشن در آن قرار می‌گیرد
                                    renderer: 'svg',       // نوع رندر (svg بهترین گزینه است)
                                    loop: true,            // تکرار انیمیشن
                                    autoplay: true,        // اجرای خودکار
                                    path: animationPath    // آدرس فایل JSON آپلود شده
                                });
                                container.setAttribute('data-lottie-url', '');
                            }

                        });
                        paymentButton();
                    }
                    button.html(originalHTML);
                    button.prop('disabled', false);
                }, 'v2')
            }
        }else{
            uikit__collections_error('سبد خرید خالی میباشد');
        }
    });
    $(document).on('change','#wallet', function () {
        const useWallet = $(this).is(':checked') ? 1 : 0;
        $(".before\\:loading").addClass("is-loading").css('filter', 'blur(0px)');
        $(".before\\:loading > div").css('filter', 'blur(1px)');
        SAJ('update-wallet',{useWallet:useWallet},function (res){
            if (res.success){
                   $(".before\\:loading").removeClass("is-loading");
                $(".before\\:loading > div").css('filter', 'blur(0px)');
                $("[data-summary=\"total\"] span").text(res.total);
                $("#balance").text(res.available);
                const element = document.querySelector("#balance");
                const target  = res.available;

                const duration = 1000;
                const step = Math.ceil(target / (duration / 16));
                let current = 0;
                const timer = setInterval(() => {
                    current += step;
                    if (current >= target) {
                        current = target;
                        clearInterval(timer);
                    }
                    element.textContent = current.toLocaleString();
                }, 16);

            }else {
                uikit__collections_error("خطایی رخ داده است");
            }
        },'v1',{ withCredentials: true })
    });
    $(document).on('change','#walletApi', function () {
        const useWallet = $(this).is(':checked') ? 1 : 0;
        $("#popper-root .space-y-10.lg\\:space-y-12.lg\\:sticky.lg\\:top-28").addClass("is-loading").css('filter', 'blur(0px)');
        $("#popper-root .space-y-10.lg\\:space-y-12.lg\\:sticky.lg\\:top-28 > div").css('filter', 'blur(1px)');
        SAJ('update-wallet',{useWallet:useWallet},function (res){
               $("#popper-root .space-y-10.lg\\:space-y-12.lg\\:sticky.lg\\:top-28").removeClass("is-loading");
                $("#popper-root .space-y-10.lg\\:space-y-12.lg\\:sticky.lg\\:top-28 > div").css('filter', 'blur(0px)');
            if (res.success){
                $("#popper-root [data-summary=\"total\"]").text(res.total);
                $("[data-summary=\"dtotal\"]").text(res.dtotal);
            }else {
                uikit__collections_error("خطایی رخ داده است");
            }
        },'v1',{ withCredentials: true })
    });
    $(document).on('click', '.Button-cc65', function (e) {
        e.preventDefault();
        const button = $(this);
        const originalHTML = button.html();
        button.prop('disabled', true);
        button.html(`<div class="d-flex ai-center jc-center relative grow-1"> <div class="uikit-atomic-Button-Button-module__Loading--jNJ_Z" data-testid="button-loading"> <div style="border-color: #000 transparent"></div> </div> </div>`);
        SAJ('points', {}, function (d) {
                if (d.status == true) {
                    uikit__collections_success(d.message);
                    $(".wejF5").html(d.points + " امتیاز");
                    $("#balance").html(d.balance + " تومان");
                    button.prop('disabled', false);
                    button.html(originalHTML);
                } else {
                    uikit__collections_error(d.message);
                    button.prop('disabled', false);
                    button.html(originalHTML);
                }
            },
            'v2'
        );
    });
    function detectBankImage(cardNumber) {
        cardNumber = cardNumber.replace(/\D/g, '');
        if (cardNumber.length < 6) return false;

        const bin = cardNumber.substring(0, 6);

        const banks = {
            '603799': '/assets/banks/bmi.svg',
            '589210': '/assets/banks/sph.svg',
            '627648': '/assets/banks/edbi.svg',
            '207177': '/assets/banks/edbi.svg',
            '627961': '/assets/banks/bim.svg',
            '603770': '/assets/banks/bki.svg',
            '639217': '/assets/banks/bki.svg',
            '628023': '/assets/banks/msk.svg',
            '627760': '/assets/banks/pst.svg',
            '502908': '/assets/banks/ttb.svg',
            '603769': '/assets/banks/bsi.svg',
            '610433': '/assets/banks/bmt.svg',
            '991975': '/assets/banks/bmt.svg',
            '589463': '/assets/banks/rfh.svg',
            '627353': '/assets/banks/tjr.svg',
            '585983': '/assets/banks/tjr.svg',

            // بانک‌های خصوصی
            '627412': '/assets/banks/enb.svg',
            '622106': '/assets/banks/prs.svg',
            '639194': '/assets/banks/prs.svg',
            '627884': '/assets/banks/prs.svg',
            '502229': '/assets/banks/bpi.svg',
            '639347': '/assets/banks/bpi.svg',
            '627488': '/assets/banks/kar.svg',
            '502910': '/assets/banks/kar.svg',
            '621986': '/assets/banks/sb24.svg',
            '639346': '/assets/banks/sina.svg',
            '639607': '/assets/banks/sbn.svg',
            '636214': '/assets/banks/ba24.svg',
            '504706': '/assets/banks/shahr.svg',
            '502806': '/assets/banks/shahr.svg',
            '502938': '/assets/banks/day.svg',
            '639599': '/assets/banks/sph.svg',
            '636949': '/assets/banks/sph.svg',
            '505416': '/assets/banks/tour.svg',
            '585947': '/assets/banks/kme.svg',

            '627381': '/assets/banks/sph.svg',
            '505785': '/assets/banks/izb.svg',
            '636795': '/assets/banks/cbi.svg',
            '606373': '/assets/banks/qmb.svg',
            '504172': '/assets/banks/rqb.svg',
            '505801': '/assets/banks/sph.svg',
            '639370': '/assets/banks/sph.svg',
            '507677': '/assets/banks/noor.svg',
            '581874': '/assets/banks/ivbb.svg',
        };

        return banks[bin] || false;
    }
    function detectBankImageBg(cardNumber,v) {
        cardNumber = cardNumber.replace(/\D/g, '');
        if (cardNumber.length < 6) return false;

        const bin = cardNumber.substring(0, 6);

        const banks = {
            '603799': {img:`/assets/banks/bg/bmi/${v}.svg`,color:null,positionText:'47',Box:{x:8,y:74,color:"#000"}},
            '589210': {img:`/assets/banks/bg/sph/${v}.svg`,color:null,positionText:'35',Box:{x:6,y:60,color:"#000"}},
            '207177': {img:`/assets/banks/bg/all/${v}.svg`,color:null,positionText:'50',Box:{x:6,y:78,color:"#000"}},
            '627648': {img:`/assets/banks/bg/all/${v}.svg`,color:null,positionText:'50',Box:{x:6,y:78,color:"#000"}},
            '627961': {img:`/assets/banks/bg/all/${v}.svg`,color:null,positionText:'50',Box:{x:6,y:78,color:"#000"}},
            '603770': {img:`/assets/banks/bg/bki/${v}.svg`,color:null,positionText:'47',Box:{x:8,y:74,color:"#000"}},
            '639217': {img:`/assets/banks/bg/bki/${v}.svg`,color:null,positionText:'47',Box:{x:6,y:74,color:"#000"}},
            '628023': {img:`/assets/banks/bg/msk/${v}.svg`,color:null,positionText:'50',Box:{x:8,y:81,color:"#000"}},
            '627760': {img:`/assets/banks/bg/pst/${v}.svg`,color:null,positionText:'50',Box:{x:5,y:79,color:"#000"}},
            '502908': {img:`/assets/banks/bg/all/${v}.svg`,color:null,positionText:'50',Box:{x:6,y:78,color:"#000"}},
            '603769': {img:`/assets/banks/bg/bsi/${v}.svg`,color:null,positionText:'50',Box:{x:6,y:76,color:"#000"}},
            '610433': {img:`/assets/banks/bg/mlt/${v}.svg`,color:"#FFF",positionText:'50',Box:{x:9,y:80,color:"#000"}},
            '991975': {img:`/assets/banks/bg/mlt/${v}.svg`,color:"#FFF",positionText:'50',Box:{x:9,y:80,color:"#000"}},
            '589463': {img:`/assets/banks/bg/rfh/${v}.svg`,color:null,positionText:'38',Box:{x:6,y:67,color:"#000"}},
            '627353': {img:`/assets/banks/bg/all/${v}.svg`,color:null,positionText:'50',Box:{x:6,y:78,color:"#000"}},
            '585983': {img:`/assets/banks/bg/all/${v}.svg`,color:null,positionText:'50',Box:{x:6,y:78,color:"#000"}},

            // بانک‌های خصوصی
            '627412': {img:`/assets/banks/bg/enb/${v}.svg`,color:"#FFF",positionText:'45',Box:{x:9,y:83,color:"#FFF"}},
            '622106': {img:`/assets/banks/bg/prs/${v}.svg`,color:null,positionText:'55',Box:{x:9,y:83,color:"#000"}},
            '639194': {img:`/assets/banks/bg/prs/${v}.svg`,color:null,positionText:'55',Box:{x:9,y:83,color:"#000"}},
            '627884': {img:`/assets/banks/bg/prs/${v}.svg`,color:null,positionText:'55',Box:{x:9,y:83,color:"#000"}},
            '502229': {img:`/assets/banks/bg/bpi/${v}.svg`,color:"#FFF",positionText:'45',Box:{x:9,y:73,color:"#FFF"}},
            '639347': {img:`/assets/banks/bg/bpi/${v}.svg`,color:"#FFF",positionText:'45',Box:{x:9,y:73,color:"#FFF"}},
            '627488': {img:`/assets/banks/bg/kar/${v}.svg`,color:"#FFF",positionText:'45',Box:{x:9,y:73,color:"#FFF"}},
            '502910': {img:`/assets/banks/bg/kar/${v}.svg`,color:"#FFF",positionText:'45',Box:{x:9,y:73,color:"#FFF"}},
            '621986': {img:`/assets/banks/bg/sb24/${v}.svg`,color:null,positionText:'45',Box:{x:9,y:83,color:"#000"}},
            '639346': {img:`/assets/banks/bg/sina/${v}.svg`,color:null,positionText:'46',Box:{x:7,y:78,color:"#000"}},
            '639607': {img:`/assets/banks/bg/sbn/${v}.svg`,color:null,positionText:'46',Box:{x:6,y:78,color:"#000"}},
            '636214': {img:`/assets/banks/bg/all/${v}.svg`,color:null,positionText:'50',Box:{x:6,y:78,color:"#000"}},
            '504706': {img:`/assets/banks/bg/shahr/${v}.svg`,color:null,positionText:'40',Box:{x:6,y:65,color:"#000"}},
            '502806': {img:`/assets/banks/bg/shahr/${v}.svg`,color:null,positionText:'40',Box:{x:6,y:65,color:"#000"}},
            '502938': {img:`/assets/banks/bg/day/${v}.svg`,color:null,positionText:'43',Box:{x:6,y:78,color:"#000"}},
            '639599': {img:`/assets/banks/bg/sph/${v}.svg`,color:null,positionText:'35',Box:{x:6,y:60,color:"#000"}},
            '636949': {img:`/assets/banks/bg/sph/${v}.svg`,color:null,positionText:'35',Box:{x:6,y:60,color:"#000"}},
            '505416': {img:`/assets/banks/bg/tour/${v}.svg`,color:null,positionText:'35',Box:{x:9,y:74,color:"#fff"}},
            '585947': {img:`/assets/banks/bg/kme/${v}.svg`,color:null,positionText:'39',Box:{x:7,y:78,color:"#000"}},

            '627381': {img:`/assets/banks/bg/sph/${v}.svg`,color:null,positionText:'35',Box:{x:6,y:60,color:"#000"}},
            '505785': {img:`/assets/banks/bg/izb/${v}.svg`,color:null,positionText:'40',Box:{x:6,y:74,color:"#000"}},
            '636795': {img:`/assets/banks/bg/all/${v}.svg`,color:null,positionText:'50',Box:{x:6,y:78,color:"#000"}},
            '606373': {img:`/assets/banks/bg/qmb/${v}.svg`,color:null,positionText:'40',Box:{x:6,y:78,color:"#000"}},
            '504172': {img:`/assets/banks/bg/rqb/${v}.svg`,color:null,positionText:'40',Box:{x:6,y:74,color:"#000"}},
            '505801': {img:`/assets/banks/bg/sph/${v}.svg`,color:null,positionText:'35',Box:{x:6,y:60,color:"#000"}},
            '639370': {img:`/assets/banks/bg/sph/${v}.svg`,color:null,positionText:'35',Box:{x:6,y:60,color:"#000"}},
            '606256': {img:`/assets/banks/bg/all/${v}.svg`,color:null,positionText:'50',Box:{x:6,y:78,color:"#000"}},
            '507677': {img:`/assets/banks/bg/all/${v}.svg`,color:null,positionText:'50',Box:{x:6,y:78,color:"#000"}},
            '581874': {img:`/assets/banks/bg/all/${v}.svg`,color:null,positionText:'50',Box:{x:6,y:78,color:"#000"}},
        };

        return banks[bin] || false;
    }

    $(document).on('click', '.Button-ac45', function (e) {
        e.preventDefault();
        document.body.classList.toggle("lock-body-scroll");
        const contienr = document.querySelector("#popper-root");
        const div = document.createElement("div");
        div.className = 'absolute';
        div.innerHTML = `<div class="ModalComponent__root-YwCAMP ModalComponent__root--desktop-JzGyNl ModalComponent__animation-JkgpfL ModalComponent__root--open-i5pSf7 ModalComponent__root--open__desktop-x1XDzU"> <div class="ModalComponent__content-XqD1rL ModalComponent__animation-JkgpfL ModalComponent__content--desktop-o5IbOt ModalComponent__content--border-md-4G9biy overflow-auto " style="transform: translateY(50%);"> <div class="ModalComponent__header-l62jh_"> <div class="d-flex ai-center AppHeader__headerBorder-sqCler  jc-between ProfileModal__header-QU8G4w"><p class="text-h5 color-n-700 text-h5 text-color-neutral-700">افزودن شماره کارت</p> <div class="d-flex pointer pointer mr-2" data-testid="close-wrapper"> <svg style="width: 24px; height: 24px; fill: var(--color-icon-high-emphasis);"> <path d="M12 11.0537C12 11.0537 16.2827 6.77342 17.8617 5.19523C18.1221 4.93492 18.5443 4.93492 18.8047 5.19523C19.0651 5.45553 19.0651 5.87753 18.8047 6.13783C17.2257 7.71602 12.9391 12 12.9391 12C12.9391 12 17.2257 16.284 18.8047 17.8622C19.0651 18.1225 19.0651 18.5445 18.8047 18.8047C18.5443 19.0651 18.1221 19.0651 17.8617 18.8048C16.2827 17.2266 12 12.9463 12 12.9463C12 12.9463 7.7173 17.2266 6.1383 18.8048C5.8779 19.0651 5.4557 19.0651 5.1953 18.8048C4.9349 18.5445 4.9349 18.1225 5.1953 17.8622C6.7743 16.284 11.0609 12 11.0609 12C11.0609 12 6.7743 7.71602 5.1953 6.13783C4.9349 5.87753 4.9349 5.45552 5.1953 5.19533C5.4557 4.93493 5.8779 4.93492 6.1383 5.19523C7.7173 6.77342 12 11.0537 12 11.0537Z"></path> </svg> </div> </div> </div> <div class="uModalComponent__body-WvxQuY ModalComponent__body--default-sYpvC3"> <div class="Hint--primary-mwFS2H Hint__padding-nRd4K4 radius Hint__iconStart-bpg5ZO mb-3" data-testid="hint-wrapper"> <div class="d-flex ai-center"> <div class="d-flex Hint__titleSlot-yPP6H0" data-testid="icon-wrapper"> <svg style="width: 24px; height: 24px; fill: #1ab1d4;"> <path d="M2 12c0 5.523 4.477 10 10 10s10-4.477 10-10c0-5.523-4.477-10-10-10s-10 4.477-10 10zM12 7c0.552 0 1 0.448 1 1s-0.448 1-1 1c-0.552 0-1-0.448-1-1s0.448-1 1-1zM10 10h3v7h-2v-5h-1v-2z"></path> </svg> </div> <span class="mr-2 text-body-1 color-brand-primary-700 Hint__padding--title-AHG0eM">صرفاً در صورتی که کارت بانکی ثبت‌شده متعلق به کد ملی شما باشد، فرآیند افزودن کارت بدون نیاز به ارائه اطلاعات تکمیلی انجام می‌پذیرد. در صورت ثبت کارت‌های متعلق به اشخاص دیگر، درج شماره تلفن، کد ملی و تاریخ تولد صاحب کارت الزامی خواهد بود.</span> </div> </div> <div class="bV40_bank normal" style="height: 40px"> <input class="TextField__input-xuVYy" name="number" autocomplete="off" maxlength="19" inputmode="numeric"> </div> </div> <div class="grow-1"></div> <div class="ModalComponent__footerContainer-rb1vEj media"> <div class="ProfileModal__footer-IVQdrc media justify-between" style="display: flex"> <button class="Button_vd96"></button> <div class="progress-ring"> <svg viewBox="0 0 200 200"> <defs> <linearGradient id="gradient" x1="0%" y1="0%" x2="100%" y2="0%"> <stop offset="0%" stop-color="#14b8a6"></stop> <stop offset="50%" stop-color="#22d3bb"></stop> <stop offset="100%" stop-color="#2dd4bf"></stop> </linearGradient> </defs> <circle class="track" cx="100" cy="100" r="90"></circle> <circle class="progress" cx="100" cy="100" r="90" style="stroke-dashoffset: 565.487;"></circle> </svg> <div class="percent-text">0٪</div> </div> </div> </div> </div> </div>`;
        contienr.appendChild(div);
        const input = document.querySelector('input[name="number"]');

        input.addEventListener('input', function (e) {
            const numberCart = this.value;
            let value = this.value.replace(/\D/g, '').substring(0, 16);
            const newImage = detectBankImageBg(value,'v2').img;
            const newImageV1 = detectBankImageBg(value,'v1');
            let NumverCard;
            if (newImageV1.color !=null){
                NumverCard = `style="color:${newImageV1.color};bottom:${newImageV1.positionText}px"`;
            }else{
                NumverCard = `style="bottom:${newImageV1.positionText}px"`;
            }
            const Box = document.querySelector('.bV40_bank');
            if (value.length ==16){
                e.target.blur();
                SAJ('addCart',{value:value},function (res) {
                    if (!res.status){
                        uikit__collections_error(res.message);
                        return;
                    }
                    if (res.verify) {
                        if(res.drg){
                            setProgress(90);
                            uikit__collections_error("این کارت به نام شما ثبت نشده لطفا مراحل را ادامه دهید")
                            document.querySelector("#popper-root .absolute .ModalComponent__header-l62jh_ p").innerHTML = `تایید تلفن همراه`;
                            document.querySelector("#popper-root .absolute .uModalComponent__body-WvxQuY.ModalComponent__body--default-sYpvC3").innerHTML = `<p class="mb-2 color-n-700 text-body-1 mb-2" data-testid="form-label">تماس صوتی را جواب دهید و کد otp را وارد کنید</p><div class="_wrap_87tyg_1 _input_pjp0p_66"> <input type="text" class="_input_87tyg_11" data-method="cart" inputmode="numeric"> <div class="_digit_87tyg_33"><span></span></div> <div class="_digit_87tyg_33"><span></span></div> <div class="_digit_87tyg_33"><span></span></div> <div class="_digit_87tyg_33"><span></span></div> <div class="_digit_87tyg_33"><span></span></div> <div class="_digit_87tyg_33"><span></span></div> </div><input class="hidden" type="text" name="drg" value="${res.drg}">`;
                        }else {
                            setProgress(90);
                            document.querySelector("#popper-root .absolute .ModalComponent__header-l62jh_ p").innerHTML = `تایید تلفن همراه`;
                            document.querySelector("#popper-root .absolute .uModalComponent__body-WvxQuY.ModalComponent__body--default-sYpvC3").innerHTML = `<p class="mb-2 color-n-700 text-body-1 mb-2" data-testid="form-label">تماس صوتی را جواب دهید و کد otp را وارد کنید</p><div class="_wrap_87tyg_1 _input_pjp0p_66"> <input type="text" class="_input_87tyg_11" data-method="cartOtp" inputmode="numeric"> <div class="_digit_87tyg_33"><span></span></div> <div class="_digit_87tyg_33"><span></span></div> <div class="_digit_87tyg_33"><span></span></div> <div class="_digit_87tyg_33"><span></span></div> <div class="_digit_87tyg_33"><span></span></div> <div class="_digit_87tyg_33"><span></span></div> </div><input class="hidden" type="text" name="hash" value="${res.hash}">`;
                        }
                    }else{
                        Box.classList.add("animation-out-top");
                        if (isMobileDevice()){
                            $("#popper-root .absolute .uModalComponent__body-WvxQuY.ModalComponent__body--default-sYpvC3").animate({
                                height: "40px"
                            }, 300);
                            setTimeout(function (){
                                const boxcard = `<div class="V10-3-Bank normal"><img src="${ wpApiSettingsGiftMax.directory + newImageV1.img}"><span class="numberCard" ${NumverCard}>${numberCart}</span><span class="full__name-user" style="right: ${newImageV1.Box.x}%;bottom: ${newImageV1.Box.y}px;color:${newImageV1.Box.color}"></span><span class="birthday-user" style="bottom: ${newImageV1.Box.y}px;color:${newImageV1.Box.color}"></span><span class="national__code-user" style="bottom: ${newImageV1.Box.y}px;color:${newImageV1.Box.color}"></span><span class="number-user" style="bottom: ${newImageV1.Box.y}px;color:${newImageV1.Box.color}"></span></div>`;
                                setProgress(50);
                                uikit__collections_error("کارت متعلق به شما نبود");
                                const Button = document.querySelector('.Button_vd96');
                                Button.className = 'relative d-flex ai-center user-select-none btn-wc51H8 text-button-2 btn--primary-uiqWij radius Button__medium-gIvke_ Button__filledPrimary-OvgwGb ProfileBase__button-jvi4aR ProfileBase__button__modal-O3kjhU Button-vc45';
                                Button.innerHTML = `<div class="d-flex ai-center jc-center relative grow-1">افزودن</div>`;
                                $("#popper-root .absolute .uModalComponent__body-WvxQuY.ModalComponent__body--default-sYpvC3").html(`${boxcard}<div class="Hint--primary-mwFS2H Hint__padding-nRd4K4 radius Hint__iconStart-bpg5ZO mb-3" data-testid="hint-wrapper"><div class="d-flex ai-center"><div class="d-flex Hint__titleSlot-yPP6H0" data-testid="icon-wrapper"><svg style="width: 24px; height: 24px; fill: #1ab1d4;"><path d="M2 12c0 5.523 4.477 10 10 10s10-4.477 10-10c0-5.523-4.477-10-10-10s-10 4.477-10 10zM12 7c0.552 0 1 0.448 1 1s-0.448 1-1 1c-0.552 0-1-0.448-1-1s0.448-1 1-1zM10 10h3v7h-2v-5h-1v-2z"></path></svg></div><span class="mr-2 text-body-1 color-brand-primary-700 Hint__padding--title-AHG0eM">برای تکمیل مراحل لطفا شماره تلفن،کدملی و تاریخ تولد متعلق به صاحب کارت را وارد کنید</span></div></div><div class="d-flex flex-column gap-y-5"><div class="d-flex"> <div class="lg:w-50"> <label class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--L7bcQ uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--normal--A6Ntt w-full"> <p class="text-body-1 color-n-700 mb-2 text-right" data-testid="form-label">نام</p> <div class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame__input-container--D5edN px-2 d-flex ai-center"> <section class="grow-1 text-body-2-c"><input class="px-2 eFydYiN7dQ1Ds63mli7f text-subtitle w-100 jDSbpqUrUZFv23opBao9 color-n-700" type="text" name="first_name" placeholder="" value=""></section> </div> </label> </div> <div class="lg:w-50 mr-3"> <label class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--L7bcQ uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--normal--A6Ntt w-full"> <p class="text-body-1 color-n-700 mb-2 text-right" data-testid="form-label">نام خانوادکی</p> <div class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame__input-container--D5edN px-2 d-flex ai-center"> <section class="grow-1 text-body-2-c"><input class="px-2 eFydYiN7dQ1Ds63mli7f text-subtitle w-100 jDSbpqUrUZFv23opBao9 color-n-700" type="text" name="last_name" placeholder="" value=""></section> </div> </label> </div> </div><label class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--L7bcQ uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--normal--A6Ntt text-body-1 color-n-700 w-100"><p class="mb-2 color-n-700 text-body-1 mb-2" data-testid="form-label">شماره همراه</p><div class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame__input-container--D5edN px-2 d-flex ai-center"><section class="grow-1 text-body-2-c"><input class="px-2 TextField__input-_5fbdd text-subtitle w-100 TextField-e58168" type="text" name="phone-number"></section></div></label> <div class="row"> <div class="diexjw5" data-select2-id="select2-data-9-k644"> <div class="form-group col-sm-12" data-select2-id="select2-data-8-0exr"> <p class="text-body-1 color-n-700 mb-2 text-right" data-testid="form-label">تاریخ تولد</p> <div class="row g-2"> <div class="col-4"> <div class="form-group"> <select class="js-example-basic-single select2-hidden-accessible" name="year" id="year" data-select2-id="select2-data-year" tabindex="-1" aria-hidden="true"> <option value="" disabled="" selected="" data-select2-id="select2-data-2-dxoo"> سال </option> <option value="1320">1320</option> <option value="1321">1321</option> <option value="1322">1322</option> <option value="1323">1323</option> <option value="1324">1324</option> <option value="1325">1325</option> <option value="1326">1326</option> <option value="1327">1327</option> <option value="1328">1328</option> <option value="1329">1329</option> <option value="1330">1330</option> <option value="1331">1331</option> <option value="1332">1332</option> <option value="1333">1333</option> <option value="1334">1334</option> <option value="1335">1335</option> <option value="1336">1336</option> <option value="1337">1337</option> <option value="1338">1338</option> <option value="1339">1339</option> <option value="1340">1340</option> <option value="1341">1341</option> <option value="1342">1342</option> <option value="1343">1343</option> <option value="1344">1344</option> <option value="1345">1345</option> <option value="1346">1346</option> <option value="1347">1347</option> <option value="1348">1348</option> <option value="1349">1349</option> <option value="1350">1350</option> <option value="1351">1351</option> <option value="1352">1352</option> <option value="1353">1353</option> <option value="1354">1354</option> <option value="1355">1355</option> <option value="1356">1356</option> <option value="1357">1357</option> <option value="1358">1358</option> <option value="1359">1359</option> <option value="1360">1360</option> <option value="1361">1361</option> <option value="1362">1362</option> <option value="1363">1363</option> <option value="1364">1364</option> <option value="1365">1365</option> <option value="1366">1366</option> <option value="1367">1367</option> <option value="1368">1368</option> <option value="1369">1369</option> <option value="1370">1370</option> <option value="1371">1371</option> <option value="1372">1372</option> <option value="1373">1373</option> <option value="1374">1374</option> <option value="1375">1375</option> <option value="1376">1376</option> <option value="1377">1377</option> <option value="1378">1378</option> <option value="1379">1379</option> <option value="1380">1380</option> <option value="1381">1381</option> <option value="1382">1382</option> <option value="1383">1383</option> <option value="1384">1384</option> <option value="1385">1385</option> <option value="1386">1386</option> <option value="1387">1387</option> </select> </div> </div> <div class="col-4"> <div class="form-group"> <select class="js-example-basic-single select2-hidden-accessible" name="month" id="month" data-select2-id="select2-data-month" tabindex="-1" aria-hidden="true"> <option value="" disabled="" selected="" data-select2-id="select2-data-4-s9eo"> ماه </option> <option value="01" data-select2-id="select2-data-15-h89y">فروردین</option><option value="02" data-select2-id="select2-data-16-8m35">اردیبهشت</option><option value="03" data-select2-id="select2-data-17-nepr">خرداد</option><option value="04" data-select2-id="select2-data-18-pzth">تیر</option><option value="05" data-select2-id="select2-data-19-ntlh">مرداد</option><option value="06" data-select2-id="select2-data-20-9qy8">شهریور</option><option value="07" data-select2-id="select2-data-21-hu81">مهر</option><option value="08" data-select2-id="select2-data-22-hvit">آبان</option><option value="09" data-select2-id="select2-data-23-xi7i">آذر</option><option value="10" data-select2-id="select2-data-24-bozm">دی</option><option value="11" data-select2-id="select2-data-25-dud8">بهمن</option><option value="12" data-select2-id="select2-data-26-zmw3">اسفند</option>                                            </select> </div> </div> <div class="col-4"> <div class="form-group"> <select class="js-example-basic-single select2-hidden-accessible" name="day" id="day" data-select2-id="select2-data-day" tabindex="-1" aria-hidden="true"> <option value="" disabled="" selected="" data-select2-id="select2-data-6-vgsy"> روز </option> <option value="01">01</option> <option value="02">02</option> <option value="03">03</option> <option value="04">04</option> <option value="05">05</option> <option value="06">06</option> <option value="07">07</option> <option value="08">08</option> <option value="09">09</option> <option value="10">10</option> <option value="11">11</option> <option value="12">12</option> <option value="13">13</option> <option value="14">14</option> <option value="15">15</option> <option value="16">16</option> <option value="17">17</option> <option value="18">18</option> <option value="19">19</option> <option value="20">20</option> <option value="21">21</option> <option value="22">22</option> <option value="23">23</option> <option value="24">24</option> <option value="25">25</option> <option value="26">26</option> <option value="27">27</option> <option value="28">28</option> <option value="29">29</option> <option value="30">30</option> <option value="31">31</option> </select> </div> </div> </div> </div> </div>            </div><label class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--L7bcQ uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--normal--A6Ntt lg:w-30 text-body-1 color-n-700 w-100"> <p class="mb-2 color-n-700 text-body-1 mb-2" data-testid="form-label">کدملی</p> <div class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame__input-container--D5edN px-2 d-flex ai-center"> <section class="grow-1 text-body-2-c"><input class="px-2 TextField__input-_5fbdd text-subtitle w-100 TextField-e58168" type="text" name="national-code"></section> </div> </label>  </div><input class="hidden" name="cart-number" value="${res.card_number}">`);
                                $('.js-example-basic-single').select2({
                                    width: 'resolve',
                                    dir: 'rtl'
                                });
                                Box.classList.add("animation-out-top");
                                $("#popper-root .absolute .uModalComponent__body-WvxQuY.ModalComponent__body--default-sYpvC3").animate({
                                    height: "600px"
                                }, 600);
                                setTimeout(function() {
                                    document.querySelector(".V10-3-Bank").classList.add("animation-in-top");
                                },300)
                                setTimeout(function (){
                                    document.querySelector('#popper-root .absolute .ModalComponent__body-WvxQuY.ModalComponent__body--default-sYpvC3').removeAttribute('style');
                                },600);
                            },400)
                        }else{
                            $("#popper-root .absolute .uModalComponent__body-WvxQuY.ModalComponent__body--default-sYpvC3").animate({
                                height: "40px"
                            }, 800);
                            setTimeout(function (){
                                const boxcard = `<div class="V10-3-Bank normal"><img src="${ wpApiSettingsGiftMax.directory + newImageV1.img}"><span class="numberCard" ${NumverCard}>${numberCart}</span><span class="full__name-user" style="right: ${newImageV1.Box.x}%;bottom: ${newImageV1.Box.y}px;color:${newImageV1.Box.color}"></span><span class="birthday-user" style="bottom: ${newImageV1.Box.y}px;color:${newImageV1.Box.color}"></span><span class="national__code-user" style="bottom: ${newImageV1.Box.y}px;color:${newImageV1.Box.color}"></span><span class="number-user" style="bottom: ${newImageV1.Box.y}px;color:${newImageV1.Box.color}"></span></div>`;
                                setProgress(50);
                                uikit__collections_error("کارت متعلق به شما نبود");
                                const Button = document.querySelector('.Button_vd96');
                                Button.className = 'relative d-flex ai-center user-select-none btn-wc51H8 text-button-2 btn--primary-uiqWij radius Button__medium-gIvke_ Button__filledPrimary-OvgwGb ProfileBase__button-jvi4aR ProfileBase__button__modal-O3kjhU Button-vc45';
                                Button.innerHTML = `<div class="d-flex ai-center jc-center relative grow-1">افزودن</div>`;
                                $("#popper-root .absolute .uModalComponent__body-WvxQuY.ModalComponent__body--default-sYpvC3").html(`${boxcard}<div class="Hint--primary-mwFS2H Hint__padding-nRd4K4 radius Hint__iconStart-bpg5ZO mb-3" data-testid="hint-wrapper"><div class="d-flex ai-center"><div class="d-flex Hint__titleSlot-yPP6H0" data-testid="icon-wrapper"><svg style="width: 24px; height: 24px; fill: #1ab1d4;"><path d="M2 12c0 5.523 4.477 10 10 10s10-4.477 10-10c0-5.523-4.477-10-10-10s-10 4.477-10 10zM12 7c0.552 0 1 0.448 1 1s-0.448 1-1 1c-0.552 0-1-0.448-1-1s0.448-1 1-1zM10 10h3v7h-2v-5h-1v-2z"></path></svg></div><span class="mr-2 text-body-1 color-brand-primary-700 Hint__padding--title-AHG0eM">برای تکمیل مراحل لطفا شماره تلفن،کدملی و تاریخ تولد متعلق به صاحب کارت را وارد کنید</span></div></div><div class="d-flex flex-column gap-y-5"><div class="d-flex"> <div class="lg:w-50"> <label class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--L7bcQ uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--normal--A6Ntt w-full"> <p class="text-body-1 color-n-700 mb-2 text-right" data-testid="form-label">نام</p> <div class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame__input-container--D5edN px-2 d-flex ai-center"> <section class="grow-1 text-body-2-c"><input class="px-2 eFydYiN7dQ1Ds63mli7f text-subtitle w-100 jDSbpqUrUZFv23opBao9 color-n-700" type="text" name="first_name" placeholder="" value=""></section> </div> </label> </div> <div class="lg:w-50 mr-3"> <label class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--L7bcQ uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--normal--A6Ntt w-full"> <p class="text-body-1 color-n-700 mb-2 text-right" data-testid="form-label">نام خانوادکی</p> <div class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame__input-container--D5edN px-2 d-flex ai-center"> <section class="grow-1 text-body-2-c"><input class="px-2 eFydYiN7dQ1Ds63mli7f text-subtitle w-100 jDSbpqUrUZFv23opBao9 color-n-700" type="text" name="last_name" placeholder="" value=""></section> </div> </label> </div> </div><label class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--L7bcQ uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--normal--A6Ntt text-body-1 color-n-700 w-100"><p class="mb-2 color-n-700 text-body-1 mb-2" data-testid="form-label">شماره همراه</p><div class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame__input-container--D5edN px-2 d-flex ai-center"><section class="grow-1 text-body-2-c"><input class="px-2 TextField__input-_5fbdd text-subtitle w-100 TextField-e58168" type="text" name="phone-number"></section></div></label> <div class="row"> <div class="diexjw5" data-select2-id="select2-data-9-k644"> <div class="form-group col-sm-12" data-select2-id="select2-data-8-0exr"> <p class="text-body-1 color-n-700 mb-2 text-right" data-testid="form-label">تاریخ تولد</p> <div class="row g-2"> <div class="col-4"> <div class="form-group"> <select class="js-example-basic-single select2-hidden-accessible" name="year" id="year" data-select2-id="select2-data-year" tabindex="-1" aria-hidden="true"> <option value="" disabled="" selected="" data-select2-id="select2-data-2-dxoo"> سال </option> <option value="1320">1320</option> <option value="1321">1321</option> <option value="1322">1322</option> <option value="1323">1323</option> <option value="1324">1324</option> <option value="1325">1325</option> <option value="1326">1326</option> <option value="1327">1327</option> <option value="1328">1328</option> <option value="1329">1329</option> <option value="1330">1330</option> <option value="1331">1331</option> <option value="1332">1332</option> <option value="1333">1333</option> <option value="1334">1334</option> <option value="1335">1335</option> <option value="1336">1336</option> <option value="1337">1337</option> <option value="1338">1338</option> <option value="1339">1339</option> <option value="1340">1340</option> <option value="1341">1341</option> <option value="1342">1342</option> <option value="1343">1343</option> <option value="1344">1344</option> <option value="1345">1345</option> <option value="1346">1346</option> <option value="1347">1347</option> <option value="1348">1348</option> <option value="1349">1349</option> <option value="1350">1350</option> <option value="1351">1351</option> <option value="1352">1352</option> <option value="1353">1353</option> <option value="1354">1354</option> <option value="1355">1355</option> <option value="1356">1356</option> <option value="1357">1357</option> <option value="1358">1358</option> <option value="1359">1359</option> <option value="1360">1360</option> <option value="1361">1361</option> <option value="1362">1362</option> <option value="1363">1363</option> <option value="1364">1364</option> <option value="1365">1365</option> <option value="1366">1366</option> <option value="1367">1367</option> <option value="1368">1368</option> <option value="1369">1369</option> <option value="1370">1370</option> <option value="1371">1371</option> <option value="1372">1372</option> <option value="1373">1373</option> <option value="1374">1374</option> <option value="1375">1375</option> <option value="1376">1376</option> <option value="1377">1377</option> <option value="1378">1378</option> <option value="1379">1379</option> <option value="1380">1380</option> <option value="1381">1381</option> <option value="1382">1382</option> <option value="1383">1383</option> <option value="1384">1384</option> <option value="1385">1385</option> <option value="1386">1386</option> <option value="1387">1387</option> </select> </div> </div> <div class="col-4"> <div class="form-group"> <select class="js-example-basic-single select2-hidden-accessible" name="month" id="month" data-select2-id="select2-data-month" tabindex="-1" aria-hidden="true"> <option value="" disabled="" selected="" data-select2-id="select2-data-4-s9eo"> ماه </option> <option value="01" data-select2-id="select2-data-15-h89y">فروردین</option><option value="02" data-select2-id="select2-data-16-8m35">اردیبهشت</option><option value="03" data-select2-id="select2-data-17-nepr">خرداد</option><option value="04" data-select2-id="select2-data-18-pzth">تیر</option><option value="05" data-select2-id="select2-data-19-ntlh">مرداد</option><option value="06" data-select2-id="select2-data-20-9qy8">شهریور</option><option value="07" data-select2-id="select2-data-21-hu81">مهر</option><option value="08" data-select2-id="select2-data-22-hvit">آبان</option><option value="09" data-select2-id="select2-data-23-xi7i">آذر</option><option value="10" data-select2-id="select2-data-24-bozm">دی</option><option value="11" data-select2-id="select2-data-25-dud8">بهمن</option><option value="12" data-select2-id="select2-data-26-zmw3">اسفند</option>                                            </select> </div> </div> <div class="col-4"> <div class="form-group"> <select class="js-example-basic-single select2-hidden-accessible" name="day" id="day" data-select2-id="select2-data-day" tabindex="-1" aria-hidden="true"> <option value="" disabled="" selected="" data-select2-id="select2-data-6-vgsy"> روز </option> <option value="01">01</option> <option value="02">02</option> <option value="03">03</option> <option value="04">04</option> <option value="05">05</option> <option value="06">06</option> <option value="07">07</option> <option value="08">08</option> <option value="09">09</option> <option value="10">10</option> <option value="11">11</option> <option value="12">12</option> <option value="13">13</option> <option value="14">14</option> <option value="15">15</option> <option value="16">16</option> <option value="17">17</option> <option value="18">18</option> <option value="19">19</option> <option value="20">20</option> <option value="21">21</option> <option value="22">22</option> <option value="23">23</option> <option value="24">24</option> <option value="25">25</option> <option value="26">26</option> <option value="27">27</option> <option value="28">28</option> <option value="29">29</option> <option value="30">30</option> <option value="31">31</option> </select> </div> </div> </div> </div> </div>            </div><label class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--L7bcQ uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--normal--A6Ntt lg:w-30 text-body-1 color-n-700 w-100"> <p class="mb-2 color-n-700 text-body-1 mb-2" data-testid="form-label">کدملی</p> <div class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame__input-container--D5edN px-2 d-flex ai-center"> <section class="grow-1 text-body-2-c"><input class="px-2 TextField__input-_5fbdd text-subtitle w-100 TextField-e58168" type="text" name="national-code"></section> </div> </label>  </div><input class="hidden" name="cart-number" value="${res.card_number}">`);
                                $('.js-example-basic-single').select2({
                                    width: 'resolve',
                                    dir: 'rtl'
                                });
                                Box.classList.add("animation-out-top");
                                $("#popper-root .absolute .uModalComponent__body-WvxQuY.ModalComponent__body--default-sYpvC3").animate({
                                    height: "100%"
                                }, 1000);
                                setTimeout(function() {
                                    document.querySelector(".V10-3-Bank").classList.add("animation-in-top");
                                },500)
                            },500)
                        }
                    }
                },'v2')
            }
            if (newImage) {
                $(".bV40_bank").animate({
                    height: "100%"
                }, 100);
                $(".bV40_bank").removeClass("normal");
                const newSrc = wpApiSettingsGiftMax.directory + newImage;
                if (!lastBankImage) {
                    const img = document.createElement("img");
                    img.src = newSrc;
                    img.className = "transition-opacity-0.2 animation-out"
                    Box.appendChild(img);
                    lastBankImage = newSrc;
                    setTimeout(function () {
                        img.classList.remove("animation-out");
                        img.classList.add("animation-in");
                    },1);
                    setTimeout(function (){
                        img.className = '';
                    },210)
                }
                else if (lastBankImage !== newSrc) {
                    const img = Box.querySelector("img");

                    if (img) {
                        img.src = newSrc; // smooth replace بدون flicker
                    } else {
                        const img = document.createElement("img");
                        img.src = newSrc;
                        Box.appendChild(img);
                    }

                    lastBankImage = newSrc;
                }
            }
            else {
                if (Box.querySelector("img")) {
                    const img = Box.querySelector("img");
                    img.classList.add("transition-opacity-0.2");
                    img.classList.add("animation-out");
                    setTimeout(function (){
                        img.remove();
                    },210)
                }
                lastBankImage = null;
                if (!document.querySelector('.bV40_bank').classList.contains("normal")) {
                    $(".bV40_bank").animate({
                        height: "40px"
                    }, 300);
                }
                $(".bV40_bank").addClass("normal");
            }
            let formatted = value.match(/.{1,4}/g);
            formatted = formatted ? formatted.join('-') : '';

            const cursorPosition = this.selectionStart;
            const oldLength = this.value.length;

            this.value = formatted;

            const newLength = formatted.length;
            const diff = newLength - oldLength;

            this.setSelectionRange(
                cursorPosition + diff,
                cursorPosition + diff
            );
        });
    });
    $(document).on('click', '.Buttun-td23', function () {
        const button = $(this);
        const originalHTML = button.html();
        const input = document.querySelector('input[name="number"]').value;
        const pendingCleanNumber = input.replace(/-/g, '');
        if(pendingCleanNumber.length <=0){
            uikit__collections_error("شماره را وارد نکرده اید!");
            return;
        }
        button.prop('disabled', true);
        button.html(`<div class="d-flex ai-center jc-center relative grow-1"> <div class="uikit-atomic-Button-Button-module__Loading--jNJ_Z" data-testid="button-loading"> <div></div> </div> </div>`);
        SAJ('addCart',{value:pendingCleanNumber},function (res) {
            button.html(originalHTML);
            button.prop('disabled', false);
            if (!res.status){
                uikit__collections_error(res.message);
                return;
            }
            if (res.verify) {
                if(res.drg){
                    setProgress(90);
                    uikit__collections_error("این کارت به نام شما ثبت نشده لطفا مراحل را ادامه دهید")
                    document.querySelector("#popper-root .absolute .ModalComponent__header-l62jh_ p").innerHTML = `تایید تلفن همراه`;
                    document.querySelector("#popper-root .absolute .uModalComponent__body-WvxQuY.ModalComponent__body--default-sYpvC3").innerHTML = `<p class="mb-2 color-n-700 text-body-1 mb-2" data-testid="form-label">کد otp را وارد کنید</p><div class="_wrap_87tyg_1 _input_pjp0p_66"> <input type="text" class="_input_87tyg_11" data-method="cart" inputmode="numeric"> <div class="_digit_87tyg_33"><span></span></div> <div class="_digit_87tyg_33"><span></span></div> <div class="_digit_87tyg_33"><span></span></div> <div class="_digit_87tyg_33"><span></span></div> <div class="_digit_87tyg_33"><span></span></div> <div class="_digit_87tyg_33"><span></span></div> </div><input class="hidden" type="text" name="drg" value="${res.drg}">`;
                    document.querySelector(".Buttun-td23 div").innerHTML = "";
                    document.querySelector(".Buttun-td23").className = '';
                }else {
                    setProgress(90);
                    document.querySelector("#popper-root .absolute .ModalComponent__header-l62jh_ p").innerHTML = `تایید تلفن همراه`;
                    document.querySelector("#popper-root .absolute .uModalComponent__body-WvxQuY.ModalComponent__body--default-sYpvC3").innerHTML = `<p class="mb-2 color-n-700 text-body-1 mb-2" data-testid="form-label">کد otp را وارد کنید</p><div class="_wrap_87tyg_1 _input_pjp0p_66"> <input type="text" class="_input_87tyg_11" data-method="cartOtp" inputmode="numeric"> <div class="_digit_87tyg_33"><span></span></div> <div class="_digit_87tyg_33"><span></span></div> <div class="_digit_87tyg_33"><span></span></div> <div class="_digit_87tyg_33"><span></span></div> <div class="_digit_87tyg_33"><span></span></div> <div class="_digit_87tyg_33"><span></span></div> </div><input class="hidden" type="text" name="hash" value="${res.hash}">`;
                    document.querySelector(".Buttun-td23 div").innerHTML = "";
                    document.querySelector(".Buttun-td23").className = '';
                }
            }else{
                setProgress(50);
                uikit__collections_error("کارت متعلق به شما نبود");
                document.querySelector(".Buttun-td23").classList.add('Button-vc45');
                document.querySelector(".Buttun-td23").classList.remove('Buttun-td23');
                $("#popper-root .absolute .uModalComponent__body-WvxQuY.ModalComponent__body--default-sYpvC3").html(`<div class="Hint--primary-mwFS2H Hint__padding-nRd4K4 radius Hint__iconStart-bpg5ZO mb-3" data-testid="hint-wrapper"><div class="d-flex ai-center"><div class="d-flex Hint__titleSlot-yPP6H0" data-testid="icon-wrapper"><svg style="width: 24px; height: 24px; fill: #1ab1d4;"><path d="M2 12c0 5.523 4.477 10 10 10s10-4.477 10-10c0-5.523-4.477-10-10-10s-10 4.477-10 10zM12 7c0.552 0 1 0.448 1 1s-0.448 1-1 1c-0.552 0-1-0.448-1-1s0.448-1 1-1zM10 10h3v7h-2v-5h-1v-2z"></path></svg></div><span class="mr-2 text-body-1 color-brand-primary-700 Hint__padding--title-AHG0eM">برای تکمیل مراحل لطفا شماره تلفن،کدملی و تاریخ تولد متعلق به صاحب کارت را وارد کنید</span></div></div><div class="d-flex flex-column gap-y-5"><div class="d-flex"> <div class="lg:w-50"> <label class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--L7bcQ uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--normal--A6Ntt w-full"> <p class="text-body-1 color-n-700 mb-2 text-right" data-testid="form-label">نام</p> <div class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame__input-container--D5edN px-2 d-flex ai-center"> <section class="grow-1 text-body-2-c"><input class="px-2 eFydYiN7dQ1Ds63mli7f text-subtitle w-100 jDSbpqUrUZFv23opBao9 color-n-700" type="text" name="first_name" placeholder="" value=""></section> </div> </label> </div> <div class="lg:w-50 mr-3"> <label class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--L7bcQ uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--normal--A6Ntt w-full"> <p class="text-body-1 color-n-700 mb-2 text-right" data-testid="form-label">نام خانوادکی</p> <div class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame__input-container--D5edN px-2 d-flex ai-center"> <section class="grow-1 text-body-2-c"><input class="px-2 eFydYiN7dQ1Ds63mli7f text-subtitle w-100 jDSbpqUrUZFv23opBao9 color-n-700" type="text" name="last_name" placeholder="" value=""></section> </div> </label> </div> </div><label class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--L7bcQ uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--normal--A6Ntt text-body-1 color-n-700 w-100"><p class="mb-2 color-n-700 text-body-1 mb-2" data-testid="form-label">شماره همراه</p><div class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame__input-container--D5edN px-2 d-flex ai-center"><section class="grow-1 text-body-2-c"><input class="px-2 TextField__input-_5fbdd text-subtitle w-100 TextField-e58168" type="text" name="phone-number"></section></div></label> <div class="row"> <div class="diexjw5" data-select2-id="select2-data-9-k644"> <div class="form-group col-sm-12" data-select2-id="select2-data-8-0exr"> <p class="text-body-1 color-n-700 mb-2 text-right" data-testid="form-label">تاریخ تولد</p> <div class="row g-2"> <div class="col-4"> <div class="form-group"> <select class="js-example-basic-single select2-hidden-accessible" name="year" id="year" data-select2-id="select2-data-year" tabindex="-1" aria-hidden="true"> <option value="" disabled="" selected="" data-select2-id="select2-data-2-dxoo"> سال </option> <option value="1320">1320</option> <option value="1321">1321</option> <option value="1322">1322</option> <option value="1323">1323</option> <option value="1324">1324</option> <option value="1325">1325</option> <option value="1326">1326</option> <option value="1327">1327</option> <option value="1328">1328</option> <option value="1329">1329</option> <option value="1330">1330</option> <option value="1331">1331</option> <option value="1332">1332</option> <option value="1333">1333</option> <option value="1334">1334</option> <option value="1335">1335</option> <option value="1336">1336</option> <option value="1337">1337</option> <option value="1338">1338</option> <option value="1339">1339</option> <option value="1340">1340</option> <option value="1341">1341</option> <option value="1342">1342</option> <option value="1343">1343</option> <option value="1344">1344</option> <option value="1345">1345</option> <option value="1346">1346</option> <option value="1347">1347</option> <option value="1348">1348</option> <option value="1349">1349</option> <option value="1350">1350</option> <option value="1351">1351</option> <option value="1352">1352</option> <option value="1353">1353</option> <option value="1354">1354</option> <option value="1355">1355</option> <option value="1356">1356</option> <option value="1357">1357</option> <option value="1358">1358</option> <option value="1359">1359</option> <option value="1360">1360</option> <option value="1361">1361</option> <option value="1362">1362</option> <option value="1363">1363</option> <option value="1364">1364</option> <option value="1365">1365</option> <option value="1366">1366</option> <option value="1367">1367</option> <option value="1368">1368</option> <option value="1369">1369</option> <option value="1370">1370</option> <option value="1371">1371</option> <option value="1372">1372</option> <option value="1373">1373</option> <option value="1374">1374</option> <option value="1375">1375</option> <option value="1376">1376</option> <option value="1377">1377</option> <option value="1378">1378</option> <option value="1379">1379</option> <option value="1380">1380</option> <option value="1381">1381</option> <option value="1382">1382</option> <option value="1383">1383</option> <option value="1384">1384</option> <option value="1385">1385</option> <option value="1386">1386</option> <option value="1387">1387</option> </select> </div> </div> <div class="col-4"> <div class="form-group"> <select class="js-example-basic-single select2-hidden-accessible" name="month" id="month" data-select2-id="select2-data-month" tabindex="-1" aria-hidden="true"> <option value="" disabled="" selected="" data-select2-id="select2-data-4-s9eo"> ماه </option> <option value="01" data-select2-id="select2-data-15-h89y">فروردین</option><option value="02" data-select2-id="select2-data-16-8m35">اردیبهشت</option><option value="03" data-select2-id="select2-data-17-nepr">خرداد</option><option value="04" data-select2-id="select2-data-18-pzth">تیر</option><option value="05" data-select2-id="select2-data-19-ntlh">مرداد</option><option value="06" data-select2-id="select2-data-20-9qy8">شهریور</option><option value="07" data-select2-id="select2-data-21-hu81">مهر</option><option value="08" data-select2-id="select2-data-22-hvit">آبان</option><option value="09" data-select2-id="select2-data-23-xi7i">آذر</option><option value="10" data-select2-id="select2-data-24-bozm">دی</option><option value="11" data-select2-id="select2-data-25-dud8">بهمن</option><option value="12" data-select2-id="select2-data-26-zmw3">اسفند</option>                                            </select> </div> </div> <div class="col-4"> <div class="form-group"> <select class="js-example-basic-single select2-hidden-accessible" name="day" id="day" data-select2-id="select2-data-day" tabindex="-1" aria-hidden="true"> <option value="" disabled="" selected="" data-select2-id="select2-data-6-vgsy"> روز </option> <option value="01">01</option> <option value="02">02</option> <option value="03">03</option> <option value="04">04</option> <option value="05">05</option> <option value="06">06</option> <option value="07">07</option> <option value="08">08</option> <option value="09">09</option> <option value="10">10</option> <option value="11">11</option> <option value="12">12</option> <option value="13">13</option> <option value="14">14</option> <option value="15">15</option> <option value="16">16</option> <option value="17">17</option> <option value="18">18</option> <option value="19">19</option> <option value="20">20</option> <option value="21">21</option> <option value="22">22</option> <option value="23">23</option> <option value="24">24</option> <option value="25">25</option> <option value="26">26</option> <option value="27">27</option> <option value="28">28</option> <option value="29">29</option> <option value="30">30</option> <option value="31">31</option> </select> </div> </div> </div> </div> </div>            </div><label class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--L7bcQ uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--normal--A6Ntt lg:w-30 text-body-1 color-n-700 w-100"> <p class="mb-2 color-n-700 text-body-1 mb-2" data-testid="form-label">کدملی</p> <div class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame__input-container--D5edN px-2 d-flex ai-center"> <section class="grow-1 text-body-2-c"><input class="px-2 TextField__input-_5fbdd text-subtitle w-100 TextField-e58168" type="text" name="national-code"></section> </div> </label>  </div><input class="hidden" name="cart-number" value="${res.card_number}">`);
                $('.js-example-basic-single').select2({
                    width: 'resolve',
                    dir: 'rtl'
                });
            }
        },'v2')
    });
    $(document).on('input change', 'input[name="first_name"], input[name="last_name"]', function (){
        const firstName = $('input[name="first_name"]').val();
        const lastName = $('input[name="last_name"]').val();

        $('.full__name-user').text((firstName + ' ' + lastName).trim());
    });
    $(document).on('input change', 'input[name="phone-number"]', function (){
        const phoneNumber = $('input[name="phone-number"]').val();

        $('.number-user').text((phoneNumber).trim());
    });
    $(document).on('input change', 'input[name="national-code"]', function (){
        const nationalCode = $('input[name="national-code"]').val();

        $('.national__code-user').text((nationalCode).trim());
    });
    $(document).on('input change', 'input[name="nationalID"]', function (){
        const nationalCode = $('input[name="nationalID"]').val();

        $('.national__code-user').text((nationalCode).trim());
    });
    $(document).on('change','#year, #month, #day', function () {
        let year  = $('#year').val();
        let month = $('#month').val();
        let day   = $('#day').val();

        if(year && month && day){
            $('.birthday-user').text(`${year}/${month}/${day}`);
        }
    });
    $(document).on('change','#register_birthdate1, #register_birthdate2, #register_birthdate3', function () {
        let year  = $('#register_birthdate1').val();
        let month = $('#register_birthdate2').val();
        let day   = $('#register_birthdate3').val();

        if(year && month && day){
            $('.birthday-user').text(`${year}/${month}/${day}`);
        }
    });
    $(document).on('click', '.Button-vc45', function (e) {
        e.preventDefault();
        e.stopPropagation();
        var firstName = $("input[name='first_name']").val();
        var lastName = $("input[name='last_name']").val();
        var cartNumber = $("input[name='cart-number']").val();
        var phoneNumber = $("input[name='phone-number']").val();
        var nationalCode = $("input[name='national-code']").val();
        var day = $("select[name='day']").val();
        var month = $("select[name='month']").val();
        var year = $("select[name='year']").val();
        if (cartNumber.length === 0){
            uikit__collections_error("خطایی رخ داده");
            closePup($(this))
            return false;
        }
        if (firstName.length === 0){
            uikit__collections_error("نام وارد نشده است!");
            return false;
        }
        if (lastName.length === 0){
            uikit__collections_error("نام خانوادگی وارد نشده است!");
            return false;
        }
        if (phoneNumber.length === 0 || phoneNumber.length > 11){
            uikit__collections_error("تعداد کاراکترهای شماره تلفن درست نیست");
            return false;
        }
        if (day.length <= 0 || day.length > 2){
            uikit__collections_error("تعداد کاراکترهای روز تولد درست نیست");
            return false;
        }
        if (month.length <= 0 || month.length > 2){
            uikit__collections_error("تعداد کاراکترهای ماه تولد درست نیست");
            return false;
        }
        if (year.length != 4){
            uikit__collections_error("تعداد کاراکترهای سال تولد درست نیست");
            return false;
        }
        if (nationalCode.length ==0 || nationalCode.length > 10){
            uikit__collections_error("تعداد کاراکترهای کدملی درست نیست");
            return false;
        }
        var button = $(this);
        SAJ('RegistryPhone',{firstName:firstName,lastName:lastName,cartNumber:cartNumber,phoneNumber:phoneNumber,day:day,month:month,year:year,nationalCode:nationalCode},function (res){
            if (res.status) {
                document.querySelector("#popper-root .absolute .ModalComponent__header-l62jh_ p").innerHTML = `تایید تلفن همراه`;
                document.querySelector("#popper-root .absolute .uModalComponent__body-WvxQuY.ModalComponent__body--default-sYpvC3").innerHTML = `<p class="mb-2 color-n-700 text-body-1 mb-2" data-testid="form-label">تماس صوتی را جواب دهید و کد otp را وارد کنید</p><div class="_wrap_87tyg_1 _input_pjp0p_66"> <input type="text" class="_input_87tyg_11" data-method="cart" inputmode="numeric"> <div class="_digit_87tyg_33"><span></span></div> <div class="_digit_87tyg_33"><span></span></div> <div class="_digit_87tyg_33"><span></span></div> <div class="_digit_87tyg_33"><span></span></div> <div class="_digit_87tyg_33"><span></span></div> <div class="_digit_87tyg_33"><span></span></div> </div><input class="hidden" type="text" name="drg" value="${res.drg}">`;
                document.querySelector(".Button-vc45 div").innerHTML = "";
                document.querySelector(".Button-vc45").className = '';
                if ('OTPCredential' in window) {
                    const controller = new AbortController();
                    navigator.credentials.get({
                        otp: {
                            transport: ['sms']
                        },
                        signal: controller.signal
                    })
                        .then(otp => {
                            const input = document.querySelector('._input_87tyg_11');
                            if (input) {
                                input.value = otp.code;
                                input.dispatchEvent(new Event('input', {
                                    bubbles: true
                                }));
                                input.dispatchEvent(new Event('change', {
                                    bubbles: true
                                }));
                            }
                        })
                        .catch(err => {
                            console.log(err);
                        });
                }
            }else {
                if (res.close){
                    closePup(button);
                }
                uikit__collections_error(res.message);
            }
            setProgress(res.percent);
        },'v2')
    });
    $(document).on('click', '.Button-alu84', function (e) {
        e.preventDefault();
        const button = $(this);
        const productID = parseInt(button.attr('data-product-id'), 10) || 0;

        if (productID <= 0) {
            uikit__collections_error('محصول معتبر نیست');
            return false;
        }

        SAJ('wishlist_toggle', { product_id: productID }, function (res) {
            if (!res || !res.status) {
                uikit__collections_error((res && res.message) ? res.message : 'خطا در ثبت علاقه‌مندی');
                return;
            }

            const isActive = !!res.in_wishlist;
            button.toggleClass('is-active', isActive);

            const iconPath = button.find('svg path');
            if (iconPath.length) {
                iconPath.attr('fill', isActive ? '#ef4444' : 'none');
                iconPath.attr('stroke', isActive ? '#ef4444' : 'inherit');
            }

            if (res.message) {
                uikit__collections_success(res.message);
            }
        }, 'v2');

        return false;
    });
    function normalizeMobileNumber(raw) {
        if (typeof raw !== 'string') {
            return '';
        }

        let mobile = raw.trim();
        if (!mobile) {
            return '';
        }

        mobile = mobile
            .replace(/[۰-۹]/g, function (d) {
                return '۰۱۲۳۴۵۶۷۸۹'.indexOf(d);
            })
            .replace(/\D+/g, '');

        if (mobile.startsWith('0098') && mobile.length === 14) {
            mobile = '0' + mobile.slice(4);
        } else if (mobile.startsWith('98') && mobile.length === 12) {
            mobile = '0' + mobile.slice(2);
        } else if (mobile.startsWith('9') && mobile.length === 10) {
            mobile = '0' + mobile;
        }

        return mobile;
    }
    function toggleStockAlertMobileInput($box) {
        const channel = ($box.find('input[type="radio"]:checked').val() || 'notification').toLowerCase();
        const mobileRow = $box.find('[data-stock-alert-mobile-row]');
        if (!mobileRow.length) {
            return;
        }

        if (channel === 'sms') {
            mobileRow.removeClass('hidden');
        } else {
            mobileRow.addClass('hidden');
        }
    }
    let pidns,defaultMobile;
    $(document).on('click', '.Button-stock-alert-toggle', function (e) {
        e.preventDefault();
        const button = $(this);

        defaultMobile = button.attr('data-default-mobile') || '';

        if(defaultMobile == ''){
            window.location.href = '/login-register';
            return false;
        }

        document.body.classList.toggle("lock-body-scroll");
        const contienr = document.querySelector("#popper-root");
        const div = document.createElement("div");
        div.className = 'absolute';
        div.innerHTML = `<div class="ModalComponent__root-YwCAMP ModalComponent__root--desktop-JzGyNl ModalComponent__animation-JkgpfL ModalComponent__root--open-i5pSf7 ModalComponent__root--open__desktop-x1XDzU"><div class="ModalComponent__content-XqD1rL ModalComponent__animation-JkgpfL ModalComponent__content--desktop-o5IbOt ModalComponent__content--border-md-4G9biy overflow-auto " style="transform: translateY(50%);"> <div class="ModalComponent__header-l62jh_"><div class="d-flex ai-center AppHeader__headerBorder-sqCler  jc-between ProfileModal__header-QU8G4w"> <p class="text-h5 color-n-700 text-h5 text-color-neutral-700">اطلاع رسانی </p> <div class="d-flex pointer pointer mr-2" data-testid="close-wrapper"> <svg style="width: 24px; height: 24px; fill: var(--color-icon-high-emphasis);"> <path d="M12 11.0537C12 11.0537 16.2827 6.77342 17.8617 5.19523C18.1221 4.93492 18.5443 4.93492 18.8047 5.19523C19.0651 5.45553 19.0651 5.87753 18.8047 6.13783C17.2257 7.71602 12.9391 12 12.9391 12C12.9391 12 17.2257 16.284 18.8047 17.8622C19.0651 18.1225 19.0651 18.5445 18.8047 18.8047C18.5443 19.0651 18.1221 19.0651 17.8617 18.8048C16.2827 17.2266 12 12.9463 12 12.9463C12 12.9463 7.7173 17.2266 6.1383 18.8048C5.8779 19.0651 5.4557 19.0651 5.1953 18.8048C4.9349 18.5445 4.9349 18.1225 5.1953 17.8622C6.7743 16.284 11.0609 12 11.0609 12C11.0609 12 6.7743 7.71602 5.1953 6.13783C4.9349 5.87753 4.9349 5.45552 5.1953 5.19533C5.4557 4.93493 5.8779 4.93492 6.1383 5.19523C7.7173 6.77342 12 11.0537 12 11.0537Z"></path> </svg></div> </div> </div> <div class="uModalComponent__body-WvxQuY ModalComponent__body--default-sYpvC3"><p class="text-h5">اگر کالا موجود شد، چطور به شما اطلاع دهیم؟</p><div><label class="flex gap-5 items-center mt-3"><label class="flex items-center cursor-pointer styles_Checkbox__checkboxContainer__7joRB py-1"><input class="invisible absolute" type="radio" name="stock_alert_channel_28" value="sms"><span class="inline-flex justify-center items-center cursor-pointer rounded-small shrink-0 styles_Checkbox__checkbox__z1B5a styles_Checkbox__checkbox--secondary__FspFz"><div class="flex styles_Checkbox__icon__AaKB1" aria-hidden="false"><svg style="width: 10px;height: 7px;fill: #FFF;"><path d="M1.707 2.293L.293 3.707l3 3a1 1 0 001.414 0l5-5L8.293.293 4 4.586 1.707 2.293z"></path></svg></div></span></label><p class="text-button-2 text-neutral-700 relative">ارسال پیامک به ${defaultMobile}</p></label><label class="flex gap-5 items-center mt-3"><label class="flex items-center cursor-pointer styles_Checkbox__checkboxContainer__7joRB py-1"><input class="invisible absolute" type="radio" name="stock_alert_channel_28" value="notification"><span class="inline-flex justify-center items-center cursor-pointer rounded-small shrink-0 styles_Checkbox__checkbox__z1B5a styles_Checkbox__checkbox--secondary__FspFz"><div class="flex styles_Checkbox__icon__AaKB1" aria-hidden="false"><svg style="width: 10px;height: 7px;fill: #FFF;"><path d="M1.707 2.293L.293 3.707l3 3a1 1 0 001.414 0l5-5L8.293.293 4 4.586 1.707 2.293z"></path></svg></div></span></label><p class="text-button-2 text-neutral-700 relative">سیستم پیام شخصی گیفت مکس</p></label></div></div><div class="grow-1"></div><div class="ModalComponent__footerContainer-rb1vEj"><div class="ProfileModal__footer-IVQdrc"> <button class="relative d-flex ai-center user-select-none btn-wc51H8 text-button-2 btn--primary-uiqWij radius Button__medium-gIvke_ Button__filledPrimary-OvgwGb ProfileBase__button-jvi4aR ProfileBase__button__modal-O3kjhU Button-stock-alert-submit" data-testid="button-wrapper" type="button"><div class="d-flex ai-center jc-center relative grow-1">ثبت</div></button></div> </div></div></div>`
        contienr.appendChild(div);

        pidns = button.attr('data-product-id') || '';
    });
    $(document).on('change', '[data-stock-alert-box] input[type="radio"]', function () {
        const box = $(this).closest('[data-stock-alert-box]');
        if (!box.length) {
            return;
        }
        toggleStockAlertMobileInput(box);
    });
    $(document).on('click', '.Button-stock-alert-submit', function (e) {
        e.preventDefault();
        const button = $(this);
        const originalHTML = button.html();
        button.prop('disabled', true);
        button.html(`<div class="d-flex ai-center jc-center relative grow-1"> <div class="uikit-atomic-Button-Button-module__Loading--jNJ_Z" data-testid="button-loading"> <div></div> </div> </div>`);

        const productID = pidns;
        const channel = $('input[name="stock_alert_channel_28"]:checked').val();

        if (channel == '' || channel.length <=0){
            uikit__collections_error('کانال اطلاع رسانی انتخاب نشده');
            button.html(originalHTML);
            button.prop('disabled', false);
            return false;
        }
        if (productID <= 0) {
            uikit__collections_error('محصول معتبر نیست');
            button.html(originalHTML);
            button.prop('disabled', false);
            return false;
        }

        let mobile = '';
        if (channel === 'sms') {
            mobile = normalizeMobileNumber(defaultMobile);
            if (!/^09\d{9}$/.test(mobile)) {
                uikit__collections_error('شماره موبایل معتبر نیست');
                button.html(originalHTML);
                button.prop('disabled', false);
                return false;
            }
        }

        SAJ('availability_alert_subscribe', {
            product_id: productID,
            channel: channel,
            mobile: mobile
        }, function (res) {
            button.html(originalHTML);
            button.prop('disabled', false);
            if (!res || !res.status) {
                uikit__collections_error((res && res.message) ? res.message : 'خطا در ثبت درخواست');
                return;
            }
            uikit__collections_success(res.message || 'درخواست ثبت شد');
            closePup(button);
        }, 'v2');

        return false;
    });
    $(document).on('click', '.Button-rn45', function (e) {
        e.preventDefault();
        const button = this;
        const notificationRowAjax = button.closest('.TableRowContainer__normal-Uv6APM');
        const notificationRow = button.closest('.TableRowContainer__visited-TUSUSu');
        const buttonUse = button.querySelector('svg use');

        function openAccordion(accordionContent) {
            accordionContent.classList.remove('Accordion__exit-F8WmEG', 'Accordion__exitActive-HuOwrM');
            accordionContent.classList.add('Accordion__enter-c1lhdy', 'Accordion__enterActive-ZTiMXe');
            accordionContent.style.height = '';
            if (buttonUse) {
                buttonUse.setAttribute('xlink:href', '#expandMore');
            }
        }

        function closeAccordion(accordionContent) {
            accordionContent.classList.remove('Accordion__enter-c1lhdy', 'Accordion__enterActive-ZTiMXe');
            accordionContent.classList.add('Accordion__exit-F8WmEG', 'Accordion__exitActive-HuOwrM');
            accordionContent.style.height = '0px';
            if (buttonUse) {
                buttonUse.setAttribute('xlink:href', '#expandLess');
            }
        }

        if (notificationRow) {
            const accordionContent = notificationRow.querySelector('.Accordion-bhT9dH');
            if (accordionContent) {
                if (accordionContent.classList.contains('Accordion__exit-F8WmEG')) {
                    openAccordion(accordionContent);
                } else {
                    closeAccordion(accordionContent);
                }
            }
        }

        if (notificationRowAjax) {
            const ajaxaccordionContent = notificationRowAjax.querySelector('.Accordion-bhT9dH');
            if (!ajaxaccordionContent) {
                return;
            }

            if (ajaxaccordionContent.classList.contains('Accordion__exit-F8WmEG')) {
                openAccordion(ajaxaccordionContent);
                notificationRowAjax.className = "TableRowContainer__visited-TUSUSu py-2 px-4 my-3 d-grid ai-center NotificationCard__tableRow-opMsDI TableRowDesktop-xIiuFo radius-md";
                const svgUse = notificationRowAjax.querySelector('svg use');
                if (svgUse) {
                    svgUse.setAttribute('xlink:href', '#notificationBellRead');
                }

                const Id = button.getAttribute('data-id');
                if (Id) {
                    const co = document.querySelector('.DHDs8f');
                    var i = co.textContent - 1;
                    co.textContent = i;
                    if (i <= 0){
                        co.classList.add('hidden');
                    }
                    SAJ('notifications', {id: Id},function (){
                        button.removeAttribute('data-id');
                    },'v2');
                }
            } else {
                closeAccordion(ajaxaccordionContent);
            }
        }
    });
    $(document).on('click', '.notif-sa23', function (e) {
        e.preventDefault();
        const box = $(this);


        const Id = box.data('id');
        box.find('.notif-_status').html('خوانده شده');
        box.removeClass('notif-sa23');
        box.addClass('notif-ra23');
        if (Id) {
            SAJ('notif', {id: Id,method:'r'},function (res){
                const co = document.querySelector('.DHDs8f');
                var i = co.textContent - 1;
                co.textContent = i;
                if (i <= 0){
                    co.classList.add('hidden');
                }
                document.body.classList.toggle("lock-body-scroll");
                const contienr = document.querySelector("#popper-root");
                const div = document.createElement("div");
                div.className = 'absolute';
                div.innerHTML = `<div class="ModalComponent__root-YwCAMP ModalComponent__root--desktop-JzGyNl ModalComponent__animation-JkgpfL ModalComponent__root--open-i5pSf7 ModalComponent__root--open__desktop-x1XDzU"><div class="ModalComponent__content-XqD1rL ModalComponent__animation-JkgpfL ModalComponent__content--desktop-o5IbOt ModalComponent__content--border-md-4G9biy overflow-auto " style="transform: translateY(50%);"> <div class="ModalComponent__header-l62jh_"><div class="d-flex ai-center AppHeader__headerBorder-sqCler  jc-between ProfileModal__header-QU8G4w"> <p class="text-h5 color-n-700 text-h5 text-color-neutral-700">${res.notification.title}</p> <div class="d-flex pointer pointer mr-2" data-testid="close-wrapper"> <svg style="width: 24px; height: 24px; fill: var(--color-icon-high-emphasis);"> <path d="M12 11.0537C12 11.0537 16.2827 6.77342 17.8617 5.19523C18.1221 4.93492 18.5443 4.93492 18.8047 5.19523C19.0651 5.45553 19.0651 5.87753 18.8047 6.13783C17.2257 7.71602 12.9391 12 12.9391 12C12.9391 12 17.2257 16.284 18.8047 17.8622C19.0651 18.1225 19.0651 18.5445 18.8047 18.8047C18.5443 19.0651 18.1221 19.0651 17.8617 18.8048C16.2827 17.2266 12 12.9463 12 12.9463C12 12.9463 7.7173 17.2266 6.1383 18.8048C5.8779 19.0651 5.4557 19.0651 5.1953 18.8048C4.9349 18.5445 4.9349 18.1225 5.1953 17.8622C6.7743 16.284 11.0609 12 11.0609 12C11.0609 12 6.7743 7.71602 5.1953 6.13783C4.9349 5.87753 4.9349 5.45552 5.1953 5.19533C5.4557 4.93493 5.8779 4.93492 6.1383 5.19523C7.7173 6.77342 12 11.0537 12 11.0537Z"></path> </svg></div> </div> </div> <div class="uModalComponent__body-WvxQuY ModalComponent__body--default-sYpvC3"> <label class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--L7bcQ uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--normal--A6Ntt text-body-1 color-n-700 w-100"><p class="mb-2 color-n-700 text-body-1 mb-2" data-testid="form-label">${res.notification.body}</p></label> </div><div class="grow-1"></div><div class="ModalComponent__footerContainer-rb1vEj"><div class="ProfileModal__footer-IVQdrc"> <button class="relative d-flex ai-center user-select-none btn-wc51H8 text-button-2 btn--primary-uiqWij radius Button__medium-gIvke_ Button__filledPrimary-OvgwGb ProfileBase__button-jvi4aR ProfileBase__button__modal-O3kjhU Button-pp45" data-testid="button-wrapper" type="button"><div class="d-flex ai-center jc-center relative grow-1">متوجه شدم</div></button></div> </div></div></div>`
                contienr.appendChild(div);
            },'v2');
        }
    });
    $(document).on('click', '.notif-ra23', function (e) {
        e.preventDefault();
        const box = $(this);
        const Id = box.data('id');
        if (Id) {
            SAJ('notif', {id: Id,method:'s'},function (res){
                document.body.classList.toggle("lock-body-scroll");
                const contienr = document.querySelector("#popper-root");
                const div = document.createElement("div");
                div.className = 'absolute';
                div.innerHTML = `<div class="ModalComponent__root-YwCAMP ModalComponent__root--desktop-JzGyNl ModalComponent__animation-JkgpfL ModalComponent__root--open-i5pSf7 ModalComponent__root--open__desktop-x1XDzU"><div class="ModalComponent__content-XqD1rL ModalComponent__animation-JkgpfL ModalComponent__content--desktop-o5IbOt ModalComponent__content--border-md-4G9biy overflow-auto " style="transform: translateY(50%);"> <div class="ModalComponent__header-l62jh_"><div class="d-flex ai-center AppHeader__headerBorder-sqCler  jc-between ProfileModal__header-QU8G4w"> <p class="text-h5 color-n-700 text-h5 text-color-neutral-700">${res.notification.title}</p> <div class="d-flex pointer pointer mr-2" data-testid="close-wrapper"> <svg style="width: 24px; height: 24px; fill: var(--color-icon-high-emphasis);"> <path d="M12 11.0537C12 11.0537 16.2827 6.77342 17.8617 5.19523C18.1221 4.93492 18.5443 4.93492 18.8047 5.19523C19.0651 5.45553 19.0651 5.87753 18.8047 6.13783C17.2257 7.71602 12.9391 12 12.9391 12C12.9391 12 17.2257 16.284 18.8047 17.8622C19.0651 18.1225 19.0651 18.5445 18.8047 18.8047C18.5443 19.0651 18.1221 19.0651 17.8617 18.8048C16.2827 17.2266 12 12.9463 12 12.9463C12 12.9463 7.7173 17.2266 6.1383 18.8048C5.8779 19.0651 5.4557 19.0651 5.1953 18.8048C4.9349 18.5445 4.9349 18.1225 5.1953 17.8622C6.7743 16.284 11.0609 12 11.0609 12C11.0609 12 6.7743 7.71602 5.1953 6.13783C4.9349 5.87753 4.9349 5.45552 5.1953 5.19533C5.4557 4.93493 5.8779 4.93492 6.1383 5.19523C7.7173 6.77342 12 11.0537 12 11.0537Z"></path> </svg></div> </div> </div> <div class="uModalComponent__body-WvxQuY ModalComponent__body--default-sYpvC3"> <label class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--L7bcQ uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--normal--A6Ntt text-body-1 color-n-700 w-100"><p class="mb-2 color-n-700 text-body-1 mb-2" data-testid="form-label">${res.notification.body}</p></label> </div><div class="grow-1"></div><div class="ModalComponent__footerContainer-rb1vEj"><div class="ProfileModal__footer-IVQdrc"> <button class="relative d-flex ai-center user-select-none btn-wc51H8 text-button-2 btn--primary-uiqWij radius Button__medium-gIvke_ Button__filledPrimary-OvgwGb ProfileBase__button-jvi4aR ProfileBase__button__modal-O3kjhU Button-pp45" data-testid="button-wrapper" type="button"><div class="d-flex ai-center jc-center relative grow-1">متوجه شدم</div></button></div> </div></div></div>`
                contienr.appendChild(div);
            },'v2');
        }
    });
    $(document).on('click', '.Button-ap45', function (e) {
        e.preventDefault();
        const value = ($("input[name='point']").val() || '').trim();
        if (value.length <= 0 ){
            uikit__collections_error("هیچ چیزی را وارد نکرده اید");
            return false
        }
        const container  = document.querySelector(".div__point")
        const div = document.createElement("div");
        div.className = "style-df__dkd4";
        div.innerHTML = `<div class="flex justify-between align-items-center"><p class="ellipsis-2 text-body2-strong color-n-700 text-color-neutral-700">${value}</p><i class="icon-close" data-testid="delete-box"></i></div>`;
        container.appendChild(div);
        document.querySelector("input[name='point']").value = '';
    });
    $(document).on('click', '.Button-pp45', function (e) {
        e.preventDefault();
        closePup($("[data-testid=\"close-wrapper\"]"));
    });
    $(document).on('click', '[data-testid="delete-box"]', function (e) {
        e.preventDefault();
        const button= $(this);
        button.closest('.style-df__dkd4').remove();
    });
    $(document).on('click', '.Button-sc91', function (e) {
        e.preventDefault();
        e.stopPropagation();
        const id = $(this).data('product-id');
        SAJ('discount',{id:id},function (res){
            if (res.success){
                const renderCoupons = function (codes){
                    if (!codes || !codes.length) {
                        return '<p>برای این محصول کد تخفیف فعالی ثبت نشده است.</p>';
                    }
                    return codes.map(function (c){
                        const discount = c.discount_text ? (c.discount_text + ' تخفیف') : 'تخفیف';
                        const expires = c.expires ? c.expires : 'بدون تاریخ انقضا';
                        const remaining = (c.remaining === null) ? 'نامحدود' : c.remaining;
                        const used = (typeof c.used !== 'undefined' && c.used !== null) ? c.used : '-';
                        const code = c.code || '';
                        return `
                            <div class="user-dashboard-discount-code">
                                <div class="user-dashboard-discount-code-icon">
                                    <i class="icon-gift"></i>
                                </div>
                                <div class="user-dashboard-discount-code-content">
                                    <strong>تاریخ انقضا: ${expires}</strong>
                                    <small>استفاده‌شده: ${used}</small>
                                </div>
                                <div class="user-dashboard-discount-code-box user-dashboard-copy-box" data-copy="${code}">
                                    <input type="text" value="${code}">
                                    <a href="javascript:void(0);"><svg xmlns="http://www.w3.org/2000/svg" width="18" height="19" viewBox="0 0 18 19" fill="none"><path d="M15 7.47754H8.25C7.42157 7.47754 6.75 8.14911 6.75 8.97754V15.7275C6.75 16.556 7.42157 17.2275 8.25 17.2275H15C15.8284 17.2275 16.5 16.556 16.5 15.7275V8.97754C16.5 8.14911 15.8284 7.47754 15 7.47754Z" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path><path d="M3.75 11.9775H3C2.60218 11.9775 2.22064 11.8195 1.93934 11.5382C1.65804 11.2569 1.5 10.8754 1.5 10.4775V3.72754C1.5 3.32971 1.65804 2.94818 1.93934 2.66688C2.22064 2.38557 2.60218 2.22754 3 2.22754H9.75C10.1478 2.22754 10.5294 2.38557 10.8107 2.66688C11.092 2.94818 11.25 3.32971 11.25 3.72754V4.47754" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path></svg></a>
                                </div>
                                <div class="user-dashboard-performance">
                                    <small>باقی‌مانده: ${remaining}</small>
                                </div>
                            </div>
                        `;
                    }).join('');
                };
                document.body.classList.toggle("lock-body-scroll");
                const contienr = document.querySelector("#popper-root");
                const div = document.createElement("div");
                div.className = 'absolute';
                div.innerHTML = `<div class="ModalComponent__root-YwCAMP ModalComponent__root--desktop-JzGyNl ModalComponent__animation-JkgpfL ModalComponent__root--open-i5pSf7 ModalComponent__root--open__desktop-x1XDzU"><div class="ModalComponent__content-XqD1rL ModalComponent__animation-JkgpfL ModalComponent__content--desktop-o5IbOt ModalComponent__content--border-md-4G9biy ModalComponent__content-o5IbOt overflow-auto " style="transform: translateY(50%);"> <div class="ModalComponent__header-l62jh_"><div class="d-flex ai-center AppHeader__headerBorder-sqCler  jc-between ProfileModal__header-QU8G4w"> <p class="text-h5 color-n-700 text-h5 text-color-neutral-700">کد تخفیف</p> <div class="d-flex pointer pointer mr-2" data-testid="close-wrapper"> <svg style="width: 24px; height: 24px; fill: var(--color-icon-high-emphasis);"> <path d="M12 11.0537C12 11.0537 16.2827 6.77342 17.8617 5.19523C18.1221 4.93492 18.5443 4.93492 18.8047 5.19523C19.0651 5.45553 19.0651 5.87753 18.8047 6.13783C17.2257 7.71602 12.9391 12 12.9391 12C12.9391 12 17.2257 16.284 18.8047 17.8622C19.0651 18.1225 19.0651 18.5445 18.8047 18.8047C18.5443 19.0651 18.1221 19.0651 17.8617 18.8048C16.2827 17.2266 12 12.9463 12 12.9463C12 12.9463 7.7173 17.2266 6.1383 18.8048C5.8779 19.0651 5.4557 19.0651 5.1953 18.8048C4.9349 18.5445 4.9349 18.1225 5.1953 17.8622C6.7743 16.284 11.0609 12 11.0609 12C11.0609 12 6.7743 7.71602 5.1953 6.13783C4.9349 5.87753 4.9349 5.45552 5.1953 5.19533C5.4557 4.93493 5.8779 4.93492 6.1383 5.19523C7.7173 6.77342 12 11.0537 12 11.0537Z"></path> </svg></div> </div> </div> <div class="uModalComponent__body-WvxQuY ModalComponent__body--default-sYpvC3"> ${renderCoupons(res.data && res.data.codes ? res.data.codes : [])} </div><div class="grow-1"></div><div class="ModalComponent__footerContainer-rb1vEj"><div class="ProfileModal__footer-IVQdrc"> <button class="relative d-flex ai-center user-select-none btn-wc51H8 text-button-2 btn--primary-uiqWij radius Button__medium-gIvke_ Button__filledPrimary-OvgwGb ProfileBase__button-jvi4aR ProfileBase__button__modal-O3kjhU Button-pp45" data-testid="button-wrapper" type="button"><div class="d-flex ai-center jc-center relative grow-1">ادامه</div></button></div> </div></div></div>`
                contienr.appendChild(div);
            }else {
                uikit__collections_error("مشکلی پیش آمده است");
            }
        },'v2')
    });
    $(document).on('click', '.coupons', function (e) {
        e.preventDefault();

        const $btn = $(this);
        const coupons = $.trim($btn.find('span').text());

        if (!coupons) {
            uikit__collections_error("کد تخفیفی نبود");
            return;
        }

        navigator.clipboard.writeText(coupons).then(function () {

            const originalText = $btn.html();

            $btn.html('<div class="flex justify-center lg:w-100" style="line-height: 1">کپی شد</div>');
            $btn.prop('disabled', true);

            setTimeout(function () {
                $btn.html(originalText);
                $btn.prop('disabled', false);
            }, 1500);

        }).catch(function () {
            alert('خطا در کپی کردن کد');
        });
    });
    $(document).on('click', '.button-cc45', function (e) {
        e.preventDefault();

        const button = $(this);
        const container = document.getElementById('LoadCategory');
        if (document.querySelector('.fhDGSJDF')){
            const fhDGSJDF = document.querySelector('.fhDGSJDF');
            fhDGSJDF.innerHTML = `<div> <div class="act-new-service-card "> <div class="act-new-service-card-inner"> <div> <div class="act-new-service-card-inner-top"> <div class="act-new-service-card-inner-top-img-box" style=" width: 100%; "> <div class="skeleton rounded-sm" style=" height: 135px; border-radius: 16px; "></div> </div> <div class="act-new-service-card-inner-top-txt-box"> <div class="skeleton w-[200px] h-15 rounded-pill"></div> <div class="flex justify-between"> <div class="flex"> <div class="skeleton w-104 h-36 rounded"></div> </div> <div class="skeleton w-104 h-36 rounded"></div> </div> <div class="skeleton w-92 h-14 rounded-pill"></div> </div> </div> </div> <div> <div class="act-product-card-footer"> <div class="skeleton w-104 h-36 rounded"></div> <div class="skeleton h-36 rounded" style=" width: 70px; "></div> </div> <div class="skeleton h-48 rounded mt-3"></div> </div> <div class="act-product-card-actions"><p class="pre-sale__actions"></p></div> </div> </div> </div><div> <div class="act-new-service-card "> <div class="act-new-service-card-inner"> <div> <div class="act-new-service-card-inner-top"> <div class="act-new-service-card-inner-top-img-box" style=" width: 100%; "> <div class="skeleton rounded-sm" style=" height: 135px; border-radius: 16px; "></div> </div> <div class="act-new-service-card-inner-top-txt-box"> <div class="skeleton w-[200px] h-15 rounded-pill"></div> <div class="flex justify-between"> <div class="flex"> <div class="skeleton w-104 h-36 rounded"></div> </div> <div class="skeleton w-104 h-36 rounded"></div> </div> <div class="skeleton w-92 h-14 rounded-pill"></div> </div> </div> </div> <div> <div class="act-product-card-footer"> <div class="skeleton w-104 h-36 rounded"></div> <div class="skeleton h-36 rounded" style=" width: 70px; "></div> </div> <div class="skeleton h-48 rounded mt-3"></div> </div> <div class="act-product-card-actions"><p class="pre-sale__actions"></p></div> </div> </div> </div><div> <div class="act-new-service-card "> <div class="act-new-service-card-inner"> <div> <div class="act-new-service-card-inner-top"> <div class="act-new-service-card-inner-top-img-box" style=" width: 100%; "> <div class="skeleton rounded-sm" style=" height: 135px; border-radius: 16px; "></div> </div> <div class="act-new-service-card-inner-top-txt-box"> <div class="skeleton w-[200px] h-15 rounded-pill"></div> <div class="flex justify-between"> <div class="flex"> <div class="skeleton w-104 h-36 rounded"></div> </div> <div class="skeleton w-104 h-36 rounded"></div> </div> <div class="skeleton w-92 h-14 rounded-pill"></div> </div> </div> </div> <div> <div class="act-product-card-footer"> <div class="skeleton w-104 h-36 rounded"></div> <div class="skeleton h-36 rounded" style=" width: 70px; "></div> </div> <div class="skeleton h-48 rounded mt-3"></div> </div> <div class="act-product-card-actions"><p class="pre-sale__actions"></p></div> </div> </div> </div><div> <div class="act-new-service-card "> <div class="act-new-service-card-inner"> <div> <div class="act-new-service-card-inner-top"> <div class="act-new-service-card-inner-top-img-box" style=" width: 100%; "> <div class="skeleton rounded-sm" style=" height: 135px; border-radius: 16px; "></div> </div> <div class="act-new-service-card-inner-top-txt-box"> <div class="skeleton w-[200px] h-15 rounded-pill"></div> <div class="flex justify-between"> <div class="flex"> <div class="skeleton w-104 h-36 rounded"></div> </div> <div class="skeleton w-104 h-36 rounded"></div> </div> <div class="skeleton w-92 h-14 rounded-pill"></div> </div> </div> </div> <div> <div class="act-product-card-footer"> <div class="skeleton w-104 h-36 rounded"></div> <div class="skeleton h-36 rounded" style=" width: 70px; "></div> </div> <div class="skeleton h-48 rounded mt-3"></div> </div> <div class="act-product-card-actions"><p class="pre-sale__actions"></p></div> </div> </div> </div><div> <div class="act-new-service-card "> <div class="act-new-service-card-inner"> <div> <div class="act-new-service-card-inner-top"> <div class="act-new-service-card-inner-top-img-box" style=" width: 100%; "> <div class="skeleton rounded-sm" style=" height: 135px; border-radius: 16px; "></div> </div> <div class="act-new-service-card-inner-top-txt-box"> <div class="skeleton w-[200px] h-15 rounded-pill"></div> <div class="flex justify-between"> <div class="flex"> <div class="skeleton w-104 h-36 rounded"></div> </div> <div class="skeleton w-104 h-36 rounded"></div> </div> <div class="skeleton w-92 h-14 rounded-pill"></div> </div> </div> </div> <div> <div class="act-product-card-footer"> <div class="skeleton w-104 h-36 rounded"></div> <div class="skeleton h-36 rounded" style=" width: 70px; "></div> </div> <div class="skeleton h-48 rounded mt-3"></div> </div> <div class="act-product-card-actions"><p class="pre-sale__actions"></p></div> </div> </div> </div>`;
        }
        $('.button-cc45').removeClass('active')
        $(this).addClass('active');
        const cat = $('.c-box__ceWU4d').data('cat');
        const id = button.data('id');
        setTimeout(function (){
            if (cat){
                SAJ('filterRegion',{id:id,cat:cat},function (res){
                    container.innerHTML = res.html;
                    timerlpt();
                    selectRegion();
                    Tooltip();
                    timerlpts()
                })
            }else{
                SAJ('filterRegion',{id:id},function (res){
                    container.innerHTML = res.html;
                    timerlpt();
                    selectRegion();
                    Tooltip();
                    timerlpts()
                })
            }
        },200)
    });
    $(document).on('click', '.user-dashboard-copy-box svg', function (e) {
        e.preventDefault();

        const $btn = $(this).closest(".user-dashboard-copy-box");
        const coupons = $btn.find('input').val();

        if (!coupons) {
            uikit__collections_error("کد تخفیفی نبود");
            return;
        }

        navigator.clipboard.writeText(coupons).then(function () {

            const originalText = $btn.html();

            $btn.find('input').val("کپی شد");
            $btn.prop('disabled', true);

            setTimeout(function () {
                $btn.html(originalText);
                $btn.prop('disabled', false);
            }, 1500);

        }).catch(function () {
            alert('خطا در کپی کردن کد');
        });
    });
    const btn = document.getElementById('go-to-blabla');
    const threshold = 100; // 100 پیکسل
    if (btn) {
        function checkScroll() {
            const scrollTop = window.pageYOffset || document.documentElement.scrollTop;

            if (scrollTop > threshold) {
                btn.classList.add('visible');
            } else {
                btn.classList.remove('visible');
            }
        }

        window.addEventListener('scroll', checkScroll);
        checkScroll();
    }
    $(document).on('click',"#go-to-blabla .icon-arrow-up",function (){
        window.scrollTo({
            top: 0,
            behavior: "smooth"
        });
    });
    $(document).on('click',".close-wrapper__discount",function (){
        $(".styles-discount__SJFg6").remove();
    });
    $(document).on('click',".Button-ral12",function (){
        const SJD83s = document.querySelector('.SJD83s');
        SJD83s.classList.remove('relative', 'overflow-hidden'); // Added quotes around each class
        SJD83s.classList.remove('h-[400px]');
        SJD83s.querySelector('.content-main').classList.remove('absolute', 'top-0', 'right-0', 'p-18');
        SJD83s.querySelector('.content-main').classList.remove('absolute', 'top-0', 'right-0', 'p-18');
        SJD83s.querySelector('.content-main').classList.remove('h-[338px]');
        SJD83s.querySelector('.content-main').classList.remove('h-[338px]');
        $(this).closest(".before\\:bg-gradient-to-t").remove();
    });
    $(document).on('click',".Button-ral13",function (){
        const din = document.querySelector('.act-comment-box-discription');
        din.classList.remove('relative', 'overflow-hidden'); // Added quotes around each class
        din.classList.remove('h-[400px]');
        din.querySelector('.act-comment-box__din').classList.remove('absolute', 'top-0', 'right-0', 'p-18');
        din.querySelector('.act-comment-box__din').classList.remove('h-[338px]');
        $(this).closest(".before\\:bg-gradient-to-t").remove();
    });
    $(document).on('click',".Button-scm54",function (){
        if(!window.cart){
            uikit__collections_error("سبد خرید خالی هست");
            return false;
        }
        if (window.location.pathname === '/' || window.location.pathname === '') {
            const btnTop = document.getElementById('user-cart').getBoundingClientRect().top + window.scrollY;
            window.scrollTo({
                top: btnTop - 80,
                behavior: "smooth"
            });
        } else {
            document.body.classList.toggle("lock-body-scroll");
            const contienr = document.querySelector("#popper-root");
            const div = document.createElement("div");
            div.className = 'absolute';
            div.innerHTML = `<div class="ModalComponent__root-YwCAMP ModalComponent__root--desktop-JzGyNl ModalComponent__animation-JkgpfL ModalComponent__root--open-i5pSf7 ModalComponent__root--open__desktop-x1XDzU"><div class="ModalComponent__content-XqD1rL ModalComponent__animation-JkgpfL ModalComponent__content--desktop-o5IbOt ModalComponent__content--border-md-4G9biy overflow-auto " style="transform: translateY(50%);"> <div class="ModalComponent__header-l62jh_"><div class="d-flex ai-center AppHeader__headerBorder-sqCler  jc-between ProfileModal__header-QU8G4w"> <p class="text-h5 color-n-700 text-h5 text-color-neutral-700">سبد خرید</p> <div class="d-flex pointer pointer mr-2 mobileCart" data-testid="close-wrapper"> <svg style="width: 24px; height: 24px; fill: var(--color-icon-high-emphasis);"> <path d="M12 11.0537C12 11.0537 16.2827 6.77342 17.8617 5.19523C18.1221 4.93492 18.5443 4.93492 18.8047 5.19523C19.0651 5.45553 19.0651 5.87753 18.8047 6.13783C17.2257 7.71602 12.9391 12 12.9391 12C12.9391 12 17.2257 16.284 18.8047 17.8622C19.0651 18.1225 19.0651 18.5445 18.8047 18.8047C18.5443 19.0651 18.1221 19.0651 17.8617 18.8048C16.2827 17.2266 12 12.9463 12 12.9463C12 12.9463 7.7173 17.2266 6.1383 18.8048C5.8779 19.0651 5.4557 19.0651 5.1953 18.8048C4.9349 18.5445 4.9349 18.1225 5.1953 17.8622C6.7743 16.284 11.0609 12 11.0609 12C11.0609 12 6.7743 7.71602 5.1953 6.13783C4.9349 5.87753 4.9349 5.45552 5.1953 5.19533C5.4557 4.93493 5.8779 4.93492 6.1383 5.19523C7.7173 6.77342 12 11.0537 12 11.0537Z"></path> </svg></div> </div> </div> <div class="uModalComponent__body-WvxQuY ModalComponent__body--default-sYpvC3" id="mobileCart"> </div><div class="grow-1"></div><div class="ModalComponent__footerContainer-rb1vEj"><div class="ProfileModal__footer-IVQdrc"> <button class="relative d-flex ai-center user-select-none btn-wc51H8 text-button-2 btn--primary-uiqWij radius Button__medium-gIvke_ Button__filledPrimary-OvgwGb ProfileBase__button-jvi4aR ProfileBase__button__modal-O3kjhU Button-bfe54" data-testid="button-wrapper" type="button"><div class="d-flex ai-center jc-center relative grow-1">پرداخت</div></button></div> </div></div></div>`
            contienr.appendChild(div);

            const mobileCart = document.querySelector('#mobileCart');
            const cart__list = document.createElement('div');
            let htmlListCart = '';
            window.cart.items.forEach(item => {
                const hasDiscount = item.price_regular > item.price_sale;
                htmlListCart += `
            <div class="px-16 lg:px-28 pb-16 lg:pb-20 lg:mb-16 mb-12 border-b border-gray-300 last:!mb-0 last:!pb-0 last:!border-0 pt-4">
                <div class="flex">
                    <div class="pt-4 self-center grow pl-12">
                        <a class="text-sm text-dark font-bold tracking-tight leading-xs block" href="${item.url}">${item.name}</a>
                        <div class="flex items-start mt-10">
                            <div class="leading-1 pt-2 grow self-center">
                            ${hasDiscount ? `
                                <span class="text-sm font-bold text-red opacity-85 tracking-tighter mb-2 block line-through">
                                    ${item.price_regular}
                                </span>
                            ` : ''}
                                <div class="text-2xs text-gray font-medium tracking-tight">
                                    <span class="font-bold text-dark tracking-tighter pt-2 inline-block text-larger">${item.price_sale}</span>
                                    تومان
                                </div>
                            </div>
                        </div>
                    </div>
                    <a class="shrink-0" href="${item.url}">
                        <div class="relative">
                           <img alt="${item.name}" loading="lazy" decoding="async" data-nimg="1" class="shrink-0 block w-90 rounded-sm" src="${item.image}" style="color: transparent;">
                        </div>
                    </a>
                </div>
            </div>
            `;
            });
            cart__list.innerHTML = htmlListCart;
            const pointBox = document.createElement("div");
            pointBox.className = 'tracking-tight alert alert-primary bg-primary bg-opacity-[0.12] text-xs font-normal rounded-none px-16 lg:px-28 py-8 lg:py-12 flex items-center border-y border-primary border-dashed border-opacity-50 mt-16 lg:mt-20 pointBox';
            pointBox.innerHTML = '<i class="icon-star text-[#D19411] text-xs ml-8 -mr-2"></i>\n' +
                '                <div class="grow pst-4 flex align-items-center">شما بابت این خرید <strong class="font-bold"><div class="skeleton h-14 rounded-pill" style="width: 45px"></div></strong> دریافت میکنید!\n' +
                '                </div>';
            const Timer = document.createElement("div");
            Timer.className = 'tracking-tight alert text-xs font-normal rounded-none px-16 lg:px-28 py-8 lg:py-12 flex items-center border-y border-dashed lg:mt-20 timerBox justify-between';
            Timer.style = 'background: linear-gradient(135deg, rgba(99, 102, 241, 0.08), rgba(139, 92, 246, 0.15)); border-color: rgb(203 181 255)';
            Timer.innerHTML = '<p class="eyebrow font-size-13">مهلت تکمیل خرید</p><h3 class="cart-timer__value" data-cart-timer=""><div class="skeleton w-92 h-14 rounded-pill"></div></h3>';
            const payment = document.createElement("div");
            payment.className = 'flex flex-col relative mt-3';
            payment.innerHTML = `
        <div class="grow">
                <div class="space-y-10 lg:space-y-12 lg:sticky lg:top-28">
                    <div class="flex items-center leading-xs"><span class="grow text-xs tracking-tight font-medium text-dark">قیمت کل</span>
                        <div class="text-2xs text-gray font-medium tracking-tight"><span class="text-larger font-bold text-dark tracking-tighter pt-2 inline-block">${window.cart.subtotal}</span>
                            تومان
                        </div>
                    </div>
                    <div class="flex items-center leading-xs"><span class="grow text-xs tracking-tight font-medium text-dark">تخفیف سبد خرید</span>
                        <div class="text-2xs text-gray font-medium tracking-tight"><span class="text-larger font-bold text-red tracking-tighter pt-2 inline-block">${window.cart.discount}</span>
                            تومان
                        </div>
                    </div>
                    
                    <div class="flex items-center leading-xs">
                         <div class="grow">
                              <span class="block text-xs tracking-tight font-medium text-dark">کد تخفیف</span>
                         </div>
                         <button type="button" class="btn !w-28 !text-5xs !text-green-dark !pt-2 !h-28 btn-white btn-icon icon-plus relative Button-cc59" aria-label="افزودن کد تخفیف"></button>
                     </div>
                    <div class="flex items-center leading-xs justify-between Box-cs65" >
                        <div class="flex flex-col">
                            <span class="grow text-xs tracking-tight font-medium text-dark pt-1">استفاده از کیف پول</span>
                            <span class="grow text-xs tracking-tight font-medium text-dark pt-1 inventoryWallet" style=" color: #a7a7a7; font-size: 12px; "><div class="skeleton w-92 h-14 rounded-pill"></div></span>
                        </div>
                        <div class="text-2xs text-gray font-medium tracking-tight">
                            <label for="walletApi" class="input-label start w40_1">
                                <span class="start-label"></span>
                                <input id="walletApi" type="checkbox" class="input">
                                <span class="input-check" style=""></span>
                            </label>
                        </div>
                    </div>
                    <div class="hr-p"></div>
                    <div class="flex items-center leading-xs" style="filter: blur(0px);"><span class="grow text-xs tracking-tight font-medium text-dark pt-1">مبلغ قابل پرداخت</span>
                        <div class="flex flex-col align-items-end">
                            <div class="text-2xs text-gray font-medium tracking-tight">
                            <span class="text-lg font-bold text-green-dark tracking-tighter pt-2 inline-block" data-summary="total">${window.cart.total}</span>
                                تومان
                            </div>
                            <div class="text-2xs text-gray font-medium tracking-tight">
                            <span class="text-lg font-bold text-green-dark tracking-tighter pt-2 inline-block" data-summary="dtotal">${window.cart.totalUSD}</span>
                                دلار
                            </div>
                        </div>
                    </div>
                </div>
            </div>
<div class="border rounded mt-14 lg:mt-16">
                <button type="button" class="border-b w-full text-right border-gray-300 last:!border-b-0 py-16 px-14 flex items-center Button-p5" data-gateway="zibal">
                    <div class="pt-2 grow leading-1 tracking-tight">
                        <span class="block text-xs text-dark font-bold">پرداخت آنلاین</span>
                        <span class="block text-2xs font-normal text-dark mt-8">درگاه پرداخت زیبال</span>
                    </div>
                    <i class="w-20 h-20 text-center rounded-circle text-4xs pl-1 ml-4 !leading-[22px] icon-check transition-colors text-white bg-green bg-opacity-100"></i>
                </button>
                <button type="button" class="border-b w-full text-right border-gray-300 last:!border-b-0 py-16 px-14 flex items-center Button-p5" data-gateway="paystar">
                    <div class="pt-2 grow leading-1 tracking-tight">
                        <span class="block text-xs text-dark font-bold">پرداخت آنلاین</span>
                        <span class="block text-2xs font-normal text-dark mt-8">درگاه پرداخت پی استار</span>
                    </div>
                    <i class="w-20 h-20 text-center rounded-circle bg-gray bg-opacity-15 text-4xs pl-1 ml-4 !leading-[22px] icon-check transition-colors text-transparent"></i>
                </button>
                <button type="button" class="border-b w-full text-right border-gray-300 last:!border-b-0 py-16 px-14 flex items-center Button-p5" data-gateway="Payment4">
                    <div class="pt-2 grow leading-1 tracking-tight">
                        <span class="block text-xs text-dark font-bold">پرداخت دلاری</span>
                        <span class="block text-2xs font-normal text-dark mt-8">Payment4</span>
                    </div>
                    <i class="w-20 h-20 text-center rounded-circle bg-gray bg-opacity-15 text-4xs pl-1 ml-4 !leading-[22px] icon-check transition-colors text-transparent"></i>
                </button>
            </div>
            <div class="ktfb border-0">
                <h4>نکات مهم :</h4>
                <p> 1.  سبد خرید شما تا زمانی که پرداخت نهایی انجام نشه، قطعی رزرو نشده.لطفاً تا ۵ دقیقه آینده سفارشتون رو تکمیل و پرداخت کنید، وگرنه آیتم‌های داخل سبد به صورت خودکار آزاد و حذف می‌شن.</p>
                <p> 2. در صورت تکمیل سفارش و انجام فرایند احراز هویت و تحویل محصول خریداری شده ،فاکتور قابل عودت و برگشت به هیچ وجه ممکن نخواهد بود.</p>
                <p>3. درصورت عودت هرگونه وجهی ، 10% ارزش افزوده از مبلغ واریزی کسر و باقیمانده مبلغ طی 24 ساعت کاری به همان کارت بانکی که خرید شده است عودت خواهد شد.</p>
            </div>`;
            mobileCart.appendChild(cart__list);
            mobileCart.appendChild(pointBox);
            mobileCart.appendChild(Timer);
            mobileCart.appendChild(payment);
            const buttons = document.querySelectorAll('.Button-p5');
            buttons.forEach((button, index) => {
                button.addEventListener('click', function () {
                    buttons.forEach(btn => {
                        btn.querySelector('i').className = 'w-20 h-20 text-center rounded-circle bg-gray bg-opacity-15 text-4xs pl-1 ml-4 !leading-[22px] icon-check transition-colors text-transparent';
                    });
                    localStorage.setItem('selectedButtonFast', button.dataset.gateway);
                    this.querySelector('i').className = "w-20 h-20 text-center rounded-circle text-4xs pl-1 ml-4 !leading-[22px] icon-check transition-colors text-white bg-green bg-opacity-100";
                    if(button.dataset.gateway === 'Payment4'){
                        document.querySelectorAll("#mobileCart .flex.items-center.leading-xs")[2].style = 'display:none';
                        document.querySelectorAll("#mobileCart .flex.items-center.leading-xs")[3].style = 'display:none';
                    }else{
                        document.querySelectorAll("#mobileCart .flex.items-center.leading-xs")[2].style = '';
                        document.querySelectorAll("#mobileCart .flex.items-center.leading-xs")[3].style = '';
                    }
                });
            });
            SAJ("mc", {}, function (res) {
                if (res.success) {
                    $(".pointBox .font-bold").html(res.data.point);
                    if (res.data.inventory != 0) {
                        $(".inventoryWallet").html(res.data.inventory);
                    } else {
                        $(".inventoryWallet").html('');
                        $("#walletApi").remove();
                    }
                }
                startCartTimer();
            })
        }
    });
    $(document).on('click',".Button-au65",function (){
        const verification = window.user.type ? '' : `<li>
                        <a class="flex items-center leading-2 tracking-tight relative transition-colors py-5 px-16 text-gray hover:text-dark link-ds54" href="${wpApiSettingsGiftMax.home}/profile/verification">
                        <div class="flex items-center justify-center w-24 h-24 ml-10 -mr-4"><i class="opacity-90 icon-verify text-[21px] pt-1"></i></div>
                        <span class="pt-4 grow font-normal text-sm">احراز هویت</span>
                        </a>
                        </li>`;
            const contienr = document.querySelector("#popper-root");
            const div = document.createElement("div");
            div.className = 'absolute';
            div.innerHTML = `<div class="bg-n-000 overflow-y-hidden radius-md Popper__popper-_MjEue Popper__popper--sm-O6ws1M shadow-modal border-200 FilterChips__zIndex-HJBa6n Popper__popper--animated-active-c4re2j" style=""><div class="bg_while overflow-auto menuUser" style="transform: translateY(50%);"><div class="pos-sticky top-0 bg_while z-1 d-flex jc-between ai-center py-2 px-4 FilterChips__cardHeader-r0RCCF"> <div class="flex items-center pt-24 pb-8"><div class="text-secondary font-bold tracking-tighter text-normal leading-xs">${window.user.fullName}</div><div class="badge text-2xs rounded-pill font-normal px-14 mr-8 inline-block">کاربر <span class="font-medium"> ${window.user.access} </span></div></div> <div class="d-flex pointer  pointer" data-testid="close-wrapper-_app"> <svg style="width: 24px; height: 24px; fill: var(--color-icon-high-emphasis);"> <path d="M12 11.0537C12 11.0537 16.2827 6.77342 17.8617 5.19523C18.1221 4.93492 18.5443 4.93492 18.8047 5.19523C19.0651 5.45553 19.0651 5.87753 18.8047 6.13783C17.2257 7.71602 12.9391 12 12.9391 12C12.9391 12 17.2257 16.284 18.8047 17.8622C19.0651 18.1225 19.0651 18.5445 18.8047 18.8047C18.5443 19.0651 18.1221 19.0651 17.8617 18.8048C16.2827 17.2266 12 12.9463 12 12.9463C12 12.9463 7.7173 17.2266 6.1383 18.8048C5.8779 19.0651 5.4557 19.0651 5.1953 18.8048C4.9349 18.5445 4.9349 18.1225 5.1953 17.8622C6.7743 16.284 11.0609 12 11.0609 12C11.0609 12 6.7743 7.71602 5.1953 6.13783C4.9349 5.87753 4.9349 5.45552 5.1953 5.19533C5.4557 4.93493 5.8779 4.93492 6.1383 5.19523C7.7173 6.77342 12 11.0537 12 11.0537Z"></path> </svg></div> </div><div class="py-2 cardBodyDesktop-FZT9Y2"> 
            <div class="h-fit-content">
                <ul class="pb-16 grow overflow-y-auto"><li>
                <a class="flex items-center leading-2 tracking-tight relative transition-colors py-5 px-16 text-gray hover:text-dark link-ds54" href="${wpApiSettingsGiftMax.home}/profile">
                <div class="flex items-center justify-center w-24 h-24 ml-10 -mr-4"><i class="opacity-90 icon-menu2 text-lg"></i></div>
                <span class="grow font-normal text-sm">داشبورد</span>
                </a>
                </li>
                <li>
                <a class="flex items-center leading-2 tracking-tight relative transition-colors py-5 px-16 text-gray hover:text-dark link-ds54" href="${wpApiSettingsGiftMax.home}/profile/orders">
                <div class="flex items-center justify-center w-24 h-24 ml-10 -mr-4"><i class="opacity-90 text-xl icon icon-order pb-2"></i></div>
                <span class="grow font-normal text-sm">سفارش های من</span>
                </a>
                </li>
                <li>
                <a class="flex items-center leading-2 tracking-tight relative transition-colors py-5 px-16 text-gray hover:text-dark link-ds54 !text-secondary" href="${wpApiSettingsGiftMax.home}/profile/list">
                <div class="flex items-center justify-center w-24 h-24 ml-10 -mr-4">
                <svg viewBox="0 0 24 24" style="width: 18px; fill: none; stroke: #000000a6; display: flex; justify-content: center; align-items: center; line-height: normal;">
                            <path d="M12.62 20.81C12.28 20.93 11.72 20.93 11.38 20.81C8.48 19.82 2 15.69 2 8.68998C2 5.59998 4.49 3.09998 7.56 3.09998C9.38 3.09998 10.99 3.97998 12 5.33998C13.01 3.97998 14.63 3.09998 16.44 3.09998C19.51 3.09998 22 5.59998 22 8.68998C22 15.69 15.52 19.82 12.62 20.81Z" fill="none" stroke="inherit" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                        </svg>
                        </div>
                        <span class="grow font-normal text-sm">لیست علاقه مندی ها</span>
                        </a>
                        </li>
                        <li>
                        <a class="flex items-center leading-2 tracking-tight relative transition-colors py-5 px-16 text-gray hover:text-dark link-ds54" href="${wpApiSettingsGiftMax.home}/profile/deliveries">
                        <div class="flex items-center justify-center w-24 h-24 ml-10 -mr-4"><i class="opacity-90 icon-flash text-[19px] pb-1"></i></div>
                        <span class="grow font-normal text-sm">کدهای تحویل&zwnj;شده</span>
                        </a>
                        </li>
                        <li>
                        <li>
                        <a class="flex items-center leading-2 tracking-tight relative transition-colors py-5 px-16 text-gray hover:text-dark link-ds54" href="${wpApiSettingsGiftMax.home}/profile/post">
                        <div class="flex items-center justify-center w-24 h-24 ml-10 -mr-4"><i class="opacity-90 icon-document text-[19px] pb-1"></i></div>
                        <span class="grow font-normal text-sm">ارسال مقاله</span>
                        <span class="leading-1">
                        <div class="text-larger font-bold alert-blue tracking-tighter">  ${window.user.CounterPost} <span class="text-2xs text-gray font-medium">مقاله</span></div>
                        </span>
                        </a>
                        </li>
                        <li>
                        <a class="flex items-center leading-2 tracking-tight relative transition-colors py-5 px-16 text-gray hover:text-dark link-ds54" href="${wpApiSettingsGiftMax.home}/profile/wallet">
                        <div class="flex items-center justify-center w-24 h-24 ml-10 -mr-4"><i class="opacity-90 icon-wallet text-[21px] pb-1"></i></div>
                        <span class="grow font-normal text-sm">کیف پول و امتیاز</span>
                        <span class="leading-1">
                        <div class="text-larger font-bold text-primary-dark tracking-tighter">  ${window.user.points} <span class="text-2xs text-gray font-medium">امتیاز</span></div>
                        </span>
                        </a>
                        </li>
                        <li>
                        <a class="flex items-center leading-2 tracking-tight relative transition-colors py-5 px-16 text-gray hover:text-dark link-ds54" href="${wpApiSettingsGiftMax.home}/ticket">
                        <div class="flex items-center justify-center w-24 h-24 ml-10 -mr-4"><i class="opacity-90 text-xl icon-support pt-2"></i></div>
                        <span class="grow font-normal text-sm">پشتیبانی</span>
                        </a>
                        </li>
                        ${verification}
                        <li>
                        <a class="flex items-center leading-2 tracking-tight relative transition-colors py-5 px-16 text-gray hover:text-dark link-ds54" href="${wpApiSettingsGiftMax.home}/profile/coupons">
                        <div class="flex items-center justify-center w-24 h-24 ml-10 -mr-4"><i class="opacity-90 text-xl icon-gift"></i></div>
                        <span class="grow font-normal text-sm">کد های تخفیف</span>
                        </a>
                        </li>
                           <li>
                        <a class="flex items-center leading-2 tracking-tight relative transition-colors py-5 px-16 text-gray hover:text-dark link-ds54" href="${wpApiSettingsGiftMax.home}/profile/cards">
                        <div class="flex items-center justify-center w-24 h-24 ml-10 -mr-4"><i class="opacity-90 text-xl icon-card"></i></div>
                        <span class="grow font-normal text-sm">کارت&zwnj;های بانکی</span>
                        </a>
                        </li>
                        <li>
                        <a class="flex items-center leading-2 tracking-tight relative transition-colors py-5 px-16 text-gray hover:text-dark link-ds54" href="${wpApiSettingsGiftMax.home}/profile/user">
                        <div class="flex items-center justify-center w-24 h-24 ml-10 -mr-4"><i class="opacity-90 text-xl icon-user-o"></i></div>
                        <span class="grow font-normal text-sm">تنظیمات حساب کاربری</span>
                        </a>
                        </li>
                         <li>
                        <a class="flex items-center leading-2 tracking-tight relative transition-colors py-5 px-16 text-gray hover:text-dark link-ds54" href="${wpApiSettingsGiftMax.logout}">
                        <div class="flex items-center justify-center w-24 h-24 ml-10 -mr-4"><i class="opacity-90 text-xl icon-logout"></i></div>
                        <span class="grow font-normal text-sm">خروج از حساب</span>
                        </a>
                        </li>
                        </ul>
            </div>  </div></div></div>`
            contienr.appendChild(div);
        setTimeout(function () {
            var innerElement = document.querySelector('.menuUser');
            if (innerElement) {
                innerElement.style.transform = 'translateY(0%)'; // تنظیم transform
            }
        }, 20);
    });
    $(document).on("click",".link-ds54,[data-testid='close-wrapper-_app']",function (e){
        e.preventDefault();
        var innerElement = document.querySelector('.menuUser');
        if (innerElement) {
            innerElement.style.transform = 'translateY(400%)'; // تنظیم transform
        }
        setTimeout(function () {
            innerElement.closest(".absolute").remove();
        }, 100);
    });
    $(document).on("click",".dp-remove-filters",function (e){
        e.preventDefault();
       $(".msjduf").removeClass("SJDe9S5");
    });
    $(document).on("click",".act-filter-but",function (e){
        e.preventDefault();
       $(".msjduf").addClass("SJDe9S5");
    });
    $(document).on("click",".icon-show-nofit",function (e){
        e.preventDefault();
        const box = $(this);
        const r = box.closest('.toast-item-wrapper');
        const id = box.closest('.toast-item-wrapper').data('id');
        box.closest(".icon-wrapper").html(`<div class="d-flex ai-center jc-center relative grow-1" style=" width: 1em; height: 1em; "> <div class="uikit-atomic-Button-Button-module__Loading--jNJ_Z" data-testid="button-loading" style=" height: 12px; width: 13px; "> <div style=" height: 13px; width: 13px; "></div> </div> </div>`);
        SAJ('alert-notif',{id:id,method:'show'},function (res){
            r.remove();
            if (res.data.status){
                const co = document.querySelector('.DHDs8f');
                var i = co.textContent - 1;
                co.textContent = i;
                if (i <= 0){
                    co.classList.add('hidden');
                }
                document.body.classList.toggle("lock-body-scroll");
                const contienr = document.querySelector("#popper-root");
                const div = document.createElement("div");
                div.className = 'absolute';
                div.innerHTML = `<div class="ModalComponent__root-YwCAMP ModalComponent__root--desktop-JzGyNl ModalComponent__animation-JkgpfL ModalComponent__root--open-i5pSf7 ModalComponent__root--open__desktop-x1XDzU"><div class="ModalComponent__content-XqD1rL ModalComponent__animation-JkgpfL ModalComponent__content--desktop-o5IbOt ModalComponent__content--border-md-4G9biy overflow-auto " style="transform: translateY(50%);"> <div class="ModalComponent__header-l62jh_"><div class="d-flex ai-center AppHeader__headerBorder-sqCler  jc-between ProfileModal__header-QU8G4w"> <p class="text-h5 color-n-700 text-h5 text-color-neutral-700">${res.data.notification.title}</p> <div class="d-flex pointer pointer mr-2" data-testid="close-wrapper"> <svg style="width: 24px; height: 24px; fill: var(--color-icon-high-emphasis);"> <path d="M12 11.0537C12 11.0537 16.2827 6.77342 17.8617 5.19523C18.1221 4.93492 18.5443 4.93492 18.8047 5.19523C19.0651 5.45553 19.0651 5.87753 18.8047 6.13783C17.2257 7.71602 12.9391 12 12.9391 12C12.9391 12 17.2257 16.284 18.8047 17.8622C19.0651 18.1225 19.0651 18.5445 18.8047 18.8047C18.5443 19.0651 18.1221 19.0651 17.8617 18.8048C16.2827 17.2266 12 12.9463 12 12.9463C12 12.9463 7.7173 17.2266 6.1383 18.8048C5.8779 19.0651 5.4557 19.0651 5.1953 18.8048C4.9349 18.5445 4.9349 18.1225 5.1953 17.8622C6.7743 16.284 11.0609 12 11.0609 12C11.0609 12 6.7743 7.71602 5.1953 6.13783C4.9349 5.87753 4.9349 5.45552 5.1953 5.19533C5.4557 4.93493 5.8779 4.93492 6.1383 5.19523C7.7173 6.77342 12 11.0537 12 11.0537Z"></path> </svg></div> </div> </div> <div class="uModalComponent__body-WvxQuY ModalComponent__body--default-sYpvC3"> <label class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--L7bcQ uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--normal--A6Ntt text-body-1 color-n-700 w-100"><p class="mb-2 color-n-700 text-body-1 mb-2" data-testid="form-label">${res.data.notification.body}</p></label> </div><div class="grow-1"></div><div class="ModalComponent__footerContainer-rb1vEj"><div class="ProfileModal__footer-IVQdrc"> <button class="relative d-flex ai-center user-select-none btn-wc51H8 text-button-2 btn--primary-uiqWij radius Button__medium-gIvke_ Button__filledPrimary-OvgwGb ProfileBase__button-jvi4aR ProfileBase__button__modal-O3kjhU Button-pp45" data-testid="button-wrapper" type="button"><div class="d-flex ai-center jc-center relative grow-1">متوجه شدم</div></button></div> </div></div></div>`
                contienr.appendChild(div);
            }else{
               uikit__collections_error(res.data.message)
            }
        })
    });
    $(document).on("click",".icon-button",function (e){
        e.preventDefault();
        const box = $(this);
        const id = box.closest('.toast-item-wrapper').data('id');
        box.closest('.toast-item-wrapper').remove();
        if(id) {
            SAJ('alert-notif', {id: id, method: 'delete'}, function (res) {
                if (!res.data.status) {
                    uikit__collections_error(res.data.message)
                }
            })
        }
    });
    $(document).on('click','.Button-oc64', function(){
        document.body.classList.toggle("lock-body-scroll");
        const contienr = document.querySelector("#popper-root");
        const div = document.createElement("div");
        div.className = 'absolute';
        div.innerHTML = `<div class="ModalComponent__root-YwCAMP ModalComponent__root--desktop-JzGyNl ModalComponent__animation-JkgpfL ModalComponent__root--open-i5pSf7 ModalComponent__root--open__desktop-x1XDzU"><div class="ModalComponent__content-XqD1rL ModalComponent__animation-JkgpfL ModalComponent__content--desktop-o5IbOt ModalComponent__content--border-md-4G9biy overflow-auto " style="transform: translateY(50%);"> <div class="ModalComponent__header-l62jh_"><div class="d-flex ai-center AppHeader__headerBorder-sqCler  jc-between ProfileModal__header-QU8G4w"><p class="text-h5 color-n-700 text-h5 text-color-neutral-700">افزایش موجودی</p> <div class="d-flex pointer pointer mr-2" data-testid="close-wrapper"> <svg style="width: 24px; height: 24px; fill: var(--color-icon-high-emphasis);"> <path d="M12 11.0537C12 11.0537 16.2827 6.77342 17.8617 5.19523C18.1221 4.93492 18.5443 4.93492 18.8047 5.19523C19.0651 5.45553 19.0651 5.87753 18.8047 6.13783C17.2257 7.71602 12.9391 12 12.9391 12C12.9391 12 17.2257 16.284 18.8047 17.8622C19.0651 18.1225 19.0651 18.5445 18.8047 18.8047C18.5443 19.0651 18.1221 19.0651 17.8617 18.8048C16.2827 17.2266 12 12.9463 12 12.9463C12 12.9463 7.7173 17.2266 6.1383 18.8048C5.8779 19.0651 5.4557 19.0651 5.1953 18.8048C4.9349 18.5445 4.9349 18.1225 5.1953 17.8622C6.7743 16.284 11.0609 12 11.0609 12C11.0609 12 6.7743 7.71602 5.1953 6.13783C4.9349 5.87753 4.9349 5.45552 5.1953 5.19533C5.4557 4.93493 5.8779 4.93492 6.1383 5.19523C7.7173 6.77342 12 11.0537 12 11.0537Z"></path> </svg></div> </div> </div> <div class="uModalComponent__body-WvxQuY ModalComponent__body--default-sYpvC3"><div class="Hint--primary-mwFS2H Hint__padding-nRd4K4 radius Hint__iconStart-bpg5ZO mb-2" data-testid="hint-wrapper"><div class="d-flex ai-center"><div class="d-flex Hint__titleSlot-yPP6H0" data-testid="icon-wrapper"><svg style="width: 24px; height: 24px; fill: #1ab1d4;"><path d="M2 12c0 5.523 4.477 10 10 10s10-4.477 10-10c0-5.523-4.477-10-10-10s-10 4.477-10 10zM12 7c0.552 0 1 0.448 1 1s-0.448 1-1 1c-0.552 0-1-0.448-1-1s0.448-1 1-1zM10 10h3v7h-2v-5h-1v-2z"></path></svg></div><span class="mr-2 text-body-1 color-brand-primary-700 Hint__padding--title-AHG0eM">به منظور پیشگیری از فیشینگ و کلاهبرداری در پرداخت‌های اینترنتی، پرداخت تنها با استفاده از کارتی مجاز است که متعلق به خود شما می‌باشد. برای انجام افزایش موجودی، ابتدا باید تلفن ثابت شما احراز شده باشد.</span></div></div>  <div class="d-flex flex-column gap-y-5"> <div> <div class="text-body-1 color-n-700 d-flex ai-center jc-between"><p>مقدار شارژ حساب(ريال)</p></div> <p class="text-body-2 color-n-500"></p><label class="FormComponentFrame-sy77JE FormComponentFrame--normal-Tol9_4 w-100"> <div class="FormComponentFrame__input-container-fArle6 px-2 d-flex ai-center"> <section class="grow-1 text-body-2-c"><input class="px-2 TextField__input-xuVYYy text-subtitle w-100 TextField-cJQfI5 TextField--primary-cAI5H3" name="wallet_amount"></section> <div></div> </div> </label></div>  </div> <div class="d-flex Container-mirV2w mb-4 Container--withBorder-OdFFhL"><div class="ProfileLayout__tab-rvmH7A TabItem-CWkOsT TabItem__active-AZcc4O text-subtitle-strong">کارت های متعاق به خودتان</div></div><div id="cartUser"><div class="d-flex ai-center jc-center relative grow-1"> <div class="uikit-atomic-Button-Button-module__Loading--jNJ_Z" data-testid="button-loading"> <div style="border-color: #000000 transparent;"></div> </div> </div></div> </div><div class="grow-1"></div><div class="ModalComponent__footerContainer-rb1vEj media"><div class="ProfileModal__footer-IVQdrc media"> <button class="relative d-flex ai-center user-select-none btn-wc51H8 text-button-2 btn--primary-uiqWij radius Button__medium-gIvke_ Button__filledPrimary-OvgwGb ProfileBase__button-jvi4aR ProfileBase__button__modal-O3kjhU Button-uw56" data-testid="button-wrapper" type="button"><div class="d-flex ai-center jc-center relative grow-1">پرداخت</div></button></div> </div></div></div>`;
        contienr.appendChild(div);
        setTimeout(function (){
            SAJ('userCart',{m:true},function (res){
                if(res.html){
                    $("#cartUser").html(res.html);
                }
            },"v2")
        },500)
    });
    $(document).on('click', '.Button-uw56', function (e) {
        e.preventDefault();
        const button = $(this);
        const originalHTML = button.html();
        button.prop('disabled', true);
        button.html(`<div class="d-flex ai-center jc-center relative grow-1"> <div class="uikit-atomic-Button-Button-module__Loading--jNJ_Z" data-testid="button-loading"> <div></div> </div> </div>`);

        const walletInput = $("input[name='wallet_amount']").val();

        const wallet_amount = parseInt(walletInput.replace(/,/g, ''), 10);

        if (isNaN(wallet_amount) || wallet_amount < 100000) {
            uikit__collections_error("حداقل مبلغ 100 هزار ریال است");
            button.prop('disabled', false);
            button.html(originalHTML);
            return false;
        }

        SAJ('wallet_amount', { wallet_amount: wallet_amount }, function (d) {
                if (d.status) {
                    window.location.href = d.url;
                } else {
                    uikit__collections_error(d.message);
                    if(d.n){
                        closePup(button);
                        setTimeout(function (){
                            document.body.classList.toggle("lock-body-scroll");
                            const contienr = document.querySelector("#popper-root");
                            const div = document.createElement("div");
                            div.className = 'absolute';
                            div.innerHTML = `<div class="ModalComponent__root-YwCAMP ModalComponent__root--desktop-JzGyNl ModalComponent__animation-JkgpfL ModalComponent__root--open-i5pSf7 ModalComponent__root--open__desktop-x1XDzU"><div class="ModalComponent__content-XqD1rL ModalComponent__animation-JkgpfL ModalComponent__content--desktop-o5IbOt ModalComponent__content--border-md-4G9biy overflow-auto " style="transform: translateY(50%);"> <div class="ModalComponent__header-l62jh_"><div class="d-flex ai-center AppHeader__headerBorder-sqCler  jc-between ProfileModal__header-QU8G4w"> <p class="text-h5 color-n-700 text-h5 text-color-neutral-700">تایید تلفن ثابت</p> <div class="d-flex pointer pointer mr-2" data-testid="close-wrapper"> <svg style="width: 24px; height: 24px; fill: var(--color-icon-high-emphasis);"> <path d="M12 11.0537C12 11.0537 16.2827 6.77342 17.8617 5.19523C18.1221 4.93492 18.5443 4.93492 18.8047 5.19523C19.0651 5.45553 19.0651 5.87753 18.8047 6.13783C17.2257 7.71602 12.9391 12 12.9391 12C12.9391 12 17.2257 16.284 18.8047 17.8622C19.0651 18.1225 19.0651 18.5445 18.8047 18.8047C18.5443 19.0651 18.1221 19.0651 17.8617 18.8048C16.2827 17.2266 12 12.9463 12 12.9463C12 12.9463 7.7173 17.2266 6.1383 18.8048C5.8779 19.0651 5.4557 19.0651 5.1953 18.8048C4.9349 18.5445 4.9349 18.1225 5.1953 17.8622C6.7743 16.284 11.0609 12 11.0609 12C11.0609 12 6.7743 7.71602 5.1953 6.13783C4.9349 5.87753 4.9349 5.45552 5.1953 5.19533C5.4557 4.93493 5.8779 4.93492 6.1383 5.19523C7.7173 6.77342 12 11.0537 12 11.0537Z"></path> </svg></div> </div> </div> <div class="uModalComponent__body-WvxQuY ModalComponent__body--default-sYpvC3"> <label class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--L7bcQ uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--normal--A6Ntt text-body-1 color-n-700 w-100"><p class="mb-2 color-n-700 text-body-1 mb-2" data-testid="form-label">شماره تلفن ثابت خود را وارد کنید </p><div class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame__input-container--D5edN px-2 d-flex ai-center"><section class="grow-1 text-body-2-c"><input class="px-2 TextField__input-_5fbdd text-subtitle w-100 TextField-e58168" type="text" name="value" placeholder="031123456789"></section></div></label> </div><div class="grow-1"></div><div class="ModalComponent__footerContainer-rb1vEj"><div class="ProfileModal__footer-IVQdrc"> <button class="relative d-flex ai-center user-select-none btn-wc51H8 text-button-2 btn--primary-uiqWij radius Button__medium-gIvke_ Button__filledPrimary-OvgwGb ProfileBase__button-jvi4aR ProfileBase__button__modal-O3kjhU Button-on45" data-testid="button-wrapper" type="button"><div class="d-flex ai-center jc-center relative grow-1">تایید</div></button></div> </div></div></div>`
                            contienr.appendChild(div);
                        },500)
                    }
                    button.prop('disabled', false);
                    button.html(originalHTML);
                }
            },
            'v2'
        );

        return false;
    });
    $(document).on('click', '.apd5 .act-faq_item', function (e) {
        e.preventDefault();
        const item = $(this);
        const answer = item.find('.act-answer');
        const icon = item.find(".act-questions-flash")[0];
        if (item.hasClass('collapsed')) {
            item.removeClass('collapsed');
            answer.removeClass('show');
            icon.animate(
                [
                    { transform: "rotate(0deg)" },
                    { transform: "rotate(180deg)" }
                ],
                {
                    duration: 300,
                    fill: "forwards"
                }
            );
        } else {
            item.addClass('collapsed');
            answer.addClass('show');
            icon.animate(
                [
                    { transform: "rotate(180deg)" },
                    { transform: "rotate(0deg)" }
                ],
                {
                    duration: 300,
                    fill: "forwards"
                }
            );

        }

    });
    $(document).on('click', '.Button-csu56', function (e) {
        e.preventDefault();
        const button = $(this);
        const name = $("#name").val(), email = $("#email").val(),subject = $("#subject").val(),text = $("#text").val();
        if(name.length <= 0 || email.length <= 0 || subject.length <= 0 || text.length <= 0){
            uikit__collections_error("لطفا همه ورودی ها را کامل کنید");
            return ;
        }
        const originalHTML = button.html();
        button.prop('disabled', true);
        button.html(`<div class="d-flex ai-center jc-center relative grow-1"> <div class="uikit-atomic-Button-Button-module__Loading--jNJ_Z" data-testid="button-loading"> <div></div> </div> </div>`);

        SAJ('contact', { name: name,email:email,subject:subject,text:text }, function (d) {
                button.prop('disabled', false);
                button.html(originalHTML);
                if (d.status) {
                    uikit__collections_success("پیغام شما ثبت شده،ممنون از شما");
                    $('#name, #email, #subject, #text').val('');
                } else {
                    uikit__collections_error(d.message);
                }
            },
            'v2'
        );
    });
    const djde6s5 = document.querySelector(".djde6s5");
    if (djde6s5 && djde6s5.clientHeight > 29) {
        djde6s5.height = '29px';
        djde6s5.querySelector('ul').classList.remove('flex-wrap');
        const div = document.createElement('div');
        div.className = "bg-gradient-to-r from-white from-50% pr-60 absolute left-0 top-0 pointer-events-none";
        div.innerHTML = `<button type="button" class="btn group px-8 border border-light bg-light hover:bg-primary hover:border-transparent hover:bg-opacity-15 block rounded-sm text-2xs leading-1 pt-8 pb-6 pointer-events-auto Buton-df96"> <span className="text-dark opacity-75 group-hover:opacity-100 group-hover:text-primary-dark transition-all">بیشتر...</span> </button>`;
        djde6s5.appendChild(div);
    }
    $(document).on('click','.list_meno .toggle-header',function (){
        const header = $(this);
        const ulElement = header.closest('.box').find('ul');
        const icon = header.find('.toggle-icon');
        ulElement.toggleClass('open');
        icon.toggleClass('rotate');
    });
    $(document).on('click', '.v10__Pagination-item', function () {
        setActive(this);
    })
    const items = document.querySelectorAll('.v10__Pagination-item');
    if (items.length > 0) {
        const defaultActive = document.querySelector('.v10__Pagination-item.active') || items[0];
        setActive(defaultActive);
    }
    $(document).on('click', '.Button-np51', function (e) {
        e.preventDefault();
        const page = $(this).data('page');
        if(page) {
            SAJ('pagination', {page: page,method:"notification"}, function (response) {
                document.querySelector("#app > main > main > div > div:nth-child(2) > div > section > section > div > section").innerHTML = response.html;
            })
        }
    });
    $(document).on('click', '.Button-np52', function (e) {
        e.preventDefault();
        const page = $(this).data('page');
        if(page) {
            SAJ('pagination', {page: page,method:"ticket"}, function (response) {
                document.querySelector("#app > main > main > div:nth-child(3) > div > section.p-5.TableCard--bodyMobile-tDS3OZ > section > div > section").innerHTML = response.html;
            })
        }
    });
});
document.addEventListener('DOMContentLoaded', function () {
    if(document.querySelector('.skeleton-loader')) {
        document.querySelector('.skeleton-loader').style.display = 'none';
    }
    const lottieContainers = document.querySelectorAll('.lottie-container');

    lottieContainers.forEach(container => {
        const animationPath = container.getAttribute('data-lottie-url');

        if (animationPath) {
            lottie.loadAnimation({
                container: container, // المانی که انیمیشن در آن قرار می‌گیرد
                renderer: 'svg',       // نوع رندر (svg بهترین گزینه است)
                loop: true,            // تکرار انیمیشن
                autoplay: true,        // اجرای خودکار
                path: animationPath    // آدرس فایل JSON آپلود شده
            });
            container.setAttribute('data-lottie-url', '');
        }

    });
});