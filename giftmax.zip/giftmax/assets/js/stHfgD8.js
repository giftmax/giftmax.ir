var $ = jQuery;
(function ($) {
    'use strict';
    window.uikit__collections_error = function (message) {
        const container = document.querySelector("#popper-root #snackbar-container");
        const div = document.createElement('div');
        div.className = "Snackbar__root-_963b0 Snackbar__bg--error-_533ca d-flex mb-2 p-4 jc-start flex-column Snackbar__root--open-_126cb";
        div.style = "opacity: 1; transform: translateY(100px);"
        div.innerHTML = `<div class="color-000 text-body-1 align-center">${message}</div>`
        container.appendChild(div);
        setTimeout(function () {
            div.style = "opacity: 1; transform: translateY(0px);"
        }, 10);
        setTimeout(function () {
            div.style = "opacity: 0; transform: translateY(100px);"
        }, 6000);
        setTimeout(function () {
            div.remove();
        }, 7000);
    }
    window.uikit__collections_success = function (message) {
        const container = document.querySelector("#popper-root #snackbar-container");
        const div = document.createElement('div');
        div.className = "Snackbar__root-_963b0 Snackbar__bg--success-UqXMB3 d-flex mb-2 p-4 jc-start flex-column Snackbar__root--open-_126cb";
        div.style="opacity: 1; transform: translateY(100px);"
        div.innerHTML = `<div class="color-000 text-body-1 align-center">${message}</div>`
        container.appendChild(div);
        setTimeout(function() {
            div.style="opacity: 1; transform: translateY(0px);"
        }, 10);
        setTimeout(function() {
            div.style="opacity: 0; transform: translateY(100px);"
        }, 6000);
        setTimeout(function() {
            div.remove();
        }, 7000);
    }

    window.uikit__collections_Popup = function (message, item, type,cla= '',button=null) {
        if (button == null) {
            button = `<div class="ProfileModal__footer-IVQdrc ${type}"> <button class="relative d-flex ai-center user-select-none btn-wc51H8 text-button-2 btn--primary-uiqWij radius Button__medium-gIvke_ Button__filledPrimary-OvgwGb ProfileBase__button-jvi4aR ProfileBase__button__modal-O3kjhU Button-MNNP44" data-testid="button-wrapper" type="button"><div class="d-flex ai-center jc-center relative grow-1">تایید</div></button></div> `;
        }
        if (button != false && button !=null) {
            if(type === ''){
                type = 'ProfileModal__footerContainer-eYd58G';
            }
            var buttons = `<div class="ModalComponent__footerContainer-rb1vEj ${type}">${button}</div>`;
        } else {
            buttons = "";
        }
        const container_main = document.querySelector("#popper-root");
        let classcheck = '';
        if (cla !== '') {
            const raw = cla.startsWith('.') ? cla.slice(1) : cla; // فقط نام کلاس
            classcheck = `.${CSS.escape(raw)}`;
        }
        if (!container_main.querySelector(`.ModalComponent__content-XqD1rL.ModalComponent__animation-JkgpfL.ModalComponent__content--desktop-o5IbOt.ModalComponent__content--border-md-4G9biy.overflow-auto${classcheck}`)) {
            const container = document.createElement("div");
            container.className = "absolute";
            container_main.appendChild(container);
            const div = document.createElement('div');
            div.className = "ModalComponent__root-YwCAMP ModalComponent__root--desktop-JzGyNl ModalComponent__animation-JkgpfL ModalComponent__root--open-i5pSf7 ModalComponent__root--open__desktop-x1XDzU";
            div.innerHTML = `<div class="ModalComponent__content-XqD1rL ModalComponent__animation-JkgpfL ModalComponent__content--desktop-o5IbOt ModalComponent__content--border-md-4G9biy overflow-auto ${cla}" style="transform: translateY(400%);"> <div class="ModalComponent__header-l62jh_"><div class="d-flex ai-center AppHeader__headerBorder-sqCler  jc-between ProfileModal__header-QU8G4w"> <p class="text-h5 color-n-700 text-h5 text-color-neutral-700">${message}</p> <div class="d-flex pointer pointer mr-2" data-testid="close-wrapper"> <svg style="width: 24px; height: 24px; fill: var(--color-icon-high-emphasis);"> <path d="M12 11.0537C12 11.0537 16.2827 6.77342 17.8617 5.19523C18.1221 4.93492 18.5443 4.93492 18.8047 5.19523C19.0651 5.45553 19.0651 5.87753 18.8047 6.13783C17.2257 7.71602 12.9391 12 12.9391 12C12.9391 12 17.2257 16.284 18.8047 17.8622C19.0651 18.1225 19.0651 18.5445 18.8047 18.8047C18.5443 19.0651 18.1221 19.0651 17.8617 18.8048C16.2827 17.2266 12 12.9463 12 12.9463C12 12.9463 7.7173 17.2266 6.1383 18.8048C5.8779 19.0651 5.4557 19.0651 5.1953 18.8048C4.9349 18.5445 4.9349 18.1225 5.1953 17.8622C6.7743 16.284 11.0609 12 11.0609 12C11.0609 12 6.7743 7.71602 5.1953 6.13783C4.9349 5.87753 4.9349 5.45552 5.1953 5.19533C5.4557 4.93493 5.8779 4.93492 6.1383 5.19523C7.7173 6.77342 12 11.0537 12 11.0537Z"></path> </svg></div> </div> </div> <div class="uModalComponent__body-WvxQuY ModalComponent__body--default-sYpvC3"> ${item} </div><div class="grow-1"></div>${buttons}</div>`;
            document.body.classList.add("lock-body-scroll");
            container.appendChild(div);
            setTimeout(function () {
                $(".ModalComponent__content-XqD1rL.ModalComponent__animation-JkgpfL.ModalComponent__content--desktop-o5IbOt.ModalComponent__content--border-md-4G9biy.overflow-auto").css('transform', 'translateY(50%)');
            }, 20);
        }
    }
    window.SAJ = function (url='', dataAjax = {},callback) {
        const ajaxOptions = {
            url: `${wpApiSettingsGiftMax.root}api/v3/${url}`,
            method: 'POST',
            dataType: 'json',
            data: dataAjax,
            beforeSend: function (xhr) {
                xhr.setRequestHeader('X-WP-Nonce', wpApiSettingsGiftMax.nonce);
            },
            success: function (response) {
                if (typeof callback === 'function') {
                    callback(response);
                }
            },
            error: function (jqXHR, exception) {
                if (jqXHR.status === 0) {
                    uikit__collections_error('اینترنت شما قطع شده است!');
                } else if (jqXHR.status == 404) {
                    uikit__collections_error('Requested page not found. [404]');
                } else if (jqXHR.status == 500) {
                    uikit__collections_error('Internal Server Error [500].');
                } else if (exception === 'parsererror') {
                    uikit__collections_error('Requested JSON parse failed.');
                    uikit__collections_error(jqXHR.message);
                } else if (exception === 'timeout') {
                    uikit__collections_error('Time out error.');
                } else if (exception === 'abort') {
                    uikit__collections_error('Ajax request aborted.');
                } else {
                    uikit__collections_error('Uncaught Error.\n' + jqXHR.message);
                }
            }
        };
        $.ajax(ajaxOptions);
    }
    window.initSearch = function () {
        document.querySelectorAll('.Search__call-Ms6j86').forEach(dayElement => {
            dayElement.addEventListener('click', function () {
                const name = this.querySelector('p').innerText;
                const id = this.querySelector('#cat_id').value;
                if (this.classList.contains('SearchCall__selected-LkAfu4')){
                    this.classList.remove('SearchCall__selected-LkAfu4');
                    this.querySelector(".IconButton__prependIcon-mxVR2M svg").innerHTML = `<path d="M12 22c5.523 0 10-4.477 10-10s-4.477-10-10-10c-5.523 0-10 4.477-10 10s4.477 10 10 10zM11 11v-4h2v4h4v2h-4v4h-2v-4h-4v-2h4z"></path>`
                    document.querySelector(`.c-category__${id}`).remove();
                } else {
                    this.classList.add('SearchCall__selected-LkAfu4');
                    if (!document.querySelector(`.c-category__${id}`)) {
                        this.querySelector(".IconButton__prependIcon-mxVR2M svg").innerHTML = `<path d="M2 12c0 5.523 4.477 10 10 10s10-4.477 10-10c0-5.523-4.477-10-10-10s-10 4.477-10 10zM17 11v2h-10v-2h10z"></path>`
                        const category_c = document.querySelector("#category_c");
                        const div = document.createElement("div");
                        div.className = `d-flex ai-center c-category__${id}`;
                        div.innerHTML = `<button class="relative d-flex ai-center user-select-none btn-wc51H8 text-button-2 btn--text-se4oQM btn--error-UMipUi btn--icon-ZPHT4g radius Button__medium-gIvke_ Button__textError-a_OxlI Button__prependIcon-hh7768 IconButton__button-RRc2H_ Button-dcc89" data-testid="button-wrapper" type="button"><div class="d-flex ai-center jc-center relative grow-1"><div class="d-flex IconButton__prependIcon-mxVR2M p-4" data-testid="icon-wrapper"><svg data-testid="button-prepend-icon" style="width: 24px; height: 24px; fill: var(--color-icon-neutral-000);"><path d="M17 8h2v11c0 1.657-1.343 3-3 3h-8c-1.657 0-3-1.343-3-3v-11h2v11c0 0.552 0.448 1 1 1h8c0.552 0 1-0.448 1-1v-11zM4 7v-2h16v2h-16zM9 8h2v10h-2v-10zM13 8h2v10h-2v-10zM8 4v-2h8v2h-8z"></path></svg></div></div></button><p class="text-body1-strong ">${name}</p><input name="c_id[]" type="text" class="hidden" value="${id}">`;
                        category_c.appendChild(div);
                    }
                }
            });
        });
    }
    window.closePup = function (closeBtn){
        const modalRoot = closeBtn.closest(
            '.ModalComponent__root-YwCAMP.ModalComponent__root--desktop-JzGyNl.ModalComponent__animation-JkgpfL.ModalComponent__root--open-i5pSf7.ModalComponent__root--open__desktop-x1XDzU'
        );
        closeBtn.closest('.ModalComponent__content-XqD1rL').css('transform', 'translateY(400%)');
        setTimeout(function () {
            modalRoot.remove();
            document.body.classList.toggle('lock-body-scroll');
        }, 100);
    }
})(jQuery);
function changeSwitch(id_div) {
    document.querySelectorAll(`#${id_div}`)[0].checked = false;
    const id = id_div;
    let on = id_div.checked;
    if (on){
        on = 1;
    }else{
        on = 0;
    }
    SAJ("Save",{key:id,value:on},function (res){
        if (res.status) {
            uikit__collections_success(res.message);
        }else{
            uikit__collections_error(res.message);
        }
    })
}
$(function (){
    let timer = null;

    $(document).on('click', '#popper-root [data-testid=\"close-wrapper\"]', function (e) {
        e.preventDefault();
        closePup($(this));
    });
    $(document).on('click', '.Button-dcc89', function (e) {
        e.preventDefault();
        this.closest('div').remove();
        var id = this.closest('div').querySelector('input').value;
        const div = document.querySelector(`.Div-cc${id}`);
        if(div.classList.contains("SearchCall__selected-LkAfu4")){
            div.classList.remove("SearchCall__selected-LkAfu4");
            div.querySelector(".IconButton__prependIcon-mxVR2M svg").innerHTML = `<path d="M12 22c5.523 0 10-4.477 10-10s-4.477-10-10-10c-5.523 0-10 4.477-10 10s4.477 10 10 10zM11 11v-4h2v4h4v2h-4v4h-2v-4h-4v-2h4z"></path>`
        }
    });
    $(document).on('click', '.Button-cb54', function (e) {
        e.preventDefault();
        e.stopPropagation();

        uikit__collections_Popup("انتخاب دسته بندی ها","<label class=\"uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--L7bcQ uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--normal--A6Ntt text-body-1 color-n-700 w-100\"><p class=\"mb-2 color-n-700 text-body-1 mb-2\" data-testid=\"form-label\">با جستجو دسته بندی ها رو اضافه کنید</p><div class=\"uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame__input-container--D5edN px-2 d-flex ai-center\"><section class=\"grow-1 text-body-2-c\"><input class=\"px-2 TextField__input-_5fbdd text-subtitle w-100 TextField-e58168\" type=\"text\" name=\"category\" placeholder=\"مثال: هوش مصنوعی\"></section></div></label><div class=\"WorkdaySearchModal__Seach-ExCB17 radius-md  mb-2 hidden\"></div><div id='category_c'></div>","Button-sc54");
        SAJ("ShowCategory",{},function (res){
            if (res.status){
                const main = document.querySelector("#category_c");
                main.innerHTML = res.html;
            }
        })
    });
    let name,nameEn;
    $(document).on('click', '.Button-qfc65', function (e) {
        e.preventDefault();
        e.stopPropagation();
        const button = $(this);
        name = button.closest('.styles_btn-_mLWbq').find('#name').val();
        nameEn = button.closest('.styles_btn-_mLWbq').find('#name_en').val();
        if (name.length <= 0 || nameEn.length <= 0){
            uikit__collections_error("باید همه اطلاعات تب رو کامل کنید");
            return false;
        }
        uikit__collections_Popup("انتخاب دسته بندی ها","<label class=\"uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--L7bcQ uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--normal--A6Ntt text-body-1 color-n-700 w-100\"><p class=\"mb-2 color-n-700 text-body-1 mb-2\" data-testid=\"form-label\">با جستجو دسته بندی ها رو اضافه کنید</p><div class=\"uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame__input-container--D5edN px-2 d-flex ai-center\"><section class=\"grow-1 text-body-2-c\"><input class=\"px-2 TextField__input-_5fbdd text-subtitle w-100 TextField-e58168\" type=\"text\" name=\"categoryProduct\" placeholder=\"مثال: هوش مصنوعی\"></section></div></label><div class=\"WorkdaySearchModal__Seach-ExCB17 radius-md  mb-2 hidden\"></div><div id='category_c'></div>","Button-dh87");
        SAJ("ShowCategoryProduct",{slug:nameEn},function (res){
            if (res.status){
                const main = document.querySelector("#category_c");
                main.innerHTML = res.html;
            }
        })
    });
    $(document).on('click', '.Button-dh87', function (e) {
        e.preventDefault();
        e.stopPropagation();
        const inputs = document.querySelectorAll('#category_c input[name="c_id[]"]');
        const ids = Array.from(inputs, el => el.value.trim()).filter(v => v !== '').join(',');
        if (ids.length <=0){
            uikit__collections_error('هنوز هیچ دسته بندی مشخص نشده');
            return false;
        }
        SAJ("scp",{name:name,slug:nameEn,value:ids},function (res){
            if (res.status) {
                uikit__collections_success(res.message);
                closePup($(this));
            }else{
                uikit__collections_error(res.message);
            }
        })
    });
    $(document).on('click', '.Button-dfs18', function (e) {
        e.preventDefault();
        e.stopPropagation();
        const button = $(this);
        var slug =$(this).closest('.styles_btn-_mLWbq').data('slug');
        if (slug) {
            SAJ('dt', {slug: slug}, function (res) {
                if (res.status) {
                    button.closest('.styles_btn-_mLWbq').remove();
                    uikit__collections_success("عملیات با موفقیت انجام شده");
                } else {
                    uikit__collections_error("خطایی رخ داده است");
                }
            })
        }else {
            $(this).closest('.styles_btn-_mLWbq').remove();
        }
        if (document.querySelectorAll(".styles_btn-_mLWbq").length <= 0){
            const div = document.createElement('div');
            div.className = 'styles_btn-_mLWbq';
            div.innerHTML = `<div class="styles_btn--neutralOutlined__mLWbq Button-dfs18">
                <i class="icon-delete"></i>
            </div>
        <div class=" d-flex flex-column">
                <div class="d-flex jc-between ai-start gap-14">
                    <div>
                        <label class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--L7bcQ uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--normal--A6Ntt text-body-1 color-n-700 w-100">
                            <p class="mb-2 color-n-700 text-body-1 mb-2" data-testid="form-label"> نام تب </p>
                            <div class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame__input-container--D5edN px-2 d-flex ai-center">
                                <section class="grow-1 text-body-2-c">
                                    <input class="px-2 TextField__input-_5fbdd text-subtitle w-100 TextField-e58168" type="text" id="name"></section>
                            </div>
                        </label>
                        <label class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--L7bcQ uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--normal--A6Ntt text-body-1 color-n-700 w-100">
                            <p class="mb-2 color-n-700 text-body-1 mb-2" data-testid="form-label"> نام انگلیسی تب </p>
                            <div class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame__input-container--D5edN px-2 d-flex ai-center">
                                <section class="grow-1 text-body-2-c">
                                    <input class="px-2 TextField__input-_5fbdd text-subtitle w-100 TextField-e58168" type="text" id="name_en" ></section>
                            </div>
                        </label>
                        <p class="text-subtitle-strong flex-1"></p>
                    </div>
                    <button class="relative d-flex ai-center user-select-none btn-wc51H8 text-button-2 btn--text-se4oQM btn--primary-uiqWij btn--icon-ZPHT4g radius Button__medium-gIvke_ Button__textPrimary-IWW5Sd Button__prependIcon-hh7768 IconButton__button-RRc2H_ Button-qfc65" data-testid="button-wrapper" type="button">
                        <div class="d-flex ai-center jc-center relative grow-1">
                            <div class="d-flex IconButton__prependIcon-mxVR2M p-4" data-testid="icon-wrapper">
                                <svg data-testid="button-prepend-icon" style="width: 24px; height: 24px; fill: var(--color-icon-primary);"><path d="M15.293 3.293c0.391-0.391 1.024-0.391 1.414 0l4 4c0.391 0.391 0.391 1.024 0 1.414l-12 12c-0.188 0.188-0.442 0.293-0.707 0.293h-4c-0.552 0-1-0.448-1-1v-4c0-0.265 0.105-0.52 0.293-0.707l12-12zM5 16.414v2.586h2.586l11-11-2.586-2.586-11 11zM10 21l2-2h9v2h-11z"></path></svg>
                            </div>
                        </div>
                    </button>
                </div>
            </div>`;
            document.querySelector('.styles_box-_dXFga').appendChild(div);
        }
    });
    $(document).on('input',"input[name='categoryProduct']", function (e) {
        e.preventDefault();
        e.stopPropagation();

        const query = $(this).val().trim();
        clearTimeout(timer);

        timer = setTimeout(() => {
            const main = document.querySelector(".WorkdaySearchModal__Seach-ExCB17");
            if (query.length > 0) {
                SAJ("searchCategory",{query:query,method:'product',slug:nameEn},function (res){
                    if (res.status) {
                        main.innerHTML = res.html;
                        main.classList.remove("hidden");
                        initSearch();
                    }else{
                        uikit__collections_error(res.message);
                    }
                })
            }else {
                main.classList.add("hidden");
            }
        }, 500);
    });
    $(document).on('click','.Button-qfs65', function (e) {
        e.preventDefault();
        const div = document.createElement('div');
        div.className = 'styles_btn-_mLWbq';
        div.innerHTML = `<div class="styles_btn--neutralOutlined__mLWbq Button-dfs18">
                <i class="icon-delete"></i>
            </div>
        <div class=" d-flex flex-column">
                <div class="d-flex jc-between ai-start gap-14">
                    <div>
                        <label class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--L7bcQ uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--normal--A6Ntt text-body-1 color-n-700 w-100">
                            <p class="mb-2 color-n-700 text-body-1 mb-2" data-testid="form-label"> نام تب </p>
                            <div class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame__input-container--D5edN px-2 d-flex ai-center">
                                <section class="grow-1 text-body-2-c">
                                    <input class="px-2 TextField__input-_5fbdd text-subtitle w-100 TextField-e58168" type="text" id="name"></section>
                            </div>
                        </label>
                        <label class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--L7bcQ uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--normal--A6Ntt text-body-1 color-n-700 w-100">
                            <p class="mb-2 color-n-700 text-body-1 mb-2" data-testid="form-label"> نام انگلیسی تب </p>
                            <div class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame__input-container--D5edN px-2 d-flex ai-center">
                                <section class="grow-1 text-body-2-c">
                                    <input class="px-2 TextField__input-_5fbdd text-subtitle w-100 TextField-e58168" type="text" id="name_en" ></section>
                            </div>
                        </label>
                        <p class="text-subtitle-strong flex-1"></p>
                    </div>
                    <button class="relative d-flex ai-center user-select-none btn-wc51H8 text-button-2 btn--text-se4oQM btn--primary-uiqWij btn--icon-ZPHT4g radius Button__medium-gIvke_ Button__textPrimary-IWW5Sd Button__prependIcon-hh7768 IconButton__button-RRc2H_ Button-qfc65" data-testid="button-wrapper" type="button">
                        <div class="d-flex ai-center jc-center relative grow-1">
                            <div class="d-flex IconButton__prependIcon-mxVR2M p-4" data-testid="icon-wrapper">
                                <svg data-testid="button-prepend-icon" style="width: 24px; height: 24px; fill: var(--color-icon-primary);"><path d="M15.293 3.293c0.391-0.391 1.024-0.391 1.414 0l4 4c0.391 0.391 0.391 1.024 0 1.414l-12 12c-0.188 0.188-0.442 0.293-0.707 0.293h-4c-0.552 0-1-0.448-1-1v-4c0-0.265 0.105-0.52 0.293-0.707l12-12zM5 16.414v2.586h2.586l11-11-2.586-2.586-11 11zM10 21l2-2h9v2h-11z"></path></svg>
                            </div>
                        </div>
                    </button>
                </div>
            </div>`;
        document.querySelector('.styles_box-_dXFga').appendChild(div);
    });
    $(document).on('click', '.Button-sd78', function (e) {
        e.preventDefault();
        uikit__collections_Popup("توضیحات درباره سایت","<textarea name='description' id='description' class=\"px-1 TextField__textarea-df80b4 text-subtitle w-100 TextField-e58168\"></textarea>","Button-sd741",'z_999-w_1300_h_80');
        const oldEditor = tinymce.get('description');
        if (oldEditor) {
            oldEditor.remove();
        }
        SAJ('content',{},function (res){
            $('#description').val(res.content);
            tinymce.init({
                selector: "#description",
                plugins: [
                    "advlist",
                    "autolink",
                    "lists",
                    "link",
                    "image",
                    "charmap",
                    "preview",
                    "anchor",
                    "searchreplace",
                    "visualblocks",
                    "code",
                    "fullscreen",
                    "insertdatetime",
                    "media",
                    "table",
                    "emoticons",
                    "wordcount"
                ],
                toolbar: "undo redo | blocks fontfamily fontsize | bold italic underline strikethrough | forecolor backcolor | alignleft aligncenter alignright alignjustify | bullist numlist | outdent indent | link image media table | emoticons charmap | removeformat | code fullscreen preview",                custom_elements: "~inline-token",
                height: '100%',
            });
        })
    });
    $(document).on('click', '.Button-sdl78', function (e) {
        e.preventDefault();
        uikit__collections_Popup("توضیحات ثبت نام","<label class=\"uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--L7bcQ uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--normal--A6Ntt text-subtitle color-n-700  w-100\"><div class=\"uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame__input-container--D5edN uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame__input-container--textArea--qCxT1 px-2 d-flex ai-center p-2 \"><section class=\"grow-1 text-body-2-c\"><textarea name='description' class=\"px-1 TextField__textarea-df80b4 text-subtitle w-100 TextField-e58168\" rows=\"4\"></textarea></section></div></label><div class=\"mb-2  d-flex jc-between ai-center text-caption-strong color-n-500\"></div>","Button-sdl58");
    });
    $(document).on('click', '.Button-sak78', function (e) {
        e.preventDefault();
        uikit__collections_Popup("Api Key","<label class=\"uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--L7bcQ uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--normal--A6Ntt text-body-1 color-n-700 w-100\"><p class=\"mb-2 color-n-700 text-body-1 mb-2\" data-testid=\"form-label\"> Api Key :</p><div class=\"uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame__input-container--D5edN px-2 d-flex ai-center\"><section class=\"grow-1 text-body-2-c\"><input class=\"px-2 TextField__input-_5fbdd text-subtitle w-100 TextField-e58168\" type=\"text\" name=\"contact_method\"></section></div></label><input id='key' type='text' class='hidden'  value='َApiKey'>","Button-ab45");
    });
    $(document).on('click', '.Button-sakr78', function (e) {
        e.preventDefault();
        uikit__collections_Popup("Api Key","<label class=\"uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--L7bcQ uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--normal--A6Ntt text-body-1 color-n-700 w-100\"><p class=\"mb-2 color-n-700 text-body-1 mb-2\" data-testid=\"form-label\"> Api Key :</p><div class=\"uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame__input-container--D5edN px-2 d-flex ai-center\"><section class=\"grow-1 text-body-2-c\"><input class=\"px-2 TextField__input-_5fbdd text-subtitle w-100 TextField-e58168\" type=\"text\" name=\"contact_method\"></section></div></label><input id='key' type='text' class='hidden'  value='َApiKeyRubika'>","Button-ab45");
    });
    $(document).on('click', '.Button-cr97', function (e) {
        e.preventDefault();
        SAJ('connect-bot',{bot:'rubika'},function (res){
            if (res.status){
                uikit__collections_success('ربات متصل شد');
            }else{
                uikit__collections_error(res.message);
            }
        })
    });
    $(document).on('click', '.Button-cb97', function (e) {
        e.preventDefault();
        SAJ('connect-bot',{bot:'bale'},function (res){
            if (res.status){
                uikit__collections_success('ربات متصل شد');
            }else{
                uikit__collections_error(res.message);
            }
        })
    });
    $(document).on('click', '.Button-sid78', function (e) {
        e.preventDefault();
        uikit__collections_Popup("ایدی کانال یا گروه","<label class=\"uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--L7bcQ uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--normal--A6Ntt text-body-1 color-n-700 w-100\"><p class=\"mb-2 color-n-700 text-body-1 mb-2\" data-testid=\"form-label\"> ایدی کانال یا گروه :</p><div class=\"uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame__input-container--D5edN px-2 d-flex ai-center\"><section class=\"grow-1 text-body-2-c\"><input class=\"px-2 TextField__input-_5fbdd text-subtitle w-100 TextField-e58168\" type=\"text\" name=\"contact_method\"></section></div></label><input id='key' type='text' class='hidden'  value='idDomain'>","Button-ab45");
    });
    $(document).on('click', '.Button-sid85', function (e) {
        e.preventDefault();
        uikit__collections_Popup("ایدی کانال یا گروه","<label class=\"uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--L7bcQ uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--normal--A6Ntt text-body-1 color-n-700 w-100\"><p class=\"mb-2 color-n-700 text-body-1 mb-2\" data-testid=\"form-label\"> ایدی کانال یا گروه :</p><div class=\"uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame__input-container--D5edN px-2 d-flex ai-center\"><section class=\"grow-1 text-body-2-c\"><input class=\"px-2 TextField__input-_5fbdd text-subtitle w-100 TextField-e58168\" type=\"text\" name=\"contact_method\"></section></div></label><input id='key' type='text' class='hidden'  value='idDomainContact'>","Button-ab45");
    });
    $(document).on('input',"input[name='category']", function (e) {
        e.preventDefault();
        e.stopPropagation();

        const query = $(this).val().trim();
        clearTimeout(timer);

        timer = setTimeout(() => {
            const main = document.querySelector(".WorkdaySearchModal__Seach-ExCB17");
            if (query.length > 0) {
                SAJ("searchCategory",{query:query},function (res){
                    if (res.status) {
                        main.innerHTML = res.html;
                        main.classList.remove("hidden");
                        initSearch();
                    }else{
                        uikit__collections_error(res.message);
                    }
                })
            }else {
                main.classList.add("hidden");
            }
        }, 500);
    });
    $(document).on('input',"#person", function (e) {
        e.preventDefault();
        e.stopPropagation();

        const query = $(this).val().trim();
        clearTimeout(timer);

        timer = setTimeout(() => {
            const main = document.querySelector(".user");
            if (query.length > 0) {
                SAJ("person",{query:query},function (res){
                    if (res.status) {
                        main.innerHTML = res.html;
                        main.classList.remove("hidden");
                        initSearch();
                    }else{
                        uikit__collections_error(res.message);
                    }
                })
            }else {
                main.classList.add("hidden");
            }
        }, 500);
    });
    $(document).on('click',".select-user", function (e) {
        e.preventDefault();
        e.stopPropagation();
        uikit__collections_success("کاربر انتخاب شد");
        $("#person").val($(this).data("id"));
        const main = document.querySelector(".user");
        main.classList.add("hidden");
    });
    $(document).on('click', '.Button-sc54', function (e) {
        e.preventDefault();
        e.stopPropagation();
        const inputs = document.querySelectorAll('#category_c input[name="c_id[]"]');
        const ids = Array.from(inputs, el => el.value.trim()).filter(v => v !== '').join(',');
        if (ids.length <=0){
            uikit__collections_error('هنوز هیچ دسته بندی مشخص نشده');
            return false;
        }
        SAJ("Save",{key:'category',value:ids},function (res){
            if (res.status) {
                uikit__collections_success(res.message);
                closePup($(this));
            }else{
                uikit__collections_error(res.message);
            }
        })
    });
    $(document).on('click', '.Button-sd741', function (e) {
        e.preventDefault();
        e.stopPropagation();
        const description = tinyMCE.get('description').getContent();
        if (description.length <=0){
            uikit__collections_error('توضیحی وارد نشده');
            return false;
        }
        SAJ("Save",{key:'description',value:description},function (res){
            if (res.status) {
                uikit__collections_success(res.message);
                closePup($(this));
            }else{
                uikit__collections_error(res.message);
            }
        })
    });
    $(document).on('click', '.Button-sn05', function (e) {
        e.preventDefault();
        e.stopPropagation();
        const title = $("#title").val();
        const id = $("#person").val();
        if (title.length <=0){
            uikit__collections_error('سرتیتر وارد نشده');
            return false;
        }
        const description = tinyMCE.get('description').getContent();
        if (description.length <=0){
            uikit__collections_error('متن وارد نشده');
            return false;
        }
        SAJ("send-notifications",{method:'all',title:title,description:description,id:id},function (res){
            if (res.status) {
                uikit__collections_success(res.message);
                $("#title").val('');
                $("#person").val('');
                tinyMCE.get('description').setContent('');
            }else{
                uikit__collections_error(res.message);
            }
        })
    });
    $(document).on('click', '.Button-sdl58', function (e) {
        e.preventDefault();
        e.stopPropagation();
        const description = $("textarea[name=\"description\"]").val();
        if (description.length <=0){
            uikit__collections_error('توضیحی وارد نشده');
            return false;
        }
        SAJ("Save",{key:'description_register',value:description},function (res){
            if (res.status) {
                uikit__collections_success(res.message);
                closePup($(this));
            }else{
                uikit__collections_error(res.message);
            }
        })
    });
    $(document).on('change', 'input[type="checkbox"]', function () {
        const id = this.id;
        let on = this.checked;
        if (on){
            on = 1;
        }else{
            on = 0;
        }
        SAJ("Save",{key:id,value:on},function (res){
            if (res.status) {
                uikit__collections_success(res.message);
                closePup($(this));
            }else{
                uikit__collections_error(res.message);
            }
        })
    });
    $(document).on('change', '#banner', function () {
        const on = this.checked;
        if (on){
            $("#c-banner").removeClass("hidden");
        }else{
            $("#c-banner").addClass("hidden");
        }
    });
    $(document).on('click', '.Button-tb54', function (e) {
        e.preventDefault();
        uikit__collections_Popup("شماره تماس","<label class=\"uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--L7bcQ uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--normal--A6Ntt text-body-1 color-n-700 w-100\"><p class=\"mb-2 color-n-700 text-body-1 mb-2\" data-testid=\"form-label\">راه ارتباطی:</p><div class=\"uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame__input-container--D5edN px-2 d-flex ai-center\"><section class=\"grow-1 text-body-2-c\"><input class=\"px-2 TextField__input-_5fbdd text-subtitle w-100 TextField-e58168\" type=\"text\" name=\"contact_method\"></section></div></label><input id='key' type='text' class='hidden' value='tel'>","Button-ab45");
    });
    $(document).on('click', '.Button-gb45', function (e) {
        e.preventDefault();
        uikit__collections_Popup("تلگرام","<label class=\"uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--L7bcQ uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--normal--A6Ntt text-body-1 color-n-700 w-100\"><p class=\"mb-2 color-n-700 text-body-1 mb-2\" data-testid=\"form-label\">راه ارتباطی:</p><div class=\"uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame__input-container--D5edN px-2 d-flex ai-center\"><section class=\"grow-1 text-body-2-c\"><input class=\"px-2 TextField__input-_5fbdd text-subtitle w-100 TextField-e58168\" type=\"text\" name=\"contact_method\"></section></div></label><input id='key' type='text' class='hidden'  value='telegram'>","Button-ab45");
    });
    $(document).on('click', '.Button-ib45', function (e) {
        e.preventDefault();
        uikit__collections_Popup("اینستاگرام","<label class=\"uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--L7bcQ uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--normal--A6Ntt text-body-1 color-n-700 w-100\"><p class=\"mb-2 color-n-700 text-body-1 mb-2\" data-testid=\"form-label\">راه ارتباطی:</p><div class=\"uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame__input-container--D5edN px-2 d-flex ai-center\"><section class=\"grow-1 text-body-2-c\"><input class=\"px-2 TextField__input-_5fbdd text-subtitle w-100 TextField-e58168\" type=\"text\" name=\"contact_method\"></section></div></label><input id='key' type='text' class='hidden'  value='instagram'>","Button-ab45");
    });
    $(document).on('click', '.Button-sb42', function (e) {
        e.preventDefault();
        uikit__collections_Popup("واتساپ","<label class=\"uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--L7bcQ uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--normal--A6Ntt text-body-1 color-n-700 w-100\"><p class=\"mb-2 color-n-700 text-body-1 mb-2\" data-testid=\"form-label\">راه ارتباطی:</p><div class=\"uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame__input-container--D5edN px-2 d-flex ai-center\"><section class=\"grow-1 text-body-2-c\"><input class=\"px-2 TextField__input-_5fbdd text-subtitle w-100 TextField-e58168\" type=\"text\" name=\"contact_method\"></section></div></label><input id='key' type='text' class='hidden'  value='whatsapp'>","Button-ab45");
    });
    $(document).on('click', '.Button-eb65', function (e) {
        e.preventDefault();
        uikit__collections_Popup("ایمیل","<label class=\"uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--L7bcQ uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--normal--A6Ntt text-body-1 color-n-700 w-100\"><p class=\"mb-2 color-n-700 text-body-1 mb-2\" data-testid=\"form-label\">راه ارتباطی:</p><div class=\"uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame__input-container--D5edN px-2 d-flex ai-center\"><section class=\"grow-1 text-body-2-c\"><input class=\"px-2 TextField__input-_5fbdd text-subtitle w-100 TextField-e58168\" type=\"text\" name=\"contact_method\"></section></div></label><input id='key' type='text' class='hidden'  value='email'>","Button-ab45");
    });
    $(document).on('click', '.Button-ab45', function (e) {
        e.preventDefault();
        e.stopPropagation();
        const button = $(this);
        const key = $('#key').val();
        const value = $('input[name="contact_method"]').val();
        if (value.length <=0){
            uikit__collections_error('هنوز راهی را تعریف نکرده اید!');
            return false;
        }
        SAJ("Save",{key:key,value:value},function (res){
            if (res.status) {
                uikit__collections_success(res.message);
                closePup(button);
            }else{
                uikit__collections_error(res.message);
            }
        })
    });
    $(document).on('click','.styles_btn--neutralOutlined__mLWvq', function (e) {
        e.preventDefault();
        $(this).closest(".styles_btn-_mLWvq").remove();
    });
    $(document).on('click','.Button-adb65', function (e) {
        e.preventDefault();
        const div = document.createElement('div');
        div.className = 'styles_btn-_mLWvq';
        div.innerHTML = `<div class="styles_btn--neutralOutlined__mLWvq Button-dw84">
            <i class="icon-delete"></i>
        </div>
        <div><label class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--L7bcQ uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--normal--A6Ntt text-body-1 color-n-700 w-100">
            <p class="mb-2 color-n-700 text-body-1 mb-2" data-testid="form-label">لینک تبلیغات </p>
            <div class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame__input-container--D5edN px-2 d-flex ai-center">
                <section class="grow-1 text-body-2-c">
                    <input class="px-2 TextField__input-_5fbdd text-subtitle w-100 TextField-e58168" type="text" name="ads[][link]" placeholder="https://example.com"></section>
            </div>
        </label>
        <label class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--L7bcQ uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--normal--A6Ntt text-body-1 color-n-700 w-100">
            <p class="mb-2 color-n-700 text-body-1 mb-2" data-testid="form-label">عکس تبلیغات </p>
            <div style="display: flex; justify-content: space-between">
            <div class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame__input-container--D5edN px-2 d-flex ai-center" style="width: calc(100% - 70px)">
                <section class="grow-1 text-body-2-c">
                    <input class="px-2 TextField__input-_5fbdd text-subtitle w-100 TextField-e58168 adsImg" type="text" name="ads[][img]"></section>
            </div>
                <div class="giftmax-media-field Button--uai23" data-id="adsImg">اپلود</div>
            </div>
        </label>
        </div>`;
        document.querySelector('.styles_box-_dXFga').appendChild(div);
    });
    $(document).on('click','.Button-adb66', function (e) {
        e.preventDefault();
        const div = document.createElement('div');
        div.className = 'styles_btn-_mLWvq';
        div.innerHTML = `<div class="styles_btn--neutralOutlined__mLWvq Button-dw86">
            <i class="icon-delete"></i>
        </div>
        <div>
        <label class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--L7bcQ uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--normal--A6Ntt text-body-1 color-n-700 w-100">
                    <p class="mb-2 color-n-700 text-body-1 mb-2" data-testid="form-label">سوال</p>
                    <div class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame__input-container--D5edN px-2 d-flex ai-center">
                        <section class="grow-1 text-body-2-c">
                            <input class="px-2 TextField__input-_5fbdd text-subtitle w-100 TextField-e58168" type="text" name="faq[][q]"></section>
                    </div>
                </label><label class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--L7bcQ uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--normal--A6Ntt text-body-1 color-n-700 w-100">
                    <p class="mb-2 color-n-700 text-body-1 mb-2" data-testid="form-label">جواب</p>
                    <div class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame__input-container--D5edN uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame__input-container--textArea--qCxT1 px-2 d-flex ai-center p-2 ">
                        <section class="grow-1 text-body-2-c">
                            <textarea class="px-1 TextField__textarea-df80b4 text-subtitle w-100 TextField-e58168" rows="4" name="faq[][a]"></textarea>
                        </section>
                    </div>
                </label>
        </div>`;
        document.querySelector('.styles_box-_dXFga').appendChild(div);
    });

    $(document).on('click','.Button-abs65', function (e) {
        e.preventDefault();
        const div = document.createElement('div');
        div.className = 'styles_btn-_mLWvq';
        div.innerHTML = `<div class="styles_btn--neutralOutlined__mLWvq Button-dw84">
            <i class="icon-delete"></i>
        </div>
        <div>
                    <label class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--L7bcQ uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--normal--A6Ntt text-body-1 color-n-700 w-100">
                        <p class="mb-2 color-n-700 text-body-1 mb-2" data-testid="form-label"> سرتیتر </p>
                        <div class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame__input-container--D5edN px-2 d-flex ai-center">
                            <section class="grow-1 text-body-2-c">
                                <input class="px-2 TextField__input-_5fbdd text-subtitle w-100 TextField-e58168" type="text" name="slider[][title]" placeholder="بازی جدید زیادش خوبه"></section>
                        </div>
                    </label>
                    <label class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--L7bcQ uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--normal--A6Ntt text-body-1 color-n-700 w-100">
                        <p class="mb-2 color-n-700 text-body-1 mb-2" data-testid="form-label">توضیحات مختصر </p>
                        <div class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame__input-container--D5edN px-2 d-flex ai-center">
                            <section class="grow-1 text-body-2-c">
                                <input class="px-2 TextField__input-_5fbdd text-subtitle w-100 TextField-e58168" type="text" name="slider[][description]"></section>
                        </div>
                    </label>
                    <label class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--L7bcQ uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--normal--A6Ntt text-body-1 color-n-700 w-100">
                        <p class="mb-2 color-n-700 text-body-1 mb-2" data-testid="form-label"> متن دکمه </p>
                        <div class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame__input-container--D5edN px-2 d-flex ai-center">
                            <section class="grow-1 text-body-2-c">
                                <input class="px-2 TextField__input-_5fbdd text-subtitle w-100 TextField-e58168" type="text" name="slider[][button][title]"></section>
                        </div>
                    </label>
                    <label class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--L7bcQ uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--normal--A6Ntt text-body-1 color-n-700 w-100">
                        <p class="mb-2 color-n-700 text-body-1 mb-2" data-testid="form-label"> آدرس دکمه </p>
                        <div class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame__input-container--D5edN px-2 d-flex ai-center">
                            <section class="grow-1 text-body-2-c">
                                <input class="px-2 TextField__input-_5fbdd text-subtitle w-100 TextField-e58168" type="text" name="slider[][button][link]"></section>
                        </div>
                    </label>
                    <label class="flex uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--L7bcQ uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--normal--A6Ntt text-body-1 color-n-700 w-100">
                        <p class="mb-2 color-n-700 text-body-1 mb-2" data-testid="form-label"> رنگ اول </p>
                        <div style="width: 9%;">
                            <input class="px-2 TextField__input-_5fbdd text-subtitle w-100 TextField-e58168" type="color" name="slider[][color][one]">
                        </div>
                    </label>
                    <label class="flex uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--L7bcQ uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--normal--A6Ntt text-body-1 color-n-700 w-100">
                        <p class="mb-2 color-n-700 text-body-1 mb-2" data-testid="form-label"> رنگ دوم </p>
                        <div style="width: 9%;">
                            <input class="px-2 TextField__input-_5fbdd text-subtitle w-100 TextField-e58168" type="color" name="slider[][color][two]">
                        </div>
                    </label>
                    <label class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--L7bcQ uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--normal--A6Ntt text-body-1 color-n-700 w-100">
                        <p class="mb-2 color-n-700 text-body-1 mb-2" data-testid="form-label">عکس  </p>
                        <div style="display: flex; justify-content: space-between">
                            <div class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame__input-container--D5edN px-2 d-flex ai-center" style="width: calc(100% - 70px)">
                                <section class="grow-1 text-body-2-c">
                                    <input class="px-2 TextField__input-_5fbdd text-subtitle w-100 TextField-e58168 SliderImg" type="text" name="slider[][img]"></section>
                            </div>
                            <div class="Button--uai23" data-id="SliderImg">اپلود</div>
                        </div>
                    </label>
                </div>`;
        document.querySelector('.styles_box-_dXFga').appendChild(div);
    });
    let giftmaxUploader;
    $(document).on('click','.Button--uai23', function (e) {
        e.preventDefault();
        e.stopPropagation();

        const $button = $(this);               // دکمهٔ جاری
        const inputClass = $button.data('id'); // مثلاً 'adsImg'

        // اگر هنوز آبجکت wp.media ساخته نشده بود، ساختن آن
        if (!giftmaxUploader) {
            giftmaxUploader = wp.media({
                title: 'انتخاب تصویر',
                button: { text: 'انتخاب' },
                multiple: false
            });
        }

        /* ----------- تعیین هدف فیلد ----------------- */
        // فیلد متن مربوط به این ردیف (با توجه به کلاس inputClass)
        const $input = $button.closest('.styles_btn-_mLWvq').find('.' + inputClass);
        giftmaxUploader.inputField = $input;   // نگه‌داشتن در آبجکت

        /* ----------- هندلر select ----------------- */
        // از off('select') استفاده می‌کنیم تا هندلر قبلی پاک شود
        giftmaxUploader.off('select').on('select', function () {
            const attachment = giftmaxUploader.state()
                .get('selection')
                .first()
                .toJSON();

            // مقدار URL را در فیلد هدف قرار می‌دهیم
            giftmaxUploader.inputField.val(attachment.url);
        });

        // باز کردن فایل‌بار
        giftmaxUploader.open();
    });
    $(document).on('click','.Button-sa45', function (e) {
        const linkInputs = document.querySelectorAll('input[name="ads[][link]"]');
        const imgInputs  = document.querySelectorAll('input[name="ads[][img]"]');

        const data = [];
        linkInputs.forEach((linkInp, idx) => {
            const linkVal = linkInp.value.trim();
            const imgVal  = imgInputs[idx] ? imgInputs[idx].value.trim() : '';
            if (linkVal || imgVal) {
                data.push({ link: linkVal, img: imgVal });
            }
        });
        SAJ('ads',{data:data},function (res){
            if (res.status) {
                uikit__collections_success("باموفقیت ثبت شد");
            }
        },'v3')
    });
    $(document).on('click','.Button-sa46', function (e) {
        const question = document.querySelectorAll('input[name="faq[][q]"]');
        const Answer  = document.querySelectorAll('textarea[name="faq[][a]"]');

        const data = [];
        question.forEach((a, n) => {
            const question = a.value.trim();
            const answer  = Answer[n] ? Answer[n].value.trim() : '';
            if (question || answer) {
                data.push({ question: question, answer: answer });
            }
        });
        SAJ('faq',{data:data},function (res){
            if (res.status) {
                uikit__collections_success("باموفقیت ثبت شد");
            }
        },'v3')
    });
    $(document).on('click','.Button-ss05', function (e) {
        const titleInputs = document.querySelectorAll('input[name="slider[][title]"]');
        const description = document.querySelectorAll('input[name="slider[][description]"]');
        const buttonTitle = document.querySelectorAll('input[name="slider[][button][title]"]');
        const buttonLink = document.querySelectorAll('input[name="slider[][button][link]"]');
        const colorOne = document.querySelectorAll('input[name="slider[][color][one]"]');
        const colorTwo = document.querySelectorAll('input[name="slider[][color][two]"]');
        const imgInputs  = document.querySelectorAll('input[name="slider[][img]"]');

        const data = [];
        titleInputs.forEach((linkInp, idx) => {
            const titleVal = linkInp.value.trim();
            const descriptionVal  = description[idx] ? description[idx].value.trim() : '';
            const buttonTitleVal  = buttonTitle[idx] ? buttonTitle[idx].value.trim() : '';
            const buttonLinkVal  = buttonLink[idx] ? buttonLink[idx].value.trim() : '';
            const colorOneVal  = colorOne[idx] ? colorOne[idx].value.trim() : '';
            const colorTwoVal  = colorTwo[idx] ? colorTwo[idx].value.trim() : '';
            const imgVal  = imgInputs[idx] ? imgInputs[idx].value.trim() : '';
            data.push({ title: titleVal, description: descriptionVal, button: {'title' : buttonTitleVal, 'link' : buttonLinkVal}, color: {'one' : colorOneVal, 'two' : colorTwoVal}, img: imgVal });
        });
        SAJ('slider',{data:data},function (res){
            if (res.status) {
                uikit__collections_success("باموفقیت ثبت شد");
            }
        },'v3')
    });
    $(document).on('click','.Button-scpw4', function (e) {
        e.preventDefault();
        e.stopPropagation();
        uikit__collections_Popup("امتیاز","<label class=\"uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--L7bcQ uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--normal--A6Ntt text-body-1 color-n-700 w-100\"><p class=\"mb-2 color-n-700 text-body-1 mb-2\" data-testid=\"form-label\">امتیاز:</p><div class=\"uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame__input-container--D5edN px-2 d-flex ai-center\"><section class=\"grow-1 text-body-2-c\"><input class=\"px-2 TextField__input-_5fbdd text-subtitle w-100 TextField-e58168\" type=\"text\" name=\"points\"></section></div></label><label class=\"uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--L7bcQ uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--normal--A6Ntt text-body-1 color-n-700 w-100\"><p class=\"mb-2 color-n-700 text-body-1 mb-2\" data-testid=\"form-label\">معادل به تومان</p><div class=\"uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame__input-container--D5edN px-2 d-flex ai-center\"><section class=\"grow-1 text-body-2-c\"><input class=\"px-2 TextField__input-_5fbdd text-subtitle w-100 TextField-e58168\" type=\"text\" name=\"toman\"></section></div></label>","Button-stp12");
        const points = document.querySelector('input[name="points"]');
        const toman = document.querySelector('input[name="toman"]');
        points.addEventListener('input', e => e.target.value = e.target.value.replace(/\D/g,'').replace(/\B(?=(\d{3})+(?!\d))/g, ','));
        toman.addEventListener('input', e => e.target.value = e.target.value.replace(/\D/g,'').replace(/\B(?=(\d{3})+(?!\d))/g, ','));

    });
    $(document).on('click','.Button-so42', function (e) {
        e.preventDefault();
        e.stopPropagation();
        uikit__collections_Popup("سفارش مشکوک","<label class=\"uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--L7bcQ uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--normal--A6Ntt text-body-1 color-n-700 w-100\"><p class=\"mb-2 color-n-700 text-body-1 mb-2\" data-testid=\"form-label\">دقیقه:</p><div class=\"uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame__input-container--D5edN px-2 d-flex ai-center\"><section class=\"grow-1 text-body-2-c\"><input class=\"px-2 TextField__input-_5fbdd text-subtitle w-100 TextField-e58168\" type=\"text\" name=\"minutes\"></section></div></label><label class=\"uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--L7bcQ uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--normal--A6Ntt text-body-1 color-n-700 w-100\"><p class=\"mb-2 color-n-700 text-body-1 mb-2\" data-testid=\"form-label\">حداقل مبلغ به تومان</p><div class=\"uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame__input-container--D5edN px-2 d-flex ai-center\"><section class=\"grow-1 text-body-2-c\"><input class=\"px-2 TextField__input-_5fbdd text-subtitle w-100 TextField-e58168\" type=\"text\" name=\"min_total\"></section></div></label>","Button-sso42");
        const minutes = document.querySelector('input[name="minutes"]');
        const minTotal = document.querySelector('input[name="min_total"]');
        minutes.addEventListener('input', e => e.target.value = e.target.value.replace(/\D/g,'').replace(/\B(?=(\d{3})+(?!\d))/g, ','));
        minTotal.addEventListener('input', e => e.target.value = e.target.value.replace(/\D/g,'').replace(/\B(?=(\d{3})+(?!\d))/g, ','));

    });
    $(document).on('click','.Button-stp12', function (e) {
        e.preventDefault();
        e.stopPropagation();
        let points = document.querySelector('input[name="points"]').value;
        let toman = document.querySelector('input[name="toman"]').value;
        points = points.replace(/,/g, '');
        toman = toman.replace(/,/g, '');
        if (toman.length <= 0 || points.length <= 0) {
            uikit__collections_error("روردی ها کامل نیستند!");
            return;
        }
        const data = [];
        data.push({ points: points, toman: toman});

        SAJ("stp",{data:data},function (res){
            if (res.status) {
                uikit__collections_success("باموفقیت ثبت شد");
            }else{
                uikit__collections_error(res.message);
            }
        })
    });
    $(document).on('click','.Button-sso42', function (e) {
        e.preventDefault();
        e.stopPropagation();
        let minutes = document.querySelector('input[name="minutes"]').value;
        let minTotal = document.querySelector('input[name="min_total"]').value;
        minutes = minutes.replace(/,/g, '');
        minTotal = minTotal.replace(/,/g, '');
        if (minTotal.length <= 0 || minutes.length <= 0) {
            uikit__collections_error("روردی ها کامل نیستند!");
            return;
        }
        const data = [];
        data.push({ minutes: minutes, minTotal: minTotal});

        SAJ("sso",{data:data},function (res){
            if (res.status) {
                uikit__collections_success("باموفقیت ثبت شد");
            }else{
                uikit__collections_error(res.message);
            }
        })
    });
    $(document).on('click','.Button-sn45', function (e) {
        const linkInputs = document.querySelectorAll('input[name="notifications[][link]"]');
        const imgInputsd  = document.querySelectorAll('input[name="notifications[][img][d]"]');
        const imgInputsm  = document.querySelectorAll('input[name="notifications[][img][m]"]');

        const data = [];
        linkInputs.forEach((linkInp, idx) => {
            const linkVal = linkInp.value.trim();
            const m  = imgInputsm[idx] ? imgInputsm[idx].value.trim() : '';
            const d  = imgInputsd[idx] ? imgInputsd[idx].value.trim() : '';
            if (linkVal || imgVal) {
                data.push({ link: linkVal, img: {m: m, d: d} });
            }
        });
        SAJ('notifications',{data:data},function (res){
            if (res.status) {
                uikit__collections_success("باموفقیت ثبت شد");
            }
        },'v3')
    });
    $(document).on('click', '.Button-sl21', function (e) {
        e.preventDefault();
        uikit__collections_Popup("جستجوی لایسنس","<label class=\"uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--L7bcQ uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--normal--A6Ntt text-body-1 color-n-700 w-100\"><p class=\"mb-2 color-n-700 text-body-1 mb-2\" data-testid=\"form-label\"> کد لایسنس را وارد کنید:</p><div class=\"uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame__input-container--D5edN px-2 d-flex ai-center\"><section class=\"grow-1 text-body-2-c\"><input class=\"px-2 TextField__input-_5fbdd text-subtitle w-100 TextField-e58168\" type=\"text\" id=\"searchLicense\"></section></div></label><div id='html' style=\" margin-top: 10px; \"></div>","",'w-\[700px\]',false);
    });
    $(document).on('input','#searchLicense', function() {
        const keyword = this.value.trim();
        if (keyword.length <= 0) {
            uikit__collections_error("چیزی وارد نکردید");
            return false;
        }
        setTimeout(function (){
            SAJ("searchLicense",{keyword:keyword},function (res){
                if (res.status) {
                   $("#html").html(res.html);
                }else{
                    uikit__collections_error("مشکلی رخ دادن مجدد تلاش کنید!")
                }
            });
        },400)
    })
    $(document).on('click','.Button-iu64', function() {
        const number = $(this).data('number');
        SAJ("searchUser",{keyword:number},function (res){
            if (res.status) {
                uikit__collections_Popup("اطلاعات کاربر",res.html,"",'w-\[700px\] infoUser',false);
            }else{
                uikit__collections_error("مشکلی رخ دادن مجدد تلاش کنید!")
            }
        });
    })
    $(document).on('click', '.Button-pu47', function (e) {
        e.preventDefault();
        uikit__collections_Popup("جستجوی کاربران","<label class=\"uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--L7bcQ uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--normal--A6Ntt text-body-1 color-n-700 w-100\"><p class=\"mb-2 color-n-700 text-body-1 mb-2\" data-testid=\"form-label\">کد ملی یا شماره موبایل را وارد کن:</p><div class=\"uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame__input-container--D5edN px-2 d-flex ai-center\"><section class=\"grow-1 text-body-2-c\"><input class=\"px-2 TextField__input-_5fbdd text-subtitle w-100 TextField-e58168\" type=\"text\" id=\"searchUser\"></section></div></label><div id='html' style=\" margin-top: 10px; \"></div>","",'w-\[700px\]',false);
    });
    $(document).on('input','#searchUser', function() {
        const keyword = this.value.trim();
        if (keyword.length <= 0) {
            uikit__collections_error("چیزی وارد نکردید");
            return false;
        }
        setTimeout(function (){
            SAJ("searchUser",{keyword:keyword},function (res){
                if (res.status) {
                   $("#html").html(res.html);
                }else{
                    uikit__collections_error(res.message);
                }
            });
        },400)
    })
    $(document).on('click', '.Button-drt57', function (e) {
        e.preventDefault();
        uikit__collections_Popup("جستجوی کاربران","<label class=\"uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--L7bcQ uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--normal--A6Ntt text-body-1 color-n-700 w-100\"><p class=\"mb-2 color-n-700 text-body-1 mb-2\" data-testid=\"form-label\">کد ملی یا شماره موبایل را وارد کن:</p><div class=\"uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame__input-container--D5edN px-2 d-flex ai-center\"><section class=\"grow-1 text-body-2-c\"><input class=\"px-2 TextField__input-_5fbdd text-subtitle w-100 TextField-e58168\" type=\"text\" id=\"BsearchUser\"></section></div></label><div id='html' style=\" margin-top: 10px; \"></div>","",'',false);
    });
    $(document).on('click', '.Button-swu64', function (e) {
        e.preventDefault();
        uikit__collections_Popup("لیست کیف پول","<div id='html'></div>","",'w-800',false);
        SAJ("list-wallet",{},function (res){
            if (res.status) {
                $("#html").html(res.html);
            }else{
                uikit__collections_error(res.message);
            }
        });
    });
    $(document).on('click', '.Button-sln89', function (e) {
        e.preventDefault();
        const id = $(this).data('id');
        uikit__collections_Popup("لیست شماره های این لیست ","<div id='html'></div>","",'',false);
        SAJ("number-list",{id:id},function (res){
            if (res.status) {
                $("#html").html(res.html);
            }else{
                uikit__collections_error(res.message);
            }
        });
    });
    $(document).on('click','.Button-suw45', function() {
        const number = $(this).data('number');
        document.querySelector(".ModalComponent__content-XqD1rL.ModalComponent__animation-JkgpfL.ModalComponent__content--desktop-o5IbOt.ModalComponent__content--border-md-4G9biy.overflow-auto.w-800")?.classList.remove("w-800");
        SAJ("searchUser",{keyword:number,method:2},function (res){
            if (res.status) {
                $("#html").html(res.html);
                const input = document.querySelector('input[name="balance"]');
                input.addEventListener('input', e => e.target.value = e.target.value.replace(/\D/g,'').replace(/\B(?=(\d{3})+(?!\d))/g, ','));
            }else{
                uikit__collections_error(res.message);
            }
        });
    })
    $(document).on('input','#BsearchUser', function() {
        const keyword = this.value.trim();
        if (keyword.length <= 0) {
            uikit__collections_error("چیزی وارد نکردید");
            return false;
        }
        setTimeout(function (){
            SAJ("searchUser",{keyword:keyword,method:2},function (res){
                if (res.status) {
                   $("#html").html(res.html);
                    const input = document.querySelector('input[name="balance"]');
                    input.addEventListener('input', e => e.target.value = e.target.value.replace(/\D/g,'').replace(/\B(?=(\d{3})+(?!\d))/g, ','));
                }else{
                    uikit__collections_error(res.message);
                }
            });
        },400)
    })
    $(document).on('click', '.Button-bw41', function (e) {
        e.preventDefault();
        const button = $(this);
        const input = document.querySelector('input[name="balance"]').value;
        const userId = document.querySelector('input[name="userId"]').value;
        var balance = input.replace(/,/g, '');
        if (balance.length <= 0 || userId.length <= 0) {
            uikit__collections_error("ورودی را کامل کنید");
            return false;
        }
        SAJ("balance",{balance:balance,userId:userId},function (res){
            if (res.status) {
                if (res.sms){
                    uikit__collections_error(res.sms);
                }
                closePup(button);
                uikit__collections_success("افزایش موجودی با موفقیت انجام شد");
            }else{
                uikit__collections_error(res.message);
            }
        });
    });
    $(document).on('click', '.Button-bu12', function (e) {
        e.preventDefault();
        const id = $(this).data('id');
        if (id.length <= 0) {
            uikit__collections_error("ایدی انتخاب نشد");
            return false;
        }
        SAJ("block",{id:id},function (res){
            if (res.status) {
                if (res.sms){
                    uikit__collections_error(res.sms);
                }
                uikit__collections_success("عملیات بلاکی انجام شد");
            }else{
                uikit__collections_error(res.message);
            }
        });
    });
    $(document).on('click', '.Button-bc57', function (e) {
        e.preventDefault();
        uikit__collections_Popup("اطلاعات کارت","<label class=\"uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--L7bcQ uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--normal--A6Ntt text-body-1 color-n-700 w-100\"><p class=\"mb-2 color-n-700 text-body-1 mb-2\" data-testid=\"form-label\">شماره کارت را وارد کن:</p><div class=\"uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame__input-container--D5edN px-2 d-flex ai-center\"><section class=\"grow-1 text-body-2-c\"><input class=\"px-2 TextField__input-_5fbdd text-subtitle w-100 TextField-e58168\" type=\"text\" id=\"searchCart\"></section></div></label><div id='html' style=\" margin-top: 10px; \"></div>","",'w-\[655px\]',false);
    });
    $(document).on('input','#searchCart', function() {
        const keyword = this.value.trim();
        if (keyword.length <= 0) {
            uikit__collections_error("چیزی وارد نکردید");
            return false;
        }
        setTimeout(function (){
            SAJ("searchCart",{keyword:keyword},function (res){
                if (res.status) {
                   $("#html").html(res.html);
                }else{
                    uikit__collections_error(res.message);
                }
            });
        },400)
    })
    $(document).on('click','.Button-fw64', function() {
        const id = $(this).data('id');
        SAJ("CartUser",{id:id},function (res){
            if (res.status) {
                uikit__collections_Popup("کارت های کاربر",res.html,"",'w-\[700px\] cartUser',false);
            }else{
                uikit__collections_error("مشکلی رخ دادن مجدد تلاش کنید!")
            }
        });
    })
    $(document).on('click','.Button-giu18', function() {
        uikit__collections_success("دریافت اطلاعات...");
        SAJ("GetUser",{},function (res){
            if (res.status) {
                uikit__collections_success("ساخت فایل txt ...");
                const fileContent = res.users.join('\n');
                const blob = new Blob([fileContent], {type: 'text/plain;charset=utf-8'});
                const url = URL.createObjectURL(blob);
                window.open(url, '_blank');
                URL.revokeObjectURL(url);
            }else{
                uikit__collections_error("مشکلی رخ دادن مجدد تلاش کنید!")
            }
        });
    });
    $(document).on('click','.Button-ts47', function() {
        SAJ("send-sms",{method:'test',content:$("textarea[name='description']").val()},function (res){
            if (res.status) {
                uikit__collections_success("پیامک ارسال شد");
            }else{
                uikit__collections_error(res.message)
            }
        });
    });
    $(document).on('click','.Button-ssa54', function() {
        uikit__collections_success("بسته به تعداد کاربران ممکنه این درخواست زمان ببره تا زمان مشاهده شدن پیغام بعدی منتظر بمانید");
        SAJ("send-sms",{method:'all',content:$("textarea[name='description']").val(),title:$("#title").val(),time:$("#time").val(),listblock:$("[name='listblock']").val(),listwhite:$("[name='listwhite']").val()},function (res){
            if (res.status) {
                uikit__collections_success("پیامک ها ارسال شد");
                $("textarea[name='description']").val('');
                $("#title").val('');
                $("#time").val('');
                $("[name='listblock']").val('');
                $("[name='listwhite']").val('');
            }else{
                uikit__collections_error(res.message)
            }
        });
    });
    $(document).on('click','.Button-sln10', function() {
        SAJ("add-list",{title:$("input[name='list[title]']").val(),numbers:$("textarea[name='list[numbers]']").val()},function (res){
            if (res.status) {
                uikit__collections_success("اضافه شد");
                $("input[name='list[title]']").val('');
                $("textarea[name='list[numbers]']").val('');
                if (res.html){
                    $("#list-number").html(res.html);
                }
            }else{
                uikit__collections_error(res.message)
            }
        });
    });
    $(document).on('click','.Button-dl54', function() {
        const id = $(this).data('id');
        const button = $(this);
        SAJ("delete-list-sms",{id:id},function (res){
            if (res.status) {
                uikit__collections_success("حذف شد");
                button.closest('.c-bills__body').remove();
            }else{
                uikit__collections_error(res.message)
            }
        });
    });
    $(document).on('click','.Button-dsc14', function() {
        const id = $(this).data('id');
        const button = $(this);
        SAJ("delete-history-sms",{id:id},function (res){
            if (res.status) {
                uikit__collections_success("حذف شد");
                button.closest('.c-bills__body').remove();
            }else{
                uikit__collections_error(res.message)
            }
        });
    });
    $(document).on('click','.Button-dsc56',function (e){
        e.preventDefault();
        e.stopPropagation();
        var id  = $(this).data('id');
        var pup = document.querySelector(".pup");
        var modal = document.querySelector(".ar-modal");
        pup.style = "opacity: 1; visibility: visible;";
        document.body.style = "overflow: hidden;";
        modal.style = "opacity: 1; visibility: visible;";
        SAJ('details-sms',{id:id},function (res){
            jQuery(".ar-modal__content").html(res);
        },'v3')
    })
    $(document).on('click','.ar-modal__close',function (){
        var pup = document.querySelector(".pup");
        var modal = document.querySelector(".ar-modal");
        pup.style = "opacity: 0; visibility: hidden;";
        document.body.style = "";
        modal.style = "opacity: 0; visibility: hidden;";
    })
    let searchTimer;
    $(document).on('input','#listwhite',function (){
        clearTimeout(searchTimer);
        const keyword = $("#listwhite").val();

        searchTimer = setTimeout(function(){
            SAJ('search',{key:keyword},function (res){
                if (res.status){
                    const div = document.querySelector(".listwhite_search");
                    div.classList.remove('hidden');
                    div.innerHTML = res.html;
                }
            })
        },500)
    });
    $(document).on('input','#listblock',function (){
        clearTimeout(searchTimer);
        const keyword = $("#listblock").val();

        searchTimer = setTimeout(function(){
            SAJ('search',{key:keyword},function (res){
                if (res.status){
                    const div = document.querySelector(".listblock_search");
                    div.classList.remove('hidden');
                    div.innerHTML = res.html;
                }
            })
        },500)
    });
    $(document).on('click','.Button-swl64',function (e){
        e.preventDefault();
        if ($(this).closest(".listwhite_search").length) {
            $("#listwhite").val($(this).data('id'));
            const div = document.querySelector(".listwhite_search");
            div.classList.add('hidden');
        }else{
            $("#listblock").val($(this).data('id'));
            const div = document.querySelector(".listblock_search");
            div.classList.add('hidden');
        }
    });
    $(document).on('click','.Button-sf56',function (e){
        e.preventDefault();
        const id = $(this).data('id');
        SAJ('send',{id:id,method:'failed',time:$("#d-time").val()},function (res){
            if (res.status) {
                uikit__collections_success("پیام ها ارسال شد");
                var pup = document.querySelector(".pup");
                var modal = document.querySelector(".ar-modal");
                pup.style = "opacity: 0; visibility: hidden;";
                document.body.style = "";
                modal.style = "opacity: 0; visibility: hidden;";
            }else{
                uikit__collections_error(res.message);
            }
        })
    });
    $(document).on('click','.Button-ss94',function (e){
        e.preventDefault();
        const id = $(this).data('id');
        SAJ('send',{id:id,method:'sent',time:$("#d-time").val()},function (res){
            if (res.status) {
                uikit__collections_success("پیام ها ارسال شد");
                var pup = document.querySelector(".pup");
                var modal = document.querySelector(".ar-modal");
                pup.style = "opacity: 0; visibility: hidden;";
                document.body.style = "";
                modal.style = "opacity: 0; visibility: hidden;";
            }else{
                uikit__collections_error(res.message);
            }
        })
    });
    $(document).on('click','.Button-sa64',function (e){
        e.preventDefault();
        const id = $(this).data('id');
        SAJ('send',{id:id,method:'all',time:$("#d-time").val()},function (res){
            if (res.status) {
                uikit__collections_success("پیام ها ارسال شد");
                var pup = document.querySelector(".pup");
                var modal = document.querySelector(".ar-modal");
                pup.style = "opacity: 0; visibility: hidden;";
                document.body.style = "";
                modal.style = "opacity: 0; visibility: hidden;";
            }else{
                uikit__collections_error(res.message);
            }
        })
    });
    $(document).on('click','.Button-sn67', function() {
        const title = $("#notif-title").val();
        const white = $("[name='notif-white']").val();
        const block = $("[name='notif-block']").val();
        if (white.length <=0 && block.length <=0){
            uikit__collections_error('برای ارسال انبوه باید حدقل یکی لیست ها پر باشه');
            return false;
        }
        const description = tinyMCE.get('notif-description').getContent();
        if (description.length <=0){
            uikit__collections_error('متن وارد نشده');
            return false;
        }
        uikit__collections_success("بسته به تعداد کاربران ممکنه این درخواست زمان ببره تا زمان مشاهده شدن پیغام بعدی منتظر بمانید");
        SAJ("send-notifications",{method:'mass',title:title,description:description,white:white,block:block},function (res){
            if (res.status) {
                uikit__collections_success(res.message);
                $("#notif-title").val('');
                $("[name='notif-white']").val('');
                $("[name='notif-block']").val('');
                tinyMCE.get('notif-description').setContent('');
            }else{
                uikit__collections_error(res.message);
            }
        })
    });
    $(document).on('input','#searchUserWallet', function() {
        const keyword = this.value.trim();
        if (keyword.length <= 0) {
            uikit__collections_error("چیزی وارد نکردید");
            return false;
        }
        setTimeout(function (){
            SAJ("search-user-wallet",{keyword:keyword},function (res){
                if (res.status) {
                    $("#html-js").html(res.html);
                }else{
                    uikit__collections_error(res.message);
                }
            });
        },400)
    })
})