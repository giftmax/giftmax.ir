var $ = jQuery;
(function ($) {
    window.uikit__collections_error = function (message) {
        const container = document.querySelector("#popper-root #snackbar-container");
        const div = document.createElement('div');
        div.className = "Snackbar__root-_963b0 Snackbar__bg--error-_533ca d-flex mb-2 p-4 jc-start flex-column Snackbar__root--open-_126cb";
        div.style = "opacity: 1; transform: translateY(100px);"
        div.innerHTML = `<div class="color-000 text-body-1 align-center">${message}</div>`
        container.appendChild(div);
        setTimeout(function () {
            div.style = "opacity: 1; transform: translateY(0px);"
        }, 10);
        setTimeout(function () {
            div.style = "opacity: 0; transform: translateY(100px);"
        }, 6000);
        setTimeout(function () {
            div.remove();
        }, 7000);
    }
    window.uikit__collections_success = function (message) {
        const container = document.querySelector("#popper-root #snackbar-container");
        const div = document.createElement('div');
        div.className = "Snackbar__root-_963b0 Snackbar__bg--success-UqXMB3 d-flex mb-2 p-4 jc-start flex-column Snackbar__root--open-_126cb";
        div.style="opacity: 1; transform: translateY(100px);"
        div.innerHTML = `<div class="color-000 text-body-1 align-center">${message}</div>`
        container.appendChild(div);
        setTimeout(function() {
            div.style="opacity: 1; transform: translateY(0px);"
        }, 10);
        setTimeout(function() {
            div.style="opacity: 0; transform: translateY(100px);"
        }, 6000);
        setTimeout(function() {
            div.remove();
        }, 7000);
    }
    window.SAJ = function (url='', dataAjax = {},callback) {
        const ajaxOptions = {
            url: `${wpApiSettingsGiftMax.root}api/v3/${url}`,
            method: 'POST',
            dataType: 'json',
            data: dataAjax,
            beforeSend: function (xhr) {
                xhr.setRequestHeader('X-WP-Nonce', wpApiSettingsGiftMax.nonce);
            },
            success: function (response) {
                if (typeof callback === 'function') {
                    callback(response);
                }
            },
            error: function (jqXHR, exception) {
                if (jqXHR.status === 0) {
                    uikit__collections_error('Not connect.\n Verify Network.');
                } else if (jqXHR.status == 404) {
                    uikit__collections_error('Requested page not found. [404]');
                } else if (jqXHR.status == 500) {
                    uikit__collections_error('Internal Server Error [500].');
                } else if (exception === 'parsererror') {
                    uikit__collections_error('Requested JSON parse failed.');
                    uikit__collections_error(jqXHR.message);
                } else if (exception === 'timeout') {
                    uikit__collections_error('Time out error.');
                } else if (exception === 'abort') {
                    uikit__collections_error('Ajax request aborted.');
                } else {
                    uikit__collections_error('Uncaught Error.\n' + jqXHR.message);
                }
            }
        };
        $.ajax(ajaxOptions);
    }
})(jQuery);

$(function (){
    $(document).on('click','.Button-df45',function (e){
        e.preventDefault();
        e.stopPropagation();
        var id  = $(this).data('id');
        var pup = document.querySelector(".pup");
        var modal = document.querySelector(".ar-modal");
        pup.style = "opacity: 1; visibility: visible;";
        document.body.style = "overflow: hidden;";
        modal.style = "opacity: 1; visibility: visible;";
        SAJ('verify',{id:id},function (res){
            jQuery(".ar-modal__content").html(res);
        },'v3')
    })
    $(document).on('click','.ar-modal__close',function (){
        var pup = document.querySelector(".pup");
        var modal = document.querySelector(".ar-modal");
        pup.style = "opacity: 0; visibility: hidden;";
        document.body.style = "";
        modal.style = "opacity: 0; visibility: hidden;";
    })
    $(document).on('change', 'input[type="checkbox"]', function () {
        const id = $(this).attr('data-id');
        document.querySelector(`#textarea_v_${id}`).classList.toggle("hidden");
    });
    $(document).on('click', '.Button-sd87', function () {
        var id = $(this).data('id');
        var checked = $(`#checkbox_${id}`).prop('checked');
        if (!checked){
            var textarea = $(`#textarea_v_${id} textarea`).val();
            if (textarea.length == 0){
                uikit__collections_error("دلیل رد کردن را وارد کنید");
                return false;
            }
            SAJ('StoryVerify',{id:id,checked:checked,text:textarea},function (res){
                if (res.status){
                    uikit__collections_success("با موفقیت ثبت شد");
                    var pup = document.querySelector(".pup");
                    var modal = document.querySelector(".ar-modal");
                    pup.style = "opacity: 0; visibility: hidden;";
                    document.body.style = "";
                    modal.style = "opacity: 0; visibility: hidden;";
                }else{
                    uikit__collections_error("مشکلی پیش آمده");
                }
            },'v3')
        }else{
            SAJ('StoryVerify',{id:id,checked:checked},function (res){
                if (res.status){
                    uikit__collections_success("با موفقیت ثبت شد");
                    var pup = document.querySelector(".pup");
                    var modal = document.querySelector(".ar-modal");
                    pup.style = "opacity: 0; visibility: hidden;";
                    document.body.style = "";
                    modal.style = "opacity: 0; visibility: hidden;";
                }else{
                    uikit__collections_error("مشکلی پیش آمده");
                }
            },'v3')
        }
    });
})