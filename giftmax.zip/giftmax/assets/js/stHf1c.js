var $ = jQuery;
(function ($) {
    'use strict';
    window.uikit__collections_error = function (message) {
        alert(message);
    }
    window.uikit__collections_success = function (message) {
        alert(message);
    }

    window.SAJ = function (url='', dataAjax = {},callback) {
        const ajaxOptions = {
            url: `${wpApiSettingsGiftMax.root}api/v3/${url}`,
            method: 'POST',
            dataType: 'json',
            data: dataAjax,
            beforeSend: function (xhr) {
                xhr.setRequestHeader('X-WP-Nonce', wpApiSettingsGiftMax.nonce);
            },
            success: function (response) {
                if (typeof callback === 'function') {
                    callback(response);
                }
            },
            error: function (jqXHR, exception) {
                if (jqXHR.status === 0) {
                    uikit__collections_error('اینترنت شما قطع شده است!');
                } else if (jqXHR.status == 404) {
                    uikit__collections_error('Requested page not found. [404]');
                } else if (jqXHR.status == 500) {
                    uikit__collections_error('Internal Server Error [500].');
                } else if (exception === 'parsererror') {
                    uikit__collections_error('Requested JSON parse failed.');
                    uikit__collections_error(jqXHR.message);
                } else if (exception === 'timeout') {
                    uikit__collections_error('Time out error.');
                } else if (exception === 'abort') {
                    uikit__collections_error('Ajax request aborted.');
                } else {
                    uikit__collections_error('Uncaught Error.\n' + jqXHR.message);
                }
            }
        };
        $.ajax(ajaxOptions);
    }
})(jQuery);
$(function (){
    $(document).on('change','#w-text_custom',function (){
        const w = $(this).is(':checked') ? 1 : 0;
        if (w){
            document.querySelector("#text_custom").classList.toggle('hidden');
        }else{
            document.querySelector("#text_custom").classList.toggle('hidden');
        }
    });
    $(document).on('change','#w-send',function (){
        const w = $(this).is(':checked') ? 1 : 0;
        if (w){
            document.querySelector("#couponBox").classList.toggle('hidden');
        }else{
            document.querySelector("#couponBox").classList.toggle('hidden');
        }
    });
    $(document).on('change','#block-s',function (){
        const w = $(this).is(':checked') ? 1 : 0;
        if (w){
            document.querySelector("#w-block").classList.toggle('hidden');
        }else{
            document.querySelector("#w-block").classList.toggle('hidden');
        }
    });
    $(document).on('change','#white-s',function (){
        const w = $(this).is(':checked') ? 1 : 0;
        if (w){
            document.querySelector("#w-white").classList.toggle('hidden');
        }else{
            document.querySelector("#w-white").classList.toggle('hidden');
        }
    });
    $(document).on('change','#time-s',function (){
        const w = $(this).is(':checked') ? 1 : 0;
        if (w){
            document.querySelector("#w-time").classList.toggle('hidden');
        }else{
            document.querySelector("#w-time").classList.toggle('hidden');
        }
    });
    $(document).on('change','#expiry-date',function (){
        const w = $(this).is(':checked') ? 1 : 0;
        if (w){
            document.querySelector("#l_expiry-date").classList.toggle('hidden');
        }else{
            document.querySelector("#l_expiry-date").classList.toggle('hidden');
        }
    });
    let searchTimer;
    $(document).on('input','#listwhite',function (){
        clearTimeout(searchTimer);
        const keyword = $("#listwhite").val();

        searchTimer = setTimeout(function(){
            SAJ('search',{key:keyword},function (res){
                if (res.status){
                    const div = document.querySelector(".listwhite_search");
                    div.classList.remove('hidden');
                    div.innerHTML = res.html;
                }
            })
        },500)
    });
    $(document).on('input','#listblock',function (){
        clearTimeout(searchTimer);
        const keyword = $("#listblock").val();

        searchTimer = setTimeout(function(){
            SAJ('search',{key:keyword},function (res){
                if (res.status){
                    const div = document.querySelector(".listblock_search");
                    div.classList.remove('hidden');
                    div.innerHTML = res.html;
                }
            })
        },500)
    });
    $(document).on('click','.Button-swl64',function (e){
        e.preventDefault();
        if ($(this).closest(".listwhite_search").length) {
            $("#listwhite").val($(this).data('id'));
            const div = document.querySelector(".listwhite_search");
            div.classList.add('hidden');
        }else{
            $("#listblock").val($(this).data('id'));
            const div = document.querySelector(".listblock_search");
            div.classList.add('hidden');
        }
    });
})