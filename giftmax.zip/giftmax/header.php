<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
    <link rel="icon" href="<?=get_template_directory_uri()?>/assets/img/favicon.ico">
    <?php
    wp_head();
    ?>
    <script>
        var $ = jQuery;
        var timer = "<?=gjdate(date("Y-m-d"),"d M Y");?>";
        <?php
        if (WC()->cart &&  WC()->cart->get_cart() && is_user_logged_in()) {

        $cart_product_discount = 0;
        $cart_items = [];
        $subtotal = 0; // بدون تخفیف
        $total = 0; // نهایی
        $discount = 0;
        foreach (WC()->cart->get_cart() as $cart_item) {
            $product = $cart_item['data'];
            $qty = (int)$cart_item['quantity'];
            $regular_price = (float)$product->get_regular_price();
            $line_total = $cart_item['line_total'];

            $cart_product_discount += ($regular_price * $qty) - $line_total;
            $line_subtotal = (float)$cart_item['line_subtotal'];

            $total += $line_total;

            $cart_items[] = [
                'product_id' => $cart_item['product_id'],
                'url' => get_permalink($cart_item['product_id']),
                'name' => $product->get_name(),
                'qty' => $cart_item['quantity'],
                'price_regular' => number_format_usd($regular_price * (int)$cart_item['quantity']),
                'price_sale' => number_format_usd($cart_item['line_total']),
                'image' => $product->get_image_id()
                    ? wp_get_attachment_image_url($product->get_image_id(), 'product_discount')
                    : wc_placeholder_img_src(),
            ];
        }
        $coupon_discount_total = WC()->cart->get_discount_total();
        $total_discount = $cart_product_discount + $coupon_discount_total;
        $is_cart_empty = WC()->cart->is_empty();
        $total_points = 0;
        $mini = [
            'items_count' => WC()->cart->get_cart_contents_count(),
            'subtotal' => number_format_usd(WC()->cart->get_subtotal() + $cart_product_discount),
            'discount' => number_format_usd($cart_product_discount),
            'total' => number_format_usd($total),
            'totalUSD' => ($total),
            'items' => $cart_items
        ];
        ?>
        window.cart = <?= json_encode($mini, JSON_UNESCAPED_UNICODE); ?>;
        <?php
        }
        if(is_user_logged_in()){
        $current_user = wp_get_current_user();
        $user_id = $current_user->ID;
        $db = \Giftmax\modules\Db::getLnstance();
        global $wpdb;
        $National_card__img = $db->first("SELECT * FROM {$wpdb->prefix}documents WHERE user_id = :user_id AND doc_type = 'National_card__img' AND accepted=2 ",array('user_id' => $user_id));
        $birth_certificate = $db->first("SELECT * FROM {$wpdb->prefix}documents WHERE user_id = :user_id AND doc_type = 'Birth_certificate' AND accepted=2 ",array('user_id' => $user_id));
        $recoords_Vip = \Giftmax\model\SiteModel::table("user_identity","user_id",$user_id);
        if (is_array($recoords_Vip) && $recoords_Vip['account_type'] == 'vip'){
            $vip = 1;
        }else{
            $vip = 0;
        }
        $access = is_user_blocked() ? 'مسدود' : ($vip ? 'ویژه': 'عادی');
        $ajaxUser = [
            'fullName' => $current_user->first_name . ' ' . $current_user->last_name,
            'mobile' => $current_user->user_login,
            'access' => $access,
            'type' => $vip,
            'points' => number_format(\Giftmax\model\UserModel::points()),
            'CounterPost' => number_format(count_user_posts($user_id, 'post'))
        ];
        ?>
        window.user = <?= json_encode($ajaxUser, JSON_UNESCAPED_UNICODE); ?>;
        <?php
        }
        ?>
    </script>
</head>
<body>
<div id="app">
    <svg style="display: none">
        <symbol id="cartOff" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
            <path fill-rule="evenodd"
                  d="M20 4h2V2h-3a1 1 0 00-1 1v1H3a1 1 0 00-.995 1.1l1 10A1 1 0 004 16h15a1 1 0 001-1V4zm-2 17a2 2 0 110-4 2 2 0 010 4zM5 21a2 2 0 110-4 2 2 0 010 4zm13-7V6H4.105l.8 8H18z"
                  clip-rule="evenodd"></path>
        </symbol>
        <symbol id="chevronLeft" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
            <path d="M11.414 12l4.293 4.293-1.414 1.414-5-5a1 1 0 010-1.414l5-5 1.414 1.414L11.414 12z"></path>
        </symbol>
        <symbol id="chevronRight" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
            <path d="M12.583 12L8.29 16.293l1.414 1.414 5-5a1 1 0 000-1.414l-5-5L8.29 7.707 12.583 12z"></path>
        </symbol>
    </svg>
    <?php

    $post = get_post(0);
    $leavename = false;
    $sample = false;
    $permalink = get_attachment_link($post, $leavename);
    $permalink = str_ireplace(home_url(), '', $permalink);
    $permalink = str_ireplace('/', '', $permalink);
    if ($permalink != 'login-register') {
        $db = \Giftmax\modules\Db::getLnstance();
        global $wpdb;
        $records = $db->first("SELECT meta_value FROM `{$wpdb->prefix}setting` WHERE `meta_key`=:key",array('key'=>'notifications'));
        if (\Giftmax\model\SiteModel::setting("banner") === true && !empty($records)){
            $records = json_decode($records['meta_value'],true)[0];

            ?>
            <a href="<?=$records['link']?>" class="relative zIndex-9999 h-[70px] xs:h-[50px] flex" target="_blank">
                <img src="<?=$records['img']['d']?>" class="hidden object-cover! md:block w-full">
                <img src="<?=$records['img']['m']?>" class="object-cover! md:hidden w-full">
            </a>
            <?php
        }
        if (isMobile()){
            ?>
            <div class="swiper swiper-initialized swiper-horizontal usdtirim d-none">
                <div class="swiper-wrapper" id="swiper-coin"></div>
            </div>
            <?php
        }
        ?>
        <div class="menu-help">
            <div class="container-xl-w mx-auto flex justify-between">
                <ul class="flex align-items-center">
                    <?php
                    if (!isMobile()){
                        ?>
                        <li class="hidden md:block">
            <span class="title">
                <img src="<?=get_template_directory_uri()?>/assets/img/svg/home-smile.svg" class="menu-item-icon" width="18">
                <a href="<?=home_url()?>">صفحه اصلی</a>
            </span>
                        </li>
                        <?php
                    }
                    ?>
                    <li class="">
            <span class="title">
                <img src="<?=get_template_directory_uri()?>/assets/img/blog.webp" class="menu-item-icon" width="18">
                <a href="<?=home_url('/blogs')?>" class="">وبلاگ</a>
            </span>
                    </li>
                    <li class="">
            <span class="title">
                <img src="<?=get_template_directory_uri()?>/assets/img/svg/bolt.svg" class="menu-item-icon" width="18">
                <a href="<?=home_url('/our-rules')?>" class="">قوانین و مقررات</a>
            </span>
                    </li>
                    <?php
                    if (is_user_logged_in()){
                        ?>
                        <li class="">
                        <span class="title">
                            <img src="<?=get_template_directory_uri()?>/assets/img/ticket.webp" class="menu-item-icon" width="18">
                            <a href="<?=home_url('/ticket')?>" class="">تیکت ها</a>
                        </span>
                        </li>
                        <?php
                        $user_id = get_current_user_id();
                        $recoords_Vip = \Giftmax\model\SiteModel::table("user_identity", "user_id", $user_id);
                        if (is_array($recoords_Vip) && $recoords_Vip['account_type'] != 'vip') {
                            ?>
                            <li class="relative">
                        <span class="title">
                             <img src="<?=get_template_directory_uri()?>/assets/img/payment-authentication.webp" class="menu-item-icon" width="18">
                            <a href="<?=home_url('/profile/verification')?>" class=""> احراز هویت</a>
                        </span>
                                <?php
                                if (isMobile()){?>
                                    <span style="mask: linear-gradient(-60deg, #000 30%, rgb(0 0 0 / .3333333333333333), #000 50%) right / 300% 100%;background-repeat: no-repeat;-webkit-animation: shimmer 3s infinite;animation: shimmer 3s infinite;background-color: #00691b;color: #FFF;padding: 0px 4px;border-radius: 6px;font-size: 11px;top: -11px;right: 28px;position: absolute;width: 32px;display: flex;justify-content: center;align-items: center;">ارتقا</span>
                                    <?php
                                }else{
                                    ?>
                                    <span style="mask: linear-gradient(-60deg, #000 30%, rgb(0 0 0 / .3333333333333333), #000 50%) right / 300% 100%; background-repeat: no-repeat; -webkit-animation: shimmer 3s infinite; animation: shimmer 3s infinite;background-color: #00691b; color: #FFF; padding: 2px 4px; border-radius: 6px; font-size: 11px; top: 2px; right: 81px; position: absolute; width: 88px; display: flex; justify-content: center; align-items: center;"> ارتقاء حساب کاربری </span>
                                    <?php
                                }
                                ?>
                            </li>
                            <?php
                        }
                    }
                    ?>
                    <li style="<?=!isMobile() && is_array($recoords_Vip) && $recoords_Vip['account_type'] == 'normal' ? 'margin-right: 85px' : ''?>">
                        <span class="title">
                             <img src="<?=get_template_directory_uri()?>/assets/img/chat.webp" class="menu-item-icon" width="18">
                            <a href="<?=home_url('/contact')?>" class="">تماس با ما</a>
                        </span>
                    </li>
                </ul>
            </div>
        </div>
        <header class="site-header">
            <div class="site-header-top">
                <div class="container-xl-w mx-auto">
                    <div class="row">
                        <div class="col-auto">
                            <div class="header-logo">
                                <button class="toggle-responsive-menu btn btn-md" aria-label="نمایش منو">
                                    <i class="icon-menu"></i>
                                </button>

                                <a href="<?= home_url('/') ?>">
                                    <img src="<?= get_template_directory_uri() ?>/assets/img/logo.png"
                                         class="img-logo" alt="">
                                </a>
                            </div>
                        </div>
                        <div class="col-auto hidden md:flex">
                            <div class="header-search-outer header-search-desktop">
                                <div class="header-search">
                                    <form role="search" data-page="1" class="search-form-header" method="get" id="searchform" style="/* display: none; */">
                                        <div class="input-group">
                                            <div class="input-field input-has-prepend">
                                                <input type="text" name="s" placeholder="نام محصول یا مقاله مثلاً: پلی استیشن" class="search-field form-field">
                                                <div class="search-field__remove" style="display: none;"><i class="icon-close"></i></div>
                                                <label class="input-prepend" for="headerSearchField">
                                                    <i class="icon-search"></i>
                                                    <i class="rip rip-l-arrow-right input-prepend-back"></i>
                                                </label>
                                            </div>
                                        </div>
                                        <div class="header-search-result header-search-result--first">
                                        </div>
                                        <div class="header-search-result header-search-result--second"><div class="header-search-result__inner"><div class="header-search-result__head"><div class="header-search-result__head-text"><i class="rip rip-l-arrows-repeat"></i> جستجوهای پرتکرار </div></div><div class="header-search-result__category"><div class="swiper searchResultSwiper swiper-initialized swiper-horizontal swiper-pointer-events swiper-rtl"><div class="swiper-wrapper" id="swiper-wrapper-2ce6fafd38310376b" aria-live="polite" style="transition-duration: 0ms;"></div><span class="swiper-notification" aria-live="assertive" aria-atomic="true"></span></div></div><div class="header-search-result__head header-search-result__history-section header-search-result__history-section-hide pt-4"><div class="header-search-result__head-text"><i class="rip rip-l-hourglass"></i> جستجوهای اخیر شما </div><span class="header-search-result__head-action header-search-result__head-action--delete"><i class="rip rip-l-trash"></i></span></div><div class="header-search-result__history header-search-result__history-section header-search-result__history-section-hide"><ul class="header-search-result__list-content header-search-result__list-content-ul"><li class="header-search-result__list-item"><a href="#"><div class="header-search-result__list-item-title"> قالب تمام المنتوری تجارتخانه </div><div class="header-search-result__list-item-action"><div class="header-search-result__list-item-icon"><i class="rip rip-l-arrow-up"></i></div></div></a></li><li class="header-search-result__list-item"><a href="#"><div class="header-search-result__list-item-title"> قالب تمام المنتوری تجارتخانه </div><div class="header-search-result__list-item-action"><div class="header-search-result__list-item-icon"><i class="rip rip-l-arrow-up"></i></div></div></a></li><li class="header-search-result__list-item"><a href="#"><div class="header-search-result__list-item-title"> قالب تمام المنتوری تجارتخانه </div><div class="header-search-result__list-item-action"><div class="header-search-result__list-item-icon"><i class="rip rip-l-arrow-up"></i></div></div></a></li></ul></div></div></div><span class="c-spinner spinner--styles"></span></form>
                                </div>
                            </div>
                        </div>

                        <div class="col responsive-header-left-panel">
                            <nav class="row header-left-panel align-items-center flex">
                                <?php
                                if (is_user_logged_in()) {
                                    $unread_notifications_count = giftmax_get_unread_notifications_count();
                                    $unread_notifications_label = $unread_notifications_count > 99 ? '99+' : $unread_notifications_count;
                                    $counter = $db->query("SELECT * FROM `{$wpdb->prefix}user_wishlist` WHERE user_id=:user_id",array('user_id'=>$user_id));
                                    ?>
                                    <div class="atlDDG" style="position:relative;">
                                        <a href="<?= home_url('/profile/list') ?>">
                                            <svg viewBox="0 0 24 24">
                                                <path d="M12.62 20.81C12.28 20.93 11.72 20.93 11.38 20.81C8.48 19.82 2 15.69 2 8.68998C2 5.59998 4.49 3.09998 7.56 3.09998C9.38 3.09998 10.99 3.97998 12 5.33998C13.01 3.97998 14.63 3.09998 16.44 3.09998C19.51 3.09998 22 5.59998 22 8.68998C22 15.69 15.52 19.82 12.62 20.81Z" fill="none" stroke="inherit" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                                            </svg>
                                            <span class="DHDs8l <?=!empty($counter) ? '' : 'hidden' ?>"><?= !empty($counter) ? count($counter) : 0 ?></span>
                                        </a>
                                    </div>
                                    <div class="notifications md:inline-flex" style="position:relative;">
                                        <a href="<?= home_url('/notifications') ?>">
                                            <div class="lottie-container" style="width: 43px" data-lottie-url="<?=get_template_directory_uri()?>/assets/img/wsl/notification.json"></div>
                                            <span class="DHDs8f <?= $unread_notifications_count > 0 ? '' : 'hidden' ?>"><?= $unread_notifications_label ?></span>
                                        </a>
                                        <div class="widget-notifications hidden md:block">
                                            <div style="" class="flex flex-col">
                                                <div class="ModalComponent__header-l62jh_ r-border-6">
                                                    <div class="d-flex ai-center AppHeader__headerBorder-sqCler  jc-between ProfileModal__header-QU8G4w">
                                                        <p class="text-h5 color-n-700 text-h5 text-color-neutral-700">نوتیفیکیشن</p>
                                                    </div>
                                                </div>
                                                <div class="uModalComponent__body-WvxQuY ModalComponent__body--default-sYpvC3">
                                                    <?php
                                                    $db = \Giftmax\modules\Db::getLnstance();
                                                    global $wpdb;
                                                    $user_id = get_current_user_id();
                                                    $records = $db->query("SELECT n.*,r.* FROM `{$wpdb->prefix}notifications` n LEFT JOIN `{$wpdb->prefix}notification_reads` r ON r.`notification_id` = n.`Id` AND r.`user_id` = :user_id WHERE n.`is_active`=1 AND (n.`userId` IS NULL OR n.`userId`=0 OR n.`userId`=:user_id) ORDER BY n.`Id` DESC Limit 3", array('user_id' => $user_id));
                                                    if (!empty($records)){
                                                        foreach ($records as $i => $record){
                                                            $Id = $record['Id'];
                                                            ?>
                                                            <div class="flex justify-between text-body-1 color-n-700 w-100 mb-3<?=empty($record['notification_id']) ? " notif-sa23" : ' notif-ra23'?>" data-id='<?=$Id?>'>
                                                                <div class="flex gap-3 align-items-center">
                                                                    <p class="notif-_count"><?=$i+1?></p>
                                                                    <p class="mb-2 color-n-700 text-body-1 mb-2"><?=$record['title']?></p>
                                                                </div>
                                                                <div>
                                                                    <?php
                                                                    if (!empty($record['notification_id'])) {?>
                                                                        <span class="notif-_status"> خوانده شده </span>
                                                                    <?php }else{?>
                                                                        <span class="notif-_status"> خوانده نشده </span>
                                                                    <?php }
                                                                    ?>
                                                                </div>
                                                            </div>
                                                            <?php
                                                        }
                                                    }else{?>
                                                        <div class="flex justify-between align-items-center">
                                                            <img class="lg:w-20" src="<?=get_template_directory_uri()?>/assets/img/ticket_img.png">
                                                            <p class="text-body2-strong">برای شما هیچ نوتیفیکیشنی ثبت نشده!</p>
                                                        </div>
                                                    <?php }
                                                    ?>
                                                </div>
                                                <div class="grow-1"></div>
                                                <div class="ModalComponent__footerContainer-rb1vEj">
                                                    <div class="ProfileModal__footer-IVQdrc">
                                                        <a href="<?= home_url('/notifications') ?>" class="relative d-flex ai-center user-select-none btn-wc51H8 text-button-2 btn--primary-uiqWij radius Button__medium-gIvke_ Button__filledPrimary-OvgwGb ProfileBase__button-jvi4aR ProfileBase__button__modal-O3kjhU"
                                                           data-testid="button-wrapper" type="button">
                                                            <div class="d-flex ai-center jc-center relative grow-1">مشاهده
                                                            </div>
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                    <div class="border-hr hidden md:block"></div>
                                    <?php
                                }
                                ?>
                                <div class="col-auto site-header__pro Button-cu46"><i class="icon-phone-ring text-xl text-green-dark"></i><span
                                            class="site-header__pro-text"><?= \Giftmax\model\SiteModel::setting("tel") == 'true' ? \Giftmax\model\UserModel::settingValue("tel") : ""?></span></div>
                                <?php
                                if (is_user_logged_in()) {
                                    ?>
                                    <div class="w-48 p-0 hidden md:block">
                                        <div class="btn w-48 h-48 lg:w-52 lg:h-52 navbar-btn text-xl pointer header-basket Cart-gd445"
                                             aria-label="سبد خرید" style="padding: 0;position: relative;--btn-hover-color: #444552; --btn-hover-bg-color: #f1f1f1;margin-right: 6px;">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="26" height="26"
                                                 viewBox="0 0 26 26" fill="currentcolor">
                                                <path d="M17.875 9.34916C17.4308 9.34916 17.0625 8.98083 17.0625 8.53666V7.04166C17.0625 5.90416 16.575 4.79916 15.73 4.03C14.8742 3.25 13.7692 2.8925 12.5992 3.00083C10.6492 3.185 8.9375 5.17833 8.9375 7.25833V8.30916C8.9375 8.75333 8.56917 9.12166 8.125 9.12166C7.68083 9.12166 7.3125 8.75333 7.3125 8.30916V7.2475C7.3125 4.33333 9.66333 1.64666 12.4475 1.37583C14.0725 1.22417 15.6325 1.73333 16.8242 2.8275C18.005 3.9 18.6875 5.43833 18.6875 7.04166V8.53666C18.6875 8.98083 18.3192 9.34916 17.875 9.34916Z"></path>
                                                <path d="M16.2498 24.6457H9.7498C4.7448 24.6457 3.81314 22.3165 3.5748 20.0523L2.7623 13.5632C2.64314 12.3932 2.5998 10.714 3.7373 9.45734C4.7123 8.374 6.32647 7.854 8.66647 7.854H17.3331C19.684 7.854 21.2981 8.38484 22.2623 9.45734C23.389 10.714 23.3565 12.3932 23.2373 13.5415L22.4248 20.0523C22.1865 22.3165 21.2548 24.6457 16.2498 24.6457ZM8.66647 9.479C6.83564 9.479 5.57897 9.8365 4.9398 10.5515C4.40897 11.1365 4.23564 12.0357 4.37647 13.379L5.18897 19.8682C5.37314 21.6015 5.8498 23.0315 9.7498 23.0315H16.2498C20.1498 23.0315 20.6265 21.6123 20.8106 19.8898L21.6231 13.379C21.764 12.0573 21.5906 11.1582 21.0598 10.5623C20.4206 9.8365 19.164 9.479 17.3331 9.479H8.66647Z"></path>
                                                <path d="M16.7045 14.2458C16.0979 14.2458 15.6104 13.7583 15.6104 13.1624C15.6104 12.5666 16.0979 12.0791 16.6937 12.0791C17.2895 12.0791 17.777 12.5666 17.777 13.1624C17.777 13.7583 17.3004 14.2458 16.7045 14.2458Z"></path>
                                                <path d="M9.12151 14.2458C8.51484 14.2458 8.02734 13.7583 8.02734 13.1624C8.02734 12.5666 8.51484 12.0791 9.11068 12.0791C9.70651 12.0791 10.194 12.5666 10.194 13.1624C10.194 13.7583 9.71734 14.2458 9.12151 14.2458Z"></path>
                                            </svg>
                                            <span class="SJf5G <?= (WC()->cart && WC()->cart->get_cart_contents_count() > 0) ? '' : 'hidden'; ?>"><?= (WC()->cart) ? WC()->cart->get_cart_contents_count() : 0; ?></span>
                                        </div>
                                        <div class="widget-shop-cart">
                                            <?php
                                            if (!function_exists('WC') || WC()->cart->is_empty()) {
                                                echo '<div class="p-24 text-center text-gray">سبد خرید خالی است</div>';
                                            } else {
                                                $cart = WC()->cart;
                                                ?>

                                                <div class="flex flex-col overflow-hidden max-h-[480px]">
                                                    <div class="p-24 grow overflow-y-auto minimal-scrollbar">

                                                        <?php foreach ($cart->get_cart() as $cart_item_key => $cart_item) :

                                                            $product = $cart_item['data'];
                                                            if (!$product || !$product->exists()) {
                                                                continue;
                                                            }

                                                            $product_id = $cart_item['product_id'];
                                                            $qty = $cart_item['quantity'];
                                                            $price = $cart_item['line_total']; // قیمت نهایی محصول
                                                            ?>

                                                            <div class="flex items-start pb-20 mb-20 border-b border-gray-300 last:!mb-0 last:!pb-0 last:!border-none"
                                                                 data-product-id="<?php echo esc_attr($product_id); ?>">
                                                                <div class="pt-3 pb-1 grow leading-xs">
                                                                    <a class="text-sm text-dark font-bold tracking-tight"><?= esc_html($product->get_name()); ?></a>

                                                                    <div class="flex items-center mt-6 min-h-[38px]">
                                                                        <div class="leading-1 pt-2 grow">
                                                                            <div class="text-2xs text-gray font-medium tracking-tight">
                                                                                <span class="text-larger font-bold text-dark tracking-tighter pt-2 inline-block"><?= number_format_usd($price); ?></span>
                                                                                تومان
                                                                            </div>

                                                                        </div>

                                                                        <div class="rounded bg-light w-104 h-36 flex flex-row-reverse transition-opacity">
                                                                            <button type="button" class="pl-6 btn-minus"
                                                                                    data-product-id="<?= $product_id ?>">
                                                                                <i class="<?= ($qty != 1) ? 'icon-minus text-[9px] text-gray bg-white shadow-sm block text-center rounded-sm w-28 h-28 !leading-[28px]' : 'icon-delete text-xs text-red-dark w-24 h-24 bg-white shadow-sm block !leading-[24px] text-center rounded-sm' ?>"></i>
                                                                            </button>
                                                                            <div class="grow text-center flex flex-col justify-center leading-1">
                                                                                <div class="pt-2 text-dark font-bold tracking-tighter text-sm after:loading after:border-blue transition-colors after:text-3xs text-qty"><?= $qty ?></div>
                                                                            </div>
                                                                            <button type="button" class="pr-6 btn-plus"
                                                                                    data-product-id="<?= $product_id ?>">
                                                                                <i class="w-24 h-24 bg-white shadow-sm text-gray rounded-sm icon-plus text-[9px] block !leading-[24px] text-center"></i>
                                                                            </button>
                                                                        </div>
                                                                    </div>

                                                                </div>
                                                            </div>

                                                        <?php endforeach; ?>

                                                    </div>

                                                    <!-- Cart Footer -->
                                                    <div class="px-24 py-16 flex items-center border-t border-gray-300 shrink-0">
                                                        <div class="grow leading-xs pst-4">

                                                            <div class="text-2xs font-medium text-gray">
                                                                مبلغ قابل پرداخت
                                                            </div>

                                                            <div class="flex items-center mt-2 flex-wrap">
                                                                <div class="text-2xs text-gray font-medium tracking-tight">
                                                                    <span class="text-lg font-bold text-dark tracking-tighter pt-2 inline-block"><?= number_format_usd($cart->get_total('edit')); ?></span>
                                                                    تومان
                                                                </div>
                                                            </div>

                                                            <div class="mt-8 text-2xs text-gray font-medium tracking-tight"
                                                                 data-timer-container>
                                                                <span class="text-dark font-bold">زمان باقی مانده:</span>
                                                                <span class="inline-block min-w-[52px] text-dark"
                                                                      data-cart-timer></span>
                                                            </div>

                                                        </div>

                                                        <a class="btn btn-primary rounded whitespace-nowrap mr-12">ثبت
                                                            سفارش</a>
                                                    </div>

                                                </div>
                                                <?php
                                            }
                                            ?>
                                        </div>


                                    </div>
                                    <?php
                                }
                                ?>
                                <div class="col-auto" style="padding-left: 0">
                                    <div class="<?= !is_user_logged_in() ? 'header-account' : 'header-dashboard' ?>">
                                        <?php
                                        if (!is_user_logged_in()) {
                                            ?>
                                            <a href="<?= home_url('/login-register') ?>" target="_blank"
                                               class="btn btn-outline login-btn">
                                                <div class="login-btn-inner">
                                                    <div class="login-btn-inner-text">ورود</div>
                                                    <div>ثبت نام</div>
                                                </div>
                                                <span class="prepend-icon">
                                                <i class="icon-logout"></i>
                                            </span>
                                            </a>
                                            <?php
                                        } else {
                                            $user = wp_get_current_user();
                                            ?>
                                            <div class="inner">
                                                <a>
                                                    <figure class="avatar">
                                                        <img src="<?=get_template_directory_uri() . '/assets/img/avatar.png'?>"
                                                             alt="<?= $user->user_login ?>">
                                                    </figure>
                                                </a>
                                                <div class="flex flex-col mr-3 xs:mr-4">
                                                    <div class="f5fh5fr">
                                                        <div class="title ellipsis">
                                                            <?=$user->first_name . ' ' . $user->last_name?>
                                                        </div>
                                                    </div>
                                                    <div class="flex justify-between xs:flex-col">
                                                        <?php
                                                        $user_id = get_current_user_id();
                                                        $recoords_Vip = \Giftmax\model\SiteModel::table("user_identity","user_id",$user_id);
                                                        if (is_array($recoords_Vip) && $recoords_Vip['account_type'] == 'vip'){
                                                            $vip = 1;
                                                        }else{
                                                            $vip = 0;
                                                        }
                                                        if (is_user_blocked()){
                                                            ?>
                                                            <div class="title">کاربر <span class="font-medium" style="color:#0865ff;">مسدود </span></div>
                                                            <?php
                                                        }else{
                                                            ?>
                                                            <div class="title">کاربر <span class="font-medium" style="color:#0865ff;"><?=$vip ?'ویژه': 'عادی'; ?></span></div>
                                                            <?php
                                                        }
                                                        ?>
                                                        <div class="wallet mt-0 mr-3 xs:mr-0 xs:mt-1">
                                                            <div class="title hidden md:block"> کیف پول</div>
                                                            <div class="value xs:mr-0">
                                                                <?php
                                                                $balance = \Giftmax\model\UserModel::wallet();
                                                                ?>
                                                                <span><?=isMobile() && $balance>=9000000 ? "+9,000,000" : number_format($balance) ?></span>
                                                                تومان
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <span class="arrow hidden"><i class="icon-angle-down"></i></span>
                                            </div>
                                            <div class="outer">
                                                <a class="user" href="<?= home_url('/profile') ?>">
                                                    <div class="user-content">
                                                        <div class="user-avatar">
                                                            <figure class="avatar">
                                                                <img src="<?=get_template_directory_uri() . '/assets/img/avatar.png'?>"
                                                                     alt="<?=$user->first_name . ' ' . $user->last_name?>">
                                                            </figure>
                                                        </div>
                                                        <div class="user-name"> <?=$user->first_name . ' ' . $user->last_name?></div>
                                                    </div>
                                                    <span class="arrow"><i class="icon-angle-left"></i></span>
                                                </a>
                                                <?php
                                                if (!empty($National_card__img) || !empty($birth_certificate)) {
                                                    $p = "100";
                                                }elseif(is_array($recoords_Vip) && !$recoords_Vip['is_verified']){
                                                    $p = "30";
                                                }else{
                                                    $p = "80";
                                                }
                                                if (!$vip){?>
                                                    <div class="nwp-top-user-area-inner-process-bar">
                                                        <div class="nwp-top-user-area-inner-process-account">
                                                            <div class="nwp-top-user-area-inner-process-account-line" style="width:<?=$p?>%"></div>
                                                        </div>
                                                        <span>شما<strong><?=$p?>%</strong>از پروفایل خودتان را تکمیل کردید.</span>
                                                    </div>
                                                    <?php
                                                }
                                                ?>
                                                <hr>
                                                <div class="points mt-0">
                                                    <div class="title">امتیاز </div>
                                                    <div class="value">
                                                        <span><?= number_format(\Giftmax\model\UserModel::points()) ?></span>
                                                    </div>
                                                </div>
                                                <hr>
                                                <ul class="list-items">
                                                    <li>
                                                        <a href="<?= home_url('/profile') ?>">
                                                            <i class="icon icon-menu2"></i>
                                                            پیشخوان کاربری
                                                        </a>
                                                    </li>
                                                    <li>
                                                        <a href="<?= home_url('/profile/orders') ?>">
                                                            <i class="icon icon-order"></i>
                                                            سفارشات
                                                        </a>
                                                    </li>
                                                    <li>
                                                        <a href="<?= home_url('/profile/deliveries') ?>">
                                                            <i class="icon icon-flash"></i>
                                                            لایسنس
                                                        </a>
                                                    </li>
                                                    <li>
                                                        <a href="<?= home_url('/profile/coupons') ?>">
                                                            <i class="icon icon-gift"></i>
                                                            کد های تخفیف
                                                        </a>
                                                    </li>
                                                    <li>
                                                        <a href="<?= home_url('/profile/wallet') ?>">
                                                            <i class="icon icon-wallet"></i>
                                                            کیف پول و امتیاز
                                                        </a>
                                                    </li>
                                                    <?php
                                                    $defaultCard = $db->query("SELECT * FROM `{$wpdb->prefix}user_bank_cards` WHERE `user_id`=:user_id AND `is_active`=1",array('user_id'=>$user_id));
                                                    ?>
                                                    <li>
                                                        <a href="<?= home_url('/profile/cards') ?>">
                                                            <i class="icon icon-card"></i>
                                                            <div class="cartsBank">
                                                                <div class="title">کارت های بانکی</div>
                                                                <div class="value"><?=!empty($defaultCard) ? count($defaultCard) : 0?></div>
                                                            </div>
                                                        </a>
                                                    </li>
                                                    <li>
                                                        <a href="<?= home_url('/profile/list') ?>">
                                                            <svg viewBox="0 0 24 24" class="interest">
                                                                <path d="M12.62 20.81C12.28 20.93 11.72 20.93 11.38 20.81C8.48 19.82 2 15.69 2 8.68998C2 5.59998 4.49 3.09998 7.56 3.09998C9.38 3.09998 10.99 3.97998 12 5.33998C13.01 3.97998 14.63 3.09998 16.44 3.09998C19.51 3.09998 22 5.59998 22 8.68998C22 15.69 15.52 19.82 12.62 20.81Z" fill="none" stroke="inherit" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                                                            </svg>
                                                            لیست علاقه مندی ها
                                                        </a>
                                                    </li>
                                                    <li>
                                                        <a href="<?= home_url('/ticket') ?>">
                                                            <i class="icon icon-support"></i>
                                                            تیکت ها
                                                        </a>
                                                    </li>
                                                </ul>
                                                <hr>
                                                <ul class="list-items">
                                                    <?php
                                                    $user_id = get_current_user_id();
                                                    $recoords_Vip = \Giftmax\model\SiteModel::table("user_identity", "user_id", $user_id);
                                                    if (is_array($recoords_Vip) && $recoords_Vip['account_type'] != 'vip') {
                                                        ?>
                                                        <li>
                                                            <a href="<?= home_url('/profile/verification') ?>">
                                                                احراز هویت (درخواست رفع مسدودی)
                                                            </a>
                                                        </li>
                                                        <?php
                                                    }
                                                    ?>
                                                    <li>
                                                        <a href="<?= wp_logout_url(home_url()) ?>" target="_blank">
                                                            خروج
                                                        </a>
                                                    </li>
                                                </ul>
                                            </div>
                                            <div class="rtl-dimmer"></div>
                                            <?php
                                        }
                                        ?>
                                    </div>
                                </div>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
            <nav class="main-navbar" style=" pointer-events: auto; ">
                <div class="responsive-item responsive-logo">
                    <div class="header-logo">
                        <button class="toggle-responsive-menu btn btn-md" aria-label="نمایش منو">
                            <i class="icon-menu"></i>
                        </button>

                        <a href="<?= home_url('/') ?>">
                            <img src="<?= get_template_directory_uri() ?>/assets/img/logo.png"
                                 class="img-logo">
                        </a>
                    </div>
                </div>
                <div class="container-xl-w mx-auto" style="height: 66px">
                    <div class="row align-items-center">
                        <div class="responsive-item col-12">
                            <div class="responsive-search">
                                <div class="header-search-outer">
                                    <div class="header-search">
                                        <form role="search" data-page="1" class="search-form-header" method="get" id="searchform" style="/* display: none; */">
                                            <div class="input-group">
                                                <div class="input-field input-has-prepend">
                                                    <input type="text" name="s" placeholder="نام محصول یا مقاله مثلاً: پلی استیشن" class="search-field form-field">
                                                    <div class="search-field__remove" style="display: none;"><i class="icon-close"></i></div>
                                                    <label class="input-prepend" for="headerSearchField">
                                                        <i class="icon-search"></i>
                                                        <i class="icon-arrow-right input-prepend-back"></i>
                                                    </label>
                                                </div>
                                            </div>
                                            <div class="header-search-result header-search-result--first">
                                            </div>
                                            <div class="header-search-result header-search-result--second"><div class="header-search-result__inner"><div class="header-search-result__head"><div class="header-search-result__head-text"><i class="rip rip-l-arrows-repeat"></i> جستجوهای پرتکرار </div></div><div class="header-search-result__category"><div class="swiper searchResultSwiper swiper-initialized swiper-horizontal swiper-pointer-events swiper-rtl"><div class="swiper-wrapper" id="swiper-wrapper-2ce6fafd38310376b" aria-live="polite" style="transition-duration: 0ms;"></div><span class="swiper-notification" aria-live="assertive" aria-atomic="true"></span></div></div><div class="header-search-result__head header-search-result__history-section header-search-result__history-section-hide pt-4"><div class="header-search-result__head-text"><i class="rip rip-l-hourglass"></i> جستجوهای اخیر شما </div><span class="header-search-result__head-action header-search-result__head-action--delete"><i class="rip rip-l-trash"></i></span></div><div class="header-search-result__history header-search-result__history-section header-search-result__history-section-hide"><ul class="header-search-result__list-content header-search-result__list-content-ul"><li class="header-search-result__list-item"><a href="#"><div class="header-search-result__list-item-title"> قالب تمام المنتوری تجارتخانه </div><div class="header-search-result__list-item-action"><div class="header-search-result__list-item-icon"><i class="rip rip-l-arrow-up"></i></div></div></a></li><li class="header-search-result__list-item"><a href="#"><div class="header-search-result__list-item-title"> قالب تمام المنتوری تجارتخانه </div><div class="header-search-result__list-item-action"><div class="header-search-result__list-item-icon"><i class="rip rip-l-arrow-up"></i></div></div></a></li><li class="header-search-result__list-item"><a href="#"><div class="header-search-result__list-item-title"> قالب تمام المنتوری تجارتخانه </div><div class="header-search-result__list-item-action"><div class="header-search-result__list-item-icon"><i class="rip rip-l-arrow-up"></i></div></div></a></li></ul></div></div></div><span class="c-spinner spinner--styles"></span></form>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg">
                            <div class="bk_menu bk_vertical_menu level">
                                <?php
                                if (isMobile()){
                                    ?>
                                    <div class="off-canvas-panel-wrapper_mo">
                                        <nav id="main-navigation_mo">
                                            <ul class="main-menu">

                                                <li>
                                            <span class="menu-title menu-title1">
                                                <a class="btn_mo-ripple haschild next" data-ripple-color="rgba(190,190,190,0.75)">
                                                    <span class="pull-right">دسته بندی</span>
                                                   <svg style="width: 10%;height: 20px;margin-left: 10px;"><path d="M11.414 12l4.293 4.293-1.414 1.414-5-5a1 1 0 010-1.414l5-5 1.414 1.414L11.414 12z"></path></svg>
                                                </a>
                                            </span>
                                                    <ul class="collapse submenu" style="right: -300px;">
                                                        <li class="go-back">دسته بندی ها
                                                            <svg><path d="M12.583 12L8.29 16.293l1.414 1.414 5-5a1 1 0 000-1.414l-5-5L8.29 7.707 12.583 12z" style=" "></path></svg>
                                                        </li>
                                                        <li>
                                                    <span class="menu-title menu-title2">
                                                        <a class="btn_mo-ripple haschild" data-ripple-color="rgba(190,190,190,0.75)" href="#popup">
                                                            <span class="pull-right">دسته بندی مقالات</span>
                                                            <svg style=" width: 62%; height: 20px; "><path d="M11.414 12l4.293 4.293-1.414 1.414-5-5a1 1 0 010-1.414l5-5 1.414 1.414L11.414 12z"></path></svg>
                                                        </a>

                                                    </span>
                                                            <ul class="collapse submenu" style="right: -300px;">
                                                                <li class="go-back">
                                                                    دسته بندی مقالات
                                                                    <svg><path d="M12.583 12L8.29 16.293l1.414 1.414 5-5a1 1 0 000-1.414l-5-5L8.29 7.707 12.583 12z" style=" "></path></svg>
                                                                </li>
                                                                <?php
                                                                $article_cats = get_terms( array(
                                                                        'taxonomy'   => 'category',      // طبقه‌بندی پیش‌فرض نوشته‌ها
                                                                        'hide_empty' => false,
                                                                        'orderby'    => 'name',
                                                                ) );
                                                                if (!empty($article_cats)) {
                                                                    foreach ($article_cats as  $key => $cat) {
                                                                        ?>
                                                                        <li>
                                                                    <span class="menu-title4">
                                                                        <a class="ch btn_mo-ripple" href="<?= get_term_link($cat) ?>" >
                                                                            <span><?= $cat->name ?></span>
                                                                        </a>
                                                                    </span>
                                                                        </li>
                                                                        <?php
                                                                        wp_reset_postdata();
                                                                    }
                                                                }
                                                                ?>
                                                            </ul>
                                                        </li>
                                                        <?php
                                                        $main_categories = get_terms(array(
                                                            'taxonomy' => 'product_cat',
                                                            'hide_empty' => false,      // حتی دسته‌هایی که محصول ندارند نمایش بده
                                                            'parent' => 0,          // دسته‌های سطح ۱
                                                            'orderby' => 'menu_order',
                                                        ));
                                                        if (!empty($main_categories)) {
                                                            foreach ($main_categories as $key => $main_cat) {
                                                                ?>
                                                                <li>
                                                    <span class="menu-title menu-title2">
                                                        <a class="btn_mo-ripple haschild" data-ripple-color="rgba(190,190,190,0.75)">
                                                            <span class="pull-right"><?= $main_cat->name ?></span>
                                                            <svg style="width: 25px;height: 20px; "><path d="M11.414 12l4.293 4.293-1.414 1.414-5-5a1 1 0 010-1.414l5-5 1.414 1.414L11.414 12z"></path></svg>
                                                        </a>
                                                    </span>
                                                                    <ul class="collapse submenu" style="right: -300px;">
                                                                        <li class="go-back">
                                                                            <?= $main_cat->name ?>
                                                                            <svg><path d="M12.583 12L8.29 16.293l1.414 1.414 5-5a1 1 0 000-1.414l-5-5L8.29 7.707 12.583 12z" style=" "></path></svg>
                                                                        </li>
                                                                        <?php
                                                                        $products = new WP_Query(array(
                                                                            'post_type' => 'product',
                                                                                'tax_query' => array(
                                                                                        array(
                                                                                                'taxonomy' => 'product_cat',
                                                                                                'field' => 'term_id',
                                                                                                'terms' => $main_cat->term_id,
                                                                                        ),
                                                                                ),
                                                                                'meta_query' => [
                                                                                        'relation' => 'OR',

                                                                                        [
                                                                                                'key'     => 'giftmax_setting_order',
                                                                                                'compare' => 'EXISTS',
                                                                                                'type'    => 'NUMERIC',
                                                                                        ],

                                                                                        [
                                                                                                'key'     => 'giftmax_setting_order',
                                                                                                'compare' => 'NOT EXISTS',
                                                                                        ],
                                                                                ],

                                                                                'orderby' => [
                                                                                        'meta_value_num' => 'ASC',
                                                                                        'date'           => 'DESC',
                                                                                ],
                                                                            'order' => 'DESC',
                                                                        ));
                                                                        if ($products->have_posts()) :
                                                                            while ( $products->have_posts() ) :
                                                                                $products->the_post();
                                                                                $settings = get_post_meta(get_the_ID(), 'giftmax_box_setting', true);
                                                                                ?>
                                                                                <li>
                                                                                    <div class="flex justify-between align-items-center">
                                                                                         <span class="menu-title4">
                                                                        <a class="ch btn_mo-ripple" href="<?php the_permalink(); ?>" >
                                                                            <span><?php the_title(); ?></span>
                                                                        </a>
                                                                    </span>
                                                                                        <?php
                                                                                        if (!empty($settings[0]['logo_region'])){
                                                                                            ?>
                                                                                            <div class="item-logo__region">
                                                                                                <img alt="<?=$settings[0]['logo_region']?>" src="<?=empty($settings[0]['logo_region']) ?: get_template_directory_uri() . '/assets/flag/' . $settings[0]['logo_region'] . '.svg'?>">
                                                                                            </div>
                                                                                            <?php
                                                                                        }
                                                                                        ?>
                                                                                    </div>
                                                                                </li>
                                                                            <?php
                                                                            endwhile;
                                                                        endif;
                                                                        ?>
                                                                    </ul>
                                                                </li>
                                                                <?php
                                                                wp_reset_postdata();
                                                            }
                                                        }
                                                        ?>
                                                    </ul>
                                                </li>
                                                <li>
                                            <span class="menu-title menu-title1">
                                                <a class="btn_mo-ripple" href="<?=home_url()?>">
                                                    <span class="pull-right">صفحه اصلی</span>
                                                </a>
                                            </span>
                                                </li>
                                                <li>
                                            <span class="menu-title menu-title1">
                                                <a class="btn_mo-ripple" href="<?=home_url('/shop')?>">
                                                    <span class="pull-right">فروشگاه</span>
                                                </a>
                                            </span>
                                                </li>
                                                <li>
                                            <span class="menu-title menu-title1">
                                                <a class="btn_mo-ripple" href="<?=home_url('/blogs')?>">
                                                    <span class="pull-right">وبلاگ</span>
                                                </a>
                                            </span>
                                                </li>
                                                <li>
                                            <span class="menu-title menu-title1">
                                                <a class="btn_mo-ripple" href="<?=home_url('/our-rules')?>">
                                                    <span class="pull-right">قوانین و مقررات</span>
                                                </a>
                                            </span>
                                                </li>
                                            </ul>
                                        </nav>
                                    </div>
                                    <?php
                                }else{
                                    ?>
                                    <div class="bakala">
                                        <ul>
                                            <li class="bg-transparent zIndex-high">
                                                <span class="title">
                                                    <img data-perfmatters-preload="" src="<?= get_template_directory_uri() ?>/assets/img/category.svg" class="menu-item-icon" width="18" fetchpriority="high">
                                                    <a href="#" class="">دسته بندی ها</a>
                                                </span>
                                                <span class="arrow dashicons dashicons-arrow-down-alt2"></span>
                                                <div class="bakala-tab-menu-items">
                                                    <ul class="level">
                                                        <li class="first">
                                                            <span class="title2"><a href="<?=home_url('/blogs')?>">دسته بندی مقالات</a></span>
                                                            <div class="submenu">
                                                                <ul class="menu_ul">
                                                                    <?php

                                                                    $article_cats = get_terms( array(
                                                                            'taxonomy'   => 'category',      // طبقه‌بندی پیش‌فرض نوشته‌ها
                                                                            'hide_empty' => false,
                                                                            'orderby'    => 'name',
                                                                    ) );
                                                                    if (!empty($article_cats)) {
                                                                        foreach ($article_cats as $cat) {
                                                                            $key = mt_rand(1000,5000);
                                                                            ?>
                                                                            <li class="<?=(int)($key * 2.5) % 2 == 0 ? 'title' : 'item'?>">
                                                                                <span class="title3">
                                                                                    <a href="<?= get_term_link( $cat ) ?>"><?= esc_html( $cat->name ) ?></a>
                                                                                </span>
                                                                            </li>
                                                                            <?php
                                                                            wp_reset_postdata();
                                                                        }
                                                                    }
                                                                    ?>
                                                                </ul>
                                                            </div>
                                                        </li>
                                                        <li class="first cateqory-product">
                                                            <div class="title2"><span>دسته بندی محصولات</span></div>
                                                            <div class="submenu-trigger">
                                                                <ul class="menu_ul">
                                                                    <?php
                                                                    $main_categories = get_terms(array(
                                                                            'taxonomy' => 'product_cat',
                                                                            'hide_empty' => false,      // حتی دسته‌هایی که محصول ندارند نمایش بده
                                                                            'parent' => 0,          // دسته‌های سطح ۱
                                                                            'orderby' => 'menu_order',
                                                                    ));
                                                                    if (!empty($main_categories)) {
                                                                        foreach ($main_categories as $key => $main_cat) {
                                                                            ?>
                                                                            <li>
                                                                                <span class="title2"><a href="<?= get_term_link($main_cat) ?>"><?= esc_html($main_cat->name) ?></a></span>
                                                                                <div class="submenu">
                                                                                    <div class="V10-menuRegion">
                                                                                        <?php
                                                                                        $products = new WP_Query(array(
                                                                                                'post_type' => 'product',
                                                                                                'posts_per_page' => -1,
                                                                                                'tax_query' => array(
                                                                                                        array(
                                                                                                                'taxonomy' => 'product_cat',
                                                                                                                'field' => 'term_id',
                                                                                                                'terms' => $main_cat->term_id,
                                                                                                        ),
                                                                                                ),
                                                                                                'orderby' => 'date',
                                                                                                'order' => 'DESC',
                                                                                        ));

                                                                                        $regions_products = array();

                                                                                        if ($products->have_posts()) {
                                                                                            while ($products->have_posts()) {
                                                                                                $products->the_post();
                                                                                                $pid = get_the_ID();

                                                                                                $prod_settings = get_post_meta($pid, 'giftmax_box_setting', true);
                                                                                                $product_regions = array();
                                                                                                if (!empty($prod_settings) && is_array($prod_settings)) {
                                                                                                    if (isset($prod_settings[0]['logo_region'])) {
                                                                                                        $product_regions[] = $prod_settings[0]['logo_region'];
                                                                                                    }
                                                                                                }

                                                                                                if (!empty($product_regions)) {
                                                                                                    foreach ($product_regions as $reg) {
                                                                                                        $reg = trim($reg);
                                                                                                        if (!isset($regions_products[$reg])) {
                                                                                                            $regions_products[$reg] = array();
                                                                                                        }
                                                                                                        $regions_products[$reg][] = array(
                                                                                                                'title' => get_the_title(),
                                                                                                                'permalink' => get_the_permalink(),
                                                                                                        );
                                                                                                    }
                                                                                                } else {
                                                                                                    if (!isset($regions_products['نامشخص'])) {
                                                                                                        $regions_products['نامشخص'] = array();
                                                                                                    }
                                                                                                    $regions_products['نامشخص'][] = array(
                                                                                                            'title' => get_the_title(),
                                                                                                            'permalink' => get_the_permalink(),
                                                                                                    );
                                                                                                }
                                                                                            }
                                                                                            wp_reset_postdata();
                                                                                        }

                                                                                        foreach ($regions_products as $region => $prods) {
                                                                                            echo '<div class="region-block">';
                                                                                            echo '<div class="region-title">' . regionPersian($region) . '<img class="region-img" src="' . get_template_directory_uri() . '/assets/flag/' . $region . '.svg"></div>';
                                                                                            echo '<ul class="region-products">';
                                                                                            foreach ($prods as $p) {
                                                                                                echo '<li class="item">';
                                                                                                echo '<a href="' . esc_url($p['permalink']) . '">' . esc_html($p['title']) . '</a>';
                                                                                                echo '</li>';
                                                                                            }
                                                                                            echo '</ul>';
                                                                                            echo '</div>';
                                                                                        }
                                                                                        ?>
                                                                                    </div>
                                                                                </div>
                                                                            </li>
                                                                            <?php
                                                                        }
                                                                    }
                                                                    ?>
                                                                </ul>
                                                            </div>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </li>
                                            <?php
                                            wp_nav_menu([
                                                'theme_location' => 'header-menu',
                                                'container'      => false,
                                                'items_wrap'     => '%3$s',
                                                'walker'         => new Custom_Menu_Walker('header-menu')
                                            ]);
                                            ?>
                                        </ul>
                                    </div>
                                    <?php
                                }
                                ?>
                            </div>
                        </div>
                        <div class="col-lg-auto flex sx:flex-col">
                            <?php
                            if (!isMobile()){
                                ?>
                                <div class="header-main-left">
                                    <div class="header-extra__list d-none">
                                        <div class="header-extra__item">
                                            <div class="swiper swiper-initialized swiper-horizontal swiper-coin">
                                                <div class="swiper-wrapper" id="swiper-wrapper-coin"></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="usdtiri d-none"></div>
                                <?php
                            }
                            ?>
                        </div>
                    </div>
                </div>
            </nav>
            <div class="rtl-dimmer"></div>

        </header>
        <?php
        $recent_posts = new WP_Query( array(
            'posts_per_page' => 10,
            'post_status'    => 'publish',
            'orderby'        => 'date',
            'order'          => 'DESC',
        ) );

        if ( $recent_posts->have_posts() ) :
            ?>
            <div id="teletype" class="block relative z-50">
                <div class="container-xl-w mx-auto ticker_container">
                    <div class="sar_ticker">آخرین مقالات:</div>
                    <div id="ticker-wrapper" class="swiper swiper-initialized swiper-horizontal swiper-blogs md:h-24">
                        <div class="swiper-wrapper">
                            <?php
                            while ( $recent_posts->have_posts() ) : $recent_posts->the_post();
                                ?>
                                <div class="swiper-slide">
                                    <a class="flex md:gap-2.5 act-blogs-header_box" href="<?=get_the_permalink()?>" target="_blank">
                                        <div class="flex align-items-center">
                                            <h3 class="ellipsis"><?=get_the_title()?></h3>
                                            <span class="act-blogs-box-label"><?=get_the_category(get_the_ID())[0]->name?></span>
                                        </div>
                                        <div class="flex gap-2.5">
                                            <div class="act-vb hidden md:block"></div>
                                            <div class="flex 2xs:gap-6">
                                                <div class="flex align-items-center ml-1 xs:font-9"><i class="icon-eye"></i><p><?= view_giftmax(get_the_ID())?></p></div><div class="flex align-items-center xs:font-9"><i class="icon-clock"></i><?=gjdate(get_the_date('Y-m-d'),"d M Y")?></div><div class="flex align-items-center xs:font-9"><i class="icon-user"></i><?=giftmax_get_author_full_name()?></div>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                            <?php endwhile; ?>

                        </div>
                    </div>
                </div>
            </div>
        <?php
        endif;
        wp_reset_postdata();
        ?>
        <div class="skeleton-loader">
            <div class="skeleton-body pt-10 pbs-8 bg-neutral-000 w-max rounded-medium border-complete flex items-center justify-center flex-col mx-auto">
                <div aria-hidden="false" style="width: 194px; line-height: 0;">
                    <img class="w-full inline-block" src="<?= get_template_directory_uri() ?>/assets/img/logo.png"
                         width="120" style="object-fit: contain;"></div>
                <div class="d-flex items-center justify-center">
                    <div class="d-flex items-center justify-around mts-7" style="width: 24px; height: 24px;">
                        <div class="rounded-circle styles_Loading__circle1__K7HNJ"
                             style="width: 6px; height: 6px; background: rgb(239, 57, 78);"></div>
                        <div class="rounded-circle styles_Loading__circle2__jpl_q"
                             style="width: 6px; height: 6px; background: rgb(239, 57, 78);"></div>
                        <div class="rounded-circle styles_Loading__circle3__otcH4"
                             style="width: 6px; height: 6px; background: rgb(239, 57, 78);"></div>
                    </div>
                </div>
            </div>
        </div>
        <?php
    }
    ?>
