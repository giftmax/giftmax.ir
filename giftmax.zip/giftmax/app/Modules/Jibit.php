<?php
namespace Giftmax\Modules;

if (!defined('ABSPATH')) exit;

class Jibit
{
    private static $BASE_URL = 'https://napi.jibit.ir/ide/v1';
    private static $API_KEY = 'eWLrB_PvTp';
    private static $SECRET_KEY = 'M8roysnxwr1tugZtMtBw2SGx1';
    private static $instance;

    public static function getLnstance($option = null)
    {
        if (self::$instance === null) {
            self::$instance = new self($option);
        }
        return self::$instance;
    }
    public function __construct() {}

    private function curl_request(string $method, string $url, array $headers = [], $body = null)
    {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CUSTOMREQUEST  => $method,
            CURLOPT_HTTPHEADER     => $headers,
            CURLOPT_POSTFIELDS     => $body,
        ]);

        $res = curl_exec($ch);
        $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);

        if (curl_errno($ch)) {
            $error = curl_error($ch);
            curl_close($ch);
            throw new Exception("cURL error: {$error}");
        }
        curl_close($ch);

        return ['code' => $code, 'body' => json_decode($res, true)];
    }

    private function setToken(array $token):void{
        $_SESSION['accessToken']  = $token['accessToken'];
        $_SESSION['refreshToken'] = $token['refreshToken'];
    }
    private function getToken(): ?array
    {
        if (empty($_SESSION['accessToken'])) {
            return null;
        }
        return [
            'accessToken'  => $_SESSION['accessToken'],
            'refreshToken' => $_SESSION['refreshToken'] ?? null,
        ];
    }
    private function generateToken(): array
    {
        $url = self::$BASE_URL . "/tokens/generate";
        $body = json_encode(['apiKey' => self::$API_KEY, 'secretKey' => self::$SECRET_KEY]);

        $headers = ['Content-Type: application/json'];

        $res = $this->curl_request('POST', $url, $headers, $body);
        if ($res['code'] !== 200) {
            throw new \Exception('خطا در generate token: ' . json_encode($res['body']));
        }

        $token = $res['body'];
        $this->setToken($token);
        return $token;
    }
    private function refreshToken(string $refreshToken): array
    {

        $url = self::$BASE_URL . "/tokens/refresh";
        $body = json_encode(['refreshToken' => $refreshToken]);

        $headers = ['Content-Type: application/json'];

        $res = $this->curl_request('POST', $url, $headers, $body);
        if ($res['code'] !== 200) {
            return $this->generateToken();
        }

        $token = $res['body'];
        $this->setToken($token);
        return $token;
    }
    public function api_request(
        string $method,
        string $endpoint,
        array $queryParams = [],
               $body = null,
        bool $retry = true
    ): array
    {
        $token = $this->getToken();
        if ($token === null) {
            $token = $this->generateToken();
        }
        $query = http_build_query($queryParams);
        $url   = self::$BASE_URL . "{$endpoint}" . ($query ? "?{$query}" : '');

        $headers = [
            "Authorization: Bearer {$token['accessToken']}",
            "Accept: application/json"
        ];
        if ($method === 'POST' && $body !== null) {
            $headers[] = 'Content-Type: application/json';
            $body = json_encode($body);
        }
        $res = $this->curl_request($method, $url, $headers, $body);
        error_log(var_export($res, true));
        $isExpired = false;

        if ($res['code'] === 401) {
            $isExpired = true;
        } elseif (is_array($res['body']) && isset($res['body']['errorCode'])) {
            $code = $res['body']['errorCode'];
            if (in_array($code, ['token.expired', 'invalid.request_body', '401', '403'])) {
                $isExpired = true;
            }
        }

        if ($isExpired && $retry) {
            try {
                if (!empty($token['refreshToken'])) {
                    $token = $this->refreshToken($token['refreshToken']);
                } else {
                    $token = $this->generateToken();
                }

                $headers[0] = "Authorization: Bearer {$token['accessToken']}";
                if ($method === 'POST' && $body !== null) {
                    if (!is_string($body)) {
                        $body = json_encode($body);
                    }
                    $headers[] = 'Content-Type: application/json';
                }

                $res = $this->curl_request($method, $url, $headers, $body);
            } catch (\Exception $e) {
                return ['code' => 500, 'body' => ['error' => $e->getMessage()]];
            }
        }

        return $res;
    }
}
