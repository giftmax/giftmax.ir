<?php
/**
 * Plugin Name: Giftmax Payments
 * Description: افزودن درگاه‌های Zibal، Zarinpal، کیف پول و Payment4 به ووکامرس
 * Version: 1.0
 * Author: Giftmax
 */

namespace Giftmax\Modules;

if ( ! defined( 'ABSPATH' ) ) exit;

// --------------- Zibal ------------------
class Gateway_Zibal extends \WC_Payment_Gateway {

    public string $api_key;

    public function __construct() {
        $this->id = 'zibal';
        $this->method_title = 'درگاه زیبال';
        $this->has_fields = false;

        $this->init_form_fields();
        $this->init_settings();

        $this->title = $this->get_option('title');
        $this->api_key = $this->get_option('api_key');
        $this->enabled = $this->get_option('enabled');

        add_action(
            'woocommerce_update_options_payment_gateways_' . $this->id,
            [$this, 'process_admin_options']
        );
    }
    public function init_form_fields() {
        $this->form_fields = [
            'enabled' => [
                'title'   => 'فعال/غیرفعال',
                'type'    => 'checkbox',
                'label'   => 'فعال کردن درگاه زیبال',
                'default' => 'no'
            ],
            'api_key' => [
                'title'       => 'کلید API',
                'type'        => 'text',
                'description' => 'کلید API دریافتی از پنل زیبال',
                'default'     => '',
                'desc_tip'    => true
            ]
        ];
    }
}

// --------------- Paystar ------------------
class Gateway_Paystar extends \WC_Payment_Gateway {
    public string $sign;
    public string $gateway_id;

    public function __construct() {
        $this->id           = 'paystar';
        $this->method_title = 'درگاه پی استار';
        $this->has_fields   = false;

        $this->init_form_fields();
        $this->init_settings();

        $this->sign        = $this->get_option('sign');
        $this->gateway_id  = $this->get_option('gateway_id');
        $this->enabled = $this->get_option('enabled');

        add_action(
            'woocommerce_update_options_payment_gateways_' . $this->id,
            [$this, 'process_admin_options']
        );
    }

    public function init_form_fields() {
        $this->form_fields = [
            'enabled' => [
                'title'   => 'فعال/غیرفعال',
                'type'    => 'checkbox',
                'label'   => 'فعال کردن درگاه پی استار',
                'default' => 'no'
            ],
            'sign'        => ['title' => 'sign',       'type' => 'text', 'default' => ''],
            'gateway_id'  => ['title' => 'gateway_id', 'type' => 'text', 'default' => ''],
        ];
    }
}

// --------------- Payment4 ------------------
class Gateway_Payment4 extends \WC_Payment_Gateway {
    public string $api_key;

    public function __construct() {
        $this->id='Payment4';
        $this->method_title='Payment4';
        $this->has_fields=false;

        $this->init_form_fields();
        $this->init_settings();


        $this->api_key = $this->get_option('api_key');
        $this->enabled = $this->get_option('enabled');
        add_action('woocommerce_update_options_payment_gateways_'.$this->id, array($this,'process_admin_options'));
    }

    public function init_form_fields() {
        $this->form_fields=[
            'enabled' => [
                'title'   => 'Enable/Disable',
                'type'    => 'checkbox',
                'label'   => 'Enable Payment4 Gateway',
                'default' => 'no'
            ],
            'api_key' => [
                'title' => 'API Key',
                'type' => 'text',
                'default' => ''
            ]
        ];
    }
}

class Payment
{
    public function __construct() {
        add_filter('woocommerce_payment_gateways', function($methods){
            $methods[] = Gateway_Zibal::class;
            $methods[] = Gateway_Paystar::class;
            $methods[] = Gateway_Payment4::class;
            return $methods;
        });

    }
}