<?php
namespace Giftmax\Modules;

class UserModel
{
    public function __construct()
    {}

    public static function insertUser($user_id, $nationalID, $birthDate, $CardNumber,$hash,$is_verified) {
        global $wpdb;
        $db = Db::getLnstance();
        $recordUser = UserModel::table('user_identity','user_id', $user_id);
        if(!empty($recordUser)){
            $db->modify("DELETE FROM `{$wpdb->prefix}user_identity` WHERE id = :id",["id"=>$recordUser['id']]);
        }
        $recordCard = UserModel::table('user_bank_cards','user_id', $user_id,'card_number_enc',encrypt_data($CardNumber));
        if(!empty($recordCard)){
            $db->modify("DELETE FROM `{$wpdb->prefix}user_bank_cards` WHERE id = :id",["id"=>$recordCard['id']]);
        }
        $db->insert("INSERT INTO `{$wpdb->prefix}user_identity` (`user_id`, `national_id_enc`, `birth_date_enc`, `landline_phone`, `account_type`, `is_verified`, `is_vip`) VALUES (:user_id, :national_id, :birth_date, :landline, :account_type, :is_verified, :is_vip)", array(
                'user_id'      => $user_id,
                'national_id'  => encrypt_data($nationalID),
                'birth_date'   => encrypt_data($birthDate),
                'landline'     => '',
                'account_type' => 'normal',
                'is_verified'  => $is_verified,
                'is_vip'       => 0,
            )
        );
        $db->insert("INSERT INTO `{$wpdb->prefix}user_bank_cards` (`user_id`, `hash`, `card_number_enc`, `card_last4`, `is_active`,`ip`,`created_at`) VALUES (:user_id, :hash, :card_number, :card_last4, :is_active,:ip,:created_at)",array(
            'user_id'     => $user_id,
            'card_number' => encrypt_data($CardNumber),
            'hash' => $hash,
            'card_last4'  => substr($CardNumber, -4),
            'ip'  => encrypt_data(giftmax_get_user_ip()),
            'is_active'   => 0,
            'created_at'   => date('Y-m-d H:i:s'),
        ));
        $db->insert("INSERT INTO `{$wpdb->prefix}user_points` (`user_id`, `points`) VALUES (:user_id, 0)",array('user_id'=> $user_id));
        $db->insert("INSERT INTO `{$wpdb->prefix}wallet` (`user_id`, `balance`) VALUES (:user_id, 0)",array('user_id'=> $user_id));
    }
    public static function registerUser($UserLogin,$hash) {
        global $wpdb;
        $db = Db::getLnstance();
        $records = self::table('token_register',`UserLogin`,$UserLogin);
        if (!empty($records)){
            self::TokenRegisterDelete($records['id']);
        }
        $db->insert("INSERT INTO `{$wpdb->prefix}token_register`(`id`,`UserLogin`, `hash`) VALUES (NULL,:UserLogin,:hash)", array(
                'UserLogin' => $UserLogin,
                'hash'  => $hash
            )
        );
    }

    public static function table($name,$option = null , $method = null,$optionTwo = null , $methodTwo = null,$query = false){
        global $wpdb;
        $db = Db::getLnstance();
        if (is_null($option)) {
            $records = $db->first("SELECT * FROM `{$wpdb->prefix}$name`");
        }elseif(is_null($optionTwo)){
            $records = $db->first("SELECT * FROM `{$wpdb->prefix}$name` WHERE $option=:option",array('option'=>$method));
        }elseif (!$query){
            $records = $db->first("SELECT * FROM `{$wpdb->prefix}$name` WHERE $option=:option AND `$optionTwo` =:optiot ",array('option'=>$method,'optiot'=>$methodTwo));
        }elseif ($query){
            $records = $db->query("SELECT * FROM `{$wpdb->prefix}$name` WHERE $option=:option AND `$optionTwo` =:optiot ",array('option'=>$method,'optiot'=>$methodTwo));
        }
        return $records;
    }
    public static function otp($phone,$otp,$expiry){
        global $wpdb;
        $db = Db::getLnstance();
        $db->insert("INSERT INTO `{$wpdb->prefix}otp` (`id`, `phone`, `otp`, `otp_expiry`) VALUES (NULL, :phone, :otp,:expiry)", array("phone" => $phone, "otp" => $otp, "expiry" => $expiry));
        }
    public static function exitOtp($phone,$otp=null,$method=null){
        global $wpdb;
        $db = Db::getLnstance();
        if ($otp!=null){
            $records = $db->first("SELECT * FROM `{$wpdb->prefix}otp` WHERE phone=:phonenumber AND $otp=:method", array("phonenumber" => $phone, "method" => $method));
        }else {
            $records = $db->first("SELECT * FROM `{$wpdb->prefix}otp` WHERE phone=:phonenumber", array("phonenumber" => $phone));
        }
        return $records;
    }
    public static function otpDelete($id){
        global $wpdb;
        $db = Db::getLnstance();
        $db->modify("DELETE FROM `{$wpdb->prefix}otp` WHERE `id` = :id",array("id" => $id));
    }
    public static function TokenRegisterDelete($id){
        global $wpdb;
        $db = Db::getLnstance();
        $db->modify("DELETE FROM `{$wpdb->prefix}token_register` WHERE `id` = :id",array("id" => $id));
    }

    public static function expiryEnd(){
        global $wpdb;
        $db = Db::getLnstance();
        $time = date("Y-m-d H:i:s");
        $db->modify( "DELETE FROM `{$wpdb->prefix}otp` WHERE otp_expiry < :time",array("time" => $time));
    }
    public static function phone($number){
        global $wpdb;
        $db = Db::getLnstance();
        $records = $db->query('SELECT * FROM ' . $wpdb->prefix .'users WHERE user_login=:user_login',array('user_login'=>$number));
        if(is_array($records)){
            return 1;
        }else{
            return 0;
        }

    }
    public static function wallet($user_id = null){
        global $wpdb;
        $db = Db::getLnstance();
        if ($user_id == null) {
            $user_id = get_current_user_id();
        }
        $records = $db->first('SELECT * FROM ' . $wpdb->prefix .'wallet WHERE user_id=:user_id',array('user_id'=>$user_id));
        if(is_array($records)){
            return $records['balance'];
        }else{
            return 0;
        }
    }
    public static function points($user_id = null){
        global $wpdb;
        $db = Db::getLnstance();
        if ($user_id == null) {
            $user_id = get_current_user_id();
        }
        $records = $db->first('SELECT * FROM ' . $wpdb->prefix .'user_points WHERE user_id=:user_id',array('user_id'=>$user_id));
        if(is_array($records)){
            return $records['points'];
        }else{
            return 0;
        }
    }
    public static function wallet_transactions(){
        global $wpdb;
        $db = Db::getLnstance();
        $user_id = get_current_user_id();
        $records = $db->query('SELECT * FROM ' . $wpdb->prefix .'wallet_transactions WHERE user_id=:user_id ORDER BY created_at DESC LIMIT 10',array('user_id'=>$user_id));
        return $records;
    }
    public static function walletTransactionsAll($limit=10){
        global $wpdb;
        $db = Db::getLnstance();
        $records = $db->query("SELECT * FROM {$wpdb->prefix}wallet_transactions ORDER BY created_at DESC LIMIT $limit");
        return $records;
    }
    public static function walletTransactionsAllUser($userId,$limit=10){
        global $wpdb;
        $db = Db::getLnstance();
        $records = $db->query("SELECT * FROM {$wpdb->prefix}wallet_transactions WHERE user_id=:user_id ORDER BY created_at DESC LIMIT $limit",['user_id'=>$userId]);
        return $records;
    }
    public static function setting($key):bool{
        $db = Db::getLnstance();
        global $wpdb;
        $records = $db->first("SELECT meta_value FROM `{$wpdb->prefix}setting` WHERE `meta_key`=:key",array('key'=>$key));
        return !is_null($records) ? $records['meta_value'] : 0;
    }
    public static function settingValue($key){
        $db = Db::getLnstance();
        global $wpdb;
        $records = $db->first("SELECT meta_value FROM `{$wpdb->prefix}setting` WHERE `meta_key`=:key",array('key'=>$key));
        return !is_null($records) ? $records['meta_value'] : '';
    }
    public static function user_id__document(){
        $db = Db::getLnstance();
        global $wpdb;
        $records = $db->query("SELECT DISTINCT user_id FROM `{$wpdb->prefix}documents` WHERE accepted=0");
        return $records;
    }
    public static function alert($user_id,$notificationsId){
        $db = Db::getLnstance();
        global $wpdb;
        $records = self::table('alert','userId',$user_id);
        if (empty($records)) {
            $db->insert("INSERT INTO `{$wpdb->prefix}alert` (`userId`,`notificationsId`,`hash`) VALUES (:user_id,:notificationsId,:hash)", array(
                'user_id' => $user_id,
                'notificationsId' => $notificationsId,
                'hash' => generateHash()
            ));
        }else{
            $db->modify("UPDATE `{$wpdb->prefix}alert` SET `notificationsId`=:notificationsId,`hash`=:hash WHERE `userId` = :userId",array(
                'userId' => $user_id,
                'notificationsId' => $notificationsId,
                'hash' => generateHash()
            ));
        }
        return $records;
    }
    public static function deleteAlert($user_id,$notificationsId,$m=0){
        $db = Db::getLnstance();
        global $wpdb;
        if ($m ==0) {
            $records = self::table('alert', 'userId', $user_id, 'notificationsId', $notificationsId);
        }else{
            $records = self::table('alert', 'hash', $notificationsId);
        }
        if (!empty($records)) {
            $db->modify("DELETE FROM `{$wpdb->prefix}alert` WHERE `Id` = :id",array("id" => $records['Id']));
        }
        return $records;
    }
    public static function search($key){
        global $wpdb;
        $db = Db::getLnstance();
        $records = $db->query("SELECT * FROM {$wpdb->prefix}ticketing_category WHERE `name` LIKE :key", array('key' => '%' . $key . '%'));
        return $records;
    }
    private static function formatKeysSelect($data) {
        $keys = array_keys($data);


        return implode(' AND ', array_map(function($key) {
            return "$key=:$key";
        }, $keys));

    }
    public static function tableSearch($table,$method,$data = '',$s=1){
        global $wpdb;
        $db = Db::getLnstance();
        if ($s == 0) {
            $records = $db->$method("SELECT * FROM `{$wpdb->prefix}$table`");
        }else{
            $dataSql = self::formatKeysSelect($data);
            $records = $db->$method("SELECT * FROM `{$wpdb->prefix}$table` WHERE $dataSql",$data);
        }
        return $records;
    }
}
