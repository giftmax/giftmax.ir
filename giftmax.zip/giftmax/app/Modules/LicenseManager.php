<?php

namespace Giftmax\Modules;

class LicenseManager
{
    public function __construct(){

    }
    public static function license($product_id,$licence_code,$cost_price,$description) : void {
        global $wpdb;
        $db = Db::getLnstance();
        $records = $db->first("SELECT * FROM `{$wpdb->prefix}product_licences` WHERE `licence_code`=:licence_code",array('licence_code'=>$licence_code));
        if (empty($records)) {
            $db->insert("INSERT INTO `{$wpdb->prefix}product_licences` (`product_id`, `licence_code`,`description`, `licence_status`, `cost_price`, `created_at`) VALUES (:product_id,:licence_code,:description,'available',:cost_price,:created_at)", array(
                'product_id' => $product_id,
                'licence_code' => encrypt_data($licence_code),
                'description' => $description,
                'cost_price' => $cost_price,
                'created_at' => date('Y-m-d H:i:s')
            ));
        }
    }
    public static function AdminLicense($product_id) : array {
        global $wpdb;
        $db = Db::getLnstance();
        $records = $db->query("SELECT * FROM `{$wpdb->prefix}product_licences` WHERE `product_id`=:product_id AND licence_status='available' ORDER BY sort_order ASC",array('product_id'=>$product_id));
        return is_array($records) ? $records : [];
    }
    public static function ShowLicense($licence_id,$order_id) : array {
        global $wpdb;
        $db = Db::getLnstance();
        $records = $db->first("SELECT * FROM {$wpdb->prefix}product_licences WHERE licence_id = :licence_id AND order_id=:order_id AND licence_status='assigned'", array(
            'licence_id' => $licence_id,
            'order_id' => $order_id
            )
        );
        return is_array($records) ? $records : [];
    }
}