<?php
namespace Giftmax\Modules;

if (!defined('ABSPATH')) exit;

class addShortcode {

    public function __construct() {

        add_shortcode( 'gift_Login', [$this, 'formLogin'] );
        add_shortcode( 'gift_index', [$this, 'pageIndex'] );
        add_shortcode( 'giftmax_profile', [$this, 'pageProfile'] );
        add_shortcode( 'giftmax_ticket', [$this, 'pageTicket'] );
        add_shortcode( 'giftmax_blogs', [$this, 'pageBlogs'] );
        add_shortcode( 'giftmax_notifications', [$this, 'pageNotifications'] );
        add_shortcode( 'giftmax_contact', [$this, 'pageContact'] );
        add_shortcode( 'giftmax_incredible_offers', [$this, 'pageIncredibleOffers'] );
        add_shortcode( 'giftmax_connect_bot', [$this, 'pageConnectBot'] );
    }

    public  function formLogin(){
        if ( !is_user_logged_in() ) {
            ob_start();
            get_template_part( 'inc/templates/template-parts/login/login_template', null, null );
        }else{
            header("location: " . home_url('/profile')); ;
            exit;
        }
    }
    public  function pageContact(){
        ob_start();
        get_template_part( 'inc/templates/template-parts/page/contact', null, null );
    }
    public  function pageProfile(){
        if ( is_user_logged_in() ) {
            $tab = get_query_var('profile_tab');
            $order_id = get_query_var('order_id');
            ob_start();
            switch ($tab) {
                case 'orders':
                    get_template_part(
                        'inc/templates/template-parts/profile/orders'
                    );
                    break;

                case 'edit':
                    get_template_part(
                        'inc/templates/template-parts/profile/edit'
                    );
                    break;

                case 'deliveries':
                    get_template_part(
                        'inc/templates/template-parts/profile/deliveries'
                    );
                    break;

                case 'wallet':
                    get_template_part(
                        'inc/templates/template-parts/profile/wallet'
                    );
                    break;
                case 'verification':
                    get_template_part(
                        'inc/templates/template-parts/profile/verification'
                    );
                    break;
                case 'invoices':
                    set_query_var('order_id', $order_id);

                    get_template_part(
                        'inc/templates/template-parts/profile/invoices'
                    );
                    break;
                case 'coupons':
                    get_template_part(
                        'inc/templates/template-parts/profile/coupons'
                    );
                    break;
                case 'cards':
                    get_template_part(
                        'inc/templates/template-parts/profile/cards'
                    );
                    break;
                case 'post':
                    get_template_part(
                        'inc/templates/template-parts/profile/post'
                    );
                    break;
                case 'list':
                    get_template_part(
                        'inc/templates/template-parts/profile/list'
                    );
                    break;
                case 'user':
                    get_template_part(
                        'inc/templates/template-parts/profile/user'
                    );
                    break;
                default:
                    get_template_part(
                        'inc/templates/template-parts/profile/index'
                    );
            }
        }else{
             header("location: " . home_url('/login-register')); ;
            exit;
        }
    }
    public  function pageTicket(){

        if ( is_user_logged_in() ) {
            if (current_user_can('administrator')) {
                $p = 'ticket_admin';
            }else{
                $p = 'ticket';
            }
            ob_start();
            ?>
            <svg style="display: none"><symbol id="closeFill" version="1.1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><title>closeFill</title><path d="M4.929 4.929c3.905-3.905 10.237-3.905 14.142 0s3.905 10.237 0 14.142c-3.905 3.905-10.237 3.905-14.142 0s-3.905-10.237 0-14.142zM14.828 7.757l-2.828 2.828-2.828-2.828-1.414 1.414 2.828 2.828-2.828 2.828 1.414 1.414 2.828-2.828 2.828 2.828 1.414-1.414-2.828-2.828 2.828-2.828-1.414-1.414z"></path></symbol><symbol id="add" version="1.1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><title>add</title><path d="M13 11h4v2h-4v4h-2v-4h-4v-2h4v-4h2v4zM12 22c-5.523 0-10-4.477-10-10s4.477-10 10-10c5.523 0 10 4.477 10 10s-4.477 10-10 10zM12 20c4.418 0 8-3.582 8-8s-3.582-8-8-8c-4.418 0-8 3.582-8 8s3.582 8 8 8z"></path></symbol><symbol id="delete" version="1.1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><title>delete</title><path d="M17 8h2v11c0 1.657-1.343 3-3 3h-8c-1.657 0-3-1.343-3-3v-11h2v11c0 0.552 0.448 1 1 1h8c0.552 0 1-0.448 1-1v-11zM4 7v-2h16v2h-16zM9 8h2v10h-2v-10zM13 8h2v10h-2v-10zM8 4v-2h8v2h-8z"></path></symbol><symbol id="fileDoc" version="1.1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><title>file-doc</title><path d="M13.172 2c0.53 0 1.039 0.211 1.414 0.586v0l4.828 4.828c0.375 0.375 0.586 0.884 0.586 1.414v0 10.172c0 1.657-1.343 3-3 3v0h-9.999c-1.657 0-3.001-1.344-3-3.001v0l0.007-14c0.001-1.656 1.344-2.998 3-2.998v0zM13 4h-6c-0.552 0-1 0.448-1 1v14c0 0.552 0.448 1 1 1h10c0.552 0 1-0.448 1-1v-10h-4c-0.552 0-1-0.448-1-1v-4z"></path></symbol><symbol id="infoFilled" version="1.1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><title>infoFilled</title><path d="M2 12c0 5.523 4.477 10 10 10s10-4.477 10-10c0-5.523-4.477-10-10-10s-10 4.477-10 10zM12 7c0.552 0 1 0.448 1 1s-0.448 1-1 1c-0.552 0-1-0.448-1-1s0.448-1 1-1zM10 10h3v7h-2v-5h-1v-2z"></path></symbol><symbol id="uploadExcel2" version="1.1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><title>uploadExcel2</title><path d="M13.17 2c0.471 0 0.926 0.166 1.284 0.467l0.13 0.119 4.828 4.828c0.333 0.333 0.537 0.772 0.578 1.238l0.008 0.176v10.172c0 1.598-1.249 2.904-2.824 2.995l-0.176 0.005h-9.999c-1.598 0-2.904-1.25-2.995-2.825l-0.005-0.176 0.007-14c0.001-1.597 1.25-2.902 2.824-2.993l0.176-0.005h6.163zM12.999 4h-6c-0.552 0-1 0.448-1 1v14c0 0.552 0.448 1 1 1h10c0.552 0 1-0.448 1-1v-10h-4c-0.552 0-1-0.448-1-1v-4zM10.715 11l1.288 1.789 1.287-1.789h2.464l-2.519 3.5 2.519 3.5h-2.464l-1.287-1.788-1.288 1.788h-2.465l2.521-3.5-2.521-3.5h2.465z"></path></symbol><symbol id="closeBold" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="M12 11.0537C12 11.0537 16.2827 6.77342 17.8617 5.19523C18.1221 4.93492 18.5443 4.93492 18.8047 5.19523C19.0651 5.45553 19.0651 5.87753 18.8047 6.13783C17.2257 7.71602 12.9391 12 12.9391 12C12.9391 12 17.2257 16.284 18.8047 17.8622C19.0651 18.1225 19.0651 18.5445 18.8047 18.8047C18.5443 19.0651 18.1221 19.0651 17.8617 18.8048C16.2827 17.2266 12 12.9463 12 12.9463C12 12.9463 7.7173 17.2266 6.1383 18.8048C5.8779 19.0651 5.4557 19.0651 5.1953 18.8048C4.9349 18.5445 4.9349 18.1225 5.1953 17.8622C6.7743 16.284 11.0609 12 11.0609 12C11.0609 12 6.7743 7.71602 5.1953 6.13783C4.9349 5.87753 4.9349 5.45552 5.1953 5.19533C5.4557 4.93493 5.8779 4.93492 6.1383 5.19523C7.7173 6.77342 12 11.0537 12 11.0537Z"></path></symbol><symbol id="chevronLeft2" viewBox="0 0 25 24" xmlns="http://www.w3.org/2000/svg"><path d="M11.1642 12L15.4571 16.2928L14.0429 17.7071L9.04289 12.7071C8.65237 12.3165 8.65237 11.6834 9.04289 11.2928L14.0429 6.29285L15.4571 7.70706L11.1642 12Z"></path></symbol><symbol id="attach" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="M12.025 22.525C10.3417 22.525 8.91667 21.9417 7.75 20.775C6.58333 19.6083 6 18.1833 6 16.5V5.8C6 4.56667 6.42934 3.51667 7.288 2.65C8.146 1.78333 9.18333 1.35 10.4 1.35C11.6333 1.35 12.6833 1.78333 13.55 2.65C14.4167 3.51667 14.85 4.56667 14.85 5.8V15.375C14.85 16.175 14.575 16.8457 14.025 17.387C13.475 17.929 12.8083 18.2 12.025 18.2C11.2417 18.2 10.575 17.929 10.025 17.387C9.475 16.8457 9.2 16.175 9.2 15.375V5.8H11.15V15.375C11.15 15.6417 11.2333 15.8627 11.4 16.038C11.5667 16.2127 11.775 16.3 12.025 16.3C12.275 16.3 12.4833 16.2127 12.65 16.038C12.8167 15.8627 12.9 15.6417 12.9 15.375V5.8C12.9 5.1 12.6583 4.50833 12.175 4.025C11.6917 3.54167 11.1 3.3 10.4 3.3C9.7 3.3 9.10833 3.54167 8.625 4.025C8.14167 4.50833 7.9 5.1 7.9 5.8V16.5C7.9 17.6333 8.30433 18.6043 9.113 19.413C9.921 20.221 10.8917 20.625 12.025 20.625C13.1583 20.625 14.1293 20.221 14.938 19.413C15.746 18.6043 16.15 17.6333 16.15 16.5V5.8H18.05V16.5C18.05 18.1833 17.4667 19.6083 16.3 20.775C15.1333 21.9417 13.7083 22.525 12.025 22.525Z"></path></symbol><symbol id="submit" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M18.5808 4.09383C18.8905 3.94929 19.2526 3.97293 19.5409 4.15653C19.8292 4.34012 20.0037 4.65822 20.0037 5L20.0037 19.0042C20.0037 19.346 19.8292 19.6641 19.5409 19.8477C19.2526 20.0313 18.8905 20.055 18.5808 19.9104L3.5771 12.9083C3.22503 12.744 3 12.3906 3 12.0021C3 11.6136 3.22503 11.2603 3.5771 11.0959L18.5808 4.09383ZM18.0037 10.3689V6.57024L6.3646 12.0021L18.0037 17.434V13.6311L11.9693 12.4913C11.7331 12.4467 11.5621 12.2404 11.5621 12C11.5621 11.7596 11.7331 11.5533 11.9693 11.5087L18.0037 10.3689Z"></path></symbol><symbol id="arrowBack" version="1.1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><title>arrowBack</title><path d="M12.707 19.707l-1.414-1.414 5.293-5.293h-12.586v-2h12.586l-5.293-5.293 1.414-1.414 7 7c0.39 0.391 0.39 1.024 0 1.414l-7 7z"></path></symbol><symbol id="chevronDown" version="1.1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 41 24"><title>chevronDown</title><path d="M1.714 5.332l2.491-2.466 16.366 16.203 16.366-16.203 2.491 2.466-18.857 18.668-18.857-18.668z"></path></symbol><symbol id="arrowRight" version="1.1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><title>arrowRight</title><path d="M13.583 12l-4.293 4.293 1.414 1.414 5-5c0.39-0.391 0.39-1.024 0-1.414l-5-5-1.414 1.414 4.293 4.293z"></path></symbol><symbol id="arrowLeft" version="1.1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><title>arrowLeft</title><path d="M10.414 12l4.293 4.293-1.414 1.414-5-5c-0.391-0.391-0.391-1.024 0-1.414l5-5 1.414 1.414-4.293 4.293z"></path></symbol><symbol id="filter" version="1.1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><title>filter</title><path d="M8 8c-1.657 0-3-1.343-3-3s1.343-3 3-3c1.657 0 3 1.343 3 3s-1.343 3-3 3zM8 6c0.552 0 1-0.448 1-1s-0.448-1-1-1c-0.552 0-1 0.448-1 1s0.448 1 1 1zM13.171 11c0.412-1.165 1.523-2 2.829-2s2.417 0.835 2.829 2h3.171v2h-3.171c-0.412 1.165-1.523 2-2.829 2s-2.417-0.835-2.829-2h-11.171v-2h11.171zM5.171 18c0.412-1.165 1.523-2 2.829-2s2.417 0.835 2.829 2h11.171v2h-11.171c-0.412 1.165-1.523 2-2.829 2s-2.417-0.835-2.829-2h-3.171v-2h3.171zM16 13c0.552 0 1-0.448 1-1s-0.448-1-1-1c-0.552 0-1 0.448-1 1s0.448 1 1 1zM8 20c0.552 0 1-0.448 1-1s-0.448-1-1-1c-0.552 0-1 0.448-1 1s0.448 1 1 1zM10 6v-2h12v2h-12zM2 6v-2h4v2h-4z"></path></symbol><symbol id="arrowDownFill" version="1.1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><title>arrowDownFill</title><path d="M17 10h-10l4.293 4.293c0.39 0.39 1.024 0.39 1.414 0l4.293-4.293z"></path></symbol><symbol id="addInput" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="M13 4H11V11H4V13H11V20H13V13H20V11H13V4Z"></path></symbol><symbol id="search" version="1.1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><title>search</title><path d="M10.5 3c4.142 0 7.5 3.358 7.5 7.5 0 1.71-0.572 3.287-1.536 4.548l4.536 4.536-1.414 1.414-4.536-4.536c-1.262 0.964-2.839 1.537-4.55 1.537-4.142 0-7.5-3.358-7.5-7.5s3.358-7.5 7.5-7.5zM10.5 5c-3.038 0-5.5 2.462-5.5 5.5s2.462 5.5 5.5 5.5c3.038 0 5.5-2.462 5.5-5.5s-2.462-5.5-5.5-5.5z"></path></symbol><symbol id="close" version="1.1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><title>close</title><path d="M18.364 7.050l-1.414-1.414-4.95 4.95-4.95-4.95-1.414 1.414 4.95 4.95-4.95 4.95 1.414 1.414 4.95-4.95 4.95 4.95 1.414-1.414-4.95-4.95 4.95-4.95z"></path></symbol><symbol id="discount" version="1.1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><title>discount</title><path d="M20.5 4c1.325 0 2.41 1.032 2.495 2.336l0.005 0.164v11c0 1.325-1.032 2.41-2.336 2.495l-0.164 0.005h-13.7c-0.578 0-1.136-0.2-1.58-0.563l-0.144-0.127-3.3-3.143c-0.45-0.429-0.723-1.009-0.769-1.625l-0.007-0.186v-4.714c0-0.622 0.232-1.219 0.646-1.677l0.13-0.133 3.3-3.143c0.418-0.398 0.96-0.638 1.532-0.682l0.192-0.007h13.7zM20.5 6h-13.7c-0.096 0-0.19 0.028-0.27 0.079l-0.075 0.059-3.3 3.143c-0.079 0.075-0.131 0.174-0.149 0.281l-0.007 0.081v4.714c0 0.11 0.036 0.215 0.101 0.301l0.054 0.061 3.3 3.143c0.070 0.066 0.157 0.111 0.25 0.129l0.095 0.009h13.7c0.245 0 0.45-0.177 0.492-0.41l0.008-0.090v-11c0-0.276-0.224-0.5-0.5-0.5zM18.793 7.793l1.414 1.414-7 7-1.414-1.414 7-7zM18.5 13c0.828 0 1.5 0.672 1.5 1.5s-0.672 1.5-1.5 1.5c-0.828 0-1.5-0.672-1.5-1.5s0.672-1.5 1.5-1.5zM7 9c1.657 0 3 1.343 3 3s-1.343 3-3 3c-1.657 0-3-1.343-3-3s1.343-3 3-3zM7 11c-0.552 0-1 0.448-1 1s0.448 1 1 1c0.552 0 1-0.448 1-1s-0.448-1-1-1zM13.5 8c0.828 0 1.5 0.672 1.5 1.5s-0.672 1.5-1.5 1.5-1.5-0.672-1.5-1.5c0-0.828 0.672-1.5 1.5-1.5z"></path></symbol></svg>

            <?php
            $tab = get_query_var('ticket_tab');
            $id = get_query_var('id');
            ob_start();
            switch ($tab) {
                case 'id':
                    set_query_var('id', $id);
                    get_template_part('inc/templates/template-parts/ticket/index_'.$p);
                    break;
                default:
                    ?>
                <style>
                    @media (max-width: 768px) {
                        #go-to-blabla {
                            bottom: 158px !important;
                        }
                    }
                </style>
                <?php
                    get_template_part('inc/templates/template-parts/ticket/'.$p);
            }
        }else{
            header("location: " . home_url('/login-register')); ;
            exit;
        }
    }
    public function pageNotifications(){

        if ( is_user_logged_in() ) {
            ob_start();
            ?>
            <svg style="display: none"><symbol id="notificationBellRead" version="1.1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><title>notificationBellRead</title><path d="M15 21c-0.437 1.165-1.615 2-3 2s-2.563-0.835-3-2h6zM12 2c1.929 0 3.734 0.786 5.041 2.143l0.192 0.208-1.495 1.329c-0.944-1.062-2.29-1.68-3.739-1.68-2.689 0-4.882 2.122-4.995 4.783l-0.005 0.217v3c0 1.424-0.751 2.704-1.918 3.416l-0.082 0.047-0.001 2.537h14.001v-2.537l-0.081-0.046c-1.109-0.676-1.843-1.866-1.913-3.204l-0.006-0.212h2c0 0.855 0.541 1.606 1.333 1.886 0.36 0.127 0.612 0.446 0.659 0.817l0.008 0.126v4.171c0 0.513-0.386 0.936-0.883 0.993l-0.117 0.007h-16c-0.513 0-0.936-0.386-0.993-0.884l-0.007-0.117 0.001-4.171c0-0.381 0.216-0.725 0.551-0.893l0.116-0.049c0.743-0.263 1.264-0.94 1.326-1.727l0.006-0.159v-3c0-3.866 3.134-7 7-7zM18.793 5.793l1.414 1.414-7.5 7.5c-0.36 0.36-0.928 0.388-1.32 0.083l-0.094-0.083-3-3 1.414-1.414 2.293 2.292 6.793-6.792z"></path></symbol><symbol id="notificationBell" version="1.1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><title>notificationBell</title><path d="M9 21h6c-0.437 1.165-1.615 2-3 2s-2.563-0.835-3-2zM5 18h14v-2.535c-1.214-0.701-2-2.008-2-3.465v-3c0-2.761-2.239-5-5-5s-5 2.239-5 5v3c0 1.457-0.786 2.764-2 3.465v2.535zM3.667 13.886c0.792-0.28 1.333-1.032 1.333-1.886v-3c0-3.866 3.134-7 7-7s7 3.134 7 7v3c0 0.855 0.541 1.606 1.333 1.886 0.4 0.141 0.667 0.519 0.667 0.943v4.171c0 0.552-0.448 1-1 1h-16c-0.552 0-1-0.448-1-1v-4.171c0-0.424 0.267-0.802 0.667-0.943z"></path></symbol><symbol id="expandLess" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="M6.69251 13.3075L11.2929 8.70711C11.6834 8.31658 12.3166 8.31658 12.7071 8.70711L17.3075 13.3075C17.5008 13.5008 17.5008 13.8142 17.3075 14.0075L17.305 14.01C17.1085 14.2037 16.7926 14.2026 16.5975 14.0075L12 9.41L7.40251 14.0075C7.20742 14.2026 6.89147 14.2037 6.695 14.01C6.50033 13.8181 6.49811 13.5047 6.69004 13.31C6.69086 13.3092 6.69169 13.3083 6.69251 13.3075Z"></path></symbol><symbol id="expandMore" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="M6.69251 10.6925C6.69169 10.6917 6.69086 10.6909 6.69004 10.69C6.49811 10.4953 6.50033 10.1819 6.695 9.99C6.89147 9.7963 7.20742 9.79742 7.40251 9.99251L12 14.59L16.5975 9.99251C16.7926 9.79742 17.1085 9.7963 17.305 9.99C17.3058 9.99082 17.3067 9.99165 17.3075 9.99248C17.5008 10.1858 17.5008 10.4992 17.3075 10.6925L12.7071 15.2929C12.3166 15.6834 11.6834 15.6834 11.2929 15.2929L6.69251 10.6925Z"></path></symbol><symbol id="expandMoreBold" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="M6.51821 9.81322C6.81321 9.52238 7.28761 9.52406 7.58053 9.81699L12 14.2364L16.4195 9.81699C16.7124 9.52406 17.1868 9.52238 17.4818 9.81322C17.483 9.81445 17.4843 9.81569 17.4855 9.81693C17.7758 10.1072 17.7758 10.5778 17.4855 10.868L12.7071 15.6464C12.3166 16.037 11.6834 16.037 11.2929 15.6464L6.51447 10.868C6.51323 10.8668 6.51199 10.8655 6.51076 10.8643C6.22257 10.572 6.22591 10.1014 6.51821 9.81322Z"></path></symbol></svg>
            <?php
            get_template_part( 'inc/templates/template-parts/page/notifications', null, null );
        }else{
            header("location: " . home_url('/login-register')); ;
            exit;
        }
    }
    public function pageBlogs(){
        get_template_part( 'inc/templates/template-parts/page/blogs', null, null );
    }
    public function pageIncredibleOffers(){
        get_template_part( 'inc/templates/template-parts/page/incredible-offers', null, null );
    }
    public function pageIndex(){
        get_template_part( 'inc/templates/template-parts/page/index', null, null );
    }
}
