<?php

namespace Giftmax\woo;
use Giftmax\model\UserModel;
use Giftmax\modules\Db;
use Giftmax\templates\AdminProductTemplate;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class ProductHooks {
    const SCREENS = [
            'product' => 'product',
            'shop_coupon' => 'shop_coupon'
    ];
    public function __construct() {
       add_filter('cron_schedules', function ($schedules) {
            $schedules['every_minute'] = [
                'interval' => 60,
                'display' => 'هر دقیقه'
            ];
           $schedules['fifteen_minutes'] = [
                   'interval' => 900,
                   'display' => 'Every 10 Minutes'
           ];
            return $schedules;
        });
        add_action('init', function () {
            if (!wp_next_scheduled('giftmax_auto_clear_expired_carts_event')) {
                wp_schedule_event(time(), 'every_minute', 'giftmax_auto_clear_expired_carts_event');
            }
            if (!wp_next_scheduled('giftmax_update_usd_rate_event')) {
                wp_schedule_event(time(), 'fifteen_minutes', 'giftmax_update_usd_rate_event');
            }
        });
        add_action('giftmax_update_usd_rate_event', [$this, 'giftmax_update_usd_rate']);
        add_action('giftmax_auto_clear_expired_carts_event', [$this, 'giftmax_auto_clear_expired_carts']);
        add_action('giftmax_auto_clear_expired_carts_event', [$this, 'giftmax_process_product_alerts']);
        /**
         * Hook Orders
         */
        /*add_action( 'woocommerce_order_status_completed', [$this,'giftmax_assign_licenses_to_completed'], 10, 1 );
        add_action( 'woocommerce_order_status_processing', [$this,'giftmax_assign_licenses_to_completed'], 10, 1 );
        add_action( 'woocommerce_order_status_failed',    [$this,'giftmax_release_licenses_on_failed_or_cancelled'], 10, 1 );
        add_action( 'woocommerce_order_status_cancelled', [$this,'giftmax_release_licenses_on_failed_or_cancelled'], 10, 1 );

        */
        add_filter('woocommerce_shop_order_list_table_columns', [$this, 'add_preorder_column_to_orders_list']);

        // نمایش محتوای ستون پیش‌فروش
        add_action('woocommerce_shop_order_list_table_custom_column', [$this, 'show_preorder_status_in_orders_list'], 10, 2);
        // قابلیت جستجو و فیلتر
        add_filter('woocommerce_orders_table_search_query', [$this, 'search_preorder_orders'], 10, 2);
        // 1. اول متای سفارش رو هنگام ثبت ذخیره کن// 2. اصلاح فیلتر dropdown
        add_action('woocommerce_order_list_table_restrict_manage_orders', [$this, 'add_preorder_filter_dropdown']);
        // 3. اصلاح فیلتر روی query
        add_action('woocommerce_order_list_table_prepare_items_query_args', [$this, 'filter_orders_by_preorder']);
        // 4. اصلاح ستون نمایش برای HPOS
        add_action('admin_init', [$this, 'admin_init']);

        add_filter( 'wp_date', [ $this, 'wp_date' ], 100, 4 );
        add_action( 'admin_enqueue_scripts', [ $this, 'datepicker' ], 1000 );
        add_action( 'admin_print_footer_scripts', [ $this, 'inline_js' ] );
        add_action('add_meta_boxes_shop_coupon', [ $this, 'register_coupon_meta_boxes' ]);
        add_action('save_post_shop_coupon', [ $this, 'save_coupon' ], 10, 3);
    }
    public function save_coupon()
    {
        if (isset($_POST['coupon']) && $_POST['coupon']['status']) {
            $coupon_obj    = new \WC_Coupon( get_the_ID() );
            $discount_type = $coupon_obj->get_discount_type();
            $amount        = $coupon_obj->get_amount();

            switch ( $discount_type ) {
                case 'percent':
                    $discount_text = $amount . '%';
                    break;
                case 'fixed_cart':
                case 'fixed_product':
                    $discount_text = number_format_usd( $amount) . ' تومان';
                    break;
                default:
                    $discount_text = 'نامشخص';
            }
            $expiry_date   = $coupon_obj->get_date_expires();
            $usage_limit   = $coupon_obj->get_usage_limit();
            $usage_count   = $coupon_obj->get_usage_count();
            $remaining     = $usage_limit
                    ? max( 0, $usage_limit - $usage_count )
                    : 'نامحدود';
            $text = '🎁 کد تخفیف ویژه برای شما'."\n\n";
            $text .= 'کد تخفیف: ' . $coupon_obj->get_code() . "\n";
            if (isset($_POST['coupon']['amount'])){
                $text .= '💰 میزان تخفیف: ' . $discount_text . "\n";
            }
            if (isset($_POST['coupon']['number'])){
                $text .= '🎟 تعداد کدهای باقی‌مانده: ' . $remaining  . "\n";
            }
            if (isset($_POST['coupon']['expiry']) && !is_null($expiry_date)){
                $text .= "⏰ تاریخ انقضا: " . gjdate($expiry_date->date_i18n( 'Y-m-d' ),"d-m-Y") . "\n\n";
            }
            if (isset($_POST['coupon']['input_text_custom'])){
                $text .= "\n" . $_POST['coupon']['text_custom'];
            }
            if ($_POST['coupon']['time-input'] && preg_match('/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/',$_POST['coupon']['time'])) {
                $jalali = $_POST['coupon']['time'];

                [$date, $time] = explode(' ', $jalali);
                [$jy, $jm, $jd] = explode('-', $date);
                [$gy, $gm, $gd] = jalaliToGregorian($jy, $jm, $jd);
                $gregorian = sprintf("%04d-%02d-%02d %s", $gy, $gm, $gd, $time);
                $this->handelSendSms($coupon_obj->get_code(),$text,$_POST['coupon']['white'],$_POST['coupon']['listwhite'],$_POST['coupon']['block'],$_POST['coupon']['listblock'],$gregorian);
            }else{
                $this->handelSendSms($coupon_obj->get_code(),$text,$_POST['coupon']['white'],$_POST['coupon']['listwhite'],$_POST['coupon']['block'],$_POST['coupon']['listblock'],date("Y-m-d H:i:s", strtotime("+2 minute")));
            }
            if ($_POST['coupon']['expiry'] && is_numeric($_POST['coupon']['expiry-date']) && $_POST['coupon']['expiry-date'] != 0 && !is_null($expiry_date)) {
                $data = $_POST['coupon']['expiry-date'];
                $expiry_date->modify("-$data days");
                if (current_time('Y-m-d') < $expiry_date->date_i18n('Y-m-d')) {
                    $this->handelSendSms($coupon_obj->get_code() . " با تاریخ انقضای " . $data, $text, $_POST['coupon']['white'], $_POST['coupon']['listwhite'], $_POST['coupon']['block'], $_POST['coupon']['listblock'],$expiry_date->date_i18n('Y-m-d H:i:s'));
                }
            }
        }
    }
    private function handelSendSms($code,$text,$isSetWhite,$whiteList,$isSetBlcok,$blockList,$send_at)
    {
        global $wpdb;
        $db = Db::getLnstance();
        $db->insert("INSERT INTO `{$wpdb->prefix}sms_campaigns` (`id`, `title`,`type`, `message`, `total_count`, `sent_count`, `failed_count`, `created_at`, `send_at`) VALUES (NULL, :title,'کدتخفیف', :message, '0', '0', '0', :created_at,:send_at)",array(
                'title' => 'ارسال پیام برای کد تخفیف ' . $code,
                'message' => $text,
                'send_at' => $send_at,
                'created_at' => date('Y-m-d H:i:s')
        ));
        $campaign_id = $db->lastInsertId();
        $total_count = $sent_count = $failed_count = 0;
        $users = get_users(array('fields' => array('user_login')));
        $phones = [];

        foreach ($users as $user) {
            $phones[] = $user->user_login;
        }
        if ($isSetWhite) {
            $id = $whiteList;
            $wList = $db->first("SELECT * FROM `{$wpdb->prefix}sms_lists` WHERE `id`=:id",array('id'=>$id));
            if (!empty($wList)) {
                $records = $db->query("SELECT phone FROM `{$wpdb->prefix}sms_list_members` WHERE `list_id`=:list_id",array('list_id'=>$wList['id']));
                if (!empty($records)) {
                    $include_phones = [];
                    foreach ($records as $record) {
                        $include_phones[] = $record['phone'];
                    }
                    $phones = array_merge($phones, $include_phones);
                }
            }
        }


        // حذف تکراری ها
        $phones = array_unique($phones);


        if ($isSetBlcok) {
            $id = $blockList;
            $bList = $db->first("SELECT * FROM `{$wpdb->prefix}sms_lists` WHERE `id`=:id",array('id'=>$id));
            if (!empty($bList)) {
                $records = $db->query("SELECT phone FROM `{$wpdb->prefix}sms_list_members` WHERE `list_id`=:list_id",array('list_id'=>$bList['id']));
                if (!empty($records)) {
                    $exclude_phones = [];
                    foreach ($records as $record) {
                        $exclude_phones[] = $record['phone'];
                    }
                    // شماره های بلاک شده
                    $phones = array_diff($phones, $exclude_phones);
                }
            }
        }
        $phones = array_values($phones);
        foreach ($phones as $phone) {
                $db->insert("INSERT INTO `{$wpdb->prefix}sms_campaign_recipients` (`id`, `campaign_id`, `phone`, `status`, `sent_at`, `error_message`) VALUES (NULL, :campaign_id, :phone, 'pending', :sent_at, NULL)",array(
                        'campaign_id' => $campaign_id,
                        'phone' => $phone,
                        'sent_at' => date('Y-m-d H:i:s')
                ));
            $total_count++;
        }
        $db->modify("UPDATE `{$wpdb->prefix}sms_campaigns` SET `total_count`=:total_count,`sent_count` = :sent_count,`failed_count`=:failed_count WHERE `id` = :id",array(
                'total_count' => $total_count,
                'sent_count' => 0,
                'failed_count' => 0,
                'id' => $campaign_id
        ));
    }
    public function register_coupon_meta_boxes(){
        add_meta_box(
                'giftmax_coupon_setting',
                __( 'تنظیمات کد تخفیف', 'giftmax' ),
                [ $this, 'render_coupon_setting' ],
                'shop_coupon',
                'side',
                'high'
        );
    }
    public function render_coupon_setting( $post ): void {
        $view = new AdminProductTemplate();
        $view->render_fast_setting_coupon( $post );
    }
    public function wp_date($date, $format, $timestamp, $timezone)
    {
        if (!is_admin() || ((!isset($_GET['page']) || $_GET['page'] !== 'wc-orders' || isset($_GET['action']) && $_GET['action'] == 'edit') && (!isset($_GET['post_type']) || $_GET['post_type'] !== 'shop_coupon'))) {
            return $date;
        }
        $format = str_replace('M', 'F', $format);
        try {
            return gjdate(date("Y-m-d", $timestamp),"Y-m-d");
        } catch(\Exception $e) {

            return $date;
        }
    }
    public function datepicker() {

        if ( isset( self::SCREENS[ urldecode( get_current_screen()->id ) ] ) ) {
            wp_enqueue_style(
                    'persian-datepicker',
                    get_template_directory_uri() . '/assets/css/persian-datepicker.min.css',
                    [],
                    '1.0'
            );
            wp_enqueue_script(
                    'pw-datepicker-js',
                    get_template_directory_uri() . '/assets/js/persian-datepicker.min.js',
                    ['jquery'],
                    '1.0',
                    true
            );
        }
    }

    public function inline_js() {

        $screen = get_current_screen()->id;
        if ( ! isset( self::SCREENS[ urldecode( $screen ) ] ) ) {
            return true;
        }

        $method_name = "inline_js_" . self::SCREENS[ urldecode( $screen ) ];
        ?>
        <style type="text/css">
            #ui-datepicker-div {
                display: none !important;
            }
        </style>
        <?php

        $this->{$method_name}();
    }
    public function inline_js_product() {
        ?>
        <script type="text/javascript">
            (function ($) {
                $(document).ready(function () {
                    let _sale_price_dates_from = $("#_sale_price_dates_from").val();

                    $("#_sale_price_dates_from").persianDatepicker({
                        formatDate: "YYYY-0M-0D",
                        showGregorianDate: 1,   // ← اضافه شد
                        selectedBefore: _sale_price_dates_from.length ? 1 : 0,
                        selectedDate: _sale_price_dates_from.length ? _sale_price_dates_from.replace(/-/gi, "/") : null
                    });

                    let _sale_price_dates_to = $("#_sale_price_dates_to").val();

                    $("#_sale_price_dates_to").persianDatepicker({
                        formatDate: "YYYY-0M-0D",
                        showGregorianDate: 1,   // ← اضافه شد
                        selectedBefore: _sale_price_dates_to.length ? 1 : 0,
                        selectedDate: _sale_price_dates_to.length ? _sale_price_dates_to.replace(/-/gi, "/") : null
                    });

                    $("div.woocommerce_variations").on("click", "a.sale_schedule", function () {
                        let el_to = $(this).parent().parent().next().find("input[name*=to]");
                        let el_date_to = el_to.val();

                        el_to.persianDatepicker({
                            formatDate: "YYYY-0M-0D",
                            showGregorianDate: 1,   // ← اضافه شد
                            selectedBefore: el_date_to.length ? 1 : 0,
                            selectedDate: el_date_to.length ? el_date_to.replace(/-/gi, "/") : null
                        });

                        let el_from = $(this).parent().parent().next().find("input[name*=from]");
                        let el_date_from = el_from.val();

                        el_from.persianDatepicker({
                            formatDate: "YYYY-0M-0D",
                            showGregorianDate: 1,   // ← اضافه شد
                            selectedBefore: el_date_from.length ? 1 : 0,
                            selectedDate: el_date_from.length ? el_date_from.replace(/-/gi, "/") : null
                        });
                    });
                });
            })(jQuery)
        </script>
        <?php
    }
    public function inline_js_shop_coupon() {

        $coupon = new \WC_Coupon( intval( $_GET['post'] ) );

        $expiry_date = $coupon->get_date_expires( 'edit' ) ? $coupon->get_date_expires( 'edit' )->date_i18n( 'Y-m-d' ) : '';

        ?>
        <script type="text/javascript">
            jQuery(function ($) {
                let expiry_date = <?=esc_attr(gjdate($expiry_date, 'Y-m-d'))?>;

                let args = {
                    formatDate: "YYYY-0M-0D",
                    showGregorianDate: 1,   // ← اضافه شد
                    selectedBefore: expiry_date.length ? 1 : 0,
                    selectedDate: expiry_date.length ? expiry_date.replace(/-/gi, "/") : null
                };

                $("input[name=expiry_date]").persianDatepicker(args);
                $("#time").persianDatepicker({
                    formatDate: "YYYY-0M-0D hh:mm",
                    showGregorianDate: 0,
                    timePicker: true
                });
            });
        </script>
        <?php
    }
    public function giftmax_update_usd_rate() {
        $rate = self::giftmax_fetch_usd_rate();
        if ($rate && $rate > 1000) {
            update_option('giftmax_usd_rate', $rate);
            update_option('giftmax_usd_rate_updated', date('Y-m-d H:i:s'));
        }
    }
    private function giftmax_fetch_usd_rate() {
        $url = home_url('/wp-json/mnswmc/v1/currency/9f8e7adfcdb7c395d33d08fcd968ade8');
        $response = wp_remote_get($url, ['timeout' => 10]);

        if (is_wp_error($response)) return false;

        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);

       return number_format($data['2590']['rate']);
    }
    public function admin_init() {
        if (!is_admin()) {
            return;
        }

        global $pagenow;

        $is_product_page = false;

        if (
                $pagenow === 'post-new.php'
                && isset($_GET['post_type'])
                && $_GET['post_type'] === 'product'
        ) {
            $is_product_page = true;
        }

        if (
                $pagenow === 'post.php'
                && isset($_GET['action'])
                && $_GET['action'] === 'edit'
        ) {

            $post_id = intval($_GET['post'] ?? 0);

            if ($post_id && get_post_type($post_id) === 'product') {
                $is_product_page = true;
            }
        }

        if (!$is_product_page) {
            return;
        }

        $cookie_token = $_COOKIE['my_product_access'] ?? '';

        $fingerprint = hash(
                'sha256',
                ($_SERVER['HTTP_USER_AGENT'] ?? '') .
                ($_SERVER['HTTP_ACCEPT_LANGUAGE'] ?? '') .
                ($_SERVER['HTTP_SEC_CH_UA_PLATFORM'] ?? '')
        );

        $expected_token = hash_hmac(
                'sha256',
                $fingerprint,
                MY_PRODUCT_SECURITY_PASSWORD
        );

        if (hash_equals($expected_token, $cookie_token) && get_transient('giftmax_product_token_' . $cookie_token)) {
            return;
        }
        if (isset($_POST['my_product_password']) && password_verify( $_POST['my_product_password'], MY_PRODUCT_SECURITY_PASSWORD)) {
            $fingerprint = hash(
                    'sha256',
                    ($_SERVER['HTTP_USER_AGENT'] ?? '') .
                    ($_SERVER['HTTP_ACCEPT_LANGUAGE'] ?? '') .
                    ($_SERVER['HTTP_SEC_CH_UA_PLATFORM'] ?? '')
            );

            $token = hash_hmac(
                    'sha256',
                    $fingerprint,
                    MY_PRODUCT_SECURITY_PASSWORD
            );
            set_transient(
                    'giftmax_product_token_' . $token,
                    true,
                    30 * MINUTE_IN_SECONDS
            );
            setcookie(
                    'my_product_access',
                    $token,
                    time() + (30 * MINUTE_IN_SECONDS),
                    COOKIEPATH,
                    COOKIE_DOMAIN,
                    is_ssl(),
                    false
            );

            wp_redirect($_SERVER['REQUEST_URI']);
            exit;
        }
        ?>

        <style>
            .form{
                max-width: 400px;
                margin: 100px auto;
                background-color: #FFF;
                box-shadow: 0 0 0 1px #f1f1f1, 0 0 20px 0px #dedede;
                padding: 40px 34px;
                border-radius: 10px;
            }
            .form h2{
                margin-top: 0;
            }
            .form input{
                width: 100%;
                border: 0 !important;
                outline: 0 !important;
                background-color: #f1f1f1;
                height: 30px;
                border-radius: 9px;
            }
            .form button{
                background-color: #FFF;
                height: 30px;
                width: 54px;
                border-radius: 11px;
                margin-top: 10px;
                border: 1px solid;
            }
        </style>
        <form method="post" class="form">
            <h2>Password Security Product</h2>
            <input name="my_product_password">
            <button type="submit">Login</button>
        </form>
        <?php
        exit();
    }
    public function giftmax_auto_clear_expired_carts() {
        global $wpdb;
        $db = \Giftmax\modules\Db::getLnstance();
        $api_url = "https://api.brsapi.ir/Market/Gold_Currency.php?key=BKKPZAbBXslNk73v4KzSqwJeJuuGDads";

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $api_url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);

        $response = curl_exec($ch);
        curl_close($ch);

        if ($response) {
            $data = json_decode($response, true);
            if ($data || isset($data['currency'])) {
                $symbols = ['USD', 'EUR', 'GBP', 'CNY', 'USDT_IRT'];
                $result = [];

                foreach ($data['currency'] as $currency) {
                    if (in_array($currency['symbol'], $symbols)) {
                        $result[] = [
                            'symbol' => $currency['symbol'],
                            'name' => $currency['name'],
                            'dayClose' => (string)$currency['price'],
                            'dayChange' => (string)$currency['change_percent'],
                            'dayChangeValue' => (string)$currency['change_value'],
                            'unit' => $currency['unit'],
                            'date' => $currency['date'],
                            'time' => $currency['time']
                        ];
                    }
                }
                if (count($result) > 0) {
                    $records = $db->first("SELECT * FROM `{$wpdb->prefix}setting` WHERE `meta_key`=:meta_key", array('meta_key' => 'currency'));
                    if (empty($records)) {
                        $db->insert("INSERT INTO `{$wpdb->prefix}setting` (`id`, `meta_key`, `meta_value`) VALUES (NULL, :meta_key, :meta_value)", array('meta_key' => 'currency', 'meta_value' => json_encode($result)));
                    } else {
                        $db->modify("UPDATE `{$wpdb->prefix}setting` SET `meta_value`=:meta_value WHERE `meta_key`=:meta_key", array('meta_value' => json_encode($result), 'meta_key' => 'currency'));
                    }
                }
            }
        }
        $db->modify("UPDATE `{$wpdb->prefix}user_identity` AS ui LEFT JOIN `{$wpdb->prefix}documents` AS d ON ui.user_id = d.user_id SET ui.landline_phone = NULL WHERE d.user_id IS NULL AND TIMESTAMPDIFF(MINUTE, ui.updated_at, NOW()) > 15;");
        $db->modify("DELETE FROM `{$wpdb->prefix}user_bank_cards` WHERE is_active = 0 AND created_at < DATE_SUB(NOW(), INTERVAL 10 MINUTE);");


        $expire_time = time();

        $expired = $db->query(
            "SELECT licence_id, product_id  FROM {$wpdb->prefix}product_licences  WHERE licence_status = 'reserved' AND reserved_at < :time",
            ['time' => $expire_time]
        );

        if (empty($expired)) return;
        foreach ($expired as $licence) {
            $db->modify("UPDATE {$wpdb->prefix}product_licences  SET licence_status = 'available', reserved_at = NULL, order_id=NULL WHERE licence_id = :id",
                    ['id' => $licence['licence_id']]
            );
        }
    }
    private function normalize_mobile_number($mobile_raw) {
        $mobile = is_string($mobile_raw) ? trim($mobile_raw) : '';
        if ($mobile === '') {
            return '';
        }

        $mobile = strtr($mobile, array(
            '۰' => '0', '۱' => '1', '۲' => '2', '۳' => '3', '۴' => '4',
            '۵' => '5', '۶' => '6', '۷' => '7', '۸' => '8', '۹' => '9',
        ));
        $mobile = preg_replace('/\D+/', '', $mobile);

        if (strpos($mobile, '98') === 0 && strlen($mobile) === 12) {
            $mobile = '0' . substr($mobile, 2);
        } elseif (strpos($mobile, '0098') === 0 && strlen($mobile) === 14) {
            $mobile = '0' . substr($mobile, 4);
        } elseif (strpos($mobile, '9') === 0 && strlen($mobile) === 10) {
            $mobile = '0' . $mobile;
        }

        return $mobile;
    }
    private function mark_alert_as_sent($alert_id) {
        $alert_id = (int) $alert_id;
        if ($alert_id <= 0) {
            return;
        }

        global $wpdb;
        $db = Db::getLnstance();
        $table = $wpdb->prefix . 'product_availability_alerts';
        $db->modify("UPDATE `{$table}` SET `is_sent`=1,`sent_at`=NOW() WHERE `id`=:id", array(
            'id' => $alert_id,
        ));
    }
    private function send_availability_sms($mobile, $product_name,$link)
    {
        $mobile = $this->normalize_mobile_number($mobile);
        if (!preg_match('/^09\d{9}$/', $mobile)) {
            return false;
        }
        $baseUrl = "https://edge.ippanel.com/v1/api/send";
        $token = "wns0sWEioLyJejB0g0olFj-PVlL2Yt5O2G94prP-BXg=";

        $data = [
            "sending_type" => "pattern",
                "from_number" => "+9890007189",
                "code" => "2fbqs5qge3eed07",
            "recipients" => [$mobile],
            "params" => [
                "product" => $product_name,
                "link" => $link
            ],
        ];

        $ch = curl_init($baseUrl);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            "Content-Type: application/json; charset=utf-8",
            "Content-Type: application/json",
            "Authorization: $token"
        ]);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data, JSON_UNESCAPED_UNICODE));

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($httpCode !== 200 || empty($response)) {
            return false; // خطا در اتصال یا پاسخ خالی
        }

        $responseData = json_decode($response, true);
        if (isset($responseData['meta']['status']) && $responseData['meta']['status'] === true) {
            return true; // ارسال موفق
        }

        return false;
    }
    public function giftmax_process_product_alerts() {
        global $wpdb;
        $db = Db::getLnstance();
        $table = $wpdb->prefix . 'product_availability_alerts';

        $alerts = $db->query("SELECT `id`,`product_id`,`user_id`,`mobile`,`channel` FROM `{$table}` WHERE `is_sent`=0 ORDER BY `id` ASC LIMIT 200");
        if (empty($alerts)) {
            return;
        }

        foreach ($alerts as $alert) {
            $alert_id = (int) $alert['id'];
            $product_id = (int) $alert['product_id'];
            $user_id = (int) $alert['user_id'];
            $channel = isset($alert['channel']) ? (string) $alert['channel'] : '';
            $mobile = isset($alert['mobile']) ? (string) $alert['mobile'] : '';

            if ($alert_id <= 0 || $product_id <= 0) {
                $this->mark_alert_as_sent($alert_id);
                continue;
            }

            if (!\product_available($product_id)) {
                continue;
            }

            $product = wc_get_product($product_id);
            $product_name = $product ? $product->get_name() : ('محصول #' . $product_id);

            if ($channel === 'notification') {
                if ($user_id <= 0) {
                    $this->mark_alert_as_sent($alert_id);
                    continue;
                }
                $link = '<a href="' . esc_url( $product->get_permalink() ) . '">مشاهده محصول</a>';
                $db->insert("INSERT INTO `{$wpdb->prefix}notifications` (`userId`,`body`,`title`,`status`,`is_active`,`created_at`) VALUES (:user_id,:body,:title,'show',1,NOW())", array(
                    'user_id' => $user_id,
                    'title' => 'موجودی محصول',
                    'body' => 'محصول ' . $product_name . ' موجود شد.' . "\n" . $link,
                ));
                UserModel::alert($user_id,$db->lastInsertId());
                $this->mark_alert_as_sent($alert_id);
                continue;
            }
            if ($channel === 'sms') {
                if ($this->send_availability_sms($mobile, $product_name,$product->get_permalink())) {
                    $this->mark_alert_as_sent($alert_id);
                }
                continue;
            }

            $this->mark_alert_as_sent($alert_id);
        }
    }
    public function filter_orders_by_preorder($query_args) {
        if(isset($_GET['preorder_filter']) && !empty($_GET['preorder_filter'])) {
            $filter_type = sanitize_text_field($_GET['preorder_filter']);

            $meta_query = isset($query_args['meta_query']) ? $query_args['meta_query'] : array();

            if($filter_type === 'preorder') {
                $meta_query[] = array(
                    'key' => '_has_preorder_items',
                    'value' => true,
                    'compare' => '='
                );
            } elseif($filter_type === 'normal') {
                $meta_query[] = array(
                    'key' => '_has_preorder_items',
                    'value' => false,
                    'compare' => '='
                );
            }

            if(!empty($meta_query)) {
                $query_args['meta_query'] = $meta_query;
            }
        }

        return $query_args;
    }
    public function add_preorder_column_to_orders_list($columns) {
        $new_columns = array();
        foreach($columns as $key => $column) {
            $new_columns[$key] = $column;
            if($key === 'order_status') {
                $new_columns['preorder_status'] = 'وضعیت پیش‌فروش';
                $new_columns['suspicious_order'] = 'مشکوک';
                $new_columns['incomplete_licence'] = 'وضعیت لایسنس';
            }
        }
        return $new_columns;
    }
    public function show_preorder_status_in_orders_list($column, $order) {
        if($column === 'preorder_status') {
            $has_preorder = false;
            foreach($order->get_items() as $item) {
                $product_id = $item->get_product_id();
                $delivery = get_post_meta($product_id, 'delivery', true);

                $is_preorder = isset($delivery['two']) && $delivery['two'] == 'on';

                if($is_preorder) {
                    $has_preorder = true;
                    break;
                }
            }
            if($has_preorder) {
                echo '<span style="background: #f39c12; color: white; padding: 3px 8px; border-radius: 3px; font-size: 12px;">بله</span>';
            } else {
                echo '<span style="color: #95a5a6;">خیر</span>';
            }
        }elseif ($column === 'suspicious_order') {
           $suspicious_order = $order->get_meta('_suspicious_order');
           if ($suspicious_order == 1) {
               echo '<span style="color: #95a5a6;">مشکوک</span>';
           }else{
               echo '<span style="color: #95a5a6;">-</span>';
           }
        } elseif ($column === 'incomplete_licence') {
           $suspicious_order = $order->get_meta('_giftmax_incomplete_licence');
           if ($suspicious_order == 1) {
               echo '<span style="color: #ef2e05;">ناقص</span>';
           }else{
               echo '<span style="color: #009c00;">کامل</span>';
           }
        }
    }
    public function search_preorder_orders($search, $query) {
        if(isset($_GET['preorder_filter']) && $_GET['preorder_filter'] === 'preorder') {
            $query->set('meta_key', '_has_preorder_items');
            $query->set('meta_value', true);
        }
        return $search;
    }
    public function add_preorder_filter_dropdown() {
        $current = isset($_GET['preorder_filter']) ? sanitize_text_field($_GET['preorder_filter']) : '';
        ?>
        <select name="preorder_filter">
            <option value="">همه سفارشات</option>
            <option value="preorder" <?php selected($current, 'preorder'); ?>>دارای پیش‌فروش</option>
            <option value="normal" <?php selected($current, 'normal'); ?>>بدون پیش‌فروش</option>
        </select>
        <?php
    }
}
