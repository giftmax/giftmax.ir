<?php

namespace Giftmax\setup;

use Giftmax\model\UserModel;

class Db
{
    public function __construct() {
        //$this->insert();
        if (!wp_next_scheduled('giftmax_cleanup_otp')) {
            wp_schedule_event(time(), 'hourly', 'giftmax_cleanup_otp');
        }

        add_action('giftmax_cleanup_otp', [$this,'giftmax_delete_expired_otps']);
    }
    public function giftmax_delete_expired_otps()
    {
        UserModel::expiryEnd();
    }
    public function insert()
    {
        global $wpdb;
        $db = \Giftmax\modules\Db::getLnstance();
        $db->insert("CREATE TABLE IF NOT EXISTS `" . $wpdb->prefix . "otp` (id INT AUTO_INCREMENT PRIMARY KEY,phone VARCHAR(20) UNIQUE,otp VARCHAR(6),  otp_expiry DATETIME ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
        $db->insert("CREATE TABLE IF NOT EXISTS `" . $wpdb->prefix . "user_identity` ( id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, user_id BIGINT UNSIGNED NOT NULL, national_id_enc VARBINARY(255) NOT NULL, birth_date_enc VARBINARY(255) NOT NULL, landline_phone VARBINARY(255) NULL,  account_type ENUM('normal','vip','') DEFAULT 'normal',  is_verified TINYINT(1) DEFAULT 0, is_vip TINYINT(1) DEFAULT 0, created_at DATETIME DEFAULT CURRENT_TIMESTAMP,updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,UNIQUE KEY user_id (user_id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");
        $db->insert("CREATE TABLE IF NOT EXISTS `" . $wpdb->prefix . "user_bank_cards` (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,hash VARCHAR(64) NOT NULL, user_id BIGINT UNSIGNED NOT NULL, card_number_enc VARBINARY(255) NOT NULL, card_last4 CHAR(4) NOT NULL,phone VARBINARY(255) NULL,birth_date VARBINARY(255) NULL,national_code VARBINARY(255) NULL,first_name VARBINARY(255) NULL,last_name VARBINARY(255) NULL, is_active TINYINT(1) DEFAULT 1,ip varbinary(255) NOT NULL, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, INDEX user_id (user_id), INDEX is_active (is_active), INDEX phone (phone) ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");
        $db->insert("CREATE TABLE IF NOT EXISTS `" . $wpdb->prefix . "user_requests` (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, user_id BIGINT UNSIGNED NOT NULL, request_type ENUM('block','unblock','verification','upgrade') NOT NULL, request_text TEXT NOT NULL, status ENUM('pending','approved','rejected') DEFAULT 'pending', created_at DATETIME DEFAULT CURRENT_TIMESTAMP, INDEX user_id (user_id) ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");
        $db->insert("CREATE TABLE IF NOT EXISTS `" . $wpdb->prefix . "user_documents` (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, user_id BIGINT UNSIGNED NOT NULL, document_type ENUM( 'national_card', 'birth_certificate', 'personal_photo' ) NOT NULL, file_path VARCHAR(255) NOT NULL, status ENUM('pending','approved','rejected') DEFAULT 'pending', uploaded_at DATETIME DEFAULT CURRENT_TIMESTAMP, INDEX user_id (user_id) ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");
        $db->insert('CREATE TABLE IF NOT EXISTS ' . $wpdb->prefix . 'image (id INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY,url LONGTEXT COLLATE utf8mb4_general_ci NULL,code VARCHAR(4) COLLATE utf8mb4_general_ci NULL)');
        $db->insert('CREATE TABLE IF NOT EXISTS ' . $wpdb->prefix . 'ticket (ticketId INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY,rep_Id int(11) NULL,categoryId varchar(50) NULL,userId INT(11) NULL,Issue VARCHAR(50) COLLATE utf8mb4_unicode_ci NULL,requestText VARCHAR(500) COLLATE utf8mb4_unicode_ci NULL,attachment LONGTEXT COLLATE utf8mb4_general_ci NULL,`condition` int(1) null ,`time` DATETIME NULL)');
        $db->insert('CREATE TABLE IF NOT EXISTS ' . $wpdb->prefix . 'ticketing_category (categoryId INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY,name VARCHAR(255) COLLATE utf8mb4_unicode_ci NULL,subset INT NULL,main_category INT(1) NULL)');
        $db->insert("CREATE TABLE IF NOT EXISTS `" . $wpdb->prefix . "product_licences` ( `licence_id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT, `product_id` BIGINT UNSIGNED NOT NULL,`file_id` BIGINT UNSIGNED NULL ,`licence_code` varbinary(255) NOT NULL, `licence_status` ENUM('available','assigned','reserved','refunded') NOT NULL DEFAULT 'available',`sort_order` INT UNSIGNED NOT NULL DEFAULT 0, `description` VARCHAR(255) NULL , `cost_price` BIGINT UNSIGNED , `order_id` BIGINT UNSIGNED NULL, `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP, `reserved_at` INT NULL, `assigned_at` TIMESTAMP NULL, PRIMARY KEY (`licence_id`), KEY `product_id` (`product_id`), KEY `licence_status` (`licence_status`), KEY `order_id` (`order_id`),    KEY `sort_order` (`sort_order`) ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        $db->insert("CREATE TABLE IF NOT EXISTS `" . $wpdb->prefix . "product_licences_file` ( `file_id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT, `url` VARCHAR(2048) NOT NULL,`password` varbinary(255) NOT NULL,`name` VARCHAR(500) NOT NULL, PRIMARY KEY (`file_id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        $db->insert("CREATE TABLE IF NOT EXISTS `" . $wpdb->prefix . "user_points` ( `id` INT AUTO_INCREMENT PRIMARY KEY , `user_id` INT NULL , `points` INT NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        $db->insert("CREATE TABLE IF NOT EXISTS `" . $wpdb->prefix . "wallet` ( `id` INT AUTO_INCREMENT PRIMARY KEY , `user_id` INT NULL , balance INT(10) UNSIGNED) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        $db->insert("CREATE TABLE IF NOT EXISTS `" . $wpdb->prefix . "wallet_transactions` (`id` INT AUTO_INCREMENT PRIMARY KEY , `user_id` INT NULL,`method` ENUM('wallet','points') NULL , `method_id` BIGINT NULL , `amount` DECIMAL(15,2) NULL , `type` ENUM('credit','debit') NULL , `description` VARCHAR(255) NULL , `created_at` TIMESTAMP NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        $db->insert("CREATE TABLE IF NOT EXISTS `" . $wpdb->prefix . "wallet_payments` (`id`  INT AUTO_INCREMENT PRIMARY KEY, `user_id` INT NULL ,`hash` VARCHAR(50) NULL, `amount` DOUBLE(15,0) NULL , `gateway_tx_id` VARCHAR(50) NULL , `created_at` TIMESTAMP NULL , `updated_at` TIMESTAMP NULL , `metadata` JSON NULL , `status` INT(1) NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        $db->insert("CREATE TABLE IF NOT EXISTS `" . $wpdb->prefix . "documents` (`id`  INT AUTO_INCREMENT PRIMARY KEY, `user_id` INT NULL ,`doc_type` VARCHAR(50) NULL, `document` VARCHAR(300) NULL , `accepted` INT(1) NULL , `description`  VARCHAR(300) NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        $db->insert("CREATE TABLE IF NOT EXISTS `" . $wpdb->prefix . "setting` (`id`  INT AUTO_INCREMENT PRIMARY KEY,meta_key VARCHAR(255)  COLLATE utf8mb4_unicode_520_ci NULL,meta_value longtext COLLATE utf8mb4_unicode_520_ci NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        $db->insert("CREATE TABLE IF NOT EXISTS `" . $wpdb->prefix . "user_wishlist` (`id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,`user_id` BIGINT UNSIGNED NOT NULL,`product_id` BIGINT UNSIGNED NOT NULL,`created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,UNIQUE KEY `uniq_user_product` (`user_id`,`product_id`),KEY `product_id` (`product_id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        $db->insert("CREATE TABLE IF NOT EXISTS `" . $wpdb->prefix . "product_availability_alerts` (`id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,`product_id` BIGINT UNSIGNED NOT NULL,`user_id` BIGINT UNSIGNED NOT NULL DEFAULT 0,`mobile` VARCHAR(20) NOT NULL DEFAULT '',`channel` ENUM('notification','sms') NOT NULL,`is_sent` TINYINT(1) NOT NULL DEFAULT 0,`created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,`sent_at` DATETIME NULL,UNIQUE KEY `uniq_product_channel_target` (`product_id`,`user_id`,`mobile`,`channel`),KEY `idx_is_sent` (`is_sent`),KEY `idx_product` (`product_id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        $db->insert("CREATE TABLE IF NOT EXISTS `" . $wpdb->prefix . "post_unique_views` (`id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,`post_id` BIGINT UNSIGNED NOT NULL,`user_id` BIGINT UNSIGNED NULL,`visitor_hash` VARCHAR(80) NOT NULL,`created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,UNIQUE KEY `uniq_post_visitor` (`post_id`,`visitor_hash`),KEY `post_id` (`post_id`),KEY `user_id` (`user_id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        $db->insert('CREATE TABLE IF NOT EXISTS `' . $wpdb->prefix . 'alert` (Id INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY,userId INT NULL,notificationsId INT NULL,hash VARCHAR(50) COLLATE utf8mb4_unicode_ci NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4');
        $db->insert('CREATE TABLE IF NOT EXISTS `' . $wpdb->prefix . 'notifications` (Id INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY,userId INT NULL,body LONGTEXT COLLATE utf8mb4_unicode_ci NULL,title VARCHAR(250) NULL,status VARCHAR(50) COLLATE utf8mb4_unicode_ci NULL,is_active TINYINT(1) NOT NULL DEFAULT 1,created_at DATETIME NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4');
        $db->insert('CREATE TABLE IF NOT EXISTS `' . $wpdb->prefix . 'notification_reads` (notification_id INT(11) UNSIGNED NOT NULL,user_id BIGINT(20) UNSIGNED NOT NULL,seen_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY (notification_id,user_id),KEY user_id (user_id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4');
        $db->insert('CREATE TABLE IF NOT EXISTS `' . $wpdb->prefix . 'token_register` (id INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY,`UserLogin` VARCHAR(11) NOT NULL,`hash` VARCHAR(50) NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4');
        $db->insert('CREATE TABLE IF NOT EXISTS `' . $wpdb->prefix . 'bot_platform` (id INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY,`UserId` INT(11) NOT NULL,`chat_id` VARCHAR(400) NULL,`sender_id` VARCHAR(400) NULL,platform_name ENUM("rubika", "bale") NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4');
        $db->insert('CREATE TABLE IF NOT EXISTS `' . $wpdb->prefix . 'contact` (id bigint(20) unsigned NOT NULL AUTO_INCREMENT, name varchar(255) NOT NULL, email varchar(255) NOT NULL, subject varchar(255) NOT NULL, message longtext NOT NULL, ip_address varchar(45) DEFAULT NULL, user_agent text DEFAULT NULL, status tinyint(1) NOT NULL DEFAULT 0, created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY (id), KEY status (status), KEY created_at (created_at), KEY email (email)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4');
        $db->insert('CREATE TABLE IF NOT EXISTS `' . $wpdb->prefix . 'post_views` (`id` INT AUTO_INCREMENT PRIMARY KEY ,`UserId` INT(11) UNSIGNED NOT NULL,`PostId` INT(11) UNSIGNED NOT NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4');
        $db->insert('CREATE TABLE IF NOT EXISTS `' . $wpdb->prefix . 'nonce` (`hash` VARCHAR(50) NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4');
        $db->insert('CREATE TABLE IF NOT EXISTS `' . $wpdb->prefix . 'sms_campaigns` (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, `type` VARCHAR(64) NULL, title VARCHAR(255) NULL, message TEXT NULL, total_count INT UNSIGNED NULL DEFAULT 0, sent_count INT UNSIGNED NULL DEFAULT 0, failed_count INT UNSIGNED NULL DEFAULT 0, created_at DATETIME NULL DEFAULT CURRENT_TIMESTAMP, send_at DATETIME NULL DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4');
        $db->insert("CREATE TABLE IF NOT EXISTS `{$wpdb->prefix}sms_campaign_recipients` (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, campaign_id BIGINT UNSIGNED NULL, phone VARCHAR(20) NULL, status ENUM('pending', 'sent', 'failed') NULL DEFAULT 'pending', sent_at DATETIME NULL, error_message TEXT NULL, UNIQUE KEY campaign_phone (campaign_id, phone), INDEX idx_campaign_status (campaign_id, status), INDEX idx_phone (phone), FOREIGN KEY (campaign_id) REFERENCES {$wpdb->prefix}sms_campaigns(id) ON DELETE CASCADE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        $db->insert("CREATE TABLE IF NOT EXISTS `{$wpdb->prefix}sms_lists` (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, `name` VARCHAR(255) NULL,created_at DATETIME NULL DEFAULT CURRENT_TIMESTAMP, INDEX idx_name (`name`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        $db->insert("CREATE TABLE IF NOT EXISTS `{$wpdb->prefix}sms_list_members` (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, list_id BIGINT UNSIGNED NULL, phone VARCHAR(20) NULL, created_at DATETIME NULL DEFAULT CURRENT_TIMESTAMP, INDEX idx_phone (phone), FOREIGN KEY (list_id) REFERENCES `{$wpdb->prefix}sms_lists`(id) ON DELETE CASCADE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        $db->insert("CREATE TABLE IF NOT EXISTS `{$wpdb->prefix}db_errors` ( `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT, `error_message` TEXT NULL, `error_code` INT NULL, `query_final` LONGTEXT NULL, `bindings` LONGTEXT NULL, `file` TEXT NULL, `line` INT NULL, `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY (`id`), KEY `error_code` (`error_code`), KEY `created_at` (`created_at`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

        $notifications_table = $wpdb->prefix . 'notifications';
        $is_active_column = $wpdb->get_var($wpdb->prepare("SHOW COLUMNS FROM `{$notifications_table}` LIKE %s", 'is_active'));
        if (!$is_active_column) {
            $db->modify("ALTER TABLE `{$notifications_table}` ADD `is_active` TINYINT(1) NOT NULL DEFAULT 1 AFTER `status`");
        }


    }
}
