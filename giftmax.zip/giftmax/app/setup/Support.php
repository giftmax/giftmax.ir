<?php
namespace Giftmax\setup;

use Giftmax\model\SiteModel;
use Giftmax\modules\Db;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Support {

    public function __construct() {
        add_action( 'after_setup_theme', [ $this, 'mytheme_setup' ] );
        add_action( 'template_redirect', [ $this, 'track_unique_post_view' ] );
        $this->removeEndpoint();
    }
    public function removeEndpoint()
    {
        add_filter('rest_endpoints', function ($endpoints) {

            unset($endpoints['/wp/v2/users']);
            unset($endpoints['/wp/v2/users/(?P<id>[\d]+)']);

            // مواردی که اطلاعات قابل شناسایی سایت را بیرون می‌دهند
            unset($endpoints['/wp/v2/comments']);
            unset($endpoints['/wp/v2/posts']);
            unset($endpoints['/wp/v2/search']);
            unset($endpoints['/wp/v2/media']);

            return $endpoints;
        });
        add_filter('rest_pre_dispatch', function ($result, $server, $request) {

            $route = $request->get_route();

            // جلوگیری از API کاربران
            if (
                preg_match('#^/wp/v2/users(?:/|$)#', $route)
            ) {
                return new \WP_Error(
                    'rest_user_disabled',
                    'User REST API is disabled.',
                    ['status' => 404]
                );
            }

            return $result;

        }, 10, 3);
        add_filter('rest_pre_dispatch', function ($result, $server, $request) {

            $route = $request->get_route();

            /*
             * مسدود کردن کامل WooCommerce Store API
             *
             * /wp-json/wc/store/v1/...
             */
            if (preg_match('#^/wc/store/v[0-9]+(?:/|$)#', $route)) {

                return new \WP_Error(
                    'giftmax_store_api_disabled',
                    'دسترسی مستقیم به WooCommerce Store API مجاز نیست.',
                    [
                        'status' => 403,
                    ]
                );
            }

            return $result;

        }, 10, 3);
    }
    public function mytheme_setup() {
        add_theme_support( 'title-tag' );
        add_theme_support('automatic_feed_link');
        add_theme_support( 'post-thumbnails' );
        add_theme_support( 'woocommerce' );
        add_image_size('product_discount', 408, 256,true);
        register_nav_menus(
            array(
                'header-menu' => "منو توی هدر",
                'quick-access' => "دسترسی سریع منوی",
                'help-support' =>"منوی راهنمایی و پشتیبانی",
                'footer-menu' => "منوی افقی در فوتر"
            )
        );
    }
    public function track_unique_post_view():void {
        if (is_admin() || wp_doing_ajax() || !is_singular('post') || is_preview() ) {
            return;
        }
        $post_id = (int) get_queried_object_id();
        if ($post_id <= 0) {
            return;
        }

        $visitor_hash = $this->get_visitor_hash();
        if ($visitor_hash === '') {
            return;
        }

        $db = Db::getLnstance();
        global $wpdb;
        if (is_user_logged_in()) {
            $user_id = get_current_user_id();
            $records = SiteModel::table('post_views', 'UserId', $user_id, 'PostId', $post_id);
            if (empty($records)) {
                $db->insert(
                    "INSERT INTO `{$wpdb->prefix}post_views` (`UserId`,`PostId`) VALUES (:UserId,:PostId)",
                    [
                        'PostId' => $post_id,
                        'UserId' => $user_id
                    ]
                );
                $views = (int)get_post_meta($post_id, 'views', true);
                update_post_meta($post_id, 'views', $views + 1);
            } else {
                $this->get_visitor_hash();
            }
        }else{
            $cookie_name = 'giftmax_video_seen_' . $post_id;

            if (!isset($_COOKIE[$cookie_name])) {
                $views = (int)get_post_meta($post_id, 'views', true);
                update_post_meta($post_id, 'views', $views + 1);
                setcookie(
                    $cookie_name,
                    '1',
                    time() + (5 * YEAR_IN_SECONDS),
                    '/',
                    '',
                    is_ssl(),
                    true
                );

                $_COOKIE[$cookie_name] = '1';
            }
        }
    }

    private function get_visitor_hash(): string {
        if (is_user_logged_in()) {
            return 'u_' . get_current_user_id();
        }

        $cookie_name = 'giftmax_visitor_id';
        $visitor_id = isset($_COOKIE[$cookie_name]) ? sanitize_text_field(wp_unslash($_COOKIE[$cookie_name])) : '';

        if ($visitor_id === '' || !preg_match('/^[A-Za-z0-9_-]{16,80}$/', $visitor_id)) {
            $visitor_id = str_replace('-', '', wp_generate_uuid4());
            setcookie(
                $cookie_name,
                $visitor_id,
                time() + (100 * YEAR_IN_SECONDS),
                COOKIEPATH ? COOKIEPATH : '/',
                COOKIE_DOMAIN,
                is_ssl(),
                true
            );
            $_COOKIE[$cookie_name] = $visitor_id;
        }

        return 'g_' . $visitor_id;
    }
}
