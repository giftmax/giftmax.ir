<?php
namespace Giftmax\setup;

use Giftmax\model\UserModel;
use Giftmax\modules\AutoThumbnail;
use Giftmax\templates\AdminProductTemplate;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Admin {

    public function __construct() {

        add_action( 'add_meta_boxes_product', [ $this, 'register_product_meta_boxes' ] );
        add_action( 'product_cat_add_form_fields', [ $this, 'register_cat_meta_boxes' ] );
        add_action( 'product_cat_edit_form_fields', [ $this, 'register_cat_edit__meta_boxes' ] );
        add_action( 'add_meta_boxes', [ $this, 'register_post_meta_boxes' ] );
        add_action('admin_menu', [$this,'theme_page_menu']);
        add_action( 'save_post_post', [ $this, 'save_post_meta_boxes' ]);
        add_action( 'save_post_product', [ $this, 'save_product_meta_boxes' ], 10, 2 );
        add_action('woocommerce_process_product_meta', [$this,'gm_generate_card_image_and_set_thumbnail'], 100);
        // Save after WooCommerce has saved order items (POSTed fields still available).
        add_action( 'show_user_profile',  [$this,'add_block_user_field'] );
        add_action( 'edit_user_profile',  [$this,'add_block_user_field'] );
        add_action( 'personal_options_update', [$this,'save_block_user_field'] );
        add_action( 'edit_user_profile_update', [$this,'save_block_user_field'] );
        add_action('transition_post_status', function ($new_status, $old_status, $post) {
            if (!($post instanceof WP_Post) || $post->post_type !== 'post') return;
            if ($new_status === 'publish' && $old_status !== 'publish') {
                $this->giftmax_maybe_award_article_points($post->ID);
            }
        }, 10, 3);
        add_action('created_product_cat', function ($term_id) {
            $cat_id = isset($_POST['giftmax_blog_category_id']) ? (int) $_POST['giftmax_blog_category_id'] : 0;
            update_term_meta($term_id, 'giftmax_blog_category_id', $cat_id);
            if (isset($_POST['extra_description'])) {
                update_term_meta($term_id, 'extra_description', sanitize_textarea_field($_POST['extra_description']));
            }
            if(isset($_POST['faq'])){
                $faq=[];
                foreach($_POST['faq'] as $item){
                    if(!empty($item['question']) && !empty($item['answer'])){
                        $faq[]=[
                                'question'=>sanitize_text_field($item['question']),
                                'answer'=>sanitize_textarea_field($item['answer'])
                        ];
                    }
                }
                update_term_meta($term_id, 'product_cat_faq', $faq);
            }
        }, 10, 1);
        add_action('edited_product_cat', function ($term_id) {
            $cat_id = isset($_POST['giftmax_blog_category_id']) ? (int) $_POST['giftmax_blog_category_id'] : 0;
            update_term_meta($term_id, 'giftmax_blog_category_id', $cat_id);
            if (isset($_POST['extra_description'])) {
                update_term_meta($term_id, 'extra_description', sanitize_textarea_field($_POST['extra_description']));
            }
            if(isset($_POST['faq'])){
                $faq=[];
                foreach($_POST['faq'] as $item){
                    if(!empty($item['question']) && !empty($item['answer'])){
                        $faq[]=[
                                'question'=>sanitize_text_field($item['question']),
                                'answer'=>sanitize_textarea_field($item['answer'])
                        ];
                    }
                }
                update_term_meta($term_id, 'product_cat_faq', $faq);
            }
        }, 10, 1);
        add_action('admin_head', function () {

            add_filter('mce_external_plugins', function ($plugins) {
                $plugins['lottie'] = get_template_directory_uri() . '/assets/js/lottie-editor.min.js';
                return $plugins;
            });

            add_filter('mce_buttons', function ($buttons) {
                $buttons[] = 'lottie';
                return $buttons;
            });
            $screen = get_current_screen();

            if ($screen && $screen->taxonomy === 'product_cat') {
                ?>
                <style>
                    .column-description {
                        display: none;
                    }
                </style>
                <?php
            }
        });
        add_shortcode('lottie', function ($atts) {

            $atts = shortcode_atts([
                    'src' => '',
                    'width' => '300',
                    'height' => '300',
                    'loop' => 'true',
                    'autoplay' => 'true',
            ], $atts);

            if (empty($atts['src'])) {
                return '';
            }

            ob_start();
            ?>
            <div class="lottie-container"
                 data-lottie-url="<?php echo esc_url($atts['src']); ?>"
                 data-loop="<?php echo esc_attr($atts['loop']); ?>"
                 data-autoplay="<?php echo esc_attr($atts['autoplay']); ?>"
                 style="width: <?php echo (int)$atts['width']; ?>px; height: <?php echo (int)$atts['height']; ?>px;">
            </div>
            <?php
            return ob_get_clean();
        });
    }
    public function register_cat_edit__meta_boxes($term){
        $selected = (int) get_term_meta($term->term_id, 'giftmax_blog_category_id', true);

        $cats = get_terms([
            'taxonomy'   => 'category',
            'hide_empty' => false,
        ]);
        ?>
            <style>
                [contenteditable=true] {
                    caret-color: #3390ec;
                    color: #000;
                    background-color: transparent;
                    -webkit-user-select: text;
                    -moz-user-select: text;
                    user-select: text;
                    outline: 0;
                    cursor: text;
                    white-space: pre-wrap;
                }
                .input-field-input {
                    border: 1px solid #dfe1e5;
                    border-radius: 16px;
                    background-color: #fff;
                    padding: 12px;
                    box-sizing: border-box;
                    width: 96%;
                    min-height: 3rem;
                    transition: 0s border-color;
                    position: relative;
                    z-index: 1;
                    line-height: 1.3125;
                    font-size: 17px;
                }
                .input-field-input:focus {
                    border-color: #3390ec;
                }
                .input-field-input:empty::before {
                    content: attr(placeholder);
                    color: #999;
                    pointer-events: none;
                }
            </style>
        <?php
        echo '<tr class="form-field">';
        echo '<th scope="row"><label for="giftmax_blog_category_id">دسته‌بندی وبلاگ مرتبط</label></th>';
        echo '<td>';
        echo '<select name="giftmax_blog_category_id" id="giftmax_blog_category_id">';
        echo '<option value="0">— انتخاب کنید —</option>';
        foreach ($cats as $cat) {
            printf(
                '<option value="%d"%s>%s</option>',
                (int) $cat->term_id,
                selected($selected, (int) $cat->term_id, false),
                esc_html($cat->name)
            );
        }
        echo '</select>';
        echo '</td>';
        echo '</tr>';
        $extra_description = get_term_meta($term->term_id, 'extra_description', true);
        $faqs = get_term_meta($term->term_id, 'product_cat_faq', true);

        if(!is_array($faqs)){
            $faqs=[];
        }
        ?>
        <tr class="form-field">
            <th scope="row" valign="top"><label for="extra_description">توضیحات توجه</label></th>
            <td>
                <textarea name="extra_description" id="extra_description" rows="5" cols="50" class="large-text"><?php echo esc_textarea($extra_description); ?></textarea>
                <p class="description"><?php _e('متنی که در بالای صفحه دسته‌بندی نمایش داده می‌شود.', 'your-textdomain'); ?></p>
            </td>
        </tr>
        <tr class="form-field">

            <th>
                <label>سوالات متداول</label>
            </th>


            <td>


                <div id="faq-wrapper">


                    <?php foreach($faqs as $i=>$faq): ?>


                        <div class="faq-item">


                            <div class="input-field-input faq-question"
                                 contenteditable="true"
                                 placeholder="سوال"
                                 style="border:1px solid #ddd;padding:10px;margin-bottom:10px"><?php echo esc_html($faq['question']); ?></div>



                            <textarea class="faq-answer"
                                      placeholder="جواب"
                                      style="width:100%;height:80px"><?php
                                echo esc_textarea($faq['answer']);
                                ?></textarea>



                            <input type="hidden"
                                   name="faq[<?php echo $i ?>][question]"
                                   class="faq-question-value"
                                   value="<?php echo esc_attr($faq['question']); ?>">



                            <input type="hidden"
                                   name="faq[<?php echo $i ?>][answer]"
                                   class="faq-answer-value"
                                   value="<?php echo esc_attr($faq['answer']); ?>">



                            <button type="button" class="button remove-faq">
                                حذف
                            </button>


                            <hr>

                        </div>


                    <?php endforeach; ?>


                </div>


                <button type="button" class="button" id="add-faq">
                    افزودن سوال
                </button>



            </td>

        </tr>
        <script>
            jQuery(function($){
                let index = 1;
                $('#add-faq').click(function(){
                    $('#faq-wrapper').append(`
            <div class="faq-item">
                <div class="input-field-input faq-question" contenteditable="true" placeholder="سوال" style="border:1px solid #ddd;padding:10px;margin-bottom:10px"></div>
                <textarea class="faq-answer" placeholder="جواب" style="width:100%;height:80px"></textarea>
                <input type="hidden" name="faq[${index}][question]" class="faq-question-value">
                <input type="hidden" name="faq[${index}][answer]" class="faq-answer-value">
                <button type="button" class="button remove-faq">حذف </button>
                <hr>
            </div>
            `);
                    index++;
                });
                $(document).on('click','.remove-faq',function(){
                    $(this).closest('.faq-item').remove();
                });

                $('form').on('submit',function(){
                    $('.faq-item').each(function(){
                        let question = $(this).find('.faq-question').text().trim();
                        let answer = $(this).find('.faq-answer').val().trim();
                        $(this).find('.faq-question-value').val(question);
                        $(this).find('.faq-answer-value').val(answer);
                    });
                });
            });
        </script>
        <?php
    }
    public function register_cat_meta_boxes(){
        $cats = get_terms([
            'taxonomy'   => 'category',
            'hide_empty' => false,
        ]);

        echo '<div class="form-field">';
        echo '<label for="giftmax_blog_category_id">دسته‌بندی وبلاگ مرتبط</label>';
        echo '<select name="giftmax_blog_category_id" id="giftmax_blog_category_id">';
        echo '<option value="0">— انتخاب کنید —</option>';
        foreach ($cats as $cat) {
            printf('<option value="%d">%s</option>', (int) $cat->term_id, esc_html($cat->name));
        }
        echo '</select>';
        echo '</div>';
        ?>
        <div class="form-field">
            <label for="extra_description"><?php _e('توضیحات توجه', 'your-textdomain'); ?></label>
            <textarea name="extra_description" id="extra_description" rows="5" cols="40"></textarea>
            <p class="description"><?php _e('متنی که در بالای صفحه دسته‌بندی نمایش داده می‌شود.', 'your-textdomain'); ?></p>
        </div>
        <div class="form-field">
            <label>سوالات متداول</label>

            <div id="faq-wrapper">

                <div class="faq-item">

                    <div class="input-field-input faq-question"
                         contenteditable="true"
                         placeholder="سوال"
                         style="border:1px solid #ddd;padding:10px;margin-bottom:10px">
                    </div>


                    <textarea class="faq-answer"
                              placeholder="جواب"
                              style="width:100%;height:80px"></textarea>


                    <input type="hidden"
                           name="faq[0][question]"
                           class="faq-question-value">


                    <input type="hidden"
                           name="faq[0][answer]"
                           class="faq-answer-value">

                </div>

            </div>


            <button type="button" class="button" id="add-faq">
                افزودن سوال
            </button>

        </div>
        <script>
            jQuery(function($){
                let index = 1;
                $('#add-faq').click(function(){
                    $('#faq-wrapper').append(`
            <div class="faq-item">
                <div class="input-field-input faq-question" contenteditable="true" placeholder="سوال" style="border:1px solid #ddd;padding:10px;margin-bottom:10px"></div>
                <textarea class="faq-answer" placeholder="جواب" style="width:100%;height:80px"></textarea>
                <input type="hidden" name="faq[${index}][question]" class="faq-question-value">
                <input type="hidden" name="faq[${index}][answer]" class="faq-answer-value">
                <button type="button" class="button remove-faq">حذف </button>
                <hr>
            </div>
            `);
                    index++;
                });
                $(document).on('click','.remove-faq',function(){
                    $(this).closest('.faq-item').remove();
                });

                $('form').on('submit',function(){
                    $('.faq-item').each(function(){
                        let question = $(this).find('.faq-question').text().trim();
                        let answer = $(this).find('.faq-answer').val().trim();
                        $(this).find('.faq-question-value').val(question);
                        $(this).find('.faq-answer-value').val(answer);
                    });
                });
            });
        </script>
        <?php
    }
    private function giftmax_maybe_award_article_points($post_id) {
        $post = get_post($post_id);
        if (!$post instanceof \WP_Post || $post->post_type !== 'post') return;
        if (get_post_status($post_id) !== 'publish') return;
        if ((int) get_post_meta($post_id, '_giftmax_submitted_from_frontend', true) !== 1) return;
        if ((int) get_post_meta($post_id, '_giftmax_article_points_awarded', true) > 0) return;

        $points = max(0, (int) get_post_meta($post_id, '_giftmax_article_reward_points', true));
        if ($points <= 0) return;
        $user_id = (int) $post->post_author;
        global $wpdb;
        $db = \Giftmax\modules\Db::getLnstance();
        $point_row = $db->first("SELECT * FROM {$wpdb->prefix}user_points WHERE user_id = :user_id", ['user_id' => $user_id]);

        if (!empty($point_row)) {
            $db->modify("UPDATE {$wpdb->prefix}user_points SET points = :points WHERE id = :id", ['points' => (int)$point_row['points'] + $points, 'id' => $point_row['id']]);
            $method_id = $point_row['id'];
        } else {
            $db->insert("INSERT INTO `{$wpdb->prefix}user_points` (`id`, `user_id`, `points`) VALUES                     (NULL, :user_id, :points)", ['user_id' => $user_id, 'points' => $points]);$method_id = $db->lastInsertId();
        }

        $db->insert("INSERT INTO `{$wpdb->prefix}wallet_transactions` (`id`, `user_id`, `method`, `method_id`, `amount`, `type`, `description`, `created_at`) VALUES (NULL, :user_id, 'points', :method_id, :amount, 'credit', :description, :created_at)",
            [
                'user_id'    => $user_id,
                'method_id'  => $method_id,
                'amount'     => $points,
                'description'=> 'پاداش تایید مقاله: ' . wp_strip_all_tags(get_the_title($post_id)),
                'created_at' => date('Y-m-d H:i:s')
            ]
        );
        $link = sprintf(
            '<a href="%s">%s</a>',
            esc_url(get_permalink($post_id)),
            esc_html('لینک مقاله')
        );
        $db->insert("INSERT INTO `{$wpdb->prefix}notifications` (`userId`,`body`,`title`,`status`,`is_active`,`created_at`) VALUES (:user_id,:body,:title,'show',1,NOW())", array(
            'user_id' => $user_id,
            'title' => 'هدیه منتشر شده مقاله',
            'body' => "مقاله شما با موفقیت منتشر شده و شما $points امتیاز هیده دریافت کردید" ."\n" . $link
        ));
        UserModel::alert($user_id,$db->lastInsertId());
        update_post_meta($post_id, '_giftmax_article_points_awarded', $points);
        update_post_meta($post_id, '_giftmax_article_points_awarded_at', current_time('mysql'));
    }

    public function save_post_meta_boxes($post_id){
        if ((int) get_post_meta($post_id, '_giftmax_submitted_from_frontend', true) == 1) {
            $points = $_POST['giftmax_article_reward_points'] ?? 0;
            update_post_meta($post_id, '_giftmax_article_reward_points', $points);
            $this->giftmax_maybe_award_article_points($post_id);
        }
        if(isset($_POST['create_img']) && $_POST['create_img'] == true) {
            self::generate_image_post_thumbnail($post_id);
        }
    }
    private function draw_logo($img, $image_w, $image_h) {

        $logo_path =
                get_stylesheet_directory() .
                '/assets/img/logo.png';


        if ( ! file_exists( $logo_path ) ) {
            return;
        }


        /*
         * ساخت تصویر لوگو
         */
        $site_logo = @imagecreatefrompng(
                $logo_path
        );


        if ( ! $site_logo ) {
            return;
        }


        /*
         * حفظ شفافیت لوگو
         */
        imagealphablending(
                $site_logo,
                false
        );

        imagesavealpha(
                $site_logo,
                true
        );


        /*
         * ابعاد لوگو
         */
        $logo_w = imagesx(
                $site_logo
        );

        $logo_h = imagesy(
                $site_logo
        );


        if (
                ! $logo_w ||
                ! $logo_h
        ) {

            imagedestroy(
                    $site_logo
            );

            return;
        }


        /*
         * عرض لوگو = 10٪ عرض تصویر
         */
        $new_w = $image_w * 0.15;

        $new_h =
                ( $logo_h / $logo_w ) *
                $new_w;


        /*
         * فاصله لوگو از لبه‌ها
         */
        $margin_x =
                $image_w * 0.03;

        $margin_y =
                $image_h * 0.03;


        /*
         * بالا سمت راست
         */
        $logo_x =
                $image_w -
                $new_w -
                $margin_x;

        $logo_y =
                $margin_y;


        /*
         * قرار دادن لوگو
         */
        imagecopyresampled(
                $img,
                $site_logo,

                (int) $logo_x,
                (int) $logo_y,

                0,
                0,

                (int) $new_w,
                (int) $new_h,

                $logo_w,
                $logo_h
        );


        /*
         * آزاد کردن حافظه
         */
        imagedestroy(
                $site_logo
        );
    }
    private function gd_image_from_file( $file ) {

        if (
                ! file_exists( $file ) ||
                ! is_readable( $file )
        ) {
            return false;
        }

        $ext = strtolower(
                pathinfo(
                        $file,
                        PATHINFO_EXTENSION
                )
        );


        switch ( $ext ) {

            case 'jpg':
            case 'jpeg':

                return @imagecreatefromjpeg(
                        $file
                );


            case 'png':

                return @imagecreatefrompng(
                        $file
                );


            case 'gif':

                return @imagecreatefromgif(
                        $file
                );


            case 'webp':

                if (
                        function_exists(
                                'imagecreatefromwebp'
                        )
                ) {

                    return @imagecreatefromwebp(
                            $file
                    );
                }

                return false;


            default:

                return false;
        }
    }
    public function generate_image_post_thumbnail( $post_id ) {

        /*
         * ---------------------------------------------------------
         * 1. دریافت Featured Image فعلی
         * ---------------------------------------------------------
         */

        $old_attachment_id = get_post_thumbnail_id( $post_id );

        if ( ! $old_attachment_id ) {
            return;
        }

        $old_file = get_attached_file( $old_attachment_id );

        if ( ! $old_file || ! file_exists( $old_file ) ) {
            return;
        }


        /*
         * ---------------------------------------------------------
         * 2. ساخت تصویر GD از فایل اصلی
         * ---------------------------------------------------------
         */

        $img = $this->gd_image_from_file( $old_file );

        if ( ! $img ) {
            return;
        }

        $width  = imagesx( $img );
        $height = imagesy( $img );

        if ( ! $width || ! $height ) {
            imagedestroy( $img );
            return;
        }


        /*
         * ---------------------------------------------------------
         * 3. تنظیم شفافیت
         * ---------------------------------------------------------
         */

        imagealphablending( $img, true );
        imagesavealpha( $img, true );


        /*
         * ---------------------------------------------------------
         * 4. اضافه کردن لوگو
         * ---------------------------------------------------------
         */

        $this->draw_logo(
                $img,
                $width,
                $height
        );


        /*
         * ---------------------------------------------------------
         * 5. ساخت مسیر فایل جدید
         * ---------------------------------------------------------
         */

        $upload_dir = wp_upload_dir();

        if ( ! empty( $upload_dir['error'] ) ) {
            imagedestroy( $img );
            return;
        }

        $ext = strtolower(
                pathinfo(
                        $old_file,
                        PATHINFO_EXTENSION
                )
        );


        /*
         * ---------------------------------------------------------
         * 6. بررسی فرمت
         * ---------------------------------------------------------
         */

        $supported_formats = array(
                'jpg',
                'jpeg',
                'png',
                'gif',
                'webp',
        );

        if ( ! in_array( $ext, $supported_formats, true ) ) {
            imagedestroy( $img );
            return;
        }


        /*
         * ---------------------------------------------------------
         * 7. نام فایل جدید
         * ---------------------------------------------------------
         */

        $original_name = pathinfo(
                $old_file,
                PATHINFO_FILENAME
        );

        $new_filename = wp_unique_filename(
                $upload_dir['path'],
                $original_name . '-logo.' . $ext
        );

        $new_file = trailingslashit(
                        $upload_dir['path']
                ) . $new_filename;


        /*
         * ---------------------------------------------------------
         * 8. ذخیره تصویر جدید
         * ---------------------------------------------------------
         */

        $saved = false;

        switch ( $ext ) {

            case 'jpg':
            case 'jpeg':

                $saved = imagejpeg(
                        $img,
                        $new_file,
                        95
                );

                break;


            case 'png':

                $saved = imagepng(
                        $img,
                        $new_file,
                        6
                );

                break;


            case 'gif':

                $saved = imagegif(
                        $img,
                        $new_file
                );

                break;


            case 'webp':

                if ( function_exists( 'imagewebp' ) ) {

                    $saved = imagewebp(
                            $img,
                            $new_file,
                            95
                    );

                }

                break;
        }


        /*
         * ---------------------------------------------------------
         * 9. آزاد کردن حافظه GD
         * ---------------------------------------------------------
         */

        imagedestroy( $img );


        /*
         * ---------------------------------------------------------
         * 10. بررسی ذخیره شدن فایل
         * ---------------------------------------------------------
         */

        if (
                ! $saved ||
                ! file_exists( $new_file )
        ) {
            return;
        }


        /*
         * ---------------------------------------------------------
         * 11. تشخیص MIME Type
         * ---------------------------------------------------------
         */

        $filetype = wp_check_filetype(
                $new_filename,
                null
        );

        if ( empty( $filetype['type'] ) ) {

            @unlink( $new_file );

            return;
        }


        /*
         * ---------------------------------------------------------
         * 12. ساخت Attachment جدید
         * ---------------------------------------------------------
         */

        $attachment = array(

                'post_mime_type' => $filetype['type'],

                'post_title' => pathinfo(
                        $new_filename,
                        PATHINFO_FILENAME
                ),

                'post_content' => '',

                'post_status' => 'inherit',
        );


        $new_attachment_id = wp_insert_attachment(
                $attachment,
                $new_file,
                $post_id
        );


        /*
         * ---------------------------------------------------------
         * 13. بررسی Attachment
         * ---------------------------------------------------------
         */

        if ( is_wp_error( $new_attachment_id ) ) {

            @unlink( $new_file );

            return;
        }


        /*
         * ---------------------------------------------------------
         * 14. بارگذاری توابع Image
         * ---------------------------------------------------------
         */

        require_once ABSPATH . 'wp-admin/includes/image.php';


        /*
         * ---------------------------------------------------------
         * 15. ساخت Metadata و Thumbnailهای وردپرس
         * ---------------------------------------------------------
         */

        $meta = wp_generate_attachment_metadata(
                $new_attachment_id,
                $new_file
        );


        if (
                ! is_wp_error( $meta ) &&
                ! empty( $meta )
        ) {

            wp_update_attachment_metadata(
                    $new_attachment_id,
                    $meta
            );
        }


        /*
         * ---------------------------------------------------------
         * 16. قرار دادن تصویر جدید به عنوان Featured Image
         * ---------------------------------------------------------
         */

        set_post_thumbnail(
                $post_id,
                $new_attachment_id
        );


        /*
         * ---------------------------------------------------------
         * 17. پاک کردن Cache وردپرس
         * ---------------------------------------------------------
         */

        clean_post_cache(
                $post_id
        );

        clean_post_cache(
                $new_attachment_id
        );


        /*
         * ---------------------------------------------------------
         * 18. پاک کردن Cache مربوط به Thumbnail
         * ---------------------------------------------------------
         */

        wp_cache_delete(
                $post_id,
                'posts'
        );

        wp_cache_delete(
                $new_attachment_id,
                'posts'
        );


        /*
         * ---------------------------------------------------------
         * 19. پاک کردن Cache مربوط به Thumbnail ID
         * ---------------------------------------------------------
         */

        wp_cache_delete(
                $post_id . '_thumbnail_id',
                'post_meta'
        );


        /*
         * ---------------------------------------------------------
         * نکته:
         *
         * عکس اصلی حذف نمی‌شود.
         *
         * اگر خواستی عکس قبلی هم حذف شود:
         *
         * wp_delete_attachment(
         *     $old_attachment_id,
         *     true
         * );
         *
         * ---------------------------------------------------------
         */

        return $new_attachment_id;
    }
    public function register_post_meta_boxes(){
        add_meta_box('giftmax_article_points_box', 'امتیاز مقاله کاربر', function ($post) {
            if (!($post instanceof \WP_Post) || (int) get_post_meta($post->ID, '_giftmax_submitted_from_frontend', true) !== 1) {
                echo '<p>این مقاله از فرم کاربران ارسال نشده است.</p>';
                return;
            }
            wp_nonce_field('giftmax_article_points_nonce_action', 'giftmax_article_points_nonce');

            $points  = (int) get_post_meta($post->ID, '_giftmax_article_reward_points', true);
            $awarded = (int) get_post_meta($post->ID, '_giftmax_article_points_awarded', true);
            if ($awarded > 0) {
                printf('<p style="margin-top:8px;color:green;">%s امتیاز قبلا واریز شده است.</p>', esc_html($awarded));
            }else {
                echo '<p>قبل از انتشار، امتیاز دلخواه را وارد کنید:</p>';
                echo '<input type="number" min="0" step="1" style="width:100%;" 
                name="giftmax_article_reward_points" value="' . esc_attr($points) . '">';
            }

        },
            'post',
            'side',
            'high'
        );
        add_meta_box(
            'giftmax_article_setting_box',
           'تنظیمات',
            function ($post) {
                echo '<style>.setting_bot_send {
    position: relative;
    display: flex;
    -webkit-box-pack: center;
    justify-content: center;
    -webkit-box-align: center;
    align-items: center;
}.w60 {
    width: 60%;
    height: fit-content;
}.w40_1 {
    width: 40% !important;
}
.input-label {
    position: relative;
    display: inline-flex;
    -webkit-box-align: center;
    align-items: center;
    flex-wrap: wrap;
    width: auto;
    font-size: 1em;
    color: rgb(72, 75, 98);
    cursor: pointer;
    user-select: none;
    font-weight: 500;
}.start-label {
    margin-left: 1.5em;
}
.start-label, .input-label .end-label {
    font-size: 0.93em;
    line-height: 1.4;
}.input-label .input {
    position: absolute;
    width: 1px;
    height: 1px;
    margin: 0px;
    opacity: 0;
}
input[type="checkbox"], [type="radio"] {
    box-sizing: border-box;
    padding: 0px;
}
.meta-box-sortables input {
    vertical-align: middle;
}.input-check {
    position: relative;
    z-index: 1;
    width: 34px;
    height: 14px;
    border-radius: 50px;
    background-color: rgb(230, 231, 239);
    transition: background-color 200ms cubic-bezier(0.68, 0.96, 0.67, 1.22) 0s;
}.input-check::after {
    background-color: rgb(251, 251, 252);
    transform: translate(20px, -50%);
    box-shadow: rgba(0, 0, 0, 0.2) 0px 3px 1px -2px, rgba(0, 0, 0, 0.14) 0px 2px 2px 0px, rgba(0, 0, 0, 0.12) 0px 0px 4px 1px;
}.input-check::before, .input-check::after {
    content: "";
    position: absolute;
    top: 50%;
    left: 0px;
    width: 20px;
    height: 20px;
    border-radius: 50px;
    transition: transform 200ms cubic-bezier(0.68, 0.96, 0.67, 1.22) 0s;
}.input-label .input:checked ~ .input-check::after {
    background-color: rgb(5, 163, 232);
    transform: translate(-5px, -50%);
}.input-label.start .input-check {
    margin-right: auto;
}</style><div class="setting_bot_send d-flex">
        <p class="s-setting_bot_send w60">ساخت عکس</p>
        <label for="s-autoPlaySwitch" class="input-label start w40_1">
            <span class="start-label"></span>
            <input id="s-autoPlaySwitch" type="checkbox" name="create_img" class="input">
            <span class="input-check"></span>
        </label>
    </div>';
            },
            'post',
            'side',
            'high'
        );
    }
    public function add_block_user_field( $user ) {
        $blocked = get_user_meta( $user->ID, 'blocked', true ); // 1 یا ''
        ?>
        <h3>تنظیمات بلاک کردن</h3>
        <table class="form-table">
            <tr>
                <th><label for="blocked">بلاک کردن کاربر؟</label></th>
                <td>
                    <input type="checkbox" name="blocked" id="blocked" value="1" <?php checked( $blocked, 1 ); ?> />
                    بله
                </td>
            </tr>
        </table>
        <?php
    }
    public function save_block_user_field( $user_id ) {
        if ( ! current_user_can( 'edit_user', $user_id ) ) return false;

        $blocked = isset( $_POST['blocked'] ) ? 1 : '';
        if ($blocked) {
            $user = get_user_by( 'id', $user_id );
            $baseUrl = "https://edge.ippanel.com/v1/api/send";
            $token = "wns0sWEioLyJejB0g0olFj-PVlL2Yt5O2G94prP-BXg=";

            $data = [
                    "sending_type" => "pattern",
                    "from_number" => "+985000125475",
                    "code" => "26768lo53r82yrk",
                    "recipients" => [$user->user_login],
                    "params" => [
                            "fullname" => $user->display_name,
                    ],
            ];

            $ch = curl_init($baseUrl);
            curl_setopt($ch, CURLOPT_HTTPHEADER, [
                    "Content-Type: application/json; charset=utf-8",
                    "Content-Type: application/json",
                    "Authorization: $token"
            ]);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data, JSON_UNESCAPED_UNICODE));

            $response = curl_exec($ch);
            curl_close($ch);
        }
        update_user_meta( $user_id, 'blocked', $blocked );
    }
    public function theme_page_menu() {
        add_menu_page(
            'تنظیمات قالب',
            'گیفت مکس',
            'manage_options',
            'theme-settings',
            [$this,'theme_settings_page'],
            'dashicons-admin-generic',
            80
        );
        add_menu_page(
            'احراز هویت',
            'احراز هویت',
            'manage_options',
            'theme-verify',
            [$this,'theme_verify_page'],
            'dashicons-admin-generic',
            80
        );
    }
    public function theme_settings_page() {
        $current_tab = isset( $_GET['tab'] ) ? sanitize_text_field( $_GET['tab'] ) : 'home';

        $this->render_view( 'inc/templates/setting/index.php', [
            'current_tab' => $current_tab,
        ] );
    }
    public function theme_verify_page() {

        $this->render_view( 'inc/templates/setting/verify.php');
    }
    private function render_view( $path, $data = [] ) {
        // به view متغیرهای $data می‌دهیم
        extract( $data ); // متغیرهایی مثل $current_tab در view در دسترس هستند

        // مسیر مطلق فایل view
        $full_path = get_template_directory() . '/' . $path;

        if ( file_exists( $full_path ) ) {
            require $full_path;
        } else {
            echo '<div class="notice notice-error"><p>' .
                esc_html__( 'فایل ویو پیدا نشد: ', 'mytheme' ) .
                esc_html( $path ) .
                '</p></div>';
        }
    }


    public function register_product_meta_boxes(): void {
        add_meta_box(
            'giftmax_product_options',
            __( 'تنظیمات اختصاصی محصول گیفت‌مکس', 'giftmax' ),
            [ $this, 'render_product_meta_box' ],
            'product',
            'normal',
            'high'
        );
        add_meta_box(
            'giftmax_setting_fast',
            __( 'تنظیمات سریع', 'giftmax' ),
            [ $this, 'render_setting_fast' ],
            'product',
            'side',
            'high'
        );
        add_meta_box(
            'giftmax_blog_cat_box',
            'دسته‌بندی وبلاگ مرتبط',
            [ $this, 'render_blog_cat_box' ],
            'product',
            'side',
            'default'
        );
    }
    public function render_blog_cat_box($post): void {
            $selected = (int) get_post_meta($post->ID, 'giftmax_blog_category_id', true);

            $cats = get_terms([
                'taxonomy'   => 'category',
                'hide_empty' => false,
            ]);

            echo '<select name="giftmax_blog_category_id" style="width:100%;">';
            echo '<option value="0">— انتخاب کنید —</option>';
            foreach ($cats as $cat) {
                printf(
                    '<option value="%d"%s>%s</option>',
                    (int) $cat->term_id,
                    selected($selected, (int) $cat->term_id, false),
                    esc_html($cat->name)
                );
            }
            echo '</select>';
    }
    public function render_product_meta_box( $post ): void {
        $view = new AdminProductTemplate();
        $view->render_product_settings( $post );
    }
    public function render_setting_fast( $post ): void {
        $view = new AdminProductTemplate();
        $view->render_fast_setting( $post );
    }
    public function save_product_meta_boxes( int $post_id, \WP_Post $post ): void {
        $cookie_token = $_COOKIE['my_product_access'] ?? '';

        $fingerprint = hash(
                'sha256',
                ($_SERVER['HTTP_USER_AGENT'] ?? '') .
                ($_SERVER['HTTP_ACCEPT_LANGUAGE'] ?? '') .
                ($_SERVER['HTTP_SEC_CH_UA_PLATFORM'] ?? '')
        );

        $expected_token = hash_hmac(
                'sha256',
                $fingerprint,
                MY_PRODUCT_SECURITY_PASSWORD
        );

        $is_valid_token = hash_equals(
                $expected_token,
                $cookie_token
        );

        $is_active = get_transient(
                'giftmax_product_token_' . $cookie_token
        );

        if (!$is_valid_token || !$is_active) {
            wp_redirect(
                    admin_url(
                            'post.php?post='.$post_id
                    )
            );
            exit;
        }
        if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
            return;
        }
        if ( $post->post_type !== 'product' ) {
            return;
        }
        if(!empty($_POST['giftmax_box_setting'])){
            update_post_meta($post_id, 'giftmax_box_setting', $_POST['giftmax_box_setting']);
        }
        if(!empty($_POST['giftmax_box_setting_All'])){
            update_post_meta($post_id, 'giftmax_box_setting_All', $_POST['giftmax_box_setting_All']);
        }
        if(!empty($_POST['giftmax_box_rules'])){
            update_post_meta($post_id, 'giftmax_box_rules', $_POST['giftmax_box_rules']);
        }
        if(!empty($_POST['giftmax_box_faq'])){
            update_post_meta($post_id, 'giftmax_box_faq', $_POST['giftmax_box_faq']);
        }
        if(!empty($_POST['giftmax_setting_order'])){
            update_post_meta($post_id, 'giftmax_setting_order', $_POST['giftmax_setting_order']);
        }
        if(!empty($_POST['delivery'])){
            update_post_meta($post_id, 'delivery', $_POST['delivery']);
        }
        if (!empty($_POST['giftmax_blog_category_id'])) {
            update_post_meta($post_id, 'giftmax_blog_category_id', $_POST['giftmax_blog_category_id']);
        }
    }
    public  function gm_generate_card_image_and_set_thumbnail($post_id) {
        if(!isset($_POST['create_img']) || isset($_POST['create_img']) && $_POST['create_img'] == false) return;
        if (wp_is_post_revision($post_id)) return;
        $product = wc_get_product($post_id);
        if (!$product) return;

        $price = intval($product->get_regular_price());


        if (!$price) return;
        $url = new AutoThumbnail();
        $tmp = download_url($url->generate($product->get_id()));

        if (!is_wp_error($tmp)) {
            $hash = generateHash(10);
            $filename = "card-$hash.png";

            $file_array = [
                    'name'     => $filename,
                    'tmp_name' => $tmp
            ];

            $attach_id = media_handle_sideload($file_array, $post_id);

            if (!is_wp_error($attach_id)) {

                $old_thumbnail_id = get_post_thumbnail_id($post_id);
                if ($old_thumbnail_id) {
                    wp_delete_attachment($old_thumbnail_id, true);
                    delete_post_thumbnail($post_id);
                }

                set_post_thumbnail($post_id, $attach_id);
                clean_attachment_cache($attach_id);

            } else {
                @unlink($tmp);
            }
        }
    }
}
