<?php
namespace Giftmax\blog;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Blog {

    public function __construct() {
        add_action('wp_head', function() {
            $this->record_post_views(get_the_ID());
        });
    }
    public function record_post_views($post_id) {
        if (!is_single()) return;

        if (empty($post_id)) {
            global $post;
            $post_id = $post->ID;
        }

        $user_ip = $_SERVER['REMOTE_ADDR'];
        $cookie_name = 'viewed_post_' . $post_id;

        if(isset($_COOKIE[$cookie_name])) return;

        $views = get_post_meta($post_id, 'post_views', true);
        $views = $views ? intval($views) + 1 : 1;

        update_post_meta($post_id, 'post_views', $views);

        setcookie($cookie_name, $user_ip, time() + 86400, "/");
    }
}
