<?php
namespace Giftmax\modules;

class TicketModel
{
    public function __construct()
    {}

    public static function exist($name){
        global $wpdb;
        $db = Db::getLnstance();
        $records = $db->query("SELECT * FROM {$wpdb->prefix}ticketing_category WHERE `name`=:name", array(
            'name' => $name
        ));
        return $records;
    }
    public static function insert($name,$subset){
        if(!empty($subset)){
            $main_category = 0;
        }else{
            $main_category = 1;
        }
        global $wpdb;
        $db = Db::getLnstance();
        $db->insert("INSERT INTO `{$wpdb->prefix}ticketing_category` (`categoryId`, `name`, `subset`, `main_category`) VALUES (NULL, :name, :subset, :main_category)", array(
            'name' => $name,
            'subset' => $subset !== '' ? (int)$subset : 0,
            'main_category' => $main_category
        ));
    }
}
