<?php
namespace Giftmax\modules;

if (!defined('ABSPATH')) exit;

class AutoThumbnail
{
    public function __construct() {}
    public function generate(int $product_id) {
        $pid = $product_id;
        if (!$pid) return false;
        $product = wc_get_product($pid);
        if (!$product) return false;

        $settings = get_post_meta($pid, 'giftmax_box_setting', true);

        /* ---------- CANVAS ---------- */
        if (isset($settings[0]['bg_url']) && !empty($settings[0]['bg_url'])) {
            $img = \imagecreatefrompng($settings[0]['bg_url']);
        }else{
            $img = \imagecreatefrompng(
                get_stylesheet_directory() . '/assets/img/9eb926.png'
            );
        }
        \imagesavealpha($img, true);

        $width  = \imagesx($img);
        $height = \imagesy($img);

        /* ---------- HELPERS ---------- */
        $gm_url_to_path = function ($url) {
            if (!$url) return '';
            $upload = wp_upload_dir();
            if (strpos($url, $upload['baseurl']) === 0) {
                return $upload['basedir'] . substr($url, strlen($upload['baseurl']));
            }
            return $url;
        };

        $gm_load_image_any = function ($path) {
            if (!file_exists($path)) {
                return false;
            }

            $ext = strtolower(pathinfo($path, PATHINFO_EXTENSION));

            switch ($ext) {
                case 'svg':
                    if (!extension_loaded('imagick')) {
                        return false;
                    }

                    $imagick = new \Imagick();
                    $imagick->setBackgroundColor(new \ImagickPixel('transparent'));
                    $imagick->readImage($path);
                    $imagick->setImageFormat('png');

                    $blob = $imagick->getImageBlob();
                    $imagick->clear();
                    $imagick->destroy();

                    return imagecreatefromstring($blob);

                case 'png':
                    return imagecreatefrompng($path);

                case 'jpg':
                case 'jpeg':
                    return imagecreatefromjpeg($path);

                case 'gif':
                    return imagecreatefromgif($path);

                case 'webp':
                    return function_exists('imagecreatefromwebp')
                        ? imagecreatefromwebp($path)
                        : false;
            }

            return false;
        };
        /* ---------- PLATFORM LOGO ---------- */
        $platform_logo_url = $settings[0]['logo_platforms'] ?? '';

        $platform_logo     = $gm_load_image_any($gm_url_to_path($platform_logo_url));
        if ($platform_logo) {
            \imagecopyresampled(
                $img,
                $platform_logo,
                20, 20,      // X , Y
                0, 0,
                200, 200,
                \imagesx($platform_logo),
                \imagesy($platform_logo)
            );
            \imagedestroy($platform_logo);
        }

        /* ---------- PRODUCT NAME (CENTERED) ---------- */
        $draw = new \ImagickDraw();
        $draw->setFont(get_stylesheet_directory() . '/assets/font/Peyda-Bold.ttf');
        $draw->setFontSize(18);
        $draw->setTextAlignment(\Imagick::ALIGN_CENTER);
        $draw->setFillColor('white');

        $img_im = new \Imagick();
        $img_im->newImage($width, $height, new \ImagickPixel('transparent'));
        $img_im->setImageFormat('png');

        $img_im->annotateImage(
            $draw,
            300,
            145,
            0,
            $settings[0]['text_img']
        );
        $price = $settings[0]['price'];
        $currency = $settings[0]['currency_icon'];

        $drawPrice = new \ImagickDraw();
        $drawPrice->setFont(get_stylesheet_directory() . '/assets/font/BebasNeue-Regular.ttf');
        $drawPrice->setFontSize(45);
        $drawPrice->setFillColor('white');


        $drawCurrency = new \ImagickDraw();
        $drawCurrency->setFont(get_stylesheet_directory() . '/assets/font/LeagueGothic-Regular.ttf');
        $drawCurrency->setFontSize(35);
        $drawCurrency->setFillColor('white');

        $priceMetrics = $img_im->queryFontMetrics($drawPrice, $price);
        $currencyMetrics = $img_im->queryFontMetrics($drawCurrency, $currency);
        $spacing = 6;

        $priceX = 300;
        $priceY = 200;

        $currencyX = $priceX - $currencyMetrics['textWidth'] - $spacing;

        $currencyY = $priceY - (($priceMetrics['textHeight'] - $currencyMetrics['textHeight']) / 2) + 3;

        $img_im->annotateImage(
            $drawPrice,
            $priceX,
            $priceY,
            0,
            $price
        );

        $img_im->annotateImage(
            $drawCurrency,
            $currencyX,
            $currencyY,
            0,
            $currency
        );

        $image_png = \imagecreatefromstring($img_im->getImageBlob());
        \imagecopy($img, $image_png, 0, 0, 0, 0, $width, $height);
        \imagedestroy($image_png);

        /* ---------- SITE LOGO ---------- */
        $site_logo_path = get_stylesheet_directory() . '/assets/img/plogo.png';

        if (file_exists($site_logo_path)) {
            $site_logo = \imagecreatefrompng($site_logo_path);

            $logo_w  = \imagesx($site_logo);
            $logo_h  = \imagesy($site_logo);
            $new_w   = 80;
            $new_h   = 26.66666666666667;
            $logo_x  = 72;
            $logo_y  = 227;

            \imagecopyresampled(
                $img,
                $site_logo,
                $logo_x,
                $logo_y,
                0,
                0,
                $new_w,
                $new_h,
                $logo_w,
                $logo_h
            );

            \imagedestroy($site_logo);
        }

        /* ---------- OUTPUT ---------- */
        $upload = wp_upload_dir();
        if (!is_dir($upload['path'])) wp_mkdir_p($upload['path']);

        $file = $upload['path'] . '/giftmax_' . md5(uniqid()) . '.webp';

        \imagewebp($img, $file, 95);

        \imagedestroy($img);

        return file_exists($file) ? $upload['url'] . '/' . basename($file) : false;
    }

}
