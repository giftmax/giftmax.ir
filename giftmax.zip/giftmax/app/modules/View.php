<?php

namespace Giftmax\modules;
class View
{
    public static function render($filePath, $data = array(), $mustExit = array())
    {
        extract($data);
        ob_start();
        require_once(GIFTMAX__URI . $filePath);
    }

    public static function re($filePath, $data = array())
    {
        extract($data);
        ob_start();
        require GIFTMAX__URI . $filePath;
        $output = ob_get_clean();
        return $output;
    }
}