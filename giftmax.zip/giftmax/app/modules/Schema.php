
<?php

namespace Giftmax\modules;

class Schema {

    public static function init(){

        add_action('wp_head',[__CLASS__,'output_schema'],20);

    }

    public static function output_schema(){

        if(is_front_page()){

            self::website_schema();

        }

        if(is_product()){

            self::product_schema();

            self::breadcrumb_schema();

        }

        if(is_product_category()){

            self::collection_schema();

        }

    }

    private static function website_schema(){

        $data=[

            "@context"=>"https://schema.org",

            "@graph"=>[

                [

                    "@type"=>"Organization",

                    "@id"=>home_url().'#organization',

                    "name"=>"گیفت مکث",

                    "url"=>home_url('/'),

                    "logo"=>home_url('/logo.png')

                ],

                [

                    "@type"=>"WebSite",

                    "@id"=>home_url().'#website',

                    "url"=>home_url('/'),

                    "name"=>"GiftMax",

                    "publisher"=>["@"=>"https://schema.org/Organization"]

                ]

            ]

        ];

        self::print_json($data);

    }

    private static function product_schema(){

        global $product;

        if(!$product) return;

        $brand=self::brand($product);

        if($product->is_type('variable')){

            $variants=[];

            foreach($product->get_children() as $id){

                $v=wc_get_product($id);

                if(!$v) continue;

                $variants[]=[

                    "@type"=>"Product",

                    "name"=>$v->get_name(),

                    "sku"=>$v->get_sku(),

                    "offers"=>[

                        "@type"=>"Offer",

                        "price"=>wc_get_price_to_display($v),

                        "priceCurrency"=>"IRR",

                        "availability"=>$v->is_in_stock()

                        ?"https://schema.org/InStock"

                        :"https://schema.org/OutOfStock"

                    ]

                ];

            }

            $data=[

                "@context"=>"https://schema.org",

                "@type"=>"ProductGroup",

                "@id"=>get_permalink()."#productgroup",

                "name"=>$product->get_name(),

                "description"=>wp_strip_all_tags($product->get_short_description()),

                "image"=>wp_get_attachment_url($product->get_image_id()),

                "brand"=>[

                    "@type"=>"Brand",

                    "name"=>$brand

                ],

                "category"=>self::category($product),

                "hasVariant"=>$variants

            ];

        }else{

            $data=[

                "@context"=>"https://schema.org",

                "@type"=>"Product",

                "@id"=>get_permalink()."#product",

                "name"=>$product->get_name(),

                "description"=>wp_strip_all_tags($product->get_short_description()),

                "image"=>wp_get_attachment_url($product->get_image_id()),

                "sku"=>$product->get_sku(),

                "category"=>self::category($product),

                "brand"=>[

                    "@type"=>"Brand",

                    "name"=>$brand

                ],

                "offers"=>[

                    "@type"=>"Offer",

                    "url"=>get_permalink(),

                    "price"=>wc_get_price_to_display($product),

                    "priceCurrency"=>"IRR",

                    "availability"=>$product->is_in_stock()

                    ?"https://schema.org/InStock"

                    :"https://schema.org/OutOfStock",

                    "itemCondition"=>"https://schema.org/NewCondition",

                    "priceValidUntil"=>date('Y-m-d',strtotime('+30 days')),

                    "seller"=>[

                        "@type"=>"Organization",

                        "name"=>"GiftMax"

                    ]

                ]

            ];

        }

        if($product->get_review_count()>0){

            $data["aggregateRating"]=[

                "@type"=>"AggregateRating",

                "ratingValue"=>$product->get_average_rating(),

                "reviewCount"=>$product->get_review_count()

            ];

        }

        self::print_json($data);

    }

    private static function breadcrumb_schema(){

        global $product;

        $terms=get_the_terms($product->get_id(),'product_cat');

        if(!$terms) return;

        $term=$terms[0];

        $items=[];

        $items[]=[

            "@type"=>"ListItem",

            "position"=>1,

            "name"=>"خانه",

            "item"=>home_url('/')

        ];

        $parents=array_reverse(get_ancestors($term->term_id,'product_cat'));

        $pos=2;

        foreach($parents as $pid){

            $p=get_term($pid);

            $items[]=[

                "@type"=>"ListItem",

                "position"=>$pos++,

                "name"=>$p->name,

                "item"=>get_term_link($p)

            ];

        }

        $items[]=[

            "@type"=>"ListItem",

            "position"=>$pos++,

            "name"=>$term->name,

            "item"=>get_term_link($term)

        ];

        $items[]=[

            "@type"=>"ListItem",

            "position"=>$pos,

            "name"=>$product->get_name(),

            "item"=>get_permalink()

        ];

        self::print_json([

            "@context"=>"https://schema.org",

            "@type"=>"BreadcrumbList",

            "itemListElement"=>$items

        ]);

    }

    private static function collection_schema(){

        $term=get_queried_object();

        self::print_json([

            "@context"=>"https://schema.org",

            "@type"=>"CollectionPage",

            "name"=>$term->name,

            "url"=>get_term_link($term),

            "description"=>"خرید ".$term->name." با تحویل آنی."

        ]);

    }

    private static function brand($product){

        $terms=get_the_terms($product->get_id(),'product_cat');

        if(!$terms) return "GiftMax";

        foreach($terms as $term){

            if(function_exists('giftmax_get_term_english_name')){

                $name=giftmax_get_term_english_name($term);

                if($name) return $name;

            }

            return $term->name;

        }

        return "GiftMax";

    }

    private static function category($product){

        $terms=get_the_terms($product->get_id(),'product_cat');

        return $terms ? $terms[0]->name : "";

    }

    private static function print_json($data){

        echo '<script type="application/ld+json">';

        echo wp_json_encode($data,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);

        echo '</script>';

    }

}

Schema::init();