<?php
namespace Giftmax\modules;
use mysqli;

class Db
{
    private $connection;
    private static $instance;

    public static function getLnstance($option = null)
    {
        if (self::$instance === null) {
            self::$instance = new self($option);
        }
        return self::$instance;
    }

    private function __construct($option = null)
    {
        if ($option != null) {
            $host = $option['host'];
            $user = $option['user'];
            $pass = $option['pass'];
            $name = $option['name'];
        } else {
            include_once ABSPATH . '/wp-config.php';
            $host = DB_HOST;
            $user = DB_USER;
            $pass = DB_PASSWORD;
            $name = DB_NAME;
        }

        $this->connection = new mysqli($host, $user, $pass, $name);
        if ($this->connection->connect_error) {
            error_log("DB Connection failed: " . $this->connection->connect_error);
            die("خطا در اتصال به پایگاه داده.");
        }

        $this->connection->set_charset("utf8mb4");
    }

    private function safeQuery(&$sql, $data){
        foreach ($data as $key => $value) {

            if ($value === null) {
                $sql = str_replace(":$key", "NULL", $sql);
                continue;
            }

            $value = $this->connection->real_escape_string($value);
            $value = "'$value'";
            $sql = str_replace(":$key", $value, $sql);
        }

        return $this->connection->query($sql);
    }

    public function first($sql, $data = array()){
        $records = $this->query($sql, $data);
        if ($records == null){
            return null;
        }

        return $records[0];
    }
    private function logDatabaseError($finalSql, $data, $errorMessage, $errorCode, $file, $line){
        global $wpdb;
        $this->insert("INSERT INTO `{$wpdb->prefix}db_errors` (`id`, `error_message`, `error_code`, `query_final`, `bindings`, `file`, `line`, `created_at`) VALUES (NULL, :error_message, :error_code, :query_final, :bindings, :file, :line, :created_at)",
            [
                'error_message'  => $errorMessage,
                'error_code'     => $errorCode,
                'query_final'    => $finalSql,
                'bindings'       => wp_json_encode(
                    $data,
                    JSON_UNESCAPED_UNICODE
                ),
                'file'           => $file,
                'line'           => $line,
                'created_at'     => current_time('mysql'),
            ]
        );
    }
    public function modify($sql, $data = array()){
        $result = $this->safeQuery($sql, $data);
        if(!$result){
            $trace = debug_backtrace(
                DEBUG_BACKTRACE_IGNORE_ARGS,
                10
            );

            $file = null;
            $line = null;

            foreach ($trace as $item) {

                if (
                    isset($item['file'], $item['line']) &&
                    !str_contains(
                        $item['file'],
                        DIRECTORY_SEPARATOR . 'Db.php'
                    )
                ) {
                    $file = $item['file'];
                    $line = $item['line'];
                    break;
                }
            }
            $this->logDatabaseError(
                $sql,
                $data,
                $this->connection->error,
                $this->connection->errno,
                $file,
                $line
            );
            die(json_encode(['status'=>false,'message'=>'اتصال برقرار نشد']));
        }
        return $result;
    }

    public function insert($sql, $data = array()){
        $result = $this->safeQuery($sql, $data);
        if(!$result){
            $trace = debug_backtrace(
                DEBUG_BACKTRACE_IGNORE_ARGS,
                10
            );

            $file = null;
            $line = null;

            foreach ($trace as $item) {

                if (
                    isset($item['file'], $item['line']) &&
                    !str_contains(
                        $item['file'],
                        DIRECTORY_SEPARATOR . 'Db.php'
                    )
                ) {
                    $file = $item['file'];
                    $line = $item['line'];
                    break;
                }
            }
            $this->logDatabaseError(
                $sql,
                $data,
                $this->connection->error,
                $this->connection->errno,
                $file,
                $line
            );
            die(json_encode(['status'=>false,'message'=>'اتصال برقرار نشد']));
        }
        return $result;
    }
    public function query($sql, $data = array()){
        $result = $this->safeQuery($sql, $data);
        if(!$result){
            $trace = debug_backtrace(
                DEBUG_BACKTRACE_IGNORE_ARGS,
                10
            );

            $file = null;
            $line = null;

            foreach ($trace as $item) {

                if (
                    isset($item['file'], $item['line']) &&
                    !str_contains(
                        $item['file'],
                        DIRECTORY_SEPARATOR . 'Db.php'
                    )
                ) {
                    $file = $item['file'];
                    $line = $item['line'];
                    break;
                }
            }
            $this->logDatabaseError(
                $sql,
                $data,
                $this->connection->error,
                $this->connection->errno,
                $file,
                $line
            );
            die(json_encode(['status'=>false,'message'=>'اتصال برقرار نشد']));
        }

        if (is_bool($result)) {
            return null;
        }

        $records = array();
        if ($result->num_rows == 0) {
            return null;
        }
        while($row = $result->fetch_assoc()) {
            $records[] = $row;
        }
        return $records;
    }

    public function connection(){
        return $this->connection;
    }
    public function lastInsertId() {
        return $this->connection->insert_id;
    }
    public function close(){
        return $this->connection->close();
    }

}