<?php
namespace Giftmax\model;

use Giftmax\modules\Db;

class ProductModel{
    private static $db;

    private static function db()
    {
        if (!self::$db) self::$db = Db::getLnstance();
        return self::$db;
    }
    public static function available($product_id)
    {
        global $wpdb;
        return self::db()->query("SELECT COUNT(*) AS total FROM {$wpdb->prefix}product_licences WHERE product_id = :product_id AND licence_status = 'available'", array('product_id' => $product_id));
    }
    public static function insertDocuments($user_id,$type_media,$img)
    {
        global $wpdb;
        self::db()->insert("INSERT INTO `{$wpdb->prefix}documents` (`id`, `user_id`, `doc_type`, `document`, `accepted`) VALUES (NULL, :user_id, :doc_type, :document, :accepted)", array(
            'user_id' => $user_id,
            'doc_type' => $type_media,
            'document' => $img,
            'accepted' => 0
        ));
    }
}