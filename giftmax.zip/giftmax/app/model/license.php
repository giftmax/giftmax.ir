<?php
namespace Giftmax\model;

use Giftmax\modules\Db;

class LicenseModel{
    private static $db;

    private static function db()
    {
        if (!self::$db) self::$db = Db::getLnstance();
        return self::$db;
    }
    public static function availableLicenses($product_id)
    {
        global $wpdb;
        return self::db()->query("SELECT licence_id FROM {$wpdb->prefix}product_licences WHERE product_id = :product_id AND licence_status='available' ORDER BY sort_order ASC", array('product_id' => $product_id));
    }
    public static function assignedSet($orderId,$licenceId)
    {
        global $wpdb;
        self::db()->modify(" UPDATE {$wpdb->prefix}product_licences SET licence_status='assigned', assigned_at=:assigned_at, order_id=:order_id WHERE licence_id=:licence_id ",[
            'assigned_at'=>current_time('mysql'),
            'order_id'=>$orderId,
            'licence_id'=>$licenceId
        ]);
    }
}