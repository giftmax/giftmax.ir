<?php
namespace Giftmax\model;

use Giftmax\modules\Db;

class TicketModel{
    private static $db;

    private static function db()
    {
        if (!self::$db) self::$db = Db::getLnstance();
        return self::$db;
    }
    public static function admin($startIndex)
    {
        global $wpdb;
        return self::db()->query("SELECT * FROM  {$wpdb->prefix}ticket WHERE rep_Id IS NULL ORDER BY `ticketId` DESC LIMIT $startIndex, 10");
    }
    public static function pageCount($user_id = null)
    {
        global $wpdb;
        if (is_null($user_id)) {
            return self::db()->query("SELECT COUNT(*) AS total FROM  {$wpdb->prefix}ticket WHERE rep_Id IS NULL");
        }else{
            return self::db()->query("SELECT COUNT(*) AS total FROM  {$wpdb->prefix}ticket WHERE userId=:userId AND rep_Id IS NULL",['userId'=>$user_id]);
        }
    }
    public static function user($user_id,$startIndex)
    {
        global $wpdb;
        return self::db()->query("SELECT * FROM  {$wpdb->prefix}ticket WHERE userId=:userId AND rep_Id IS NULL ORDER BY `ticketId` DESC LIMIT $startIndex, 10",['userId'=>$user_id]);
    }
    public static function category($id)
    {
        global $wpdb;
        return self::db()->query("SELECT * FROM `{$wpdb->prefix}ticketing_category` WHERE `categoryId`=:id",[ 'id' => $id]);
    }
    public static function time($ticketId)
    {
        global $wpdb;
        return self::db()->query("SELECT t1.*, t2.* FROM {$wpdb->prefix}ticket t1 LEFT JOIN {$wpdb->prefix}ticket t2 ON t1.ticketId = t2.rep_Id WHERE t1.ticketId = :ticketId ORDER BY t1.time DESC LIMIT 1",[ 'ticketId' => $ticketId]);
    }
    public static function keyword($keyword)
    {
        global $wpdb;
        return self::db()->query("SELECT * FROM  `{$wpdb->prefix}ticketing_category` WHERE `name` LIKE :keyword", array(
            'keyword' => '%' .$keyword . '%',
        ));
    }
    public static function mainCategory()
    {
        global $wpdb;
        return self::db()->query("SELECT * FROM  `{$wpdb->prefix}ticketing_category` WHERE `main_category`=1");
    }
    public static function subset($subset)
    {
        global $wpdb;
        return self::db()->query("SELECT * FROM  `{$wpdb->prefix}ticketing_category` WHERE `subset`=:subset", array(
            'subset' => $subset,
        ));
    }
    public static function allCategory()
    {
        global $wpdb;
        return self::db()->query("SELECT * FROM `{$wpdb->prefix}ticketing_category`");
    }
    public static function insert($categoryId,$userId,$title,$description,$images_data,$condition)
    {
        global $wpdb;
        self::db()->insert("INSERT INTO `{$wpdb->prefix}ticket` (`ticketId`, `rep_Id`, `categoryId`, `userId`, `Issue`, `requestText`, `attachment`, `condition`, `time`) VALUES (NULL, NULL,:categoryId,:userId,:Issue,:requestText,:attachment,:condition,:tim)", array(
            'categoryId' => $categoryId,
            'userId' => $userId,
            'Issue' => $title,
            'requestText' => $description,
            'attachment'=> $images_data,
            'condition'=> $condition,
            'tim'=>  current_time('mysql', true)
        ));
    }
    public static function insertRep($repId,$userId,$description,$images_data)
    {
        global $wpdb;
        self::db()->insert('INSERT INTO ' . $wpdb->prefix . 'ticket (`ticketId`, `rep_Id`, `categoryId`, `userId`, `Issue`, `requestText`, `attachment`, `condition`, `time`) VALUES (NULL, :rep_Id, NULL, :userId, NULL, :requestText, :attachment, NULL, :tim)', array(
            'rep_Id' => $repId ,
            'userId' =>$userId,
            'requestText' => $description,
            'attachment'=> $images_data,
            'tim'=>  current_time('mysql', true)
        ));
    }
    public static function setCondition($id,$select)
    {
        global $wpdb;
        self::db()->modify("UPDATE `{$wpdb->prefix}ticket` SET `condition` = :select WHERE `ticketId` = :id", array(
            'select' => $select,
            'id' => $id,
        ));
    }
    public static function getTicket($id)
    {
        global $wpdb;
        return self::db()->first("SELECT userId FROM `{$wpdb->prefix}ticket` WHERE `ticketId` = :id AND rep_Id IS NULL", array('id'=>$id));
    }
}