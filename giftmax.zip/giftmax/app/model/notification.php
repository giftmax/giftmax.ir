<?php
namespace Giftmax\model;

use Giftmax\modules\Db;

class NotificationModel{
    private static $db;

    private static function db()
    {
        if (!self::$db) self::$db = Db::getLnstance();
        return self::$db;
    }
    public static function queryUser($id,$user_id)
    {
        global $wpdb;
        return self::db()->first("SELECT `Id`,`userId`,body,title FROM `{$wpdb->prefix}notifications` WHERE `Id`=:Id AND `is_active`=1 AND (`userId` IS NULL OR `userId`=0 OR `userId`=:user_id)", array(
            'Id' => $id,
            'user_id' => $user_id,
        ));
    }
    public static function setRead($id,$user_id)
    {
        global $wpdb;
        self::db()->insert("INSERT INTO `{$wpdb->prefix}notification_reads` (`notification_id`,`user_id`,`seen_at`) VALUES (:notification_id,:user_id,NOW()) ON DUPLICATE KEY UPDATE `seen_at` = VALUES(`seen_at`)", array(
            'notification_id' => $id,
            'user_id' => $user_id,
        ));
        self::$db->modify("UPDATE `{$wpdb->prefix}notifications` SET `status`='read' WHERE `Id`=:Id AND `userId`=:user_id", array(
            'Id' => $id,
            'user_id' => $user_id,
        ));
    }
    public static function getNotification($startIndex,$userId)
    {
        global $wpdb;
        return self::db()->query("SELECT n.*,r.* FROM `{$wpdb->prefix}notifications` n LEFT JOIN `{$wpdb->prefix}notification_reads` r ON r.`notification_id` = n.`Id` AND r.`user_id` = :user_id WHERE n.`is_active`=1 AND (n.`userId` IS NULL OR n.`userId`=0 OR n.`userId`=:user_id) ORDER BY n.`Id` DESC LIMIT $startIndex, 10", array('user_id' => $userId));

    }

    public static function getTotalNotification($userId)
    {
        global $wpdb;
        return self::db()->query("SELECT COUNT(*) AS total FROM `{$wpdb->prefix}notifications` n LEFT JOIN `{$wpdb->prefix}notification_reads` r ON r.`notification_id` = n.`Id` AND r.`user_id` = :user_id WHERE n.`is_active`=1 AND (n.`userId` IS NULL OR n.`userId`=0 OR n.`userId`=:user_id)", array('user_id' => $userId))[0]['total'];

    }
    public static function addNotification($userId,$title,$body)
    {
        global $wpdb;
        self::db()->insert("INSERT INTO `{$wpdb->prefix}notifications` (`userId`,`body`,`title`,`status`,`is_active`,`created_at`) VALUES (:user_id,:body,:title,'show',1,:created_at)", array(
            'user_id' => $userId,
            'title' => $title,
            'body' => $body,
            'created_at' => date('Y-m-d H:i:s')
        ));
        return self::db()->lastInsertId();
    }
}