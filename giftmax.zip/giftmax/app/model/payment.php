<?php
namespace Giftmax\model;

use Giftmax\modules\Db;

class paymentModel{
    private static $db;

    private static function db()
    {
        if (!self::$db) self::$db = Db::getLnstance();
        return self::$db;
    }

}