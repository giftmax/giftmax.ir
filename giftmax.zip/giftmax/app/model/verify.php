<?php
namespace Giftmax\model;

use Giftmax\modules\Db;

class VerifyModel{
    private static $db;

    private static function db()
    {
        if (!self::$db) self::$db = Db::getLnstance();
        return self::$db;
    }
    public static function userDocuments($user_id)
    {
        global $wpdb;
        return self::db()->query("SELECT * FROM `{$wpdb->prefix}documents` WHERE `user_id` = :user_id AND (`accepted`=0 OR `accepted`=2)", array('user_id' => $user_id));
    }
    public static function insertDocuments($user_id,$type_media,$img)
    {
        global $wpdb;
        self::db()->insert("INSERT INTO `{$wpdb->prefix}documents` (`id`, `user_id`, `doc_type`, `document`, `accepted`) VALUES (NULL, :user_id, :doc_type, :document, :accepted)", array(
            'user_id' => $user_id,
            'doc_type' => $type_media,
            'document' => $img,
            'accepted' => 0
        ));
    }
    public static function DeleteCardBank($id)
    {
        global $wpdb;
        self::db()->modify("DELETE FROM `{$wpdb->prefix}user_bank_cards` WHERE `id` = :id", array("id" => $id));

    }
    public static function insertCardBank($userId,$cartNumber,$firstName,$lastName,$phoneNumber,$birthDate,$nationalCode,$hash)
    {
        global $wpdb;
        self::db()->insert("INSERT INTO `{$wpdb->prefix}user_bank_cards` (`user_id`,`hash`, `card_number_enc`, `card_last4`, `phone`, `birth_date`, `national_code`,`first_name` ,`last_name`, `is_active`, `ip`, `created_at`) VALUES (:user_id, :hash,:card_number, :card_last4, :phone, :birth_date,:national_code,:first_name,:last_name,0,:ip,:created_at)", array(
            'user_id' => $userId,
            'card_number' => encrypt_data($cartNumber),
            'first_name' => $firstName,
            'last_name' => $lastName,
            'card_last4' => substr($cartNumber, -4),
            'phone' => encrypt_data($phoneNumber),
            'birth_date' => encrypt_data($birthDate),
            'national_code' => encrypt_data($nationalCode),
            'ip' => encrypt_data(giftmax_get_user_ip()),
            'created_at' => date('Y-m-d H:i:s'),
            'hash' => $hash
        ));

    }
}