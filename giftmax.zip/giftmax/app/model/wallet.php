<?php
namespace Giftmax\model;

use Giftmax\modules\Db;

class WalletModel{
    private static $db;

    private static function db()
    {
        if (!self::$db) self::$db = Db::getLnstance();
        return self::$db;
    }
    public static function getWallet($user_id)
    {
        global $wpdb;
        return self::db()->first("SELECT * FROM `{$wpdb->prefix}wallet` WHERE `user_id` = :user_id", array(
            'user_id' => $user_id,
        ));
    }
    public static function getPoints($user_id)
    {
        global $wpdb;
        return self::db()->first("SELECT * FROM `{$wpdb->prefix}user_points` WHERE `user_id` = :user_id", array(
            'user_id' => $user_id,
        ));
    }
    public static function insertTransactions($userId,$methodId,$amount,$description,$method,$type)
    {
        global $wpdb;
        self::db()->insert("INSERT INTO `{$wpdb->prefix}wallet_transactions` (`id`, `user_id`,`method`, `method_id`, `amount`, `type`, `description`, `created_at`) VALUES (NULL, :user_id,:method, :method_id, :amount, :type, :description, :created_at)", array(
            'user_id' => $userId,
                'method_id' => $methodId,
                'amount' => $amount,
                'description' => $description,
                'method' => $method,
                'type' => $type,
                'created_at' => date('Y-m-d H:i:s')
            )
        );
    }
    public static function insertWallet($userId){
        global $wpdb;
        return self::db()->insert("INSERT INTO `{$wpdb->prefix}wallet` (`id`, `user_id`, `balance`) VALUES (NULL, :user_id, '0')", array('user_id' => $userId));
    }
    public static function updateBalance($id,$balance){
        global $wpdb;
        self::db()->modify("UPDATE `{$wpdb->prefix}wallet` SET `balance` = :balance WHERE `id` = :id", array(
            'id' => $id,
            'balance' => $balance
        ));
    }
    public static function updatePoint($id,$points){
        global $wpdb;
        self::db()->modify("UPDATE `{$wpdb->prefix}user_points` SET `points` = :points WHERE `id` =:Id", array(
            'Id' => $id,
            'points' => $points
        ));
    }
    public static function updateWalletPayments($time,$status,$hash){
        global $wpdb;
        self::db()->modify("UPDATE `{$wpdb->prefix}wallet_payments` SET `status` = :status,`updated_at`=:updated_at WHERE `hash` = :hash", array(
            'updated_at' => $time,
            'status' => $status,
            'hash' => $hash,
        ));
    }
    public static function getWalletPayments($hash){
        global $wpdb;
        return self::db()->first("SELECT * FROM `{$wpdb->prefix}wallet_payments` WHERE `hash` = :hash", array(
            'hash' => $hash,
        ));
    }
    public static function getWalletUser($userId){
        global $wpdb;
        return self::db()->first("SELECT * FROM `{$wpdb->prefix}wallet` WHERE `user_id` = :user_id", array(
            'user_id' => $userId,
        ));
    }
}