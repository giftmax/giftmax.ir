<?php
namespace Giftmax\model;

use Giftmax\modules\Db;

class SiteModel{
    private static $db;

    private static function db()
    {
        if (!self::$db) self::$db = Db::getLnstance();
        return self::$db;
    }
    public static function querySmsCampaigns()
    {
        global $wpdb;
        return self::db()->query("SELECT * FROM `{$wpdb->prefix}sms_campaigns` WHERE  DATE_FORMAT(send_at, '%Y-%m-%d %H:%i') = DATE_FORMAT(:time, '%Y-%m-%d %H:%i')", array('time' => date('Y-m-d H:i:s')));
    }
    public static function campaignRecipients($campaign_id)
    {
        global $wpdb;
        return self::db()->query("SELECT * FROM `{$wpdb->prefix}sms_campaign_recipients` WHERE `campaign_id`=:campaign_id", array(
            'campaign_id' => $campaign_id
        ));
    }
    public static function recipientsSetFailed($error_message,$id)
    {
        global $wpdb;
        self::db()->modify("UPDATE `{$wpdb->prefix}sms_campaign_recipients` SET `sent_at` = :sent_at,`status`='failed',`error_message`=:error_message WHERE `id` = :id", array(
            'sent_at' => date('Y-m-d H:i:s'),
            'error_message' => $error_message,
            'id' => $id
        ));
    }
    public static function recipientsSetSent($id)
    {
        global $wpdb;
        return self::db()->modify("UPDATE `{$wpdb->prefix}sms_campaign_recipients` SET `sent_at` = :sent_at,`status`='sent' WHERE `id` = :id", array(
            'sent_at' => date('Y-m-d H:i:s'),
            'id' => $id
        ));
    }
    public static function dataCampaigns($id,$sent_count,$failed_count)
    {
        global $wpdb;
        self::db()->modify("UPDATE `{$wpdb->prefix}sms_campaigns` SET `sent_count` = :sent_count,`failed_count`=:failed_count WHERE `id` = :id", array(
            'sent_count' => $sent_count,
            'failed_count' => $failed_count,
            'id' => $id
        ));
    }
    public static function table($name,$option = null , $method = null,$optionTwo = null , $methodTwo = null,$query = false){
        global $wpdb;
        if (is_null($option)) {
            $records = self::db()->first("SELECT * FROM `{$wpdb->prefix}$name`");
        }elseif(is_null($optionTwo)){
            $records = self::db()->first("SELECT * FROM `{$wpdb->prefix}$name` WHERE $option=:option",array('option'=>$method));
        }elseif (!$query){
            $records = self::db()->first("SELECT * FROM `{$wpdb->prefix}$name` WHERE $option=:option AND `$optionTwo` =:optiot ",array('option'=>$method,'optiot'=>$methodTwo));
        }elseif ($query){
            $records = self::db()->query("SELECT * FROM `{$wpdb->prefix}$name` WHERE $option=:option AND `$optionTwo` =:optiot ",array('option'=>$method,'optiot'=>$methodTwo));
        }
        return $records;
    }
    public static function setting($key) :bool{
        global $wpdb;
        $records = self::db()->first("SELECT meta_value FROM `{$wpdb->prefix}setting` WHERE `meta_key`=:key",array('key'=>$key));
        return !is_null($records) ? $records['meta_value'] : 0;
    }
    public static function insertContact($name,$email,$subject,$text){
        global $wpdb;
        return self::db()->insert("INSERT INTO `{$wpdb->prefix}contact` (`id`, `name`, `email`, `subject`, `message`, `ip_address`, `user_agent`, `status`, `created_at`) VALUES (NULL, :name,:email,:subject,:message,:ip_address,:user_agent ,'0', :created_at)", array(
            'name' => $name,
            'email' => $email,
            'subject' => $subject,
            'message' => $text,
            'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? '',
            'ip_address' => giftmax_get_user_ip(),
            'created_at' => date('Y-m-d H:i:s')
        ));
    }
}