<?php
namespace Giftmax\Templates;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

abstract class BaseTemplate {

    protected function include_view( string $relative_path, array $data = [] ): void {
        $path = GIFTMAX_PATH . '/inc/templates/' . $relative_path . '.php';

        if ( file_exists( $path ) ) {
            extract( $data );
            include $path;
        }
    }
}
