<?php

namespace Giftmax\Templates;

if (!defined('ABSPATH')) {
    exit;
}

class AdminProductTemplate extends BaseTemplate
{

    public function render_product_settings(\WP_Post $post): void
    {

        $settings = get_post_meta($post->ID, 'giftmax_box_setting', true);
        $checkmarks = get_post_meta($post->ID, '_feature_checkmarks', true);

        $this->include_view(
            'product/setting-admin/product-setting',
            [
                'post' => $post,
                'settings' => $settings,
                'checkmarks' => $checkmarks,
            ]
        );
    }

    public function render_fast_setting(\WP_Post $post): void
    {
        $this->include_view(
            'product/setting-admin/setting_small',
            [
                'post' => $post,
            ]
        );
    }
    public function render_fast_setting_coupon(\WP_Post $post): void
    {
        $this->include_view(
            'product/setting-admin/setting_small_coupon',
            [
                'post' => $post,
            ]
        );
    }
    public function render_add_licences($order): void
    {
        $this->include_view('product/setting-admin/add_licences',
            [
                'order' => $order,
            ]
        );
    }
}
