<?php
namespace Giftmax;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Autoloader {
    protected static string $base_path;
    protected static string $base_namespace;

    public static function run( string $base_path, string $base_namespace = 'Giftmax' ): void {
        self::$base_path      = rtrim( $base_path, '/\\' );
        self::$base_namespace = trim( $base_namespace, '\\' );

        spl_autoload_register( [ __CLASS__, 'autoload' ] );
    }

    public static function autoload( string $class ): void {
        if ( strpos( $class, self::$base_namespace . '\\' ) !== 0 ) {
            return;
        }
        if (strpos($class, "Model") !== false) {
            $class = str_replace("Model", "", $class);
            $class = strtolower($class);
            $relative = substr( $class, strlen( self::$base_namespace . '\\' ) );
            $relative_path = str_replace( '\\', DIRECTORY_SEPARATOR, $relative );
            $file = self::$base_path . DIRECTORY_SEPARATOR . $relative_path . '.php';
            require_once $file;
            return;
        }
        $relative = substr( $class, strlen( self::$base_namespace . '\\' ) );
        $relative_path = str_replace( '\\', DIRECTORY_SEPARATOR, $relative );

        $file = self::$base_path . DIRECTORY_SEPARATOR . $relative_path . '.php';
        if ( is_readable( $file ) ) {
            require $file;
        }
    }
}
