<?php
namespace Giftmax;

use Giftmax\modules\addShortcode;
use Giftmax\modules\Payment;
use Giftmax\setup\Admin;
use Giftmax\setup\Assets;
use Giftmax\setup\Db;
use Giftmax\setup\Support;
use Giftmax\webservice\method\Profile;
use Giftmax\webservice\method\Site;
use Giftmax\webservice\method\User;
use Giftmax\webservice\method\VerifyUser;
use Giftmax\webservice\method\Woocommerce;
use Giftmax\woo\ProductHooks;
use Giftmax\woo\WpOrders;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Theme {

    private static ?Theme $instance = null;

    public static function get_instance(): Theme {
        if ( self::$instance === null ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        new Support();
        new Assets();
        new Admin();
        new \Giftmax\webservice\method\Admin();
        new \Giftmax\webservice\method\Payment();
        new Profile();
        new Site();
        new User();
        new VerifyUser();
        new Woocommerce();
        new addShortcode();
        new Db();
        if ( class_exists( 'WooCommerce' ) ) {
           new ProductHooks();
           new Payment();
           new WpOrders();
        }
    }
}
