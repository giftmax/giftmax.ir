<?php
namespace Giftmax;

use Giftmax\Api\versen;
use Giftmax\Modules\addShortcode;
use Giftmax\Modules\Payment;
use Giftmax\Modules\View;
use Giftmax\Setup\Admin;
use Giftmax\Setup\Db;
use Giftmax\Setup\Support;
use Giftmax\Setup\Assets;
use Giftmax\Woo\ProductHooks;
use Giftmax\Woo\WpOrders;
use SimplePie\Parse\Date;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Theme {

    private static ?Theme $instance = null;

    public static function get_instance(): Theme {
        if ( self::$instance === null ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {

        new Support();
        new Assets();
        new Admin();
       // new Ajax();
        new versen\v1();
        new versen\v2();
        new versen\v3();
        new addShortcode();
        new Db();
        if ( class_exists( 'WooCommerce' ) ) {
           new ProductHooks();
           new Payment();
           new WpOrders();
        }
    }
}
