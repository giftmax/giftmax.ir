<?php
namespace Giftmax\Setup;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Assets {
    public function __construct() {
        add_action( 'wp_enqueue_scripts', [ $this, 'enqueue_front_assets' ] );
        add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_admin_assets' ] );
    }

    public function enqueue_front_assets(): void {
        $version = wp_get_theme()->get('Version');
        if ( is_page('ticket') ) {
            wp_enqueue_style('giftmax-ticket', get_template_directory_uri() . '/assets/css/ticket.min.css', array(), $version, 'all');

            wp_enqueue_script('giftmax-ticket', get_template_directory_uri() . '/assets/js/ticket.5r9fef68rh.min.js', array('jquery'), $version, true);
        }
        wp_enqueue_style('giftmax-globals', get_template_directory_uri() . '/assets/css/globals.min.css', array(), $version, 'all');
        wp_enqueue_style('tooltipstercss', get_template_directory_uri() . '/assets/css/tooltipster.min.css', array(), $version, 'all');
        wp_enqueue_style('giftmax-style', get_stylesheet_uri(), array(), null, 'all');
        wp_enqueue_style('swiper-bundle.min', get_template_directory_uri() . '/assets/css/swiper-bundle.min.css', array(), $version, 'all');

        wp_enqueue_script('jquery');
        if ( is_page('login-register') ) {
            wp_enqueue_style('giftmax-login-css', get_template_directory_uri() . '/assets/css/login.min.css', array(), $version, 'all');
        }
        if ( is_page('notifications') ) {
            wp_enqueue_style('giftmax-notifications', get_template_directory_uri() . '/assets/css/notifications.min.css', array(), $version, 'all');
        }
        if ( is_front_page() || is_home() ) {
            wp_enqueue_style('giftmax-home-css', get_template_directory_uri() . '/assets/css/home.min.css', array(), $version, 'all');
            wp_enqueue_script('bootstrap', get_template_directory_uri() . '/assets/js/bootstrap.min.js', array('jquery'), $version, true);

        }
        if ( is_page('profile') ) {
            wp_enqueue_script('giftmax-profile', get_template_directory_uri() . '/assets/js/profile.min.js', array('jquery'), $version, true);
            wp_enqueue_script('giftmax-sdHd8', get_template_directory_uri() . '/assets/js/sdHd8.min.js', array('jquery'), $version, true);
            wp_enqueue_style('giftmax-sd45d8-css', get_template_directory_uri() . '/assets/css/cart.min.css', array(), $version, 'all');
            wp_enqueue_style('giftmax-sdHd8-css', get_template_directory_uri() . '/assets/css/sdHd8.min.css', array(), $version, 'all');
        }
        if ( is_page('blogs') || is_category() ) {
            wp_enqueue_style('giftmax-baIF8r-css', get_template_directory_uri() . '/assets/css/baIF8r.min.css', array(), $version, 'all');
        }
        if ( class_exists( 'WooCommerce' ) ) {
            if (is_product()) {
                wp_enqueue_script('bootstrap', get_template_directory_uri() . '/assets/js/bootstrap.min.js', array('jquery'), $version, true);
            }
            if ( is_product_category() || is_shop()){
                wp_enqueue_script('bootstrap', get_template_directory_uri() . '/assets/js/bootstrap.min.js', array('jquery'), $version, true);
                wp_enqueue_style('giftmax-archive', get_template_directory_uri() . '/assets/css/archive.min.css', array(), $version, 'all');
            }
            if ( is_product() ||  is_cart()  ) {
                wp_enqueue_style('giftmax-sd45d8-css', get_template_directory_uri() . '/assets/css/cart.min.css', array(), $version, 'all');
                wp_enqueue_script('apexcharts', get_template_directory_uri() . '/assets/js/apexcharts.min.js', array(), $version, true);

            }
        }
        if (is_search()){
            wp_enqueue_style('giftmax-baIF8r-css', get_template_directory_uri() . '/assets/css/baIF8r.min.css', array(), $version, 'all');
             wp_enqueue_script('bootstrap', get_template_directory_uri() . '/assets/js/bootstrap.min.js', array('jquery'), $version, true);
            wp_enqueue_style('giftmax-archive', get_template_directory_uri() . '/assets/css/archive.min.css', array(), $version, 'all');
        }
        if (is_page('incredible-offers')){
            wp_enqueue_script('bootstrap', get_template_directory_uri() . '/assets/js/bootstrap.min.js', array('jquery'), $version, true);
            wp_enqueue_style('giftmax-archive', get_template_directory_uri() . '/assets/css/ioht5s.min.css', array(), $version, 'all');
        }
        if ( is_singular( 'post' )  ) {
            wp_enqueue_style('giftmax-fl8Ueb5-css', get_template_directory_uri() . '/assets/css/fl8Ueb5.min.css', array(), $version, 'all');
        }
        wp_enqueue_style('giftmax-select2-css', get_template_directory_uri() . '/assets/css/select2.min.css', array(), $version, 'all');


        wp_enqueue_script('giftmax-select2', get_template_directory_uri() . '/assets/js/select2.min.js', array('jquery'), $version, true);
        wp_enqueue_script('router', get_template_directory_uri() . '/assets/js/router.min.js', array(), false, true);

        wp_enqueue_script('giftmax-swiper', get_template_directory_uri() . '/assets/js/swiper-bundle.min.js', array('jquery'), $version, true);
        wp_enqueue_script('giftmax-lottie', get_template_directory_uri() . '/assets/js/lottie.min.js', array('jquery'), $version, true);
        wp_enqueue_script('giftmax-HsJE74', get_template_directory_uri() . '/assets/js/HsJE74.min.js', array('jquery'), $version, true);


        wp_enqueue_script('tooltipsterjs', get_template_directory_uri() . '/assets/js/jquery.tooltipster.min.js', array('jquery'), $version, true);

        wp_enqueue_script('giftmax-main-js', get_template_directory_uri() . '/assets/js/main.min.js', array('jquery'), $version, true);
        wp_enqueue_script('giftmax-nprogress-js', get_template_directory_uri() . '/assets/js/nprogress.min.js', array('jquery'), $version, true);
        wp_localize_script('jquery', 'wpApiSettingsGiftMax', array(
            'root' => esc_url_raw(rest_url()),
            'home' => home_url(),
            'logout' => wp_logout_url(home_url()),
            'directory' => get_template_directory_uri(),
            'nonce' => wp_create_nonce('wp_rest')
        ));
    }

    public function enqueue_admin_assets($hook): void {
        global $post;
        if ($hook === 'post.php' || $hook === 'post-new.php') {
            if (isset($post->post_type) && $post->post_type === 'product') {

                wp_enqueue_style(
                    'giftmax-product-metabox-style',
                    get_template_directory_uri() . '/assets/css/product-rtl.min.css',
                    [],
                    '1.0'
                );
                wp_enqueue_media();

                wp_enqueue_style('giftmax-select2-css', get_template_directory_uri() . '/assets/css/select2.min.css', array(), null, 'all');
                wp_enqueue_script('giftmax-select2', get_template_directory_uri() . '/assets/js/select2.min.js', array('jquery'), null, true);
                wp_enqueue_script(
                    'giftmax-media-script',
                    get_template_directory_uri() . '/assets/js/product-rtl.df41f.min.js',
                    ['jquery'],
                    '1.0',
                    true
                );
                wp_localize_script('jquery', 'wpApiSettingsGiftMax', array(
                    'root' => esc_url_raw(rest_url()),
                    'home' => home_url(),
                    'ajaxUrl' => home_url('wp-admin/admin-ajax.php'),
                    'nonce' => wp_create_nonce('wp_rest')
                ));
            }
            if (isset($post->post_type) && $post->post_type === 'shop_coupon') {

                wp_enqueue_style(
                    'giftmax-dfDy4-style',
                    get_template_directory_uri() . '/assets/css/dfDy4.min.css',
                    [],
                    '1.0'
                );
                wp_enqueue_style(
                    'giftmax-stHfgD8-style',
                    get_template_directory_uri() . '/assets/css/stHfgD8.min.css',
                    [],
                    '1.0'
                );
                wp_enqueue_script(
                    'giftmax-stHfgD8-script',
                    get_template_directory_uri() . '/assets/js/stHf1c.min.js',
                    ['jquery'],
                    '1.0',
                    true
                );
                wp_localize_script('jquery', 'wpApiSettingsGiftMax', array(
                    'root' => esc_url_raw(rest_url()),
                    'home' => home_url(),
                    'nonce' => wp_create_nonce('wp_rest')
                ));
            }
        }
        if ( $hook == 'toplevel_page_theme-settings' ) {
            wp_enqueue_style(
                'giftmax-stHfgD8-style',
                get_template_directory_uri() . '/assets/css/stHfgD8.min.css',
                [],
                '1.0'
            );
            wp_enqueue_style(
                'giftmax-sdHd8-style',
                get_template_directory_uri() . '/assets/css/sdHd8.min.css',
                [],
                '1.0'
            );
            wp_enqueue_style(
                'giftmax-skins-style',
                get_template_directory_uri() . '/assets/tinymce/skins/ui/oxide/skin.css',
                [],
                '1.0'
            );
            wp_enqueue_style(
                'giftmax-dfDy4-style',
                get_template_directory_uri() . '/assets/css/dfDy4.min.css',
                [],
                '1.0'
            );
            wp_enqueue_media();

            wp_enqueue_script(
                'giftmax-stHfgD8-script',
                get_template_directory_uri() . '/assets/js/stHfgD8.min.js',
                ['jquery'],
                '1.0',
                true
            );
            wp_enqueue_script(
                'giftmax-tinymce-script',
                get_template_directory_uri() . '/assets/tinymce/tinymce.min.js',
                ['jquery'],
                '1.0',
                true
            );
            wp_enqueue_script(
                'giftmax-tinymce-main-script',
                get_template_directory_uri() . '/assets/tinymce/jquery.tinymce.min.js',
                ['jquery'],
                '1.0',
                true
            );
            wp_enqueue_script(
                'giftmax-tinymce-plugin-script',
                get_template_directory_uri() . '/assets/tinymce/plugins/save/plugin.min.js',
                ['jquery'],
                '1.0',
                true
            );
            wp_localize_script('jquery', 'wpApiSettingsGiftMax', array(
                'root' => esc_url_raw(rest_url()),
                'home' => home_url(),
                'nonce' => wp_create_nonce('wp_rest')
            ));
        }
        if ( $hook == 'toplevel_page_theme-verify' ) {
            wp_enqueue_style(
                'giftmax-dfDy4-style',
                get_template_directory_uri() . '/assets/css/dfDy4.min.css',
                [],
                '1.0'
            );
            wp_enqueue_media();

            wp_enqueue_script(
                'giftmax-dfDy4-script',
                get_template_directory_uri() . '/assets/js/dfDy4.min.js',
                ['jquery'],
                '1.0',
                true
            );
            wp_localize_script('jquery', 'wpApiSettingsGiftMax', array(
                'root' => esc_url_raw(rest_url()),
                'home' => home_url(),
                'nonce' => wp_create_nonce('wp_rest')
            ));
        }
    }
}
