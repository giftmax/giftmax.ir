<?php
namespace Giftmax\Setup;

use Giftmax\Modules\Db;
use Giftmax\Modules\UserModel;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Support {

    public function __construct() {
        add_action( 'after_setup_theme', [ $this, 'mytheme_setup' ] );
        add_action( 'template_redirect', [ $this, 'track_unique_post_view' ] );

    }

    public function mytheme_setup() {
        add_theme_support( 'title-tag' );
        add_theme_support('automatic_feed_link');
        add_theme_support( 'post-thumbnails' );
        add_theme_support( 'woocommerce' );
        add_image_size('product_discount', 408, 256,true);
        register_nav_menus(
            array(
                'header-menu' => "منو توی هدر",
                'quick-access' => "دسترسی سریع منوی",
                'help-support' =>"منوی راهنمایی و پشتیبانی",
                'footer-menu' => "منوی افقی در فوتر"
            )
        );
    }
    public function track_unique_post_view():void {
        if (is_admin() || wp_doing_ajax() || !is_singular('post') || is_preview() || !is_user_logged_in()) {
            return;
        }
        $post_id = (int) get_queried_object_id();
        if ($post_id <= 0) {
            return;
        }

        $visitor_hash = $this->get_visitor_hash();
        if ($visitor_hash === '') {
            return;
        }

        $db = Db::getLnstance();
        global $wpdb;
        $user_id = get_current_user_id();
        $records = UserModel::table('post_views','UserId',$user_id,'PostId',$post_id);
        if (empty($records)) {
            $db->insert(
                "INSERT INTO `{$wpdb->prefix}post_views` (`UserId`,`PostId`) VALUES (:UserId,:PostId)",
                [
                    'PostId' => $post_id,
                    'UserId' => $user_id
                ]
            );
            $views = (int) get_post_meta($post_id, 'views', true);
            update_post_meta($post_id, 'views', $views + 1);
           }else{
            $this->get_visitor_hash();
        }
    }

    private function get_visitor_hash(): string {
        if (is_user_logged_in()) {
            return 'u_' . get_current_user_id();
        }

        $cookie_name = 'giftmax_visitor_id';
        $visitor_id = isset($_COOKIE[$cookie_name]) ? sanitize_text_field(wp_unslash($_COOKIE[$cookie_name])) : '';

        if ($visitor_id === '' || !preg_match('/^[A-Za-z0-9_-]{16,80}$/', $visitor_id)) {
            $visitor_id = str_replace('-', '', wp_generate_uuid4());
            setcookie(
                $cookie_name,
                $visitor_id,
                time() + (100 * YEAR_IN_SECONDS),
                COOKIEPATH ? COOKIEPATH : '/',
                COOKIE_DOMAIN,
                is_ssl(),
                true
            );
            $_COOKIE[$cookie_name] = $visitor_id;
        }

        return 'g_' . $visitor_id;
    }
}
