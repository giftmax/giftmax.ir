<?php
namespace Giftmax\webservice\method;


use Giftmax\model\NotificationModel;
use Giftmax\model\ProductModel;
use Giftmax\model\SiteModel;
use Giftmax\model\UserModel;
use Giftmax\modules\Db;

class Site
{
    public function __construct(){
        add_action( 'rest_api_init',[ $this, 'addApiRoutes' ] );
        add_filter('rest_index', function ($response) {

            // Namespaceهایی که نمی‌خواهیم در REST index دیده شوند
            if (isset($response->data['namespaces'])) {

                $hidden_namespaces = [
                        'api/v1',
                        'api/v2',
                        'api/v3',
                ];

                $response->data['namespaces'] = array_values(
                        array_filter(
                                $response->data['namespaces'],
                                function ($namespace) use ($hidden_namespaces) {
                                    return !in_array($namespace, $hidden_namespaces, true);
                                }
                        )
                );
            }

            // Routeهای اختصاصی را هم از REST index حذف کن
            if (isset($response->data['routes'])) {

                foreach (array_keys($response->data['routes']) as $route) {

                    if (preg_match('#^/api/(v1|v2|v3)(?:/|$)#', $route)) {
                        unset($response->data['routes'][$route]);
                    }
                }
            }

            return $response;
        });
    }
    public function addApiRoutes(){
        register_rest_route( 'api/v1', '/stats', array(
            'methods' => 'POST',
            'callback' => [$this, 'statsApiFunction'],
            'permission_callback' => "__return_true"
        ) );
        register_rest_route( 'api/v1', '/images', array(
            'methods' => 'POST',
            'callback' => [$this, 'imagesApiV1Function'],
            'permission_callback' => function () {
                return is_user_logged_in();
            }
        ) );
        register_rest_route('api/v2', '/image', array(
            'methods' => 'POST',
            'callback' => [$this, 'imageApiFunction'],
            'permission_callback' => function () {
                return is_user_logged_in();
            }
        ));
        register_rest_route('api/v2', '/notifications', array(
            'methods' => 'POST',
            'callback' => [$this, 'notificationsApiFunction'],
            'permission_callback' => function () {
                return is_user_logged_in();
            }
        ));
        register_rest_route('api/v2', '/notif', array(
            'methods' => 'POST',
            'callback' => [$this, 'notifApiFunction'],
            'permission_callback' => function () {
                return is_user_logged_in();
            }
        ));
        register_rest_route('api/v2', '/post', array(
            'methods' => 'POST',
            'callback' => [$this, 'postApiFunction'],
            'permission_callback' => function () {
                return is_user_logged_in();
            }
        ));
        register_rest_route( 'api/v1', '/LoadCategory', array(
            'methods' => 'POST',
            'callback' => [$this, 'loadCategoryApiFunction'],
            'permission_callback' => "__return_true"
        ) );
        register_rest_route( 'api/v1', '/search', array(
                'methods' => 'POST',
                'callback' => [$this, 'searchApiFunction'],
                'permission_callback' => "__return_true"
        ) );
        register_rest_route( 'api/v1', '/alert-notif', array(
                'methods' => 'POST',
                'callback' => [$this, 'alertNotifFunction'],
                'permission_callback' => "__return_true"
        ) );
        register_rest_route( 'api/v1', '/alert', array(
                'methods' => 'POST',
                'callback' => [$this, 'alertApiFunction'],
                'permission_callback' => "__return_true"
        ) );
        register_rest_route( 'api/v1', '/pagination', array(
                'methods' => 'POST',
                'callback' => [$this, 'PaginationApiFunction'],
                'permission_callback' => function () {
                    return is_user_logged_in();
                }
        ));
        register_rest_route( 'api/v1', '/send-sms', array(
                'methods' => 'GET',
                'callback' => [$this, 'sendSmsFunction'],
                'permission_callback' => "__return_true"
        ) );
        register_rest_route( 'api/v1', '/posts', array(
                'methods' => 'POST',
                'callback' => [$this, 'postsApiFunction'],
                'permission_callback' => "__return_true"
        ) );
        register_rest_route( 'api/v1', '/set-price', array(
                'methods' => 'GET',
                'callback' => [$this, 'setPriceFunction'],
                'permission_callback' => "__return_true"
        ) );
    }
    public function statsApiFunction(){
        $records = SiteModel::table("setting","meta_key","currency");
        if ($records && isset($records['meta_value'])) {
            echo $records['meta_value'];
        } else {
            header('Content-Type: application/json; charset=utf-8');
            echo json_encode(['error' => 'داده‌ای یافت نشد'], JSON_UNESCAPED_UNICODE);
        }
    }
    public function imagesApiV1Function(){
        if ( ! isset( $_FILES['file'] ) ) {
            return new \WP_Error( 'no_file', 'No file provided', array( 'status' => 400 ) );
        }
        $uploadDirectory = wp_upload_dir()['path']; // برای استفاده از پوشه آپلود شده وردپرس

        $uploadedImages = array();
        $allowedTypes = [
            // Excel
                'application/vnd.ms-excel' => 'xls',
                'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' => 'xlsx',
            // Video
                'video/mp4'       => 'mp4',
                'video/quicktime' => 'mov',
                'video/x-msvideo' => 'avi',
                'video/mpeg'      => 'mpeg',
                'video/x-m4v'     => 'm4v',
                'video/x-ms-wmv'  => 'wmv',
            // Image
                'image/jpeg' => 'jpg',
                'image/png'  => 'png',
                'image/gif'  => 'gif',
        ];
        foreach ($_FILES['file']['tmp_name'] as $key => $tmp_name) {
            if ($_FILES['file']['size'][$key] >6 * 1024 * 1024){
                return new \WP_Error( 'size_big',"حجم رعایت نشده بود", array( 'status' => 400 ) );
            }
            if (!isset($allowedTypes[$_FILES['file']['type'][$key]])) {
                $response_data = array(
                        'stats' => false,
                        'message' => 'فرمت فایل مجاز نیست. فقط PNG، JPG و JPEG مجاز هستند.',
                );

                echo json_encode($response_data);
                exit();
            }
            $file_name = $_FILES['file']['name'][$key];
            $file_tmp = $_FILES['file']['tmp_name'][$key];
            $new_file_name = $uploadDirectory . basename($file_name);
            $newFile = str_replace(rtrim($_SERVER['DOCUMENT_ROOT'], '/') . '/','',$new_file_name);
            $id = generateHash(4);
            UserModel::addImage($id,$newFile);
            move_uploaded_file($file_tmp, $new_file_name);

            $uploadedImages[] = array(
                'id' => $id,
                'url' => basename($file_name)
            );
        }
        $response_data = array(
            'uploadedImages' => $uploadedImages,
        );
        echo json_encode($response_data);
    }
    private function media_handle($file_id, $post_id, $post_data = array(), $overrides = array('test_form' => false))
    {
        require_once(ABSPATH . 'wp-admin/includes/media.php');
        require_once(ABSPATH . 'wp-admin/includes/file.php');
        require_once(ABSPATH . 'wp-admin/includes/post.php');
        require_once(ABSPATH . 'wp-admin/includes/image.php');
        $time = current_time('mysql');
        $post = get_post($post_id);

        if ($post) {
            if ('page' !== $post->post_type && substr($post->post_date, 0, 4) > 0) {
                $time = $post->post_date;
            }
        }

        $file = wp_handle_upload($_FILES[$file_id], $overrides, $time);

        if (isset($file['error'])) {
            $response_data = array(
                'stats' => false,
                'message' => "خطای آپلود",
            );

            echo json_encode($response_data);
            exit();
        }

        $name = $_FILES[$file_id]['name'];
        $ext = pathinfo($name, PATHINFO_EXTENSION);
        $name = wp_basename($name, ".$ext");

        $url = $file['url'];
        $type = $file['type'];
        $file = $file['file'];
        $title = sanitize_text_field($name);
        $content = '';
        $excerpt = '';

        if (preg_match('#^audio#', $type)) {
            $meta = wp_read_audio_metadata($file);

            if (!empty($meta['title'])) {
                $title = $meta['title'];
            }

            if (!empty($title)) {

                if (!empty($meta['album']) && !empty($meta['artist'])) {
                    $content .= sprintf(__('"%1$s" from %2$s by %3$s.'), $title, $meta['album'], $meta['artist']);
                } elseif (!empty($meta['album'])) {
                    $content .= sprintf(__('"%1$s" from %2$s.'), $title, $meta['album']);
                } elseif (!empty($meta['artist'])) {
                    $content .= sprintf(__('"%1$s" by %2$s.'), $title, $meta['artist']);
                } else {
                    $content .= sprintf(__('"%s".'), $title);
                }
            } elseif (!empty($meta['album'])) {

                if (!empty($meta['artist'])) {
                    $content .= sprintf(__('%1$s by %2$s.'), $meta['album'], $meta['artist']);
                } else {
                    $content .= $meta['album'] . '.';
                }
            } elseif (!empty($meta['artist'])) {

                $content .= $meta['artist'] . '.';

            }

            if (!empty($meta['year'])) {
                $content .= ' ' . sprintf(__('Released: %d.'), $meta['year']);
            }

            if (!empty($meta['track_number'])) {
                $track_number = explode('/', $meta['track_number']);

                if (is_numeric($track_number[0])) {
                    if (isset($track_number[1]) && is_numeric($track_number[1])) {
                        $content .= ' ' . sprintf(
                            /* translators: Audio file track information. 1: Audio track number, 2: Total audio tracks. */
                                __('Track %1$s of %2$s.'),
                                number_format_i18n($track_number[0]),
                                number_format_i18n($track_number[1])
                            );
                    } else {
                        $content .= ' ' . sprintf(
                                __('Track %s.'),
                                number_format_i18n($track_number[0])
                            );
                    }
                }
            }

            if (!empty($meta['genre'])) {
                $content .= ' ' . sprintf(__('Genre: %s.'), $meta['genre']);
            }

        } elseif (str_starts_with($type, 'image/')) {
            $image_meta = wp_read_image_metadata($file);

            if ($image_meta) {
                if (trim($image_meta['title']) && !is_numeric(sanitize_title($image_meta['title']))) {
                    $title = $image_meta['title'];
                }

                if (trim($image_meta['caption'])) {
                    $excerpt = $image_meta['caption'];
                }
            }
        }

        $attachment = array_merge(
            array(
                'post_mime_type' => $type,
                'guid' => $url,
                'post_parent' => $post_id,
                'post_title' => $title,
                'post_content' => $content,
                'post_excerpt' => $excerpt,
            ),
            $post_data
        );

        unset($attachment['ID']);

        $attachment_id = wp_insert_attachment($attachment, $file, $post_id, true);

        if (!is_wp_error($attachment_id)) {
            if (!headers_sent()) {
                header('X-WP-Upload-Attachment-ID: ' . $attachment_id);
            }
            wp_update_attachment_metadata($attachment_id, wp_generate_attachment_metadata($attachment_id, $file));
        }

        return $attachment_id;
    }
    public function imageApiFunction()
    {
        if (!isset($_FILES['file'])) {
            $response_data = array(
                'stats' => false,
                'message' => "فایلی موجود نیست",
            );

            echo json_encode($response_data);
            exit();
        }
        $maxSize = 2 * 1024 * 1024;
        $allowedTypes = [
                'image/png'  => 'png',
                'image/jpeg' => 'jpg',
        ];

        if (!isset($allowedTypes[$_FILES['file']['type']])) {
            $response_data = array(
                    'stats' => false,
                    'message' => 'فرمت فایل مجاز نیست. فقط PNG، JPG و JPEG مجاز هستند.',
            );

            echo json_encode($response_data);
            exit();
        }
        if ($_FILES['file']['size'] > $maxSize) {
            $response_data = array(
                    'stats' => false,
                    'message' => "حجم فایل نباید بیشتر از 2 مگابایت باشد.",
            );

            echo json_encode($response_data);
            exit();
        }
        $attachment_id = self::media_handle('file', 0);

        if (is_wp_error($attachment_id)) {
            $response_data = array(
                'stats' => false,
                'message' => $attachment_id->get_error_message(),
            );

            echo json_encode($response_data);
            exit();
        }

        $file_url = wp_get_attachment_url($attachment_id);

        $response_data = array(
            'stats' => true,
            'file_url' => $file_url,
        );

        echo json_encode($response_data);
    }
    public function notificationsApiFunction()
    {
        $id = isset($_POST['id']) ? absint($_POST['id']) : 0;
        $user_id = get_current_user_id();
        if ($id <= 0 || $user_id <= 0) {
            return new \WP_REST_Response([
                'status' => false,
                'message' => 'درخواست نامعتبر است'
            ], 400);
        }
        $notification = NotificationModel::queryUser($id, $user_id);

        if (empty($notification)) {
            return new \WP_REST_Response([
                'status' => false,
                'message' => 'اعلان یافت نشد'
            ], 404);
        }
        NotificationModel::setRead($id, $user_id);
        UserModel::deleteAlert($user_id, $id);
        return new \WP_REST_Response([
            'status' => true,
            'html' => 'OK'
        ], 200);
    }
    public function notifApiFunction()
    {
        $id = isset($_POST['id']) ? absint($_POST['id']) : 0;
        $user_id = get_current_user_id();
        if ($id <= 0 || $user_id <= 0) {
            return new \WP_REST_Response([
                'status' => false,
                'message' => 'درخواست نامعتبر است'
            ], 400);
        }

        $notification = NotificationModel::queryUser($id, $user_id);

        if (empty($notification)) {
            return new \WP_REST_Response([
                'status' => false,
                'message' => 'اعلان یافت نشد'
            ], 404);
        }
        if ($_POST['method'] == 'r') {
            NotificationModel::setRead($id, $user_id);
            UserModel::deleteAlert($user_id, $id);
        }
        unset($notification['Id']);
        unset($notification['userId']);
        $notification['body'] = wp_kses_post($notification['body']);
        return new \WP_REST_Response([
            'status' => true,
            'html' => 'OK',
            'notification' => $notification
        ], 200);
    }
    public function postApiFunction(\WP_REST_Request $request)
    {
        $user_id = get_current_user_id();
        if ($user_id <= 0) {
            return new \WP_REST_Response([
                'status' => false,
                'message' => 'ابتدا وارد شوید'
            ], 401);
        }

        $title = sanitize_text_field($request->get_param('title'));
        $content = wp_kses_post($request->get_param('content'));
        $category = absint($request->get_param('category'));

        if ($title === '' || $content === '' || $category <= 0) {
            return new \WP_REST_Response([
                'status' => false,
                'message' => 'عنوان، متن یا دسته‌بندی را وارد کنید'
            ], 422);
        }

        if (!term_exists($category, 'category')) {
            return new \WP_REST_Response([
                'status' => false,
                'message' => 'دسته‌بندی نامعتبر است'
            ], 422);
        }

        if (!giftmax_user_can_submit_article($user_id)) {
            return new \WP_REST_Response([
                'status' => false,
                'message' => 'شما مجاز به ارسال مقاله نیستید'
            ], 403);
        }

        $post_id = wp_insert_post([
            'post_type' => 'post',
            'post_status' => 'pending',
            'post_author' => $user_id,
            'post_title' => $title,
            'post_content' => $content,
            'post_category' => [$category],
        ], true);

        if (is_wp_error($post_id) || !$post_id) {
            return new \WP_REST_Response([
                'status' => false,
                'message' => 'خطا در ثبت مقاله'
            ], 500);
        }

        update_post_meta($post_id, '_giftmax_submitted_from_frontend', 1);

        return new \WP_REST_Response([
            'status' => true,
            'message' => 'مقاله با موفقیت ثبت شد و در انتظار تایید است'
        ], 200);
    }
    public function loadCategoryApiFunction(  ) {
        ob_start();
        $term_id = $_POST['term_id'];
        $term = get_term($term_id, 'product_cat');
        $giftmax_is_user_logged_in = is_user_logged_in();
        $giftmax_wishlist_ids = $giftmax_is_user_logged_in ? giftmax_get_user_wishlist_product_ids() : [];
        if (is_wp_error($term) || !$term) {
            return new \WP_REST_Response([
                'success' => false,
                'html'    => ''
            ], 400);
        }

        $term_name = $term->name;
        $term_link = get_term_link($term);
        ?>
        <div class="act-new-service-carousel-head d-flex align-items-center justify-content-between">
            <svg xmlns="http://www.w3.org/2000/svg" width="1281" height="75" viewBox="0 0 1281 75" fill="none" class="act-new-service-carousel-head-svg">
                <path d="M1280.47 0.5H1000.91C986.771 0.5 979.703 0.5 973.764 2.99163C969.027 4.9789 964.838 8.07733 961.551 12.025C957.43 16.9747 955.361 23.7331 951.224 37.25C947.086 50.7669 945.017 57.5253 940.896 62.475C937.609 66.4227 933.42 69.5211 928.683 71.5084C922.744 74 915.676 74 901.54 74H412.882C399.847 74 393.329 74 387.813 71.8926C382.12 69.7177 377.167 65.9625 373.536 61.0686C370.017 56.3267 368.257 50.0512 364.737 37.5C361.217 24.9488 359.457 18.6733 355.938 13.9314C352.307 9.0375 347.353 5.2823 341.661 3.10737C336.145 1 329.627 1 316.592 1H0" stroke="url(#paint0_linear_29_20094)"></path>
                <defs>
                    <linearGradient id="paint0_linear_29_20094" x1="29.4736" y1="0.500002" x2="1213.79" y2="-28.0511" gradientUnits="userSpaceOnUse">
                        <stop stop-color="#0B61FF" stop-opacity="0"></stop>
                        <stop offset="0.5" stop-color="#0B61FF"></stop>
                        <stop offset="1" stop-color="#0B61FF" stop-opacity="0"></stop>
                    </linearGradient>
                </defs>
            </svg>
            <div class="act-our-services-carousel-head-title">
                <div class="act-our-services-carousel-head-title-divs">
                    <div class="act-our-services-carousel-head-title-div1"></div>
                    <div class="act-our-services-carousel-head-title-div2"></div>
                </div>
                <div class="act-our-services-carousel-head-title-content V13-category-name">
                    <h5>
                        جدیدترین <strong><?php echo esc_html($term_name); ?></strong>
                    </h5>
                    <p>PRODUCTS</p>
                </div>
            </div>
            <div class="act-new-service-carousel-head-content">

                <a class="act-link-but" href="<?php echo esc_url($term_link); ?>" target="_blank" rel="nofollow">
                    مشاهده بیشتر
                    <svg xmlns="http://www.w3.org/2000/svg" width="34" height="34" viewBox="0 0 34 34" fill="currentcolor">
                        <path d="M20.0744 10.4295C20.2088 10.5639 20.2936 10.7477 20.2936 10.9599C20.2936 11.37 19.9542 11.7094 19.5441 11.7094L11.7094 11.7094L11.7094 19.5442C11.7094 19.9543 11.3699 20.2937 10.9598 20.2937C10.5497 20.2937 10.2103 19.9543 10.2103 19.5442L10.2103 10.9599C10.2103 10.5498 10.5497 10.2103 10.9598 10.2103L19.5441 10.2103C19.7562 10.2103 19.9401 10.2952 20.0744 10.4295Z"></path>
                        <path d="M11.611 10.5501L23.5116 22.4507C23.8015 22.7406 23.8015 23.2215 23.5116 23.5114C23.2217 23.8013 22.7409 23.8013 22.451 23.5114L10.5504 11.6108C10.2605 11.3209 10.2605 10.84 10.5504 10.5501C10.8403 10.2602 11.3211 10.2602 11.611 10.5501Z"></path>
                    </svg>
                </a>
            </div>
        </div>
        <?php
        if ( ! $term_id ) {
            return new \WP_REST_Response([
                'success' => false,
                'html'    => ''
            ], 400);
        }
        $home_coupon_objects = [];
        $home_coupon_ids = get_posts([
            'post_type'      => 'shop_coupon',
            'post_status'    => 'publish',
            'numberposts'    => -1,
            'fields'         => 'ids',
        ]);

        if (!empty($home_coupon_ids)) {
            foreach ($home_coupon_ids as $home_coupon_id) {
                $home_coupon_objects[] = new \WC_Coupon($home_coupon_id);
            }
        }
        $args = [
            'post_type'      => 'product',
            'posts_per_page' => -1,
            'tax_query'      => [
                [
                    'taxonomy' => 'product_cat',
                    'field'    => 'term_id',
                    'terms'    => $term_id,
                ]
            ],
            'meta_query' => [
                'relation' => 'OR',
                [
                    'key'     => 'giftmax_setting_order',
                    'compare' => 'EXISTS',
                    'type'    => 'NUMERIC',
                ],

                [
                    'key'     => 'giftmax_setting_order',
                    'compare' => 'NOT EXISTS',
                ],
            ],

            'orderby' => [
                'meta_value_num' => 'ASC',
                'date'           => 'DESC',
            ],
            'order'          => 'ASE',
        ];
        $region_args = [
            'post_type'      => 'product',
            'posts_per_page' => -1,
            'fields'         => 'ids',
            'tax_query'      => [
                [
                    'taxonomy' => 'product_cat',
                    'field'    => 'term_id',
                    'terms'    => $term_id,
                ]
            ],
            'meta_query' => [
                [
                    'key'     => 'giftmax_box_setting',
                    'compare' => 'EXISTS'
                ]
            ]
        ];

        $region_query = new \WP_Query($region_args);

        $regions = [];

        foreach ($region_query->posts as $pid) {
            $settings = get_post_meta($pid, 'giftmax_box_setting', true);
            if (!empty($settings[0]['logo_region'])) {
                $regions[] = $settings[0]['logo_region'];
            }
        }

        $regions = array_unique($regions);
        $query = new \WP_Query($args);
        if ($query->have_posts()) :
            ?>
            <div class="w-full">
                <div class="flex flex-col overflow-hidden">
                    <div class="flex overflow-hidden mb-20">
                        <div class="flex justify-between lg:w-20 md:w-11">
                            <div class="act-our-services-carousel-head-title">
                                <div class="act-our-services-carousel-head-title-divs">
                                    <div class="act-our-services-carousel-head-title-div1 tsc54b"></div>
                                </div>
                                <div class="act-our-services-carousel-head-title-content">
                                    <h5>انتخاب <strong>کشور</strong> </h5>
                                    <p class="tsc54">SELECT REGION</p>
                                </div>
                            </div>
                        </div>
                        <div class="swiper c-box__ceWU4d" data-cat="<?=$term_id?>">
                            <div class="swiper-wrapper">
                                <div data-id="" class="act-catagory-card swiper-slide pointer button-cc45" style="width: 75px !important;">
                                    <div class="act-catagory-card-inner">
                                        <div class="act-catagory-card-name">
                                            <div class="act-our-services-carousel-head-title-divs">
                                                <div class="act-our-services-carousel-head-title-div1" style="height: 15px;  margin-bottom: 4px;"></div>
                                                <div class="act-our-services-carousel-head-title-div2" style=" height: 12px;"></div>
                                            </div>
                                            <div class="act-catagory-name-text">
                                                <strong>همه</strong>
                                                <p>All</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php
                                foreach ($regions as $region){
                                    ?>
                                    <div data-id="<?=$region?>" class="act-catagory-card swiper-slide pointer button-cc45">
                                        <div class="act-catagory-card-inner">
                                            <div class="act-catagory-card-name">
                                                <div class="act-our-services-carousel-head-title-divs">
                                                    <div class="act-our-services-carousel-head-title-div1" style="height: 15px;  margin-bottom: 4px;"></div>
                                                    <div class="act-our-services-carousel-head-title-div2" style=" height: 12px;"></div>
                                                </div>
                                                <div class="act-catagory-name-text">
                                                    <strong><?=regionPersian($region) ?></strong>
                                                    <p><?=$region?></p>
                                                </div>
                                            </div>
                                            <div class="act-catagory-card-img">
                                                <img src="<?=get_template_directory_uri() . '/assets/flag/' .$region . '.svg'?>">
                                            </div>
                                        </div>
                                    </div>
                                    <?php
                                }
                                ?>
                            </div>
                            <div class="swiper-navigation-region">
                                <div class="swiper-button-region swiper-button-prev-region">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                                        <path d="M13.583 12l-4.293 4.293 1.414 1.414 5-5c0.39-0.391 0.39-1.024 0-1.414l-5-5-1.414 1.414 4.293 4.293z"></path>
                                    </svg>
                                </div>
                                <div class="swiper-button-region swiper-button-next-region">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                                        <path d="M10.414 12l4.293 4.293-1.414 1.414-5-5c-0.391-0.391-0.391-1.024 0-1.414l5-5 1.414 1.414-4.293 4.293z"></path>
                                    </svg>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="flex fhDGSJDF">
                    <?php while ($query->have_posts()) : $query->the_post(); global $product;
                        $regular = $product->get_regular_price();
                        $sale    = $product->get_sale_price();
                        $final_price = $product->is_on_sale() && $sale > 0 ? $sale : $regular;
                        $img = get_the_post_thumbnail_url(get_the_ID(), 'product_discount');
                        $settings = get_post_meta($product->get_id(), 'giftmax_box_setting', true);
                        $delivery = get_post_meta($product->get_id(), 'delivery', true);
                        $matched_coupon_code = '';

                        if (!empty($home_coupon_objects)) {
                            foreach ($home_coupon_objects as $home_coupon_obj) {
                                $expires_at = $home_coupon_obj->get_date_expires();

                                if ($expires_at && $expires_at->getTimestamp() < current_time('timestamp')) {
                                    continue;
                                }
                                $usage_limit = (int) $home_coupon_obj->get_usage_limit();
                                $usage_count = (int) $home_coupon_obj->get_usage_count();
                                if ($usage_limit > 0 && $usage_count >= $usage_limit) {
                                    continue;
                                }
                                if ($home_coupon_obj->is_valid_for_product($product)) {
                                    $matched_coupon_code = $home_coupon_obj->get_code();
                                    break;
                                }
                            }
                        }
                        ?>
                        <div>
                            <div class="act-new-service-card <?=!empty($matched_coupon_code) ? 'has-discount' : ''?>">
                                <?php if (!empty($matched_coupon_code) && !isMobile()) { ?>
                                    <div class="act-new-service-card-discount Button-sc91" data-product-id="<?=esc_attr($product->get_id())?>">
                                        <div class="anScr"></div>
                                        <div class="anSct">مشاهده کد تخفیف</div>
                                        <div class="anScl"></div>
                                    </div>
                                <?php } ?>
                                <div class="act-new-service-card-inner">
                                    <div <?=isset($delivery['two']) && $delivery['two'] == 'on' || product_available($product->get_id()) ?'':'class="NdhJD5"'?>>
                                        <div class="act-new-service-card-inner-top">
                                            <a href="<?=get_permalink()?>">
                                                <div class="act-new-service-card-inner-top-img-box relative">
                                                    <img loading="lazy" decoding="async" width="32" height="33" src="<?=$img?>" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="">
                                                    <?php
                                                    if (!empty($settings[0]['logo_region'])){
                                                        ?>
                                                        <div class="logo_region">
                                                            <img src="<?=empty($settings[0]['logo_region']) ?: get_template_directory_uri() . '/assets/flag/' . $settings[0]['logo_region'] . '.svg'?>">
                                                        </div>
                                                        <?php
                                                    }
                                                    $date_from = $product->get_date_on_sale_from();
                                                    $date_to   = $product->get_date_on_sale_to();
                                                    if ($product->is_on_sale() & ($date_from || $date_to)){
                                                        ?>
                                                        <div class="logo_detail" style="top: 7px;right: 7px;background-color: transparent;">
                                                            <img width="33" height="29" src="<?=get_template_directory_uri()?>/assets/img/svg/Amazings.svg">
                                                        </div>
                                                        <?php
                                                    } elseif ($product->is_on_sale()){
                                                        ?>
                                                        <div class="logo_detail" style="top: 7px;right: 7px;">
                                                            <img src="<?=get_template_directory_uri()?>/assets/img/svg/percent.svg">
                                                        </div>
                                                        <?php
                                                    }
                                                    ?>
                                                </div>
                                            </a>
                                            <div class="act-new-service-card-inner-top-txt-box" <?=!empty($settings[0]['label']) && $settings[0]['label'] != '' ? 'style="gap:2px"' : ''?>>
                                                <a href="<?=get_permalink()?>">
                                                    <h4 class="act-product-title"><?=get_the_title()?></h4>
                                                    <?php
                                                    if(!empty($settings[0]['sub_head']) && !isMobile()) echo "<p class='act-product-title-en'>" . $settings[0]['sub_head'] . "</p>";
                                                    ?>
                                                </a>
                                                <div class="flex justify-between">
                                                    <div class="flex">
                                                        <?php
                                                        $tooltip = isset($delivery['description']) ? $delivery['description'] : '';
                                                        ?>
                                                        <div class="act-product-option-box__nw <?=isset($delivery['two']) && $delivery['two'] == 'on' ? 'pre-sale wiki wiki__holder js-dk-wiki-trigger' : 'same-day'?>" <?=isset($delivery['two']) && $delivery['two'] == 'on' ? 'data-tooltip="'. $tooltip .'"' :''?>><?=isset($delivery['two']) && $delivery['two'] == 'on' ? 'پیش فروش' : 'تحویل آنی'?></div>
                                                        <div class="purchaseScore wiki wiki__holder js-dk-wiki-trigger" data-tooltip="با خرید این گیفت کارت <?=empty($settings[0]['purchaseScore']) ?0: $settings[0]['purchaseScore']?> امتیاز دریافت میکنید">
                                                            <i class="icon-star"></i>
                                                            <?=empty($settings[0]['purchaseScore']) ?0: $settings[0]['purchaseScore']?>
                                                        </div>
                                                    </div>
                                                    <?php $is_in_wishlist = in_array((int) $product->get_id(), $giftmax_wishlist_ids, true); ?>
                                                    <button class="add-to__favorites Button-alu84 <?=$is_in_wishlist ? 'is-active' : ''?>" data-product-id="<?=esc_attr($product->get_id())?>" data-auth="<?=$giftmax_is_user_logged_in ? '1' : '0'?>" style="width: 28px;height: 28px;border-radius: 7px">
                                                        <svg viewBox="0 0 24 24" style="width: 64%;">
                                                            <path d="M12.62 20.81C12.28 20.93 11.72 20.93 11.38 20.81C8.48 19.82 2 15.69 2 8.68998C2 5.59998 4.49 3.09998 7.56 3.09998C9.38 3.09998 10.99 3.97998 12 5.33998C13.01 3.97998 14.63 3.09998 16.44 3.09998C19.51 3.09998 22 5.59998 22 8.68998C22 15.69 15.52 19.82 12.62 20.81Z" fill="<?=$is_in_wishlist ? '#ef4444' : 'none'?>" stroke="<?=$is_in_wishlist ? '#ef4444' : 'inherit'?>" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                                                        </svg>
                                                    </button>
                                                </div>
                                                <?php if (!empty($matched_coupon_code) && isMobile()) { ?>
                                                    <div class="act-new-service-card-discount Button-sc91" data-product-id="<?=esc_attr($product->get_id())?>">
                                                        مشاهده کد تخفیف
                                                    </div>
                                                <?php }else{ ?>
                                                    <p class="act-product-txt"><?=empty($settings[0]['description_short']) ?'': $settings[0]['description_short']?></p>
                                                    <?php
                                                }
                                                ?>                                                <?php
                                                if (!empty($settings[0]['label']) && $settings[0]['label'] != ''){?>
                                                    <div class="label-fjd84">
                                                        <img src="<?=empty($settings[0]['label']) ?'': $settings[0]['label']?>" class="logo_label">
                                                        <p class="label_title"><?=empty($settings[0]['label_title']) ?'': $settings[0]['label_title']?></p>
                                                    </div>
                                                    <?php
                                                }
                                                ?>
                                            </div>
                                        </div>
                                    </div>
                                    <?php
                                    $date_from = $product->get_date_on_sale_from();
                                    $date_to   = $product->get_date_on_sale_to();
                                    if ($product->is_on_sale() & ($date_from || $date_to)) {
                                        $sale_from_ts = $date_from ? $date_from->getTimestamp() : null;
                                        $sale_to_ts   = $date_to ? $date_to->getTimestamp() : null;
                                        if ($sale_from_ts && $sale_to_ts) {
                                            $now_ts = time();
                                            $total_duration = $sale_to_ts - $sale_from_ts;
                                            $elapsed = $now_ts - $sale_from_ts;

                                            $progress_percent = max(0, min(100, ($elapsed / $total_duration) * 100));
                                        } else {
                                            $progress_percent = 0;
                                        }
                                    }else{
                                        $sale_to_ts = null;
                                    }
                                    if (!$sale_to_ts){
                                        ?>
                                        <div class="act-hor-bor"></div>
                                        <?php
                                    }else{
                                        ?>
                                        <div class="flex justify-between flex-col">
                                            <div class="relative bg-neutral-100 style_ProductPromotionTimeline__progress__JnKWE" style="">
                                                <div class="absolute bg-primary-700 h-full left-0 top-0 style_ProductPromotionTimeline--active__oYyta" style="width: <?=$progress_percent?>%;"></div>
                                            </div>
                                            <span class="text-primary-700 text-body2-strong style_ProductPromotionTimeline__timer__zS6ZA1 text-left"><?= date('Y-m-d H:i:s', $sale_to_ts); ?></span>

                                        </div>
                                        <?php
                                    }
                                    ?>
                                    <div>
                                        <?php
                                        if(!empty($matched_coupon_code)){
                                            $usage_limit  = (int) $home_coupon_obj->get_usage_limit();
                                            $usage_count  = (int) $home_coupon_obj->get_usage_count();

                                            $remaining_uses = $usage_limit > 0
                                                ? max( 0, $usage_limit - $usage_count )
                                                : __( 'نامحدود', 'textdomain' );
                                            ?>
                                            <div class="">
                                                <div class="relative bg-neutral-100 style_ProductPromotionTimeline__progress__JnKWE">
                                                    <div class="absolute bg-primary-700 h-full left-0 top-0 style_ProductPromotionTimeline--active__oYyta" style="width: <?=($home_coupon_obj->get_usage_count()/($home_coupon_obj->get_usage_count()+$remaining_uses))*100?>%;"></div>
                                                </div>
                                                <div class="whitespace-nowrap flex justify-between pt-1">
                                                    <div class=""><span class="text-primary-700 text-body-strong ml-1"><?=($home_coupon_obj->get_usage_count()/($home_coupon_obj->get_usage_count()+$remaining_uses))*100?>%</span><span class="text-neutral-500 text-caption">فروش رفته</span></div>
                                                    <?php
                                                    if ($home_coupon_obj->get_date_expires()){
                                                        ?>
                                                        <div class="text-primary-700 text-body2-strong style_ProductPromotionTimeline__timer__zS6ZA"><?= $home_coupon_obj->get_date_expires() ? $home_coupon_obj->get_date_expires()->date_i18n( 'Y-m-d H:i:s' ) : 'بدون تاریخ انقضا'?></div>
                                                        <?php
                                                    }else{?>
                                                        <div class="text-primary-700 text-body2-strong style_ProductPromotionTimeline__timer__zS6ZA"></div>
                                                    <?php }
                                                    ?>
                                                </div>
                                            </div>
                                            <?php
                                        }
                                        ?>
                                        <div class="act-product-card-footer">
                                            <a href="<?=the_permalink()?>" class="act-special-carousel-card-buy-box-option">جزئیات</a>
                                            <div class="act-product-price-box">
                                                <?php
                                                if ( $product->is_on_sale() ) {?>
                                                    <div class="act-product-price-box-top">
                                                        <div class="act-product-price-off-price"><?=number_format_usd($regular)?></div>
                                                        <div class="act-product-price-off-percent">  <?=get_discount_percent($product)?> ٪       </div>


                                                    </div>
                                                    <?php
                                                }
                                                ?>
                                                <div class="act-product-price<?=$product->is_on_sale() ? ' bpt' : ''?>">
                                                    <?php
                                                    if($final_price > 0){?>
                                                        <div id="priceValue" data-id="<?=$product->get_id()?>" data-target="<?=payment_usd($product->is_on_sale() ? $sale :$regular)?>"><?=number_format_usd($product->is_on_sale() ? $sale : $regular)?></div><span>تومان</span>
                                                        <?php
                                                    }else{
                                                        ?>
                                                        <div class="act-product-price-free">رایگان</div>
                                                        <?php
                                                    }
                                                    ?>
                                                </div>
                                            </div>
                                        </div>
                                        <?php
                                        if (isset($delivery['two']) && $delivery['two'] == 'on' || product_available($product->get_id())){
                                            if (SiteModel::setting("buy") === true){
                                                ?>
                                                <button type="button" class="act-special-carousel-card-buy-box-but Button-aca48 pointer" data-product-id="<?=$product->get_id()?>">
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="26" height="26" viewBox="0 0 26 26" fill="currentcolor">
                                                        <path d="M17.875 9.34916C17.4308 9.34916 17.0625 8.98083 17.0625 8.53666V7.04166C17.0625 5.90416 16.575 4.79916 15.73 4.03C14.8742 3.25 13.7692 2.8925 12.5992 3.00083C10.6492 3.185 8.9375 5.17833 8.9375 7.25833V8.30916C8.9375 8.75333 8.56917 9.12166 8.125 9.12166C7.68083 9.12166 7.3125 8.75333 7.3125 8.30916V7.2475C7.3125 4.33333 9.66333 1.64666 12.4475 1.37583C14.0725 1.22417 15.6325 1.73333 16.8242 2.8275C18.005 3.9 18.6875 5.43833 18.6875 7.04166V8.53666C18.6875 8.98083 18.3192 9.34916 17.875 9.34916Z"></path>
                                                        <path d="M16.2498 24.6457H9.7498C4.7448 24.6457 3.81314 22.3165 3.5748 20.0523L2.7623 13.5632C2.64314 12.3932 2.5998 10.714 3.7373 9.45734C4.7123 8.374 6.32647 7.854 8.66647 7.854H17.3331C19.684 7.854 21.2981 8.38484 22.2623 9.45734C23.389 10.714 23.3565 12.3932 23.2373 13.5415L22.4248 20.0523C22.1865 22.3165 21.2548 24.6457 16.2498 24.6457ZM8.66647 9.479C6.83564 9.479 5.57897 9.8365 4.9398 10.5515C4.40897 11.1365 4.23564 12.0357 4.37647 13.379L5.18897 19.8682C5.37314 21.6015 5.8498 23.0315 9.7498 23.0315H16.2498C20.1498 23.0315 20.6265 21.6123 20.8106 19.8898L21.6231 13.379C21.764 12.0573 21.5906 11.1582 21.0598 10.5623C20.4206 9.8365 19.164 9.479 17.3331 9.479H8.66647Z"></path>
                                                        <path d="M16.7045 14.2458C16.0979 14.2458 15.6104 13.7583 15.6104 13.1624C15.6104 12.5666 16.0979 12.0791 16.6937 12.0791C17.2895 12.0791 17.777 12.5666 17.777 13.1624C17.777 13.7583 17.3004 14.2458 16.7045 14.2458Z"></path>
                                                        <path d="M9.12151 14.2458C8.51484 14.2458 8.02734 13.7583 8.02734 13.1624C8.02734 12.5666 8.51484 12.0791 9.11068 12.0791C9.70651 12.0791 10.194 12.5666 10.194 13.1624C10.194 13.7583 9.71734 14.2458 9.12151 14.2458Z"></path>
                                                    </svg>
                                                    افزودن به سبد خرید
                                                </button>
                                                <?php
                                            }else{?>
                                                <button type="button" class="btn btn-buy-disable mb-2" >خرید از سایت غیرفعال هست</button>
                                                <?php
                                            }
                                        }else{
                                            echo '<div class="inaJSDge8">ناموجود</div>';
                                        }
                                        ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endwhile; ?>
                </div>
                <span class="swiper-notification" aria-live="assertive" aria-atomic="true"></span>
            </div>
        <?php
        else :
            ?>
            <div class="w-full flex justify-center fhDGSJDF sfje5">
                <p>محصولی در این دسته بندی قرار نداره</p>
            </div>
        <?php
        endif;
        wp_reset_postdata();

        $html = ob_get_clean();
        $extra_description = get_term_meta($term->term_id, 'extra_description', true);

        return new \WP_REST_Response([
            'success' => true,
            'html'    => $html,
            'description'=> $extra_description,
        ], 200);
    }
    public function searchApiFunction() {
        if (!isset($_POST['keyword']))
            wp_send_json_error();

        $keyword = sanitize_text_field($_POST['keyword']);

        /* ===== محصول اصلی (بالا) ===== */
        $args = [
                'post_type'      => 'product',
                'posts_per_page' => 3,
                's'              => $keyword,
                'orderby'        => 'meta_value_num',
                'meta_key'        => 'total_sales',
                'order'           => 'DESC'
        ];

        $query = new \WP_Query($args);

        $html = '';

        if ($query->have_posts()) :
            while ($query->have_posts()) : $query->the_post();

                $product_id = get_the_ID();
                $title       = get_the_title();
                $link        = get_permalink();
                $image       = get_the_post_thumbnail_url($product_id, 'product_discount');

                $html .= '
            <div class="row header-search-result--first--row">
            <div class="header-search-result__col">
                <div class="header-search-result__area">
                    <div class="header-search-result__products">
                        <a href="'. esc_url($link) .'" class="header-search-result__products-card">

                            <div class="header-search-result__products-card-img">
                                <img src="'. esc_url($image) .'" alt="thumb">
                            </div>

                            <div class="header-search-result__products-card-content">

                                <div class="header-search-result__products-card-content-inner">
                                    <div class="header-search-result__products-card-title">
                                        '. esc_html($title) .'
                                    </div>
                                </div>

                                <div class="header-search-result__products-card-content-icon">
                                    <i class="icon-arrow-up"></i>
                                </div>
                            </div>
                        </a>
                    </div>
                </div>
                </div>
            </div>';
            endwhile;

        else:

            $html .= '<div class="col-lg-12 text-center p-4">محصولی یافت نشد!</div>';

        endif;

        wp_reset_postdata();
        $argsPost = [
                'post_type'      => 'post',
                'posts_per_page' => 3,
                's'              => $keyword,
                'order'           => 'DESC'
        ];

        $queryPost = new \WP_Query($argsPost);

        if ($queryPost->have_posts()) :
            $html .= '<div class="header-search-result__post"><span>مقالات</span><div style="display: flex; gap: 3px; flex-wrap: wrap;">';

            while ($queryPost->have_posts()) : $queryPost->the_post();

                $html .= '
            <div class="header-search-result__posts">
            
<a href="'. esc_url(get_permalink()) .'" class="header-search-result__post-card">
    <div class="header-search-result__post-card-title">
                                        '. get_the_title() .'
                                    </div>
                        </a>
                                    </div>';
            endwhile;
            $html .= '</div></div>';
        endif;
        wp_reset_postdata();


        /* ===== دسته بندی ها ===== */

        $count_query = new \WP_Query(
                [
                        'post_type'      => 'product',
                        'posts_per_page' => -1,
                        's'              => $keyword,
                        'fields'         => 'ids',
                ]
        );

        $product_count = $count_query->found_posts;
        wp_reset_postdata();

        /* -------------------------------------------------------
         * 4. جست‌وجوی وب‌لاگ (بدون دسته‌بندی)
         * ------------------------------------------------------- */
        $blog_query = new \WP_Query(
                [
                        'post_type'      => 'post',
                        'posts_per_page' => -1,
                        's'              => $keyword,
                        'fields'         => 'ids',
                ]
        );
        $blog_count = $blog_query->found_posts;
        wp_reset_postdata();


        $html .= '
    <div class="col-lg-12 p-0">
        <div class="header-search-result__history header-search-result__history--categories">
            <ul class="header-search-result__list-content header-search-result--categories">';

        $product_link = add_query_arg([
                's'   => $keyword,
                'type'   => 'product',
        ], site_url('/'));
        $post_link = add_query_arg([
                's'   => $keyword,
                'type'   => 'post',
        ], site_url('/'));

        $html .= ' 
  <li class="header-search-result__list-item">

                <a href="'. esc_url($product_link) .'">

                    <div class="header-search-result__list-item-title">
                        <i class="icon-search"></i>
                        <span> جستجو در بخش محصولات </span>
                    </div>

                    <div class="header-search-result__list-item-action">
                        <div class="header-search-result__list-item-action-text">
                            '. $product_count .' محصول
                        </div>

                        <div class="header-search-result__list-item-icon">
                            <i class="icon-arrow-up"></i>
                        </div>
                    </div>

                </a>

            </li>
            <li class="header-search-result__list-item">

                <a href="'. esc_url($post_link) .'">

                    <div class="header-search-result__list-item-title">
                        <i class="icon-search"></i>
                      <span> جستجو در بخش مقالات </span>
                    </div>

                    <div class="header-search-result__list-item-action">
                        <div class="header-search-result__list-item-action-text">
                            '. $blog_count .' مقالات
                        </div>

                        <div class="header-search-result__list-item-icon">
                            <i class="icon-arrow-up"></i>
                        </div>
                    </div>

                </a>

            </li>';


        /* ===== مشاهده همه ===== */

        $html .= '
            </ul>
        </div>
    </div>';

        wp_send_json_success([
                'html' => $html
        ]);
    }
    public function alertNotifFunction()
    {
        if (is_user_logged_in()) {
            if($_POST['method'] == 'delete') {
                UserModel::deleteAlert('alert', $_POST['id'],1);
                \wp_send_json_success(array(
                        'status' => 'true'
                ));
            }else if ($_POST['method'] == 'show') {
                $hash = isset($_POST['id']) ? $_POST['id'] : 0;
                $user_id = get_current_user_id();
                if ($hash == 0 || $user_id <= 0) {
                    return new \WP_REST_Response([
                            'status' => false,
                            'message' => 'درخواست نامعتبر است'
                    ], 400);
                }

                $records = SiteModel::table('alert', 'hash', $hash);
                if (!empty($records)){
                    $id = $records['notificationsId'];
                    $notification = NotificationModel::queryUser($id, $user_id);
                    if (empty($notification)) {
                        return new \WP_REST_Response([
                                'status' => false,
                                'message' => 'اعلان یافت نشد'
                        ], 404);
                    }
                    NotificationModel::setRead($id, $user_id);
                    UserModel::deleteAlert($user_id,$id);
                    unset($notification['Id']);
                    unset($notification['userId']);
                    return \wp_send_json_success([
                            'status' => true,
                            'html' => 'OK',
                            'notification' => $notification
                    ]);
                }else{
                    return \wp_send_json_success(array('status' => 'false','message'=>"پیام موجود نمیباشد"));
                }
            } else{
                return \wp_send_json_success(array('status' => 'true'));
            }
        }else{
            return \wp_send_json_success(array('status' => 'true'));
        }
    }
    public function alertApiFunction()
    {
        if (is_user_logged_in()) {
            $userId = get_current_user_id();
            $records = UserModel::getAlert($userId);
            if (empty($records)) {
                $records = null;
            }else{
                $records = $records['hash'];
            }
            return \wp_send_json_success(array(
                    'status' => 'true',
                    'records' => $records
            ));
        }else{
            return \wp_send_json_success(array('status' => 'true'));
        }
    }
    public function PaginationApiFunction()
    {
        if (!isset($_POST['page']) || !isset($_POST['method'])) {
            echo json_encode(['status'=>false,'message'=>'اطلاعت ناقص']);
        }
        $paged = absint($_POST['page']);
        $user_id = get_current_user_id();
        if ($_POST['method'] == "order"){
            ob_start();
            $paged = absint($_POST['page']);
            $per_page = 10;
            $args = [
                    'customer_id' => $user_id,
                    'limit'       => $per_page,
                    'page'        => $paged,
                    'orderby'     => 'date',
                    'order'       => 'DESC',
            ];
            $orders = wc_get_orders($args);
            if ($orders){
                foreach ($orders as $dashboard_order):
                    $dashboard_order_date = $dashboard_order->get_date_created();
                    $dashboard_order_date = $dashboard_order_date ? $dashboard_order_date->date_i18n('Y/m/d') : '-';
                    if (!isMobile()){
                        ?>
                        <tr class="cursor-pointer">
                            <td data-content="تاریخ سفارش">
                                <div class="table-td-inner"><?=gjdate($dashboard_order_date,"d M Y")?></div>
                            </td>
                            <td data-content="تاریخ سفارش">
                                <div class="table-td-inner"><?php
                                    $gateway = $dashboard_order->get_payment_method();
                                    if ( $gateway === 'payment4' ) {
                                        $currency = 'USD';
                                    } else {
                                        $currency = 'TOMAN';
                                    }
                                    $amount = $dashboard_order->get_total();
                                    echo gm_wc_price( $amount, array( 'currency' => $currency ) );
                                    ?>
                                </div>
                            </td>
                            <td data-content="وضعیت سفارش" class="py-7">
                                <div class="table-td-inner">
                                    <?php
                                    if ($dashboard_order->get_status() == 'card-not-verified'){?>
                                        <div class="flex gap-2">
                                            <span class="badge status-pill--completed text-3xs">تکمیل شده</span>
                                            <span class="badge status-pill--card-not-verified text-3xs">مغایرت کارت بانکی</span>
                                        </div>
                                        <span class="badge status-pill--pending text-3xs" style="margin-top: 3px;">تایید مالکیت کارت</span>
                                        <?php
                                    }else{?>
                                        <span class="badge status-pill--<?=$dashboard_order->get_status()?> text-3xs"><?= esc_html(wc_get_order_status_name($dashboard_order->get_status())) ?></span>
                                        <?php
                                    }
                                    ?>
                                </div>
                            </td>
                            <td data-content="وضعیت فروش">
                                <?php
                                $is_preorder = $dashboard_order->get_meta('_has_preorder_items');
                                if(!$is_preorder) {?>
                                    <div class="badge badge-primary text-3xs">تحویل آنی</div>
                                    <?php
                                }else{
                                    $presale = get_max_presale_item_by_order_id($dashboard_order->get_id());
                                    if ($presale['t'] && $presale['license_status'] != 2){?>
                                        <div class="table-td-inner">
                                            <span class="text-neutral-500 text-caption line-height-1">تحویل با تاخیر</span>
                                            <div class="text-primary-700 text-body2-strong style_ProductPromotionTimeline__timer__zS6ZA1 line-height-1 mt-1"><?=$presale['ctt']?></div>
                                        </div>
                                        <?php
                                    }else{
                                        ?>
                                        <div class="badge badge-info text-3xs">تحویل با تاخیر</div>
                                        <?php
                                    }
                                }
                                ?>
                            </td>
                            <td data-content="وضعیت تحویل">
                                <?php
                                if ($dashboard_order->get_status() == 'completed'){
                                    if($is_preorder){
                                        if ($presale['license_status'] == 0){
                                            echo '<span class="badge status-pill--pending text-3xs">درحال تامین کالا</span>';
                                        }elseif ($presale['license_status'] == 1){
                                            echo '<span class="badge status-pill--checkout-draft text-3xs">در حال تحویل</span>';
                                        }elseif ($presale['license_status'] == 2){
                                            echo '<span class="badge status-pill--completed text-3xs">تحویل داده شد</span>';
                                        }
                                    }else{
                                        ?>
                                        <span class="badge status-pill--completed text-3xs">تحویل داده شد</span>
                                        <?php
                                    }
                                }else if ($dashboard_order->get_status() == 'card-not-verified'){
                                    ?>
                                    <div class="flex justify-between">
                                        <span class="badge status-pill--failed text-3xs">عدم تحویل</span>
                                        <?php
                                        $cardPay = $dashboard_order->get_meta( '_card_pay', true );
                                        $isCheck = $dashboard_order->get_meta( '_is_card_pay', true );
                                        $card = SiteModel::table('user_bank_cards', 'card_number_enc', encrypt_data($cardPay),"user_id",$user_id);
                                        if (!empty($card)) {
                                            ?>
                                            <span class="badge status-pill--completed text-3xs">تایید کارت</span>
                                            <?php
                                        }else{
                                            ?>
                                            <span class="badge status-pill--failed text-3xs">تایید کارت</span>
                                            <?php
                                        }
                                        ?>
                                        <span class="badge status-pill--failed text-3xs check-phone">تایید تلفن</span>
                                    </div>
                                    <?php
                                }else if ($dashboard_order->get_status() != 'card-not-verified' && $dashboard_order->get_status() != 'completed'){
                                    ?>
                                    <span class="badge status-pill--failed text-3xs">عدم تحویل</span>
                                    <?php
                                }
                                ?>
                            </td>
                            <td class="table-list-actions">
                                <div class="table-td-inner flex justify-end pb-2 space-x-8 space-x-reverse align-items-center">
                                    <?php
                                    if ($dashboard_order->get_status() != 'card-not-verified'){
                                        ?>
                                        <a class="btn btn-2xs btn-white text-dark btn-view" href="<?= esc_url(home_url('/profile/invoices/' . $dashboard_order->get_id())) ?>">مشاهده</a>
                                        <?php
                                    }else{
                                        if ($isCheck){?>
                                            <svg class="Button-od94" data-number="<?=$cardPay?>" data-id="<?=encrypt_id($dashboard_order->get_id())?>" viewBox="0 0 24 24"><path fill-rule="evenodd" d="M2 12c0 5.523 4.477 10 10 10s10-4.477 10-10S17.523 2 12 2 2 6.477 2 12zm18 0a8 8 0 11-16 0 8 8 0 0116 0zm-10-2h3v7h-2v-5h-1v-2zm3-2a1 1 0 10-2 0 1 1 0 002 0z" clip-rule="evenodd"></path></svg>
                                            <button class="btn btn-2xs btn-white text-dark btn-view Button-vcs788" data-id="<?=encrypt_id($dashboard_order->get_id())?>">تایید کارت</button>
                                        <?php }else{?>
                                            <svg class="Button-od94" data-number="<?=$cardPay?>" data-check="1" data-id="<?=encrypt_id($dashboard_order->get_id())?>" viewBox="0 0 24 24"><path fill-rule="evenodd" d="M2 12c0 5.523 4.477 10 10 10s10-4.477 10-10S17.523 2 12 2 2 6.477 2 12zm18 0a8 8 0 11-16 0 8 8 0 0116 0zm-10-2h3v7h-2v-5h-1v-2zm3-2a1 1 0 10-2 0 1 1 0 002 0z" clip-rule="evenodd"></path></svg>
                                            <button class="btn btn-2xs btn-white text-dark btn-view Button-sc45" data-number="<?=$cardPay?>" data-id="<?=encrypt_id($dashboard_order->get_id())?>">تایید کارت</button>
                                            <?php
                                        } }
                                    ?>

                                </div>
                            </td>
                        </tr>
                        <?php
                    }else{?>
                        <tr class="cursor-pointer">
                            <td data-content="شماره فاکتور">
                                <div class="table-td-inner text-sm tracking-tight font-medium text-dark ellipsis">#<?= esc_html($dashboard_order->get_order_number()) ?></div>
                            </td>
                            <td data-content="تاریخ سفارش">
                                <div class="table-td-inner"><?=gjdate($dashboard_order_date,"d M Y")?></div>
                            </td>
                            <td data-content="مبلغ سفارش">
                                <div class="table-td-inner"><?php
                                    $gateway = $dashboard_order->get_payment_method();
                                    if ( $gateway === 'payment4' ) {
                                        $currency = 'USD';
                                    } else {
                                        $currency = 'TOMAN';
                                    }
                                    $amount = $dashboard_order->get_total();
                                    echo gm_wc_price( $amount, array( 'currency' => $currency ) );
                                    ?>
                                </div>
                            </td>
                            <td data-content="وضعیت سفارش">
                                <div class="table-td-inner">
                                    <span class="badge status-pill--<?=$dashboard_order->get_status()?> text-3xs"><?= esc_html(wc_get_order_status_name($dashboard_order->get_status())) ?></span>
                                </div>
                            </td>
                            <td data-content="وضعیت فروش">
                                <?php
                                $is_preorder = $dashboard_order->get_meta('_has_preorder_items');
                                if(!$is_preorder) {?>
                                    <div class="badge badge-primary text-3xs">تحویل آنی</div>
                                    <?php
                                }else{
                                    $presale = get_max_presale_item_by_order_id($dashboard_order->get_id());
                                    if ($presale['t'] && $presale['license_status'] != 2){?>
                                        <div class="table-td-inner">
                                            <span class="text-neutral-500 text-caption line-height-1">تحویل با تاخیر</span>
                                            <div class="text-primary-700 text-body2-strong style_ProductPromotionTimeline__timer__zS6ZA1 line-height-1 mt-1"><?=$presale['ctt']?></div>
                                        </div>
                                        <?php
                                    }else{
                                        ?>
                                        <div class="badge badge-info text-3xs">تحویل با تاخیر</div>
                                        <?php
                                    }
                                }
                                ?>
                            </td>
                            <td data-content="وضعیت تحویل">
                                <div class="table-td-inner">
                                    <?php
                                    if ($dashboard_order->get_status() == 'completed'){
                                        if($is_preorder){
                                            if ($presale['license_status'] == 0){
                                                echo '<span class="badge status-pill--pending text-3xs">درحال تامین کالا</span>';
                                            }elseif ($presale['license_status'] == 1){
                                                echo '<span class="badge status-pill--checkout-draft text-3xs">در حال تحویل</span>';
                                            }elseif ($presale['license_status'] == 2){
                                                echo '<span class="badge status-pill--completed text-3xs">تحویل داده شد</span>';
                                            }
                                        }else{
                                            ?>
                                            <span class="badge status-pill--completed text-3xs">تحویل داده شد</span>
                                            <?php
                                        }
                                    }else if ($dashboard_order->get_status() == 'card-not-verified'){
                                        ?>
                                        <div class="flex justify-between">
                                            <span class="badge status-pill--failed text-3xs">عدم تحویل</span>
                                            <?php
                                            $cardPay = $dashboard_order->get_meta( '_card_pay', true );
                                            $isCheck = $dashboard_order->get_meta( '_is_card_pay', true );
                                            $card = SiteModel::table('user_bank_cards', 'card_number_enc', encrypt_data($cardPay),"user_id",$user_id);
                                            if (!empty($card)) {
                                                ?>
                                                <span class="badge status-pill--completed text-3xs">تایید کارت</span>
                                                <?php
                                            }else{
                                                ?>
                                                <span class="badge status-pill--failed text-3xs">تایید کارت</span>
                                                <?php
                                            }
                                            ?>
                                            <span class="badge status-pill--failed text-3xs check-phone">تایید تلفن</span>
                                        </div>
                                        <?php
                                    }else if ($dashboard_order->get_status() != 'card-not-verified' && $dashboard_order->get_status() != 'completed'){
                                        ?>
                                        <span class="badge status-pill--failed text-3xs">عدم تحویل</span>
                                        <?php
                                    }
                                    ?>
                                </div>
                            </td>
                            <td class="table-list-actions">
                                <div class="table-td-inner flex justify-end pb-2 space-x-8 space-x-reverse align-items-center">
                                    <?php
                                    if ($dashboard_order->get_status() != 'card-not-verified'){
                                        ?>
                                        <a class="btn btn-2xs btn-white text-dark btn-view" href="<?= esc_url('/profile/invoices/' . $dashboard_order->get_id()) ?>">مشاهده</a>
                                        <?php
                                    }else{
                                        if ($isCheck){?>
                                            <svg class="Button-od94" data-number="<?=$cardPay?>" data-id="<?=encrypt_id($dashboard_order->get_id())?>" viewBox="0 0 24 24"><path fill-rule="evenodd" d="M2 12c0 5.523 4.477 10 10 10s10-4.477 10-10S17.523 2 12 2 2 6.477 2 12zm18 0a8 8 0 11-16 0 8 8 0 0116 0zm-10-2h3v7h-2v-5h-1v-2zm3-2a1 1 0 10-2 0 1 1 0 002 0z" clip-rule="evenodd"></path></svg>
                                            <button class="btn btn-2xs btn-white text-dark btn-view Button-vcs788" data-id="<?=encrypt_id($dashboard_order->get_id())?>">تایید کارت</button>
                                        <?php }else{?>
                                            <svg class="Button-od94" data-number="<?=$cardPay?>" data-check="1" data-id="<?=encrypt_id($dashboard_order->get_id())?>" viewBox="0 0 24 24"><path fill-rule="evenodd" d="M2 12c0 5.523 4.477 10 10 10s10-4.477 10-10S17.523 2 12 2 2 6.477 2 12zm18 0a8 8 0 11-16 0 8 8 0 0116 0zm-10-2h3v7h-2v-5h-1v-2zm3-2a1 1 0 10-2 0 1 1 0 002 0z" clip-rule="evenodd"></path></svg>
                                            <button class="btn btn-2xs btn-white text-dark btn-view Button-sc45" data-number="<?=$cardPay?>" data-id="<?=encrypt_id($dashboard_order->get_id())?>">تایید کارت</button>
                                            <?php
                                        }
                                    }
                                    ?>
                                </div>
                            </td>
                        </tr>
                    <?php }
                    ?>
                <?php endforeach;
            }else{
                ?>
                <section class="p-5 TableCard--bodyMobile-tDS3OZ">
                    <div class="d-flex ai-center jc-center align-center w-100 h-100">
                        <div class="py-4 d-flex flex-column jc-center ai-center EmptyState__desktopContainer-ggZkIg">
                            <div class="d-flex jc-center mb-3" data-testid="empty-src">
                                <div data-testid="image-wrapper" style="width: 200px; height: 150px;">
                                    <img class="w-100" src="<?=get_template_directory_uri()?>/assets/img/ticket_img.png" width="200" height="150" data-testid="image-defaultImage" style="object-fit: contain;">
                                </div>
                            </div>
                            <div class="text-h5 color-900">نتیجه&zwnj;ای پیدا نکردیم...</div>
                            <div class="text-caption-strong color-500" data-testid="empty-description">
                                <div>فیلتر ها رو تغییر دهید و سپس دوباره امتحان کنید.</div>
                            </div>
                        </div>
                    </div>
                </section>
                <?php
            }
            $output = ob_get_clean();
            ob_start();
            $total_orders = wc_get_orders([
                    'customer_id' => $user_id,
                    'limit'       => -1,
            ]);

            $total_pages = ceil(count($total_orders) / $per_page);
            for ($i = $paged-1; $i <= $paged+1; $i++) {
                if ($i < 1){
                    continue;
                }
                if ($i>$total_pages){continue;}
                if ($paged == $i){
                    echo '<button class="v10__Pagination-item Button-np54 active">' . $i . '</button>';
                }else {
                    echo '<button class="v10__Pagination-item Button-np54" data-page="' . $i . '">' . $i . '</button>';
                }
            }
            $pagination = ob_get_clean();
            echo json_encode(['status' => true, 'html'=>$output, 'pagination'=>$pagination]);
        }
        elseif($_POST['method'] == 'notification'){
            global $wpdb;
            $db = Db::getLnstance();
            $startIndex = 10*($paged-1);
            $records = NotificationModel::getNotification($startIndex,$user_id);
            ob_start();
            if (!empty($records)){
                foreach ($records as $record){
                    if (empty($record['notification_id'])){
                        ?>
                        <section
                                class="TableRowContainer__normal-Uv6APM py-2 px-4 my-3 d-grid ai-center NotificationCard__tableRow-opMsDI TableRowDesktop-xIiuFo radius-md">
                            <div class="NotificationCard__title-GEjaN6 d-flex flex-row">
                                <div class="d-flex flex-row">
                                    <div class="d-flex ml-5" data-testid="icon-wrapper">
                                        <svg style="width: 24px; height: 24px; fill: var(--color-icon-high-emphasis);">
                                            <use class="disable-events" xlink:href="#notificationBell"></use>
                                        </svg>
                                    </div>
                                </div>
                                <div class="grow-1"></div>
                                <div class="color-n-500 text-body-1 dir-ltr"><?=gjdate($record['created_at'])?></div></div>
                            <div class="d-flex flex-row jc-center"><p class="text-body1-strong color-n-700"><?=esc_html($record['title'])?></p>
                                <div class="grow-1"></div>
                                <button class="relative d-flex ai-center user-select-none btn-wc51H8 text-button-2 btn--text-se4oQM btn--primary-uiqWij radius Button__medium-gIvke_ Button__textPrimary-IWW5Sd AccordionButton--commonClasses-Qnp0XR Button-rn45"
                                        data-testid="button-wrapper" data-id="<?=esc_attr($record['Id'])?>">
                                    <div class="d-flex ai-center jc-center relative grow-1">
                                        <div class="d-flex AccordionButton--expandIcon-P1W7MA"
                                             data-testid="icon-wrapper">
                                            <svg style="width: 24px; height: 24px; fill: var(--color-icon-high-emphasis);">
                                                <use class="disable-events" xlink:href="#expandLess"></use>
                                            </svg>
                                        </div>
                                    </div>
                                </button>
                            </div>
                            <div class="Accordion-bhT9dH Accordion__exit-F8WmEG Accordion__exitActive-HuOwrM">
                                <div>
                                    <div class="text-body-1 color-text-low-emphasis "><?=wp_kses_post($record['body'])?></div>
                                </div>
                            </div>
                        </section>
                        <?php
                    }else{
                        ?>
                        <section
                                class="TableRowContainer__visited-TUSUSu py-2 px-4 my-3 d-grid ai-center NotificationCard__tableRow-opMsDI TableRowDesktop-xIiuFo radius-md">
                            <div class="NotificationCard__title-GEjaN6 d-flex flex-row">
                                <div class="d-flex flex-row">
                                    <div class="d-flex ml-5" data-testid="icon-wrapper">
                                        <svg style="width: 24px; height: 24px; fill: var(--color-icon-high-emphasis);">
                                            <use class="disable-events" xlink:href="#notificationBellRead"></use>
                                        </svg>
                                    </div>
                                </div>
                                <div class="grow-1"></div>
                                <div class="color-n-500 text-body-1 dir-ltr"><?=gjdate($record['created_at'])?></div></div>
                            <div class="d-flex flex-row jc-center"><p class="text-body1-strong color-n-700"><?=esc_html($record['title'])?></p>
                                <div class="grow-1"></div>
                                <button class="relative d-flex ai-center user-select-none btn-wc51H8 text-button-2 btn--text-se4oQM btn--primary-uiqWij radius Button__medium-gIvke_ Button__textPrimary-IWW5Sd AccordionButton--commonClasses-Qnp0XR Button-rn45"
                                        data-testid="button-wrapper">
                                    <div class="d-flex ai-center jc-center relative grow-1">
                                        <div class="d-flex AccordionButton--expandIcon-P1W7MA"
                                             data-testid="icon-wrapper">
                                            <svg style="width: 24px; height: 24px; fill: var(--color-icon-high-emphasis);">
                                                <use class="disable-events" xlink:href="#expandLess"></use>
                                            </svg>
                                        </div>
                                    </div>
                                </button>
                            </div>
                            <div class="Accordion-bhT9dH Accordion__exit-F8WmEG Accordion__exitActive-HuOwrM">
                                <div>
                                    <div class="text-body-1 color-text-low-emphasis "><?=wp_kses_post($record['body'])?></div>
                                </div>
                            </div>
                        </section>
                        <?php

                    }
                }
                $recordsCount = NotificationModel::getTotalNotification($user_id);
                $pageCount = ceil($recordsCount/10);
                echo '<div class="flex justify-end"><div class="v10__Pagination">';
                for ($i = $paged-1; $i <= $paged+1; $i++) {
                    if ($i < 1){
                        continue;
                    }
                    if ($i>$pageCount){continue;}
                    if ($paged == $i){
                        echo '<button class="v10__Pagination-item Button-np51 active">' . $i . '</button>';
                    }else {
                        echo '<button class="v10__Pagination-item Button-np51" data-page="' . $i . '">' . $i . '</button>';
                    }
                }
                echo '</div></div> ';
            }else{
                ?>
                <section class="p-5 TableCard--bodyMobile-tDS3OZ">
                    <div class="d-flex ai-center jc-center align-center w-100 h-100">
                        <div class="py-4 d-flex flex-column jc-center ai-center EmptyState__desktopContainer-ggZkIg">
                            <div class="d-flex jc-center mb-3" data-testid="empty-src">
                                <div data-testid="image-wrapper" style="width: 200px; height: 150px;">
                                    <img class="w-100"
                                         src="<?=get_template_directory_uri()?>/assets/img/ticket_img.png"
                                         width="200"
                                         height="150"
                                         data-testid="image-defaultImage"
                                         style="object-fit: contain;">
                                </div>
                            </div>
                            <div class="text-h5 color-900">نتیجه&zwnj;ای پیدا نکردیم...</div>
                            <div class="text-caption-strong color-500" data-testid="empty-description">
                                <div>فیلترها را تغییر دهید و دوباره امتحان کنید</div>
                            </div>
                        </div>
                    </div>
                </section>
                <?php
            }

            $output = ob_get_clean();
            echo json_encode(['status' => true, 'html'=>$output]);
        }
        elseif($_POST['method'] == 'ticket'){
            $startIndex = ($paged-1)*10;
            if (is_current_user_admin()){
                $records = \Giftmax\model\TicketModel::admin($startIndex);
                if (!empty($records)){
                    $pageCount = \Giftmax\model\TicketModel::pageCount();
                }
            }else {
                $records = \Giftmax\model\TicketModel::user($user_id,$startIndex);
                if (!empty($records)) {
                    $pageCount = \Giftmax\model\TicketModel::pageCount($user_id);
                }
            }
            ob_start();
            if (!empty($records)){
                foreach ($records as $key=>$record){
                    if (is_numeric($record['categoryId'])) {
                        $categorys = \Giftmax\model\TicketModel::category($record['categoryId']);
                    }else{
                        $categoryId = explode('|',decrypt_data($record['categoryId']));
                        $categorys = [['name'=>"سفارش #".$categoryId[0]]];
                    }
                    ?>

                    <section
                            class="TableRowContainer__normal-Uv6APM py-2 px-4 my-3 d-grid TableRowDesktop-xIiuFo rounded-full">
                        <div class="d-grid py-2"
                             style="grid-template-columns: 0.4fr 0.8fr 1.3fr 1.3fr 0.6fr 0.8fr 0.7fr 0.7fr;">
                            <div class="pr-2 pl-2 text-body-1 d-flex ai-center color-text-high-emphasis mt-1 gap-x-2">
                                <div class="pr-2 pl-2 text-body-1 d-flex ai-center color-text-high-emphasis color-text-low-emphasis">
                                    <?=$key+1?>
                                </div>
                            </div>
                            <div class="pr-2 pl-2 text-body-1 d-flex ai-center color-text-high-emphasis">
                                S-<?=$record['ticketId']?>
                            </div>
                            <div class="pr-2 pl-2 text-body-1 d-flex ai-center color-text-high-emphasis">
                                <?=$record['Issue']?>
                            </div>
                            <div class="pr-2 pl-2 text-body-1 d-flex ai-center color-text-high-emphasis">
                                <?=$categorys[0]['name']?>
                            </div>
                            <div class="pr-2 pl-2 text-body-1 d-flex ai-center color-text-high-emphasis">
                                <?=gjdate($record['time'],"Y-m-d")?>
                            </div>
                            <?php $times = \Giftmax\model\TicketModel::time($record['ticketId']) ?>
                            <div class="pr-2 pl-2 text-body-1 d-flex ai-center color-text-high-emphasis">
                                <?=!empty($times[0]['time']) ? gjdate($times[0]['time'],"H:i - Y-m-d") : "-"?>
                            </div>
                            <div class="pr-2 pl-2 text-body-1 d-flex ai-center color-text-high-emphasis">
                                <?php
                                if ($record['condition'] == 0){
                                    $cls = 'Badge__info-st92ed';
                                    $nm = "جدید";
                                }elseif ($record['condition'] == 1){
                                    $cls = 'Badge__info-16f59';
                                    $nm = "درحال بررسی";
                                }elseif ($record['condition'] == 2){
                                    $cls = 'Badge__warning-MfubDgd';
                                    $nm = "در انتظار جزئیات";
                                }elseif ($record['condition'] == 3){
                                    $cls = 'Badge__success-AVxEpg';
                                    $nm = "حل شده";
                                }elseif ($record['condition'] == 4){
                                    $cls = 'Badge__neutral-XFzczo';
                                    $nm = "بسته شده";
                                }
                                ?>
                                <div class="d-inline-flex ai-center <?=$cls?> text-no-wrap Badge-vPRt_1 Badge--medium-SregFw px-3 text-body2-strong"
                                     style="background-color: var(--color-undefined); color: var(--color-undefined);">
                                    <?=$nm?>
                                </div>
                            </div>
                            <div class="pr-2 pl-2 text-body-1 d-flex ai-center color-text-high-emphasis justify-end">
                                <?php $gid = ($record['ticketId']) * 10 / 5?>
                                <a
                                        href="<?=esc_url( get_permalink() )?>id/<?=$gid?>">
                                    <button class="relative d-flex ai-center user-select-none btn-wc51H8 text-button-2 btn--outlined-I96mhk btn--primary-uiqWij rounded-full Button__medium-gIvke_ Button__outlinedPrimary-V1OV6N Button-MNNP44"
                                            data-testid="button-wrapper">
                                        <div class="d-flex ai-center jc-center relative grow-1">مشاهده
                                            تیکت
                                        </div>
                                    </button>
                                </a></div>
                        </div>
                    </section>
                    <?php
                }
                echo '<div class="flex justify-end"><div class="v10__Pagination">';
                for ($i = $paged-1; $i <= $paged+1; $i++) {
                    if ($i < 1){
                        continue;
                    }
                    if ($i>ceil($pageCount[0]['total']/10)){continue;}
                    if ($paged == $i){
                        echo '<button class="v10__Pagination-item Button-np52 active">' . $i . '</button>';
                    }else {
                        echo '<button class="v10__Pagination-item Button-np52" data-page="' . $i . '">' . $i . '</button>';
                    }
                }
                echo '</div></div> ';
            }else{
                ?>
                <section class="p-5 TableCard--bodyMobile-tDS3OZ">
                    <div class="d-flex ai-center jc-center align-center w-100 h-100">
                        <div class="py-4 d-flex flex-column jc-center ai-center EmptyState__desktopContainer-ggZkIg">
                            <div class="d-flex jc-center mb-3" data-testid="empty-src">
                                <div data-testid="image-wrapper" style="width: 200px; height: 150px;"><img class="w-100"
                                                                                                           src="<?=get_template_directory_uri()?>/assets/img/ticket_img.png"
                                                                                                           width="200"
                                                                                                           height="150"
                                                                                                           data-testid="image-defaultImage"
                                                                                                           style="object-fit: contain;">
                                </div>
                            </div>
                            <div class="text-h5 color-900">نتیجه&zwnj;ای پیدا نکردیم...</div>
                            <div class="text-caption-strong color-500" data-testid="empty-description">
                                <div>فیلترها را تغییر دهید و دوباره امتحان کنید</div>
                            </div>
                        </div>
                    </div>
                </section>
            <?php }
            $output = ob_get_clean();
            echo json_encode(['status' => true, 'html'=>$output]);
        }else{
            echo json_encode(['status' => false]);
        }
    }
    public function sendSmsFunction()
    {
        if(!isset($_GET['key']) || $_GET['key'] != 'e2hcxeugdqlkj49ckpzlx76n'){
            echo json_encode(['status' => false]);
            exit();
        }
        $records = SiteModel::querySmsCampaigns();
        foreach ($records as $record) {

            $phones = SiteModel::campaignRecipients($record['id']);
            $failed_count = $sent_count = 0;
            foreach ($phones as $phone) {
                $message = render_message_variables($record['message'], $phone['phone']);
                $result = sendSms($phone['phone'], $message);
                if (is_null($result->data)){
                    $failed_count++;
                    SiteModel::recipientsSetFailed($result->meta->message, $phone['id']);
                }else{
                    $sent_count++;
                    SiteModel::recipientsSetSent($phone['id']);
                }
            }
            SiteModel::dataCampaigns($record['id'], $sent_count, $failed_count);
        }
    }
    /**
     * لود کردن پست ها
     */
    public function postsApiFunction(){
        $category = $_POST['category'];
        ob_start();
        $posts_per_page = 6;
        $orderby        = 'date';
        $order          = 'DESC';
        $args   = [
                'posts_per_page'=> $posts_per_page,
                'orderby'       => $orderby,
                'order'         => $order,
                'no_found_rows' => true,
        ];
        if(!empty( $_POST['category'])){
            $category_slug  = $category;
            $cat_obj = get_category_by_slug( $category_slug );
            $cat_id  = ( $cat_obj ) ? $cat_obj->term_id : 0;
            $args['category'] = $cat_id;
            $linkCat = get_category_link($cat_obj);
            $nameEnCat = giftmax_get_term_english_name($cat_obj);
            $nameCat = $cat_obj->name;
        }else{
            $nameCat = "همه";
            $nameEnCat = "All";
            $linkCat = home_url('/blogs');
        }
        $posts  = get_posts( $args );

        if ( ! empty( $posts ) ) {
            if (!empty($posts[0]->ID) || !empty($posts[1]->ID)){
                $Post_right = array(
                        empty($posts[0]->ID) ? 'no' : $posts[0]->ID,
                        empty($posts[1]->ID) ? 'no' : $posts[1]->ID
                )
                ?>
                <div class="act-blogs-first-box">
                    <?php
                    foreach ($Post_right as $item){
                        if ($item == 'no'){
                            continue;
                        }
                        ?>
                        <div class="act-blog-first-card">
                            <a href="<?=get_permalink($item)?>" class="act-blog-card">
                                <div class="act-blog-card-inner">
                                    <div class="act-blog-card-img-box">
                                        <img decoding="async" src="<?=get_the_post_thumbnail_url($item)?>" alt="">
                                        <span class="act-blog-card-img-box-label"><?=get_the_category($item)[0]->name?></span></div>
                                    <div class="act-blog-card-content">
                                        <h4 class="act-product-title"><?=get_the_title($item)?></h4>
                                        <div class="act-blog-card-text"><?=get_the_excerpt($item)?></div>
                                        <div class="act-blog-card-footer">
                                            <div class="act-blog-card-footer-read-time"><div class="flex align-items-center ml-1"><i class="icon-eye"></i><p><?= view_giftmax($item)?></p></div><div class="flex align-items-center"><i class="icon-user"></i><?=giftmax_get_author_full_name(get_post_author_id($item))?></div><div class="flex align-items-center blog_clock-view"><i class="icon-clock"></i><?=gjdate(get_the_date('Y-m-d',$item),"d M Y")?></div></div>
                                            <div class="act-blog-card-link">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="26" height="26" viewBox="0 0 26 26" fill="currentcolor">
                                                    <path d="M15.0559 8.6175C14.9551 8.71827 14.8173 8.78191 14.6582 8.78191L8.7821 8.78191L8.7821 14.658C8.7821 14.9656 8.52755 15.2201 8.21996 15.2201C7.91236 15.2201 7.6578 14.9656 7.6578 14.658L7.6578 8.21976C7.6578 7.91216 7.91236 7.65761 8.21995 7.65761L14.6582 7.65761C14.9658 7.65761 15.2203 7.91216 15.2203 8.21976C15.2256 8.37355 15.1567 8.51674 15.0559 8.6175Z"></path>
                                                    <path d="M17.6333 17.6332C17.4159 17.8506 17.0553 17.8506 16.8379 17.6332L7.9124 8.7077C7.69496 8.49027 7.69496 8.12964 7.9124 7.91221C8.12983 7.69477 8.49046 7.69477 8.70789 7.91221L17.6333 16.8377C17.8508 17.0551 17.8508 17.4157 17.6333 17.6332Z"></path>
                                                </svg>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <?php
                    }
                    ?>
                </div>
                <?php
            }
            if (!empty($posts[2]->ID)){
                ?>
                <a href="<?=get_permalink($posts[2]->ID)?>" class="act-blog-card fDjf5">
                    <div class="act-blog-card-inner">
                        <div class="act-blog-card-img-box">
                            <img decoding="async" src="<?=get_the_post_thumbnail_url($posts[2]->ID)?>" alt="">
                            <span class="act-blog-card-img-box-label"><?=get_the_category($posts[2]->ID)[0]->name?></span>
                        </div>
                        <div class="act-blog-card-content">
                            <h4 class="act-product-title"><?=get_the_title($posts[2]->ID)?></h4>
                            <div class="act-blog-card-text"><?=get_the_excerpt($posts[2]->ID)?></div>
                        </div>
                        <div class="act-blog-card-footer">
                            <div class="act-blog-card-footer-read-time"><div class="flex align-items-center ml-1"><i class="icon-eye"></i><p><?= view_giftmax($posts[2]->ID)?></p></div><div class="flex align-items-center"><i class="icon-user"></i><?=giftmax_get_author_full_name(get_post_author_id($posts[2]->ID))?></div><div class="flex align-items-center blog_clock-view"><i class="icon-clock"></i><?=gjdate(get_the_date('Y-m-d',$posts[2]->ID),"d M Y")?></div></div>
                            <div class="act-blog-card-link">
                                <svg xmlns="http://www.w3.org/2000/svg" width="26" height="26" viewBox="0 0 26 26" fill="currentcolor">
                                    <path d="M15.0559 8.6175C14.9551 8.71827 14.8173 8.78191 14.6582 8.78191L8.7821 8.78191L8.7821 14.658C8.7821 14.9656 8.52755 15.2201 8.21996 15.2201C7.91236 15.2201 7.6578 14.9656 7.6578 14.658L7.6578 8.21976C7.6578 7.91216 7.91236 7.65761 8.21995 7.65761L14.6582 7.65761C14.9658 7.65761 15.2203 7.91216 15.2203 8.21976C15.2256 8.37355 15.1567 8.51674 15.0559 8.6175Z"></path>
                                    <path d="M17.6333 17.6332C17.4159 17.8506 17.0553 17.8506 16.8379 17.6332L7.9124 8.7077C7.69496 8.49027 7.69496 8.12964 7.9124 7.91221C8.12983 7.69477 8.49046 7.69477 8.70789 7.91221L17.6333 16.8377C17.8508 17.0551 17.8508 17.4157 17.6333 17.6332Z"></path>
                                </svg>

                            </div>
                        </div>
                    </div>
                </a>
                <?php
            }
            if (!empty($posts[3]->ID) || !empty($posts[4]->ID) || !empty($posts[5]->ID)){
                $Post_left = array(
                        empty($posts[3]->ID) ? 'no' : $posts[3]->ID,
                        empty($posts[4]->ID) ? 'no' : $posts[4]->ID,
                        empty($posts[5]->ID) ? 'no' : $posts[5]->ID
                );
                ?>
                <div class="act-blogs-last-box">
                    <?php
                    foreach ($Post_left as $value) {
                        if ($value == 'no'){
                            continue;
                        }
                        ?>
                        <div class="act-blog-last-card">
                            <a href="<?=get_permalink($value)?>" class="act-blog-card">
                                <div class="act-blog-card-inner">
                                    <div class="act-blog-card-img-box">
                                        <img decoding="async" src="<?=get_the_post_thumbnail_url($value)?>" alt="">
                                    </div>
                                    <div class="act-blog-card-content">
                                        <h4 class="act-product-title"><?=get_the_title($value)?></h4>
                                        <div class="act-blog-card-text"><?=get_the_excerpt($value)?></div>
                                        <div class="act-blog-card-footer">
                                            <div class="act-blog-card-footer-read-time"><div class="flex align-items-center ml-1"><i class="icon-eye"></i><p><?= view_giftmax($posts[2]->ID)?></p></div><div class="flex align-items-center"><i class="icon-user"></i><?=giftmax_get_author_full_name(get_post_author_id($posts[2]->ID))?></div><div class="flex align-items-center blog_clock-view"><i class="icon-clock"></i><?=gjdate(get_the_date('Y-m-d',$posts[2]->ID),"d M Y")?></div></div>
                                            <div class="act-blog-card-link">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="26" height="26" viewBox="0 0 26 26" fill="currentcolor">
                                                    <path d="M15.0559 8.6175C14.9551 8.71827 14.8173 8.78191 14.6582 8.78191L8.7821 8.78191L8.7821 14.658C8.7821 14.9656 8.52755 15.2201 8.21996 15.2201C7.91236 15.2201 7.6578 14.9656 7.6578 14.658L7.6578 8.21976C7.6578 7.91216 7.91236 7.65761 8.21995 7.65761L14.6582 7.65761C14.9658 7.65761 15.2203 7.91216 15.2203 8.21976C15.2256 8.37355 15.1567 8.51674 15.0559 8.6175Z"></path>
                                                    <path d="M17.6333 17.6332C17.4159 17.8506 17.0553 17.8506 16.8379 17.6332L7.9124 8.7077C7.69496 8.49027 7.69496 8.12964 7.9124 7.91221C8.12983 7.69477 8.49046 7.69477 8.70789 7.91221L17.6333 16.8377C17.8508 17.0551 17.8508 17.4157 17.6333 17.6332Z"></path>
                                                </svg>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <?php
                    }
                    ?>
                </div>
                <?php
            }
        }else{?>
            <div class=" cart-panel ">
                <div class="flex mx-auto"><span>مقاله در این دسته وجود ندارد!</span></div>
            </div>
            <?php
        }
        $output = ob_get_clean();
        echo json_encode(['html' => $output,'name'=>$nameCat,'name_en'=>$nameEnCat,'link'=>$linkCat]);
    }

    /**
     * ذخیره کردن قیمت مصحولات برای نمودار
     */
    private static function giftmax_maybe_store_daily_price($product_id, $price_value) {
        if (!$product_id) {
            return;
        }

        $price_history = get_post_meta($product_id, '_giftmax_price_history', true);
        if (!is_array($price_history)) {
            $price_history = array();
        }
        $today = current_time('Y-m-d');
        $price_value = (float) $price_value;

        if (!isset($price_history[$today]) || (float) $price_history[$today] !== $price_value) {
            $price_history[$today] = $price_value;
        }

        $cutoff = strtotime('-29 days', current_time('timestamp'));
        foreach ($price_history as $date => $stored_price) {
            $entry_ts = strtotime($date . ' 00:00:00');
            if ($entry_ts === false || $entry_ts < $cutoff) {
                unset($price_history[$date]);
            }
        }

        ksort($price_history);
        update_post_meta($product_id, '_giftmax_price_history', $price_history);
    }
    public function setPriceFunction()
    {
        if(!isset($_GET['key']) || $_GET['key'] != 'e65cwm7cjpye9'){
            echo json_encode(['status' => false]);
            exit();
        }

        $args = array(
                'post_type' => 'product',
                'posts_per_page' => -1,
                'fields' => 'ids',
        );

        $products = get_posts($args);

        foreach ($products as $product_id) {
            $wc_product = wc_get_product($product_id);
            if (!$wc_product) {
                continue;
            }

            $price = $wc_product->get_price();
            if ($price) {
                self::giftmax_maybe_store_daily_price($product_id, $price);
            }
        }
    }
}
