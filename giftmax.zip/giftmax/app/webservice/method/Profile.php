<?php

namespace Giftmax\webservice\method;

use Giftmax\model\SiteModel;
use Giftmax\model\UserModel;
use Giftmax\model\VerifyModel;
use Giftmax\model\WalletModel;
use Giftmax\modules\Db;
use Giftmax\modules\Jibit;
use Giftmax\modules\TicketModel;
use Giftmax\modules\View;

class Profile
{
    public function __construct(){
        add_action( 'rest_api_init',[ $this, 'addApiRoutes' ] );
    }
    public function addApiRoutes(){
        register_rest_route('api/v2', '/wishlist_toggle', array(
            'methods' => 'POST',
            'callback' => [$this, 'wishlist_toggle_api_function'],
            'permission_callback' => function () {
                return is_user_logged_in();
            }
        ));
        register_rest_route('api/v2', '/wishlist_status', array(
            'methods' => 'POST',
            'callback' => [$this, 'wishlistStatusApiFunction'],
            'permission_callback' => function () {
                return is_user_logged_in();
            }
        ));
        register_rest_route('api/v2', '/wishlist_list', array(
            'methods' => 'POST',
            'callback' => [$this, 'wishlistListApiFunction'],
            'permission_callback' => function () {
                return is_user_logged_in();
            }
        ));
        register_rest_route('api/v2', '/points', array(
            'methods' => 'POST',
            'callback' => [$this, 'pointsApiFunction'],
            'permission_callback' => function () {
                return is_user_logged_in();
            }
        ));
        register_rest_route('api/v2', '/download', array(
            'methods' => 'POST',
            'callback' => [$this, 'downloadApiFunction'],
            'permission_callback' => function () {
                return is_user_logged_in();
            }
        ));
        register_rest_route('api/v2', '/RegistryPhone', array(
            'methods' => 'POST',
            'callback' => [$this, 'RegistryPhoneApiFunction'],
            'permission_callback' => function () {
                return is_user_logged_in();
            }
        ));
        register_rest_route('api/v2', '/verify', array(
            'methods' => 'GET',
            'callback' => [$this, 'verifyApiFunction'],
            'permission_callback' => "__return_true"
        ));
        register_rest_route( 'api/v1', '/verify-cart', array(
            'methods' => 'POST',
            'callback' => [$this, 'verifyCartApiFunction'],
            'permission_callback' => function () {
                return is_user_logged_in();
            }
        ));
        /**
         * ticket
         */
        register_rest_route( 'api/v1', '/category', array(
            'methods' => 'POST',
            'callback' => [$this, 'categoryApiFunction'],
            'permission_callback' => function () {
                return is_current_user_admin();
            }
        ) );
        register_rest_route( 'api/v1', '/ticket_category', array(
            'methods' => 'POST',
            'callback' => [$this , 'ticketCategoryApiFunction'],
            'permission_callback' => function () {
                return is_user_logged_in();
            }
        ) );
        register_rest_route( 'api/v1', '/main', array(
            'methods' => 'POST',
            'callback' => [$this, 'mainApiFunction'],
            'permission_callback' => function () {
                return is_current_user_admin();
            }
        ) );
        register_rest_route( 'api/v1', '/ticketing', array(
            'methods' => 'POST',
            'callback' => [$this, 'ticketApiFunction'],
            'permission_callback' => function () {
                return is_user_logged_in();
            }
        ) );
    }
    public function wishlist_toggle_api_function()
    {
        $product_id = isset($_POST['product_id']) ? absint($_POST['product_id']) : 0;
        $user_id = get_current_user_id();
        if ($product_id <= 0 || $user_id <= 0 || get_post_type($product_id) !== 'product' || !is_user_logged_in()) {
            return new \WP_REST_Response([
                'status' => false,
                'message' => 'درخواست نامعتبر است'
            ], 400);
        }

        $exists = UserModel::existsWishlist($user_id, $product_id);

        if (!empty($exists)) {
           UserModel::deleteProductWishlist($user_id, $product_id);
            $in_wishlist = false;
            $message = 'از علاقه‌مندی‌ها حذف شد';
        } else {
            UserModel::insertWishlist($user_id, $product_id);
            $in_wishlist = true;
            $message = 'به علاقه‌مندی‌ها اضافه شد';
        }
        return new \WP_REST_Response([
            'status' => true,
            'in_wishlist' => $in_wishlist,
            'message' => $message
        ], 200);
    }
    public function wishlistStatusApiFunction()
    {
        $product_id = isset($_POST['product_id']) ? absint($_POST['product_id']) : 0;
        $user_id = get_current_user_id();
        if ($product_id <= 0 || $user_id <= 0 || get_post_type($product_id) !== 'product') {
            return new \WP_REST_Response([
                'status' => false,
                'message' => 'درخواست نامعتبر است'
            ], 400);
        }
        $exists = UserModel::existsWishlist($user_id, $product_id);
        $count = UserModel::countWishlist($user_id);

        return new \WP_REST_Response([
            'status' => true,
            'in_wishlist' => !empty($exists),
            'count' => !empty($count) ? (int)$count['total'] : 0
        ], 200);
    }
    public function wishlistListApiFunction()
    {
        $user_id = get_current_user_id();
        if ($user_id <= 0) {
            return new \WP_REST_Response([
                'status' => false,
                'message' => 'درخواست نامعتبر است'
            ], 400);
        }

        $rows = UserModel::listWishlist($user_id);
        $product_ids = array();
        if (!empty($rows)) {
            foreach ($rows as $row) {
                $product_ids[] = (int)$row['product_id'];
            }
        }

        return new \WP_REST_Response([
            'status' => true,
            'product_ids' => $product_ids
        ], 200);
    }
    private function loyaltyPointsToToman(int $totalPoints, int $pointsPerUnit = 100, int $moneyPerUnit = 10000): array
    {
        $convertiblePoints = intdiv($totalPoints, $pointsPerUnit) * $pointsPerUnit;

        $money = ($convertiblePoints / $pointsPerUnit) * $moneyPerUnit;
        $remainingPoints = $totalPoints - $convertiblePoints;

        return [
            'convertedPoints' => $convertiblePoints,
            'money' => $money,
            'remainingPoints' => $remainingPoints,
        ];
    }
    public function pointsApiFunction(){
        $points = UserModel::points();
        $records = SiteModel::setting('stp');
        if (empty($records)) {
            echo json_encode([
                'status' => false,
                'message' => 'تنظیمات ست نشده',
            ]);
            exit();
        }
        $record = json_decode($records['meta_value'], true);

        $res = self::loyaltyPointsToToman($points, $record[0]['points'], $record[0]['toman']);
        $user_id = get_current_user_id();
        $wallet = WalletModel::getWallet($user_id);
        $upoints = WalletModel::getPoints($user_id);
        if ($res['convertedPoints'] > 0) {
            WalletModel::insertTransactions($user_id,$upoints['id'],(float)($res['convertedPoints']),'تبدیل امتیاز به اعتبار','points','debit');
            WalletModel::insertTransactions($user_id,$wallet['id'],(float)($res['money']),'افزایش موجودی','wallet','credit');
            WalletModel::updateBalance($wallet['id'],(float)($res['money']) + $wallet['balance']);
            WalletModel::updatePoint($upoints['id'],$res['remainingPoints']);
            echo json_encode([
                'status' => true,
                'message' => 'تبدیل امتیاز انجام شد',
                'points' => number_format($res['remainingPoints']),
                'balance' => number_format((float)($res['money']) + $wallet['balance']),
            ]);
        } else {
            echo json_encode([
                'status' => false,
                'message' => 'موجودی کافی نمیباشد',
            ]);
        }
    }
    public function downloadApiFunction()
    {
        if (!isset($_POST['hash'])) {
            echo json_encode(['status' => false, 'message' => 'اطلاعات ناقص هست']);
            exit();
        }
        $hash = decrypt_data($_POST['hash']);
        $data = explode('|', $hash);
        $licence = \Giftmax\Modules\LicenseManager::ShowLicense($data[1], $data[2]);
        if (!empty($licence) && !is_null($licence['file_id']) && $data[0] === $licence['file_id']) {
            $file = SiteModel::table('product_licences_file', 'file_id', $licence['file_id']);
            if (filter_var($file['url'], FILTER_VALIDATE_URL)) {
                $file = str_replace(
                    site_url('/'),
                    ABSPATH,
                    $file['url']
                );
            } else {
                $file = $file['url'];
            }

            header('Content-Type: application/octet-stream');
            header('Content-Disposition: attachment; filename="' . basename($file) . '"');
            header('Content-Length: ' . filesize($file));
            readfile($file);

            exit;
        } else {
            echo json_encode(['status' => false, 'message' => 'دسترسی دانلود ندارید']);
            exit();
        }
    }

    public function RegistryPhoneApiFunction()
    {
        if (!isset($_POST['phoneNumber']) && !isset($_POST['cartNumber']) && !isset($_POST['day']) && !isset($_POST['month']) && !isset($_POST['year']) && !isset($_POST['nationalCode'])) {
            echo json_encode(["status" => false, "message" => "اطلاعات ناقص است", "close" => true]);
            exit;
        }
        $phoneNumber = $_POST['phoneNumber'];
        $cartNumber = decrypt_data($_POST['cartNumber']);
        $day = $_POST['day'];
        $month = $_POST['month'];
        $year = $_POST['year'];
        $nationalCode = $_POST['nationalCode'];
        $firstName = $_POST['firstName'];
        $lastName = $_POST['lastName'];
        if (!validateIranianMobile($phoneNumber)) {
            echo json_encode(["status" => false, "percent" => 50, "message" => "شماره تلفن معتبر نیست"]);
            exit;
        } elseif (!preg_match('/^(0?[1-9]|[12][0-9]|3[01])$/', $day) || !preg_match('/^(0?[1-9]|1[0-2])$/', $month) || !preg_match('/^[0-9]{4}$/', $year)) {
            echo json_encode(["status" => false, "percent" => 50, "message" => "تاریخ تولد معتبر نیست"]);
            exit;
        } elseif (empty($firstName)) {
            echo json_encode(["status" => false, "percent" => 50, "message" => "نام وارد نشده است"]);
            exit;
        } elseif (empty($lastName)) {
            echo json_encode(["status" => false, "percent" => 50, "message" => "نام خانوادگی وارد نشده است"]);
            exit;
        } elseif (!preg_match('/^[0-9]{10}$/', $nationalCode)) {
            echo json_encode(["status" => false, "percent" => 50, "message" => "کدملی معتبر نیست"]);
            exit;
        } elseif (!isCardNumberValid($cartNumber)) {
            echo json_encode(["status" => false, "percent" => 50, "message" => "کارت معتبر نیست", "close" => true]);
            exit;
        }
        $token = 'd5497c98fc9a28300406dd8ee66bac5b531fc598';
        $birthDate = $year . '/' . $month . '/' . $day;
        $jbt = Jibit::getLnstance();
        if (SiteModel::setting("shahkar_zohal") === true) {
            $result = User::callZohalService(
                'https://service.zohal.io/api/v0/services/inquiry/shahkar',
                [
                    'mobile' => $phoneNumber,
                    'national_code' => $nationalCode
                ],
                $token
            );

            if ($result['status'] !== true) {
                return new \WP_REST_Response([
                    'status' => false,
                    $result,
                    "percent" => 50
                ], 200);
            }
        } elseif (SiteModel::setting("shahkar_jibit") === true) {
            $endpoint = '/services/matching';
            $res = $jbt->api_request('GET', $endpoint, [
                'mobileNumber' => $phoneNumber,
                'nationalCode' => $nationalCode
            ], null, true);
            if ($res['code'] !== 200) {
                return new \WP_REST_Response([
                    'status' => false,
                    'message' => $res['body']['message'],
                    "percent" => 50
                ], 200);
            }
        }
        if (SiteModel::setting("check_card_with_national_code_zohal") === true) {
            $result = User::callZohalService(
                'https://service.zohal.io/api/v0/services/inquiry/check_card_with_national_code',
                [
                    'birth_date' => $birthDate,
                    'card_number' => $cartNumber,
                    'national_code' => $nationalCode
                ],
                $token
            );

            if ($result['status'] !== true) {
                return new \WP_REST_Response([
                    'status' => false,
                    $result,
                    "percent" => 75
                ], 200);
            }
        } elseif (SiteModel::setting("check_card_with_national_code_jibit") === true) {
            $endpoint = '/services/matching';
            $res = $jbt->api_request('GET', $endpoint, [
                'cardNumber' => $cartNumber,
                'nationalCode' => $nationalCode,
                'birthDate' => $year . $month . $day
            ], null, true);
            if ($res['code'] !== 200) {
                return new \WP_REST_Response([
                    'status' => false,
                    'message' => $res['body']['message'],
                    "percent" => 75
                ], 200);
            }
        }
        $user_id = get_current_user_id();
        $records = SiteModel::table('user_bank_cards', 'card_number_enc', encrypt_data($cartNumber), 'is_active', 0, 1);
        $hash = generateHash();
        if (!empty($records)) {
            VerifyModel::DeleteCardBank($records['id']);
        }
        VerifyModel::InsertCardBank($user_id, $cartNumber, $firstName,$lastName,$phoneNumber,$birthDate,$nationalCode,$hash);
        $otp = mt_rand(100000, 999999);
        $expiry = date("Y-m-d H:i:s", strtotime("+2 minutes"));
        UserModel::expiryEnd();
        $records = UserModel::exitOtp($phoneNumber);
        if (!empty($records) && strtotime($records['otp_expiry']) < time()) {
            UserModel::otpDelete($records['id']);
        }
        if (empty($records)) {
            UserModel::otp($phoneNumber, $otp, $expiry);
        }
        if (\Giftmax\model\SiteModel::setting("otpAudio") === true) {
            $url = "https://portal.avanak.ir/rest/SendOTP";
            $url = $url . "?" . "Token=" . urlencode("1ACAAF7BC85B6AB3B54E5381A72EDCDC67D7BF06");
            $url = $url . "&" . "Length=6";
            $url = $url . "&" . "Number=" . $phoneNumber;
            $url = $url . "&" . "OptionalCode=" . $otp;

            $json = file_get_contents($url);
            if ($json->ErrorCode == 0) {
                echo json_encode(["status" => true, "percent" => 90, 'drg' => encrypt_data($hash)]);
            } else {
                echo json_encode(["status" => false, "message" => "خطایی پیش آمده", "percent" => 0]);
            }
        } elseif (\Giftmax\model\SiteModel::setting("otpSms") === true) {
            $baseUrl = "https://edge.ippanel.com/v1/api/send";
            $token = "wns0sWEioLyJejB0g0olFj-PVlL2Yt5O2G94prP-BXg=";
            $data = [
                "sending_type" => "pattern",
                "from_number" => "+983000505",
                "code" => "xpvkq2fmvzmqvr6",
                "recipients" => [$phoneNumber],
                "params" => [
                    "otp" => $otp,
                    "otp_link" => $otp,
                ],
            ];

            $ch = curl_init($baseUrl);
            curl_setopt($ch, CURLOPT_HTTPHEADER, [
                "Content-Type: application/json; charset=utf-8",
                "Content-Type: application/json",
                "Authorization: $token"
            ]);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data, JSON_UNESCAPED_UNICODE));

            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);
            echo json_encode(["status" => true, "percent" => 90, 'drg' => encrypt_data($hash)]);
        }
    }
    private function postToZibal($path, $parameters)
    {
        $url = 'https://gateway.zibal.ir/v1/' . $path;

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($parameters));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        $response = curl_exec($ch);
        curl_close($ch);

        return json_decode($response);
    }
    public function verifyApiFunction($request)
    {
        $trackId = $request->get_param('trackId');
        $success = $request->get_param('success');
        $hash = $request->get_param('hash');
        if (!$trackId || !$hash) {
            header('Location:' . home_url());
            exit;
        }
        if ((int)$success !== 1) {
            $time = date('Y-m-d H:i:s');
            WalletModel::updateWalletPayments($time, 0, $hash);
            header('Content-Type: text/html; charset=utf-8');
            View::render("/inc/templates/template-parts/payment/fail.php");
            exit;
        }
        $zibal = get_option('woocommerce_zibal_settings');
        $apiKey = $zibal['api_key'];
        $response = $this->postToZibal('verify', [
            'merchant' => $apiKey,
            'trackId' => $trackId,
        ]);
        if ($response && $response->result == 100) {
            $time = date('Y-m-d H:i:s');
            WalletModel::updateWalletPayments($time, 1, $hash);
            $records = WalletModel::getWalletPayments($hash);
            $wallet = WalletModel::getWalletUser($records['user_id']);
            WalletModel::insertTransactions($records['user_id'],$records['id'],(float)($records['amount']) / 10,'افزایش موجودی','wallet','credit');
            WalletModel::updateBalance($wallet['id'],(float)($records['amount'] / 10) + $wallet['balance']);
            header('Content-Type: text/html; charset=utf-8');
            header("Refresh: 3; url=" . home_url('/profile/wallet'));
            View::render("/inc/templates/template-parts/payment/success.php", ['gateway' => 'زیبال', 'paid_date_fa' => $time]);
            exit;
        } elseif ($response && $response->result == 201) {
            header('Content-Type: text/html; charset=utf-8');
            header("Refresh: 3; url=" . home_url('/profile/wallet'));
            View::render("/inc/templates/template-parts/payment/verifed.php", ['gateway' => 'زیبال']);
            exit;
        }
    }
    public function verifyCartApiFunction(){
        if (!isset($_POST['id'])){
            echo json_encode([
                'status'=>false,
                'message' => 'ورودی ارسال نشده'
            ]);
            exit();
        }
        $id = $_POST['id'];
        $order = wc_get_order( decrypt_id($id) );
        if (!$order){
            echo json_encode([
                'status'=>false,
                'message' => 'سفارش یافت نشد'
            ]);
            exit();
        }
        $user_id = get_current_user_id();
        if ($order->get_user_id() != $user_id){
            echo json_encode([
                'status'=>false,
                'message' => 'سفارش یافت نشد',
            ]);
            exit();
        }
        $cardPay = $order->get_meta( '_card_pay', true );
        $card = SiteModel::table('user_bank_cards', 'card_number_enc', encrypt_data($cardPay),"user_id",$user_id);
        if (!empty($card)) {
            $phoneNumber = decrypt_data($card['phone']);
            $otp = mt_rand(100000, 999999);
            $expiry = date("Y-m-d H:i:s", strtotime("+2 minutes"));
            UserModel::expiryEnd();
            $records = UserModel::exitOtp($phoneNumber);
            if (!empty($records) && strtotime($records['otp_expiry']) < time()) {
                UserModel::otpDelete($records['id']);
            }
            if (empty($records)) {
                UserModel::otp($phoneNumber, $otp, $expiry);
            }
            $url = "https://portal.avanak.ir/rest/SendOTP";
            $url = $url . "?" . "Token=" . urlencode("1ACAAF7BC85B6AB3B54E5381A72EDCDC67D7BF06");
            $url = $url . "&" . "Length=6";
            $url = $url . "&" . "Number=" . $phoneNumber;
            $url = $url . "&" . "OptionalCode=" . $otp;

            $json = file_get_contents($url);
            if ($json->ErrorCode == 0) {
                $output = ["status" => true, "percent" => 90];
            } else {
                $output = ["status" => false, "message" => " خطایی پیش آمد در ارسال OTP", "percent" => 0];
            }
            $output['chl'] = 1;
            $output['html'] = '<div class="Hint--primary-mwFS2H Hint__padding-nRd4K4 radius Hint__iconStart-bpg5ZO mb-3" data-testid="hint-wrapper"><div class="d-flex ai-center"><div class="d-flex Hint__titleSlot-yPP6H0" data-testid="icon-wrapper"><svg style="width: 24px; height: 24px; fill: #1ab1d4;"><path d="M2 12c0 5.523 4.477 10 10 10s10-4.477 10-10c0-5.523-4.477-10-10-10s-10 4.477-10 10zM12 7c0.552 0 1 0.448 1 1s-0.448 1-1 1c-0.552 0-1-0.448-1-1s0.448-1 1-1zM10 10h3v7h-2v-5h-1v-2z"></path></svg></div><span class="mr-2 text-body-1 color-brand-primary-700 Hint__padding--title-AHG0eM">کد تأیید شما به شماره &lrm;'.$phoneNumber.'&rlm; ارسال گردید. خواهشمندیم برای تکمیل مراحل، آن را در محل تعیین&zwnj;شده وارد فرمایید. </span></div></div><p class="mb-2 color-n-700 text-body-1 mb-2" data-testid="form-label">کد otp را وارد کنید</p><div class="_wrap_87tyg_1 _input_pjp0p_66"> <input type="text" class="_input_87tyg_11" data-method="order" name="otp" inputmode="numeric"> <div class="_digit_87tyg_33"><span></span></div> <div class="_digit_87tyg_33"><span></span></div> <div class="_digit_87tyg_33"><span></span></div> <div class="_digit_87tyg_33"><span></span></div> <div class="_digit_87tyg_33"><span></span></div> <div class="_digit_87tyg_33"><span></span></div> </div><input class="hidden" type="hidden" name="hash" value="'.encrypt_data($id."||".'otp').'">';
            echo json_encode($output);
        }else{
            $output = ["status" => true, "percent" => 50];
            $output['html'] = '<div class="Hint--primary-mwFS2H Hint__padding-nRd4K4 radius Hint__iconStart-bpg5ZO mb-3" data-testid="hint-wrapper"><div class="d-flex ai-center"><div class="d-flex Hint__titleSlot-yPP6H0" data-testid="icon-wrapper"><svg style="width: 24px; height: 24px; fill: #1ab1d4;"><path d="M2 12c0 5.523 4.477 10 10 10s10-4.477 10-10c0-5.523-4.477-10-10-10s-10 4.477-10 10zM12 7c0.552 0 1 0.448 1 1s-0.448 1-1 1c-0.552 0-1-0.448-1-1s0.448-1 1-1zM10 10h3v7h-2v-5h-1v-2z"></path></svg></div><span class="mr-2 text-body-1 color-brand-primary-700 Hint__padding--title-AHG0eM">برای تکمیل مراحل لطفا شماره تلفن،کدملی و تاریخ تولد متعلق به صاحب کارت به شماره <p class="inline-block">' . rtrim(chunk_split($cardPay, 4, '-'), '-') . '</p> را وارد کنید</span></div></div><div class="d-flex flex-column gap-y-5"><div class="d-flex"> <div class="lg:w-50"> <label class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--L7bcQ uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--normal--A6Ntt w-full"> <p class="text-body-1 color-n-700 mb-2 text-right" data-testid="form-label">نام</p> <div class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame__input-container--D5edN px-2 d-flex ai-center"> <section class="grow-1 text-body-2-c"><input class="px-2 eFydYiN7dQ1Ds63mli7f text-subtitle w-100 jDSbpqUrUZFv23opBao9 color-n-700" type="text" name="firstName" placeholder="" value=""></section> </div> </label> </div> <div class="lg:w-50 mr-3"> <label class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--L7bcQ uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--normal--A6Ntt w-full"> <p class="text-body-1 color-n-700 mb-2 text-right" data-testid="form-label">نام خانوادکی</p> <div class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame__input-container--D5edN px-2 d-flex ai-center"> <section class="grow-1 text-body-2-c"><input class="px-2 eFydYiN7dQ1Ds63mli7f text-subtitle w-100 jDSbpqUrUZFv23opBao9 color-n-700" type="text" name="lastName" placeholder="" value=""></section> </div> </label> </div> </div><label class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--L7bcQ uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--normal--A6Ntt text-body-1 color-n-700 w-100"><p class="mb-2 color-n-700 text-body-1 mb-2" data-testid="form-label">شماره همراه</p><div class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame__input-container--D5edN px-2 d-flex ai-center"><section class="grow-1 text-body-2-c"><input class="px-2 TextField__input-_5fbdd text-subtitle w-100 TextField-e58168" type="text" name="phone-number"></section></div></label><di> <div class="diexjw5" data-select2-id="select2-data-9-k644"> <div class="form-group col-sm-12" data-select2-id="select2-data-8-0exr"> <p class="text-body-1 color-n-700 mb-2 text-right" data-testid="form-label">تاریخ تولد</p> <div class="row g-2 xs:mt-1"> <div class="col-4"> <div class="form-group"> <select class="js-example-basic-single select2-hidden-accessible" name="year" id="year" data-select2-id="select2-data-year" tabindex="-1" aria-hidden="true"> <option value="" disabled="" selected="" data-select2-id="select2-data-2-dxoo"> سال </option> <option value="1320">1320</option> <option value="1321">1321</option> <option value="1322">1322</option> <option value="1323">1323</option> <option value="1324">1324</option> <option value="1325">1325</option> <option value="1326">1326</option> <option value="1327">1327</option> <option value="1328">1328</option> <option value="1329">1329</option> <option value="1330">1330</option> <option value="1331">1331</option> <option value="1332">1332</option> <option value="1333">1333</option> <option value="1334">1334</option> <option value="1335">1335</option> <option value="1336">1336</option> <option value="1337">1337</option> <option value="1338">1338</option> <option value="1339">1339</option> <option value="1340">1340</option> <option value="1341">1341</option> <option value="1342">1342</option> <option value="1343">1343</option> <option value="1344">1344</option> <option value="1345">1345</option> <option value="1346">1346</option> <option value="1347">1347</option> <option value="1348">1348</option> <option value="1349">1349</option> <option value="1350">1350</option> <option value="1351">1351</option> <option value="1352">1352</option> <option value="1353">1353</option> <option value="1354">1354</option> <option value="1355">1355</option> <option value="1356">1356</option> <option value="1357">1357</option> <option value="1358">1358</option> <option value="1359">1359</option> <option value="1360">1360</option> <option value="1361">1361</option> <option value="1362">1362</option> <option value="1363">1363</option> <option value="1364">1364</option> <option value="1365">1365</option> <option value="1366">1366</option> <option value="1367">1367</option> <option value="1368">1368</option> <option value="1369">1369</option> <option value="1370">1370</option> <option value="1371">1371</option> <option value="1372">1372</option> <option value="1373">1373</option> <option value="1374">1374</option> <option value="1375">1375</option> <option value="1376">1376</option> <option value="1377">1377</option> <option value="1378">1378</option> <option value="1379">1379</option> <option value="1380">1380</option> <option value="1381">1381</option> <option value="1382">1382</option> <option value="1383">1383</option> <option value="1384">1384</option> <option value="1385">1385</option> <option value="1386">1386</option> <option value="1387">1387</option> </select> </div> </div> <div class="col-4"> <div class="form-group"> <select class="js-example-basic-single select2-hidden-accessible" name="month" id="month" data-select2-id="select2-data-month" tabindex="-1" aria-hidden="true"> <option value="" disabled="" selected="" data-select2-id="select2-data-4-s9eo"> ماه </option> <option value="01" data-select2-id="select2-data-15-h89y">فروردین</option><option value="02" data-select2-id="select2-data-16-8m35">اردیبهشت</option><option value="03" data-select2-id="select2-data-17-nepr">خرداد</option><option value="04" data-select2-id="select2-data-18-pzth">تیر</option><option value="05" data-select2-id="select2-data-19-ntlh">مرداد</option><option value="06" data-select2-id="select2-data-20-9qy8">شهریور</option><option value="07" data-select2-id="select2-data-21-hu81">مهر</option><option value="08" data-select2-id="select2-data-22-hvit">آبان</option><option value="09" data-select2-id="select2-data-23-xi7i">آذر</option><option value="10" data-select2-id="select2-data-24-bozm">دی</option><option value="11" data-select2-id="select2-data-25-dud8">بهمن</option><option value="12" data-select2-id="select2-data-26-zmw3">اسفند</option>                                            </select> </div> </div> <div class="col-4"> <div class="form-group"> <select class="js-example-basic-single select2-hidden-accessible" name="day" id="day" data-select2-id="select2-data-day" tabindex="-1" aria-hidden="true"> <option value="" disabled="" selected="" data-select2-id="select2-data-6-vgsy"> روز </option> <option value="01">01</option> <option value="02">02</option> <option value="03">03</option> <option value="04">04</option> <option value="05">05</option> <option value="06">06</option> <option value="07">07</option> <option value="08">08</option> <option value="09">09</option> <option value="10">10</option> <option value="11">11</option> <option value="12">12</option> <option value="13">13</option> <option value="14">14</option> <option value="15">15</option> <option value="16">16</option> <option value="17">17</option> <option value="18">18</option> <option value="19">19</option> <option value="20">20</option> <option value="21">21</option> <option value="22">22</option> <option value="23">23</option> <option value="24">24</option> <option value="25">25</option> <option value="26">26</option> <option value="27">27</option> <option value="28">28</option> <option value="29">29</option> <option value="30">30</option> <option value="31">31</option> </select> </div> </div> </div> </div> </div>            </di><label class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--L7bcQ uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--normal--A6Ntt lg:w-30 text-body-1 color-n-700 w-100"> <p class="mb-2 color-n-700 text-body-1 mb-2" data-testid="form-label">کدملی</p> <div class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame__input-container--D5edN px-2 d-flex ai-center"> <section class="grow-1 text-body-2-c"><input class="px-2 TextField__input-_5fbdd text-subtitle w-100 TextField-e58168" type="text" name="national-code"></section> </div> </label></div><input class="hidden" type="hidden" name="hash" value="'.encrypt_data($id."||".'register').'">';
            echo json_encode($output);
        }
    }
    public function categoryApiFunction() {
        $name = $_POST['title'];
        $main = $_POST['main'];

        $records = TicketModel::exist($name);
        if (empty($records)) {
            TicketModel::insert($name,$main);
            $status = 'ok';
        }else{
            $status = 'no';
        }
        $response = array('status' => $status);
        return new \WP_REST_Response($response);
    }
    public function ticketCategoryApiFunction() {
        if(empty($_POST['method'])) {
            $records = \Giftmax\model\TicketModel::keyword($_POST['keyword']);
        } elseif ($_POST['method'] == "add") {
            if (!isset($_POST['parent_id'])) {
                $records = \Giftmax\model\TicketModel::mainCategory();
            } else {
                $records = \Giftmax\model\TicketModel::subset($_POST['parent_id']);
            }
        }
        $out = ['status' => true];
        $allCategories = \Giftmax\model\TicketModel::allCategory();
        $categoriesMap = [];
        foreach ($allCategories as $cat) {
            $categoriesMap[$cat['categoryId']] = [
                'id' => $cat['categoryId'],
                'name' => $cat['name'],
                'subset_id' => $cat['subset'] // parent id
            ];
        }

        // 3️⃣ تابع بازگشتی برای ساخت زیرمجموعه‌ها
        $buildTree = function($parentId) use (&$categoriesMap, &$buildTree) {
            $children = [];
            foreach ($categoriesMap as $cat) {
                if ($cat['subset_id'] == $parentId) {
                    $children[] = [
                        'id' => $cat['id'],
                        'name' => $cat['name'],
                        'subset' => $buildTree($cat['id']) // بازگشت برای زیرمجموعه‌های عمیق‌تر
                    ];
                }
            }
            return $children;
        };
        foreach ($records as $record) {
            $categoryId = $record['categoryId'];
            $out['raw'][] = [
                'id' => $categoryId,
                'name' => $record['name'],
                'subset' => $buildTree($categoryId)
            ];
        }
        $user_id = get_current_user_id();
        $args = [
            'customer_id' => $user_id,
            'limit'       => -1,
            'orderby'     => 'date',
            'order'       => 'DESC',
        ];
        $orders = wc_get_orders($args);
        if ($orders) {
            $subsetOrder = [];
            foreach ($orders as $order){
                $orderId= $order->get_id();
                $subsetOrder[] = ['id'=>encrypt_data("$orderId|order"),'name'=>"#$orderId"];
            }
            $out['raw'][] = [
                'id' => count($out['raw']),
                'name' => "سفارش ها",
                'subset' => $subsetOrder
            ];
        }
        echo json_encode($out);
    }
    public function mainApiFunction() {
        if (isset($_POST['q'])) {
            $key = $_POST['q'];
            $data = array();
            $data['records'] = UserModel::search($key);
            $output = View::re("/inc/templates/template-parts/ticket/search.php",$data);
            $response = array('html' => $output);
        }else{
            $response = array('html' => '');
        }
        return new \WP_REST_Response($response);
    }
    public function ticketApiFunction(){
        if($_POST['method']=="insert") {
            $user = wp_get_current_user();
            $title = sanitize_text_field($_POST['title']); // Sanitize input
            $description = sanitize_textarea_field($_POST['description']); // Sanitize input

            if (isset($_POST['images']['images'])) {
                $images_data = implode('|', $_POST['images']['images']);
            }else{
                $images_data = null;
            }

            $condition = 0;

            if (isset($_POST['condition']) && $_POST['condition'] !== '') {
                $condition = (int) $_POST['condition'];
            }
            \Giftmax\model\TicketModel::insert($_POST['gid'],$user->ID,$title,$description,$images_data,$condition);
            $output = '<section class="d-flex ai-center mt-6 mb-3"><h1 class="text-h5 color-text-heading">ثبت درخواست پشتیبانی</h1><span class="color-text-heading text-h5 mx-1">|</span><p class="text-body-2 color-text-low-emphasis">اینجا می&zwnj;توانید درخواست پشتیبانی ثبت کنید</p></section><div class="bg-white my-3 shadow-2 d-flex flex-column ai-center py-9 px-5 align-center radius-large "><div data-testid="image-wrapper" style="width: 124px; height: 124px;"><img class="w-100" src="' . get_template_directory_uri() . '/assets/img/SLPromotionThanks.85c696de.png" width="124" height="124" data-testid="image-defaultImage" style="object-fit: cover;"></div><p class="text-h4 color-brand-primary-500 mt-9">درخواست پشتیبانی ثبت شد</p><p class="text-subtitle color-n-700 mt-2">همکاران ما در اولین فرصت درخواست شما را بررسی می‌کنند</p><a class="profile_hidden" href="'.home_url("/ticket").'"><button class="relative d-flex ai-center user-select-none btn-wc51H8 text-button-1 btn--large-Gj4EdP btn--primary-uiqWij btn--wide-fdCqpO radius Button__large-Zq9sTh Button__filledPrimary-OvgwGb Final__btn-PVa26x Button-MNNP44" data-testid="button-wrapper"><div class="d-flex ai-center jc-center relative grow-1">برگشت به صفحه اصلی</div></button></a></div><div></div>';

        }
        elseif ($_POST['method']=='tis') {
            $user = wp_get_current_user();
            $description = sanitize_textarea_field($_POST['body']); // Sanitize input

            if (isset($_POST['images']['images'])) {
                $images_data = implode('|', $_POST['images']['images']);
            }else{
                $images_data = null;
            }
            \Giftmax\model\TicketModel::insertRep($_POST['gid'] * 5 /10,$user->ID,$description,$images_data);
            if ($_POST['select'] && current_user_can('administrator')) {
                \Giftmax\model\TicketModel::setCondition($_POST['select'],$_POST['gid'] * 5 / 10);
                $r = \Giftmax\model\TicketModel::getTicket($_POST['gid'] * 5 /10);
                $phone = get_userdata($r['userId'])->user_login;
                $baseUrl = "https://edge.ippanel.com/v1/api/send";
                $token = "wns0sWEioLyJejB0g0olFj-PVlL2Yt5O2G94prP-BXg=";

                $data = [
                    "sending_type" => "pattern",
                    "from_number" => "+985000125475",
                    "code" => "mpxulblzdnzmt8a",
                    "recipients" => [$phone],
                    "params" => [
                        "id" => $_POST['gid'],
                        "link" => home_url('/ticket/id/' . $_POST['gid']),
                    ],
                ];

                $ch = curl_init($baseUrl);
                curl_setopt($ch, CURLOPT_HTTPHEADER, [
                    "Content-Type: application/json; charset=utf-8",
                    "Content-Type: application/json",
                    "Authorization: $token"
                ]);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                curl_setopt($ch, CURLOPT_POST, true);
                curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data, JSON_UNESCAPED_UNICODE));

                $response = curl_exec($ch);
                $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
                curl_close($ch);
            }
            set_query_var('id', $_POST['gid']);

            $user_id = get_current_user_id();


            $user = get_userdata( $user_id );

            if ( in_array( 'administrator', (array) $user->roles ) ) {
                $output = View::re("/inc/templates/template-parts/ticket/index_ticket_admin.php");

            }else{
                $output = View::re("/inc/templates/template-parts/ticket/index_ticket.php");
            }


        }
        else{
            $id = $_POST['gid'];
            if (is_numeric($id)) {
                $data = array();
                $records = \Giftmax\model\TicketModel::category($id);
                if (!empty($records[0]['subset'])) {
                    $subsets = \Giftmax\model\TicketModel::category($records[0]['subset']);
                    $data['subset'] = $subsets[0]['name'];
                }
                $data['object'] = $records[0]['name'];
                $data['id'] = $id;
            }else{
                $order_id = explode('|',decrypt_data($id))[0];
                if (is_numeric($order_id)) {
                    $order = wc_get_order($order_id);
                    $current_user_id = get_current_user_id();

                    if ($order) {
                        $order_user_id = $order->get_user_id();
                        $valid_statuses = ['completed', 'card-not-verified'];
                        $is_available = in_array($order->get_status(), $valid_statuses);
                        if ($order_user_id == $current_user_id && $is_available) {
                            $data['subset'] = "سفارش ها";
                            $data['object'] = "سفارش #" . $order_id;
                            $data['id'] = $id;
                        }else{
                            echo json_encode(['status'=>false,'message'=>"خطایی پیش آمده","close"=>true]);
                            exit();
                        }
                    }else{
                        echo json_encode(['status'=>false,'message'=>"خطایی پیش آمده","close"=>true]);
                        exit();
                    }
                }else{
                    echo json_encode(['status'=>false,'message'=>"خطایی پیش آمده","close"=>true]);
                    exit();
                }
            }
            $output = View::re("/inc/templates/template-parts/ticket/insert.php", $data);
        }
        $response = array('html' => $output);
        return new \WP_REST_Response($response);
    }

}