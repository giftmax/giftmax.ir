<?php

namespace Giftmax\webservice\method;

use Giftmax\model\SiteModel;
use Giftmax\model\UserModel;
use Giftmax\model\VerifyModel;
use Giftmax\modules\View;

class VerifyUser
{
    public function __construct(){
        add_action( 'rest_api_init',[ $this, 'addApiRoutes' ] );
    }
    public function addApiRoutes(){
        register_rest_route('api/v2', '/document-info', array(
            'methods' => 'POST',
            'callback' => [$this, 'documentInfoApiFunction'],
            'permission_callback' => function () {
                return is_user_logged_in();
            }
        ));
        register_rest_route('api/v2', '/landline-phone', array(
            'methods' => 'POST',
            'callback' => [$this, 'landlinePhoneApiFunction'],
            'permission_callback' => function () {
                return is_user_logged_in();
            }
        ));
        register_rest_route( 'api/v1', '/change-number', array(
            'methods' => 'POST',
            'callback' => [$this, 'changeNumberApiFunction'],
            'permission_callback' => function () {
                return is_user_logged_in();
            }
        ));
        register_rest_route( 'api/v1', '/card-otp', array(
            'methods' => 'POST',
            'callback' => [$this, 'cardOtpFunction'],
            'permission_callback' => "__return_true"
        ));
    }
    /*
     * اپلود عکس برای احراز هویت
     */
    public function documentInfoApiFunction(){
        $user_id = get_current_user_id();
        $u = SiteModel::table('user_identity', 'user_id', $user_id);
        if (!empty($u['landline_phone'])) {
            $elapsedSeconds = strtotime(date("Y-m-d H:i:s")) - strtotime($u['updated_at']);
            $elapsedMinutes = $elapsedSeconds / 60;
            $remainingMinutes = max(0, 15 - $elapsedMinutes);
            $timer = round($remainingMinutes, 2);
            if ($timer > 1) {
                $landline_phone = 0;
            } else {
                $landline_phone = 1;
            }
        } else {
            $landline_phone = 1;
        }

        if (!isset($_POST['img']) || !$user_id || $landline_phone) {
            $response_data = array('status' => false, 'message' => "شما اجازه ثبت را ندارید");
            echo json_encode($response_data);
            exit();
        }

        if ($_POST['select_val'] == 0) {
            $type_media = "National_card__img";
        } elseif ($_POST['select_val'] == 1) {
            $type_media = "Birth_certificate";
        }
        $verification_code = isset($_POST['verification_code']) ? sanitize_text_field(wp_unslash($_POST['verification_code'])) : '';
        $verification_date = isset($_POST['verification_date']) ? sanitize_text_field(wp_unslash($_POST['verification_date'])) : '';
        if (!empty($verification_code)) {
            update_user_meta($user_id, 'giftmax_verification_note_code', $verification_code);
        }
        if (!empty($verification_date)) {
            update_user_meta($user_id, 'giftmax_verification_note_date', $verification_date);
        }
        $records = VerifyModel::userDocuments($user_id);
        if (empty($records)) {
            VerifyModel::insertDocuments($user_id,$type_media,$_POST['img']);
            $response_data = array('status' => true, 'message' => "ثبت شد");
        } else {
            $response_data = array('status' => false, 'message' => "شما اجازه ثبت این مدرک را ندارید");
        }
        echo json_encode($response_data);
    }
    public function landlinePhoneApiFunction()
    {
        if (!isset($_POST['value'])) {
            echo json_encode(["status" => false, "message" => "اطلاعات ناقص است", "close" => true]);
            exit;
        }
        $otp = mt_rand(100000, 999999);
        $expiry = date("Y-m-d H:i:s", strtotime("+2 minutes"));
        UserModel::expiryEnd();
        $records = UserModel::exitOtp($_POST['value']);
        if (!empty($records) && strtotime($records['otp_expiry']) < time()) {
            UserModel::otpDelete($records['id']);
        }
        if (empty($records)) {
            UserModel::otp($_POST['value'], $otp, $expiry);
        }
        $url = "https://portal.avanak.ir/rest/SendOTP";
        $url = $url . "?" . "Token=" . urlencode("1ACAAF7BC85B6AB3B54E5381A72EDCDC67D7BF06");
        $url = $url . "&" . "Length=6";
        $url = $url . "&" . "Number=" . $_POST['value'];
        $url = $url . "&" . "OptionalCode=" . $otp;

        $json = file_get_contents($url);
        if ($json->ErrorCode == 0) {
            echo json_encode(["status" => true]);
        } else {
            echo json_encode(["status" => false, "message" => "خطایی پیش آمده"]);
        }
    }
    public function changeNumberApiFunction()
    {
        if (!isset($_POST['value']) || !isset($_POST['id'])){
            echo json_encode(['status'=>false,'message'=>"اطلاعات ناقص"]);
            exit();
        }
        $order = wc_get_order(decrypt_id($_POST['id']));
        $maskedCardNumber = $order->get_meta( '_card_pay', true );
        $userCardNumber = $_POST['value'];
        $masked = Payment::extractCardDigits($maskedCardNumber);

        if (!$masked) {
            echo json_encode(['status'=>false,'message'=>"شماره کارت درست نیست"]);
            exit();
        }

        $userCardNumber = preg_replace('/\D/', '', $userCardNumber);

        if (strlen($userCardNumber) !== 16) {
            echo json_encode(['status'=>false,'message'=>"شماره کارت درست نیست"]);
            exit();
        }
        if ($masked['prefix_length'] > 0) {
            if (substr($userCardNumber, 0, $masked['prefix_length']) !== $masked['prefix']) {
                echo json_encode(['status'=>false,'message'=>"شماره کارت درست نیست"]);
                exit();
            }
        }
        if ($masked['suffix_length'] > 0) {
            if (substr($userCardNumber, -$masked['suffix_length']) !== $masked['suffix']) {
                echo json_encode(['status'=>false,'message'=>"شماره کارت درست نیست"]);
                exit();
            }
        }
        $order->update_meta_data('_is_card_pay', 1);
        $order->update_meta_data('_card_pay', $userCardNumber);
        $order->save();
        echo json_encode(['status'=>true]);
    }
    public function cardOtpFunction()
    {
        if (!isset($_POST['hash'])){
            echo json_encode(['status'=>false,'message'=>"اطلاعات ناقص",'Isreload'=>true]);
            exit();
        }
        $hash = $_POST['hash'];
        $record = SiteModel::table('user_bank_cards','hash',$hash);
        if (empty($record)){
            echo json_encode(['status'=>false,'message'=>"اطلاعات ناقص",'Isreload'=>true]);
            exit();
        }
        $response_data = Woocommerce::otpCardVerify(get_userdata($record['user_id'])->user_login,$_POST['otp'],$hash);
        if ($response_data['status'] == true){
            $loginHash = SiteModel::table('token_register','UserLogin',get_userdata($record['user_id'])->user_login);
            $output = View::re("/inc/templates/template-parts/login/getpassword.php", ['userName'=>get_userdata($record['user_id'])->user_login,'hash'=>$loginHash]);
            $response_data['html'] = $output;
        }
        echo json_encode($response_data);
    }

}