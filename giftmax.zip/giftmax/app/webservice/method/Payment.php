<?php

namespace Giftmax\webservice\method;

use Giftmax\model\LicenseModel;
use Giftmax\model\NotificationModel;
use Giftmax\model\ProductModel;
use Giftmax\model\SiteModel;
use Giftmax\model\UserModel;
use Giftmax\model\WalletModel;
use Giftmax\modules\Db;
use Giftmax\modules\View;

if (!defined('ABSPATH')) {
    exit;
}

class Payment{

    public function __construct(){

        add_action( 'rest_api_init',[ $this, 'All_api_routes' ] );
    }

    public function All_api_routes(){
        register_rest_route( 'api/v1', '/PaymentMethods', array(
            'methods' => 'POST',
            'callback' => [$this, 'paymentMethodsApiFunction'],
            'permission_callback' => function () {
                return is_user_logged_in();
            }
        ) );
        register_rest_route( 'api/v1', '/payment', array(
            'methods' => 'POST',
            'callback' => [$this, 'paymentApiFunction'],
            'permission_callback' => function () {
                return is_user_logged_in();
            }
        ) );
        register_rest_route( 'api/v1', '/payment-verify/zibal', array(
            'methods' => 'GET',
            'callback' => [$this, 'paymentVerifyApiFunction'],
            'permission_callback' => "__return_true"
        ) );
        register_rest_route( 'api/v1', '/payment-verify/paystar', array(
            'methods' => 'POST',
            'callback' => [$this, 'paystarVerifyApiFunction'],
            'permission_callback' => "__return_true"
        ) );
        register_rest_route( 'api/v1', '/payment-verify/payment4', array(
            'methods' => 'GET',
            'callback' => [$this, 'payment4VerifyApiFunction'],
            'permission_callback' => "__return_true"
        ) );

    }
    private static function clear_checkout_cart($user_id = null): void
    {
        if (function_exists('WC')) {
            if (null === WC()->session) {
                WC()->initialize_session();
            }
            if (null === WC()->cart) {
                WC()->cart = new \WC_Cart();
            }

            WC()->cart->empty_cart(true);
            WC()->cart->remove_coupons();

            if (WC()->session) {
                foreach ([
                    'cart_created_time',
                    'rial_coupon',
                    'wallet_dirty',
                    'use_wallet',
                    'wallet_discount',
                    '_wallet_discount',
                    '_use_wallet',
                ] as $key) {
                    WC()->session->__unset($key);
                }
                WC()->session->set_customer_session_cookie(true);
            }
        }

        $user_id = $user_id ? absint($user_id) : get_current_user_id();
        if ($user_id > 0) {
            delete_user_meta($user_id, '_woocommerce_persistent_cart_' . get_current_blog_id());
        }
    }
    public static function callZohalService(string $url, array $payload, string $token ,int $isIdentity = 0): array
    {
        $ch = curl_init($url);

        curl_setopt_array($ch, [
            CURLOPT_POST           => true,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HTTPHEADER     => [
                'Content-Type: application/json',
                'Authorization: Bearer ' . $token
            ],
            CURLOPT_POSTFIELDS     => json_encode($payload),
            CURLOPT_TIMEOUT        => 30,
        ]);

        $response = curl_exec($ch);

        if ($response === false) {
            $error = curl_error($ch);
            curl_close($ch);
            return [
                'status'  => false,
                'message' => 'Curl Error: ' . $error
            ];
        }

        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        $data = json_decode($response, true);
        if ($httpCode === 400) {
            return [
                'status'  => false,
                'message' => $data['response_body']['message'] ?? 'درخواست نامعتبر'
            ];
        }
        if ($isIdentity === 0) {
            if ($httpCode === 200) {

                if (isset($data['response_body']['data']['matched'])) {

                    return [
                        'status' => (bool)$data['response_body']['data']['matched'],
                        'message' => $data['response_body']['data']['matched']
                            ? 'اطلاعات تطابق دارد'
                            : 'اطلاعات تطابق ندارد'
                    ];
                }

                return [
                    'status' => true,
                    'message' => $data['response_body']['message'] ?? 'عملیات موفق'
                ];
            }
        }else{
            if ($httpCode === 200) {

                if (isset($data['response_body']['data']['alive']) && $data['response_body']['data']['alive']) {
                    return $data['response_body']['data'];
                }

                return [
                    'status'  => false,
                    'message' => 'درخواست شما نامعتبر است'
                ];
            }
        }
        return [
            'status'  => false,
            'message' => 'وضعیت پاسخ نامعتبر: ' . $httpCode
        ];
    }

    public function paymentMethodsApiFunction(\WP_REST_Request $request) {

        if ( ! class_exists('WooCommerce') ) {
            wp_send_json_error([
                'message' => 'ووکامرس فعال نیست'
            ]);
        }
        $method = $request->get_param('method');

        if ( null === WC()->session ) {
            WC()->initialize_session();
        }

        if ( null === WC()->customer ) {
            WC()->customer = new \WC_Customer( get_current_user_id(), true );
        }

        if ( null === WC()->cart ) {
            WC()->cart = new \WC_Cart();
        }
        WC()->cart->calculate_totals();

        $cart = WC()->cart;

        $cart_product_discount = 0;
        WC()->session->set('payment_type', $method);
        $stored_coupon = WC()->session->get('rial_coupon');
        if($method=='r') {
            if ( $stored_coupon && ! WC()->cart->has_discount( $stored_coupon ) ) {
                WC()->cart->apply_coupon( $stored_coupon );
                WC()->cart->calculate_totals();
            }
        }else{
            if ( $stored_coupon ) {
                WC()->cart->remove_coupon( $stored_coupon );
                WC()->cart->calculate_totals();
            }
        }
        foreach (WC()->cart->get_cart() as $cart_item) {
            $product = $cart_item['data'];
            $qty = (int)$cart_item['quantity'];
            $regular_price = (float)$product->get_regular_price();
            $line_total = $cart_item['line_total'];

            $cart_product_discount += ($regular_price * $qty) - $line_total;
        }

        $coupon_discount_total = WC()->cart->get_discount_total();
        $total_discount = $cart_product_discount + $coupon_discount_total;

        $update_dollar = null;
        $USD = SiteModel::table("setting","meta_key","currency");
        if (!empty($USD)) {
            $currencies = json_decode($USD['meta_value'],true);
            foreach ($currencies as $currency) {
                if ($currency['symbol'] === 'USD') {
                    $usd_rate_updated_at = $currency['time'];
                    $dollar = $currency['dayClose'];
                    break;
                }
            }
        }
        if (!empty($usd_rate_updated_at)) {
            $usd_rate_updated_ts = strtotime($usd_rate_updated_at);
            if ($usd_rate_updated_ts !== false) {
                $elapsed_seconds = max(0,time()  - $usd_rate_updated_ts);
                if ($elapsed_seconds < 60) {
                    $update_dollar = $elapsed_seconds . ' ثانیه ';
                } else {
                    $elapsed_minutes = (int) floor($elapsed_seconds / 60);
                    $update_dollar = $elapsed_minutes . ' دقیقه ';
                }
            }
        }

        if($method=='r') {
            echo json_encode([
                'status' => true,
                'summary' => [
                    'subtotal' => '<span class="text-larger font-bold text-dark tracking-tighter pt-2 inline-block">' .  number_format_usd($cart->get_subtotal()+$total_discount) . '</span>' . "تومان",
                    'discount' => '<span class="text-larger font-bold text-red tracking-tighter pt-2 inline-block">'. number_format_usd($total_discount) .'</span>' . "تومان",
                    'total' => '<span class="text-lg font-bold text-green-dark tracking-tighter pt-2 inline-block">'. number_format_usd($cart->get_total('edit')) .'</span>' . "تومان",
                ]

            ]);
        }else{
            echo json_encode([
                'status' => true,
                'summary' => [
                    'subtotal' => '<span class="text-larger font-bold text-dark tracking-tighter pt-2 inline-block">' . number_format(($cart->get_subtotal() + $total_discount)/$dollar) . '</span>' . "دلار",
                    'discount' => '<span class="text-larger font-bold text-red tracking-tighter pt-2 inline-block">'. number_format($total_discount/$dollar) .'</span>' . "دلار",
                    'dollar' => '<span class="text-lg font-bold text-green-dark tracking-tighter pt-2 inline-block">'. number_format($dollar) .'</span>' . "تومان",
                    'update_dollar' => $update_dollar,
                    'total' => '<div class="flex flex-col ai-end gap-3"><div><span class="text-lg font-bold text-green-dark tracking-tighter pt-2 inline-block">'. number_format_usd($cart->get_total('edit')) .'</span>تومان' . "</div>" .
                        '<div><span class="text-lg font-bold text-green-dark tracking-tighter pt-2 inline-block">'. number_format($cart->get_total('edit')/$dollar) .'</span>دلار' . "</div>" . '</div>',
                ]

            ]);
        }
    }
    private static function suspiciousOrder($order)
    {
        global $wpdb;
        $db = \Giftmax\modules\Db::getLnstance();
        $records = $db->first("SELECT * FROM `{$wpdb->prefix}setting` WHERE `meta_key`='suspicious_order'");
        if (empty($records)){
            return false;
        }
        $record = json_decode($records['meta_value'], true);

        if (!$order) {
            return;
        }
        if ($order->get_status() !== 'completed' && $order->get_status() !== 'card-not-verified') {
            $order->update_meta_data('_suspicious_order', 0);
            $order->save();
            return;
        }
        if ($order->get_total() < $record[0]['minTotal']) {
            $order->update_meta_data('_suspicious_order', 0);
            $order->save();
            return;
        }

        $customer_id = $order->get_customer_id();

        if (!$customer_id) {
            $order->update_meta_data('_suspicious_order', 0);
            $order->save();
            return;
        }

        $orders = wc_get_orders([
                'customer_id' => $customer_id,
                'status'      => ['completed','card-not-verified'],
                'limit'       => 1,
                'orderby'     => 'date',
                'order'       => 'DESC',
                'exclude'     => [$order->get_id()],
                'return'      => 'objects',
        ]);
        if (empty($orders)) {
            $order->update_meta_data('_suspicious_order', 0);
            $order->save();
            return;
        }

        $last_order = $orders[0];

        $diff = $order->get_date_created()->getTimestamp() - $last_order->get_date_created()->getTimestamp();

        if ($diff <= ($record[0]['minutes'] * 60)) {
            $order->update_meta_data('_suspicious_order', 1);
            $order->save();
        }else{
            $order->update_meta_data('_suspicious_order', 0);
            $order->save();
        }
    }
    public function paymentApiFunction(\WP_REST_Request $request) {

        if (!is_user_logged_in()) {
            echo json_encode([
                'status'  => false,
                'message' => 'اجازه درخواست ندارید'
            ]);
            exit();
        }

        if (is_user_blocked()) {
            echo json_encode([
                'status'  => false,
                'message' => 'شما بلاک شده اید'
            ]);
            exit();
        }
        if (!class_exists('WooCommerce')) {
            return new \WP_REST_Response([
                'message' => 'ووکامرس فعال نیست'
            ], 400);
        }
        $buyer_ip = giftmax_get_user_ip();
        if ( ! giftmax_is_iran_ip($buyer_ip) ) {
            echo json_encode([
                'status'  => false,
                'message' => 'پرداخت فقط از طریق IP ایران امکان‌پذیر است.'
            ]);
            exit();
        }
        if (null === WC()->session) {
            WC()->initialize_session();
        }
        if (null === WC()->customer) {
            WC()->customer = new \WC_Customer(get_current_user_id(), true);
        }
        if (null === WC()->cart) {
            WC()->cart = new \WC_Cart();
        }

        $gateway = sanitize_text_field($request->get_param('gateway'));
        $number = $request->get_param('number');
        if (!in_array($gateway, ['zibal', 'paystar', 'Payment4'], true)) {
            return new \WP_REST_Response([
                'status' => false,
                'message' => 'درگاه پرداخت نامعتبر است'
            ], 200);
        }

        if (WC()->payment_gateways()->payment_gateways()[$gateway]->enabled != 'yes') {
            return new \WP_REST_Response([
                'status' => false,
                'message' => 'درگاه پرداخت غیرفعال است'
            ], 200);
        }

        $user = wp_get_current_user();
        $u    = SiteModel::table('user_identity', 'user_id', $user->ID);
        if (!$u['is_verified']){
            return new \WP_REST_Response([
                'status' => false,
                'message' => 'برای پرداخت شما اول باید احراز هویت را کامل کنید'
            ], 200);
        }
        $cart = WC()->cart;
        if ($cart->is_empty()) {
            return new \WP_REST_Response([
                'status' => false,
                'message' => 'سبد خرید خالی است'
            ], 200);
        }
        $amount = $cart->get_total('edit');
        $vip = isset($u['account_type']) && $u['account_type'] != 'vip';
        $db = Db::getLnstance();
        $order = null;

        try {
            $order = wc_create_order([
                'customer_id' => $user->ID,
            ]);
            $order->set_customer_id($user->ID);
            $order->set_billing_first_name($user->first_name);
            $order->set_billing_last_name($user->last_name);
            $order->set_billing_phone($user->user_login);
            $order->save();
            $has_preorder = false;

            foreach ($cart->get_cart() as $item) {
                $product = wc_get_product($item['product_id']);
                if (!$product) {
                    continue;
                }
                $delivery = get_post_meta($product->get_id(), 'delivery', true);

                $is_preorder = (
                        isset($delivery['two']) &&
                        $delivery['two'] === 'on'
                );

                if ($is_preorder) {
                    $has_preorder = true;
                }
                if (!$is_preorder) {
                    $available_licenses = ProductModel::available($product->get_id())['total'];
                    if ($available_licenses == 0) {
                        return new \WP_REST_Response([
                                'status' => false,
                                'message' => 'در حال حاضر لایسنسی برای محصول ' . $product->name . ' نداریم لطفا برای ادامه تراکنش ایم محصول رو از سبد خرید حذف کنید '
                        ]);
                    }
                    if ($available_licenses < $item['quantity']) {
                        return new \WP_REST_Response([
                                'status' => false,
                                'message' => 'در حال حاضر ' . ($available_licenses) . ' لایسنس برای محصول ' . $product->name . 'داریم لطفا تعداد محصول را مطابق به تعداد لایسنس ها موجود کنید'
                        ]);
                    }
                }
                if ($product->get_price() == 0 || $product->get_price() == ''){
                    return new \WP_REST_Response([
                            'status' => false,
                            'message' => 'برای پرداخت ' . $product->name . ' را از سبد خرید حذف کنید'
                    ], 200);
                }
               $order->add_product($product, $item['quantity']);
            }

            $order->update_meta_data('_has_preorder_items', $has_preorder);
            $points = (int) WC()->session->get( 'total_cart_points', 0 );
            $wallet_discount = (int) WC()->session->get( 'wallet_discount', 0 );
            $use_wallet = (int) WC()->session->get( 'use_wallet', true );
            $rial_coupon = WC()->session->get( 'rial_coupon');
            $order->set_payment_method($gateway);
            $order->update_status('pending', 'در انتظار پرداخت');
            $order->update_meta_data('_total_cart_points', $points);
            $order->update_meta_data('_wallet_discount', $wallet_discount);
            $order->update_meta_data('_use_wallet', $use_wallet);
            $order->update_meta_data('_rial_coupon', $rial_coupon);
            $order->update_meta_data('_buyer_ip', $buyer_ip);
            $order->save();
            if ($amount ==0){
                add_filter(
                    'woocommerce_email_enabled_customer_completed_order',
                    '__return_false'
                );
                try {
                    $order->update_status('completed', 'سفارش به صورت خودکار پس از پرداخت تکمیل شد');
                    $order->save();
                } catch (\Throwable $e) {
                    error_log(
                        '[PAYMENT VERIFY API] Order completed but email failed: ' .
                        $e->getMessage()
                    );
                }
                $applied_coupons =  $order->get_meta( '_rial_coupon');
                if ( !empty( $applied_coupons ) ) {
                    try {
                        $coupon = new \WC_Coupon($applied_coupons);
                        if (!$coupon->get_id()) {
                            $order->add_order_note('⚠️ کد تخفیف ' . $applied_coupons . ' در سیستم یافت نشد.');
                            throw new \Exception('Coupon not found.');
                        }

                        $usage_count = (int)$coupon->get_usage_count();
                        $coupon->set_usage_count($usage_count + 1);
                        $coupon->save();

                        $order->add_order_note(
                                sprintf(
                                        '✅ کد تخفیف "%s" با موفقیت در آمار ووکامرس ثبت شد. (استفاده %d)',
                                        $applied_coupons,
                                        $usage_count + 1
                                )
                        );

                        $order->save();

                        if (!in_array($applied_coupons, $order->get_coupon_codes())) {
                            $order->apply_coupon($applied_coupons);
                            $order->save();
                        }
                    } catch (\Exception $e) {
                        $order->add_order_note('❌ خطا در ثبت کد تخفیف: ' . $e->getMessage());
                    }
                }
                $use_wallet = $order->get_meta( '_use_wallet', true );
                $user_id = get_current_user_id();
                if ($use_wallet) {
                    $discount = $order->get_meta( '_wallet_discount', true );
                    $wallet = WalletModel::getWallet($user_id);
                    $discount = abs($discount);
                    $wallet_bal = $wallet['balance'];
                    if ($wallet_bal > 0) {
                        $new_balance = floatval($wallet_bal) - $discount;
                        $new_balance = max(0.0, $new_balance);
                        $db->query('START TRANSACTION');
                        WalletModel::updateBalance($wallet['id'],$new_balance);
                        WalletModel::insertTransactions($user_id,$wallet['id'],$discount,'کسری از قیمت سبد خرید','wallet','debit');
                        $db->query( 'COMMIT' );
                    }
                }
                $total_points = $order->get_meta( '_total_cart_points', true );
                if ($total_points !=0){
                    $points = WalletModel::getPoints($user_id);
                    WalletModel::updatePoint($points['id'],(int)$points['points'] + (int)$total_points);
                    WalletModel::insertTransactions($user_id,$points['id'],$total_points,'دریافت امتیاز خرید','points','credit');
                }
                $hasIncompleteLicence = false;
                $has_preorder = false;
                $productData = [];
                foreach ($order->get_items() as $item_id => $item) {
                    $reserved_licence_ids = [];
                    $product_id = $item->get_product_id();
                    $delivery   = get_post_meta( $product_id, 'delivery', true );
                    $product = wc_get_product( $product_id );
                    $product_name = $product->get_name();
                    $productData['names'][] = $product_name;
                    $productData['quantities'][] = (int)$item['quantity'];
                    $product_permalink = $product->get_permalink();
                    $product_img = get_the_post_thumbnail_url($product_id, 'product_discount');
                    if ( isset( $delivery['two'] ) && $delivery['two'] === 'on'){
                        $delivery_time = isset( $delivery['time'] ) ? absint( $delivery['time'] ) : 0;
                        $dataLincesns = $order->get_date_created()
                                ? (clone $order->get_date_created())
                                        ->modify( '+'.$delivery_time.' hour' )
                                        ->date( 'Y/m/d H:i' )
                                : $delivery_time;
                        $dataLincesns = gjdate($dataLincesns,"d M Y، H:i");
                        $body = '<div class="flex justify-between"> <div> محصول <a href="'.$product_permalink.'" target="_blank">'.$product_name.'</a> در سبد خرید شما به صورت <span class="pre-sale__span">پیش فروش</span> می‌باشد و تا '.$delivery_time.' ساعت آینده لایسنس آن تحویل شما داده می‌شود. </div> <div class="flex gap-2 s2ged"> <img class="w-[87px]" src="'.$product_img.'" alt="'.$product_name.'"> <div class="c-badge rounded-sm badge-orange text-2xs -mt-1 flex flex-col"> <div>تا '.$dataLincesns.'</div> <div>لایسنس موجود میشود</div> </div> </div> </div>';
                        $id = NotificationModel::addNotification($user_id,'محصول پیش فروش در سبد خرید',$body);
                        UserModel::alert($user_id,$id);
                    }else{
                        $manage_stock = get_post_meta($product_id, '_manage_stock', true);
                        if ($manage_stock == 'yes') {
                            $count = ProductModel::available($product_id)['total'];
                            update_post_meta($product_id, '_stock', $count);
                            if($count >=1) {
                                update_post_meta($product_id, '_stock_status', 'instock');
                            }
                        }
                    }
                    $is_preorder = (
                            isset($delivery['two']) &&
                            $delivery['two'] === 'on'
                    );

                    if ($is_preorder) {
                        $has_preorder = true;
                        continue;
                    }

                    $requested = (int)$item['quantity'];

                    try {

                        $db->query("START TRANSACTION");

                        $licences = LicenseModel::availableLicenses($product->get_id());
                        foreach ($licences as $licence){
                            $reserved_licence_ids[] = $licence['licence_id'];
                            LicenseModel::assignedSet($order->get_id(),$licence['licence_id']);
                        }

                        $db->query("COMMIT");

                        if(count($licences) < $requested){

                            $hasIncompleteLicence = true;

                            $incompleteProducts[] = [
                                    'product'   => $product->get_name(),
                                    'requested' => $requested,
                                    'assigned'  => count($licences)
                            ];
                        }

                    }catch(Exception $e){

                        $db->query("ROLLBACK");
                        throw $e;

                    }
                    if (!empty($reserved_licence_ids) && is_array($reserved_licence_ids)) {
                        $item->update_meta_data(
                                '_reserved_licence_ids',
                                json_encode($reserved_licence_ids)
                        );
                        $item->save();
                    }
                }
                if($has_preorder) {
                    $orderId = $order->get_id();
                    $fullname = $order->get_formatted_billing_full_name();
                    self::sendSmsPreSale($orderId,implode('، ', $productData['names']),array_sum($productData['quantities']),$fullname);
                }
                if($hasIncompleteLicence){

                    $order->update_meta_data('_giftmax_incomplete_licence', 1);
                    $order->update_meta_data('_giftmax_incomplete_products', $incompleteProducts);
                    $order->save();
                    $note = "کمبود لایسنس:\n";

                    foreach($incompleteProducts as $row){

                        $missing = $row['requested'] - $row['assigned'];

                        $note .= "{$row['product']} : {$row['assigned']} تحویل شد، {$missing} عدد موجود نبود.\n";
                    }

                    $order->add_order_note($note);
                }
                self::suspiciousOrder($order);
                self::clear_checkout_cart($order->get_user_id());
                echo json_encode([
                    'status' => true,
                    'url' => home_url('/profile/invoices/'.$order->get_id())
                ]);
                exit();
            }else {
                self::clear_checkout_cart($order->get_user_id());
                switch ($gateway) {
                    case 'zibal':
                        $order->set_total($amount);
                        $order->save();
                        $this->start_zibal_payment($order, $amount * 10);
                    case 'paystar':
                        $order->set_total($amount);
                        $order->save();
                        $this->start_paystar_payment($order, $amount * 10);
                    case 'Payment4':
                        $order->set_total($amount);
                        $order->save();
                        $this->start_payment4_payment($order);
                }
            }
        }catch ( Throwable $e ) { // هر گونه خطا یا exception
            if ($order) {
                $order->delete();
            }
            return new \WP_REST_Response(
                [
                    'status'  => false,
                    'message' => $e->getMessage(),
                    'file'    => $e->getFile(),
                    'line'    => $e->getLine(),
                ],
                200
            );
        }
    }
    private function start_paystar_payment($order, $amount){
        $paystar = get_option('woocommerce_paystar_settings');
        $sign_key = $paystar['sign'];
        $gateway_id = $paystar['gateway_id'];
        if ( empty( $gateway_id ) || empty( $sign_key ) ) {
            return new \WP_REST_Response(
                [ 'message' => __( 'تنظیمات PayStar به‌طور کامل تنظیم نشده‌اند.', 'giftmax' ) ],
                500
            );
        }
        $order_id     = $order->get_id();
        $callback_url = home_url( '/wp-json/api/v1/payment-verify/paystar');

        $sign_data = $amount . '#' . $order_id . '#' . $callback_url;
        $sign      = hash_hmac( 'SHA512', $sign_data, $sign_key );
        $user = get_userdata($order->get_user_id());
        $body = [
            'amount'    => $amount,
            'order_id'  => $order_id,
            'callback'  => $callback_url,
            'sign'      => $sign,
            'name'      => "$user->first_name $user->last_name",
            'description' => 'پرداخت سفارش #' . $order_id,
            'callback_method' => 0
        ];
        $response = wp_remote_post( 'https://core.paystar.ir/api/pardakht/create', [
            'headers' => [
                'Content-Type'  => 'application/json',
                'Authorization' => 'Bearer ' . $gateway_id,
            ],
            'body'    => wp_json_encode( $body ),
            'timeout' => 30,
        ] );
        if ( is_wp_error( $response ) ) {
            return new \WP_REST_Response(
                [ 'message' => __( 'خطا در ارتباط با درگاه PayStar.', 'giftmax' ) ],
                500
            );
        }

        $res = json_decode( wp_remote_retrieve_body( $response ), true );

        if ( isset($res['status']) && $res['status']==1 ) {
            $payment_url = 'https://core.paystar.ir/api/pardakht/payment?token=' . $res['data']['token'];
            $order->update_meta_data( '_paystar_ref_num', $res['data']['ref_num']);
            $order->update_meta_data( 'payment_amount', $res['data']['payment_amount']);
            $order->save();
            return new \WP_REST_Response(
                [
                    'status' => true,
                    'url'    => $payment_url,
                ],
                200
            );
        }

        $error_msg = '';
        if ( ! empty( $res['errors'] ) ) {
            $error_msg = implode( "\n", $res['errors'] );
        } elseif ( ! empty( $res['message'] ) ) {
            $error_msg = $res['message'];
        } else {
            $error_msg = __( 'خطا در درگاه PayStar', 'giftmax' );
        }

        $order->update_status( 'failed', __( 'خطا در اتصال به درگاه PayStar', 'giftmax' ) );
        $order->save();

        return new \WP_REST_Response(
            [
                'status'  => false,
                'message' => $error_msg,
            ],
            500
        );
    }
    private function start_zibal_payment($order, $amount) {
        $zibal = get_option('woocommerce_zibal_settings');

        $merchant = $zibal['api_key'];
        $callback = home_url('/wp-json/api/v1/payment-verify/zibal') . '?order_id=' . $order->get_id();
        $parameters = [
            "merchant" => $merchant,
            "callbackUrl" => $callback,
            "amount" => (int) $amount,
            "orderId" => $order->get_id(),
            "mobile" => get_userdata($order->get_user_id())->user_login,
            "description" => "پرداخت سفارش #" . $order->get_id()
        ];
        $response = $this->postToZibal('request', $parameters);
        if (isset($response->result) && $response->result == 100) {
            $order->update_meta_data('_zibal_trackId', $response->trackId);
            $order->save();

            echo json_encode([
                'status' => true,
                'url' => "https://gateway.zibal.ir/start/" . $response->trackId
            ]);
            exit();
        }
        add_filter(
            'woocommerce_email_enabled_customer_completed_order',
            '__return_false'
        );
        $order->update_status( 'failed', ( 'خطا در اتصال به درگاه Zibal') );
        $order->save();
        echo json_encode([
            'status' => false,
            'message' => $response->message ?? 'خطا در اتصال به درگاه Zibal'
        ]);
    }
    private function postToZibal($path, $parameters)
    {
        $url = 'https://gateway.zibal.ir/v1/' . $path;

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($parameters));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        $response = curl_exec($ch);
        curl_close($ch);

        return json_decode($response);
    }
    private function start_payment4_payment($order){
        $apiKey = get_option('woocommerce_payment4_settings')['api_key'];
        $url    = "https://service.payment4.com/api/v1/payment";

        $callbackUrl = home_url('/wp-json/api/v1/payment-verify/payment4');
        $payload = [
            "amount"       => intval($order->get_total()),
            "callbackUrl"  => $callbackUrl,
            "callbackParams" => ["order_id" => $order->get_id()],
            "webhookUrl"     => $callbackUrl,
            "webhookParams"  => ["order_id" => $order->get_id()],
            "language"       => "fa",
            "currency"       => "USD",
            "sandBox"        => true
        ];

        $headers = [
            "x-api-key: $apiKey",
            "Content-Type: application/json"
        ];

        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));

        $response = curl_exec($ch);
        $httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);

        curl_close($ch);
        $responseData = json_decode($response, true);
        if (isset($responseData['paymentUrl'])) {
            if (!empty($responseData['paymentUrl'])) {
                $order->update_meta_data('_zibal_trackId', $response->trackId);
                echo json_encode([
                    'status' => true,
                    'url' => $responseData['paymentUrl']
                ]);
                return;
            }
            echo json_encode([
                'status' => false,
                'message' => $responseData['message'] ?? 'خطا در ایجاد پرداخت'
            ]);
            $order->update_status( 'failed', __( 'خطا در اتصال به درگاه payment4', 'giftmax' ) );
            $order->save();
            exit();
        }

        echo json_encode([
            'status' => false,
            'message' => 'درخواست پرداخت با شکست مواجه شد'
        ]);
        $order->update_status( 'failed', __( 'خطا در اتصال به درگاه payment4', 'giftmax' ) );
        $order->save();
    }
    public static function extractCardDigits($maskedCardNumber) {
        $maskedCardNumber = preg_replace('/[\s-]/', '', $maskedCardNumber);

        if (preg_match('/^(\d+)\*+(\d+)$/', $maskedCardNumber, $matches)) {
            return [
                'prefix' => $matches[1],  // ارقام اول
                'suffix' => $matches[2],  // ارقام آخر
                'prefix_length' => strlen($matches[1]),
                'suffix_length' => strlen($matches[2])
            ];
        }

        if (preg_match('/^\*+(\d+)$/', $maskedCardNumber, $matches)) {
            return [
                'prefix' => '',
                'suffix' => $matches[1],
                'prefix_length' => 0,
                'suffix_length' => strlen($matches[1])
            ];
        }

        if (preg_match('/^(\d+)\*+$/', $maskedCardNumber, $matches)) {
            return [
                'prefix' => $matches[1],
                'suffix' => '',
                'prefix_length' => strlen($matches[1]),
                'suffix_length' => 0
            ];
        }

        return null;
    }
    private function verifyResultOk($order,$numberCartInPay,$order_id,$gateway)
    {
        $user_id = $order->get_user_id();
        $user = SiteModel::table('user_identity', 'user_id', $user_id);
        $verify = false;
        $is_exist = 0;
        $numberCart = null;
        if (isset($user['account_type']) && $user['account_type'] === 'vip') {
            $verify = true;
        } elseif ($extracted = self::extractCardDigits($numberCartInPay)) {
            $cards = UserModel::cardsUser($user_id);
            $matchedCard = null;
            foreach ($cards as $record) {
                $fullCardNumber = decrypt_data($record['card_number_enc']);

                $prefix_match = ($extracted['prefix_length'] === 0 ||
                    strncmp($fullCardNumber, $extracted['prefix'], $extracted['prefix_length']) === 0);

                $suffix_match = ($extracted['suffix_length'] === 0 ||
                    substr_compare($fullCardNumber, $extracted['suffix'], -$extracted['suffix_length'], $extracted['suffix_length']) === 0);

                if ($prefix_match && $suffix_match) {
                    $matchedCard = $fullCardNumber;

                    if (empty($record['phone'])) {
                        $is_exist = 0;
                        $verify = true;
                    } else {
                        $is_exist = 1;
                        $verify = false;
                    }
                    break;
                }
            }

            $numberCart = $matchedCard ?? $numberCartInPay;
        }
            try {
                $order->update_meta_data('_card_pay', $numberCart);
                $order->update_status(
                    'completed',
                    'سفارش به صورت خودکار پس از پرداخت تکمیل شد'
                );
                $order->save();
            } catch (\Throwable $e) {
                error_log(
                    '[PAYMENT VERIFY API] Order completed but email failed: ' .
                    $e->getMessage()
                );
            }
        if (!$verify) {
            try {
                $order->update_status('card-not-verified', 'تایید نشدن کارت');
                $order->update_meta_data('_is_exist', $is_exist);
                $order->save();
            } catch (\Throwable $e) {
                error_log('[PAYMENT VERIFY API] Card verification failed but status update failed: ' . $e->getMessage());
            }
        }
        $applied_coupons =  $order->get_meta( '_rial_coupon');
        if ( !empty( $applied_coupons ) ) {
            try {
	                $coupon = new \WC_Coupon($applied_coupons);
	                    if (!$coupon->get_id()) {
	                        $order->add_order_note('⚠️ کد تخفیف ' . $applied_coupons . ' در سیستم یافت نشد.');
	                        throw new \Exception('Coupon not found.');
	                    }

                    $usage_count = (int)$coupon->get_usage_count();
                    $coupon->set_usage_count($usage_count + 1);
                    $coupon->save();

                    $order->add_order_note(
                        sprintf(
                            '✅ کد تخفیف "%s" با موفقیت در آمار ووکامرس ثبت شد. (استفاده %d)',
                            $applied_coupons,
                            $usage_count + 1
                        )
                    );

                    $order->save();

                    if (!in_array($applied_coupons, $order->get_coupon_codes())) {
                        $order->apply_coupon($applied_coupons);
                        $order->save();
                    }
            } catch (\Exception $e) {
                $order->add_order_note('❌ خطا در ثبت کد تخفیف: ' . $e->getMessage());
            }
        }
        $db = Db::getLnstance();
        $use_wallet = $order->get_meta( '_use_wallet', true );
        if ($use_wallet) {
            $discount = $order->get_meta( '_wallet_discount', true );
            $wallet = WalletModel::getWallet($user_id);
            $discount = abs($discount);
            $wallet_bal = $wallet['balance'];
	            if ($wallet_bal > 0) {
	                $new_balance = $wallet_bal - $discount;
	                $new_balance = max(0.0, $new_balance);
	                $db->query('START TRANSACTION');
                    WalletModel::updateBalance($wallet['id'],$new_balance);
                    WalletModel::insertTransactions($user_id,$wallet['id'],$discount,'کسری از قیمت سبد خرید','wallet','debit');
	                $db->query( 'COMMIT' );
	            }
	        }
        $total_points = $order->get_meta( '_total_cart_points', true );
        if ($total_points !=0){
            $points = WalletModel::getPoints($user_id);
            WalletModel::updatePoint($points['id'],(int)$points['points'] + (int)$total_points);
            WalletModel::insertTransactions($user_id,$points['id'],$total_points,'دریافت امتیاز خرید','points', 'credit');
        }
        $hasIncompleteLicence = false;
        $incompleteProducts = [];
        $has_preorder = false;
        $productData = [];
        foreach ($order->get_items() as $item_id => $item) {
            $reserved_licence_ids = [];
            $product_id = $item->get_product_id();
            $delivery   = get_post_meta( $product_id, 'delivery', true );
            $product = wc_get_product( $product_id );
            $product_name = $product->get_name();
            $productData['names'][] = $product_name;
            $productData['quantities'][] = (int)$item['quantity'];
            $product_permalink = $product->get_permalink();
            $product_img = get_the_post_thumbnail_url($product_id, 'product_discount');
            $is_preorder = (isset($delivery['two']) && $delivery['two'] === 'on');

            if ( $is_preorder){
                $delivery_time = isset( $delivery['time'] ) ? absint( $delivery['time'] ) : 0;
                $dataLincesns = $order->get_date_created()
                    ? (clone $order->get_date_created())
                        ->modify( '+'.$delivery_time.' hour' )
                        ->date( 'Y/m/d H:i' )
                    : $delivery_time;
                $dataLincesns = gjdate($dataLincesns,"d M Y، H:i");
                $body = '<div class="flex justify-between"> <div> محصول <a href="'.$product_permalink.'" target="_blank">'.$product_name.'</a> در سبد خرید شما به صورت <span class="pre-sale__span">پیش فروش</span> می‌باشد و تا '.$delivery_time.' ساعت آینده لایسنس آن تحویل شما داده می‌شود. </div> <div class="flex gap-2 s2ged"> <img class="w-[87px]" src="'.$product_img.'" alt="'.$product_name.'"> <div class="c-badge rounded-sm badge-orange text-2xs -mt-1 flex flex-col"> <div>تا '.$dataLincesns.'</div> <div>لایسنس موجود میشود</div> </div> </div> </div>';
                $id = NotificationModel::addNotification($user_id,'محصول پیش فروش در سبد خرید',$body);
                UserModel::alert($user_id,$id);
            }else{
                $manage_stock = get_post_meta($product_id, '_manage_stock', true);
                if ($manage_stock == 'yes') {
                    $count = ProductModel::available($product_id)['total'];
                    update_post_meta($product_id, '_stock', $count);
                    if($count >=1) {
                        update_post_meta($product_id, '_stock_status', 'instock');
                    }
                }
            }


                if ($is_preorder) {
                    $has_preorder = true;
                    continue;
                }

                $requested = (int)$item['quantity'];

                try {

                    $db->query("START TRANSACTION");
                    $licences = LicenseModel::availableLicenses($product->get_id());
                    foreach ($licences as $licence){
                        $reserved_licence_ids[] = $licence['licence_id'];
                        LicenseModel::assignedSet($order_id,$licence['licence_id']);
                    }

                    $db->query("COMMIT");

                    if(count($licences) < $requested){

                        $hasIncompleteLicence = true;

                        $incompleteProducts[] = [
                                'product'   => $product->get_name(),
                                'requested' => $requested,
                                'assigned'  => count($licences)
                        ];
                    }

                }catch(Exception $e){

                    $db->query("ROLLBACK");
                    throw $e;

                }

            if (!empty($reserved_licence_ids) && is_array($reserved_licence_ids)) {
                $item->update_meta_data(
                        '_reserved_licence_ids',
                        json_encode($reserved_licence_ids)
                );
                $item->save();
            }
        }
        if($has_preorder) {
            $orderId = $order->get_id();
            $fullname = $order->get_formatted_billing_full_name();
            self::sendSmsPreSale($orderId,implode('، ', $productData['names']),array_sum($productData['quantities']),$fullname);
        }
        if($hasIncompleteLicence){

            $order->update_meta_data('_giftmax_incomplete_licence', 1);
            $order->update_meta_data('_giftmax_incomplete_products', $incompleteProducts);
            $order->save();
            $note = "کمبود لایسنس:\n";

            foreach($incompleteProducts as $row){

                $missing = $row['requested'] - $row['assigned'];

                $note .= "{$row['product']} : {$row['assigned']} تحویل شد، {$missing} عدد موجود نبود.\n";
            }

            $order->add_order_note($note);
        }
        $paid_date = $order->get_date_paid();
        $paid_date_fa = $paid_date ? wp_date('Y-m-d H:i', $paid_date->getTimestamp()) : '-';
        self::suspiciousOrder($order);
        header("Refresh: 5; url=" . home_url('/profile/invoices/'  . $order_id));
        header('Content-Type: text/html; charset=utf-8');
        View::render("/inc/templates/template-parts/payment/success.php", ['gateway' => $gateway, 'paid_date_fa' => $paid_date_fa, 'order_number' => $order->get_order_number(), 'amount' => $order->get_total()]);
    }
    private static function sendSmsPreSale($orderId,$product,$count,$fullname)
    {
        $baseUrl = "https://edge.ippanel.com/v1/api/send";
        $token = "wns0sWEioLyJejB0g0olFj-PVlL2Yt5O2G94prP-BXg=";

        $data = [
            "sending_type" => "pattern",
            "from_number" => "+985000125475",
            "code" => "ie4sxghbcxysu67",
            "recipients" => ['9141007342'],
            "params" => [
                "OrderNumber" => $orderId,
                "Product" => $product,
                "M" => $count,
                "Name" => $fullname,
                "link" => esc_url_raw(rest_url('api/v1/order?id='.$orderId))
            ],
        ];

        $ch = curl_init($baseUrl);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            "Content-Type: application/json; charset=utf-8",
            "Content-Type: application/json",
            "Authorization: $token"
        ]);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data, JSON_UNESCAPED_UNICODE));

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
    }
    public function paymentVerifyApiFunction(\WP_REST_Request $request)
    {
        $trackId  = $request->get_param('trackId');
        $success  = $request->get_param('success');
        $order_id = $request->get_param('order_id');
        if (!$trackId || !$order_id) {
            header('Location:'.home_url());
            exit;
        }

        $order = wc_get_order($order_id);

        if (!$order) {
            wp_safe_redirect(home_url());
            exit;
        }
        $zibal_trackId = $order->get_meta('_zibal_trackId');
        if($trackId != $zibal_trackId){
            wp_safe_redirect(home_url());
            exit;
        }
        if ( null === WC()->session ) {
            WC()->initialize_session();
        }
        if ( null === WC()->customer ) {
            WC()->customer = new \WC_Customer( $order->get_user_id(), true );
        }
        if ( null === WC()->cart ) {
            WC()->cart = new \WC_Cart();
        }
        if ((int)$success !== 1) {
            add_filter(
                'woocommerce_email_enabled_customer_completed_order',
                '__return_false'
            );

            try {
                $order->update_status('failed', 'پرداخت توسط کاربر لغو شد');

                $order->save();
            } catch (\Throwable $e) {
                error_log(
                    '[PAYMENT VERIFY API] Order completed but email failed: ' .
                    $e->getMessage()
                );
            }
            header('Content-Type: text/html; charset=utf-8');
            View::render("/inc/templates/template-parts/payment/fail.php");
            exit;
        }
        $zibal = get_option('woocommerce_zibal_settings');
        $apiKey = $zibal['api_key'];
        $response = $this->postToZibal('verify', [
            'merchant' => $apiKey,
            'trackId'  => $trackId,
        ]);
        if ($response && $response->result == 100) {
            $order->add_order_note('پرداخت موفق زیبال - TrackID: ' . $trackId);
            add_filter(
                'woocommerce_email_enabled_customer_completed_order',
                '__return_false'
            );
            self::verifyResultOk($order,$response->cardNumber,$order_id,'زیبال');
        }
        elseif ($response && $response->result == 201){
            header("Refresh: 3; url=" . home_url('/profile/invoices/'  . $order_id));
            header('Content-Type: text/html; charset=utf-8');
            View::render("/inc/templates/template-parts/payment/verifed.php", ['gateway'=>'زیبال']);
            exit;
        }
    }
    public function paystarVerifyApiFunction()
    {
        $status        = $_POST['status'];
        $ref_num       = $_POST['ref_num'];
        $order_id      = $_POST['order_id'];
        if (!isset($_POST['ref_num']) || !isset($_POST['order_id'])) {
            wp_redirect(home_url());
            exit;
        }

        $order = wc_get_order($order_id);
        if (!$order) {
            wp_redirect(home_url());
            exit;
        }
        $paystar_ref_num = $order->get_meta('_paystar_ref_num');
        if($ref_num != $paystar_ref_num){
            wp_safe_redirect(home_url());
            exit;
        }

        if (null === WC()->session) {
            WC()->initialize_session();
        }
        if (null === WC()->customer) {
            WC()->customer = new \WC_Customer($order->get_user_id(), true);
        }
        if (null === WC()->cart) {
            WC()->cart = new \WC_Cart();
        }

        if ($status !== 1) {
            $order->update_status('failed', 'پرداخت توسط کاربر لغو شد');
            $order->update_meta_data('_check_payment',true);
            $order->save();
            header("Refresh: 3; url=" . home_url());
            header('Content-Type: text/html; charset=utf-8');
            View::render("/inc/templates/template-parts/payment/fail.php");
            exit;
        }
        if ($order->get_meta('_check_payment')){
            header("Refresh: 3; url=" . home_url('/profile/invoices/'  . $order_id));
            header('Content-Type: text/html; charset=utf-8');
            View::render("/inc/templates/template-parts/payment/verifed.php", ['gateway'=>'پی استار']);
            exit();
        }
        $paystar = get_option('woocommerce_paystar_settings');
        $sign_key = $paystar['sign'];
        $gateway_id = $paystar['gateway_id'];

        if (empty( $gateway_id ) || empty( $sign_key )) {
            $order->update_status('failed', 'تنظیمات PayStar به‌طور کامل تنظیم نشده‌اند.');
            exit;
        }
        $card_number   = $_POST['card_number'];
        $tracking_code = $_POST['tracking_code'];
        $amount        = $order->get_meta("payment_amount");
        $sign_data = $amount . '#' . $ref_num . '#' . $card_number . '#' . $tracking_code;
        $sign      = hash_hmac( 'sha512', $sign_data, $sign_key );

        $body_params = [
                'amount'  => $amount,
                'ref_num' => $ref_num,
                'sign'    => $sign,
        ];
        $body_json = wp_json_encode( $body_params );

        $response = wp_remote_post(
                'https://core.paystar.ir/api/pardakht/verify',
                [
                        'headers' => [
                                'Accept'        => 'application/json',
                                'Content-Type'  => 'application/json',
                                'Authorization' => 'Bearer ' . $gateway_id,
                        ],
                        'body'    => $body_json,
                        'timeout' => 30,
                ]
        );

        if ( is_wp_error( $response ) ) {
            error_log( 'PayStar Verify – WP Error: ' . $response->get_error_message() );
            $order->update_status( 'failed', 'خطا در ارتباط با پی‌استار' );
            $order->save();
            return false;
        }

        $body   = wp_remote_retrieve_body( $response );
        $result = json_decode( $body, true );

        if ( json_last_error() !== JSON_ERROR_NONE ) {
            error_log( 'PayStar Verify – JSON decode error: ' . json_last_error_msg() );
            return false;
        }

        $code = wp_remote_retrieve_response_code( $response );
        if ( $code !== 200 ) {
            error_log( "PayStar Verify – HTTP Code: {$code}" );
            wp_redirect(home_url());
            return false;
        }

        if (isset($result['data']['ref_num'])) {
            $order->payment_complete($result['data']['ref_num'] ?? $tracking_code);
            $order->add_order_note('پرداخت موفق پی استار - Ref: ' . ($result['data']['ref_num'] ?? '-'));
            $order->update_meta_data('_check_payment',true);
            $order->save();
            add_filter(
                'woocommerce_email_enabled_customer_completed_order',
                '__return_false'
            );
            self::verifyResultOk($order,$result['data']['card_number'],$order_id,'پی استار');
        }
        $order->update_status('failed', 'تراکنش توسط پی استار تایید نشد');

        header('Content-Type: text/html; charset=utf-8');
        header("Refresh: 5; url=" . home_url());
        View::render("/inc/templates/template-parts/payment/fail.php");
        exit;
    }
    public function payment4VerifyApiFunction(\WP_REST_Request $request)
    {
        $paymentUid  = $request->get_param('paymentUid');
        $order_id = $request->get_param('order_id');
        if (!$paymentUid || !$order_id) {
            header('Location:'.home_url());
            exit;
        }

        $order    = wc_get_order($order_id);
        if (!$order) {
            header('Location:'.home_url());
            exit;
        }

        $apiKey = get_option('woocommerce_payment4_settings')['api_key'];

        $url = "https://service.payment4.com/api/v1/payment/verify";
        $headers = [
            "x-api-key: $apiKey",
            "Content-Type: application/json"
        ];
        $payload = [
            "paymentUid" =>$paymentUid,
            "amount" => $order->get_total(),
            "currency" => "USD"
        ];

        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "PUT");
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));

        $response = curl_exec($ch);
        $httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        $db = \Giftmax\modules\Db::getLnstance();
        if ( null === WC()->session ) {
            WC()->initialize_session();
        }
        if ( null === WC()->customer ) {
            WC()->customer = new \WC_Customer( $order->get_user_id(), true );
        }
        if ( null === WC()->cart ) {
            WC()->cart = new \WC_Cart();
        }
        if ($httpcode != 200) {
            add_filter(
                'woocommerce_email_enabled_customer_completed_order',
                '__return_false'
            );

            try {
                $order->update_status('failed', 'پرداخت توسط کاربر لغو شد');

                $order->save();
            } catch (\Throwable $e) {
                error_log(
                    '[PAYMENT VERIFY API] Order completed but email failed: ' .
                    $e->getMessage()
                );
            }

            header('Content-Type: text/html; charset=utf-8');
            header("Refresh: 5; url=" . home_url());
            View::render("/inc/templates/template-parts/payment/fail.php");
            exit;
        }
        $res = json_decode($response, true);
        if ((!empty($res['paymentStatus']) && !empty($res['verified'])) || ($res['paymentStatus'] ?? '') == 'ACCEPTABLE' || ($res['paymentStatus'] ?? '') == 'SUCCESS'){
            $order->add_order_note('پرداخت موفق Payment4 - TrackID: ' . $paymentUid);
            add_filter(
                'woocommerce_email_enabled_customer_completed_order',
                '__return_false'
            );

            try {
                $order->update_status(
                    'completed',
                    'سفارش به صورت خودکار پس از پرداخت تکمیل شد'
                );
                $order->save();
            } catch (\Throwable $e) {
                error_log(
                    '[PAYMENT VERIFY API] Order completed but email failed: ' .
                    $e->getMessage()
                );
            }
            $user_id =  $order->get_user_id();
            $applied_coupons =  $order->get_meta( '_rial_coupon');
            if ( !empty( $applied_coupons ) ) {
                try {
                    $coupon = new \WC_Coupon($applied_coupons);
                    if (!$coupon->get_id()) {
                        $order->add_order_note('⚠️ کد تخفیف ' . $applied_coupons . ' در سیستم یافت نشد.');
                        throw new \Exception('Coupon not found.');
                    }

                    $usage_count = (int)$coupon->get_usage_count();
                    $coupon->set_usage_count($usage_count + 1);
                    $coupon->save();

                    $order->add_order_note(
                        sprintf(
                            '✅ کد تخفیف "%s" با موفقیت در آمار ووکامرس ثبت شد. (استفاده %d)',
                            $applied_coupons,
                            $usage_count + 1
                        )
                    );

                    $order->save();

                    if (!in_array($applied_coupons, $order->get_coupon_codes())) {
                        $order->apply_coupon($applied_coupons);
                        $order->save();
                    }
                } catch (\Exception $e) {
                    $order->add_order_note('❌ خطا در ثبت کد تخفیف: ' . $e->getMessage());
                }
            }
            $total_points = $order->get_meta( '_total_cart_points', true );
            if ($total_points !=0){
                $points = WalletModel::getPoints($user_id);
                WalletModel::updatePoint($points['id'],(int)$points['points'] + (int)$total_points);
                WalletModel::insertTransactions($user_id,$points['id'],$total_points,'دریافت امتیاز خرید','points', 'credit');
            }
            $hasIncompleteLicence = false;
            $incompleteProducts = [];
            $has_preorder = false;
            $productData = [];
            foreach ($order->get_items() as $item_id => $item) {
                $reserved_licence_ids = [];
                $product_id = $item->get_product_id();
                $delivery   = get_post_meta( $product_id, 'delivery', true );
                $product = wc_get_product( $product_id );
                $product_name = $product->get_name();
                $product_permalink = $product->get_permalink();
                $productData['names'][] = $product_name;
                $productData['quantities'][] = (int)$item['quantity'];
                $product_img = get_the_post_thumbnail_url($product_id, 'product_discount');
                if ( isset( $delivery['two'] ) && $delivery['two'] === 'on'){
                    $delivery_time = isset( $delivery['time'] ) ? absint( $delivery['time'] ) : 0;
                    $dataLincesns = $order->get_date_created()
                        ? (clone $order->get_date_created())
                            ->modify( '+'.$delivery_time.' hour' )
                            ->date( 'Y/m/d H:i' )
                        : $delivery_time;
                    $dataLincesns = gjdate($dataLincesns,"d M Y، H:i");
                    $body = '<div class="flex justify-between"> <div> محصول <a href="'.$product_permalink.'" target="_blank">'.$product_name.'</a> در سبد خرید شما به صورت <span class="pre-sale__span">پیش فروش</span> می‌باشد و تا '.$delivery_time.' ساعت آینده لایسنس آن تحویل شما داده می‌شود. </div> <div class="flex gap-2 s2ged"> <img class="w-[87px]" src="'.$product_img.'" alt="'.$product_name.'"> <div class="c-badge rounded-sm badge-orange text-2xs -mt-1 flex flex-col"> <div>تا '.$dataLincesns.'</div> <div>لایسنس موجود میشود</div> </div> </div> </div>';
                    $id = NotificationModel::addNotification($user_id,'محصول پیش فروش در سبد خرید',$body);
                    UserModel::alert($user_id,$id);
                }else{
                    $manage_stock = get_post_meta($product_id, '_manage_stock', true);
                    if ($manage_stock == 'yes') {
                        $count =  ProductModel::available($product_id)['total'];
                        update_post_meta($product_id, '_stock', $count);
                        if($count >=1) {
                            update_post_meta($product_id, '_stock_status', 'instock');
                        }
                    }
                }
                $is_preorder = (
                    isset($delivery['two']) &&
                    $delivery['two'] === 'on'
                );
                if ($is_preorder) {
                    $has_preorder = true;
                    continue;
                }

                $requested = (int)$item['quantity'];

                try {

                    $db->query("START TRANSACTION");
                    $licences = LicenseModel::availableLicenses($product->get_id());

                    foreach ($licences as $licence){
                        $reserved_licence_ids[] = $licence['licence_id'];
                        LicenseModel::assignedSet($order_id,$licence['licence_id']);
                    }

                    $db->query("COMMIT");

                    if(count($licences) < $requested){

                        $hasIncompleteLicence = true;

                        $incompleteProducts[] = [
                            'product'   => $product->get_name(),
                            'requested' => $requested,
                            'assigned'  => count($licences)
                        ];
                    }

                }catch(Exception $e){

                    $db->query("ROLLBACK");
                    throw $e;

                }
                if (!empty($reserved_licence_ids) && is_array($reserved_licence_ids)) {
                    $item->update_meta_data(
                        '_reserved_licence_ids',
                        json_encode($reserved_licence_ids)
                    );
                    $item->save();
                }
            }
            if($has_preorder) {
                $orderId = $order->get_id();
                $fullname = $order->get_formatted_billing_full_name();
                self::sendSmsPreSale($orderId,implode('، ', $productData['names']),array_sum($productData['quantities']),$fullname);
            }
            if($hasIncompleteLicence){

                $order->update_meta_data('_giftmax_incomplete_licence', 1);
                $order->update_meta_data('_giftmax_incomplete_products', $incompleteProducts);
                $order->save();
                $note = "کمبود لایسنس:\n";

                foreach($incompleteProducts as $row){

                    $missing = $row['requested'] - $row['assigned'];

                    $note .= "{$row['product']} : {$row['assigned']} تحویل شد، {$missing} عدد موجود نبود.\n";
                }

                $order->add_order_note($note);
            }
            $paid_date = $order->get_date_paid();
            $paid_date_fa = $paid_date ? wp_date('Y-m-d H:i', $paid_date->getTimestamp()) : '-';
            self::suspiciousOrder($order);
            header('Content-Type: text/html; charset=utf-8');
            header("Refresh: 3; url=" . home_url('/profile/invoices/'  . $order_id));
            View::render("/inc/templates/template-parts/payment/success.php", ['gateway' => 'Payment4', 'paid_date_fa' => $paid_date_fa, 'order_number' => $order->get_order_number(), 'amount' => $order->get_total()]);
            exit;
        }
        elseif ($response && $response->result == 201){
            header('Content-Type: text/html; charset=utf-8');
            header("Refresh: 3; url=" . home_url('/profile/invoices/'  . $order_id));
            View::render("/inc/templates/template-parts/payment/verifed.php", ['gateway'=>'Payment4']);
            exit;
        }
    }
}
