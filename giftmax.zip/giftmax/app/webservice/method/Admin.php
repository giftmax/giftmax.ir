<?php

namespace Giftmax\webservice\method;


use Giftmax\model\SiteModel;
use Giftmax\model\UserModel;
use Giftmax\modules\Db;
use Giftmax\modules\LicenseManager;
use Giftmax\modules\View;

if (!defined('ABSPATH')) {
    exit;
}

class Admin{

    public function __construct(){
        add_action('rest_api_init', [$this, 'addApiRoutes']);
    }
    public function addApiRoutes(){
        register_rest_route( 'api/v3', '/searchCategory', array(
            'methods' => 'POST',
            'callback' => [$this, 'searchCategory_api_function'],
            'permission_callback' => function () {
                return is_current_user_admin();
            }
        ) );
        register_rest_route( 'api/v3', '/Save', array(
            'methods' => 'POST',
            'callback' => [$this, 'Save_api_function'],
            'permission_callback' => function () {
                return is_current_user_admin();
            }
        ) );
        register_rest_route( 'api/v3', '/scp', array(
            'methods' => 'POST',
            'callback' => [$this, 'scp_api_function'],
            'permission_callback' => function () {
                return is_current_user_admin();
            }
        ) );
        register_rest_route( 'api/v3', '/dt', array(
            'methods' => 'POST',
            'callback' => [$this, 'dt_api_function'],
            'permission_callback' => function () {
                return is_current_user_admin();
            }
        ) );
        register_rest_route( 'api/v3', '/ShowCategory', array(
            'methods' => 'POST',
            'callback' => [$this, 'ShowCategory_api_function'],
            'permission_callback' => function () {
                return is_current_user_admin();
            }
        ) );
        register_rest_route( 'api/v3', '/ShowCategoryProduct', array(
            'methods' => 'POST',
            'callback' => [$this, 'ShowCategoryProduct_api_function'],
            'permission_callback' => function () {
                return is_current_user_admin();
            }
        ) );
        register_rest_route( 'api/v3', '/verify', array(
            'methods' => 'POST',
            'callback' => [$this, 'verify_api_function'],
            'permission_callback' => function () {
                return is_current_user_admin();
            }
        ) );
        register_rest_route( 'api/v3', '/StoryVerify', array(
            'methods' => 'POST',
            'callback' => [$this, 'StoryVerify_api_function'],
            'permission_callback' => function () {
                return is_current_user_admin();
            }
        ) );
        register_rest_route( 'api/v3', '/ads', array(
            'methods' => 'POST',
            'callback' => [$this, 'ads_api_function'],
            'permission_callback' => function () {
                return is_current_user_admin();
            }
        ) );
        register_rest_route( 'api/v3', '/faq', array(
            'methods' => 'POST',
            'callback' => [$this, 'faqApiFunction'],
            'permission_callback' => function () {
                return is_current_user_admin();
            }
        ) );
        register_rest_route( 'api/v3', '/notifications', array(
            'methods' => 'POST',
            'callback' => [$this, 'notifications_api_function'],
            'permission_callback' => function () {
                return is_current_user_admin();
            }
        ) );
        register_rest_route( 'api/v3', '/send-notifications', array(
            'methods' => 'POST',
            'callback' => [$this, 'notifications_send_api_function'],
            'permission_callback' => function () {
                return is_current_user_admin();
            }
        ) );
        register_rest_route( 'api/v3', '/slider', array(
            'methods' => 'POST',
            'callback' => [$this, 'slider_api_function'],
            'permission_callback' => function () {
                return is_current_user_admin();
            }
        ) );
        register_rest_route( 'api/v3', '/searchLicense', array(
            'methods' => 'POST',
            'callback' => [$this, 'searchLicense_api_function'],
            'permission_callback' => function () {
                return is_current_user_admin();
            }
        ) );
        register_rest_route( 'api/v3', '/searchUser', array(
            'methods' => 'POST',
            'callback' => [$this, 'searchUser_api_function'],
            'permission_callback' => function () {
                return is_current_user_admin();
            }
        ) );
        register_rest_route( 'api/v3', '/balance', array(
            'methods' => 'POST',
            'callback' => [$this, 'balance_api_function'],
            'permission_callback' => function () {
                return is_current_user_admin();
            }
        ) );
        register_rest_route( 'api/v3', '/CartUser', array(
            'methods' => 'POST',
            'callback' => [$this, 'CartUser_api_function'],
            'permission_callback' => function () {
                return is_current_user_admin();
            }
        ) );
        register_rest_route( 'api/v3', '/searchCart', array(
            'methods' => 'POST',
            'callback' => [$this, 'searchCart_api_function'],
            'permission_callback' => function () {
                return is_current_user_admin();
            }
        ) );
        register_rest_route( 'api/v3', '/stp', array(
            'methods' => 'POST',
            'callback' => [$this, 'stp_api_function'],
            'permission_callback' => function () {
                return is_current_user_admin();
            }
        ) ); register_rest_route( 'api/v3', '/sso', array(
            'methods' => 'POST',
            'callback' => [$this, 'sso_api_function'],
            'permission_callback' => function () {
                return is_current_user_admin();
            }
        ) );
        register_rest_route( 'api/v3', '/GetUser', array(
            'methods' => 'POST',
            'callback' => [$this, 'get_user_api_function'],
            'permission_callback' => function () {
                return is_current_user_admin();
            }
        ) );
        register_rest_route( 'api/v3', '/delete-licence', array(
            'methods' => 'POST',
            'callback' => [$this, 'deleteLicence_api_function'],
            'permission_callback' => function () {
                return is_current_user_admin();
            }
        ) );
        register_rest_route( 'api/v3', '/license-document', array(
            'methods' => 'POST',
            'callback' => [$this, 'licenseDocument_api_function'],
            'permission_callback' => function () {
                return is_current_user_admin();
            }
        ) );
        register_rest_route( 'api/v3', '/add-license', array(
            'methods' => 'POST',
            'callback' => [$this, 'add_license_api_function'],
            'permission_callback' => function () {
                return is_current_user_admin();
            }
        ) );
        register_rest_route( 'api/v3', '/edit-description-license', array(
            'methods' => 'POST',
            'callback' => [$this, 'editDescriptionLicenseApiFunction'],
            'permission_callback' => function () {
                return is_current_user_admin();
            }
        ) );
        register_rest_route( 'api/v3', '/delete-license', array(
            'methods' => 'POST',
            'callback' => [$this, 'delete_license_api_function'],
            'permission_callback' => function () {
                return is_current_user_admin();
            }
        ) );
        register_rest_route( 'api/v3', '/update_licence_order', array(
                'methods' => 'POST',
                'callback' => [$this, 'update_licence_order_api_function'],
                'permission_callback' => function () {
                    return is_current_user_admin();
                }
        ));
        register_rest_route( 'api/v3', '/person', array(
                'methods' => 'POST',
                'callback' => [$this, 'personApiFunction'],
                'permission_callback' => function () {
                    return is_current_user_admin();
                }
        ));
        register_rest_route( 'api/v3', '/content', array(
                'methods' => 'POST',
                'callback' => [$this, 'contentApiFunction'],
                'permission_callback' => function () {
                    return is_current_user_admin();
                }
        ));

        register_rest_route( 'api/v3', '/send-sms', array(
                'methods' => 'POST',
                'callback' => [$this, 'sendSmsFunction'],
                'permission_callback' => function () {
                    return is_current_user_admin();
                }
        ));
        register_rest_route( 'api/v3', '/add-list', array(
                'methods' => 'POST',
                'callback' => [$this, 'addListFunction'],
                'permission_callback' => function () {
                    return is_current_user_admin();
                }
        ));
        register_rest_route( 'api/v3', '/delete-list-sms', array(
                'methods' => 'POST',
                'callback' => [$this, 'deleteListSmsFunction'],
                'permission_callback' => function () {
                    return is_current_user_admin();
                }
        ));
        register_rest_route( 'api/v3', '/delete-history-sms', array(
                'methods' => 'POST',
                'callback' => [$this, 'deleteHistorySmsFunction'],
                'permission_callback' => function () {
                    return is_current_user_admin();
                }
        ));
        register_rest_route( 'api/v3', '/search', array(
                'methods' => 'POST',
                'callback' => [$this, 'searchFunction'],
                'permission_callback' => function () {
                    return is_current_user_admin();
                }
        ));
        register_rest_route( 'api/v3', '/details-sms', array(
                'methods' => 'POST',
                'callback' => [$this, 'detailsSmsFunction'],
                'permission_callback' => function () {
                    return is_current_user_admin();
                }
        ));
        register_rest_route( 'api/v3', '/send', array(
                'methods' => 'POST',
                'callback' => [$this, 'sendFunction'],
                'permission_callback' => function () {
                    return is_current_user_admin();
                }
        ));
        register_rest_route( 'api/v3', '/list-wallet', array(
                'methods' => 'POST',
                'callback' => [$this, 'listWalletFunction'],
                'permission_callback' => function () {
                    return is_current_user_admin();
                }
        ));
        register_rest_route( 'api/v3', '/search-user-wallet', array(
                'methods' => 'POST',
                'callback' => [$this, 'searchUserWalletFunction'],
                'permission_callback' => function () {
                    return is_current_user_admin();
                }
        ));
        register_rest_route( 'api/v3', '/number-list', array(
                'methods' => 'POST',
                'callback' => [$this, 'numberListFunction'],
                'permission_callback' => function () {
                    return is_current_user_admin();
                }
        ));
        register_rest_route( 'api/v3', '/block', array(
                'methods' => 'POST',
                'callback' => [$this, 'blockFunction'],
                'permission_callback' => function () {
                    return is_current_user_admin();
                }
        ));
        register_rest_route( 'api/v3', '/img', array(
                'methods' => 'POST',
                'callback' => [$this, 'imgApiFunction'],
                'permission_callback' => function () {
                    return is_current_user_admin();
                }
        ));
        register_rest_route( 'api/v1', '/order', array(
                'methods' => 'GET',
                'callback' => [$this, 'orderApiFunction'],
                'permission_callback' => "__return_true"
        ));
    }
    public function orderApiFunction()
    {
        $order_id = $_GET['id'];

        if ($order_id <= 0) {
            wp_die('شناسه سفارش نامعتبر است.');
        }

        $url = admin_url('post.php?post=' . $order_id . '&action=edit');

        wp_safe_redirect($url);
    }
    public function imgApiFunction()
    {
        if(!empty($_POST['data'])){
            self::insert('img',json_encode($_POST['data']));
            echo json_encode(['status' => true]);
        }else{
            echo json_encode(['status' => false, 'message' => 'اطلاعاتی ارسال نشده']);
        }
    }
    public function blockFunction()
    {
        if (!isset($_POST['id'])) {
            echo json_encode(['status'=>'error','message'=>'دیتا کامل نیست']);
            exit();
        }
        $user_id = $_POST['id'];
        $blocked = !is_user_blocked($user_id);
        if ($blocked) {
            $user = get_user_by( 'id', $user_id );
            $baseUrl = "https://edge.ippanel.com/v1/api/send";
            $token = "wns0sWEioLyJejB0g0olFj-PVlL2Yt5O2G94prP-BXg=";

            $data = [
                    "sending_type" => "pattern",
                    "from_number" => "+985000125475",
                    "code" => "26768lo53r82yrk",
                    "recipients" => [$user->user_login],
                    "params" => [
                            "fullname" => $user->display_name,
                    ],
            ];

            $ch = curl_init($baseUrl);
            curl_setopt($ch, CURLOPT_HTTPHEADER, [
                    "Content-Type: application/json; charset=utf-8",
                    "Content-Type: application/json",
                    "Authorization: $token"
            ]);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data, JSON_UNESCAPED_UNICODE));

            $response = curl_exec($ch);
            curl_close($ch);
            $data = json_decode($response, true);
            if (!is_null($data['data'])) {
                echo json_encode(['status' => true]);
            }else{
                echo json_encode(['status' => true,'sms'=>'پیام ارسال نشد']);
            }
        }else{
            echo json_encode(['status' => true]);
        }
        update_user_meta( $user_id, 'blocked', $blocked );
    }
    public function listWalletFunction(){
        $users = get_users();
        $html = '<label class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--L7bcQ uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--normal--A6Ntt text-body-1 color-n-700 w-100">
    <p class="mb-2 color-n-700 text-body-1 mb-2" data-testid="form-label">نام و نام خانوادگی یا شماره موبایل را وارد کن:</p>
    <div class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame__input-container--D5edN px-2 d-flex ai-center">
        <section class="grow-1 text-body-2-c"><input
                    class="px-2 TextField__input-_5fbdd text-subtitle w-100 TextField-e58168" type="text"
                    id="searchUserWallet"></section>
    </div>
</label>';
        $html .='<div id="html-js">';
        $html .= View::re("/inc/templates/setting/listwallet.php", ['users'=>$users,'method'=>'all']);
        $html .='</div>';
        echo json_encode(['status' => true,'html'=>$html]);

    }
    public function searchUserWalletFunction(){
        if (!isset($_POST['keyword'])){
            echo json_encode(['status'=>'error']);
            exit();
        }
        $keyword = sanitize_text_field($_POST['keyword']);

        $check_user = get_user_by('login', $keyword);

        if ($check_user) {

            $users = [$check_user];

        } else {

            $users = get_users([
                    'meta_query' => [
                            'relation' => 'OR',
                            [
                                    'key'     => 'first_name',
                                    'value'   => $keyword,
                                    'compare' => 'LIKE',
                            ],
                            [
                                    'key'     => 'last_name',
                                    'value'   => $keyword,
                                    'compare' => 'LIKE',
                            ],
                    ],
            ]);
        }
        $html = View::re("/inc/templates/setting/listwallet.php", ['users'=>$users,'method'=>'search']);
        echo json_encode(['status' => true,'html'=>$html]);

    }
    public function numberListFunction(){
        if (!isset($_POST['id'])) {
            echo json_encode(['status'=>'error','message'=>'دیتا کامل نیست']);
            exit();
        }
        $records = UserModel::tableSearch('sms_list_members','query',['list_id'=>$_POST['id']]);
        $html = View::re("/inc/templates/setting/number-list.php", ['records'=>$records]);
        echo json_encode(['status' => true,'html'=>$html]);

    }
    private static function sendSms($title,$text,$phones,$sTime)
    {
        global $wpdb;
        $db = Db::getLnstance();
        if (preg_match('/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/',$sTime)) {
            $jalali = $sTime;

            [$date, $time] = explode(' ', $jalali);
            [$jy, $jm, $jd] = explode('-', $date);
            [$gy, $gm, $gd] = jalaliToGregorian($jy, $jm, $jd);
            $gregorian = sprintf("%04d-%02d-%02d %s", $gy, $gm, $gd, $time);
        }else{
            $gregorian = date("Y-m-d H:i:s", strtotime("+2 minute"));
        }
        $db->insert("INSERT INTO `{$wpdb->prefix}sms_campaigns` (`id`, `title`,`type`, `message`, `total_count`, `sent_count`, `failed_count`, `created_at`,`send_at`) VALUES (NULL, :title,'پیامک عمومی',:message, '0', '0', '0', :created_at,:send_at)",array(
                'title' => 'ارسال پیام دوباره برای ' . $title,
                'message' => $text,
                'send_at' => $gregorian,
                'created_at' => date('Y-m-d H:i:s')
        ));
        $campaign_id = $db->lastInsertId();
        $total_count = $sent_count = $failed_count = 0;

        foreach ($phones as $phone) {
            $db->insert("INSERT INTO `{$wpdb->prefix}sms_campaign_recipients` (`id`, `campaign_id`, `phone`, `status`, `sent_at`, `error_message`) VALUES (NULL, :campaign_id, :phone, 'pending', :sent_at, NULL)",array(
                    'campaign_id' => $campaign_id,
                    'phone' => $phone,
                    'sent_at' => date('Y-m-d H:i:s')
            ));
            $total_count++;
        }
        $db->modify("UPDATE `{$wpdb->prefix}sms_campaigns` SET `total_count`=:total_count,`sent_count` = :sent_count,`failed_count`=:failed_count WHERE `id` = :id",array(
                'total_count' => $total_count,
                'sent_count' => $sent_count,
                'failed_count' => $failed_count,
                'id' => $campaign_id
        ));
    }
    public function sendFunction(){
        if (!isset($_POST['id']) || !isset($_POST['method'])|| !isset($_POST['time'])){
            echo json_encode(['status'=>'error','message'=>'دیتا کامل نیست']);
            exit();
        }
        $method = $_POST['method'];
        $time = $_POST['time'];
        $id  = $_POST['id'];
        $sms = UserModel::tableSearch('sms_campaigns','first',['id'=>$id]);
        if (empty($sms)){
            echo json_encode(['status'=>false,'message'=>'این پیام پیدا نشد']);
            exit();
        }
        if ($method == 'all'){
            $records = UserModel::tableSearch('sms_campaign_recipients','query',['campaign_id'=>$id]);
            if (empty($records)){
                echo json_encode(['status'=>false,'message'=>' کاربری پیدا نشد پیدا نشد']);
                exit();
            }
            $phone = [];
            foreach ($records as $record){
                $phone[] = $record['phone'];
            }
            self::sendSms( $sms['title'] . ' همۀّ کاربران ',$sms['message'],$phone,$time);
        }elseif ($method == 'sent'){
            $records = UserModel::tableSearch('sms_campaign_recipients','query',['campaign_id'=>$id,'status'=>'sent']);
            if (empty($records)){
                echo json_encode(['status'=>false,'message'=>' کاربری پیدا نشد پیدا نشد']);
                exit();
            }
            $phone = [];
            foreach ($records as $record){
                $phone[] = $record['phone'];
            }
            self::sendSms($sms['title'] . "فقط کاربرانی که قبلا پیام براشون ارسال شده بود",$sms['message'],$phone,$time);
        }elseif ($method == 'failed'){
            $records = UserModel::tableSearch('sms_campaign_recipients','query',['campaign_id'=>$id,'status'=>'failed']);
            if (empty($records)){
                echo json_encode(['status'=>false,'message'=>' کاربری پیدا نشد پیدا نشد']);
                exit();
            }
            $phone = [];
            foreach ($records as $record){
                $phone[] = $record['phone'];
            }
            self::sendSms($sms['title'] . "فقط کاربرانی که قبلا پیام براشون ارسال نشده بود",$sms['message'],$phone,$time);
        }else{
                echo json_encode(['status'=>false,'message'=>'درخواست نامعتبر']);
                exit();
        }
        echo json_encode(['status'=>true]);
    }
    public function detailsSmsFunction(){
        if (!isset($_POST['id'])){
            echo json_encode(['status'=>'error','message'=>'دیتا کامل نیست']);
            exit();
        }
        $db = Db::getLnstance();
        global $wpdb;
        $sms = $db->first("SELECT * FROM `{$wpdb->prefix}sms_campaigns` WHERE `id` = :id",array('id' => $_POST['id']));
        ob_start();
        ?>
        <div class="cer_pup_show_body">
            <div class="show_information">
                <div class="border-1 border-solid border-blue-gray-50 border-radius-lg padding-5 margin-bottom-4">
                    <div class="font-size-16 font-weight-regular text-gray-800 padding-bottom-3">
                        اطلاعات کامل
                    </div>
                    <div class="flex  flex-col gap-3 margin-y-2 padding-y-1">
                        <div class="font-size-14 font-weight-regular text-blue-gray-700">تیتر</div>
                        <div class="font-size-14 font-weight-heavy text-blue-gray-900"><?= $sms['title'] ?></div>
                    </div>
                    <div class="flex align-items-center justify-content-space-between margin-y-2 padding-y-1">
                        <div class="font-size-14 font-weight-regular text-blue-gray-700">تاریخ ثبت </div>
                        <div class="font-size-14 font-weight-heavy text-blue-gray-900" dir="ltr"><?= gjdate($sms['created_at'],"Y-m-d H:i") ?></div>
                    </div>
                    <div class="flex align-items-center justify-content-space-between margin-y-2 padding-y-1">
                        <div class="font-size-14 font-weight-regular text-blue-gray-700">تعداد شماره ها</div>
                        <div class="font-size-14 font-weight-heavy text-blue-gray-900"><?= $sms['total_count'] ?></div>
                    </div>
                    <div class="flex align-items-center justify-content-space-between margin-y-2 padding-y-1">
                        <div class="font-size-14 font-weight-regular text-blue-gray-700">تعداد ارسال های موفق</div>
                        <div class="font-size-14 font-weight-heavy text-blue-gray-900"><?= $sms['sent_count'] ?></div>
                    </div>
                    <div class="flex align-items-center justify-content-space-between margin-y-2 padding-y-1">
                        <div class="font-size-14 font-weight-regular text-blue-gray-700">تعداد ارسال های ناموفق</div>
                        <div class="font-size-14 font-weight-heavy text-blue-gray-900"><?= $sms['failed_count'] ?></div>
                    </div>
                </div>
                <div class="border-1 border-solid border-blue-gray-50 border-radius-lg padding-5 margin-bottom-4">
                    <div class="font-size-16 font-weight-regular text-gray-800 padding-bottom-3">
                        پیام ارسال شده
                    </div>
                    <?=nl2br(htmlspecialchars($sms['message']))?>
                </div>
            </div>
            <div class="show_image_cer">
                <div class="justify-content border-1 border-solid border-blue-gray-50 border-radius-lg padding-5">
                    <?php
                    $records = $db->query("SELECT * FROM `{$wpdb->prefix}sms_campaign_recipients` WHERE `campaign_id` = :campaign_id AND `status`='failed'",array('campaign_id' => $sms['id']));
                        ?>
                            <div class="font-size-16 font-weight-regular text-gray-800 padding-bottom-3">
                                شماره هایی که پیام بهشون ارسال نشده
                            </div>
                    <div>
                        <div class="c-bills__header">
                            <div class="b-bills bills_number">ردیف</div>
                            <div class="b-bills purchase_date">شماره</div>
                            <div class="b-bills bills_name">توضیحات ارور</div>
                        </div>
                            <?php
                            if (!empty($records)){
                            foreach ($records as $key=>$record) {?>
                                <div class="c-bills__body">
                                    <div class="b-bills bills_number">
                                        <span class="c-number"><?=$key+1?></span>
                                    </div>
                                    <div class="b-bills purchase_date">
                                        <span class="c-color"><?=$record['phone']?></span>
                                    </div>
                                    <div class="b-bills bills_name">
                                        <span class="c-color"><?=$record['error_message']?></span>
                                    </div>
                                </div>
                                <?php
                            }
                            }else{?>
                                <div class="c-bills__body">
                                    <div class="b-bills w-full">
                                        <span class="c-color">هیچ دیتایی وجود نداره</span>
                                    </div>
                                </div>
                            <?php }
                            ?>
                    </div>
                    <div class="flex">
                        <div class="flex gap-3 w-70" style="align-items: flex-start;">
                            <div class="c-view Button-sf56" data-id="<?=$sms['id']?>">ارسال فقط به ناموفق ها</div>
                            <div class="c-view Button-ss94" data-id="<?=$sms['id']?>">ارسال فقط به موفق ها</div>
                            <div class="c-view Button-sa64" data-id="<?=$sms['id']?>">ارسال پیام به همه</div>
                        </div>
                        <label class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--L7bcQ uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--normal--A6Ntt text-body-1 color-n-700 w-30">
                            <p class="mb-2 color-n-700 text-body-1 mb-2" data-testid="form-label"> زمان دلخواه ارسال (خالی بودن مساوی با ارسال آنی)</p>
                            <div class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame__input-container--D5edN px-2 d-flex ai-center">
                                <section class="grow-1 text-body-2-c">
                                    <input class="px-2 TextField__input-_5fbdd text-subtitle w-100 TextField-e58168" type="text" id="d-time" placeholder="1405-05-01 21:20:00" dir="ltr">
                                </section>
                            </div>
                        </label>
                    </div>
                </div>
            </div>
        </div>
        <?php
        $output = ob_get_clean();

        echo json_encode($output);
    }

    public function deleteHistorySmsFunction(){
        if (!isset($_POST['id'])){
            echo json_encode(['status'=>'error','message'=>'دیتا کامل نیست']);
            exit();
        }
        global $wpdb;
        $db = Db::getLnstance();
        $record = $db->first("SELECT id FROM {$wpdb->prefix}sms_campaigns WHERE id = :id",["id"=>$_POST['id']]);
        if (!empty($record)){
            $db->modify("DELETE FROM `{$wpdb->prefix}sms_campaigns` WHERE id = :id",["id"=>$_POST['id']]);
            echo json_encode(['status'=>true]);
        }else{
            echo json_encode(['status'=>false]);
        }
    }
    public function searchFunction(){
        if (!isset($_POST['key'])){
            echo json_encode(['status'=>'error','message'=>'دیتا کامل نیست']);
            exit();
        }
        global $wpdb;
        $db = \Giftmax\modules\Db::getLnstance();
        $records = $db->query("SELECT * FROM `{$wpdb->prefix}sms_lists` WHERE `name` LIKE :key",array('key'=>'%'.$_POST['key'].'%'));
        ob_start();
        if (!empty($records)){
        foreach ($records as $key=>$record) {
        ?>
        <div class="c-bills__body">
            <div class="b-bills w-30">
                <span class="c-number"><?=$key+1?></span>
            </div>
            <div class="b-bills bills_name">
                <div class="c-color"><?=$record['name']?></div>
            </div>
            <div class="b-bills w-30">
                <div class="c-view Button-swl64" data-id="<?=$record['id']?>">انتخاب</div>
            </div>
        </div>
        <?php
        }
        }else{
            ?>
            <div class="c-bills__body">
                <div class="b-bills w-full">
                    <span class="c-color">چیزی پیدا نشد</span>
                </div>
            </div>
                <?php
        }
        $output = ob_get_clean();
        echo json_encode(['status'=>true,'html'=>$output]);
    }
    public function deleteListSmsFunction(){
        if (!isset($_POST['id'])){
            echo json_encode(['status'=>'error','message'=>'دیتا کامل نیست']);
            exit();
        }
        global $wpdb;
        $db = Db::getLnstance();
        $record = $db->first("SELECT id FROM {$wpdb->prefix}sms_lists WHERE id = :id",["id"=>$_POST['id']]);
        if (!empty($record)){
            $db->modify("DELETE FROM `{$wpdb->prefix}sms_lists` WHERE id = :id",["id"=>$_POST['id']]);
            echo json_encode(['status'=>true]);
        }else{
            echo json_encode(['status'=>false]);
        }
    }

    public function addListFunction()
    {
        if (!isset($_POST['title']) && !isset($_POST['numbers'])){
            echo json_encode(['status'=>'error','message'=>'دیتا ها کامل نیست']);
            exit();
        }
        global $wpdb;
        $db = Db::getLnstance();
        $db->insert("INSERT INTO `{$wpdb->prefix}sms_lists` (`id`, `name`, `created_at`) VALUES (NULL, :name, :created_at)",array(
                'name' => $_POST['title'],
                'created_at' => date('Y-m-d H:i:s')
        ));
        $list_id = $db->lastInsertId();
        $numbers = $_POST['numbers'];
        if (empty($numbers)){
            echo json_encode(['status'=>false,'message'=>'شماره ای ارسال نشده']);
            exit();
        }
        $numbers = explode("\n", $numbers);
        foreach ($numbers as $number) {
            if (!preg_match('/^09\d{9}$/', $number)) continue;
            $db->insert("INSERT INTO `{$wpdb->prefix}sms_list_members` (`id`, `list_id`, `phone`, `created_at`) VALUES (NULL, :list_id, :phone, :created_at)",array(
                    'list_id' => $list_id,
                    'phone' => $number,
                    'created_at' => date('Y-m-d H:i:s')
            ));
        }
        $records = $db->query("SELECT * FROM `{$wpdb->prefix}sms_lists` ORDER BY created_at DESC ");
        ob_start();
        foreach ($records as $key=>$record) {
            ?>
            <div class="c-bills__body">
                <div class="b-bills bills_number">
                    <span class="c-number"><?=$key+1?></span>
                </div>
                <div class="b-bills bills_name">
                    <div class="c-color"><?=$record['name']?></div>
                </div>
                <div class="b-bills purchase_date"><div class="c-color"><?=gjdate($record['created_at'],"Y-m-d H:i")?></div> </div>
                <div class="b-bills purchase_date flex gap-3">
                    <div class="c-view Button-sln89" data-id="<?=$record['id']?>">مشاهده</div>
                    <div class="c-view Button-dl54" data-id="<?=$record['id']?>">حذف</div>
                </div>
            </div>
        <?php
        }
        $output = ob_get_clean();
        echo json_encode(['status'=>true,'html'=>$output]);
    }
    public function sendSmsFunction()
    {
        if ($_POST['method'] == 'test'){
            $message = render_message_variables($_POST['content'], '09372821372');
            $result = sendSms('09372821372', $message);
            if (is_null($result->data)){
                $json = ['status'=>false,'message'=>$result->meta->message];
            }else{
                $json = ['status'=>true];
            }
        }elseif ($_POST['method'] == 'all'){
            global $wpdb;
            $db = Db::getLnstance();
            if (!empty($_POST['time']) && preg_match('/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}$/',$_POST['time'])) {
                $jalali = $_POST['time'];
                [$date, $time] = explode(' ', $jalali);
                [$jy, $jm, $jd] = explode('-', $date);
                [$gy, $gm, $gd] = jalaliToGregorian($jy, $jm, $jd);
                $gregorian = sprintf("%04d-%02d-%02d %s", $gy, $gm, $gd, $time);
            }else {
                $gregorian = date("Y-m-d H:i:s", strtotime("+2 minute"));
            }
            $db->insert("INSERT INTO `{$wpdb->prefix}sms_campaigns` (`id`, `title`,`type`, `message`, `total_count`, `sent_count`, `failed_count`, `created_at`,`send_at`) VALUES (NULL, :title, 'پیامک عمومی' ,:message, '0', '0', '0', :created_at,:send_at)",array(
                    'title' => $_POST['title'],
                'message' => $_POST['content'],
                'send_at' =>$gregorian,
                'created_at' => date('Y-m-d H:i:s')
            ));
            $campaign_id = $db->lastInsertId();
            $phones = [];
            if (isset($_POST['user']) && $_POST['user'] === 'true') {
                $users = get_users(array('fields' => array('user_login')));
                foreach ($users as $user) {
                    $phones[] = $user->user_login;
                }
            }
            if (!empty($_POST['listwhite']) && is_numeric($_POST['listwhite'])) {
                $id = $_POST['listwhite'];
                $wList = $db->first("SELECT * FROM `{$wpdb->prefix}sms_lists` WHERE `id`=:id",array('id'=>$id));
                if (!empty($wList)) {
                    $records = $db->query("SELECT phone FROM `{$wpdb->prefix}sms_list_members` WHERE `list_id`=:list_id",array('list_id'=>$wList['id']));
                    if (!empty($records)) {
                        $include_phones = [];
                        foreach ($records as $record) {
                            $include_phones[] = $record['phone'];
                        }
                        $phones = array_merge($phones, $include_phones);
                    }
                }
            }


            // حذف تکراری ها
            $phones = array_unique($phones);


            if (!empty($_POST['listblock']) && is_numeric($_POST['listblock'])) {
                $id = $_POST['listblock'];
                $bList = $db->first("SELECT * FROM `{$wpdb->prefix}sms_lists` WHERE `id`=:id",array('id'=>$id));
                if (!empty($bList)) {
                    $records = $db->query("SELECT phone FROM `{$wpdb->prefix}sms_list_members` WHERE `list_id`=:list_id",array('list_id'=>$bList['id']));
                    if (!empty($records)) {
                        $exclude_phones = [];
                        foreach ($records as $record) {
                            $exclude_phones[] = $record['phone'];
                        }
                        // شماره های بلاک شده
                        $phones = array_diff($phones, $exclude_phones);
                    }
                }
            }
            $phones = array_values($phones);
            $total_count = 0;

            foreach ($phones as $phone) {
                $db->insert("INSERT INTO `{$wpdb->prefix}sms_campaign_recipients` (`id`, `campaign_id`, `phone`, `status`, `sent_at`, `error_message`) VALUES (NULL, :campaign_id, :phone, 'pending', :sent_at, NULL)",array(
                        'campaign_id' => $campaign_id,
                        'phone' => $phone,
                        'sent_at' => date('Y-m-d H:i:s')
                ));
                $total_count++;
            }
            $db->modify("UPDATE `{$wpdb->prefix}sms_campaigns` SET `total_count`=:total_count,`sent_count` = :sent_count,`failed_count`=:failed_count WHERE `id` = :id",array(
                    'total_count' => $total_count,
                    'sent_count' => 0,
                    'failed_count' => 0,
                    'id' => $campaign_id
            ));
            $json = ['status'=>true];
        }else{
            $json = ['status'=>false,'message'=>"متد درستی انتخاب نشده"];
        }
        echo json_encode($json);
    }
    public function contentApiFunction()
    {
        $db = Db::getLnstance();
        global $wpdb;
        $records = $db->first("SELECT meta_value FROM `{$wpdb->prefix}setting` WHERE `meta_key`=:key",array('key'=>'description'));
        echo json_encode(['content' => !empty($records) ? $records['meta_value']: '']);
    }
    public function personApiFunction()
    {
        if (!isset($_POST['query'])){
            echo json_encode(['status'=>false,'message'=>'دیتا کامل نیست']);
            exit();
        }
        $users = new \WP_User_Query([
                'meta_query' => [
                        'relation' => 'OR',

                        [
                                'key'     => 'first_name',
                                'value'   => $_POST['query'],
                                'compare' => 'LIKE',
                        ],

                        [
                                'key'     => 'last_name',
                                'value'   => $_POST['query'],
                                'compare' => 'LIKE',
                        ]
                ],
                'fields' => ['ID', 'display_name', 'user_login'],
                'number' => 20,
        ]);
        if (count($users->get_results()) > 0){
            foreach ($users->get_results() as $user) {
                ob_start();
                ?>
                <div style=" display: flex; width: 29%; margin-top: 10px; padding: 10px; border: 1px solid #ccc; border-radius: 16px; "><div style="width: 80%;display: flex; align-items: center;"><?="$user->display_name"?></div><div class="select-user" style="background-color: #f1f1f1;width: 20%;display: flex;justify-content: center;align-items: center;border-radius: 10px;color: #000000;padding: 5px;font-weight: 700;cursor: pointer;" data-id="<?=$user->ID?>">انتخاب</div></div>
                <div style=" display: flex; width: 29%; margin-top: 10px; padding: 10px; border: 1px solid #ccc; border-radius: 16px; "><div style="width: 80%;display: flex; align-items: center;"><?="$user->display_name"?></div><div class="select-user" style="background-color: #f1f1f1;width: 20%;display: flex;justify-content: center;align-items: center;border-radius: 10px;color: #000000;padding: 5px;font-weight: 700;cursor: pointer;" data-id="<?=$user->ID?>">انتخاب</div></div>
                <div style=" display: flex; width: 29%; margin-top: 10px; padding: 10px; border: 1px solid #ccc; border-radius: 16px; "><div style="width: 80%;display: flex; align-items: center;"><?="$user->display_name"?></div><div class="select-user" style="background-color: #f1f1f1;width: 20%;display: flex;justify-content: center;align-items: center;border-radius: 10px;color: #000000;padding: 5px;font-weight: 700;cursor: pointer;" data-id="<?=$user->ID?>">انتخاب</div></div>
                <?php
                $html = ob_get_clean();
                echo json_encode(['status'=>true,'html'=>$html]);
            }
        }else{
            echo json_encode(['status'=>false,'message'=>'یافت نشد']);
        }
    }
    public function update_licence_order_api_function(){
        $cookie_token = $_COOKIE['my_product_access'] ?? '';

        $fingerprint = hash(
                'sha256',
                ($_SERVER['HTTP_USER_AGENT'] ?? '') .
                ($_SERVER['HTTP_ACCEPT_LANGUAGE'] ?? '') .
                ($_SERVER['HTTP_SEC_CH_UA_PLATFORM'] ?? '')
        );

        $expected_token = hash_hmac(
                'sha256',
                $fingerprint,
                MY_PRODUCT_SECURITY_PASSWORD
        );

        $is_valid_token = hash_equals(
                $expected_token,
                $cookie_token
        );

        $is_active = get_transient(
                'giftmax_product_token_' . $cookie_token
        );

        if (!$is_valid_token || !$is_active) {
            wp_send_json_error([
                    'message' => 'زمان لاگین پسورد محصولات تموم شده!'
            ]);
        }
        global $wpdb;
        $db = Db::getLnstance();

        foreach ($_POST['order'] as $item) {

            $secureId = $item['id'];
            $newSort = intval($item['sort_order']);

            $licence_id = $db->first("SELECT licence_id FROM {$wpdb->prefix}product_licences WHERE LEFT(SHA2(CONCAT(licence_id, 'SALT_RANDOM_STRING'), 256), 16) = :secureId", array('secureId' => $secureId));
            if (!empty($licence_id)) {
                $db->modify("UPDATE {$wpdb->prefix}product_licences SET sort_order = :sort_order WHERE licence_id = :licence_id",array(
                        'sort_order' => $newSort,
                        'licence_id' => $licence_id['licence_id'],
                ));
            }
        }

    }

    public function delete_license_api_function()
    {
        if (!isset($_POST['id']) && !isset($_POST['method'])){
            echo json_encode(['status'=>'error','message'=>'دیتا ها کامل نیست']);
            exit();
        }
        $cookie_token = $_COOKIE['my_product_access'] ?? '';

        $fingerprint = hash(
                'sha256',
                ($_SERVER['HTTP_USER_AGENT'] ?? '') .
                ($_SERVER['HTTP_ACCEPT_LANGUAGE'] ?? '') .
                ($_SERVER['HTTP_SEC_CH_UA_PLATFORM'] ?? '')
        );

        $expected_token = hash_hmac(
                'sha256',
                $fingerprint,
                MY_PRODUCT_SECURITY_PASSWORD
        );

        $is_valid_token = hash_equals(
                $expected_token,
                $cookie_token
        );

        $is_active = get_transient(
                'giftmax_product_token_' . $cookie_token
        );

        if (!$is_valid_token || !$is_active) {
            wp_redirect(
                    admin_url(
                            'post.php?post='.$_POST['product_id']
                    )
            );
            exit;
        }
        global $wpdb;
        $db = \Giftmax\modules\Db::getLnstance();
        if ($_POST['method'] == 'single') {
            $licence = $db->first("SELECT licence_id,product_id FROM {$wpdb->prefix}product_licences WHERE LEFT(SHA2(CONCAT(licence_id, 'SALT_RANDOM_STRING'), 256), 16) = :secureId", array('secureId' => $_POST['id']));
            if (empty($licence)) {
                echo json_encode(['status' => false, 'message' => 'لایسنس یافت نشد']);
                exit();
            }
            $delete = $db->modify("DELETE FROM {$wpdb->prefix}product_licences WHERE licence_id = :id", array('id' => $licence['licence_id']));
            if (!$delete) {
                echo json_encode(['status' => false, 'message' => 'خطا در حذف لایسنس']);
            }
            $manage_stock = get_post_meta($licence['product_id'], '_manage_stock', true);
            if ($manage_stock == 'yes') {
                $count = $db->first("SELECT COUNT(*) AS total FROM `{$wpdb->prefix}product_licences` WHERE product_id = :product_id AND licence_status = 'available'",array('product_id'=>$licence['product_id']))['total'];
                update_post_meta($licence['product_id'], '_stock', $count);
                if ($count >=1){
                    update_post_meta($_POST['product_id'], '_stock_status', 'instock');
                }
                echo json_encode(['status' => true, 'message' => 'لایسنس با موفقیت حذف شد','count'=>$count]);
            }else{
                echo json_encode(['status' => true, 'message' => 'لایسنس با موفقیت حذف شد']);
            }
        }elseif ($_POST['method'] == 'double') {
            foreach ($_POST['id'] as $item) {
                $licence = $db->first("SELECT licence_id,product_id FROM {$wpdb->prefix}product_licences WHERE LEFT(SHA2(CONCAT(licence_id, 'SALT_RANDOM_STRING'), 256), 16) = :secureId", array('secureId' => $item));
                if (empty($licence)) {
                    echo json_encode(['status' => false, 'message' => 'لایسنس یافت نشد']);
                    exit();
                }
                $delete = $db->modify("DELETE FROM {$wpdb->prefix}product_licences WHERE licence_id = :id", array('id' => $licence['licence_id']));
                if (!$delete) {
                    echo json_encode(['status' => false, 'message' => 'خطا در حذف لایسنس']);
                }
            }
            $manage_stock = get_post_meta($licence['product_id'], '_manage_stock', true);
            if ($manage_stock == 'yes') {
                $count = $db->first("SELECT COUNT(*) AS total FROM `{$wpdb->prefix}product_licences` WHERE product_id = :product_id AND licence_status = 'available'",array('product_id'=>$licence['product_id']))['total'];
                update_post_meta($licence['product_id'], '_stock', $count);
                if ($count >=1){
                    update_post_meta($_POST['product_id'], '_stock_status', 'instock');
                }
                echo json_encode(['status' => true, 'message' => 'لایسنس با موفقیت حذف شد','count'=>$count]);
            }else{
                echo json_encode(['status' => true, 'message' => 'لایسنس با موفقیت حذف شد']);
            }
        }

    }
    public function add_license_api_function()
    {
        if (!isset($_POST['product_id']) && (!isset($_POST['data']) || !isset($_POST['licences']))){
            wp_send_json_error([
                    'message' => 'اطلاعات ناقص هست'
            ]);
        }
        $cookie_token = $_COOKIE['my_product_access'] ?? '';

        $fingerprint = hash(
                'sha256',
                ($_SERVER['HTTP_USER_AGENT'] ?? '') .
                ($_SERVER['HTTP_ACCEPT_LANGUAGE'] ?? '') .
                ($_SERVER['HTTP_SEC_CH_UA_PLATFORM'] ?? '')
        );

        $expected_token = hash_hmac(
                'sha256',
                $fingerprint,
                MY_PRODUCT_SECURITY_PASSWORD
        );

        $is_valid_token = hash_equals(
                $expected_token,
                $cookie_token
        );

        $is_active = get_transient(
                'giftmax_product_token_' . $cookie_token
        );

        if (!$is_valid_token || !$is_active) {
            wp_redirect(
                    admin_url(
                            'post.php?post='.$_POST['product_id']
                    )
            );
            exit;
        }
        if (isset($_POST['data'])) {
            $data = $_POST['data'];
            foreach ($data as $value) {
                if (isset($value['license'])) {
                    LicenseManager::license($_POST['product_id'], $value['license'], $value['price'], $value['description']);
                }
            }
        }
        if (isset($_POST['licences'])) {
            if (!empty($_POST['licences'])) {
                $licences = explode("\n", $_POST['licences']);
                foreach ($licences as $value) {
                    $p = explode('|||', $value);
                    if (!empty($p[0])) {
                        LicenseManager::license($_POST['product_id'], $p[0], $p[1], $p[2]);
                    }else{
                        LicenseManager::license($_POST['product_id'], $p[0], $p[1], $p[2]);
                    }
                }
            }
        }
        global $wpdb;
        $db = Db::getLnstance();
        ob_start();
        $records = LicenseManager::AdminLicense($_POST['product_id']);
        if (!empty($records)){
            foreach ($records as $key=>$record){
                $secureId = substr(hash('sha256', $record['licence_id'] . 'SALT_RANDOM_STRING'), 0, 16);
                ?>
                <div class="c-bills__body" data-id="<?= $secureId; ?>" data-order="<?= $record['sort_order']; ?>">
                    <label class="label__checkbox">
                        <input type="checkbox" value="<?=$secureId?>" class="d-none">
                        <div class="div__checkbox"></div>
                    </label>
                    <div class="b-bills bills_number">
                        <span class="c-number"><?=$key+1?></span></div>
                    <div class="b-bills bills_name">
                        <?php
                        if (!is_null($record['file_id'])){
                            $file = \Giftmax\model\SiteModel::table('product_licences_file','file_id',$record['file_id']);

                            $relative_path = ltrim(str_replace(ABSPATH, '', $file['url']), '/');
                            ?>
                            <div class="c-color download-file" data-url="<?=$relative_path?>"><?=$file['name']?></div>
                            <?php
                        }else{
                            ?>
                            <div class="c-color"><?=decrypt_data($record['licence_code'])?></div>
                            <?php
                        }
                        ?>
                    </div>
                    <div class="b-bills purchase_date">
                        <div class="c-color"><?=gjdate($record['created_at'],'Y/m/d H:i')?></div>
                    </div>
                    <div class="b-bills  bills_pay">
                        <div class="c-color"><?=number_format($record['cost_price'])?></div>
                    </div>
                    <div class="b-bills bills_description flex justify-center">
                        <?php
                        if (!empty($record['description'])){?>
                            <div class="btn-cta Button-sd45" data-description="<?=$record['description']?>">نمایش</div>
                        <?php }else{
                            echo "-";
                        }
                        ?>
                    </div>
                    <div class="b-bills bills_orders" style=" margin: 0 6px; ">
                        <div class="c-view vv-top"></div>
                        <div class="c-view vv1"></div>
                        <div class="c-view vv2"></div>
                        <div class="c-view vv-bottom"></div>
                    </div>
                    <div class="b-bills bills_delete">
                        <div class="btn-cta Button-dl45" data-id="<?=$secureId?>">حذف</div>
                    </div>
                </div>
                <?php
            }
        }
        $output = ob_get_clean();
        $manage_stock = get_post_meta($_POST['product_id'], '_manage_stock', true);
        if ($manage_stock == 'yes') {
            $count = $db->first("SELECT COUNT(*) AS total FROM `{$wpdb->prefix}product_licences` WHERE product_id = :product_id AND licence_status = 'available'",array('product_id'=>$_POST['product_id']))['total'];
            update_post_meta($_POST['product_id'], '_stock', $count);
            if ($count >=1){
                update_post_meta($_POST['product_id'], '_stock_status', 'instock');
            }
            echo json_encode(['status' => true,'output'=>$output,'count'=>$count]);
        }else{
            echo json_encode(['status' => true,'output'=>$output]);
        }
    }
    public function editDescriptionLicenseApiFunction()
    {
        if (!isset($_POST['id']) || (!isset($_POST['content']))){
            wp_send_json_error([
                    'message' => 'اطلاعات ناقص هست'
            ]);
        }
        $cookie_token = $_COOKIE['my_product_access'] ?? '';

        $fingerprint = hash(
                'sha256',
                ($_SERVER['HTTP_USER_AGENT'] ?? '') .
                ($_SERVER['HTTP_ACCEPT_LANGUAGE'] ?? '') .
                ($_SERVER['HTTP_SEC_CH_UA_PLATFORM'] ?? '')
        );

        $expected_token = hash_hmac(
                'sha256',
                $fingerprint,
                MY_PRODUCT_SECURITY_PASSWORD
        );

        $is_valid_token = hash_equals(
                $expected_token,
                $cookie_token
        );

        $is_active = get_transient(
                'giftmax_product_token_' . $cookie_token
        );

        if (!$is_valid_token || !$is_active) {
            wp_send_json_error([
                    'message' => 'زمان لاگین پسورد محصولات تموم شده!'
            ]);
        }
        global $wpdb;
        $db = DB::getLnstance();
        $licence_id = $db->first("SELECT licence_id FROM {$wpdb->prefix}product_licences WHERE LEFT(SHA2(CONCAT(licence_id, 'SALT_RANDOM_STRING'), 256), 16) = :secureId", array('secureId' => $_POST['id']));
        if (!empty($licence_id)) {
            $db->modify("UPDATE {$wpdb->prefix}product_licences SET description = :description WHERE licence_id = :licence_id",array(
                    'description' => $_POST['content'],
                    'licence_id' => $licence_id['licence_id'],
            ));
            echo json_encode(['status' => true]);
        }else{
            echo json_encode(['status' => false]);
        }
    }
    public function licenseDocument_api_function()
    {
        if (!isset($_POST['product_id']) && !isset($_POST['meta'])){
            wp_send_json_error([
                    'message' => 'اطلاعات ناقص هست'
            ]);
        }
        $cookie_token = $_COOKIE['my_product_access'] ?? '';
        $fingerprint = hash(
                'sha256',
                ($_SERVER['HTTP_USER_AGENT'] ?? '') .
                ($_SERVER['HTTP_ACCEPT_LANGUAGE'] ?? '') .
                ($_SERVER['HTTP_SEC_CH_UA_PLATFORM'] ?? '')
        );

        $expected_token = hash_hmac(
                'sha256',
                $fingerprint,
                MY_PRODUCT_SECURITY_PASSWORD
        );

        $is_valid_token = hash_equals(
                $expected_token,
                $cookie_token
        );

        $is_active = get_transient(
                'giftmax_product_token_' . $cookie_token
        );

        if (!$is_valid_token || !$is_active) {
            wp_send_json_error([
                    'message' => 'زمان لاگین پسورد محصولات تموم شده!'
            ]);
        }
        $product_id = $_POST['product_id'];
        $upload_dir = wp_upload_dir();
        $tmp_name = $_FILES['attachment']['tmp_name'];
        $name     = $_FILES['attachment']['name'];
        $ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));
        $allowed_ext = ['zip', 'rar'];
        if (!in_array($ext, $allowed_ext, true)) {
            wp_send_json_error([
                    'message' => 'فقط فایل‌های ZIP و RAR مجاز هستند.'
            ]);
        }
        $hash = generateHash(5);

        $folder = $upload_dir['path'] . '/' . $hash;

        if (!file_exists($folder)) {
            mkdir($folder, 0755, true);
        }
        $destination = $folder . '/' . $name;
        move_uploaded_file($tmp_name, $destination);
        $meta = json_decode(stripslashes($_POST['meta']), true);
        $password = $meta['pass'] ?? '';
        $description = $meta['description'] ?? '';
        global $wpdb;
        $db = Db::getLnstance();
        $db->insert("INSERT INTO `{$wpdb->prefix}product_licences_file` (`file_id`,`url`,`password`,`name`) VALUES (NULL,:url,:password,:name)",array(
                "url" => $destination,
            "password" => encrypt_data($password),
            "name" => $name
        ));
        $file_id = $db->lastInsertId();
        $db->insert("INSERT INTO `{$wpdb->prefix}product_licences` (`product_id`,`file_id`, `licence_code`, `licence_status`,`description`, `cost_price`, `created_at`) VALUES(:product_id, :file_id, :licence_code, 'available', :description, :cost_price, :created_at)",array(
                "product_id" => $product_id,
            "file_id" => $file_id,
            "licence_code" => '',
            "description" => $description,
            "cost_price" => 0,
            "created_at" => date('Y-m-d H:i:s'),
        ));
        $manage_stock = get_post_meta($product_id, '_manage_stock', true);
        ob_start();
        $records = LicenseManager::AdminLicense($product_id);
        if (!empty($records)){
            foreach ($records as $key=>$record){
                $secureId = substr(hash('sha256', $record['licence_id'] . 'SALT_RANDOM_STRING'), 0, 16);
                ?>
                <div class="c-bills__body" data-id="<?= $secureId; ?>" data-order="<?= $record['sort_order']; ?>">
                    <label class="label__checkbox">
                        <input type="checkbox" value="<?=$secureId?>" class="d-none">
                        <div class="div__checkbox"></div>
                    </label>
                    <div class="b-bills bills_number">
                        <span class="c-number"><?=$key+1?></span></div>
                    <div class="b-bills bills_name">
                        <?php
                        if (!is_null($record['file_id'])){
                            $file = \Giftmax\model\SiteModel::table('product_licences_file','file_id',$record['file_id']);

                            $relative_path = ltrim(str_replace(ABSPATH, '', $file['url']), '/');
                            ?>
                            <div class="c-color download-file" data-url="<?=$relative_path?>"><?=$file['name']?></div>
                            <?php
                        }else{
                            ?>
                            <div class="c-color"><?=decrypt_data($record['licence_code'])?></div>
                            <?php
                        }
                        ?>
                    </div>
                    <div class="b-bills purchase_date">
                        <div class="c-color"><?=gjdate($record['created_at'],'Y/m/d H:i')?></div>
                    </div>
                    <div class="b-bills  bills_pay">
                        <div class="c-color"><?=number_format($record['cost_price'])?></div>
                    </div>
                    <div class="b-bills bills_description flex justify-center">
                        <?php
                        if (!empty($record['description'])){?>
                            <div class="btn-cta Button-sd45" data-description="<?=$record['description']?>">نمایش</div>
                        <?php }else{
                            echo "-";
                        }
                        ?>
                    </div>
                    <div class="b-bills bills_orders" style=" margin: 0 6px; ">
                        <div class="c-view vv-top"></div>
                        <div class="c-view vv1"></div>
                        <div class="c-view vv2"></div>
                        <div class="c-view vv-bottom"></div>
                    </div>
                    <div class="b-bills bills_delete">
                        <div class="btn-cta Button-dl45" data-id="<?=$secureId?>">حذف</div>
                    </div>
                </div>
                <?php
            }
        }
        $output = ob_get_clean();
        if ($manage_stock == 'yes') {
            $count = $db->first("SELECT COUNT(*) AS total FROM `{$wpdb->prefix}product_licences` WHERE product_id = :product_id AND licence_status = 'available'",array('product_id'=>$product_id))['total'];
            update_post_meta($product_id, '_stock', $count);
            if ($count >=1){
                update_post_meta($_POST['product_id'], '_stock_status', 'instock');
            }
            echo json_encode(['status' => true,'output'=>$output,'count'=>$count]);
        }else {
            echo json_encode(['status' => true, 'output' => $output]);
        }
    }
    public function deleteLicence_api_function(){
        if (!isset($_POST['ei'])){
            echo json_encode(['status'=>'error','message'=>'دیتا ها کامل نیست']);
            exit();
        }
        $cookie_token = $_COOKIE['my_product_access'] ?? '';
        $fingerprint = hash(
                'sha256',
                ($_SERVER['HTTP_USER_AGENT'] ?? '') .
                ($_SERVER['HTTP_ACCEPT_LANGUAGE'] ?? '') .
                ($_SERVER['HTTP_SEC_CH_UA_PLATFORM'] ?? '')
        );

        $expected_token = hash_hmac(
                'sha256',
                $fingerprint,
                MY_PRODUCT_SECURITY_PASSWORD
        );

        $is_valid_token = hash_equals(
                $expected_token,
                $cookie_token
        );

        $is_active = get_transient(
                'giftmax_product_token_' . $cookie_token
        );

        if (!$is_valid_token || !$is_active) {
            wp_send_json_error([
                    'message' => 'زمان لاگین پسورد محصولات تموم شده!'
            ]);
        }
        $ei = $_POST['ei'];
        $ei = decrypt_data($ei);
        $ei = explode('|', $ei);
        $licence_id = $ei[0];
        $order_id = $ei[1];
        global $wpdb;
        $db = \Giftmax\modules\Db::getLnstance();
        $licence = $db->first("SELECT * FROM {$wpdb->prefix}product_licences WHERE licence_id = :id",
            array('id' => $licence_id)
        );
        if (!$licence) {
            echo json_encode(['status' => false, 'message' => 'لایسنس یافت نشد']);
            exit();
        }
        $delete = $db->modify("DELETE FROM {$wpdb->prefix}product_licences WHERE licence_id = :id",array('id' => $licence_id));
        if (!$delete){
            echo json_encode(['status' => false, 'message' => 'خطا در حذف لایسنس']);
            exit();
        }
        $order = wc_get_order($order_id);
        if ($order) {
            foreach ($order->get_items() as $item_id => $item) {
                if ($item->get_product_id() == $licence['product_id']) {
                    $reserved_ids = $item->get_meta('_reserved_licence_ids', true);
                    $reserved_ids = is_string($reserved_ids) ? json_decode($reserved_ids, true) : $reserved_ids;

                    if (is_array($reserved_ids)) {
                        $key = array_search((int)$licence_id, $reserved_ids);
                        if ($key !== false) {
                            unset($reserved_ids[$key]);
                            $reserved_ids = array_values($reserved_ids);
                            $item->update_meta_data('_reserved_licence_ids', wp_json_encode($reserved_ids));
                        }
                    }
                    break;
                }
            }
            $order->save();
        }
        echo json_encode(['status' => true, 'message' => 'لایسنس با موفقیت حذف شد']);
        exit();
    }
    public function get_user_api_function(){
        $users = get_users(array(
            'fields' => array('user_login')
        ));

        $logins = array();
        foreach ($users as $user) {
            $logins[] = $user->user_login;
        }
        echo json_encode(['status' => true,"users"=>$logins]);

    }
    public function balance_api_function(){
        if (!isset($_POST['balance']) || !isset($_POST['userId'])){
            echo json_encode(['status' => false, 'message' => 'اطلاعاتی ارسال نشده']);
            exit();
        }
        $user = get_user_by('id', $_POST['userId']);
        if (!$user->exists()){
            echo json_encode(['status' => false, 'message' => 'کاربر وجود ندارد']);
            exit();
        }
        global $wpdb;
        $db = Db::getLnstance();
        $wallet = $db->first("SELECT * FROM `{$wpdb->prefix}wallet` WHERE `user_id` = :user_id",array(
            'user_id' => $_POST['userId'],
        ));
        $db->insert("INSERT INTO `{$wpdb->prefix}wallet_transactions` (`id`, `user_id`,`method`, `method_id`, `amount`, `type`, `description`, `created_at`) VALUES (NULL, :user_id,'wallet', :method_id, :amount, 'credit', :description, :created_at)",array(
                'user_id'=>$_POST['userId'],
                'method_id'=>$wallet['id'],
                'amount'=>(float) ($_POST['balance']),
                'description'=>'افزایش موجودی توسط ادمین سایت',
                'created_at'=>date('Y-m-d H:i:s')
            )
        );
        $db->modify("UPDATE `{$wpdb->prefix}wallet` SET `balance` = :balance WHERE `id` = :id",array(
            'id'=>$wallet['id'],
            'balance'=> (float)($_POST['balance']) + $wallet['balance']
        ));
        $baseUrl = "https://edge.ippanel.com/v1/api/send";
        $token = "wns0sWEioLyJejB0g0olFj-PVlL2Yt5O2G94prP-BXg=";

        $data = [
                "sending_type" => "pattern",
                "from_number" => "+985000125475",
                "code" => "drd04sbmlk4dg54",
                "recipients" => [$user->user_login],
                "params" => [
                        "add" => number_format($_POST['balance']),
                        "total" => number_format((float)($_POST['balance']) + $wallet['balance']),
                ],
        ];

        $ch = curl_init($baseUrl);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
                "Content-Type: application/json; charset=utf-8",
                "Content-Type: application/json",
                "Authorization: $token"
        ]);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data, JSON_UNESCAPED_UNICODE));

        $response = curl_exec($ch);
        curl_close($ch);
        $data = json_decode($response, true);
        if (!is_null($data['data'])) {
            echo json_encode(['status' => true]);
        }else{
            echo json_encode(['status' => true,'sms'=>'پیام ارسال نشد']);
        }
    }
    public function CartUser_api_function(){
        if (!isset($_POST['id'])){
            echo json_encode(['status' => false, 'message' => 'اطلاعاتی ارسال نشده']);
            exit();
        }
        global $wpdb;
        $db = Db::getLnstance();
        $records = $db->query("SELECT * FROM `{$wpdb->prefix}user_bank_cards` WHERE `user_id`=:user_id",array('user_id'=>$_POST['id']));
        $data['records'] = $records;
        $html = View::re("/inc/templates/setting/carts.php",$data);
        echo json_encode(['status' => true,'html'=>$html]);

    }
    public function searchLicense_api_function(){
        if (!isset($_POST['keyword'])){
            echo json_encode(['status' => false, 'message' => 'اطلاعاتی ارسال نشده']);
            exit();
        }
        global $wpdb;
        $db = Db::getLnstance();
        $records = $db->query("SELECT * FROM {$wpdb->prefix}product_licences WHERE licence_code=:licence_code",array('licence_code'=>encrypt_data($_POST['keyword'])));
        $data['records'] = $records;
        $html = View::re("/inc/templates/setting/license.php",$data);
        echo json_encode(['status' => true,'html'=>$html]);

    }
    public function searchCart_api_function(){
        if (!isset($_POST['keyword'])){
            echo json_encode(['status' => false, 'message' => 'اطلاعاتی ارسال نشده']);
            exit();
        }
        global $wpdb;
        $db = Db::getLnstance();
        $records = $db->query("SELECT * FROM `{$wpdb->prefix}user_bank_cards` WHERE `card_number_enc`=:card_number_enc",array('card_number_enc'=>encrypt_data($_POST['keyword'])));
        $data['records'] = $records;
        $html = View::re("/inc/templates/setting/cart.php",$data);
        echo json_encode(['status' => true,'html'=>$html]);

    }
    public function searchUser_api_function(){
        if (!isset($_POST['keyword'])){
            echo json_encode(['status' => false, 'message' => 'اطلاعاتی ارسال نشده']);
            exit();
        }
        if (!ctype_digit($_POST['keyword'])){
            echo json_encode(['status' => false, 'message' => 'فقط عدد وارد کنید']);
            exit();
        }
        if (strlen($_POST['keyword']) == 10) {
            $user_id = SiteModel::table('user_identity','national_id_enc',encrypt_data($_POST['keyword']));
            $user  = get_userdata($user_id['user_id']);
        }

        elseif (strlen($_POST['keyword']) == 11) {
            $user_id = SiteModel::table('users','user_login',$_POST['keyword']);
            $user  = get_userdata($user_id['ID']);
        }
        $data['user'] = $user;
        if (isset($_POST['method']) && $_POST['method'] == 2){
            $html = View::re("/inc/templates/setting/wallet.php", $data);
        }else {
            $html = View::re("/inc/templates/setting/user.php", $data);
        }
        echo json_encode(['status' => true,'html'=>$html]);

    }
    public function ads_api_function(){
        if(!empty($_POST['data'])){
            self::insert('ads',json_encode($_POST['data']));
            echo json_encode(['status' => true]);
        }else{
            echo json_encode(['status' => false, 'message' => 'اطلاعاتی ارسال نشده']);
        }
    }
    public function faqApiFunction(){
        if(!empty($_POST['data'])){
            self::insert('faq',json_encode($_POST['data']));
            echo json_encode(['status' => true]);
        }else{
            echo json_encode(['status' => false, 'message' => 'اطلاعاتی ارسال نشده']);
        }
    }
    public function stp_api_function(){
        if(!empty($_POST['data'])){
            self::insert('stp',json_encode($_POST['data']));
            echo json_encode(['status' => true]);
        }else{
            echo json_encode(['status' => false, 'message' => 'اطلاعاتی ارسال نشده']);
        }
    }
    public function sso_api_function(){
        if(!empty($_POST['data'])){
            self::insert('suspicious_order',json_encode($_POST['data']));
            echo json_encode(['status' => true]);
        }else{
            echo json_encode(['status' => false, 'message' => 'اطلاعاتی ارسال نشده']);
        }
    }
    public function notifications_api_function()
    {
        if(!empty($_POST['data'])){
            self::insert('notifications',json_encode($_POST['data']));
            echo json_encode(['status' => true]);
        }else{
            echo json_encode(['status' => false, 'message' => 'اطلاعاتی ارسال نشده']);
        }
    }
    public function notifications_send_api_function()
    {
        if(!isset($_POST['method']) ||!isset($_POST['title']) || !isset($_POST['description'])) {
            echo json_encode(['status' => false, 'message' => 'مقادر کامل ارسال نشده']);
            exit();
        }
        global $wpdb;
        $db = Db::getLnstance();
        $title_raw = $_POST['title'];
        $body_raw = $_POST['description'];
        if ($_POST['method'] == 'all') {
            if (isset($_POST['id']) && !empty($_POST['id']) && is_numeric($_POST['id'])) {
                $db->insert("INSERT INTO `{$wpdb->prefix}notifications` (`userId`,`body`,`title`,`status`,`is_active`,`created_at`) VALUES (:userId,:body,:title,'show',1,NOW())", array(
                        'userId' => $_POST['id'],
                        'title' => $title_raw,
                        'body' => $body_raw
                ));
                UserModel::alert($_POST['id'],$db->lastInsertId());
            } else {
                $db->insert("INSERT INTO `{$wpdb->prefix}notifications` (`userId`,`body`,`title`,`status`,`is_active`,`created_at`) VALUES (0,:body,:title,'show',1,NOW())", array(
                        'title' => $title_raw,
                        'body' => $body_raw
                ));
                $idNotif = $db->lastInsertId();
                $users = get_users(array('fields' => array('ID')));
                $userIds = [];

                foreach ($users as $user) {
                    $userIds[] = $user->ID;
                }
                foreach ($userIds as $userId) {
                    UserModel::alert($userId,$idNotif);
                }
            }
        }elseif ($_POST['method'] == 'mass') {
            if ((!isset($_POST['white']) && !isset($_POST['block'])) || (isset($_POST['white']) && !empty($_POST['white']) && !is_numeric($_POST['white'])) || (isset($_POST['block']) && !empty($_POST['block']) && !is_numeric($_POST['block']))) {
                echo json_encode(['status' => false,'message' => 'Bad request']);
                exit();
            }
            if (is_numeric($_POST['block']) && !is_numeric($_POST['white'])) {
                $users = get_users(array('fields' => array('user_login')));
                $phones = [];

                foreach ($users as $user) {
                    $phones[] = $user->user_login;
                }
                $id = $_POST['block'];
                $bList = $db->first("SELECT * FROM `{$wpdb->prefix}sms_lists` WHERE `id`=:id",array('id'=>$id));
                if (!empty($bList)) {
                    $records = $db->query("SELECT phone FROM `{$wpdb->prefix}sms_list_members` WHERE `list_id`=:list_id",array('list_id'=>$bList['id']));
                    if (!empty($records)) {
                        $include_phones = [];
                        foreach ($records as $record) {
                            $include_phones[] = $record['phone'];
                        }
                        $phones = array_diff($phones, $include_phones);
                    }
                }
            }elseif (is_numeric($_POST['block']) && is_numeric($_POST['white'])) {
                $phones = [];
                $wList = $db->first("SELECT * FROM `{$wpdb->prefix}sms_lists` WHERE `id`=:id",array('id'=>$_POST['white']));
                if (!empty($wList)) {
                    $records = $db->query("SELECT phone FROM `{$wpdb->prefix}sms_list_members` WHERE `list_id`=:list_id",array('list_id'=>$wList['id']));
                    if (!empty($records)) {
                        $include_phones = [];
                        foreach ($records as $record) {
                            $include_phones[] = $record['phone'];
                        }
                        $phones = array_merge($phones, $include_phones);
                    }
                }
                $bList = $db->first("SELECT * FROM `{$wpdb->prefix}sms_lists` WHERE `id`=:id",array('id'=>$_POST['block']));
                if (!empty($bList)) {
                    $records = $db->query("SELECT phone FROM `{$wpdb->prefix}sms_list_members` WHERE `list_id`=:list_id",array('list_id'=>$bList['id']));
                    if (!empty($records)) {
                        $include_phones = [];
                        foreach ($records as $record) {
                            $include_phones[] = $record['phone'];
                        }
                        $phones = array_diff($phones, $include_phones);
                    }
                }
            }elseif (!is_numeric($_POST['block']) && is_numeric($_POST['white'])) {
                $phones = [];
                $wList = $db->first("SELECT * FROM `{$wpdb->prefix}sms_lists` WHERE `id`=:id",array('id'=>$_POST['white']));
                if (!empty($wList)) {
                    $records = $db->query("SELECT phone FROM `{$wpdb->prefix}sms_list_members` WHERE `list_id`=:list_id",array('list_id'=>$wList['id']));
                    if (!empty($records)) {
                        $include_phones = [];
                        foreach ($records as $record) {
                            $include_phones[] = $record['phone'];
                        }
                        $phones = array_merge($phones, $include_phones);
                    }
                }
            }

            $phones = array_values($phones);
            $users = [];
            foreach ($phones as $phone) {

                $user = get_users([
                        'login'   => $phone,
                        'number'  => 1,
                        'fields'  => ['ID'],
                ]);

                if (!empty($user)) {
                    $users[$phone] = $user[0]->ID;
                }
            }
            if (empty($users)) {
                echo json_encode(['status' => false, 'message' => 'کاربری پیدا نشد']);
                exit();
            }
            foreach ($users as $user) {
                $db->insert("INSERT INTO `{$wpdb->prefix}notifications` (`userId`,`body`,`title`,`status`,`is_active`,`created_at`) VALUES (:userId,:body,:title,'show',1,NOW())", array(
                        'userId' => $user,
                        'title' => $title_raw,
                        'body' => $body_raw
                ));
                UserModel::alert($user,$db->lastInsertId());
            }
        }else{
            echo json_encode(['status' => false,'message' => 'Bad request']);
            exit();
        }
        echo json_encode(['status' => true,'message' => 'پیام ارسال شده به تمامی کاربران']);
    }
    public function slider_api_function()
    {
        if(!empty($_POST['data'])){
            self::insert('slider',json_encode($_POST['data']));
            echo json_encode(['status' => true]);
        }else{
            echo json_encode(['status' => false, 'message' => 'اطلاعاتی ارسال نشده']);
        }
    }
    public function StoryVerify_api_function(){
        $id = isset($_POST['id']) ? absint($_POST['id']) : 0;
        $checked = isset($_POST['checked']) ? wp_unslash($_POST['checked']) : '';
        $db = Db::getLnstance();
        global $wpdb;
        if ($id <= 0) {
            echo json_encode(['status' => false, 'message' => 'شناسه مدرک نامعتبر است']);
            return;
        }
        $user_record = $db->first("SELECT user_id FROM `{$wpdb->prefix}documents` WHERE `id` = :id",array('id'=>$id));
        if (empty($user_record) || empty($user_record['user_id'])) {
            echo json_encode(['status' => false, 'message' => 'کاربر مدرک یافت نشد']);
            return;
        }
        $user_id = (int) $user_record['user_id'];
        if ($checked == 'true'){
            $db->modify("UPDATE `{$wpdb->prefix}documents` SET `accepted` = '2' WHERE `id` = :id",array('id'=>$id));
            $db->modify("UPDATE `{$wpdb->prefix}user_identity` SET `account_type`='vip',`is_vip` = '1',`is_verified`='1' WHERE `user_id`=:user_id",array('user_id' => $user_id));
            $db->insert("INSERT INTO `{$wpdb->prefix}notifications` (`userId`,`body`,`title`,`status`,`is_active`,`created_at`) VALUES (:user_id,:body,:title,'show',1,NOW())", array(
                'user_id' => $user_id,
                'title' => 'ارتقای سطح کاربری',
                'body' => 'شما به سطح کاربر ویژه ارتقا یافتید.'
            ));
            UserModel::alert($user_id,$db->lastInsertId());
            update_user_meta( $user_id, 'blocked', 0 );
            $points = $db->first( "SELECT * FROM {$wpdb->prefix}user_points WHERE user_id = :user_id", array('user_id'=>$user_id ));
            if (!empty($points)) {
                $db->modify("UPDATE {$wpdb->prefix}user_points SET points=:points WHERE id=:id", array(
                        'points'=> (int)$points['points'] + 250,
                        'id'=>$points['id']
                    )
                );
            }else{
                $db->insert("INSERT INTO `{$wpdb->prefix}user_points` (`id`, `user_id`, `points`) VALUES (NULL, :user_id, :points)",array(
                        'user_id'=>$user_id,
                        'points'=> 250,
                    )
                );
                $points['id'] = $db->lastInsertId();
            }
            $db->insert("INSERT INTO `{$wpdb->prefix}wallet_transactions` (`id`, `user_id`,`method`, `method_id`, `amount`, `type`, `description`, `created_at`) VALUES (NULL, :user_id,'points', :method_id, :amount, 'credit', :description, :created_at)",array(
                    'user_id'=>$user_id,
                    'method_id'=>$points['id'],
                    'amount'=>250,
                    'description'=>'هدیه احراز هویت',
                    'created_at'=>date('Y-m-d H:i:s')
                )
            );

        }else{
            $description = $_POST['text'] ?? '';

            if (is_array($description)) {
                $description = implode("\n", $description);
            }

            $description = sanitize_textarea_field($description);
            $db->modify("UPDATE `{$wpdb->prefix}documents` SET `accepted` = '1',`description`=:description WHERE `id` = :id",array('id'=>$id,'description'=>$description));
            $link = sprintf(
                '<a href="%s">%s</a>',
                esc_url(home_url('/profile/verification')),
                esc_html('ارسال دوباره مدارک')
            );
            $db->insert("INSERT INTO `{$wpdb->prefix}notifications` (`userId`,`body`,`title`,`status`,`is_active`,`created_at`) VALUES (:user_id,:body,:title,'show',1,NOW())", array(
                'user_id' => $user_id,
                'title' => 'مدارک رد شد',
                'body' => $description . "\n" . $link
            ));
            UserModel::alert($user_id,$db->lastInsertId());
        }
        echo json_encode(['status'=>true]);
    }
    public function verify_api_function(){
        $id = $_POST['id'];
        $user = get_user_by('id', $id);
        $userdb = SiteModel::table("user_identity","user_id",$id);
        $verification_note_code = get_user_meta($id, 'giftmax_verification_note_code', true);
        $verification_note_date = get_user_meta($id, 'giftmax_verification_note_date', true);

        $db = Db::getLnstance();
        global $wpdb;
        $records = $db->query("SELECT * FROM `{$wpdb->prefix}documents` WHERE `user_id` = :user_id",array('user_id' => $id));
        ob_start();
            ?>
            <div class="cer_pup_show_body">
                <div class="show_information">
                    <div class="border-1 border-solid border-blue-gray-50 border-radius-lg padding-5 margin-bottom-4">
                        <div class="font-size-16 font-weight-regular text-gray-800 padding-bottom-3">
                            اطلاعات هویتی
                        </div>
                        <div class="flex align-items-center justify-content-space-between margin-y-2 padding-y-1">
                            <div class="font-size-14 font-weight-regular text-blue-gray-700">نام</div>
                            <div class="font-size-14 font-weight-heavy text-blue-gray-900"><?= $user->first_name ?></div>
                        </div>
                        <div class="flex align-items-center justify-content-space-between margin-y-2 padding-y-1">
                            <div class="font-size-14 font-weight-regular text-blue-gray-700">نام خانوادگی</div>
                            <div
                                    class="font-size-14 font-weight-heavy text-blue-gray-900"><?= $user->last_name ?></div>
                        </div>
                        <div class="flex align-items-center justify-content-space-between margin-y-2 padding-y-1">
                            <div class="font-size-14 font-weight-regular text-blue-gray-700">کد ملی</div>
                            <div class="font-size-14 font-weight-heavy text-blue-gray-900"><?=!empty($userdb['national_id_enc']) ? decrypt_data($userdb['national_id_enc']) : ''?></div>
                        </div>
                        <div class="flex align-items-center justify-content-space-between margin-y-2 padding-y-1">
                            <div class="font-size-14 font-weight-regular text-blue-gray-700">شماره تلفن همراه </div>
                            <div class="font-size-14 font-weight-heavy text-blue-gray-900"><?=$user->user_login?></div>
                        </div>
                        <div class="flex align-items-center justify-content-space-between margin-y-2 padding-y-1">
                            <div class="font-size-14 font-weight-regular text-blue-gray-700">شماره تلفن ثابت </div>
                            <div class="font-size-14 font-weight-heavy text-blue-gray-900"><?=!empty($userdb['landline_phone']) ? decrypt_data($userdb['landline_phone']) : ''?></div>
                        </div>
                        <div class="flex align-items-center justify-content-space-between margin-y-2 padding-y-1">
                            <div class="font-size-14 font-weight-regular text-blue-gray-700">تاریخ تولد </div>
                            <div class="font-size-14 font-weight-heavy text-blue-gray-900"><?=!empty($userdb['birth_date_enc']) ? decrypt_data($userdb['birth_date_enc']) : ''?></div>
                        </div>
                    </div>
                    <div class="border-1 border-solid border-blue-gray-50 border-radius-lg padding-5 margin-bottom-4">
                        <div class="font-size-16 font-weight-regular text-gray-800 padding-bottom-3">
                            متن درج شده روی کاغذ
                        </div>
                        <div class="flex align-items-center justify-content-space-between margin-y-2 padding-y-1">
                            <div class="font-size-14 font-weight-regular text-blue-gray-700">کد تایید</div>
                            <div class="font-size-14 font-weight-heavy text-blue-gray-900"><?=esc_html(!empty($verification_note_code) ? $verification_note_code : '-')?></div>
                        </div>
                        <div class="flex align-items-center justify-content-space-between margin-y-2 padding-y-1">
                            <div class="font-size-14 font-weight-regular text-blue-gray-700">تاریخ</div>
                            <div class="font-size-14 font-weight-heavy text-blue-gray-900"><?=esc_html(!empty($verification_note_date) ? $verification_note_date : '-')?></div>
                        </div>
                        <div class="flex align-items-center justify-content-space-between margin-y-2 padding-y-1">
                            <div class="font-size-14 font-weight-regular text-blue-gray-700">متن کامل</div>
                            <div class="font-size-14 font-weight-heavy text-blue-gray-900">کد تایید مسترگیفت: <?=esc_html(!empty($verification_note_code) ? $verification_note_code : '-')?> | تاریخ: <?=esc_html(!empty($verification_note_date) ? $verification_note_date : '-')?></div>
                        </div>
                    </div>
                </div>
                <div class="show_image_cer">
                    <div class="justify-content border-1 border-solid border-blue-gray-50 border-radius-lg padding-5">
                        <?php
                        foreach ($records as $record) {
                            ?>
                            <div class="verify-horizontalVodCard">
                                <div class="verify-horizontalVodCard__cover">
                                    <figure class="verify-horizontalVodCard__thumbnail">
                                        <img src="<?=$record['document']?>">
                                    </figure>
                                    <div class="flex justify-between" style="margin-top: 10px">
                                        <a class="img__show" href="<?=$record['document']?>" target="_blank">تماشای عکس</a>
                                        <?php
                                        if ($record['accepted'] == 0) {
                                            ?>
                                            <label for="checkbox_<?=$record['id']?>" class="input-label start w40_1">
                                                <span class="start-label">تایید</span>
                                                <input id="checkbox_<?=$record['id']?>" data-id="<?=$record['id']?>" type="checkbox" class="input" checked>
                                                <span class="input-check"></span>
                                            </label>
                                            <?php
                                        }
                                        ?>
                                    </div>
                                </div>
                                <div class="verify-horizontalVodCard__extra">
                                    <div class="verify-horizontalVodCard__actions">
                                        <?php
                                        if ($record['accepted'] == 0) {
                                            ?>
                                            <div class="c-view Button-sd87" data-id="<?=$record['id']?>">ثبت</div>
                                            <?php
                                        }
                                        ?>
                                    </div>
                                    <p class="verify-horizontalVodCard__detail">
                                        <span class="verify-horizontalVodCard__label">وضعیت </span>
                                        <?php
                                        if ($record['accepted'] == 0){
                                            $class = "v10-2-1-ArBadge--info";
                                            $name = "در حال بررسی";
                                        }elseif ($record['accepted'] == 1){
                                            $class = "v10-2-1-ArBadge--danger";
                                            $name = "رد شد";
                                        }else{
                                            $class = "v10-2-1-ArBadge--success";
                                            $name = "تایید";
                                        }
                                        ?>
                                        <span class="v10-2-1-ArBadge v10-2-1-ArBadge--lg <?=$class?>"><?=$name?></span>
                                    </p>
                                    <?php
                                    if ($record['accepted'] == 0) {
                                    ?>
                                    <div class="v10-2-1-ArTextarea hidden" id="textarea_v_<?=$record['id']?>">
                                        <textarea class="v10-2-1-ArTextarea__textarea " type="text" rows="3" placeholder="دلیل رد کردن.."></textarea>
                                    </div>
                                        <?php
                                    }
                                    if ($record['accepted'] == 1) {?>
                                        <p class="v10-2-1-ArTextarea__textarea">
                                            <?=$record['description']?>
                                        </p>
                                    <?php }
                                    ?>
                                </div>
                            </div>
                            <?php
                        }
                        ?>
                    </div>
                </div>
            </div>
            <?php
        $output = ob_get_clean();

        echo json_encode($output);
    }
    private function insert($meta_key,$value){
        $db = Db::getLnstance();
        global $wpdb;
        $records = $db->first("SELECT * FROM `{$wpdb->prefix}setting` WHERE `meta_key`=:meta_key",array('meta_key'=>$meta_key));
        if (empty($records)) {
            $db->insert("INSERT INTO `{$wpdb->prefix}setting` (`id`, `meta_key`, `meta_value`) VALUES (NULL, :meta_key, :meta_value)",array('meta_key'=>$meta_key,'meta_value'=>$value));
        }else{
            $db->modify("UPDATE `{$wpdb->prefix}setting` SET `meta_value`=:meta_value WHERE `meta_key`=:meta_key",array('meta_value'=>$value,'meta_key'=>$meta_key));
        }
    }
    public function ShowCategory_api_function(){
        $db = Db::getLnstance();
        global $wpdb;
        $records = $db->first("SELECT * FROM `{$wpdb->prefix}setting` WHERE `meta_key`='category'");

        $ids_string = $records['meta_value'];
        if (!empty($ids_string)){
            $ids = array_map( 'intval', explode( ',', $ids_string ) );

            $categories = get_categories( array(
                'include'    => $ids,
                'hide_empty' => false,
            ) );

            ob_start();

            if ( ! empty( $categories ) ) {
                foreach ( $categories as $cat ) { ?>
                    <div class="d-flex ai-center c-category__<?=$cat->term_id?>">
                        <button class="relative d-flex ai-center user-select-none btn-wc51H8 text-button-2 btn--text-se4oQM btn--error-UMipUi btn--icon-ZPHT4g radius Button__medium-gIvke_ Button__textError-a_OxlI Button__prependIcon-hh7768 IconButton__button-RRc2H_ Button-dcc89" data-testid="button-wrapper" type="button">
                            <div class="d-flex ai-center jc-center relative grow-1">
                                <div class="d-flex IconButton__prependIcon-mxVR2M p-4" data-testid="icon-wrapper">
                                    <svg data-testid="button-prepend-icon"
                                         style="width: 24px; height: 24px; fill: var(--color-icon-neutral-000);">
                                        <path d="M17 8h2v11c0 1.657-1.343 3-3 3h-8c-1.657 0-3-1.343-3-3v-11h2v11c0 0.552 0.448 1 1 1h8c0.552 0 1-0.448 1-1v-11zM4 7v-2h16v2h-16zM9 8h2v10h-2v-10zM13 8h2v10h-2v-10zM8 4v-2h8v2h-8z"></path>
                                    </svg>
                                </div>
                            </div>
                        </button>
                        <p class="text-body1-strong "><?=$cat->name?></p>
                        <input name="c_id[]" type="text" class="hidden" value="<?=$cat->term_id?>">
                    </div>
                    <?php
                }
            }else{?>
                <p>دسته‌ای با این نام پیدا نشد.</p>
                <?php
            }
            $output = ob_get_clean();
            echo json_encode(['status'=>true,"html"=>$output]);
        }else{
            echo json_encode(['status'=>false]);
        }
    }
    public function ShowCategoryProduct_api_function(){
        $db = Db::getLnstance();
        global $wpdb;
        $records = $db->first("SELECT meta_value FROM `{$wpdb->prefix}setting` WHERE `meta_key`=:key",array('key'=>'tab'));
        if (!empty($records) && !empty(json_decode($records['meta_value'],true))){
            $array = json_decode($records['meta_value'],true);
            $exclude_ids = [];
            if (!empty($array[$_POST['slug']]['value'])) {
                $parts = explode(',', $array[$_POST['slug']]['value']);
                foreach ($parts as $id) {
                    $exclude_ids[] = intval($id);
                }
            }
            $args = array(
                'taxonomy' => 'product_cat',
                'include' => $exclude_ids,
            );
            $categories = get_terms( $args );
            ob_start();

            if ( ! empty( $categories ) ) {
                foreach ( $categories as $cat ) { ?>
                    <div class="d-flex ai-center c-category__<?=$cat->term_id?>">
                        <button class="relative d-flex ai-center user-select-none btn-wc51H8 text-button-2 btn--text-se4oQM btn--error-UMipUi btn--icon-ZPHT4g radius Button__medium-gIvke_ Button__textError-a_OxlI Button__prependIcon-hh7768 IconButton__button-RRc2H_ Button-dcc89" data-testid="button-wrapper" type="button">
                            <div class="d-flex ai-center jc-center relative grow-1">
                                <div class="d-flex IconButton__prependIcon-mxVR2M p-4" data-testid="icon-wrapper">
                                    <svg data-testid="button-prepend-icon"
                                         style="width: 24px; height: 24px; fill: var(--color-icon-neutral-000);">
                                        <path d="M17 8h2v11c0 1.657-1.343 3-3 3h-8c-1.657 0-3-1.343-3-3v-11h2v11c0 0.552 0.448 1 1 1h8c0.552 0 1-0.448 1-1v-11zM4 7v-2h16v2h-16zM9 8h2v10h-2v-10zM13 8h2v10h-2v-10zM8 4v-2h8v2h-8z"></path>
                                    </svg>
                                </div>
                            </div>
                        </button>
                        <p class="text-body1-strong "><?=$cat->name?></p>
                        <input name="c_id[]" type="text" class="hidden" value="<?=$cat->term_id?>">
                    </div>
                    <?php
                }
            }else{?>
                <p>دسته‌ای با این نام پیدا نشد.</p>
                <?php
            }
            $output = ob_get_clean();
            echo json_encode(['status'=>true,"html"=>$output,'s'=>$exclude_ids]);
        }else{
            echo json_encode(['status'=>false]);
        }
    }
    public function Save_api_function(){
        $value = $_POST['value'];
        $key = $_POST['key'];
        self::insert($key,$value);
        echo json_encode(array("status"=>true,"message"=>"Saved"));
    }
    public function scp_api_function(){
        $value = $_POST['value'];
        $slug = $_POST['slug'];
        $name = $_POST['name'];
        $array = [];
        $tab = [
                'name'=>$name,
            'value'=>$value
        ];
        $db = \Giftmax\modules\Db::getLnstance();
        global $wpdb;
        $records = $db->first("SELECT meta_value FROM `{$wpdb->prefix}setting` WHERE `meta_key`=:key",array('key'=>'tab'));
        if (!empty($records) && !empty(json_decode($records['meta_value'],true))){
            $array = json_decode($records['meta_value'],true);
        }
        $array[$slug] = $tab;
        self::insert('tab',json_encode($array));
        echo json_encode(array("status"=>true,"message"=>"Saved"));
    }
    public function dt_api_function(){
        $slug = $_POST['slug'];
        $db = \Giftmax\modules\Db::getLnstance();
        global $wpdb;
        $records = $db->first("SELECT meta_value FROM `{$wpdb->prefix}setting` WHERE `meta_key`=:key",array('key'=>'tab'));
        if (!empty($records) && !empty(json_decode($records['meta_value'],true))){
            $array = json_decode($records['meta_value'],true);
            unset($array[$slug]);
            self::insert('tab',json_encode($array));
            echo json_encode(array("status"=>true,"message"=>"Saved"));
        }else{
            echo json_encode(array("status"=>false,"message"=>"خطایی رخ داده"));
        }
    }
    public function searchCategory_api_function(){
        $args = array(
            'search' => $_POST['query'],
            'fields' => 'all',
            'hide_empty' => false,
        );
        if (isset($_POST['method']) && $_POST['method'] == 'product') {
            $args['taxonomy']  = 'product_cat';
            $db = \Giftmax\modules\Db::getLnstance();
            global $wpdb;
            $records = $db->first("SELECT meta_value FROM `{$wpdb->prefix}setting` WHERE `meta_key`=:key",array('key'=>'tab'));
            if (!empty($records) && !empty(json_decode($records['meta_value'],true))) {
                $array = json_decode($records['meta_value'], true);
                $exclude_ids = [];

                foreach ($array as $item) {
                    if (!empty($item['value'])) {
                        $parts = explode(',', $item['value']);
                        foreach ($parts as $id) {
                            $exclude_ids[] = intval($id);
                        }
                    }
                }
                $args['exclude'] = $exclude_ids;
            }
        }else{
           $args['taxonomy']  = 'category';
        }
        $categories = get_terms( $args );

        if ( is_wp_error( $categories ) ) {
            echo json_encode(['status'=>false,'message'=>"خطایی در جستجو از سمت وردپرس رخ داده"]);

            return;
        }
        ob_start();
        ?>
        <section class=" pos-relative disable-selection">
            <section>
                <div class="Search__ViewSection-oAkF3T">
                    <?php
                    if ( ! empty( $categories ) ) {
                        foreach ( $categories as $cat ) { ?>
                            <div class="pointer pos-relative Search__call-ls10iB SearchCall__focusable-vehen_ SearchCall__md-hJ2pKK SearchCall--hover-k8Ybcg Search__call-Ms6j86 text-body2-strong Div-cc<?=$cat->term_id?>">
                                <button class="relative d-flex ai-center user-select-none btn-wc51H8 text-button-2 btn--text-se4oQM btn--primary-uiqWij btn--icon-ZPHT4g radius Button__medium-gIvke_ Button__textPrimary-IWW5Sd Button__prependIcon-hh7768 Button__iconSizeSmall-AnFGHD IconButton__button-RRc2H_ CalendarCell__focusable--iconButton-LPR1Uc Button-cc54" data-testid="button-wrapper" type="button">
                                    <div class="d-flex ai-center jc-center relative grow-1">
                                        <div class="d-flex IconButton__prependIcon-mxVR2M" data-testid="icon-wrapper">
                                            <svg data-testid="button-prepend-icon" style="width: 24px;height: 24px;fill: var(--color-icon-primary);"><path d="M12 22c5.523 0 10-4.477 10-10s-4.477-10-10-10c-5.523 0-10 4.477-10 10s4.477 10 10 10zM11 11v-4h2v4h4v2h-4v4h-2v-4h-4v-2h4z"></path></svg>
                                        </div>
                                    </div>
                                </button>
                                <div class="d-flex jc-center ai-center flex-column" style="height: 100%;">
                                    <p><?=$cat->name?></p>
                                </div>
                                <input type="text" id="cat_id" class="hidden" value="<?=$cat->term_id?>">
                            </div>
                            <?php
                        }
                    }else{?>
                        <p>دسته‌ای با این نام پیدا نشد.</p>
                        <?php
                    }
                    ?>
                </div>
            </section>
        </section>
        <?php
        $output = ob_get_clean();
        echo json_encode(['status'=>true,"html"=>$output]);

    }
}
