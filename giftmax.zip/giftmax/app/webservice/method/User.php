<?php
namespace Giftmax\webservice\method;

use Giftmax\model\SiteModel;
use Giftmax\model\UserModel;
use Giftmax\modules\Db;
use Giftmax\modules\Jibit;
use Giftmax\modules\View;

class User{
    public function __construct(){
        add_action( 'rest_api_init',[ $this, 'addApiRoutes' ] );
    }
    public function addApiRoutes(){
        register_rest_route( 'api/v1', '/register', array(
            'methods' => 'POST',
            'callback' => [$this, 'registerApiFunction'],
            'permission_callback' => "__return_true"
        ) );
        register_rest_route( 'api/v1', '/login', array(
            'methods' => 'POST',
            'callback' => [$this, 'loginApiFunction'],
            'permission_callback' => "__return_true"
        ) );
        register_rest_route( 'api/v1', '/otp', array(
            'methods' => 'POST',
            'callback' => [$this, 'otpApiFunction'],
            'permission_callback' => "__return_true"
        ) );
        register_rest_route( 'api/v1', '/login-otp', array(
            'methods' => 'POST',
            'callback' => [$this, 'loginOtpApiFunction'],
            'permission_callback' => "__return_true"
        ) );
        register_rest_route( 'api/v1', '/login-otp-audio', array(
            'methods' => 'POST',
            'callback' => [$this, 'loginOtpAudioApiFunction'],
            'permission_callback' => "__return_true"
        ) );
        register_rest_route( 'api/v1', '/lotp', array(
            'methods' => 'POST',
            'callback' => [$this, 'otpFormApiFunction'],
            'permission_callback' => "__return_true"
        ) );
        register_rest_route( 'api/v1', '/pass', array(
            'methods' => 'POST',
            'callback' => [$this, 'passwordRegisterApiFunction'],
            'permission_callback' => "__return_true"
        ) );
        register_rest_route( 'api/v1', '/setPassword', array(
            'methods' => 'POST',
            'callback' => [$this, 'setPasswordApiFunction'],
            'permission_callback' => "__return_true"
        ) );
        register_rest_route('api/v2', '/changePassword', array(
            'methods' => 'POST',
            'callback' => [$this, 'changePasswordApiFunction'],
            'permission_callback' => function () {
                return is_user_logged_in();
            }
        ));
        register_rest_route('api/v2', '/changePasswordOtp', array(
            'methods' => 'POST',
            'callback' => [$this, 'changePasswordOtpApiFunction'],
            'permission_callback' => function () {
                return is_user_logged_in();
            }
        ));
        register_rest_route('api/v2', '/otp', array(
            'methods' => 'POST',
            'callback' => [$this, 'otpApiFunctionV2'],
            'permission_callback' => function () {
                return is_user_logged_in();
            }
        ));
        register_rest_route('api/v2', '/ForgestPassword', array(
            'methods' => 'POST',
            'callback' => [$this, 'ForgestPasswordApiFunction'],
            'permission_callback' => function () {
                return is_user_logged_in();
            }
        ));
    }
    public static function callZohalService(string $url, array $payload, string $token ,int $isIdentity = 0): array
    {
        $ch = curl_init($url);

        curl_setopt_array($ch, [
            CURLOPT_POST           => true,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HTTPHEADER     => [
                'Content-Type: application/json',
                'Authorization: Bearer ' . $token
            ],
            CURLOPT_POSTFIELDS     => json_encode($payload),
            CURLOPT_TIMEOUT        => 30,
        ]);

        $response = curl_exec($ch);

        if ($response === false) {
            $error = curl_error($ch);
            curl_close($ch);
            return [
                'status'  => false,
                'message' => 'Curl Error: ' . $error
            ];
        }

        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        $data = json_decode($response, true);
        if ($httpCode === 400) {
            return [
                'status'  => false,
                'message' => $data['response_body']['message'] ?? 'درخواست نامعتبر'
            ];
        }
        if ($isIdentity === 0) {
            if ($httpCode === 200) {

                if (isset($data['response_body']['data']['matched'])) {

                    return [
                        'status' => (bool)$data['response_body']['data']['matched'],
                        'message' => $data['response_body']['data']['matched']
                            ? 'اطلاعات تطابق دارد'
                            : 'اطلاعات تطابق ندارد'
                    ];
                }

                return [
                    'status' => true,
                    'message' => $data['response_body']['message'] ?? 'عملیات موفق'
                ];
            }
        }else{
            if ($httpCode === 200) {

                if (isset($data['response_body']['data']['alive']) && $data['response_body']['data']['alive']) {
                    return $data['response_body']['data'];
                }

                return [
                    'status'  => false,
                    'message' => 'درخواست شما نامعتبر است'
                ];
            }
        }
        return [
            'status'  => false,
            'message' => 'وضعیت پاسخ نامعتبر: ' . $httpCode
        ];
    }

    public static function sendOTPMobile($number)
    {
        $otp = mt_rand(100000, 999999);
        $expiry = date("Y-m-d H:i:s", strtotime("+2 minutes"));
        UserModel::expiryEnd();
        $records = UserModel::exitOtp($number);
        if (!empty($records) && strtotime($records['otp_expiry']) < time()) {
            UserModel::otpDelete($records['id']);
        }
        if (empty($records)) {
            UserModel::otp($number, $otp, $expiry);
            $baseUrl = "https://edge.ippanel.com/v1/api/send";
            $token = "wns0sWEioLyJejB0g0olFj-PVlL2Yt5O2G94prP-BXg=";

            $data = [
                "sending_type" => "pattern",
                "from_number" => "+985000125475",
                "code" => "xpvkq2fmvzmqvr6",
                "recipients" => [$number],
                "params" => [
                    "otp" => $otp,
                    "otp_link" => $otp,
                ],
            ];

            $ch = curl_init($baseUrl);
            curl_setopt($ch, CURLOPT_HTTPHEADER, [
                "Content-Type: application/json; charset=utf-8",
                "Content-Type: application/json",
                "Authorization: $token"
            ]);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data, JSON_UNESCAPED_UNICODE));

            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);
        }
    }
    public function registerApiFunction()
    {
        $userName = $_POST['userName'];
        $hash = $_POST['hash'];
        $firstName = $_POST['first_name'];
        $lastName = $_POST['last_name'];
        $nationalID = $_POST['nationalID'];
        $CardNumber = str_replace('-', '', $_POST['CardNumber']);
        $d1 = $_POST['register_birthdate1'];
        $d2 = $_POST['register_birthdate2'];
        $d3 = $_POST['register_birthdate3'];
        if (empty($userName) || empty($hash) || empty($firstName) || empty($lastName) ||empty($nationalID) || empty($CardNumber) || empty($d1) || empty($d2) || empty($d3)) {
            return new \WP_REST_Response([
                'status' => false,
                'message' => 'همه فیلدها باید پر شوند'
            ], 200);

        }
        $hashCard = generateHash();
        $records = SiteModel::table('token_register','UserLogin',$userName,'hash',$hash);
        if (empty($records)) {
            $TokenRegister = SiteModel::table('token_register',`UserLogin`,$userName);
            if (!empty($TokenRegister)) {
                UserModel::TokenRegisterDelete($TokenRegister['id']);
            }
            return new \WP_REST_Response([
                'status' => false,
                'Isreload' => true,
                'message' => 'خطا در ثبت نام'
            ], 200);

        }
        $token = 'd5497c98fc9a28300406dd8ee66bac5b531fc598';
        $birthDate = $d1 . '/' . $d2 . '/' . $d3;
        $jbt = Jibit::getLnstance();
        if(SiteModel::setting("shahkar_zohal") === true) {
            $result = self::callZohalService(
                'https://service.zohal.io/api/v0/services/inquiry/shahkar',
                [
                    'mobile' => $userName,
                    'national_code' => $nationalID
                ],
                $token
            );

            if ($result['status'] !== true) {
                return new \WP_REST_Response([
                    'status' => false,
                    $result
                ], 200);
            }
        }
        elseif(SiteModel::setting("shahkar_jibit") === true) {
            $endpoint = '/services/matching';
            $res =  $jbt->api_request('GET', $endpoint, [
                'mobileNumber' => $userName,
                'nationalCode' => $nationalID
            ], null, true);
            if ($res['code'] !== 200) {
                return new \WP_REST_Response([
                    'status' => false,
                    'message' => $res['body']['message']
                ], 200);
            }
        }
        if(SiteModel::setting("check_card_with_national_code_zohal") === true) {
            $result = self::callZohalService(
                'https://service.zohal.io/api/v0/services/inquiry/check_card_with_national_code',
                [
                    'birth_date' => $birthDate,
                    'card_number' => $CardNumber,
                    'national_code' => $nationalID
                ],
                $token
            );

            if ($result['status'] !== true) {
                return new \WP_REST_Response([
                    'status' => false,
                    $result
                ], 200);
            }
        }
        elseif(SiteModel::setting("check_card_with_national_code_jibit") === true) {
            $endpoint = '/services/matching';
            $res =  $jbt->api_request('GET', $endpoint, [
                'cardNumber' => $CardNumber,
                'nationalCode' => $nationalID,
                'birthDate' =>  $d1  . $d2 .  $d3
            ], null, true);
            if ($res['code'] !== 200) {
                return new \WP_REST_Response([
                    'status' => false,
                    'message' => $res['body']['message']
                ], 200);
            }
        }
        $number = UserModel::phone($_POST['userName']);

        if (username_exists($_POST['userName'])) {
            return new \WP_REST_Response([
                'status'  => false,
                'message' => 'این شماره وجود دارد!'
            ], 200);
        }
        if (!$number) {
            $password = wp_generate_password(12, false);
            $user_id = wp_create_user($_POST['userName'], $password);
            $is_exist = SiteModel::table("user_identity","national_id_enc",encrypt_data($nationalID));
            if (is_user_blocked($is_exist['user_id'])){
                return new \WP_REST_Response([
                    'status'  => false,
                    'message' => 'حساب قبلی شما مسدود میباشد و اجازه ثبت نام ندارید.'
                ], 200);
            }
            if ($user_id) {
                $user = new \WP_User($user_id); // load the new user
                $user->set_role('customer');
                wp_update_user([
                    'ID' => $user_id,
                    'first_name' => $firstName,
                    'last_name'  => $lastName,
                    'display_name' => trim($firstName . ' ' . $lastName),
                    'user_email'   => $user->user_login . "@gmail.com",
                ]);
                update_user_meta($user_id, 'api_token', wp_generate_password(50, false));
                if ((SiteModel::setting("shahkar_zohal") === true || SiteModel::setting("shahkar_jibit") === true) && (SiteModel::setting("check_card_with_national_code_zohal") === true || SiteModel::setting("check_card_with_national_code_jibit") === true)) {
                    \Giftmax\model\UserModel::insertUser($user_id, $nationalID, $birthDate, $CardNumber,$hashCard, 1);
                }else{
                    \Giftmax\model\UserModel::insertUser($user_id, $nationalID, $birthDate, $CardNumber,$hashCard, 0);
                }
            }
        }
        $otp = mt_rand(100000, 999999);
        $expiry = date("Y-m-d H:i:s", strtotime("+2 minutes"));
        UserModel::expiryEnd();
        $records = UserModel::exitOtp($userName);
        if (!empty($records) && strtotime($records['otp_expiry']) < time()) {
            UserModel::otpDelete($records['id']);
        }
        if (empty($records)) {
            UserModel::otp($userName, $otp, $expiry);
        }
        $url = "https://portal.avanak.ir/rest/SendOTP";
        $url = $url . "?" . "Token=" . urlencode("1ACAAF7BC85B6AB3B54E5381A72EDCDC67D7BF06");
        $url = $url . "&" . "Length=6";
        $url = $url . "&" . "Number=" . $userName;
        $url = $url . "&" . "OptionalCode=" . $otp;

        $json = file_get_contents($url);
        if ($json->ErrorCode != 0) {
            $url = "https://portal.avanak.ir/rest/SendOTP";
            $url = $url . "?" . "Token=" . urlencode("1ACAAF7BC85B6AB3B54E5381A72EDCDC67D7BF06");
            $url = $url . "&" . "Length=6";
            $url = $url . "&" . "Number=" . $userName;
            $url = $url . "&" . "OptionalCode=" . $otp;

            $json = file_get_contents($url);
            if ($json->ErrorCode != 0) {
                $output = View::re("/inc/templates/template-parts/login/getpassword.php", $_POST);
                $response_data = array(
                    'status' => true,
                    'html' => $output,
                );
                return new \WP_REST_Response( $response_data ,200 );
            }
        }
        $output = View::re("/inc/templates/template-parts/login/card_otp.php", ['hash'=>$hashCard]);
        $response_data = array(
            'status' => true,
            'html' => $output,
        );
        return new \WP_REST_Response( $response_data ,200 );

    }
    public function loginApiFunction(){
        if (isset($_POST['userName'])) {
            $number = UserModel::phone($_POST['userName']);
            if(empty($number)) {
                self::sendOTPMobile($_POST['userName']);
                $output = View::re("/inc/templates/template-parts/login/otp.php", $_POST);
            }else{
                $output = View::re("/inc/templates/template-parts/login/password.php", $_POST);
            }
            $response_data = array(
                'html' => $output
            );
            return new \WP_REST_Response( $response_data ,200 );
        } else{
            $response_data = array(
                'status' => false,
                'message' => 'وروردی صحیح نمیباشد'
            );
            return new \WP_REST_Response( $response_data ,200 );
        }
    }
    public function otpApiFunction(){
        if (isset($_POST['userName'])) {
            $records = UserModel::exitOtp($_POST['userName'], 'otp', $_POST['otp']);
            if (!empty($records)) {
                if (strtotime($records['otp_expiry']) > time()) {
                    $number = UserModel::phone($_POST['userName']);
                    if ($number) {
                        $user = get_user_by('login', $_POST['userName']);

                        if (!is_wp_error($user)) {
                            wp_clear_auth_cookie();
                            wp_set_current_user($user->ID);
                            wp_set_auth_cookie($user->ID,true);
                            $response_data = array(
                                'url' => home_url('/'),
                            );
                        } else {
                            $response_data = array(
                                'url' => home_url('login-register'),
                            );
                        }
                        UserModel::otpDelete($records['id']);
                    } else {
                        $hash = generateHash();
                        $_POST['hash'] = $hash;
                        UserModel::registerUser($_POST['userName'],$hash);
                        $output = View::re("/inc/templates/template-parts/login/register.php", $_POST);
                        $response_data = array(
                            'html' => $output,
                        );
                        UserModel::otpDelete($records['id']);
                    }
                } else {
                    UserModel::otpDelete($records['id']);
                    $response_data = array(
                        'status' => false,
                        'message' => 'کد شما منقضی شده'
                    );
                }
                return new \WP_REST_Response($response_data, 200);

            } else {
                $response_data = array(
                    'status' => false,
                    'message' => 'کد وروردی صحیح نمیباشد'
                );
                return new \WP_REST_Response($response_data, 200);
            }
        }else{
            $response_data = array(
                'status' => false,
                'message' => 'وروردی صحیح نمیباشد'
            );
            return new \WP_REST_Response( $response_data ,200 );
        }
    }
    public function loginOtpApiFunction(){
        if (isset($_POST['userName'])) {
            $number = UserModel::phone($_POST['userName']);
            if(!empty($number)) {
                self::sendOTPMobile($_POST['userName']);
                $response_data = array(
                    'status' => true,
                    'message' => 'ارسال شد'
                );
            }else{
                $response_data = array(
                    'status' => false,
                    'message' => 'خطا ارسال شد'
                );
            }
            return new \WP_REST_Response( $response_data ,200 );
        } else{
            $response_data = array(
                'status' => false,
                'message' => 'وروردی صحیح نمیباشد'
            );
            return new \WP_REST_Response( $response_data ,200 );
        }
    }
    /**
     * ورود با otp صوتی
     **/
    public function loginOtpAudioApiFunction(){
        if (isset($_POST['userName'])) {
            $number = UserModel::phone($_POST['userName']);
            if(!empty($number)) {
                if (SiteModel::setting("otpAudioLogin") === true) {
                    $otp = mt_rand(100000, 999999);
                    $expiry = date("Y-m-d H:i:s", strtotime("+20 minutes"));
                    UserModel::expiryEnd();
                    $records = UserModel::exitOtp($_POST['userName']);
                    if (!empty($records) && strtotime($records['otp_expiry']) < time()) {
                        UserModel::otpDelete($records['id']);
                    }
                    if (empty($records)) {
                        UserModel::otp($_POST['userName'], $otp, $expiry);
                    }
                    $url = "https://portal.avanak.ir/rest/SendOTP";
                    $url = $url . "?" . "Token=" . urlencode("1ACAAF7BC85B6AB3B54E5381A72EDCDC67D7BF06");
                    $url = $url . "&" . "Length=6";
                    $url = $url . "&" . "Number=" . $_POST['userName'];
                    $url = $url . "&" . "OptionalCode=" . $otp;

                    $json = file_get_contents($url);
                    if ($json->ErrorCode != 0) {
                        echo json_encode(["status" => false, "message" => "خطایی پیش آمده", "percent" => 0]);
                    }
                    $response_data = array(
                        'status' => true,
                        'message' => 'ارسال شد'
                    );
                }else {
                    $response_data = array(
                        'status' => true,
                        'message' => 'ارسال شد'
                    );
                }
            }else{
                $response_data = array(
                    'status' => false,
                    'message' => 'این متد فعال نیست'
                );
            }
            return new \WP_REST_Response( $response_data ,200 );
        } else{
            $response_data = array(
                'status' => false,
                'message' => 'وروردی صحیح نمیباشد'
            );
            return new \WP_REST_Response( $response_data ,200 );
        }
    }
    public function otpFormApiFunction(){
        if (isset($_POST['userName'])) {
            self::sendOTPMobile($_POST['userName']);
            $output = View::re("/inc/templates/template-parts/login/otp.php", $_POST);
            $response_data = array(
                'html' => $output
            );
            return new \WP_REST_Response($response_data, 200);
        }else{
            $response_data = array(
                'status' => false,
                'message' => 'وروردی صحیح نمیباشد'
            );
            return new \WP_REST_Response( $response_data ,200 );
        }
    }
    public function passwordRegisterApiFunction(){
        if (isset($_POST['userName']) && isset($_POST['PassWord'])) {
            $username = sanitize_user($_POST['userName']);
            $password = $_POST['PassWord'];

            $user = get_user_by('login', $username);
            if ($user && wp_check_password($password, $user->user_pass, $user->ID)) {
                wp_clear_auth_cookie();
                wp_set_current_user($user->ID);
                wp_set_auth_cookie($user->ID,true);
                $response_data = array(
                    'status' => true,
                    'url' => home_url('/'),
                );

            }else{
                $response_data = array('status' => false);
            }
            return new \WP_REST_Response( $response_data ,200 );
        }else{
            $response_data = array(
                'status' => false,
                'message' => 'وروردی صحیح نمیباشد'
            );
            return new \WP_REST_Response( $response_data ,200 );
        }
    }
    /**
     * تنظیم رمز عبور جدید از طریق پروفایل
     **/
    public function setPasswordApiFunction()
    {
        $userName = $_POST['userName'];
        $password = $_POST['password'];
        $hash = $_POST['hash'];
        if (empty($userName) || empty($hash) || empty($password)) {
            return new \WP_REST_Response([
                'status' => false,
                'message' => 'رمز عبور را ارسال کنید'
            ], 200);

        }
        $records = SiteModel::table('token_register','UserLogin',$userName,'hash',$hash);
        if (empty($records)) {
            $TokenRegister = SiteModel::table('token_register',`UserLogin`,$userName);
            if (!empty($TokenRegister)) {
                UserModel::TokenRegisterDelete($TokenRegister['id']);
            }
            return new \WP_REST_Response([
                'status' => false,
                'Isreload' => true,
                'message' => 'خطا در ثبت نام'
            ], 200);
        }
        if (strlen($password) < 8) {
            $errors = 'رمز عبور باید حداقل ۸ کاراکتر باشد.';
            return new \WP_REST_Response([
                'status' => false,
                'message' => $errors
            ], 200);
        }
        $user_login = get_user_by('login', $_POST['userName']);

        if (!is_wp_error($user_login)) {
            wp_clear_auth_cookie();
            wp_set_password($password, $user_login->ID);
            wp_set_current_user($user_login->ID);
            wp_set_auth_cookie($user_login->ID);

            UserModel::TokenRegisterDelete($records['id']);
            $response_data = array(
                'status'  => true,
                'url' => home_url('/profile'),
            );
        }else{
            $response_data = array(
                'status'  => false,
                'message' => "خطایی پیش آمده دوباره تلاش کنید",
            );
        }
        return new \WP_REST_Response( $response_data ,200 );

    }

    /**
     * تغییر رمز وقتی کاربر لاگین کرده
     */
    public function changePasswordApiFunction()
    {
        $current_pass = $_POST['currentPassword'];
        $new_pass = $_POST['newPassword'];
        $confirm_pass = $_POST['rePassword'];

        $user = wp_get_current_user();
        $user_id = $user->ID;

        if (empty($current_pass) || empty($new_pass) || empty($confirm_pass)) {
            return new \WP_REST_Response([
                'status' => false,
                'message' => 'همه فیلدها باید پر شوند.'
            ], 200);
        }

        if ($new_pass !== $confirm_pass) {
            $errors = 'رمز عبور جدید و تکرار آن مطابقت ندارند.';
            return new \WP_REST_Response([
                'status' => false,
                'message' => $errors
            ], 200);
        }

        if (strlen($new_pass) < 8) {
            $errors = 'رمز عبور جدید باید حداقل ۸ کاراکتر باشد.';
            return new \WP_REST_Response([
                'status' => false,
                'message' => $errors
            ], 200);
        }

        if (!wp_check_password($current_pass, $user->user_pass, $user_id)) {
            $errors = 'رمز عبور فعلی صحیح نیست.';
            return new \WP_REST_Response([
                'status' => false,
                'message' => $errors
            ], 200);
        }
        wp_set_password($new_pass, $user_id);
        wp_set_auth_cookie($user_id);
        wp_set_current_user($user_id);
        return new \WP_REST_Response([
            'status' => true,
            'html' => 'OK'
        ], 200);
    }
    /**
     * فراموشی رمز عبور و تغییر رمز
     */
    public function changePasswordOtpApiFunction()
    {
        $otp = $_POST['otp'];
        $new_pass = $_POST['newPassword'];
        $confirm_pass = $_POST['rePassword'];

        $user = wp_get_current_user();
        $user_id = $user->ID;

        if (empty($otp) || empty($new_pass) || empty($confirm_pass)) {
            return new \WP_REST_Response([
                'status' => false,
                'message' => 'همه فیلدها باید پر شوند.'
            ], 200);
        }
        $records = UserModel::exitOtp($user->user_login, 'otp', $_POST['otp']);
        if (!empty($records)) {
            if (strtotime($records['otp_expiry']) > time()) {
                $number = UserModel::phone($user->user_login);
                if ($number) {
                    if ($new_pass !== $confirm_pass) {
                        $errors = 'رمز عبور جدید و تکرار آن مطابقت ندارند.';
                        return new \WP_REST_Response([
                            'status' => false,
                            'message' => $errors
                        ], 200);
                    }

                    if (strlen($new_pass) < 8) {
                        $errors = 'رمز عبور جدید باید حداقل ۸ کاراکتر باشد.';
                        return new \WP_REST_Response([
                            'status' => false,
                            'message' => $errors
                        ], 200);
                    }

                    wp_set_password($new_pass, $user_id);
                    wp_set_auth_cookie($user_id);
                    wp_set_current_user($user_id);
                    UserModel::otpDelete($records['id']);
                    return new \WP_REST_Response([
                        'status' => true,
                        'html' => 'OK'
                    ], 200);
                } else {
                    $errors = 'خطایی رخ داد.';
                    return new \WP_REST_Response([
                        'status' => false,
                        'close' => true,
                        'message' => $errors
                    ], 200);
                }
            } else {
                UserModel::otpDelete($records['id']);
                $response_data = array(
                    'status' => false,
                    'close' => true,
                    'message' => 'کد شما منقضی شده'
                );
            }
            return new \WP_REST_Response($response_data, 200);

        } else {
            $errors = 'کد ارسالی درست نیست.';
            return new \WP_REST_Response([
                'status' => false,
                'message' => $errors
            ], 200);
        }
    }
    public function otpApiFunctionV2()
    {
        $records = UserModel::exitOtp($_POST['value'], 'otp', $_POST['otp']);
        if (!empty($records)) {
            if (strtotime($records['otp_expiry']) > time()) {
                UserModel::otpDelete($records['id']);
                $user_id = get_current_user_id();
                UserModel::SetLandLinePhone(encrypt_data($_POST['value']),$user_id);
                $response_data = array('status' => true);
            } else {
                UserModel::otpDelete($records['id']);
                $response_data = array(
                    'status' => false,
                    'closed' => true,
                    'message' => 'کد شما منقضی شده'
                );
            }
            echo json_encode($response_data);
        } else {
            $response_data = array(
                'status' => false,
                'closed' => false,
                'message' => 'کد وروردی صحیح نمیباشد'
            );
            echo json_encode($response_data);
        }
    }
    public function ForgestPasswordApiFunction()
    {
        $user = wp_get_current_user();
        self::sendOTPMobile($user->user_login);
        $response_data = array(
            'status' => true
        );
        return new \WP_REST_Response($response_data, 200);
    }
}