<?php
namespace Giftmax\Woo;

use Giftmax\Modules\Db;
use Giftmax\Modules\UserModel;
use Giftmax\Templates\AdminProductTemplate;
use Kavenegar\Exceptions\ApiException;
use Kavenegar\Exceptions\HttpException;
use Kavenegar\KavenegarApi;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class WpOrders {

    public function __construct() {
        add_action('woocommerce_admin_order_data_after_order_details',[$this,'order_details']);

        add_action('add_meta_boxes_shop_order', [$this,'register_shop_order_meta_box']);
        add_action('add_meta_boxes_woocommerce_page_wc-orders', [$this,'register_shop_order_meta_box']);

        add_action('woocommerce_saved_order_items', [$this,'save_order_licences_meta_box'], 10, 2);
    }
    /*
     * برای بخش جزئیات فنی توی بخش بالای ویرایش سفارشات
     */
    public function order_details ($order):Void {
        echo "------------";

        if (! $order instanceof \WC_Order) {
            return;
        }

        $user_id        = $order->get_customer_id();
        $u    = UserModel::table('user_identity', 'user_id', $user_id);
        $user    = $user_id ? get_user_by('id', $user_id) : null;

        $first_name = $user ? $user->first_name : '';
        $last_name  = $user ? $user->last_name : '';
        $user_login = $user ? $user->user_login : '';

        $gateway_id     = $order->get_payment_method();
        $gateway_title  = $order->get_payment_method_title();
        $card_number    = $order->get_meta('_card_pay');
        $buyer_ip       = $order->get_meta('_buyer_ip');

        echo '<div style="
        margin-top:20px;
        border:1px solid #e1e1e1;
        border-radius:8px;
        background:#fff;
        padding:15px;
    ">';

        echo '<h3 style="margin-bottom:10px;">🧩 جزئیات فنی سفارش</h3>';

        echo '<p><strong>شناسه کاربر:</strong> ' . esc_html($user_id) . '</p>';
        if ($user) {
            echo '<p><strong>نام:</strong> ' . esc_html($first_name) . '</p>';
            echo '<p><strong>نام خانوادگی:</strong> ' . esc_html($last_name) . '</p>';
            echo '<p><strong>شماره همراه:</strong> ' . esc_html($user_login) . '</p>';
        }
        if (!empty($u['national_id_enc'])) {
            echo '<p><strong>کد ملی:</strong>' . decrypt_data($u['national_id_enc']) . '</p>';
        }
        echo '<p><strong>درگاه پرداخت:</strong> ' . esc_html($gateway_title ?: $gateway_id) . '</p>';

        if (isset($u['account_type']) && $u['account_type'] == 'normal') {
            if ($card_number) {
                echo '<p><strong>شماره کارت:</strong> ' . esc_html($card_number) . '</p>';
            }
            $records = UserModel::table('user_bank_cards','card_number_enc',encrypt_data($card_number),"user_id",$user_id);
            if (!empty($records['phone'])) {
                echo '<div style=" border: 1px solid #ccc; padding: 0 10px; border-radius: 24px; "><p>کارت متعلق به این حساب نیست</p>';
                echo '<p><strong>شماره همراه :</strong> ' . decrypt_data($records['phone']) . '</p>';
                echo '<p><strong> تاریخ تولد :</strong> ' . decrypt_data($records['birth_date']) . '</p>';
                echo '<p><strong>کدملی  :</strong> ' . decrypt_data($records['national_code']) . '</p>';
                echo '<p><strong>نام و نام خانوداگی  :</strong> ' . $records['first_name'] . ' '. $records['last_name'] . '</p>';
                echo '</div>';
            }
        }else{
            echo '<p><strong>حساب کاربر تایید شده</strong></p>';

        }
        if (is_array($u)){
            echo '<p><strong>تارخ تولد:</strong> ' . decrypt_data($u['birth_date_enc']) . '</p>';
        }
        if (is_array($u) && !empty($u['landline_phone'])){
            echo '<p><strong> شماره تلفن ثابت:</strong> ' . decrypt_data($u['landline_phone']) . '</p>';
        }
        if ($buyer_ip) {
            echo '<p><strong>IP خریدار:</strong> ' . esc_html($buyer_ip) . '</p>';
        }

        echo '</div>';
    }

    /*
     * بخش ویرایش لایسنس
     */
    public function register_shop_order_meta_box(): void {
        add_meta_box(
            'giftmax_order_licences_box',
            __( 'افزودن لایسنس', 'giftmax' ),
            function( $post ) {
                $order = wc_get_order( $post instanceof \WP_Post ? $post->ID : $post );
                $this->render_order_license_box( $order );
            },
            null,
            'normal',
            'default'
        );
        add_meta_box(
            'giftmax_order_sms_box',
            __( 'ارسال پیامک', 'giftmax' ),
            function ($post) {
                echo '<style>.setting_bot_send {
    position: relative;
    display: flex;
    -webkit-box-pack: center;
    justify-content: center;
    -webkit-box-align: center;
    align-items: center;
}.w60 {
    width: 60%;
    height: fit-content;
}.w40_1 {
    width: 40% !important;
}
.input-label {
    position: relative;
    display: inline-flex;
    -webkit-box-align: center;
    align-items: center;
    flex-wrap: wrap;
    width: auto;
    font-size: 1em;
    color: rgb(72, 75, 98);
    cursor: pointer;
    user-select: none;
    font-weight: 500;
}.start-label {
    margin-left: 1.5em;
}
.start-label, .input-label .end-label {
    font-size: 0.93em;
    line-height: 1.4;
}.input-label .input {
    position: absolute;
    width: 1px;
    height: 1px;
    margin: 0px;
    opacity: 0;
}
input[type="checkbox"], [type="radio"] {
    box-sizing: border-box;
    padding: 0px;
}
.meta-box-sortables input {
    vertical-align: middle;
}.input-check {
    position: relative;
    z-index: 1;
    width: 34px;
    height: 14px;
    border-radius: 50px;
    background-color: rgb(230, 231, 239);
    transition: background-color 200ms cubic-bezier(0.68, 0.96, 0.67, 1.22) 0s;
}.input-check::after {
    background-color: rgb(251, 251, 252);
    transform: translate(20px, -50%);
    box-shadow: rgba(0, 0, 0, 0.2) 0px 3px 1px -2px, rgba(0, 0, 0, 0.14) 0px 2px 2px 0px, rgba(0, 0, 0, 0.12) 0px 0px 4px 1px;
}.input-check::before, .input-check::after {
    content: "";
    position: absolute;
    top: 50%;
    left: 0px;
    width: 20px;
    height: 20px;
    border-radius: 50px;
    transition: transform 200ms cubic-bezier(0.68, 0.96, 0.67, 1.22) 0s;
}.input-label .input:checked ~ .input-check::after {
    background-color: rgb(5, 163, 232);
    transform: translate(-5px, -50%);
}.input-label.start .input-check {
    margin-right: auto;
}</style><div class="setting_bot_send d-flex">
        <p class="s-setting_bot_send w60">ارسال پیامک</p>
        <label for="s-autoPlaySwitch" class="input-label start w40_1">
            <span class="start-label"></span>
            <input id="s-autoPlaySwitch" type="checkbox" name="sendSms" class="input">
            <span class="input-check"></span>
        </label>
    </div>';
            },
            null,
            'side',
            'high'
        );
    }
    public function render_order_license_box( $order ): void {
        $view = new AdminProductTemplate();
        $view->render_add_licences( $order );
    }

    /*
     * بخش ذخیره لایسنس
     */
    public function save_order_licences_meta_box(int $post_id, $post = null): void {
        // Check if this is an autosave
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return;
        }

        // Verify the order exists
        $order = wc_get_order($post_id);
        if (!$order) {
            return;
        }

        if (isset($_POST['sendSms'])) {
           if ($_POST['sendSms']=='on'){
               $baseUrl = "https://edge.ippanel.com/v1/api/send";
               $token = "wns0sWEioLyJejB0g0olFj-PVlL2Yt5O2G94prP-BXg=";
               $user = get_user_by('id', $order->get_user_id());
               $data = [
                   "sending_type" => "pattern",
                   "from_number" => "+9890007189",
                   "code" => "3kgp39lioune0sn",
                   "recipients" => [$user->user_login],
                   "params" => [
                       "url" => home_url('/profile/invoices/'.$order->get_id()),
                   ],
               ];

               $ch = curl_init($baseUrl);
               curl_setopt($ch, CURLOPT_HTTPHEADER, [
                   "Content-Type: application/json; charset=utf-8",
                   "Content-Type: application/json",
                   "Authorization: $token"
               ]);
               curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
               curl_setopt($ch, CURLOPT_POST, true);
               curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data, JSON_UNESCAPED_UNICODE));

               $response = curl_exec($ch);
               $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
               curl_close($ch);
           }
        }

        if (!isset($_POST['giftmax_order_licences_nonce'])) {
            return;
        }

        if (!wp_verify_nonce($_POST['giftmax_order_licences_nonce'], 'giftmax_order_licences')) {
            return;
        }

        if (!current_user_can('edit_shop_order', $post_id)) {
            return;
        }

        if (empty($_POST['giftmax_order_licences']) || !is_array($_POST['giftmax_order_licences'])) {
            return;
        }

        global $wpdb;
        $db = \Giftmax\Modules\Db::getLnstance();
        $logger = wc_get_logger(); // Initialize logger at the start
        foreach ($order->get_items() as $item_id => $item) {
            if (empty($_POST['giftmax_order_licences'][$item_id])) {
                continue;
            }

            $lines = explode("\n", wp_unslash($_POST['giftmax_order_licences'][$item_id]));
            $lines = array_filter(array_map('trim', $lines));

            if (empty($lines)) {
                continue;
            }

            $product_id = $item->get_product_id();
            $reserved_ids = $item->get_meta('_reserved_licence_ids', true);
            $reserved_ids = is_string($reserved_ids) ? json_decode($reserved_ids, true) : $reserved_ids;

            if (!is_array($reserved_ids)) {
                $reserved_ids = [];
            }

            $current_time = current_time('mysql'); // Get current time once per item

            foreach ($lines as $line) {
                $licence_code = trim($line ?? '');
                if ($licence_code === '') {
                    continue;
                }

                $insert_data = [
                    'product_id' => $product_id,
                    'licence_code' => encrypt_data($licence_code),
                    'cost_price' => null,
                    'order_id' => $post_id,
                    'assigned_at' => $current_time,
                    'created_at' => $current_time,
                ];

                $inserted = $db->insert(
                    "INSERT INTO `{$wpdb->prefix}product_licences`
                (`product_id`, `licence_code`, `licence_status`, `cost_price`, `order_id`, `assigned_at`, `created_at`)
                VALUES
                (:product_id, :licence_code, 'assigned', :cost_price, :order_id, :assigned_at, :created_at)",
                    $insert_data
                );

                $new_id = $db->lastInsertId();

                if (!$new_id || $inserted === false) {
                    $logger->error(
                        'Giftmax: failed to insert licence for order.',
                        [
                            'source' => 'giftmax',
                            'order_id' => $post_id,
                            'item_id' => $item_id,
                            'product_id' => $product_id,
                            'licence' => $licence_code,
                            'db_error' => $wpdb->last_error ?? '',
                        ]
                    );
                    continue;
                }

                $reserved_ids[] = (int)$new_id;
            }

            $product = wc_get_product( $product_id );
            $product_name = $product->get_name();
            $product_permalink = $product->get_permalink();
            $url = home_url('/profile/deliveries');
            $body = sprintf(
                'لایسنس %1$s در پنل کاربری شما موجود شد. <a href="%2$s" target="_blank">مشاهده</a>',
                '<a href="' . esc_url( $product_permalink ) . '" target="_blank">' . esc_html( $product_name ) . '</a>',
                esc_url( $url )
            );
            $db->insert("INSERT INTO `{$wpdb->prefix}notifications` (`userId`,`body`,`title`,`status`,`is_active`,`created_at`) VALUES (:user_id,:body,:title,'show',1,NOW())", array(
                'user_id' => $order->get_user_id(),
                'title' => 'لایسنس محصول پیش فروش',
                'body' => $body
            ));
            UserModel::alert($order->get_user_id(),$db->lastInsertId());
            $item->update_meta_data('_reserved_licence_ids', wp_json_encode($reserved_ids));
        }

        // Save all items at once at the end
        $order->save();
    }


}
