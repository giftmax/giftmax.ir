<?php

namespace Giftmax\Api\versen;

use Giftmax\Modules\Db;
use Giftmax\Modules\Jibit;
use Giftmax\Modules\TicketModel;
use Giftmax\Modules\UserModel;
use Giftmax\Modules\View;

if (!defined('ABSPATH')) {
    exit;
}

class v1{

    public function __construct(){
        new UserModel();
        new TicketModel();
        add_action( 'rest_api_init',[ $this, 'All_api_routes' ] );
    }

    public function All_api_routes(){
        register_rest_route( 'api/v1', '/addCart', array(
            'methods' => 'POST',
            'callback' => [$this, 'add_to_cart_api_function'],
            'permission_callback' => "__return_true"
        ) );
        register_rest_route( 'api/v1', '/stats', array(
            'methods' => 'POST',
            'callback' => [$this, 'stats_api_function'],
            'permission_callback' => "__return_true"
        ) );
        register_rest_route( 'api/v1', '/cart', array(
            'methods' => 'POST',
            'callback' => [$this, 'cart_api_function'],
            'permission_callback' => "__return_true"
        ) );
        register_rest_route( 'api/v1', '/getCartTimer', array(
            'methods' => 'POST',
            'callback' => [$this, 'get_cart_timer_api_function'],
            'permission_callback' => "__return_true"
        ) );
        register_rest_route( 'api/v1', '/login', array(
            'methods' => 'POST',
            'callback' => [$this, 'login_api_function'],
            'permission_callback' => "__return_true"
        ) );
        register_rest_route( 'api/v1', '/login-otp-audio', array(
            'methods' => 'POST',
            'callback' => [$this, 'loginOtpAudio_api_function'],
            'permission_callback' => "__return_true"
        ) );
        register_rest_route( 'api/v1', '/login-otp', array(
            'methods' => 'POST',
            'callback' => [$this, 'loginOtp_api_function'],
            'permission_callback' => "__return_true"
        ) );
        register_rest_route( 'api/v1', '/lotp', array(
            'methods' => 'POST',
            'callback' => [$this, 'lotp_api_function'],
            'permission_callback' => "__return_true"
        ) );
        register_rest_route( 'api/v1', '/otp', array(
            'methods' => 'POST',
            'callback' => [$this, 'otp_api_function'],
            'permission_callback' => "__return_true"
        ) );
        register_rest_route( 'api/v1', '/pass', array(
            'methods' => 'POST',
            'callback' => [$this, 'pass_api_function'],
            'permission_callback' => "__return_true"
        ) );
        register_rest_route( 'api/v1', '/register', array(
            'methods' => 'POST',
            'callback' => [$this, 'register_api_function'],
            'permission_callback' => "__return_true"
        ) );
        register_rest_route( 'api/v1', '/LoadCategory', array(
            'methods' => 'POST',
            'callback' => [$this, 'load_category_api_function'],
            'permission_callback' => "__return_true"
        ) );
        register_rest_route( 'api/v1', '/ticketing', array(
            'methods' => 'POST',
            'callback' => [$this, 'ticketing_api_function'],
            'permission_callback' => function () {
                return is_user_logged_in();
            }
        ) );
        register_rest_route( 'api/v1', '/alert', array(
            'methods' => 'POST',
            'callback' => [$this, 'alert_api_function'],
            'permission_callback' => "__return_true"
        ) );
        register_rest_route( 'api/v1', '/setPassword', array(
            'methods' => 'POST',
            'callback' => [$this, 'setPassword_api_function'],
            'permission_callback' => "__return_true"
        ) );
        register_rest_route( 'api/v1', '/category', array(
            'methods' => 'POST',
            'callback' => [$this, 'category_api_function'],
            'permission_callback' => function () {
                return is_current_user_admin();
            }
        ) );
        register_rest_route( 'api/v1', '/main', array(
            'methods' => 'POST',
            'callback' => [$this, 'main_api_function'],
            'permission_callback' => function () {
                return is_current_user_admin();
            }
        ) );
        register_rest_route( 'api/v1', '/ticket_category', array(
            'methods' => 'POST',
            'callback' => [$this , 'ticket_category_api_function'],
            'permission_callback' => function () {
                return is_user_logged_in();
            }
        ) );
        register_rest_route( 'api/v1', '/images', array(
            'methods' => 'POST',
            'callback' => [$this, 'images_api_function'],
            'permission_callback' => function () {
                return is_user_logged_in();
            }
        ) );
        register_rest_route( 'api/v1', '/comment', array(
            'methods' => 'POST',
            'callback' => [$this, 'comment_api_function'],
            'permission_callback' => function () {
                return is_user_logged_in();
            }
        ) );
        register_rest_route( 'api/v1', '/coupon', array(
            'methods' => 'POST',
            'callback' => [$this, 'coupon_api_function'],
            'permission_callback' => function () {
                return is_user_logged_in();
            }
        ) );
        register_rest_route('api/v1', '/update-wallet', [
            'methods'  => 'POST',
            'callback' => [$this, 'update_wallet_discount'],
            'permission_callback' => function () {
                return is_user_logged_in();
            },
        ]);

        register_rest_route( 'api/v1', '/PaymentMethods', array(
            'methods' => 'POST',
            'callback' => [$this, 'payment_methods_api_function'],
            'permission_callback' => function () {
                return is_user_logged_in();
            }
        ) );
        register_rest_route( 'api/v1', '/payment', array(
            'methods' => 'POST',
            'callback' => [$this, 'payment_api_function'],
            'permission_callback' => function () {
                return is_user_logged_in();
            }
        ) );
        register_rest_route( 'api/v1', '/payment-verify/zibal', array(
            'methods' => 'GET',
            'callback' => [$this, 'payment__verify_api_function'],
            'permission_callback' => "__return_true"
        ) );
        register_rest_route( 'api/v1', '/payment-verify/paystar', array(
            'methods' => 'POST',
            'callback' => [$this, 'paystar_verify_api_function'],
            'permission_callback' => "__return_true"
        ) );
        register_rest_route( 'api/v1', '/payment-verify/payment4', array(
            'methods' => 'GET',
            'callback' => [$this, 'payment4_verify_api_function'],
            'permission_callback' => "__return_true"
        ) );
        register_rest_route( 'api/v1', '/UpdateCartQty', array(
            'methods' => 'POST',
            'callback' => [$this, 'update_cart_qty_api_function'],
            'permission_callback' => function () {
                return is_user_logged_in();
            }
        ));
        register_rest_route( 'api/v1', '/pagination', array(
            'methods' => 'POST',
            'callback' => [$this, 'Pagination_api_function'],
            'permission_callback' => function () {
                return is_user_logged_in();
            }
        ));
        register_rest_route( 'api/v1', '/mc', array(
            'methods' => 'POST',
            'callback' => [$this, 'mc_api_function'],
            'permission_callback' => function () {
                return is_user_logged_in();
            }
        ));
        register_rest_route( 'api/v1', '/verify-cart', array(
            'methods' => 'POST',
            'callback' => [$this, 'verifyCart_api_function'],
            'permission_callback' => function () {
                return is_user_logged_in();
            }
        ));
        register_rest_route( 'api/v1', '/change-number', array(
            'methods' => 'POST',
            'callback' => [$this, 'changeNumberApiFunction'],
            'permission_callback' => function () {
                return is_user_logged_in();
            }
        ));
        register_rest_route( 'api/v1', '/card-otp', array(
            'methods' => 'POST',
            'callback' => [$this, 'cardOtpFunction'],
                'permission_callback' => "__return_true"
        ));
        register_rest_route( 'api/v1', '/posts', array(
            'methods' => 'POST',
            'callback' => [$this, 'posts_api_function'],
            'permission_callback' => "__return_true"
        ) );
        register_rest_route( 'api/v1', '/search', array(
            'methods' => 'POST',
            'callback' => [$this, 'search_api_function'],
            'permission_callback' => "__return_true"
        ) );
        register_rest_route( 'api/v1', '/filterRegion', array(
            'methods' => 'POST',
            'callback' => [$this, 'filterRegion_api_function'],
            'permission_callback' => "__return_true"
        ) );
        register_rest_route( 'api/v1', '/alert-notif', array(
            'methods' => 'POST',
            'callback' => [$this, 'alertNotifFunction'],
            'permission_callback' => "__return_true"
        ) );
        register_rest_route( 'api/v1', '/set-price', array(
            'methods' => 'GET',
            'callback' => [$this, 'setPriceFunction'],
            'permission_callback' => "__return_true"
        ) );
    }
    public function changeNumberApiFunction()
    {
        if (!isset($_POST['value']) || !isset($_POST['id'])){
            echo json_encode(['status'=>false,'message'=>"اطلاعات ناقص"]);
            exit();
        }
        $order = wc_get_order(decrypt_id($_POST['id']));
        $maskedCardNumber = $order->get_meta( '_card_pay', true );
        $userCardNumber = $_POST['value'];
        $masked = $this->extractCardDigits($maskedCardNumber);

        if (!$masked) {
            echo json_encode(['status'=>false,'message'=>"شماره کارت درست نیست"]);
            exit();
        }

        $userCardNumber = preg_replace('/\D/', '', $userCardNumber);

        if (strlen($userCardNumber) !== 16) {
            echo json_encode(['status'=>false,'message'=>"شماره کارت درست نیست"]);
            exit();
        }
        if ($masked['prefix_length'] > 0) {
            if (substr($userCardNumber, 0, $masked['prefix_length']) !== $masked['prefix']) {
                echo json_encode(['status'=>false,'message'=>"شماره کارت درست نیست"]);
                exit();
            }
        }
        if ($masked['suffix_length'] > 0) {
            if (substr($userCardNumber, -$masked['suffix_length']) !== $masked['suffix']) {
                echo json_encode(['status'=>false,'message'=>"شماره کارت درست نیست"]);
                exit();
            }
        }
        $order->update_meta_data('_is_card_pay', 1);
        $order->update_meta_data('_card_pay', $userCardNumber);
        $order->save();
        echo json_encode(['status'=>true]);
    }
    public function cardOtpFunction()
    {
        if (!isset($_POST['hash'])){
            echo json_encode(['status'=>false,'message'=>"اطلاعات ناقص",'Isreload'=>true]);
            exit();
        }
        $hash = $_POST['hash'];
        $record = UserModel::table('user_bank_cards','hash',$hash);
        if (empty($record)){
            echo json_encode(['status'=>false,'message'=>"اطلاعات ناقص",'Isreload'=>true]);
            exit();
        }
        $response_data = v2::otpCardVerify(get_userdata($record['user_id'])->user_login,$_POST['otp'],$hash);
        if ($response_data['status'] == true){
            $loginHash = UserModel::table('token_register','UserLogin',get_userdata($record['user_id'])->user_login);
            $output = View::re("/inc/templates/template-parts/login/getpassword.php", ['userName'=>get_userdata($record['user_id'])->user_login,'hash'=>$loginHash]);
            $response_data['html'] = $output;
        }
        echo json_encode($response_data);
    }
    public function setPriceFunction()
    {
        if(!isset($_GET['key']) || $_GET['key'] != 'e65cwm7cjpye9'){
            echo json_encode(['status' => false]);
            exit();
        }

        $args = array(
                'post_type' => 'product',
                'posts_per_page' => -1,
                'fields' => 'ids',
        );

        $products = get_posts($args);

        foreach ($products as $product_id) {
            $wc_product = wc_get_product($product_id);
            if (!$wc_product) {
                continue;
            }

            $price = $wc_product->get_price();
            if ($price) {
                self::giftmax_maybe_store_daily_price($product_id, $price);
            }
        }
    }
    private static function giftmax_maybe_store_daily_price($product_id, $price_value) {
        if (!$product_id) {
            return;
        }

        $price_history = get_post_meta($product_id, '_giftmax_price_history', true);
        if (!is_array($price_history)) {
            $price_history = array();
        }
        $today = current_time('Y-m-d');
        $price_value = (float) $price_value;

        if (!isset($price_history[$today]) || (float) $price_history[$today] !== $price_value) {
            $price_history[$today] = $price_value;
        }

        $cutoff = strtotime('-29 days', current_time('timestamp'));
        foreach ($price_history as $date => $stored_price) {
            $entry_ts = strtotime($date . ' 00:00:00');
            if ($entry_ts === false || $entry_ts < $cutoff) {
                unset($price_history[$date]);
            }
        }

        ksort($price_history);
        update_post_meta($product_id, '_giftmax_price_history', $price_history);
    }

    public function Pagination_api_function()
    {
        if (!isset($_POST['page']) || !isset($_POST['method'])) {
            echo json_encode(['status'=>false,'message'=>'اطلاعت ناقص']);
        }
        $paged = absint($_POST['page']);
        $user_id = get_current_user_id();
        if ($_POST['method'] == "order"){
            ob_start();
            $paged = absint($_POST['page']);
            $per_page = 10;
            $args = [
                    'customer_id' => $user_id,
                    'limit'       => $per_page,
                    'page'        => $paged,
                    'orderby'     => 'date',
                    'order'       => 'DESC',
            ];
            $orders = wc_get_orders($args);
            if ($orders){
            foreach ($orders as $dashboard_order):
                $dashboard_order_date = $dashboard_order->get_date_created();
                $dashboard_order_date = $dashboard_order_date ? $dashboard_order_date->date_i18n('Y/m/d') : '-';
                if (!isMobile()){
                    if ($dashboard_order->get_status() != 'card-not-verified'){
                        $urlOrders = esc_url(home_url(get_current_section_base() . '/invoices/' . $dashboard_order->get_id()));
                    }else{
                        $urlOrders = esc_url(home_url(get_current_section_base() . '/orders'));
                    }
                    ?>
                    <tr class="cursor-pointer">
                        <td data-content="تاریخ سفارش">
                            <div class="table-td-inner"><?=gjdate($dashboard_order_date,"d M Y")?></div>
                        </td>
                        <td data-content="تاریخ سفارش">
                            <div class="table-td-inner"><?php
                                $gateway = $dashboard_order->get_payment_method();
                                if ( $gateway === 'payment4' ) {
                                    $currency = 'USD';
                                } else {
                                    $currency = 'TOMAN';
                                }
                                $amount = $dashboard_order->get_total();
                                echo gm_wc_price( $amount, array( 'currency' => $currency ) );
                                ?>
                            </div>
                        </td>
                        <td data-content="وضعیت سفارش" class="py-7">
                            <div class="table-td-inner">
                                <?php
                                if ($dashboard_order->get_status() == 'card-not-verified'){?>
                                    <div class="flex gap-2">
                                        <span class="badge status-pill--completed text-3xs">تکمیل شده</span>
                                        <span class="badge status-pill--card-not-verified text-3xs">مغایرت کارت بانکی</span>
                                    </div>
                                    <span class="badge status-pill--pending text-3xs" style="margin-top: 3px;">تایید مالکیت کارت</span>
                                    <?php
                                }else{?>
                                    <span class="badge status-pill--<?=$dashboard_order->get_status()?> text-3xs"><?= esc_html(wc_get_order_status_name($dashboard_order->get_status())) ?></span>
                                    <?php
                                }
                                ?>
                            </div>
                        </td>
                        <td data-content="وضعیت فروش">
                            <?php
                            $is_preorder = $dashboard_order->get_meta('_has_preorder_items');
                            if(!$is_preorder) {?>
                                <div class="badge badge-primary text-3xs">تحویل آنی</div>
                                <?php
                            }else{
                                $presale = get_max_presale_item_by_order_id($dashboard_order->get_id());
                                if ($presale['t'] && $presale['license_status'] != 2){?>
                                    <div class="table-td-inner">
                                        <span class="text-neutral-500 text-caption line-height-1">تحویل با تاخیر</span>
                                        <div class="text-primary-700 text-body2-strong style_ProductPromotionTimeline__timer__zS6ZA1 line-height-1 mt-1"><?=$presale['ctt']?></div>
                                    </div>
                                    <?php
                                }else{
                                    ?>
                                    <div class="badge badge-info text-3xs">تحویل با تاخیر</div>
                                    <?php
                                }
                            }
                            ?>
                        </td>
                        <td data-content="وضعیت تحویل">
                            <?php
                            if ($dashboard_order->get_status() == 'completed'){
                                if($is_preorder){
                                    if ($presale['license_status'] == 0){
                                        echo '<span class="badge status-pill--pending text-3xs">درحال تامین کالا</span>';
                                    }elseif ($presale['license_status'] == 1){
                                        echo '<span class="badge status-pill--checkout-draft text-3xs">در حال تحویل</span>';
                                    }elseif ($presale['license_status'] == 2){
                                        echo '<span class="badge status-pill--completed text-3xs">تحویل داده شد</span>';
                                    }
                                }else{
                                    ?>
                                    <span class="badge status-pill--completed text-3xs">تحویل داده شد</span>
                                    <?php
                                }
                            }else if ($dashboard_order->get_status() == 'card-not-verified'){
                                ?>
                                <div class="flex justify-between">
                                    <span class="badge status-pill--failed text-3xs">عدم تحویل</span>
                                    <?php
                                    $cardPay = $dashboard_order->get_meta( '_card_pay', true );
                                    $isCheck = $dashboard_order->get_meta( '_is_card_pay', true );
                                    $card = UserModel::table('user_bank_cards', 'card_number_enc', encrypt_data($cardPay),"user_id",$user_id);
                                    if (!empty($card)) {
                                        ?>
                                        <span class="badge status-pill--completed text-3xs">تایید کارت</span>
                                        <?php
                                    }else{
                                        ?>
                                        <span class="badge status-pill--failed text-3xs">تایید کارت</span>
                                        <?php
                                    }
                                    ?>
                                    <span class="badge status-pill--failed text-3xs check-phone">تایید تلفن</span>
                                </div>
                                <?php
                            }else if ($dashboard_order->get_status() != 'card-not-verified' && $dashboard_order->get_status() != 'completed'){
                                ?>
                                <span class="badge status-pill--failed text-3xs">عدم تحویل</span>
                                <?php
                            }
                            ?>
                        </td>
                        <td class="table-list-actions">
                            <div class="table-td-inner flex justify-end pb-2 space-x-8 space-x-reverse align-items-center">
                                <?php
                                if ($dashboard_order->get_status() != 'card-not-verified'){
                                    ?>
                                    <a class="btn btn-2xs btn-white text-dark btn-view" href="<?= esc_url(home_url('/profile/invoices/' . $dashboard_order->get_id())) ?>">مشاهده</a>
                                    <?php
                                }else{
                                    if ($isCheck){?>
                                    <svg class="Button-od94" data-number="<?=$cardPay?>" data-id="<?=encrypt_id($dashboard_order->get_id())?>" viewBox="0 0 24 24"><path fill-rule="evenodd" d="M2 12c0 5.523 4.477 10 10 10s10-4.477 10-10S17.523 2 12 2 2 6.477 2 12zm18 0a8 8 0 11-16 0 8 8 0 0116 0zm-10-2h3v7h-2v-5h-1v-2zm3-2a1 1 0 10-2 0 1 1 0 002 0z" clip-rule="evenodd"></path></svg>
                                    <button class="btn btn-2xs btn-white text-dark btn-view Button-vcs788" data-id="<?=encrypt_id($dashboard_order->get_id())?>">تایید کارت</button>
                                <?php }else{?>
                                    <svg class="Button-od94" data-number="<?=$cardPay?>" data-check="1" data-id="<?=encrypt_id($dashboard_order->get_id())?>" viewBox="0 0 24 24"><path fill-rule="evenodd" d="M2 12c0 5.523 4.477 10 10 10s10-4.477 10-10S17.523 2 12 2 2 6.477 2 12zm18 0a8 8 0 11-16 0 8 8 0 0116 0zm-10-2h3v7h-2v-5h-1v-2zm3-2a1 1 0 10-2 0 1 1 0 002 0z" clip-rule="evenodd"></path></svg>
                                    <button class="btn btn-2xs btn-white text-dark btn-view Button-sc45" data-number="<?=$cardPay?>" data-id="<?=encrypt_id($dashboard_order->get_id())?>">تایید کارت</button>
                                    <?php
                                } }
                                ?>

                            </div>
                        </td>
                    </tr>
                    <?php
                }else{?>
                    <tr class="cursor-pointer">
                        <td data-content="شماره فاکتور">
                            <div class="table-td-inner text-sm tracking-tight font-medium text-dark ellipsis">#<?= esc_html($dashboard_order->get_order_number()) ?></div>
                        </td>
                        <td data-content="تاریخ سفارش">
                            <div class="table-td-inner"><?=gjdate($dashboard_order_date,"d M Y")?></div>
                        </td>
                        <td data-content="مبلغ سفارش">
                            <div class="table-td-inner"><?php
                                $gateway = $dashboard_order->get_payment_method();
                                if ( $gateway === 'payment4' ) {
                                    $currency = 'USD';
                                } else {
                                    $currency = 'TOMAN';
                                }
                                $amount = $dashboard_order->get_total();
                                echo gm_wc_price( $amount, array( 'currency' => $currency ) );
                                ?>
                            </div>
                        </td>
                        <td data-content="وضعیت سفارش">
                            <div class="table-td-inner">
                                <span class="badge status-pill--<?=$dashboard_order->get_status()?> text-3xs"><?= esc_html(wc_get_order_status_name($dashboard_order->get_status())) ?></span>
                            </div>
                        </td>
                        <td data-content="وضعیت فروش">
                            <?php
                            $is_preorder = $dashboard_order->get_meta('_has_preorder_items');
                            if(!$is_preorder) {?>
                                <div class="badge badge-primary text-3xs">تحویل آنی</div>
                                <?php
                            }else{
                                $presale = get_max_presale_item_by_order_id($dashboard_order->get_id());
                                if ($presale['t'] && $presale['license_status'] != 2){?>
                                    <div class="table-td-inner">
                                        <span class="text-neutral-500 text-caption line-height-1">تحویل با تاخیر</span>
                                        <div class="text-primary-700 text-body2-strong style_ProductPromotionTimeline__timer__zS6ZA1 line-height-1 mt-1"><?=$presale['ctt']?></div>
                                    </div>
                                    <?php
                                }else{
                                    ?>
                                    <div class="badge badge-info text-3xs">تحویل با تاخیر</div>
                                    <?php
                                }
                            }
                            ?>
                        </td>
                        <td data-content="وضعیت تحویل">
                            <div class="table-td-inner">
                                <?php
                                if ($dashboard_order->get_status() == 'completed'){
                                    if($is_preorder){
                                        if ($presale['license_status'] == 0){
                                            echo '<span class="badge status-pill--pending text-3xs">درحال تامین کالا</span>';
                                        }elseif ($presale['license_status'] == 1){
                                            echo '<span class="badge status-pill--checkout-draft text-3xs">در حال تحویل</span>';
                                        }elseif ($presale['license_status'] == 2){
                                            echo '<span class="badge status-pill--completed text-3xs">تحویل داده شد</span>';
                                        }
                                    }else{
                                        ?>
                                        <span class="badge status-pill--completed text-3xs">تحویل داده شد</span>
                                        <?php
                                    }
                                }else if ($dashboard_order->get_status() == 'card-not-verified'){
                                    ?>
                                    <div class="flex justify-between">
                                        <span class="badge status-pill--failed text-3xs">عدم تحویل</span>
                                        <?php
                                        $cardPay = $dashboard_order->get_meta( '_card_pay', true );
                                        $isCheck = $dashboard_order->get_meta( '_is_card_pay', true );
                                        $card = UserModel::table('user_bank_cards', 'card_number_enc', encrypt_data($cardPay),"user_id",$user_id);
                                        if (!empty($card)) {
                                            ?>
                                            <span class="badge status-pill--completed text-3xs">تایید کارت</span>
                                            <?php
                                        }else{
                                            ?>
                                            <span class="badge status-pill--failed text-3xs">تایید کارت</span>
                                            <?php
                                        }
                                        ?>
                                        <span class="badge status-pill--failed text-3xs check-phone">تایید تلفن</span>
                                    </div>
                                    <?php
                                }else if ($dashboard_order->get_status() != 'card-not-verified' && $dashboard_order->get_status() != 'completed'){
                                    ?>
                                    <span class="badge status-pill--failed text-3xs">عدم تحویل</span>
                                    <?php
                                }
                                ?>
                            </div>
                        </td>
                        <td class="table-list-actions">
                            <div class="table-td-inner flex justify-end pb-2 space-x-8 space-x-reverse align-items-center">
                                <?php
                                if ($dashboard_order->get_status() != 'card-not-verified'){
                                    ?>
                                    <a class="btn btn-2xs btn-white text-dark btn-view" href="<?= esc_url('/profile/invoices/' . $dashboard_order->get_id()) ?>">مشاهده</a>
                                    <?php
                                }else{
                                    if ($isCheck){?>
                                    <svg class="Button-od94" data-number="<?=$cardPay?>" data-id="<?=encrypt_id($dashboard_order->get_id())?>" viewBox="0 0 24 24"><path fill-rule="evenodd" d="M2 12c0 5.523 4.477 10 10 10s10-4.477 10-10S17.523 2 12 2 2 6.477 2 12zm18 0a8 8 0 11-16 0 8 8 0 0116 0zm-10-2h3v7h-2v-5h-1v-2zm3-2a1 1 0 10-2 0 1 1 0 002 0z" clip-rule="evenodd"></path></svg>
                                    <button class="btn btn-2xs btn-white text-dark btn-view Button-vcs788" data-id="<?=encrypt_id($dashboard_order->get_id())?>">تایید کارت</button>
                                <?php }else{?>
                                    <svg class="Button-od94" data-number="<?=$cardPay?>" data-check="1" data-id="<?=encrypt_id($dashboard_order->get_id())?>" viewBox="0 0 24 24"><path fill-rule="evenodd" d="M2 12c0 5.523 4.477 10 10 10s10-4.477 10-10S17.523 2 12 2 2 6.477 2 12zm18 0a8 8 0 11-16 0 8 8 0 0116 0zm-10-2h3v7h-2v-5h-1v-2zm3-2a1 1 0 10-2 0 1 1 0 002 0z" clip-rule="evenodd"></path></svg>
                                    <button class="btn btn-2xs btn-white text-dark btn-view Button-sc45" data-number="<?=$cardPay?>" data-id="<?=encrypt_id($dashboard_order->get_id())?>">تایید کارت</button>
                                    <?php
                                }
                                }
                                ?>
                            </div>
                        </td>
                    </tr>
                <?php }
                ?>
            <?php endforeach;
            }else{
                ?>
                <section class="p-5 TableCard--bodyMobile-tDS3OZ">
                    <div class="d-flex ai-center jc-center align-center w-100 h-100">
                        <div class="py-4 d-flex flex-column jc-center ai-center EmptyState__desktopContainer-ggZkIg">
                            <div class="d-flex jc-center mb-3" data-testid="empty-src">
                                <div data-testid="image-wrapper" style="width: 200px; height: 150px;">
                                    <img class="w-100" src="<?=get_template_directory_uri()?>/assets/img/ticket_img.png" width="200" height="150" data-testid="image-defaultImage" style="object-fit: contain;">
                                </div>
                            </div>
                            <div class="text-h5 color-900">نتیجه&zwnj;ای پیدا نکردیم...</div>
                            <div class="text-caption-strong color-500" data-testid="empty-description">
                                <div>فیلتر ها رو تغییر دهید و سپس دوباره امتحان کنید.</div>
                            </div>
                        </div>
                    </div>
                </section>
                    <?php
            }
            $output = ob_get_clean();
            ob_start();
            $total_orders = wc_get_orders([
                    'customer_id' => $user_id,
                    'limit'       => -1,
            ]);

            $total_pages = ceil(count($total_orders) / $per_page);
            for ($i = $paged-1; $i <= $paged+1; $i++) {
                if ($i < 1){
                    continue;
                }
                if ($i>$total_pages){continue;}
                if ($paged == $i){
                    echo '<button class="v10__Pagination-item Button-np54 active">' . $i . '</button>';
                }else {
                    echo '<button class="v10__Pagination-item Button-np54" data-page="' . $i . '">' . $i . '</button>';
                }
            }
            $pagination = ob_get_clean();
            echo json_encode(['status' => true, 'html'=>$output, 'pagination'=>$pagination]);
        }
        elseif($_POST['method'] == 'notification'){
            global $wpdb;
            $db = Db::getLnstance();
            $startIndex = 10*($paged-1);
            $records = $db->query("SELECT n.*,r.* FROM `{$wpdb->prefix}notifications` n LEFT JOIN `{$wpdb->prefix}notification_reads` r ON r.`notification_id` = n.`Id` AND r.`user_id` = :user_id WHERE n.`is_active`=1 AND (n.`userId` IS NULL OR n.`userId`=0 OR n.`userId`=:user_id) ORDER BY n.`Id` DESC LIMIT $startIndex, 10", array('user_id' => $user_id));
            ob_start();
            if (!empty($records)){
                foreach ($records as $record){
                    if (empty($record['notification_id'])){
                        ?>
                        <section
                                class="TableRowContainer__normal-Uv6APM py-2 px-4 my-3 d-grid ai-center NotificationCard__tableRow-opMsDI TableRowDesktop-xIiuFo radius-md">
                            <div class="NotificationCard__title-GEjaN6 d-flex flex-row">
                                <div class="d-flex flex-row">
                                    <div class="d-flex ml-5" data-testid="icon-wrapper">
                                        <svg style="width: 24px; height: 24px; fill: var(--color-icon-high-emphasis);">
                                            <use class="disable-events" xlink:href="#notificationBell"></use>
                                        </svg>
                                    </div>
                                </div>
                                <div class="grow-1"></div>
                                <div class="color-n-500 text-body-1 dir-ltr"><?=gjdate($record['created_at'])?></div></div>
                            <div class="d-flex flex-row jc-center"><p class="text-body1-strong color-n-700"><?=esc_html($record['title'])?></p>
                                <div class="grow-1"></div>
                                <button class="relative d-flex ai-center user-select-none btn-wc51H8 text-button-2 btn--text-se4oQM btn--primary-uiqWij radius Button__medium-gIvke_ Button__textPrimary-IWW5Sd AccordionButton--commonClasses-Qnp0XR Button-rn45"
                                        data-testid="button-wrapper" data-id="<?=esc_attr($record['Id'])?>">
                                    <div class="d-flex ai-center jc-center relative grow-1">
                                        <div class="d-flex AccordionButton--expandIcon-P1W7MA"
                                             data-testid="icon-wrapper">
                                            <svg style="width: 24px; height: 24px; fill: var(--color-icon-high-emphasis);">
                                                <use class="disable-events" xlink:href="#expandLess"></use>
                                            </svg>
                                        </div>
                                    </div>
                                </button>
                            </div>
                            <div class="Accordion-bhT9dH Accordion__exit-F8WmEG Accordion__exitActive-HuOwrM">
                                <div>
                                    <div class="text-body-1 color-text-low-emphasis "><?=wp_kses_post($record['body'])?></div>
                                </div>
                            </div>
                        </section>
                        <?php
                    }else{
                        ?>
                        <section
                                class="TableRowContainer__visited-TUSUSu py-2 px-4 my-3 d-grid ai-center NotificationCard__tableRow-opMsDI TableRowDesktop-xIiuFo radius-md">
                            <div class="NotificationCard__title-GEjaN6 d-flex flex-row">
                                <div class="d-flex flex-row">
                                    <div class="d-flex ml-5" data-testid="icon-wrapper">
                                        <svg style="width: 24px; height: 24px; fill: var(--color-icon-high-emphasis);">
                                            <use class="disable-events" xlink:href="#notificationBellRead"></use>
                                        </svg>
                                    </div>
                                </div>
                                <div class="grow-1"></div>
                                <div class="color-n-500 text-body-1 dir-ltr"><?=gjdate($record['created_at'])?></div></div>
                            <div class="d-flex flex-row jc-center"><p class="text-body1-strong color-n-700"><?=esc_html($record['title'])?></p>
                                <div class="grow-1"></div>
                                <button class="relative d-flex ai-center user-select-none btn-wc51H8 text-button-2 btn--text-se4oQM btn--primary-uiqWij radius Button__medium-gIvke_ Button__textPrimary-IWW5Sd AccordionButton--commonClasses-Qnp0XR Button-rn45"
                                        data-testid="button-wrapper">
                                    <div class="d-flex ai-center jc-center relative grow-1">
                                        <div class="d-flex AccordionButton--expandIcon-P1W7MA"
                                             data-testid="icon-wrapper">
                                            <svg style="width: 24px; height: 24px; fill: var(--color-icon-high-emphasis);">
                                                <use class="disable-events" xlink:href="#expandLess"></use>
                                            </svg>
                                        </div>
                                    </div>
                                </button>
                            </div>
                            <div class="Accordion-bhT9dH Accordion__exit-F8WmEG Accordion__exitActive-HuOwrM">
                                <div>
                                    <div class="text-body-1 color-text-low-emphasis "><?=wp_kses_post($record['body'])?></div>
                                </div>
                            </div>
                        </section>
                        <?php

                    }
                }
                $recordsCount = $db->query("SELECT COUNT(*) AS total FROM `{$wpdb->prefix}notifications` n LEFT JOIN `{$wpdb->prefix}notification_reads` r ON r.`notification_id` = n.`Id` AND r.`user_id` = :user_id WHERE n.`is_active`=1 AND (n.`userId` IS NULL OR n.`userId`=0 OR n.`userId`=:user_id)", array('user_id' => $user_id))[0]['total'];
                $pageCount = ceil($recordsCount/10);
                echo '<div class="flex justify-end"><div class="v10__Pagination">';
                for ($i = $paged-1; $i <= $paged+1; $i++) {
                    if ($i < 1){
                        continue;
                    }
                    if ($i>$pageCount){continue;}
                    if ($paged == $i){
                        echo '<button class="v10__Pagination-item Button-np51 active">' . $i . '</button>';
                    }else {
                        echo '<button class="v10__Pagination-item Button-np51" data-page="' . $i . '">' . $i . '</button>';
                    }
                }
                echo '</div></div> ';
            }else{
                ?>
                <section class="p-5 TableCard--bodyMobile-tDS3OZ">
                    <div class="d-flex ai-center jc-center align-center w-100 h-100">
                        <div class="py-4 d-flex flex-column jc-center ai-center EmptyState__desktopContainer-ggZkIg">
                            <div class="d-flex jc-center mb-3" data-testid="empty-src">
                                <div data-testid="image-wrapper" style="width: 200px; height: 150px;">
                                    <img class="w-100"
                                         src="<?=get_template_directory_uri()?>/assets/img/ticket_img.png"
                                         width="200"
                                         height="150"
                                         data-testid="image-defaultImage"
                                         style="object-fit: contain;">
                                </div>
                            </div>
                            <div class="text-h5 color-900">نتیجه&zwnj;ای پیدا نکردیم...</div>
                            <div class="text-caption-strong color-500" data-testid="empty-description">
                                <div>فیلترها را تغییر دهید و دوباره امتحان کنید</div>
                            </div>
                        </div>
                    </div>
                </section>
                <?php
            }

            $output = ob_get_clean();
            echo json_encode(['status' => true, 'html'=>$output]);
        }
        elseif($_POST['method'] == 'ticket'){
            global $wpdb;
            $db = Db::getLnstance();
            $startIndex = ($paged-1)*10;
            if (is_current_user_admin()){
                $records = $db->query("SELECT * FROM  {$wpdb->prefix}ticket WHERE rep_Id IS NULL ORDER BY `ticketId` DESC LIMIT $startIndex, 10");
                if (!empty($records)){
                    $pageCount = $db->query("SELECT COUNT(*) AS total FROM  {$wpdb->prefix}ticket WHERE rep_Id IS NULL");
                }
            }else {
                $records = $db->query("SELECT * FROM  {$wpdb->prefix}ticket WHERE userId=$user_id AND rep_Id IS NULL ORDER BY `ticketId` DESC LIMIT $startIndex, 10");
                if (!empty($records)) {
                    $pageCount = $db->query("SELECT COUNT(*) AS total FROM  {$wpdb->prefix}ticket WHERE userId=$user_id AND rep_Id IS NULL");
                }
            }
            ob_start();
            if (!empty($records)){
                foreach ($records as $key=>$record){
                                            if (is_numeric($record['categoryId'])) {
                                                $categorys = $db->query("SELECT * FROM  `{$wpdb->prefix}ticketing_category` WHERE `categoryId`=:id", array(
                                                        'id' => $record['categoryId'],
                                                ));
                                            }else{
                                                $categoryId = explode('|',decrypt_data($record['categoryId']));
                                                $categorys = [['name'=>"سفارش #".$categoryId[0]]];
                                            }
                                            ?>

                                            <section
                                                    class="TableRowContainer__normal-Uv6APM py-2 px-4 my-3 d-grid TableRowDesktop-xIiuFo rounded-full">
                                                <div class="d-grid py-2"
                                                     style="grid-template-columns: 0.4fr 0.8fr 1.3fr 1.3fr 0.6fr 0.8fr 0.7fr 0.7fr;">
                                                    <div class="pr-2 pl-2 text-body-1 d-flex ai-center color-text-high-emphasis mt-1 gap-x-2">
                                                        <div class="pr-2 pl-2 text-body-1 d-flex ai-center color-text-high-emphasis color-text-low-emphasis">
                                                            <?=$key+1?>
                                                        </div>
                                                    </div>
                                                    <div class="pr-2 pl-2 text-body-1 d-flex ai-center color-text-high-emphasis">
                                                        S-<?=$record['ticketId']?>
                                                    </div>
                                                    <div class="pr-2 pl-2 text-body-1 d-flex ai-center color-text-high-emphasis">
                                                        <?=$record['Issue']?>
                                                    </div>
                                                    <div class="pr-2 pl-2 text-body-1 d-flex ai-center color-text-high-emphasis">
                                                        <?=$categorys[0]['name']?>
                                                    </div>
                                                    <div class="pr-2 pl-2 text-body-1 d-flex ai-center color-text-high-emphasis">
                                                        <?=gjdate($record['time'],"Y-m-d")?>
                                                    </div>
                                                    <?php $times = $db->query("SELECT t1.*, t2.*
FROM {$wpdb->prefix}ticket t1
LEFT JOIN {$wpdb->prefix}ticket t2 ON t1.ticketId = t2.rep_Id
WHERE t1.ticketId = :ticketId
ORDER BY t1.time DESC
LIMIT 1;",array('ticketId'=>$record['ticketId'])); ?>
                                                    <div class="pr-2 pl-2 text-body-1 d-flex ai-center color-text-high-emphasis">
                                                        <?=!empty($times[0]['time']) ? gjdate($times[0]['time'],"H:i - Y-m-d") : "-"?>
                                                    </div>
                                                    <div class="pr-2 pl-2 text-body-1 d-flex ai-center color-text-high-emphasis">
                                                        <?php
                                                        if ($record['condition'] == 0){
                                                            $cls = 'Badge__info-st92ed';
                                                            $nm = "جدید";
                                                        }elseif ($record['condition'] == 1){
                                                            $cls = 'Badge__info-16f59';
                                                            $nm = "درحال بررسی";
                                                        }elseif ($record['condition'] == 2){
                                                            $cls = 'Badge__warning-MfubDgd';
                                                            $nm = "در انتظار جزئیات";
                                                        }elseif ($record['condition'] == 3){
                                                            $cls = 'Badge__success-AVxEpg';
                                                            $nm = "حل شده";
                                                        }elseif ($record['condition'] == 4){
                                                            $cls = 'Badge__neutral-XFzczo';
                                                            $nm = "بسته شده";
                                                        }
                                                        ?>
                                                        <div class="d-inline-flex ai-center <?=$cls?> text-no-wrap Badge-vPRt_1 Badge--medium-SregFw px-3 text-body2-strong"
                                                             style="background-color: var(--color-undefined); color: var(--color-undefined);">
                                                            <?=$nm?>
                                                        </div>
                                                    </div>
                                                    <div class="pr-2 pl-2 text-body-1 d-flex ai-center color-text-high-emphasis justify-end">
                                                        <?php $gid = ($record['ticketId']) * 10 / 5?>
                                                        <a
                                                                href="<?=esc_url( get_permalink() )?>id/<?=$gid?>">
                                                            <button class="relative d-flex ai-center user-select-none btn-wc51H8 text-button-2 btn--outlined-I96mhk btn--primary-uiqWij rounded-full Button__medium-gIvke_ Button__outlinedPrimary-V1OV6N Button-MNNP44"
                                                                    data-testid="button-wrapper">
                                                                <div class="d-flex ai-center jc-center relative grow-1">مشاهده
                                                                    تیکت
                                                                </div>
                                                            </button>
                                                        </a></div>
                                                </div>
                                            </section>
                                            <?php
                                        }
            echo '<div class="flex justify-end"><div class="v10__Pagination">';
                for ($i = $paged-1; $i <= $paged+1; $i++) {
                    if ($i < 1){
                        continue;
                    }
                    if ($i>ceil($pageCount[0]['total']/10)){continue;}
                if ($paged == $i){
                    echo '<button class="v10__Pagination-item Button-np52 active">' . $i . '</button>';
                }else {
                    echo '<button class="v10__Pagination-item Button-np52" data-page="' . $i . '">' . $i . '</button>';
                }
            }
            echo '</div></div> ';
            }else{
                ?>
                <section class="p-5 TableCard--bodyMobile-tDS3OZ">
                    <div class="d-flex ai-center jc-center align-center w-100 h-100">
                        <div class="py-4 d-flex flex-column jc-center ai-center EmptyState__desktopContainer-ggZkIg">
                            <div class="d-flex jc-center mb-3" data-testid="empty-src">
                                <div data-testid="image-wrapper" style="width: 200px; height: 150px;"><img class="w-100"
                                                                                                           src="<?=get_template_directory_uri()?>/assets/img/ticket_img.png"
                                                                                                           width="200"
                                                                                                           height="150"
                                                                                                           data-testid="image-defaultImage"
                                                                                                           style="object-fit: contain;">
                                </div>
                            </div>
                            <div class="text-h5 color-900">نتیجه&zwnj;ای پیدا نکردیم...</div>
                            <div class="text-caption-strong color-500" data-testid="empty-description">
                                <div>فیلترها را تغییر دهید و دوباره امتحان کنید</div>
                            </div>
                        </div>
                    </div>
                </section>
            <?php }
            $output = ob_get_clean();
            echo json_encode(['status' => true, 'html'=>$output]);
        }else{
            echo json_encode(['status' => false]);
        }
    }

    private static function clear_checkout_cart($user_id = null): void
    {
        if (function_exists('WC')) {
            if (null === WC()->session) {
                WC()->initialize_session();
            }
            if (null === WC()->cart) {
                WC()->cart = new \WC_Cart();
            }

            WC()->cart->empty_cart(true);
            WC()->cart->remove_coupons();

            if (WC()->session) {
                foreach ([
                    'cart_created_time',
                    'rial_coupon',
                    'wallet_dirty',
                    'use_wallet',
                    'wallet_discount',
                    '_wallet_discount',
                    '_use_wallet',
                ] as $key) {
                    WC()->session->__unset($key);
                }
                WC()->session->set_customer_session_cookie(true);
            }
        }

        $user_id = $user_id ? absint($user_id) : get_current_user_id();
        if ($user_id > 0) {
            delete_user_meta($user_id, '_woocommerce_persistent_cart_' . get_current_blog_id());
        }
    }
    public function cart_api_function(){
            ob_start();
            if (null === WC()->session)  WC()->initialize_session();
            if (null === WC()->customer) WC()->customer = new \WC_Customer(get_current_user_id(), true);
            if (null === WC()->cart)     WC()->cart = new \WC_Cart();
            ?>
            <div class="<?=WC()->cart &&  WC()->cart->get_cart() && is_user_logged_in() ? 'cart-preview__grid cart-preview__grid--board ' : ''?> cart-panel ">
                <?php

                if (WC()->cart &&  WC()->cart->get_cart() && is_user_logged_in()){

                    $cart_items = WC()->cart->get_cart();
                    ?>
                    <div class="flex flex-col lg:w-70 justify-between md:h-stretch">
                        <div class="flex md:h-380">
                            <div class="cart-panel--list">
                                <div>
                                    <div class="flex justify-between">
                                        <div class="act-our-services-carousel-head-title">
                                            <div class="act-our-services-carousel-head-title-divs">
                                                <div class="act-our-services-carousel-head-title-div1 tsc54b"></div>
                                            </div>
                                            <div class="act-our-services-carousel-head-title-content">
                                                <h5>سبد <strong>خرید</strong></h5>
                                                <p class="tsc54">SHOPPING CART</p>
                                            </div>
                                        </div>
                                        <span class="SJf5GS"><?= ( WC()->cart ) ? WC()->cart->get_cart_contents_count() : 0?></span>
                                    </div>
                                    <div class="cart-list">
                                        <?php
                                        if(!isMobile()){
                                            ?>
                                            <table class="cart-table">
                                                <thead><tr><th>محصول</th><th>تعداد</th><th>قیمت واحد</th><th>جمع کل</th></tr></thead>
                                                <tbody>
                                                <?php
                                                foreach ( $cart_items as $cart_item_key => $cart_item ) {

                                                    $product = $cart_item['data']; // آبجکت محصول
                                                    $product_id = $product->get_id();
                                                    $name = $product->get_name();
                                                    $quantity = $cart_item['quantity'];
                                                    $regular_price = $product->get_regular_price();
                                                    $sale_price = $product->get_sale_price();
                                                    $price = $product->get_price(); // قیمت نهایی
                                                    $subtotal = $cart_item['line_subtotal']; // جمع جزء
                                                    $total = $cart_item['line_total']; // جمع با تخفیف
                                                    $thumbnail = $product->get_image(); // تصویر محصول (HTML)
                                                    $permalink = $product->get_permalink();


                                                    ?>
                                                    <tr data-mini-item="<?=$cart_item_key?>">
                                                        <td>
                                                            <div class="flex">
                                                                <div class="self-center">
                                                                    <a class="font-size-14 text-dark font-bold tracking-tight leading-xs" href="<?=$permalink?>"><?=$name?></a></div>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="rounded bg-light flex flex-row-reverse transition-opacity h-40 w-112">
                                                                <button type="button" class="pl-6 mini-quantity__btn" data-mini-decrease="">
                                                                    <?php
                                                                    if ($quantity == 1){
                                                                        ?>
                                                                        <i class="icon-delete text-xs text-red-dark text-opacity-90 bg-white shadow-sm block text-center rounded-sm w-28 h-28 !leading-[28px]"></i>
                                                                        <?php
                                                                    }else{
                                                                        ?>
                                                                        <i class="icon-minus text-[9px] text-gray pt-1 bg-white shadow-sm block text-center rounded-sm w-28 h-28 !leading-[28px]"></i>

                                                                        <?php
                                                                    }
                                                                    ?>
                                                                </button>
                                                                <div class="grow text-center flex flex-col justify-center leading-1">
                                                                    <div class="pt-2 text-dark font-bold tracking-tighter text-sm after:loading after:border-blue transition-colors after:text-3xs" data-mini-qty><?=$quantity?></div>
                                                                </div>
                                                                <button type="button" class="pr-6 mini-quantity__btn" data-mini-increase="">
                                                                    <i class="bg-white shadow-sm text-gray rounded-sm icon-plus text-[9px] block text-center pt-1 w-28 h-28 !leading-[28px]"></i>
                                                                </button>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="leading-1 pt-2 grow">
                                                                <?php
                                                                if ($product->is_on_sale()){
                                                                    ?>
                                                                    <span class="ml-6 font-size-13 text-sm font-bold text-red opacity-85 tracking-tighter mb-2 block line-through"><?=number_format_usd($regular_price)?></span>
                                                                    <?php
                                                                }
                                                                ?>
                                                                <div class="text-2xs font-size-13 text-gray font-medium tracking-tight"><span
                                                                            class="text-lg font-bold text-dark tracking-tighter pt-2 inline-block"><?=number_format_usd($product->is_on_sale() ? $sale_price : $regular_price)?></span>
                                                                    تومان
                                                                </div>
                                                            </div>
                                                        </td>
                                                        <?php
                                                        $regular_price = (float) $product->get_regular_price();
                                                        $quantity      = (int)  $cart_item['quantity'];

                                                        $price_original_total = $regular_price * $quantity;
                                                        $price_final_total    = $cart_item['line_total'];
                                                        ?>
                                                        <td>
                                                            <div class="leading-1 pt-2 grow">
                                                                <?php
                                                                if ( $price_original_total > $price_final_total ) { ?>
                                                                    <span class="ml-6 font-size-13text-sm font-bold text-red opacity-85 tracking-tighter mb-2 block line-through"><?=number_format_usd($price_original_total)?></span>
                                                                    <?php
                                                                }
                                                                ?>
                                                                <div class="text-2xs text-gray font-medium tracking-tight"><span
                                                                            class="font-size-13 text-lg font-bold text-dark tracking-tighter pt-2 inline-block"><?=number_format_usd($price_final_total)?></span>
                                                                    تومان
                                                                </div>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                    <?php
                                                }
                                                ?>
                                                </tbody>
                                            </table>
                                            <?php
                                        }else{
                                            ?>
                                            <div class="cart-list">
                                                <?php
                                                foreach ( $cart_items as $cart_item_key => $cart_item ) {

                                                    $product = $cart_item['data'];
                                                    $name = $product->get_name();
                                                    $permalink = $product->get_permalink();
                                                    $thumbnail = $product->get_image(); // تصویر محصول (HTML)

                                                    ?>
                                                    <div class="p-20 border-b border-gray-300 last:!border-b-0" data-mini-item="<?=$cart_item_key?>">
                                                        <div class="flex">
                                                            <div class="pt-4 self-center grow pl-12">
                                                                <a class="text-normal text-dark font-bold tracking-tight leading-xs block" href="<?=$permalink?>"><?=$name?></a>
                                                                <div class="leading-xs mt-6 space-y-5"></div>
                                                            </div>
                                                            <a class="shrink-0" href="<?=$permalink?>">
                                                                <div class="relative">
                                                                    <img alt="<?=$name?>" loading="lazy" width="72" height="72" decoding="async" data-nimg="1" class="shrink-0 rounded block w-60" src="<?=wp_get_attachment_image_url($product->get_image_id(),'product_discount')?>" style="color: transparent;">
                                                                </div>
                                                            </a>
                                                        </div>
                                                        <div class="flex items-start mt-12">
                                                            <div class="leading-1 pt-2 grow self-center">
                                                                <?php
                                                                $regular_price = (float) $product->get_regular_price();
                                                                $quantity      = (int)  $cart_item['quantity'];

                                                                $price_original_total = $regular_price * $quantity;
                                                                $price_final_total    = $cart_item['line_total'];
                                                                ?>
                                                                <div class="leading-1 pt-2 grow">
                                                                    <?php
                                                                    if ( $price_original_total > $price_final_total ) { ?>
                                                                        <span class="ml-6 font-size-13text-sm font-bold text-red opacity-85 tracking-tighter mb-2 block line-through"><?=number_format_usd($price_original_total)?></span>
                                                                        <?php
                                                                    }
                                                                    ?>
                                                                    <div class="text-2xs text-gray font-medium tracking-tight"><span
                                                                                class="font-size-13 text-lg font-bold text-dark tracking-tighter pt-2 inline-block"><?=number_format_usd($price_final_total)?></span>
                                                                        تومان
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="rounded bg-light flex flex-row-reverse transition-opacity h-40 lg:w-60">
                                                                <button type="button" class="pl-6 mini-quantity__btn" data-mini-decrease="">
                                                                    <?php
                                                                    if ($quantity == 1){
                                                                        ?>
                                                                        <i class="icon-delete text-xs text-red-dark text-opacity-90 bg-white shadow-sm block text-center rounded-sm w-28 h-28 !leading-[28px]"></i>
                                                                        <?php
                                                                    }else{
                                                                        ?>
                                                                        <i class="icon-minus text-[9px] text-gray pt-1 bg-white shadow-sm block text-center rounded-sm w-28 h-28 !leading-[28px]"></i>

                                                                        <?php
                                                                    }
                                                                    ?>
                                                                </button>
                                                                <div class="grow text-center flex flex-col justify-center leading-1">
                                                                    <div class="pt-2 text-dark font-bold tracking-tighter text-sm after:loading after:border-blue transition-colors after:text-3xs" data-mini-qty><?=$quantity?></div>
                                                                </div>
                                                                <button type="button" class="pr-6 mini-quantity__btn" data-mini-increase="">
                                                                    <i class="bg-white shadow-sm text-gray rounded-sm icon-plus text-[9px] block text-center pt-1 w-28 h-28 !leading-[28px]"></i>
                                                                </button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <?php
                                                }
                                                ?>
                                            </div>
                                            <?php
                                        }
                                        ?>
                                    </div>
                                </div>
                                <div>
                                    <div class="flex justify-between<?=!isMobile() ? '' : ' flex-col'?>">
                                        <?php
                                        $total_points = 0;

                                        foreach ( WC()->cart->get_cart() as $cart_item_key => $cart_item ) {

                                            $product  = $cart_item['data'];
                                            $quantity = $cart_item['quantity'];

                                            $settings = get_post_meta($product->get_id(), 'giftmax_box_setting', true);

                                            $item_points = empty($settings[0]['purchaseScore']) ? 0 : $settings[0]['purchaseScore'];

                                            $line_points = $item_points * $quantity;

                                            WC()->cart->cart_contents[ $cart_item_key ]['points'] = $line_points;

                                            $total_points += $line_points;
                                        }

                                        WC()->session->set( 'total_cart_points', $total_points );
                                        if (!isMobile()){
                                            ?>
                                            <div class="cart-timer" role="status">
                                                <p class="eyebrow font-size-13">مهلت تکمیل خرید</p>
                                                <h3 class="cart-timer__value" data-cart-timer=""></h3>
                                            </div>
                                            <div class="cart__purchaseScore">
                                                <i class="icon-star"></i>
                                                شما بابت این خرید <strong class="font-bold" id="total_points"><?=number_format($total_points)?> امتیاز</strong> دریافت میکنید!
                                            </div>
                                            <?php
                                        }else{?>
                                            <div class="tracking-tight alert text-xs font-normal rounded-none px-16 lg:px-28 py-8 lg:py-12 flex items-center border-y border-dashed lg:mt-20 timerBox justify-between" style="background: linear-gradient(135deg, rgba(99, 102, 241, 0.08), rgba(139, 92, 246, 0.15)); border-color: rgb(203, 181, 255);">
                                                <p class="eyebrow font-size-13">مهلت تکمیل خرید</p>
                                                <h3 class="cart-timer__value" data-cart-timer=""></h3>
                                            </div>
                                            <div class="tracking-tight alert alert-primary bg-primary bg-opacity-[0.12] text-xs font-normal rounded-none px-16 lg:px-28 py-8 lg:py-12 flex items-center border-y border-primary border-dashed border-opacity-50 lg:mt-20 pointBox"><i class="icon-star text-[#D19411] text-xs ml-8 -mr-2"></i>
                                                <div class="grow pst-4 flex align-items-center">شما بابت این خرید <strong class="font-bold"><?=number_format($total_points)?></strong> دریافت میکنید!</div>
                                            </div>
                                            <?php
                                        }
                                        ?>
                                    </div>
                                </div>
                            </div>
                            <div class="cart-panel--invoice">
                                <div class="act-our-services-carousel-head-title">
                                    <div class="act-our-services-carousel-head-title-divs">
                                        <div class="act-our-services-carousel-head-title-div1 tsc54b"></div>
                                    </div>
                                    <div class="act-our-services-carousel-head-title-content">
                                        <h5>احراز <strong>هویت</strong> </h5>
                                        <p class="tsc54">IDENTITY VERIFICATION</p>
                                    </div>
                                </div>
                                <?php
                                $user = wp_get_current_user();
                                $u = UserModel::table('user_identity','user_id',$user->ID);
                                $isVip = (isset($u['account_type']) && $u['account_type'] === 'vip');
                                ?>
                                <div class="profile-content">
                                    <div class="profile-section-container">
                                        <div class="profile-section c-box__info <?=$isVip ? 'w-full' : ''?>">
                                            <div>IP<span><?=giftmax_get_user_ip()?></span></div>
                                            <?php
                                            ?>
                                            <div>
                                                شماره تلفن
                                                <span><?=$user->user_login?></span>
                                            </div>
                                            <div>
                                                تلفن ثابت
                                                <?php
                                                if (!empty($u['landline_phone'])){
                                                    ?>
                                                    <span><?=decrypt_data($u['landline_phone'])?></span>
                                                    <?php
                                                }else{?>
                                                    <div class="Button-lp56">تایید تلفن ثابت</div>
                                                    <?php
                                                }
                                                ?>
                                            </div>
                                            <div>کدملی<span><?=!empty($u['national_id_enc']) ? decrypt_data($u['national_id_enc']) : ''?></span></div>
                                            <div>تاریخ تولد<span><?=!empty($u['birth_date_enc']) ? decrypt_data($u['birth_date_enc']) : ''?></span></div>
                                            <div>سطح اکانت
                                                <?php
                                                if (isset($u['account_type']) && $u['account_type'] == 'vip'){
                                                    ?>
                                                    <span style="
    background-color: #ff9100;
    color: #FFF;
    padding: 0 10px;
    border-radius: 8px;
">ویژه</span>
                                                    <?php
                                                }else{?>
                                                    <span style="background-color: #ff0000; color: #FFF; padding: 3px; border-radius: 8px; font-size: 12px; line-height: 1; display: flex; align-items: center;">معمولی</span>
                                                <?php }
                                                ?>
                                            </div>
                                        </div>
                                    </div>

                                    <script>
                                        window.vip = <?= $isVip ? 1 : 0; ?>;
                                    </script>
                                    <?php
                                    global $wpdb;
                                    $db = \Giftmax\Modules\Db::getLnstance();
                                    $records = $db->first("SELECT * FROM `{$wpdb->prefix}setting` WHERE `meta_key`='stp'");
                                    if (!empty($records)){
                                        $record = json_decode($records['meta_value'], true);
                                        if ($isVip){
                                            ?>
                                            <div class="profile-section-container">
                                                <div class="profile-section px-[16px]">
                                                    <div class="flex justify-between">
                                                        <div class="flex justify-between lg:w-50">
                                                            <h5>امتیاز وفاداری </h5>
                                                            <p class="wejF5 profile-bpp"><?=number_format(UserModel::points())?></p>
                                                        </div>
                                                        <button class="Button-cc65 sdJHS56">
                                                            تبدیل به اعتبار
                                                        </button>
                                                    </div>
                                                </div>
                                                <p class="profile-text-info"><?='هر' . number_format($record[0]['points']) . ' امتیاز معادل است با' . number_format($record[0]['toman'])?></p>
                                            </div>

                                            <div class="profile-section-container mt-3">
                                                <div class="profile-section px-[16px]" style="margin-bottom: 0">
                                                    <div class="flex justify-between align-items-center">
                                                        <div class="flex flex-col">
                                                            <h5>کیف پول</h5>
                                                        </div>
                                                        <button class="Button-oc64 sdJHS56">
                                                            افزایش
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                            <?php
                                        }else{
                                            ?>
                                            <div class="flex justify-between profile-section-container xs:flex-col">
                                                <?php
                                                if (isMobile()){?>
                                                    <div class="w-full">
                                                        <div class="profile-section px-[10px]">
                                                            <div class="flex justify-between">
                                                                <div class="flex justify-between" style="width: 68%">
                                                                    <h5>امتیاز </h5>
                                                                    <p class="wejF5 profile-bpp" style="border-radius: 999px"><?=number_format(UserModel::points())?></p>
                                                                </div>
                                                                <button class="Button-cc65 sdJHS56">
                                                                    تبدیل به اعتبار
                                                                </button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="w-full">
                                                        <div class="profile-section px-[10px]">
                                                            <div class="flex justify-between align-items-center">
                                                                <div class="flex flex-col">
                                                                    <h5>کیف پول</h5>
                                                                </div>
                                                                <button class="Button-oc64 sdJHS56">
                                                                    افزایش
                                                                </button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                <?php }else{?>
                                                    <div class="lg:w-60">
                                                        <div class="profile-section px-[10px]">
                                                            <div class="flex justify-between">
                                                                <div class="flex justify-between lg:w-50">
                                                                    <h5>امتیاز </h5>
                                                                    <p class="wejF5 profile-bpp"><?=number_format(UserModel::points())?></p>
                                                                </div>
                                                                <button class="Button-cc65 sdJHS56">
                                                                    تبدیل به اعتبار
                                                                </button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="lg:w-40 mr-1">
                                                        <div class="profile-section px-[10px]">
                                                            <div class="flex justify-between align-items-center">
                                                                <div class="flex flex-col">
                                                                    <h5>کیف پول</h5>
                                                                </div>
                                                                <button class="Button-oc64 sdJHS56">
                                                                    افزایش
                                                                </button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                <?php }
                                                ?>
                                            </div>
                                            <div class="profile-section-container">
                                                <p class="profile-text-info"><?='هر' . number_format($record[0]['points']) . ' امتیاز معادل است با' . number_format($record[0]['toman'])?></p>
                                            </div>
                                            <?php
                                        }
                                    }
                                    if (!$isVip){
                                        $db = Db::getLnstance();
                                        global $wpdb;
                                        $cards = $db->query(
                                            "SELECT * FROM `{$wpdb->prefix}user_bank_cards` WHERE `user_id` = :user_id AND `is_active`=1",
                                            array('user_id' => $user->ID)
                                        );
                                        ?>
                                        <div class="profile-section-container">
                                            <div class="card-grid card-grid--swiper profile-section" style="margin-bottom: 0">
                                                <duv class="flex justify-between">
                                                    <div class="profile-section-section-name">
                                                        <div class="flex justify-between gap-2">
                                                            <span>کارت های بانکی</span>
                                                            <?php
                                                            if (!empty($cards) && count($cards) !=0){
                                                                ?>
                                                                <p class="profile-bpp"><?=count($cards)?></p>
                                                                <?php
                                                            }else{
                                                                ?>
                                                                <p class="profile-bpp">0</p>
                                                                <?php
                                                            }
                                                            ?>
                                                        </div>
                                                    </div>
                                                    <button class="Button-ac45">افزودن</button>
                                                </duv>
                                                <?php
                                                if (!empty($cards)) {
                                                    ?>
                                                    <div class="swiper bank-cards-swiper">
                                                        <div class="swiper-wrapper">
                                                            <?php foreach ($cards as $card) {
                                                                $cardNumber = rtrim(
                                                                    chunk_split(decrypt_data($card['card_number_enc']), 4, '-'),
                                                                    '-'
                                                                );
                                                                    ?>
                                                                    <div class="swiper-slide">
                                                                        <article class="bank-card">
                                                                            <div class="bank-card-content">
                                                                                <div class="flex justify-end align-items-center">
                                                                                    <div class="bank-card__top">
                                                                                        <div class="bank-card__logo" aria-hidden="true">
                                                                                            <img loading="lazy" decoding="async" data-nimg="1" class="h-auto" src="<?=detectBankImage(decrypt_data($card['card_number_enc']))?>" style="color: transparent;width: 20px" data-booster-processed="true">
                                                                                        </div>
                                                                                    </div>
                                                                                    <div class="bank-card__number"><?=$cardNumber?></div>
                                                                                </div>
                                                                                <?php
                                                                                if (empty($card['phone'])){
                                                                                    ?>
                                                                                    <div class="flex justify-between align-items-center relative">
                                                                                        <div class="bank-card_user_status success">
                                                                                            تحت مالکیت شما
                                                                                        </div>
                                                                                        <div class="w-[50px] lottie-container absolute -right-50" data-lottie-url="<?=get_template_directory_uri()?>/assets/img/wsl/card-done.json"></div>
                                                                                    </div>
                                                                                    <?php
                                                                                }else{?>
                                                                                    <div class="flex justify-between align-items-center relative">
                                                                                        <div class="bank-card_user_status danger">
                                                                                            مالک شما نیستید
                                                                                        </div>
                                                                                        <div class="w-[50px] lottie-container absolute -right-50" data-lottie-url="<?=get_template_directory_uri()?>/assets/img/wsl/card-error.json"></div>
                                                                                    </div>
                                                                                <?php }
                                                                                ?>
                                                                            </div>
                                                                            <div class="V10-3-Bank">
                                                                                <?php
                                                                                $cardSetting = detectBankImageBg($cardNumber,'v1');
                                                                                if (empty($card['phone'])){
                                                                                    $user = get_userdata($card['user_id']);
                                                                                    $userdata = UserModel::table('user_identity','user_id',$card['user_id']);
                                                                                    ?>
                                                                                    <span class="numberCard" style="bottom: <?=$cardSetting['positionText']?>px;<?=!is_null($cardSetting['color']) ? "color:" . $cardSetting['color'] : '' ?>"><?=$cardNumber?></span>
                                                                                    <img alt="bank" loading="lazy" src="<?=$cardSetting['img']?>">
                                                                                    <span class="number-user" style="bottom: <?=$cardSetting["Box"]["y"]?>px;color:<?=$cardSetting["Box"]["color"]?>"><?=$user->user_login?></span>
                                                                                    <span class="birthday-user" style="bottom: <?=$cardSetting["Box"]["y"]?>px;color:<?=$cardSetting["Box"]["color"]?>"><?=decrypt_data($userdata['birth_date_enc'])?></span>
                                                                                    <span class="national__code-user" style="bottom: <?=$cardSetting["Box"]["y"]?>px;color:<?=$cardSetting["Box"]["color"]?>"><?=decrypt_data($userdata['national_id_enc'])?></span>
                                                                                    <span class="full__name-user" style="bottom: <?=$cardSetting["Box"]["y"]?>px;color:<?=$cardSetting["Box"]["color"]?>"><?=$user->first_name . ' ' . $user->last_name?></span>

                                                                                    <?php
                                                                                }else{
                                                                                    ?>
                                                                                    <span class="numberCard" style="bottom: <?=$cardSetting['positionText']?>px;<?=!is_null($cardSetting['color']) ? "color:" . $cardSetting['color'] : '' ?>"><?=$cardNumber?></span>
                                                                                    <span class="number-user" style="bottom: <?=$cardSetting["Box"]["y"]?>px;color:<?=$cardSetting["Box"]["color"]?>"><?=decrypt_data($card['phone'])?></span>
                                                                                    <span class="birthday-user" style="bottom: <?=$cardSetting["Box"]["y"]?>px;color:<?=$cardSetting["Box"]["color"]?>"><?=decrypt_data($card['birth_date'])?></span>
                                                                                    <span class="national__code-user" style="bottom: <?=$cardSetting["Box"]["y"]?>px;color:<?=$cardSetting["Box"]["color"]?>"><?=decrypt_data($card['national_code'])?></span>
                                                                                    <span class="full__name-user" style="bottom: <?=$cardSetting["Box"]["y"]?>px;color:<?=$cardSetting["Box"]["color"]?>"><?=$card['first_name'] . ' ' . $card['last_name']?></span>
                                                                                    <img alt="bank" loading="lazy" src="<?=$cardSetting['img']?>">
                                                                                <?php }
                                                                                ?>
                                                                            </div>
                                                                        </article>
                                                                    </div>

                                                                    <?php
                                                            } ?>
                                                        </div>
                                                    </div>
                                                    <?php
                                                } else {
                                                    ?>
                                                    <div class="flex justify-center align-items-center px-[10px]">
                                                        <div class="lottie-container w-[50px]" data-lottie-url="<?=get_template_directory_uri()?>/assets/img/wsl/card.json"></div>
                                                        <div class="text-body2-strong text-[#027275]">کارت بانکی ثبت نشده</div>
                                                    </div>
                                                        <?php
                                                }
                                                ?>
                                            </div>
                                        </div>
                                        <?php
                                    }
                                    ?>
                                </div>
                            </div>
                        </div>
                        <div class="ktfb">
                            <h4>نکات مهم :</h4>
                            <p> 1.  سبد خرید شما تا زمانی که پرداخت نهایی انجام نشه، قطعی رزرو نشده.لطفاً تا ۵ دقیقه آینده سفارشتون رو تکمیل و پرداخت کنید، وگرنه آیتم‌های داخل سبد به صورت خودکار آزاد و حذف می‌شن.</p>
                            <p> 2. در صورت تکمیل سفارش و انجام فرایند احراز هویت و تحویل محصول خریداری شده ،فاکتور قابل عودت و برگشت به هیچ وجه ممکن نخواهد بود.</p>
                            <p>3. درصورت عودت هرگونه وجهی ، 10% ارزش افزوده از مبلغ واریزی کسر و باقیمانده مبلغ طی 24 ساعت کاری به همان کارت بانکی که خرید شده است عودت خواهد شد.</p>
                        </div>
                    </div>

                    <div class="cart-panel--payment lg:w-30 md:h-stretch">
                        <div class="act-our-services-carousel-head-title">
                            <div class="act-our-services-carousel-head-title-divs">
                                <div class="act-our-services-carousel-head-title-div1 tsc54b"></div>
                            </div>
                            <div class="act-our-services-carousel-head-title-content">
                                <h5><strong>پرداخت</strong> </h5>
                                <p class="tsc54">PAYMENT</p>
                            </div>
                        </div>
                        <div class="flex justify-between" style="margin: 21px 0">
                            <button class="payment active Button-pr44"><div>پرداخت ریالی</div></button>
                            <button class="payment Button-pu44"><div>پرداخت با رمز ارز ها</div></button>
                        </div>
                        <div class="invoice-board">
                            <div class="flex flex-col relative grow">
                                <div class="grow before:loading">
                                    <div class="space-y-10 lg:space-y-12 lg:sticky lg:top-28">
                                        <?php
                                        $cart_product_discount = 0;

                                        foreach ( WC()->cart->get_cart() as $cart_item ) {
                                            $product = $cart_item['data'];
                                            $qty     = (int) $cart_item['quantity'];
                                            $regular_price = (float) $product->get_regular_price();
                                            $line_total    = $cart_item['line_total'];

                                            $cart_product_discount += ($regular_price * $qty) - $line_total;
                                        }

                                        $total_discount        = $cart_product_discount;
                                        ?>
                                        <div class="flex items-center leading-xs"><span class="grow text-xs tracking-tight font-medium text-dark">قیمت کل</span>
                                            <div class="text-2xs text-gray font-medium tracking-tight" data-summary="subtotal">
                                                <span
                                                        class="text-larger font-bold text-dark tracking-tighter pt-2 inline-block"><?=number_format_usd(WC()->cart->get_subtotal()+$total_discount)?></span>
                                                تومان
                                            </div>
                                        </div>
                                        <div class="flex items-center leading-xs"><span
                                                    class="grow text-xs tracking-tight font-medium text-dark">تخفیف سبد خرید</span>
                                            <div class="text-2xs text-gray font-medium tracking-tight" data-summary="discount">
                                                <span class="text-larger font-bold text-red tracking-tighter pt-2 inline-block"><?= number_format_usd($total_discount) ?></span>
                                                تومان
                                            </div>
                                        </div>
                                        <div class="flex items-center leading-xs">
                                            <div class="grow">
                                                <span class="block text-xs tracking-tight font-medium text-dark">کد تخفیف</span>
                                            </div>
                                            <button type="button" class="btn !w-28 !text-5xs !text-green-dark !pt-2 !h-28 btn-white btn-icon icon-plus relative Button-cc59" aria-label="افزودن کد تخفیف"></button>
                                        </div>
                                        <div class="flex items-center leading-xs justify-between Box-cs65">
                                            <div class="flex flex-col">
                                                <span class="grow text-xs tracking-tight font-medium text-dark pt-1">استفاده از کیف پول</span>
                                                <span id="balance" class="grow text-xs tracking-tight font-medium text-dark pt-1 <?=empty(UserModel::wallet()) || !empty(UserModel::wallet()) && UserModel::wallet() ==0 ? 'hidden' : ''?>" style=" color: #a7a7a7; font-size: 12px; "><?=number_format(UserModel::wallet())?> تومان</span>
                                            </div>
                                            <div class="text-2xs text-gray font-medium tracking-tight">
                                                <label for="wallet" class="input-label start w40_1">
                                                    <span class="start-label"></span>
                                                    <?php
                                                    if (!empty(UserModel::wallet()) && UserModel::wallet() != 0){
                                                        ?>
                                                        <input id="wallet" type="checkbox" class="input" <?= WC()->session->get('use_wallet',false) ? 'checked' : ''?>>
                                                        <?php
                                                    }
                                                    ?>
                                                    <span class="input-check" style="<?=empty(UserModel::wallet()) || !empty(UserModel::wallet()) && UserModel::wallet() ==0 ? 'cursor: no-drop;' : ''?>"></span>
                                                </label>
                                            </div>
                                        </div>
                                        <div class="hr-p"></div>
                                        <div class="flex items-center leading-xs"><span
                                                    class="grow text-xs tracking-tight font-medium text-dark pt-1">مبلغ قابل پرداخت</span>
                                            <div class="text-2xs text-gray font-medium tracking-tight" data-summary="total">
                                                <span class="text-lg font-bold text-green-dark tracking-tighter pt-2 inline-block"><?=number_format_usd( WC()->cart->get_total('edit'))?></span>
                                                تومان
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="border rounded mt-14 lg:mt-16 gateway-row flex">
                                    <button type="button" class="border-l w-full text-right border-gray-300 last:!border-l-0 py-16 px-14 flex items-center Button-p4" data-gateway="zibal">
                                        <div class="pt-2 grow leading-1 tracking-tight">
                                            <span class="block text-xs text-dark font-bold">پرداخت آنلاین</span>
                                            <span class="block text-2xs font-normal text-dark mt-8">درگاه پرداخت زیبال</span>
                                        </div>
                                        <i class="w-20 h-20 text-center rounded-circle text-4xs pl-1 ml-4 !leading-[22px] icon-check transition-colors text-white bg-green bg-opacity-100"></i>
                                    </button>
                                    <button type="button" class="border-l w-full text-right border-gray-300 last:!border-l-0 py-16 px-14 flex items-center Button-p4" data-gateway="paystar">
                                        <div class="pt-2 grow leading-1 tracking-tight">
                                            <span class="block text-xs text-dark font-bold">پرداخت آنلاین</span>
                                            <span class="block text-2xs font-normal text-dark mt-8">درگاه پرداخت پی استار</span>
                                        </div>
                                        <i class="w-20 h-20 text-center rounded-circle bg-gray bg-opacity-15 text-4xs pl-1 ml-4 !leading-[22px] icon-check text-transparent transition-colors"></i>
                                    </button>
                                </div>
                                <div class="css-transition-opacity after:loading !absolute inset-x-0 inset-y-0 bg-white bg-opacity-50 is-loading after:border-gray after:border-opacity-75 after:h-24 after:w-24 after:border-[3px] z-10 rounded-bl-lg"></div>
                            </div>
                        </div>
                        <div class="swiper supported__brands hidden">
                            <div class="swiper-wrapper">
                                <div class="swiper-slide">
                                    <img alt="" loading="lazy" width="1000" height="120" decoding="async"
                                         data-nimg="1" class="block dark:hidden" style="color:transparent"
                                         src="<?=get_template_directory_uri()?>/assets/img/assets.jpeg"></div>
                                <div class="swiper-slide">
                                    <img alt="" loading="lazy" width="1000" height="120" decoding="async"
                                         data-nimg="1" class="block dark:hidden" style="color:transparent"
                                         src="<?=get_template_directory_uri()?>/assets/img/assets.jpeg"></div>
                                <div class="swiper-slide">
                                    <img alt="" loading="lazy" width="1000" height="120" decoding="async"
                                         data-nimg="1" class="block dark:hidden" style="color:transparent"
                                         src="<?=get_template_directory_uri()?>/assets/img/assets.jpeg"></div>
                                <div class="swiper-slide">
                                    <img alt="" loading="lazy" width="1000" height="120" decoding="async"
                                         data-nimg="1" class="block dark:hidden" style="color:transparent"
                                         src="<?=get_template_directory_uri()?>/assets/img/assets.jpeg"></div>
                            </div>
                        </div>
                        <button class="btn btn--gradient btn--block Button-pcu48">ثبت سفارش</button>
                        <p class="payment--alert">کاربر گرامی <?="$user->first_name $user->last_name"?> ، خواهشمند است در هنگام پرداخت دقت فرمایید؛ زیرا جنس و کد دریافتی تحت هیچ شرایطی قابل عودت نمی‌باشد.</p>
                    </div>
                    <?php
                }else{
                    if(!is_user_logged_in()){
                        echo "<div class='flex mx-auto'><span>برای دسترسی به سبد خرید لاگین کنید</span></div>";
                    }else if(empty(WC()->cart) || empty(WC()->cart->get_cart())){
                        echo "<div class='flex mx-auto'><span>سبد خرید شما خالی است</span></div>";
                    }
                }
                ?>
            </div>
            <?php
            $output = ob_get_clean();
            return [
                'status' => true,
                'html'  => $output,
                'ig' => is_user_logged_in() ? true : false
            ];
    }
    public function stats_api_function(){
        $records = UserModel::table("setting","meta_key","currency");
        if ($records && isset($records['meta_value'])) {
            echo $records['meta_value']; // دیگه نیاز به json_decode و دوباره json_encode نیست
        } else {
            header('Content-Type: application/json; charset=utf-8');
            echo json_encode(['error' => 'داده‌ای یافت نشد'], JSON_UNESCAPED_UNICODE);
        }
    }
    public function verifyCart_api_function(){
        if (!isset($_POST['id'])){
            echo json_encode([
                'status'=>false,
                'message' => 'ورودی ارسال نشده'
            ]);
            exit();
        }
        $id = $_POST['id'];
        $order = wc_get_order( decrypt_id($id) );
        if (!$order){
            echo json_encode([
                'status'=>false,
                'message' => 'سفارش یافت نشد'
            ]);
            exit();
        }
        $user_id = get_current_user_id();
        if ($order->get_user_id() != $user_id){
            echo json_encode([
                'status'=>false,
                'message' => 'سفارش یافت نشد',
            ]);
            exit();
        }
        $cardPay = $order->get_meta( '_card_pay', true );
        $card = UserModel::table('user_bank_cards', 'card_number_enc', encrypt_data($cardPay),"user_id",$user_id);
        if (!empty($card)) {
            $phoneNumber = decrypt_data($card['phone']);
            $otp = mt_rand(100000, 999999);
            $expiry = date("Y-m-d H:i:s", strtotime("+2 minutes"));
            UserModel::expiryEnd();
            $records = UserModel::exitOtp($phoneNumber);
            if (!empty($records) && strtotime($records['otp_expiry']) < time()) {
                UserModel::otpDelete($records['id']);
            }
            if (empty($records)) {
                UserModel::otp($phoneNumber, $otp, $expiry);
            }
            $url = "https://portal.avanak.ir/rest/SendOTP";
            $url = $url . "?" . "Token=" . urlencode("1ACAAF7BC85B6AB3B54E5381A72EDCDC67D7BF06");
            $url = $url . "&" . "Length=6";
            $url = $url . "&" . "Number=" . $phoneNumber;
            $url = $url . "&" . "OptionalCode=" . $otp;

            $json = file_get_contents($url);
            if ($json->ErrorCode == 0) {
                $output = ["status" => true, "percent" => 90];
            } else {
                $output = ["status" => false, "message" => " خطایی پیش آمد در ارسال OTP", "percent" => 0];
            }
            $output['chl'] = 1;
            $output['html'] = '<div class="Hint--primary-mwFS2H Hint__padding-nRd4K4 radius Hint__iconStart-bpg5ZO mb-3" data-testid="hint-wrapper"><div class="d-flex ai-center"><div class="d-flex Hint__titleSlot-yPP6H0" data-testid="icon-wrapper"><svg style="width: 24px; height: 24px; fill: #1ab1d4;"><path d="M2 12c0 5.523 4.477 10 10 10s10-4.477 10-10c0-5.523-4.477-10-10-10s-10 4.477-10 10zM12 7c0.552 0 1 0.448 1 1s-0.448 1-1 1c-0.552 0-1-0.448-1-1s0.448-1 1-1zM10 10h3v7h-2v-5h-1v-2z"></path></svg></div><span class="mr-2 text-body-1 color-brand-primary-700 Hint__padding--title-AHG0eM">کد تأیید شما به شماره &lrm;'.$phoneNumber.'&rlm; ارسال گردید. خواهشمندیم برای تکمیل مراحل، آن را در محل تعیین&zwnj;شده وارد فرمایید. </span></div></div><p class="mb-2 color-n-700 text-body-1 mb-2" data-testid="form-label">کد otp را وارد کنید</p><div class="_wrap_87tyg_1 _input_pjp0p_66"> <input type="text" class="_input_87tyg_11" data-method="order" name="otp" inputmode="numeric"> <div class="_digit_87tyg_33"><span></span></div> <div class="_digit_87tyg_33"><span></span></div> <div class="_digit_87tyg_33"><span></span></div> <div class="_digit_87tyg_33"><span></span></div> <div class="_digit_87tyg_33"><span></span></div> <div class="_digit_87tyg_33"><span></span></div> </div><input class="hidden" type="hidden" name="hash" value="'.encrypt_data($id."||".'otp').'">';
            echo json_encode($output);
        }else{
            $output = ["status" => true, "percent" => 50];
            $output['html'] = '<div class="Hint--primary-mwFS2H Hint__padding-nRd4K4 radius Hint__iconStart-bpg5ZO mb-3" data-testid="hint-wrapper"><div class="d-flex ai-center"><div class="d-flex Hint__titleSlot-yPP6H0" data-testid="icon-wrapper"><svg style="width: 24px; height: 24px; fill: #1ab1d4;"><path d="M2 12c0 5.523 4.477 10 10 10s10-4.477 10-10c0-5.523-4.477-10-10-10s-10 4.477-10 10zM12 7c0.552 0 1 0.448 1 1s-0.448 1-1 1c-0.552 0-1-0.448-1-1s0.448-1 1-1zM10 10h3v7h-2v-5h-1v-2z"></path></svg></div><span class="mr-2 text-body-1 color-brand-primary-700 Hint__padding--title-AHG0eM">برای تکمیل مراحل لطفا شماره تلفن،کدملی و تاریخ تولد متعلق به صاحب کارت به شماره <p class="inline-block">' . rtrim(chunk_split($cardPay, 4, '-'), '-') . '</p> را وارد کنید</span></div></div><div class="d-flex flex-column gap-y-5"><div class="d-flex"> <div class="lg:w-50"> <label class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--L7bcQ uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--normal--A6Ntt w-full"> <p class="text-body-1 color-n-700 mb-2 text-right" data-testid="form-label">نام</p> <div class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame__input-container--D5edN px-2 d-flex ai-center"> <section class="grow-1 text-body-2-c"><input class="px-2 eFydYiN7dQ1Ds63mli7f text-subtitle w-100 jDSbpqUrUZFv23opBao9 color-n-700" type="text" name="firstName" placeholder="" value=""></section> </div> </label> </div> <div class="lg:w-50 mr-3"> <label class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--L7bcQ uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--normal--A6Ntt w-full"> <p class="text-body-1 color-n-700 mb-2 text-right" data-testid="form-label">نام خانوادکی</p> <div class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame__input-container--D5edN px-2 d-flex ai-center"> <section class="grow-1 text-body-2-c"><input class="px-2 eFydYiN7dQ1Ds63mli7f text-subtitle w-100 jDSbpqUrUZFv23opBao9 color-n-700" type="text" name="lastName" placeholder="" value=""></section> </div> </label> </div> </div><label class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--L7bcQ uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--normal--A6Ntt text-body-1 color-n-700 w-100"><p class="mb-2 color-n-700 text-body-1 mb-2" data-testid="form-label">شماره همراه</p><div class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame__input-container--D5edN px-2 d-flex ai-center"><section class="grow-1 text-body-2-c"><input class="px-2 TextField__input-_5fbdd text-subtitle w-100 TextField-e58168" type="text" name="phone-number"></section></div></label><di> <div class="diexjw5" data-select2-id="select2-data-9-k644"> <div class="form-group col-sm-12" data-select2-id="select2-data-8-0exr"> <p class="text-body-1 color-n-700 mb-2 text-right" data-testid="form-label">تاریخ تولد</p> <div class="row g-2 xs:mt-1"> <div class="col-4"> <div class="form-group"> <select class="js-example-basic-single select2-hidden-accessible" name="year" id="year" data-select2-id="select2-data-year" tabindex="-1" aria-hidden="true"> <option value="" disabled="" selected="" data-select2-id="select2-data-2-dxoo"> سال </option> <option value="1320">1320</option> <option value="1321">1321</option> <option value="1322">1322</option> <option value="1323">1323</option> <option value="1324">1324</option> <option value="1325">1325</option> <option value="1326">1326</option> <option value="1327">1327</option> <option value="1328">1328</option> <option value="1329">1329</option> <option value="1330">1330</option> <option value="1331">1331</option> <option value="1332">1332</option> <option value="1333">1333</option> <option value="1334">1334</option> <option value="1335">1335</option> <option value="1336">1336</option> <option value="1337">1337</option> <option value="1338">1338</option> <option value="1339">1339</option> <option value="1340">1340</option> <option value="1341">1341</option> <option value="1342">1342</option> <option value="1343">1343</option> <option value="1344">1344</option> <option value="1345">1345</option> <option value="1346">1346</option> <option value="1347">1347</option> <option value="1348">1348</option> <option value="1349">1349</option> <option value="1350">1350</option> <option value="1351">1351</option> <option value="1352">1352</option> <option value="1353">1353</option> <option value="1354">1354</option> <option value="1355">1355</option> <option value="1356">1356</option> <option value="1357">1357</option> <option value="1358">1358</option> <option value="1359">1359</option> <option value="1360">1360</option> <option value="1361">1361</option> <option value="1362">1362</option> <option value="1363">1363</option> <option value="1364">1364</option> <option value="1365">1365</option> <option value="1366">1366</option> <option value="1367">1367</option> <option value="1368">1368</option> <option value="1369">1369</option> <option value="1370">1370</option> <option value="1371">1371</option> <option value="1372">1372</option> <option value="1373">1373</option> <option value="1374">1374</option> <option value="1375">1375</option> <option value="1376">1376</option> <option value="1377">1377</option> <option value="1378">1378</option> <option value="1379">1379</option> <option value="1380">1380</option> <option value="1381">1381</option> <option value="1382">1382</option> <option value="1383">1383</option> <option value="1384">1384</option> <option value="1385">1385</option> <option value="1386">1386</option> <option value="1387">1387</option> </select> </div> </div> <div class="col-4"> <div class="form-group"> <select class="js-example-basic-single select2-hidden-accessible" name="month" id="month" data-select2-id="select2-data-month" tabindex="-1" aria-hidden="true"> <option value="" disabled="" selected="" data-select2-id="select2-data-4-s9eo"> ماه </option> <option value="01" data-select2-id="select2-data-15-h89y">فروردین</option><option value="02" data-select2-id="select2-data-16-8m35">اردیبهشت</option><option value="03" data-select2-id="select2-data-17-nepr">خرداد</option><option value="04" data-select2-id="select2-data-18-pzth">تیر</option><option value="05" data-select2-id="select2-data-19-ntlh">مرداد</option><option value="06" data-select2-id="select2-data-20-9qy8">شهریور</option><option value="07" data-select2-id="select2-data-21-hu81">مهر</option><option value="08" data-select2-id="select2-data-22-hvit">آبان</option><option value="09" data-select2-id="select2-data-23-xi7i">آذر</option><option value="10" data-select2-id="select2-data-24-bozm">دی</option><option value="11" data-select2-id="select2-data-25-dud8">بهمن</option><option value="12" data-select2-id="select2-data-26-zmw3">اسفند</option>                                            </select> </div> </div> <div class="col-4"> <div class="form-group"> <select class="js-example-basic-single select2-hidden-accessible" name="day" id="day" data-select2-id="select2-data-day" tabindex="-1" aria-hidden="true"> <option value="" disabled="" selected="" data-select2-id="select2-data-6-vgsy"> روز </option> <option value="01">01</option> <option value="02">02</option> <option value="03">03</option> <option value="04">04</option> <option value="05">05</option> <option value="06">06</option> <option value="07">07</option> <option value="08">08</option> <option value="09">09</option> <option value="10">10</option> <option value="11">11</option> <option value="12">12</option> <option value="13">13</option> <option value="14">14</option> <option value="15">15</option> <option value="16">16</option> <option value="17">17</option> <option value="18">18</option> <option value="19">19</option> <option value="20">20</option> <option value="21">21</option> <option value="22">22</option> <option value="23">23</option> <option value="24">24</option> <option value="25">25</option> <option value="26">26</option> <option value="27">27</option> <option value="28">28</option> <option value="29">29</option> <option value="30">30</option> <option value="31">31</option> </select> </div> </div> </div> </div> </div>            </di><label class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--L7bcQ uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--normal--A6Ntt lg:w-30 text-body-1 color-n-700 w-100"> <p class="mb-2 color-n-700 text-body-1 mb-2" data-testid="form-label">کدملی</p> <div class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame__input-container--D5edN px-2 d-flex ai-center"> <section class="grow-1 text-body-2-c"><input class="px-2 TextField__input-_5fbdd text-subtitle w-100 TextField-e58168" type="text" name="national-code"></section> </div> </label></div><input class="hidden" type="hidden" name="hash" value="'.encrypt_data($id."||".'register').'">';
            echo json_encode($output);
        }
    }
    public function alert_api_function()
    {
        if (is_user_logged_in()) {
            $userId = get_current_user_id();
            global $wpdb;
            $db = Db::getLnstance();
            $records = $db->first("SELECT * FROM `{$wpdb->prefix}alert` WHERE userId=:userId OR userId=0",array('userId'=>$userId));
            if (empty($records)) {
                $records = null;
            }else{
                $records = $records['hash'];
            }
            return \wp_send_json_success(array(
                'status' => 'true',
                'records' => $records
            ));
        }else{
            return \wp_send_json_success(array('status' => 'true'));
        }
    }
    public function alertNotifFunction()
    {
        if (is_user_logged_in()) {
            if($_POST['method'] == 'delete') {
                UserModel::deleteAlert('alert', $_POST['id'],1);
                \wp_send_json_success(array(
                    'status' => 'true'
                ));
            }else if ($_POST['method'] == 'show') {
                $hash = isset($_POST['id']) ? $_POST['id'] : 0;
                $user_id = get_current_user_id();
                if ($hash == 0 || $user_id <= 0) {
                    return new \WP_REST_Response([
                        'status' => false,
                        'message' => 'درخواست نامعتبر است'
                    ], 400);
                }

                $db = Db::getLnstance();
                global $wpdb;
                $records = UserModel::table('alert', 'hash', $hash);
                if (!empty($records)){
                    $id = $records['notificationsId'];
                    $notification = $db->first("SELECT Id,userId,body,title FROM `{$wpdb->prefix}notifications` WHERE `Id`=:Id AND `is_active`=1 AND (`userId` IS NULL OR `userId`=0 OR `userId`=:user_id)", array(
                        'Id' => $id,
                        'user_id' => $user_id,
                    ));

                    if (empty($notification)) {
                        return new \WP_REST_Response([
                            'status' => false,
                            'message' => 'اعلان یافت نشد'
                        ], 404);
                    }
                    $db->insert("INSERT INTO `{$wpdb->prefix}notification_reads` (`notification_id`,`user_id`,`seen_at`) VALUES (:notification_id,:user_id,NOW()) ON DUPLICATE KEY UPDATE `seen_at` = VALUES(`seen_at`)", array(
                        'notification_id' => $id,
                        'user_id' => $user_id,
                    ));
                    $db->modify("UPDATE `{$wpdb->prefix}notifications` SET `status`='read' WHERE `Id`=:Id AND `userId`=:user_id", array(
                        'Id' => $id,
                        'user_id' => $user_id,
                    ));
                    UserModel::deleteAlert($user_id,$id);
                    unset($notification['Id']);
                    unset($notification['userId']);
                    return \wp_send_json_success([
                        'status' => true,
                        'html' => 'OK',
                        'notification' => $notification
                    ]);
                }else{
                    return \wp_send_json_success(array('status' => 'false','message'=>"پیام موجود نمیباشد"));
                }
            } else{
                return \wp_send_json_success(array('status' => 'true'));
            }
        }else{
            return \wp_send_json_success(array('status' => 'true'));
        }
    }
    public function mc_api_function( ){
        if ( null === WC()->session )      WC()->initialize_session();
        if ( null === WC()->customer )     WC()->customer = new \WC_Customer( get_current_user_id(), true );
        if ( null === WC()->cart )         WC()->cart = new \WC_Cart();
        $total_points = 0;

        foreach ( WC()->cart->get_cart() as $cart_item_key => $cart_item ) {

            $product  = $cart_item['data'];
            $quantity = $cart_item['quantity'];

            $settings = get_post_meta($product->get_id(), 'giftmax_box_setting', true);

            $item_points = empty($settings[0]['purchaseScore']) ? 0 : $settings[0]['purchaseScore'];

            $line_points = $item_points * $quantity;

            WC()->cart->cart_contents[ $cart_item_key ]['points'] = $line_points;

            $total_points += $line_points;
        }
        return \wp_send_json_success(array(
                'point' => $total_points,
            'inventory' => UserModel::wallet() !=0 ?number_format(UserModel::wallet()).'تومان' : 0
        ));
    }
    public function filterRegion_api_function()
    {
        ob_start();
        if ($_POST['cat']) {
            $term_id = $_POST['cat'];
            $term = get_term($term_id, 'product_cat');
            $term_name = $term->name;
            $term_link = get_term_link($term);
        }
        $giftmax_is_user_logged_in = is_user_logged_in();
        $giftmax_wishlist_ids = $giftmax_is_user_logged_in ? giftmax_get_user_wishlist_product_ids() : [];
        if ($_POST['cat']){
            ?>
            <div class="act-new-service-carousel-head d-flex align-items-center justify-content-between">
                <svg xmlns="http://www.w3.org/2000/svg" width="1281" height="75" viewBox="0 0 1281 75" fill="none" class="act-new-service-carousel-head-svg">
                    <path d="M1280.47 0.5H1000.91C986.771 0.5 979.703 0.5 973.764 2.99163C969.027 4.9789 964.838 8.07733 961.551 12.025C957.43 16.9747 955.361 23.7331 951.224 37.25C947.086 50.7669 945.017 57.5253 940.896 62.475C937.609 66.4227 933.42 69.5211 928.683 71.5084C922.744 74 915.676 74 901.54 74H412.882C399.847 74 393.329 74 387.813 71.8926C382.12 69.7177 377.167 65.9625 373.536 61.0686C370.017 56.3267 368.257 50.0512 364.737 37.5C361.217 24.9488 359.457 18.6733 355.938 13.9314C352.307 9.0375 347.353 5.2823 341.661 3.10737C336.145 1 329.627 1 316.592 1H0" stroke="url(#paint0_linear_29_20094)"></path>
                    <defs>
                        <linearGradient id="paint0_linear_29_20094" x1="29.4736" y1="0.500002" x2="1213.79" y2="-28.0511" gradientUnits="userSpaceOnUse">
                            <stop stop-color="#0B61FF" stop-opacity="0"></stop>
                            <stop offset="0.5" stop-color="#0B61FF"></stop>
                            <stop offset="1" stop-color="#0B61FF" stop-opacity="0"></stop>
                        </linearGradient>
                    </defs>
                </svg>
                <div class="act-our-services-carousel-head-title">
                    <div class="act-our-services-carousel-head-title-divs">
                        <div class="act-our-services-carousel-head-title-div1"></div>
                        <div class="act-our-services-carousel-head-title-div2"></div>
                    </div>
                    <div class="act-our-services-carousel-head-title-content V13-category-name">
                        <h5>
                            جدیدترین <strong><?php echo esc_html($term_name); ?></strong>
                        </h5>
                        <p>PRODUCTS</p>
                    </div>
                </div>
                <div class="act-new-service-carousel-head-content">

                    <a class="act-link-but" href="<?php echo esc_url($term_link); ?>" target="_blank" rel="nofollow">
                        مشاهده بیشتر
                        <svg xmlns="http://www.w3.org/2000/svg" width="34" height="34" viewBox="0 0 34 34" fill="currentcolor">
                            <path d="M20.0744 10.4295C20.2088 10.5639 20.2936 10.7477 20.2936 10.9599C20.2936 11.37 19.9542 11.7094 19.5441 11.7094L11.7094 11.7094L11.7094 19.5442C11.7094 19.9543 11.3699 20.2937 10.9598 20.2937C10.5497 20.2937 10.2103 19.9543 10.2103 19.5442L10.2103 10.9599C10.2103 10.5498 10.5497 10.2103 10.9598 10.2103L19.5441 10.2103C19.7562 10.2103 19.9401 10.2952 20.0744 10.4295Z"></path>
                            <path d="M11.611 10.5501L23.5116 22.4507C23.8015 22.7406 23.8015 23.2215 23.5116 23.5114C23.2217 23.8013 22.7409 23.8013 22.451 23.5114L10.5504 11.6108C10.2605 11.3209 10.2605 10.84 10.5504 10.5501C10.8403 10.2602 11.3211 10.2602 11.611 10.5501Z"></path>
                        </svg>
                    </a>
                </div>
            </div>
            <?php
        }else{?>
            <div class="act-new-service-carousel-head d-flex align-items-center justify-content-between">
                <svg xmlns="http://www.w3.org/2000/svg" width="1281" height="75" viewBox="0 0 1281 75" fill="none" class="act-new-service-carousel-head-svg">
                    <path d="M1280.47 0.5H1000.91C986.771 0.5 979.703 0.5 973.764 2.99163C969.027 4.9789 964.838 8.07733 961.551 12.025C957.43 16.9747 955.361 23.7331 951.224 37.25C947.086 50.7669 945.017 57.5253 940.896 62.475C937.609 66.4227 933.42 69.5211 928.683 71.5084C922.744 74 915.676 74 901.54 74H412.882C399.847 74 393.329 74 387.813 71.8926C382.12 69.7177 377.167 65.9625 373.536 61.0686C370.017 56.3267 368.257 50.0512 364.737 37.5C361.217 24.9488 359.457 18.6733 355.938 13.9314C352.307 9.0375 347.353 5.2823 341.661 3.10737C336.145 1 329.627 1 316.592 1H0" stroke="url(#paint0_linear_29_20094)"></path>
                    <defs>
                        <linearGradient id="paint0_linear_29_20094" x1="29.4736" y1="0.500002" x2="1213.79" y2="-28.0511" gradientUnits="userSpaceOnUse">
                            <stop stop-color="#0B61FF" stop-opacity="0"></stop>
                            <stop offset="0.5" stop-color="#0B61FF"></stop>
                            <stop offset="1" stop-color="#0B61FF" stop-opacity="0"></stop>
                        </linearGradient>
                    </defs>
                </svg>
                <div class="act-our-services-carousel-head-title">
                    <div class="act-our-services-carousel-head-title-divs">
                        <div class="act-our-services-carousel-head-title-div1"></div>
                        <div class="act-our-services-carousel-head-title-div2"></div>
                    </div>
                    <div class="act-our-services-carousel-head-title-content">
                        <h5>
                        </h5><h5>گیفت کارت <strong>پلی استیشن </strong></h5>
                        <p>GIFT CARD PLAYSTATION</p>
                    </div>
                </div>
                <div class="act-new-service-carousel-head-content">

                    <a class="act-link-but" href="<?=home_url('/shop')?>" rel="nofollow">
                        مشاهده بیشتر                    <svg xmlns="http://www.w3.org/2000/svg" width="34" height="34" viewBox="0 0 34 34" fill="currentcolor">
                            <path d="M20.0744 10.4295C20.2088 10.5639 20.2936 10.7477 20.2936 10.9599C20.2936 11.37 19.9542 11.7094 19.5441 11.7094L11.7094 11.7094L11.7094 19.5442C11.7094 19.9543 11.3699 20.2937 10.9598 20.2937C10.5497 20.2937 10.2103 19.9543 10.2103 19.5442L10.2103 10.9599C10.2103 10.5498 10.5497 10.2103 10.9598 10.2103L19.5441 10.2103C19.7562 10.2103 19.9401 10.2952 20.0744 10.4295Z"></path>
                            <path d="M11.611 10.5501L23.5116 22.4507C23.8015 22.7406 23.8015 23.2215 23.5116 23.5114C23.2217 23.8013 22.7409 23.8013 22.451 23.5114L10.5504 11.6108C10.2605 11.3209 10.2605 10.84 10.5504 10.5501C10.8403 10.2602 11.3211 10.2602 11.611 10.5501Z"></path>
                        </svg>

                    </a>
                </div>
            </div>
        <?php }
        $home_coupon_objects = [];
        $home_coupon_ids = get_posts([
            'post_type'      => 'shop_coupon',
            'post_status'    => 'publish',
            'numberposts'    => -1,
            'fields'         => 'ids',
        ]);

        if (!empty($home_coupon_ids)) {
            foreach ($home_coupon_ids as $home_coupon_id) {
                $home_coupon_objects[] = new \WC_Coupon($home_coupon_id);
            }
        }
        $args = [
                'post_type'      => 'product',
                'posts_per_page' => 16,
                'tax_query'      => [
                        [
                                'taxonomy' => 'product_cat',
                                'field'    => 'term_id',
                                'terms'    => 1022,
                        ]
                ],
                'meta_query' => [
                        'relation' => 'AND',

                        [
                                'relation' => 'OR',

                                [
                                        'key'     => 'giftmax_setting_order',
                                        'compare' => 'EXISTS',
                                        'type'    => 'NUMERIC',
                                ],

                                [
                                        'key'     => 'giftmax_setting_order',
                                        'compare' => 'NOT EXISTS',
                                ],
                        ],
                ],


                'orderby' => [
                        'meta_value_num' => 'ASC',
                        'date'           => 'DESC',
                ],
                'order'    => 'ASC',
        ];
        $region_args = [
            'post_type'      => 'product',
            'posts_per_page' => -1,
                'tax_query'      => [
                        [
                                'taxonomy' => 'product_cat',
                                'field'    => 'term_id',
                                'terms'    => 1022,
                        ]
                ],
            'fields'         => 'ids',
            'meta_query' => [
                [
                    'key'     => 'giftmax_box_setting',
                    'compare' => 'EXISTS'
                ]
            ]
        ];
        if ($_POST['cat']){
            $args['tax_query'] = [
                [
                    'taxonomy' => 'product_cat',
                    'field'    => 'term_id',
                    'terms'    => $term_id,
                ]
            ];
            $region_args['tax_query'] = [
                [
                    'taxonomy' => 'product_cat',
                    'field'    => 'term_id',
                    'terms'    => $term_id,
                ]
            ];
        }
        $selected_regions = $_POST['id'] ?? [];

        if (!empty($selected_regions) && $selected_regions != "All") {

            $args['meta_query'][] = [
                    'key'     => 'giftmax_box_setting',
                    'value'   => sprintf(
                            's:11:"logo_region";s:%d:"%s"',
                            strlen($selected_regions),
                            sanitize_text_field($selected_regions)
                    ),
                    'compare' => 'LIKE'
            ];
        }
        $region_query = new \WP_Query($region_args);

        $regions = [];

        foreach ($region_query->posts as $pid) {
            $settings = get_post_meta($pid, 'giftmax_box_setting', true);
            if (!empty($settings[0]['logo_region'])) {
                $regions[] = $settings[0]['logo_region'];
            }
        }

        $regions = array_unique($regions);
        $query = new \WP_Query($args);
        if ($query->have_posts()) :
            ?>
            <div class="w-full">
                <?php
                if (!isMobile()){?>
                    <div class="flex overflow-hidden mb-20">
                        <div class="flex justify-between lg:w-20 md:w-11">
                            <div class="act-our-services-carousel-head-title">
                                <div class="act-our-services-carousel-head-title-divs">
                                    <div class="act-our-services-carousel-head-title-div1 tsc54b"></div>
                                </div>
                                <div class="act-our-services-carousel-head-title-content">
                                    <h5>انتخاب <strong>کشور</strong> </h5>
                                    <p class="tsc54">SELECT REGION</p>
                                </div>
                            </div>
                        </div>
                        <div class="swiper c-box__ceWU4d" <?=isset($_POST['cat']) ? "data-cat='$term_id'" : ''?>>
                            <div class="swiper-wrapper">
                                <div data-id="" class="act-catagory-card swiper-slide pointer button-cc45  <?=$selected_regions=='All' ? 'active' : ''?>" style="width: 75px !important;">
                                    <div class="act-catagory-card-inner">
                                        <div class="act-catagory-card-name">
                                            <div class="act-our-services-carousel-head-title-divs">
                                                <div class="act-our-services-carousel-head-title-div1" style="height: 15px;  margin-bottom: 4px;"></div>
                                                <div class="act-our-services-carousel-head-title-div2" style=" height: 12px;"></div>
                                            </div>
                                            <div class="act-catagory-name-text">
                                                <strong>همه</strong>
                                                <p>All</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php
                                foreach ($regions as $region){
                                    ?>
                                    <div data-id="<?=$region?>" class="act-catagory-card swiper-slide pointer button-cc45  <?=$selected_regions==$region ? 'active' : ''?>">
                                        <div class="act-catagory-card-inner">
                                            <div class="act-catagory-card-name">
                                                <div class="act-our-services-carousel-head-title-divs">
                                                    <div class="act-our-services-carousel-head-title-div1" style="height: 15px;  margin-bottom: 4px;"></div>
                                                    <div class="act-our-services-carousel-head-title-div2" style=" height: 12px;"></div>
                                                </div>
                                                <div class="act-catagory-name-text">
                                                    <strong><?=regionPersian($region) ?></strong>
                                                    <p><?=$region?></p>
                                                </div>
                                            </div>
                                            <div class="act-catagory-card-img">
                                                <img src="<?=get_template_directory_uri() . '/assets/flag/' .$region . '.svg'?>">
                                            </div>
                                        </div>
                                    </div>
                                    <?php
                                }
                                ?>
                            </div>
                            <div class="swiper-navigation-region w-full absolute">
                                <div class="swiper-button-region swiper-button-prev-region">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                                        <path d="M13.583 12l-4.293 4.293 1.414 1.414 5-5c0.39-0.391 0.39-1.024 0-1.414l-5-5-1.414 1.414 4.293 4.293z"></path>
                                    </svg>
                                </div>
                                <div class="swiper-button-region swiper-button-next-region">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                                        <path d="M10.414 12l4.293 4.293-1.414 1.414-5-5c-0.391-0.391-0.391-1.024 0-1.414l5-5 1.414 1.414-4.293 4.293z"></path>
                                    </svg>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php }else{?>
                    <div class="flex flex-col overflow-hidden mb-20">
                        <div class="flex justify-between mb-20">
                            <div class="act-our-services-carousel-head-title">
                                <div class="act-our-services-carousel-head-title-divs"></div>
                                <div class="act-our-services-carousel-head-title-content">
                                    <h5>انتخاب <strong>کشور</strong> </h5>
                                    <p class="tsc54">SELECT REGION</p>
                                </div>
                            </div>
                            <div class="swiper-navigation-region gap-2">
                                <div class="swiper-button-region swiper-button-prev-region">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                                        <path d="M13.583 12l-4.293 4.293 1.414 1.414 5-5c0.39-0.391 0.39-1.024 0-1.414l-5-5-1.414 1.414 4.293 4.293z"></path>
                                    </svg>
                                </div>
                                <div class="swiper-button-region swiper-button-next-region">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                                        <path d="M10.414 12l4.293 4.293-1.414 1.414-5-5c-0.391-0.391-0.391-1.024 0-1.414l5-5 1.414 1.414-4.293 4.293z"></path>
                                    </svg>
                                </div>
                            </div>
                        </div>
                        <div class="swiper c-box__ceWU4d" <?=isset($_POST['cat']) ? "data-cat='$term_id'" : ''?>>
                            <div class="swiper-wrapper">
                                <div data-id="" class="act-catagory-card swiper-slide pointer button-cc45  <?=$selected_regions=='All' ? 'active' : ''?>" style="width: 75px !important;">
                                    <div class="act-catagory-card-inner">
                                        <div class="act-catagory-card-name">
                                            <div class="act-our-services-carousel-head-title-divs">
                                                <div class="act-our-services-carousel-head-title-div1" style="height: 15px;  margin-bottom: 4px;"></div>
                                                <div class="act-our-services-carousel-head-title-div2" style=" height: 12px;"></div>
                                            </div>
                                            <div class="act-catagory-name-text">
                                                <strong>همه</strong>
                                                <p>All</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php
                                foreach ($regions as $region){
                                    ?>
                                    <div data-id="<?=$region?>" class="act-catagory-card swiper-slide pointer button-cc45  <?=$selected_regions==$region ? 'active' : ''?>">
                                        <div class="act-catagory-card-inner">
                                            <div class="act-catagory-card-name">
                                                <div class="act-our-services-carousel-head-title-divs">
                                                    <div class="act-our-services-carousel-head-title-div1" style="height: 15px;  margin-bottom: 4px;"></div>
                                                    <div class="act-our-services-carousel-head-title-div2" style=" height: 12px;"></div>
                                                </div>
                                                <div class="act-catagory-name-text">
                                                    <strong><?=regionPersian($region) ?></strong>
                                                    <p><?=$region?></p>
                                                </div>
                                            </div>
                                            <div class="act-catagory-card-img">
                                                <img src="<?=get_template_directory_uri() . '/assets/flag/' .$region . '.svg'?>">
                                            </div>
                                        </div>
                                    </div>
                                    <?php
                                }
                                ?>
                            </div>
                        </div>
                    </div>
                <?php }
                ?>
                <div class="flex fhDGSJDF">
                    <?php while ($query->have_posts()) : $query->the_post(); global $product;
                        $regular = $product->get_regular_price();
                        $sale    = $product->get_sale_price();
                        $final_price = $product->is_on_sale() && $sale > 0 ? $sale : $regular;
                        $img = get_the_post_thumbnail_url(get_the_ID(), 'product_discount');
                        $settings = get_post_meta($product->get_id(), 'giftmax_box_setting', true);
                        $delivery = get_post_meta($product->get_id(), 'delivery', true);
                        $matched_coupon_code = '';

                        if (!empty($home_coupon_objects)) {
                            foreach ($home_coupon_objects as $home_coupon_obj) {
                                $expires_at = $home_coupon_obj->get_date_expires();

                                if ($expires_at && $expires_at->getTimestamp() < current_time('timestamp')) {
                                    continue;
                                }

                                if ($home_coupon_obj->is_valid_for_product($product)) {
                                    $matched_coupon_code = $home_coupon_obj->get_code();
                                    break;
                                }
                            }
                        }
                        ?>
                        <div>
                            <div class="act-new-service-card <?=!empty($matched_coupon_code) ? 'has-discount' : ''?>">
                                <?php if (!empty($matched_coupon_code) && !isMobile()) { ?>
                                    <div class="act-new-service-card-discount Button-sc91" data-product-id="<?=esc_attr($product->get_id())?>">
                                        <div class="anScr"></div>
                                        <div class="anSct">مشاهده کد تخفیف</div>
                                        <div class="anScl"></div>
                                    </div>
                                <?php } ?>
                                <div class="act-new-service-card-inner">
                                    <div <?=isset($delivery['two']) && $delivery['two'] == 'on' || product_available($product->get_id()) ?'':'class="NdhJD5"'?>>
                                        <div class="act-new-service-card-inner-top">
                                            <a href="<?=get_permalink()?>">
                                                <div class="act-new-service-card-inner-top-img-box relative">
                                                    <img loading="lazy" decoding="async" width="32" height="33" src="<?=$img?>" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="">
                                                    <?php
                                                    if (!empty($settings[0]['logo_region'])){
                                                        ?>
                                                        <div class="logo_region">
                                                            <img src="<?=empty($settings[0]['logo_region']) ?: get_template_directory_uri() . '/assets/flag/' . $settings[0]['logo_region'] . '.svg'?>">
                                                        </div>
                                                        <?php
                                                    }
                                                    $date_from = $product->get_date_on_sale_from();
                                                    $date_to   = $product->get_date_on_sale_to();
                                                    if ($product->is_on_sale() & ($date_from || $date_to)){
                                                        ?>
                                                        <div class="logo_detail" style="top: 7px;right: 7px;background-color: transparent;">
                                                            <img width="33" height="29" src="<?=get_template_directory_uri()?>/assets/img/svg/Amazings.svg">
                                                        </div>
                                                        <?php
                                                    } elseif ($product->is_on_sale()){
                                                        ?>
                                                        <div class="logo_detail" style="top: 7px;right: 7px;">
                                                            <img src="<?=get_template_directory_uri()?>/assets/img/svg/percent.svg">
                                                        </div>
                                                        <?php
                                                    }
                                                    ?>
                                                </div>
                                            </a>
                                            <div class="act-new-service-card-inner-top-txt-box" <?=!empty($settings[0]['label']) && $settings[0]['label'] != '' ? 'style="gap:2px"' : ''?>>
                                                <a href="<?=get_permalink()?>">
                                                    <h4 class="act-product-title"><?=get_the_title()?></h4>
                                                    <?php
                                                    if(!empty($settings[0]['sub_head']) && !isMobile()) echo "<p class='act-product-title-en'>" . $settings[0]['sub_head'] . "</p>";
                                                    ?>
                                                </a>
                                                <div class="flex justify-between">
                                                    <div class="flex">
                                                        <?php
                                                        $tooltip = isset($delivery['description']) ? $delivery['description'] : '';
                                                        ?>
                                                        <div class="act-product-option-box__nw <?=isset($delivery['two']) && $delivery['two'] == 'on' ? 'pre-sale wiki wiki__holder js-dk-wiki-trigger' : 'same-day'?>" <?=isset($delivery['two']) && $delivery['two'] == 'on' ? 'data-tooltip="'. $tooltip .'"' :''?>><?=isset($delivery['two']) && $delivery['two'] == 'on' ? 'پیش فروش' : 'تحویل آنی'?></div>
                                                        <div class="purchaseScore wiki wiki__holder js-dk-wiki-trigger" data-tooltip="با خرید این گیفت کارت <?=empty($settings[0]['purchaseScore']) ?0: $settings[0]['purchaseScore']?> امتیاز دریافت میکنید">
                                                            <i class="icon-star"></i>
                                                            <?=empty($settings[0]['purchaseScore']) ?0: $settings[0]['purchaseScore']?>
                                                        </div>
                                                    </div>
                                                    <?php $is_in_wishlist = in_array((int) $product->get_id(), $giftmax_wishlist_ids, true); ?>
                                                    <button class="add-to__favorites Button-alu84 <?=$is_in_wishlist ? 'is-active' : ''?>" data-product-id="<?=esc_attr($product->get_id())?>" data-auth="<?=$giftmax_is_user_logged_in ? '1' : '0'?>" style="width: 28px;height: 28px;border-radius: 7px">
                                                        <svg viewBox="0 0 24 24" style="width: 64%;">
                                                            <path d="M12.62 20.81C12.28 20.93 11.72 20.93 11.38 20.81C8.48 19.82 2 15.69 2 8.68998C2 5.59998 4.49 3.09998 7.56 3.09998C9.38 3.09998 10.99 3.97998 12 5.33998C13.01 3.97998 14.63 3.09998 16.44 3.09998C19.51 3.09998 22 5.59998 22 8.68998C22 15.69 15.52 19.82 12.62 20.81Z" fill="<?=$is_in_wishlist ? '#ef4444' : 'none'?>" stroke="<?=$is_in_wishlist ? '#ef4444' : 'inherit'?>" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                                                        </svg>
                                                    </button>
                                                </div>
                                                <?php if (!empty($matched_coupon_code) && isMobile()) { ?>
                                                    <div class="act-new-service-card-discount Button-sc91" data-product-id="<?=esc_attr($product->get_id())?>">
                                                        مشاهده کد تخفیف
                                                    </div>
                                                <?php }else{ ?>
                                                    <p class="act-product-txt"><?=empty($settings[0]['description_short']) ?'': $settings[0]['description_short']?></p>
                                                    <?php
                                                }
                                                ?>                                                <?php
                                                if (!empty($settings[0]['label']) && $settings[0]['label'] != ''){?>
                                                    <div class="label-fjd84">
                                                        <img src="<?=empty($settings[0]['label']) ?'': $settings[0]['label']?>" class="logo_label">
                                                        <p class="label_title"><?=empty($settings[0]['label_title']) ?'': $settings[0]['label_title']?></p>
                                                    </div>
                                                    <?php
                                                }
                                                ?>
                                            </div>
                                        </div>
                                    </div>
                                    <?php
                                    $date_from = $product->get_date_on_sale_from();
                                    $date_to   = $product->get_date_on_sale_to();
                                    if ($product->is_on_sale() & ($date_from || $date_to)) {
                                        $sale_from_ts = $date_from ? $date_from->getTimestamp() : null;
                                        $sale_to_ts   = $date_to ? $date_to->getTimestamp() : null;
                                        if ($sale_from_ts && $sale_to_ts) {
                                            $now_ts = time();
                                            $total_duration = $sale_to_ts - $sale_from_ts;
                                            $elapsed = $now_ts - $sale_from_ts;

                                            $progress_percent = max(0, min(100, ($elapsed / $total_duration) * 100));
                                        } else {
                                            $progress_percent = 0;
                                        }
                                    }else{
                                        $sale_to_ts = null;
                                    }
                                    if (!$sale_to_ts){
                                        ?>
                                        <div class="act-hor-bor"></div>
                                        <?php
                                    }else{
                                        ?>
                                        <div class="flex justify-between flex-col">
                                            <div class="relative bg-neutral-100 style_ProductPromotionTimeline__progress__JnKWE" style="">
                                                <div class="absolute bg-primary-700 h-full left-0 top-0 style_ProductPromotionTimeline--active__oYyta" style="width: <?=$progress_percent?>%;"></div>
                                            </div>
                                            <span class="text-primary-700 text-body2-strong style_ProductPromotionTimeline__timer__zS6ZA1 text-left"><?= date('Y-m-d H:i:s', $sale_to_ts); ?></span>

                                        </div>
                                        <?php
                                    }
                                    ?>
                                    <div>
                                        <?php
                                        if(!empty($matched_coupon_code)){
                                            $usage_limit  = (int) $home_coupon_obj->get_usage_limit();
                                            $usage_count  = (int) $home_coupon_obj->get_usage_count();

                                            $remaining_uses = $usage_limit > 0
                                                ? max( 0, $usage_limit - $usage_count )
                                                : __( 'نامحدود', 'textdomain' );
                                            ?>
                                            <div class="">
                                                <div class="relative bg-neutral-100 style_ProductPromotionTimeline__progress__JnKWE">
                                                    <div class="absolute bg-primary-700 h-full left-0 top-0 style_ProductPromotionTimeline--active__oYyta" style="width: <?=($home_coupon_obj->get_usage_count()/($home_coupon_obj->get_usage_count()+$remaining_uses))*100?>%;"></div>
                                                </div>
                                                <div class="whitespace-nowrap flex justify-between pt-1">
                                                    <div class=""><span class="text-primary-700 text-body-strong ml-1"><?=($home_coupon_obj->get_usage_count()/($home_coupon_obj->get_usage_count()+$remaining_uses))*100?>%</span><span class="text-neutral-500 text-caption">فروش رفته</span></div>
                                                    <?php
                                                    if ($home_coupon_obj->get_date_expires()){
                                                        ?>
                                                        <div class="text-primary-700 text-body2-strong style_ProductPromotionTimeline__timer__zS6ZA"><?= $home_coupon_obj->get_date_expires() ? $home_coupon_obj->get_date_expires()->date_i18n( 'Y-m-d H:i:s' ) : 'بدون تاریخ انقضا'?></div>
                                                        <?php
                                                    }else{?>
                                                        <div class="text-primary-700 text-body2-strong style_ProductPromotionTimeline__timer__zS6ZA"></div>
                                                    <?php }
                                                    ?>
                                                </div>
                                            </div>
                                            <?php
                                        }
                                        ?>
                                        <div class="act-product-card-footer">
                                            <a href="<?=the_permalink()?>" class="act-special-carousel-card-buy-box-option">جزئیات</a>
                                            <div class="act-product-price-box">
                                                <?php
                                                if ( $product->is_on_sale() ) {?>
                                                    <div class="act-product-price-box-top">
                                                        <div class="act-product-price-off-price"><?=number_format_usd($regular)?></div>
                                                        <div class="act-product-price-off-percent">  <?=get_discount_percent($product)?> ٪       </div>


                                                    </div>
                                                    <?php
                                                }
                                                ?>
                                                <div class="act-product-price<?=$product->is_on_sale() ? ' bpt' : ''?>">
                                                    <?php
                                                    if($final_price > 0){?>
                                                        <div id="priceValue" data-id="<?=$product->get_id()?>" data-target="<?=payment_usd($product->is_on_sale() ? $sale :$regular)?>"><?=number_format_usd($product->is_on_sale() ? $sale : $regular)?></div><span>تومان</span>
                                                        <?php
                                                    }else{
                                                        ?>
                                                        <div class="act-product-price-free">رایگان</div>
                                                        <?php
                                                    }
                                                    ?>
                                                </div>
                                            </div>
                                        </div>
                                        <?php
                                        if (isset($delivery['two']) && $delivery['two'] == 'on' || product_available($product->get_id())){
                                            if (\Giftmax\Modules\UserModel::setting("buy") === true){
                                                ?>
                                                <button type="button" class="act-special-carousel-card-buy-box-but Button-aca48 pointer" data-product-id="<?=$product->get_id()?>">
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="26" height="26" viewBox="0 0 26 26" fill="currentcolor">
                                                        <path d="M17.875 9.34916C17.4308 9.34916 17.0625 8.98083 17.0625 8.53666V7.04166C17.0625 5.90416 16.575 4.79916 15.73 4.03C14.8742 3.25 13.7692 2.8925 12.5992 3.00083C10.6492 3.185 8.9375 5.17833 8.9375 7.25833V8.30916C8.9375 8.75333 8.56917 9.12166 8.125 9.12166C7.68083 9.12166 7.3125 8.75333 7.3125 8.30916V7.2475C7.3125 4.33333 9.66333 1.64666 12.4475 1.37583C14.0725 1.22417 15.6325 1.73333 16.8242 2.8275C18.005 3.9 18.6875 5.43833 18.6875 7.04166V8.53666C18.6875 8.98083 18.3192 9.34916 17.875 9.34916Z"></path>
                                                        <path d="M16.2498 24.6457H9.7498C4.7448 24.6457 3.81314 22.3165 3.5748 20.0523L2.7623 13.5632C2.64314 12.3932 2.5998 10.714 3.7373 9.45734C4.7123 8.374 6.32647 7.854 8.66647 7.854H17.3331C19.684 7.854 21.2981 8.38484 22.2623 9.45734C23.389 10.714 23.3565 12.3932 23.2373 13.5415L22.4248 20.0523C22.1865 22.3165 21.2548 24.6457 16.2498 24.6457ZM8.66647 9.479C6.83564 9.479 5.57897 9.8365 4.9398 10.5515C4.40897 11.1365 4.23564 12.0357 4.37647 13.379L5.18897 19.8682C5.37314 21.6015 5.8498 23.0315 9.7498 23.0315H16.2498C20.1498 23.0315 20.6265 21.6123 20.8106 19.8898L21.6231 13.379C21.764 12.0573 21.5906 11.1582 21.0598 10.5623C20.4206 9.8365 19.164 9.479 17.3331 9.479H8.66647Z"></path>
                                                        <path d="M16.7045 14.2458C16.0979 14.2458 15.6104 13.7583 15.6104 13.1624C15.6104 12.5666 16.0979 12.0791 16.6937 12.0791C17.2895 12.0791 17.777 12.5666 17.777 13.1624C17.777 13.7583 17.3004 14.2458 16.7045 14.2458Z"></path>
                                                        <path d="M9.12151 14.2458C8.51484 14.2458 8.02734 13.7583 8.02734 13.1624C8.02734 12.5666 8.51484 12.0791 9.11068 12.0791C9.70651 12.0791 10.194 12.5666 10.194 13.1624C10.194 13.7583 9.71734 14.2458 9.12151 14.2458Z"></path>
                                                    </svg>
                                                    افزودن به سبد خرید
                                                </button>
                                                <?php
                                            }else{?>
                                                <button type="button" class="btn btn-buy-disable mb-2" >خرید از سایت غیرفعال هست</button>
                                                <?php
                                            }
                                        }else{
                                            echo '<div class="inaJSDge8">ناموجود</div>';
                                        }
                                        ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endwhile; ?>
                </div>
                <span class="swiper-notification" aria-live="assertive" aria-atomic="true"></span>
            </div>
        <?php
        endif;
        ?>
        <?php
        wp_reset_postdata();

        $html = ob_get_clean(); // مهم

        return new \WP_REST_Response([
            'success' => true,
            'html'    => $html,
            'description'=> $term->description,
        ], 200);
    }
    public static function sendOTP_mobile($number)
    {
        $otp = mt_rand(100000, 999999);
        $expiry = date("Y-m-d H:i:s", strtotime("+2 minutes"));
        UserModel::expiryEnd();
        $records = UserModel::exitOtp($number);
        if (!empty($records) && strtotime($records['otp_expiry']) < time()) {
            UserModel::otpDelete($records['id']);
        }
        if (empty($records)) {
            UserModel::otp($number, $otp, $expiry);
            $baseUrl = "https://edge.ippanel.com/v1/api/send";
            $token = "wns0sWEioLyJejB0g0olFj-PVlL2Yt5O2G94prP-BXg=";

            $data = [
                "sending_type" => "pattern",
                "from_number" => "+985000125475",
                    "code" => "xpvkq2fmvzmqvr6",
                    "recipients" => [$number],
                    "params" => [
                            "otp" => $otp,
                            "otp_link" => $otp,
                    ],
            ];

            $ch = curl_init($baseUrl);
            curl_setopt($ch, CURLOPT_HTTPHEADER, [
                "Content-Type: application/json; charset=utf-8",
                "Content-Type: application/json",
                "Authorization: $token"
            ]);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data, JSON_UNESCAPED_UNICODE));

            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);
        }
    }
    public function search_api_function() {
        if (!isset($_POST['keyword']))
            wp_send_json_error();

        $keyword = sanitize_text_field($_POST['keyword']);

        /* ===== محصول اصلی (بالا) ===== */
        $args = [
            'post_type'      => 'product',
            'posts_per_page' => 3,
            's'              => $keyword,
            'orderby'        => 'meta_value_num',
            'meta_key'        => 'total_sales',
            'order'           => 'DESC'
        ];

        $query = new \WP_Query($args);

        $html = '';

        if ($query->have_posts()) :
            while ($query->have_posts()) : $query->the_post();

                $product_id = get_the_ID();
                $title       = get_the_title();
                $link        = get_permalink();
                $image       = get_the_post_thumbnail_url($product_id, 'product_discount');

                $html .= '
            <div class="row header-search-result--first--row">
            <div class="header-search-result__col">
                <div class="header-search-result__area">
                    <div class="header-search-result__products">
                        <a href="'. esc_url($link) .'" class="header-search-result__products-card">

                            <div class="header-search-result__products-card-img">
                                <img src="'. esc_url($image) .'" alt="thumb">
                            </div>

                            <div class="header-search-result__products-card-content">

                                <div class="header-search-result__products-card-content-inner">
                                    <div class="header-search-result__products-card-title">
                                        '. esc_html($title) .'
                                    </div>
                                </div>

                                <div class="header-search-result__products-card-content-icon">
                                    <i class="icon-arrow-up"></i>
                                </div>
                            </div>
                        </a>
                    </div>
                </div>
                </div>
            </div>';
            endwhile;

        else:

            $html .= '<div class="col-lg-12 text-center p-4">محصولی یافت نشد!</div>';

        endif;

        wp_reset_postdata();
        $argsPost = [
            'post_type'      => 'post',
            'posts_per_page' => 3,
            's'              => $keyword,
            'order'           => 'DESC'
        ];

        $queryPost = new \WP_Query($argsPost);

        if ($queryPost->have_posts()) :
            $html .= '<div class="header-search-result__post"><span>مقالات</span><div style="display: flex; gap: 3px; flex-wrap: wrap;">';

            while ($queryPost->have_posts()) : $queryPost->the_post();

            $html .= '
            <div class="header-search-result__posts">
            
<a href="'. esc_url(get_permalink()) .'" class="header-search-result__post-card">
    <div class="header-search-result__post-card-title">
                                        '. get_the_title() .'
                                    </div>
                        </a>
                                    </div>';
        endwhile;
        $html .= '</div></div>';
        endif;
        wp_reset_postdata();


        /* ===== دسته بندی ها ===== */

        $count_query = new \WP_Query(
            [
                'post_type'      => 'product',
                'posts_per_page' => -1,
                's'              => $keyword,
                'fields'         => 'ids',
            ]
        );

        $product_count = $count_query->found_posts;
        wp_reset_postdata();

        /* -------------------------------------------------------
         * 4. جست‌وجوی وب‌لاگ (بدون دسته‌بندی)
         * ------------------------------------------------------- */
        $blog_query = new \WP_Query(
            [
                'post_type'      => 'post',
                'posts_per_page' => -1,
                's'              => $keyword,
                'fields'         => 'ids',
            ]
        );
        $blog_count = $blog_query->found_posts;
        wp_reset_postdata();


        $html .= '
    <div class="col-lg-12 p-0">
        <div class="header-search-result__history header-search-result__history--categories">
            <ul class="header-search-result__list-content header-search-result--categories">';

        $product_link = add_query_arg([
            's'   => $keyword,
            'type'   => 'product',
        ], site_url('/'));
        $post_link = add_query_arg([
            's'   => $keyword,
            'type'   => 'post',
        ], site_url('/'));

        $html .= ' 
  <li class="header-search-result__list-item">

                <a href="'. esc_url($product_link) .'">

                    <div class="header-search-result__list-item-title">
                        <i class="icon-search"></i>
                        <span> جستجو در بخش محصولات </span>
                    </div>

                    <div class="header-search-result__list-item-action">
                        <div class="header-search-result__list-item-action-text">
                            '. $product_count .' محصول
                        </div>

                        <div class="header-search-result__list-item-icon">
                            <i class="icon-arrow-up"></i>
                        </div>
                    </div>

                </a>

            </li>
            <li class="header-search-result__list-item">

                <a href="'. esc_url($post_link) .'">

                    <div class="header-search-result__list-item-title">
                        <i class="icon-search"></i>
                      <span> جستجو در بخش مقالات </span>
                    </div>

                    <div class="header-search-result__list-item-action">
                        <div class="header-search-result__list-item-action-text">
                            '. $blog_count .' مقالات
                        </div>

                        <div class="header-search-result__list-item-icon">
                            <i class="icon-arrow-up"></i>
                        </div>
                    </div>

                </a>

            </li>';


        /* ===== مشاهده همه ===== */

        $html .= '
            </ul>
        </div>
    </div>';

        wp_send_json_success([
            'html' => $html
        ]);
    }
    public function get_cart_timer_api_function() {
        if ( ! function_exists('WC') ) {
            return wp_send_json_error('WooCommerce not loaded');
        }
        if ( null === WC()->session ) {
            WC()->session = new \WC_Session_Handler();
            WC()->session->init();
        }
        if ( null === WC()->customer ) {
            WC()->customer = new \WC_Customer( get_current_user_id(), true );
        }
        if ( null === WC()->cart ) {
            WC()->cart = new \WC_Cart();
        }

        WC()->cart->get_cart();
        global $wpdb;
        $db = Db::getLnstance();
        $cart_time = WC()->session->get('cart_created_time');
        if ( ! $cart_time ) {
            WC()->cart->empty_cart(true);
            WC()->session->set('cart_created_time', null);
            WC()->session->set('rial_coupon', null);
            WC()->session->set('wallet_dirty', null);
            WC()->session->set('use_wallet', null);
            WC()->cart->remove_coupons();
            WC()->session->set_customer_session_cookie(true);
            return wp_send_json_success(['remaining' =>0]);
        }
        $limit     = 300;
        $remaining = $limit - ( time() - $cart_time );

        if ( $remaining <= 0 ) {
            WC()->cart->empty_cart(true);
            WC()->session->set('cart_created_time', null);
            WC()->session->set('rial_coupon', null);
            WC()->session->set('wallet_dirty', null);
            WC()->session->set('use_wallet', null);
            WC()->cart->remove_coupons();
            WC()->session->set_customer_session_cookie(true);

            return wp_send_json_success(['remaining' => 0]);
        }

        return wp_send_json_success(['remaining' => max(0, $remaining)]);
    }
    public function add_to_cart_api_function() {

        $product_id = intval($_POST['product_id'] ?? 0);

        if (is_user_blocked()) {
            echo json_encode([
                'status'  => false,
                'message' => 'شما بلاک شده اید'
            ]);
            exit();
        }
        if (!$product_id) {
            echo json_encode([
                'status'  => false,
                'message' => 'شناسه محصول معتبر نیست.'
            ]);
            exit();
        }
        if(UserModel::setting("buy") === false){
            echo json_encode([
                'status'  => false,
                'message' => 'خرید از سایت فعلا غیر فعال میباشد'
            ]);
            exit();
        }
        global $wpdb;
        $db   = Db::getLnstance();
        $time = time();

        if (!function_exists('WC')) {
            echo json_encode([
                'status'  => false,
                'message' => 'WooCommerce در دسترس نیست.'
            ]);
            exit();
        }

        // Session
        if (null === WC()->session) {
            WC()->session = new \WC_Session_Handler();
            WC()->session->init();
        }

        // Customer
        if (null === WC()->customer) {
            WC()->customer = new \WC_Customer(get_current_user_id(), true);
        }

        // Cart
        if (null === WC()->cart) {
            WC()->cart = new \WC_Cart();
        }
        WC()->cart->get_cart();
        if ( WC()->session->get('payment_type') === null ) {
            WC()->session->set('payment_type', 'r');
        }

        $cart_qty = 0;
        foreach ( WC()->cart->get_cart() as $key => $item ) {
            if ( $item['product_id'] === $product_id ) {
                $cart_qty += $item['quantity'];
            }
        }
        $delivery = get_post_meta($product_id, 'delivery', true);
        if (isset($delivery['one']) && $delivery['one'] == 'on') {
                $available_licenses = $db->query("SELECT licence_id FROM {$wpdb->prefix}product_licences WHERE product_id = :product_id AND licence_status='available' ORDER BY sort_order ASC", array('product_id' => $product_id));
                if (!$available_licenses) {
                    echo json_encode([
                        'status' => false,
                        'message' => 'در حال حاضر لایسنس فعالی موجود نیست.'
                    ]);
                    exit();
                }
                if (count($available_licenses) > $cart_qty) {
                    $added = WC()->cart->add_to_cart($product_id);
                    if (!$added) {
                        echo json_encode([
                                'status' => false,
                                'message' => 'خطا در اضافه کردن به سبد.'
                        ]);
                        exit();
                    }
                }else{
                    echo json_encode([
                            'status' => false,
                            'message' => 'در حال حاضر لایسنس فعالی موجود نیست.'
                    ]);
                    exit();
                }
        }else{
            $added = WC()->cart->add_to_cart($product_id);
            if (!$added) {
                echo json_encode([
                        'status' => false,
                        'message' => 'خطا در اضافه کردن به سبد.'
                ]);
                exit();
            }
        }

        WC()->cart->calculate_totals();
        WC()->cart->set_cart_contents( WC()->cart->get_cart() );
        WC()->session->set_customer_session_cookie(true);
        if (!WC()->session->get('cart_created_time')) {
            WC()->session->set('cart_created_time', $time);
        }
        $product_qty   = 0;
        $product_name  = '';
        $product_image = '';
        $cart_items = [];
        $subtotal   = 0; // بدون تخفیف
        $total      = 0; // نهایی
        $discount   = 0;

        foreach ( WC()->cart->get_cart() as $cart_item_key => $cart_item ) {
            $product = $cart_item['data'];

            $regular_price = (float) $product->get_regular_price();
            $sale_price    = (float) $product->get_price();

            $line_total    = (float) $cart_item['line_total'];
            $qty    = (int) $cart_item['quantity'];
            $cart_product_discount += ($regular_price * $qty) - $line_total;
            $total    += $line_total;
            $cart_items[] = [
                'product_id'      => $cart_item['product_id'],
                'url'             => get_permalink($cart_item['product_id']),
                'name'            => $product->get_name(),
                'qty'             => $cart_item['quantity'],
                'price_regular'   => number_format_usd($regular_price),
                'price_sale'      => number_format_usd($sale_price),
                'image'           => $product->get_image_id()
                    ? wp_get_attachment_image_url($product->get_image_id(),'product_discount')
                    : wc_placeholder_img_src()
            ];
            if ( $cart_item['product_id'] == $product_id ) {
                $product_qty  = $cart_item['quantity'];

                $product_obj  = $cart_item['data'];
                $product_name = $product_obj->get_name();

                $image_id     = $product_obj->get_image_id();
                $product_image = $image_id
                    ? wp_get_attachment_image_url($image_id, 'product_discount')
                    : wc_placeholder_img_src();
            }

        }
        echo json_encode( [
            'status'  => true,
            'im'  => isMobile(),
            'message' => 'موفقیت‌آمیز',
            'delivery' => isset($delivery['two']) && $delivery['two'] == 'on' ? true : false,
            'deliveryTime' => isset($delivery['two']) && $delivery['two'] == 'on' && !empty($delivery['time']) ? $delivery['time'] : 'نامعلوم',
            'cart' => [
                'items_count' =>  ( WC()->cart ) ? WC()->cart->get_cart_contents_count() : 0,
                'subtotal'    => number_format_usd(WC()->cart->get_subtotal()+$cart_product_discount),
                'discount'    => number_format_usd($cart_product_discount),
                'total'       => number_format_usd($total),
                'totalUSD'       => $total,
                'items'       => $cart_items
            ],
            'product'  => [
                'name'  => $product_name,
                'qty'   => $product_qty,
                'image' => $product_image,
            ],
            'available' => ((isset($delivery['one']) && $delivery['one'] == 'on' ) && count($available_licenses)-1 != 0 ) || ((isset($delivery['two']) && $delivery['two'] == 'on' ))? true : false
        ] );
    }

    public function login_api_function(){
        if (isset($_POST['userName'])) {
            $number = UserModel::phone($_POST['userName']);
            if(empty($number)) {
                self::sendOTP_mobile($_POST['userName']);
                $output = View::re("/inc/templates/template-parts/login/otp.php", $_POST);
            }else{
                $output = View::re("/inc/templates/template-parts/login/password.php", $_POST);
            }
            $response_data = array(
                'html' => $output
            );
            return new \WP_REST_Response( $response_data ,200 );
        } else{
            $response_data = array(
                'status' => false,
                'message' => 'وروردی صحیح نمیباشد'
            );
            return new \WP_REST_Response( $response_data ,200 );
        }
    }
    public function loginOtpAudio_api_function(){
        if (isset($_POST['userName'])) {
            $number = UserModel::phone($_POST['userName']);
            if(!empty($number)) {
                if (\Giftmax\Modules\UserModel::setting("otpAudioLogin") === true) {
                    $otp = mt_rand(100000, 999999);
                    $expiry = date("Y-m-d H:i:s", strtotime("+20 minutes"));
                    UserModel::expiryEnd();
                    $records = UserModel::exitOtp($_POST['userName']);
                    if (!empty($records) && strtotime($records['otp_expiry']) < time()) {
                        UserModel::otpDelete($records['id']);
                    }
                    if (empty($records)) {
                        UserModel::otp($_POST['userName'], $otp, $expiry);
                    }
                    $url = "https://portal.avanak.ir/rest/SendOTP";
                    $url = $url . "?" . "Token=" . urlencode("1ACAAF7BC85B6AB3B54E5381A72EDCDC67D7BF06");
                    $url = $url . "&" . "Length=6";
                    $url = $url . "&" . "Number=" . $_POST['userName'];
                    $url = $url . "&" . "OptionalCode=" . $otp;

                    $json = file_get_contents($url);
                    if ($json->ErrorCode != 0) {
                        echo json_encode(["status" => false, "message" => "خطایی پیش آمده", "percent" => 0]);
                    }
                    $response_data = array(
                        'status' => true,
                        'message' => 'ارسال شد'
                    );
                }else {
                    $response_data = array(
                        'status' => true,
                        'message' => 'ارسال شد'
                    );
                }
            }else{
                $response_data = array(
                    'status' => false,
                    'message' => 'این متد فعال نیست'
                );
            }
            return new \WP_REST_Response( $response_data ,200 );
        } else{
            $response_data = array(
                'status' => false,
                'message' => 'وروردی صحیح نمیباشد'
            );
            return new \WP_REST_Response( $response_data ,200 );
        }
    }
    public function loginOtp_api_function(){
        if (isset($_POST['userName'])) {
            $number = UserModel::phone($_POST['userName']);
            if(!empty($number)) {
                self::sendOTP_mobile($_POST['userName']);
                $response_data = array(
                    'status' => true,
                    'message' => 'ارسال شد'
                );
            }else{
                $response_data = array(
                    'status' => false,
                    'message' => 'خطا ارسال شد'
                );
            }
            return new \WP_REST_Response( $response_data ,200 );
        } else{
            $response_data = array(
                'status' => false,
                'message' => 'وروردی صحیح نمیباشد'
            );
            return new \WP_REST_Response( $response_data ,200 );
        }
    }
    public function lotp_api_function(){
        if (isset($_POST['userName'])) {
            self::sendOTP_mobile($_POST['userName']);
            $output = View::re("/inc/templates/template-parts/login/otp.php", $_POST);
            $response_data = array(
                'html' => $output
            );
            return new \WP_REST_Response($response_data, 200);
        }else{
            $response_data = array(
                'status' => false,
                'message' => 'وروردی صحیح نمیباشد'
            );
            return new \WP_REST_Response( $response_data ,200 );
        }
    }
    public function pass_api_function(){
        if (isset($_POST['userName']) && isset($_POST['PassWord'])) {
            $username = sanitize_user($_POST['userName']);
            $password = $_POST['PassWord'];

            $user = get_user_by('login', $username);
            if ($user && wp_check_password($password, $user->user_pass, $user->ID)) {
            wp_clear_auth_cookie();
            wp_set_current_user($user->ID);
            wp_set_auth_cookie($user->ID,true);
                $response_data = array(
                    'status' => true,
                    'url' => home_url('/'),
                );

            }else{
                $response_data = array('status' => false);
            }
            return new \WP_REST_Response( $response_data ,200 );
        }else{
            $response_data = array(
                'status' => false,
                'message' => 'وروردی صحیح نمیباشد'
            );
            return new \WP_REST_Response( $response_data ,200 );
        }
    }
    public function otp_api_function(){
        if (isset($_POST['userName'])) {
            $records = UserModel::exitOtp($_POST['userName'], 'otp', $_POST['otp']);
            if (!empty($records)) {
                if (strtotime($records['otp_expiry']) > time()) {
                    $number = UserModel::phone($_POST['userName']);
                    if ($number) {
                        $user = get_user_by('login', $_POST['userName']);

                        if (!is_wp_error($user)) {
                            wp_clear_auth_cookie();
                            wp_set_current_user($user->ID);
                            wp_set_auth_cookie($user->ID,true);
                            $response_data = array(
                                'url' => home_url('/'),
                            );
                        } else {
                            $response_data = array(
                                'url' => home_url('login-register'),
                            );
                        }
                        UserModel::otpDelete($records['id']);
                    } else {
                        $hash = generateHash();
                        $_POST['hash'] = $hash;
                        UserModel::registerUser($_POST['userName'],$hash);
                        $output = View::re("/inc/templates/template-parts/login/register.php", $_POST);
                        $response_data = array(
                            'html' => $output,
                        );
                        UserModel::otpDelete($records['id']);
                    }
                } else {
                    UserModel::otpDelete($records['id']);
                    $response_data = array(
                        'status' => false,
                        'message' => 'کد شما منقضی شده'
                    );
                }
                return new \WP_REST_Response($response_data, 200);

            } else {
                $response_data = array(
                    'status' => false,
                    'message' => 'کد وروردی صحیح نمیباشد'
                );
                return new \WP_REST_Response($response_data, 200);
            }
        }else{
            $response_data = array(
                'status' => false,
                'message' => 'وروردی صحیح نمیباشد'
            );
            return new \WP_REST_Response( $response_data ,200 );
        }
    }
    public static function callZohalService(string $url, array $payload, string $token ,int $isIdentity = 0): array
    {
        $ch = curl_init($url);

        curl_setopt_array($ch, [
            CURLOPT_POST           => true,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HTTPHEADER     => [
                'Content-Type: application/json',
                'Authorization: Bearer ' . $token
            ],
            CURLOPT_POSTFIELDS     => json_encode($payload),
            CURLOPT_TIMEOUT        => 30,
        ]);

        $response = curl_exec($ch);

        if ($response === false) {
            $error = curl_error($ch);
            curl_close($ch);
            return [
                'status'  => false,
                'message' => 'Curl Error: ' . $error
            ];
        }

        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        $data = json_decode($response, true);
        if ($httpCode === 400) {
            return [
                'status'  => false,
                'message' => $data['response_body']['message'] ?? 'درخواست نامعتبر'
            ];
        }
        if ($isIdentity === 0) {
            if ($httpCode === 200) {

                if (isset($data['response_body']['data']['matched'])) {

                    return [
                        'status' => (bool)$data['response_body']['data']['matched'],
                        'message' => $data['response_body']['data']['matched']
                            ? 'اطلاعات تطابق دارد'
                            : 'اطلاعات تطابق ندارد'
                    ];
                }

                return [
                    'status' => true,
                    'message' => $data['response_body']['message'] ?? 'عملیات موفق'
                ];
            }
        }else{
            if ($httpCode === 200) {

                if (isset($data['response_body']['data']['alive']) && $data['response_body']['data']['alive']) {
                    return $data['response_body']['data'];
                }

                return [
                    'status'  => false,
                    'message' => 'درخواست شما نامعتبر است'
                ];
            }
        }
        return [
            'status'  => false,
            'message' => 'وضعیت پاسخ نامعتبر: ' . $httpCode
        ];
    }
    public function setPassword_api_function()
    {
        $userName = $_POST['userName'];
        $password = $_POST['password'];
        $hash = $_POST['hash'];
        if (empty($userName) || empty($hash) || empty($password)) {
            return new \WP_REST_Response([
                'status' => false,
                'message' => 'رمز عبور را ارسال کنید'
            ], 200);

        }
        $records = UserModel::table('token_register','UserLogin',$userName,'hash',$hash);
        if (empty($records)) {
            $TokenRegister = UserModel::table('token_register',`UserLogin`,$userName);
            if (!empty($TokenRegister)) {
                UserModel::TokenRegisterDelete($TokenRegister['id']);
            }
            return new \WP_REST_Response([
                'status' => false,
                'Isreload' => true,
                'message' => 'خطا در ثبت نام'
            ], 200);
        }
        if (strlen($password) < 8) {
            $errors = 'رمز عبور باید حداقل ۸ کاراکتر باشد.';
            return new \WP_REST_Response([
                'status' => false,
                'message' => $errors
            ], 200);
        }
        $user_login = get_user_by('login', $_POST['userName']);

        if (!is_wp_error($user_login)) {
            wp_clear_auth_cookie();
            wp_set_password($password, $user_login->ID);
            wp_set_current_user($user_login->ID);
            wp_set_auth_cookie($user_login->ID);

            UserModel::TokenRegisterDelete($records['id']);
            $response_data = array(
                'status'  => true,
                'url' => home_url('/profile'),
            );
        }else{
            $response_data = array(
                'status'  => false,
                'message' => "خطایی پیش آمده دوباره تلاش کنید",
            );
        }
        return new \WP_REST_Response( $response_data ,200 );

    }
    public function register_api_function()
    {
        $userName = $_POST['userName'];
        $hash = $_POST['hash'];
        $firstName = $_POST['first_name'];
        $lastName = $_POST['last_name'];
        $nationalID = $_POST['nationalID'];
        $CardNumber = str_replace('-', '', $_POST['CardNumber']);
        $d1 = $_POST['register_birthdate1'];
        $d2 = $_POST['register_birthdate2'];
        $d3 = $_POST['register_birthdate3'];
        if (empty($userName) || empty($hash) || empty($firstName) || empty($lastName) ||empty($nationalID) || empty($CardNumber) || empty($d1) || empty($d2) || empty($d3)) {
            return new \WP_REST_Response([
                'status' => false,
                'message' => 'همه فیلدها باید پر شوند'
            ], 200);

        }
        $hashCard = generateHash();
        $records = UserModel::table('token_register','UserLogin',$userName,'hash',$hash);
        if (empty($records)) {
            $TokenRegister = UserModel::table('token_register',`UserLogin`,$userName);
            if (!empty($TokenRegister)) {
                UserModel::TokenRegisterDelete($TokenRegister['id']);
            }
            return new \WP_REST_Response([
                'status' => false,
                'Isreload' => true,
                'message' => 'خطا در ثبت نام'
            ], 200);

        }
        $token = 'd5497c98fc9a28300406dd8ee66bac5b531fc598';
        $birthDate = $d1 . '/' . $d2 . '/' . $d3;
        $jbt = Jibit::getLnstance();
        if(UserModel::setting("shahkar_zohal") === true) {
            $result = self::callZohalService(
                'https://service.zohal.io/api/v0/services/inquiry/shahkar',
                [
                    'mobile' => $userName,
                    'national_code' => $nationalID
                ],
                $token
            );

            if ($result['status'] !== true) {
                return new \WP_REST_Response([
                    'status' => false,
                    $result
                ], 200);
            }
        }
        elseif(UserModel::setting("shahkar_jibit") === true) {
            $endpoint = '/services/matching';
            $res =  $jbt->api_request('GET', $endpoint, [
                'mobileNumber' => $userName,
                'nationalCode' => $nationalID
            ], null, true);
            if ($res['code'] !== 200) {
                return new \WP_REST_Response([
                    'status' => false,
                    'message' => $res['body']['message']
                ], 200);
            }
        }
        if(UserModel::setting("check_card_with_national_code_zohal") === true) {
            $result = self::callZohalService(
                'https://service.zohal.io/api/v0/services/inquiry/check_card_with_national_code',
                [
                    'birth_date' => $birthDate,
                    'card_number' => $CardNumber,
                    'national_code' => $nationalID
                ],
                $token
            );

            if ($result['status'] !== true) {
                return new \WP_REST_Response([
                    'status' => false,
                    $result
                ], 200);
            }
        }
        elseif(UserModel::setting("check_card_with_national_code_jibit") === true) {
            $endpoint = '/services/matching';
            $res =  $jbt->api_request('GET', $endpoint, [
                    'cardNumber' => $CardNumber,
                    'nationalCode' => $nationalID,
                    'birthDate' =>  $d1  . $d2 .  $d3
            ], null, true);
            if ($res['code'] !== 200) {
                return new \WP_REST_Response([
                    'status' => false,
                    'message' => $res['body']['message']
                ], 200);
            }
        }
        $number = UserModel::phone($_POST['userName']);

        if (username_exists($_POST['userName'])) {
            return new \WP_REST_Response([
                'status'  => false,
                'message' => 'این شماره وجود دارد!'
            ], 200);
        }
        if (!$number) {
            $password = wp_generate_password(12, false);
            $user_id = wp_create_user($_POST['userName'], $password);
            $is_exist = UserModel::table("user_identity","national_id_enc",encrypt_data($nationalID));
            if (is_user_blocked($is_exist['user_id'])){
                return new \WP_REST_Response([
                        'status'  => false,
                        'message' => 'حساب قبلی شما مسدود میباشد و اجازه ثبت نام ندارید.'
                ], 200);
            }
            if ($user_id) {
                $user = new \WP_User($user_id); // load the new user

                $user->set_role('customer');

                wp_update_user([
                        'ID' => $user_id,
                        'first_name' => $firstName,
                        'last_name'  => $lastName,
                        'display_name' => trim($firstName . ' ' . $lastName),
                ]);
                update_user_meta($user_id, 'api_token', wp_generate_password(50, false));
                if ((UserModel::setting("shahkar_zohal") === true || UserModel::setting("shahkar_jibit") === true) && (UserModel::setting("check_card_with_national_code_zohal") === true || UserModel::setting("check_card_with_national_code_jibit") === true)) {
                    UserModel::insertUser($user_id, $nationalID, $birthDate, $CardNumber,$hashCard, 1);
                }else{
                    UserModel::insertUser($user_id, $nationalID, $birthDate, $CardNumber,$hashCard, 0);
                }
            }
        }
        $otp = mt_rand(100000, 999999);
        $expiry = date("Y-m-d H:i:s", strtotime("+2 minutes"));
        UserModel::expiryEnd();
        $records = UserModel::exitOtp($userName);
        if (!empty($records) && strtotime($records['otp_expiry']) < time()) {
            UserModel::otpDelete($records['id']);
        }
        if (empty($records)) {
            UserModel::otp($userName, $otp, $expiry);
        }
        $url = "https://portal.avanak.ir/rest/SendOTP";
        $url = $url . "?" . "Token=" . urlencode("1ACAAF7BC85B6AB3B54E5381A72EDCDC67D7BF06");
        $url = $url . "&" . "Length=6";
        $url = $url . "&" . "Number=" . $userName;
        $url = $url . "&" . "OptionalCode=" . $otp;

        $json = file_get_contents($url);
        if ($json->ErrorCode != 0) {
            $url = "https://portal.avanak.ir/rest/SendOTP";
            $url = $url . "?" . "Token=" . urlencode("1ACAAF7BC85B6AB3B54E5381A72EDCDC67D7BF06");
            $url = $url . "&" . "Length=6";
            $url = $url . "&" . "Number=" . $userName;
            $url = $url . "&" . "OptionalCode=" . $otp;

            $json = file_get_contents($url);
            if ($json->ErrorCode != 0) {
                $output = View::re("/inc/templates/template-parts/login/getpassword.php", $_POST);
                $response_data = array(
                        'status' => true,
                        'html' => $output,
                );
                return new \WP_REST_Response( $response_data ,200 );
            }
        }
        $output = View::re("/inc/templates/template-parts/login/card_otp.php", ['hash'=>$hashCard]);
        $response_data = array(
            'status' => true,
            'html' => $output,
        );
        return new \WP_REST_Response( $response_data ,200 );

    }
    function ticketing_api_function(){
        if($_POST['method']=="insert") {
            $db = Db::getLnstance();
            global $wpdb;
            $user = wp_get_current_user();
            $title = sanitize_text_field($_POST['title']); // Sanitize input
            $description = sanitize_textarea_field($_POST['description']); // Sanitize input

            if (isset($_POST['images']['images'])) {
                $images_data = implode('|', $_POST['images']['images']);
            }else{
                $images_data = null;
            }

            $condition = 0;

            if (isset($_POST['condition']) && $_POST['condition'] !== '') {
                $condition = (int) $_POST['condition'];
            }
            $db->insert('INSERT INTO ' . $wpdb->prefix . 'ticket (`ticketId`, `rep_Id`, `categoryId`, `userId`, `Issue`, `requestText`, `attachment`, `condition`, `time`) VALUES (NULL, NULL,:categoryId,:userId,:Issue,:requestText,:attachment,:condition,:tim)', array(
                'categoryId' => $_POST['gid'],
                'userId' => $user->ID,
                'Issue' => $title,
                'requestText' => $description,
                'attachment'=> $images_data,
                'condition'=> $condition,
                'tim'=>  current_time('mysql', true)
            ));
            $output = '<section class="d-flex ai-center mt-6 mb-3"><h1 class="text-h5 color-text-heading">ثبت درخواست پشتیبانی</h1><span class="color-text-heading text-h5 mx-1">|</span><p class="text-body-2 color-text-low-emphasis">اینجا می&zwnj;توانید درخواست پشتیبانی ثبت کنید</p></section><div class="bg-white my-3 shadow-2 d-flex flex-column ai-center py-9 px-5 align-center radius-large "><div data-testid="image-wrapper" style="width: 124px; height: 124px;"><img class="w-100" src="' . get_template_directory_uri() . '/assets/img/SLPromotionThanks.85c696de.png" width="124" height="124" data-testid="image-defaultImage" style="object-fit: cover;"></div><p class="text-h4 color-brand-primary-500 mt-9">درخواست پشتیبانی ثبت شد</p><p class="text-subtitle color-n-700 mt-2">همکاران ما در اولین فرصت درخواست شما را بررسی می‌کنند</p><a class="profile_hidden" href="'.home_url("/ticket").'"><button class="relative d-flex ai-center user-select-none btn-wc51H8 text-button-1 btn--large-Gj4EdP btn--primary-uiqWij btn--wide-fdCqpO radius Button__large-Zq9sTh Button__filledPrimary-OvgwGb Final__btn-PVa26x Button-MNNP44" data-testid="button-wrapper"><div class="d-flex ai-center jc-center relative grow-1">برگشت به صفحه اصلی</div></button></a></div><div></div>';

        }
        elseif ($_POST['method']=='tis') {
            $db = Db::getLnstance();
            global $wpdb;
            $user = wp_get_current_user();
            $description = sanitize_textarea_field($_POST['body']); // Sanitize input

            if (isset($_POST['images']['images'])) {
                $images_data = implode('|', $_POST['images']['images']);
            }else{
                $images_data = null;
            }
            $db->insert('INSERT INTO ' . $wpdb->prefix . 'ticket (`ticketId`, `rep_Id`, `categoryId`, `userId`, `Issue`, `requestText`, `attachment`, `condition`, `time`) VALUES (NULL, :rep_Id, NULL, :userId, NULL, :requestText, :attachment, NULL, :tim)', array(
                'rep_Id' => $_POST['gid'] * 5 /10 ,
                'userId' => $user->ID,
                'requestText' => $description,
                'attachment'=> $images_data,
                'tim'=>  current_time('mysql', true)
            ));
            if ($_POST['select'] && current_user_can('administrator')) {
                $db->modify("UPDATE `{$wpdb->prefix}ticket` SET `condition` = :select WHERE `ticketId` = :id", array(
                    'select' => $_POST['select'],
                    'id' => $_POST['gid'] * 5 / 10,
                ));
                $r = $db->first("SELECT userId FROM `{$wpdb->prefix}ticket` WHERE `ticketId` = :id AND rep_Id IS NULL", array('id'=>$_POST['gid'] * 5 /10));
                $phone = get_userdata($r['userId'])->user_login;
                $baseUrl = "https://edge.ippanel.com/v1/api/send";
                $token = "wns0sWEioLyJejB0g0olFj-PVlL2Yt5O2G94prP-BXg=";

                $data = [
                        "sending_type" => "pattern",
                        "from_number" => "+985000125475",
                        "code" => "mpxulblzdnzmt8a",
                        "recipients" => [$phone],
                        "params" => [
                                "id" => $_POST['gid'],
                                "link" => home_url('/ticket/id/' . $_POST['gid']),
                        ],
                ];

                $ch = curl_init($baseUrl);
                curl_setopt($ch, CURLOPT_HTTPHEADER, [
                        "Content-Type: application/json; charset=utf-8",
                        "Content-Type: application/json",
                        "Authorization: $token"
                ]);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                curl_setopt($ch, CURLOPT_POST, true);
                curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data, JSON_UNESCAPED_UNICODE));

                $response = curl_exec($ch);
                $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
                curl_close($ch);
            }
            set_query_var('id', $_POST['gid']);

            $user_id = get_current_user_id();


            $user = get_userdata( $user_id );

            if ( in_array( 'administrator', (array) $user->roles ) ) {
                $output = View::re("/inc/templates/template-parts/ticket/index_ticket_admin.php");

            }else{
                $output = View::re("/inc/templates/template-parts/ticket/index_ticket.php");
            }


        }
        else{
            $id = $_POST['gid'];
            if (is_numeric($id)) {
                $db = Db::getLnstance();
                global $wpdb;
                $data = array();
                $records = $db->query("SELECT * FROM  `{$wpdb->prefix}ticketing_category` WHERE `categoryId`=:id", array(
                    'id' => $id,
                ));
                if (!empty($records[0]['subset'])) {
                    $subsets = $db->query("SELECT * FROM  `{$wpdb->prefix}ticketing_category` WHERE `categoryId`=:subset", array(
                        'subset' => $records[0]['subset'],
                    ));
                    $data['subset'] = $subsets[0]['name'];
                }
                $data['object'] = $records[0]['name'];
                $data['id'] = $id;
            }else{
                $order_id = explode('|',decrypt_data($id))[0];
                if (is_numeric($order_id)) {
                    $order = wc_get_order($order_id);
                    $current_user_id = get_current_user_id();

                    if ($order) {
                        $order_user_id = $order->get_user_id();
                        $valid_statuses = ['completed', 'card-not-verified'];
                        $is_available = in_array($order->get_status(), $valid_statuses);
                        if ($order_user_id == $current_user_id && $is_available) {
                            $data['subset'] = "سفارش ها";
                            $data['object'] = "سفارش #" . $order_id;
                            $data['id'] = $id;
                        }else{
                            echo json_encode(['status'=>false,'message'=>"خطایی پیش آمده","close"=>true]);
                            exit();
                        }
                    }else{
                        echo json_encode(['status'=>false,'message'=>"خطایی پیش آمده","close"=>true]);
                        exit();
                    }
                }else{
                    echo json_encode(['status'=>false,'message'=>"خطایی پیش آمده","close"=>true]);
                    exit();
                }
            }
            $output = View::re("/inc/templates/template-parts/ticket/insert.php", $data);
        }
        $response = array('html' => $output);
        return new \WP_REST_Response($response);
    }
    public function main_api_function() {
        if (isset($_POST['q'])) {
            $key = $_POST['q'];
            $data = array();
            $data['records'] = UserModel::search($key);
            $output = View::re("/inc/templates/template-parts/ticket/search.php",$data);
            $response = array('html' => $output);
        }else{
            $response = array('html' => '');
        }
        return new \WP_REST_Response($response);
    }
    public function category_api_function() {
        $name = $_POST['title'];
        $main = $_POST['main'];

        $records = TicketModel::exist($name);
        if (empty($records)) {
            TicketModel::insert($name,$main);
            $status = 'ok';
        }else{
            $status = 'no';
        }
        $response = array('status' => $status);
        return new \WP_REST_Response($response);
    }
    public function ticket_category_api_function() {
        $db = Db::getLnstance();
        global $wpdb;
        if(empty($_POST['method'])) {
            $records = $db->query("SELECT * FROM  `{$wpdb->prefix}ticketing_category` WHERE `name` LIKE :keyword", array(
                'keyword' => '%' . $_POST['keyword'] . '%',
            ));
        } elseif ($_POST['method'] == "add") {
            if (!isset($_POST['parent_id'])) {
                $records = $db->query("SELECT * FROM  `{$wpdb->prefix}ticketing_category` WHERE `main_category`=1");
            } else {
                $records = $db->query("SELECT * FROM  `{$wpdb->prefix}ticketing_category` WHERE `subset`=:subset", array(
                    'subset' => $_POST['parent_id'],
                ));
            }
        }
        $out = ['status' => true];
        $allCategories = $db->query("SELECT * FROM `{$wpdb->prefix}ticketing_category`");
        $categoriesMap = [];
        foreach ($allCategories as $cat) {
            $categoriesMap[$cat['categoryId']] = [
                'id' => $cat['categoryId'],
                'name' => $cat['name'],
                'subset_id' => $cat['subset'] // parent id
            ];
        }

        // 3️⃣ تابع بازگشتی برای ساخت زیرمجموعه‌ها
        $buildTree = function($parentId) use (&$categoriesMap, &$buildTree) {
            $children = [];
            foreach ($categoriesMap as $cat) {
                if ($cat['subset_id'] == $parentId) {
                    $children[] = [
                        'id' => $cat['id'],
                        'name' => $cat['name'],
                        'subset' => $buildTree($cat['id']) // بازگشت برای زیرمجموعه‌های عمیق‌تر
                    ];
                }
            }
            return $children;
        };
        foreach ($records as $record) {
            $categoryId = $record['categoryId'];
            $out['raw'][] = [
                'id' => $categoryId,
                'name' => $record['name'],
                'subset' => $buildTree($categoryId)
            ];
        }
        $user_id = get_current_user_id();
        $args = [
            'customer_id' => $user_id,
            'limit'       => -1,
            'orderby'     => 'date',
            'order'       => 'DESC',
        ];
        $orders = wc_get_orders($args);
        if ($orders) {
            $subsetOrder = [];
            foreach ($orders as $order){
                $orderId= $order->get_id();
                $subsetOrder[] = ['id'=>encrypt_data("$orderId|order"),'name'=>"#$orderId"];
            }
            $out['raw'][] = [
                'id' => count($out['raw']),
                'name' => "سفارش ها",
                'subset' => $subsetOrder
            ];
        }
        echo json_encode($out);
    }
    public function images_api_function(){
        if ( ! isset( $_FILES['file'] ) ) {
            return new \WP_Error( 'no_file', 'No file provided', array( 'status' => 400 ) );
        }
        if ($_FILES['file']['size'][0] >6 * 1024 * 1024){
            return new \WP_Error( 'size_big',"حجم رعایت نشده بود", array( 'status' => 400 ) );
        }
        $uploadDirectory = wp_upload_dir()['path']; // برای استفاده از پوشه آپلود شده وردپرس

        $uploadedImages = array();
        foreach ($_FILES['file']['tmp_name'] as $key => $tmp_name) {
            $file_name = $_FILES['file']['name'][$key];
            $file_tmp = $_FILES['file']['tmp_name'][$key];
            $new_file_name = $uploadDirectory . basename($file_name);
            $newFile = str_replace(rtrim($_SERVER['DOCUMENT_ROOT'], '/') . '/','',$new_file_name);
            $id = generateHash(4);
            global $wpdb;
            $db = Db::getLnstance();
            $db->insert('INSERT INTO ' . $wpdb->prefix .'image (`id`, `url`, `code`) VALUES (NULL, :Url, :Id)',array('Url'=>$newFile,'Id'=>$id));
            move_uploaded_file($file_tmp, $new_file_name);

            $uploadedImages[] = array(
                'id' => $id,
                'url' => basename($file_name)
            );
        }
        $response_data = array(
            'uploadedImages' => $uploadedImages,
        );
        echo json_encode($response_data);
    }
    public function load_category_api_function(  ) {
        ob_start();
        $term_id = $_POST['term_id'];
        $term = get_term($term_id, 'product_cat');
        $giftmax_is_user_logged_in = is_user_logged_in();
        $giftmax_wishlist_ids = $giftmax_is_user_logged_in ? giftmax_get_user_wishlist_product_ids() : [];
        if (is_wp_error($term) || !$term) {
            return new \WP_REST_Response([
                'success' => false,
                'html'    => ''
            ], 400);
        }

        $term_name = $term->name;
        $term_link = get_term_link($term);
        ?>
        <div class="act-new-service-carousel-head d-flex align-items-center justify-content-between">
            <svg xmlns="http://www.w3.org/2000/svg" width="1281" height="75" viewBox="0 0 1281 75" fill="none" class="act-new-service-carousel-head-svg">
                <path d="M1280.47 0.5H1000.91C986.771 0.5 979.703 0.5 973.764 2.99163C969.027 4.9789 964.838 8.07733 961.551 12.025C957.43 16.9747 955.361 23.7331 951.224 37.25C947.086 50.7669 945.017 57.5253 940.896 62.475C937.609 66.4227 933.42 69.5211 928.683 71.5084C922.744 74 915.676 74 901.54 74H412.882C399.847 74 393.329 74 387.813 71.8926C382.12 69.7177 377.167 65.9625 373.536 61.0686C370.017 56.3267 368.257 50.0512 364.737 37.5C361.217 24.9488 359.457 18.6733 355.938 13.9314C352.307 9.0375 347.353 5.2823 341.661 3.10737C336.145 1 329.627 1 316.592 1H0" stroke="url(#paint0_linear_29_20094)"></path>
                <defs>
                    <linearGradient id="paint0_linear_29_20094" x1="29.4736" y1="0.500002" x2="1213.79" y2="-28.0511" gradientUnits="userSpaceOnUse">
                        <stop stop-color="#0B61FF" stop-opacity="0"></stop>
                        <stop offset="0.5" stop-color="#0B61FF"></stop>
                        <stop offset="1" stop-color="#0B61FF" stop-opacity="0"></stop>
                    </linearGradient>
                </defs>
            </svg>
            <div class="act-our-services-carousel-head-title">
                <div class="act-our-services-carousel-head-title-divs">
                    <div class="act-our-services-carousel-head-title-div1"></div>
                    <div class="act-our-services-carousel-head-title-div2"></div>
                </div>
                <div class="act-our-services-carousel-head-title-content V13-category-name">
                    <h5>
                        جدیدترین <strong><?php echo esc_html($term_name); ?></strong>
                    </h5>
                    <p>PRODUCTS</p>
                </div>
            </div>
            <div class="act-new-service-carousel-head-content">

                <a class="act-link-but" href="<?php echo esc_url($term_link); ?>" target="_blank" rel="nofollow">
                    مشاهده بیشتر
                    <svg xmlns="http://www.w3.org/2000/svg" width="34" height="34" viewBox="0 0 34 34" fill="currentcolor">
                        <path d="M20.0744 10.4295C20.2088 10.5639 20.2936 10.7477 20.2936 10.9599C20.2936 11.37 19.9542 11.7094 19.5441 11.7094L11.7094 11.7094L11.7094 19.5442C11.7094 19.9543 11.3699 20.2937 10.9598 20.2937C10.5497 20.2937 10.2103 19.9543 10.2103 19.5442L10.2103 10.9599C10.2103 10.5498 10.5497 10.2103 10.9598 10.2103L19.5441 10.2103C19.7562 10.2103 19.9401 10.2952 20.0744 10.4295Z"></path>
                        <path d="M11.611 10.5501L23.5116 22.4507C23.8015 22.7406 23.8015 23.2215 23.5116 23.5114C23.2217 23.8013 22.7409 23.8013 22.451 23.5114L10.5504 11.6108C10.2605 11.3209 10.2605 10.84 10.5504 10.5501C10.8403 10.2602 11.3211 10.2602 11.611 10.5501Z"></path>
                    </svg>
                </a>
            </div>
        </div>
        <?php
        if ( ! $term_id ) {
            return new \WP_REST_Response([
                'success' => false,
                'html'    => ''
            ], 400);
        }
        $home_coupon_objects = [];
        $home_coupon_ids = get_posts([
            'post_type'      => 'shop_coupon',
            'post_status'    => 'publish',
            'numberposts'    => -1,
            'fields'         => 'ids',
        ]);

        if (!empty($home_coupon_ids)) {
            foreach ($home_coupon_ids as $home_coupon_id) {
                $home_coupon_objects[] = new \WC_Coupon($home_coupon_id);
            }
        }
        $args = [
                'post_type'      => 'product',
                'posts_per_page' => -1,
                'tax_query'      => [
                        [
                                'taxonomy' => 'product_cat',
                                'field'    => 'term_id',
                                'terms'    => $term_id,
                        ]
                ],
                'meta_query' => [
                        'relation' => 'OR',
                        [
                                'key'     => 'giftmax_setting_order',
                                'compare' => 'EXISTS',
                                'type'    => 'NUMERIC',
                        ],

                        [
                                'key'     => 'giftmax_setting_order',
                                'compare' => 'NOT EXISTS',
                        ],
                ],

                'orderby' => [
                        'meta_value_num' => 'ASC',
                        'date'           => 'DESC',
                ],
                'order'          => 'ASE',
        ];
        $region_args = [
            'post_type'      => 'product',
            'posts_per_page' => -1,
            'fields'         => 'ids',
            'tax_query'      => [
                [
                    'taxonomy' => 'product_cat',
                    'field'    => 'term_id',
                    'terms'    => $term_id,
                ]
            ],
            'meta_query' => [
                [
                    'key'     => 'giftmax_box_setting',
                    'compare' => 'EXISTS'
                ]
            ]
        ];

        $region_query = new \WP_Query($region_args);

        $regions = [];

        foreach ($region_query->posts as $pid) {
            $settings = get_post_meta($pid, 'giftmax_box_setting', true);
            if (!empty($settings[0]['logo_region'])) {
                $regions[] = $settings[0]['logo_region'];
            }
        }

        $regions = array_unique($regions);
        $query = new \WP_Query($args);
        if ($query->have_posts()) :
            ?>
            <div class="w-full">
                <div class="flex flex-col overflow-hidden">
                    <div class="flex overflow-hidden mb-20">
                        <div class="flex justify-between lg:w-20 md:w-11">
                            <div class="act-our-services-carousel-head-title">
                                <div class="act-our-services-carousel-head-title-divs">
                                    <div class="act-our-services-carousel-head-title-div1 tsc54b"></div>
                                </div>
                                <div class="act-our-services-carousel-head-title-content">
                                    <h5>انتخاب <strong>کشور</strong> </h5>
                                    <p class="tsc54">SELECT REGION</p>
                                </div>
                            </div>
                        </div>
                    <div class="swiper c-box__ceWU4d" data-cat="<?=$term_id?>">
                        <div class="swiper-wrapper">
                            <div data-id="" class="act-catagory-card swiper-slide pointer button-cc45" style="width: 75px !important;">
                                <div class="act-catagory-card-inner">
                                    <div class="act-catagory-card-name">
                                        <div class="act-our-services-carousel-head-title-divs">
                                            <div class="act-our-services-carousel-head-title-div1" style="height: 15px;  margin-bottom: 4px;"></div>
                                            <div class="act-our-services-carousel-head-title-div2" style=" height: 12px;"></div>
                                        </div>
                                        <div class="act-catagory-name-text">
                                            <strong>همه</strong>
                                            <p>All</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php
                            foreach ($regions as $region){
                                ?>
                                <div data-id="<?=$region?>" class="act-catagory-card swiper-slide pointer button-cc45">
                                    <div class="act-catagory-card-inner">
                                        <div class="act-catagory-card-name">
                                            <div class="act-our-services-carousel-head-title-divs">
                                                <div class="act-our-services-carousel-head-title-div1" style="height: 15px;  margin-bottom: 4px;"></div>
                                                <div class="act-our-services-carousel-head-title-div2" style=" height: 12px;"></div>
                                            </div>
                                            <div class="act-catagory-name-text">
                                                <strong><?=regionPersian($region) ?></strong>
                                                <p><?=$region?></p>
                                            </div>
                                        </div>
                                        <div class="act-catagory-card-img">
                                            <img src="<?=get_template_directory_uri() . '/assets/flag/' .$region . '.svg'?>">
                                        </div>
                                    </div>
                                </div>
                                <?php
                            }
                            ?>
                        </div>
                        <div class="swiper-navigation-region">
                            <div class="swiper-button-region swiper-button-prev-region">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                                    <path d="M13.583 12l-4.293 4.293 1.414 1.414 5-5c0.39-0.391 0.39-1.024 0-1.414l-5-5-1.414 1.414 4.293 4.293z"></path>
                                </svg>
                            </div>
                            <div class="swiper-button-region swiper-button-next-region">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                                    <path d="M10.414 12l4.293 4.293-1.414 1.414-5-5c-0.391-0.391-0.391-1.024 0-1.414l5-5 1.414 1.414-4.293 4.293z"></path>
                                </svg>
                            </div>
                        </div>
                    </div>
                    </div>
                </div>
                <div class="flex fhDGSJDF">
                    <?php while ($query->have_posts()) : $query->the_post(); global $product;
                        $regular = $product->get_regular_price();
                        $sale    = $product->get_sale_price();
                        $final_price = $product->is_on_sale() && $sale > 0 ? $sale : $regular;
                        $img = get_the_post_thumbnail_url(get_the_ID(), 'product_discount');
                        $settings = get_post_meta($product->get_id(), 'giftmax_box_setting', true);
                        $delivery = get_post_meta($product->get_id(), 'delivery', true);
                        $matched_coupon_code = '';

                        if (!empty($home_coupon_objects)) {
                            foreach ($home_coupon_objects as $home_coupon_obj) {
                                $expires_at = $home_coupon_obj->get_date_expires();

                                if ($expires_at && $expires_at->getTimestamp() < current_time('timestamp')) {
                                    continue;
                                }

                                if ($home_coupon_obj->is_valid_for_product($product)) {
                                    $matched_coupon_code = $home_coupon_obj->get_code();
                                    break;
                                }
                            }
                        }
                        ?>
                        <div>
                            <div class="act-new-service-card <?=!empty($matched_coupon_code) ? 'has-discount' : ''?>">
                                <?php if (!empty($matched_coupon_code) && !isMobile()) { ?>
                                    <div class="act-new-service-card-discount Button-sc91" data-product-id="<?=esc_attr($product->get_id())?>">
                                        <div class="anScr"></div>
                                        <div class="anSct">مشاهده کد تخفیف</div>
                                        <div class="anScl"></div>
                                    </div>
                                <?php } ?>
                                <div class="act-new-service-card-inner">
                                    <div <?=isset($delivery['two']) && $delivery['two'] == 'on' || product_available($product->get_id()) ?'':'class="NdhJD5"'?>>
                                        <div class="act-new-service-card-inner-top">
                                            <a href="<?=get_permalink()?>">
                                                <div class="act-new-service-card-inner-top-img-box relative">
                                                    <img loading="lazy" decoding="async" width="32" height="33" src="<?=$img?>" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="">
                                                    <?php
                                                    if (!empty($settings[0]['logo_region'])){
                                                        ?>
                                                        <div class="logo_region">
                                                            <img src="<?=empty($settings[0]['logo_region']) ?: get_template_directory_uri() . '/assets/flag/' . $settings[0]['logo_region'] . '.svg'?>">
                                                        </div>
                                                        <?php
                                                    }
                                                    $date_from = $product->get_date_on_sale_from();
                                                    $date_to   = $product->get_date_on_sale_to();
                                                    if ($product->is_on_sale() & ($date_from || $date_to)){
                                                        ?>
                                                        <div class="logo_detail" style="top: 7px;right: 7px;background-color: transparent;">
                                                            <img width="33" height="29" src="<?=get_template_directory_uri()?>/assets/img/svg/Amazings.svg">
                                                        </div>
                                                        <?php
                                                    } elseif ($product->is_on_sale()){
                                                        ?>
                                                        <div class="logo_detail" style="top: 7px;right: 7px;">
                                                            <img src="<?=get_template_directory_uri()?>/assets/img/svg/percent.svg">
                                                        </div>
                                                        <?php
                                                    }
                                                    ?>
                                                </div>
                                            </a>
                                            <div class="act-new-service-card-inner-top-txt-box" <?=!empty($settings[0]['label']) && $settings[0]['label'] != '' ? 'style="gap:2px"' : ''?>>
                                                <a href="<?=get_permalink()?>">
                                                    <h4 class="act-product-title"><?=get_the_title()?></h4>
                                                    <?php
                                                    if(!empty($settings[0]['sub_head']) && !isMobile()) echo "<p class='act-product-title-en'>" . $settings[0]['sub_head'] . "</p>";
                                                    ?>
                                                </a>
                                                <div class="flex justify-between">
                                                    <div class="flex">
                                                        <?php
                                                        $tooltip = isset($delivery['description']) ? $delivery['description'] : '';
                                                        ?>
                                                        <div class="act-product-option-box__nw <?=isset($delivery['two']) && $delivery['two'] == 'on' ? 'pre-sale wiki wiki__holder js-dk-wiki-trigger' : 'same-day'?>" <?=isset($delivery['two']) && $delivery['two'] == 'on' ? 'data-tooltip="'. $tooltip .'"' :''?>><?=isset($delivery['two']) && $delivery['two'] == 'on' ? 'پیش فروش' : 'تحویل آنی'?></div>
                                                        <div class="purchaseScore wiki wiki__holder js-dk-wiki-trigger" data-tooltip="با خرید این گیفت کارت <?=empty($settings[0]['purchaseScore']) ?0: $settings[0]['purchaseScore']?> امتیاز دریافت میکنید">
                                                            <i class="icon-star"></i>
                                                            <?=empty($settings[0]['purchaseScore']) ?0: $settings[0]['purchaseScore']?>
                                                        </div>
                                                    </div>
                                                    <?php $is_in_wishlist = in_array((int) $product->get_id(), $giftmax_wishlist_ids, true); ?>
                                                    <button class="add-to__favorites Button-alu84 <?=$is_in_wishlist ? 'is-active' : ''?>" data-product-id="<?=esc_attr($product->get_id())?>" data-auth="<?=$giftmax_is_user_logged_in ? '1' : '0'?>" style="width: 28px;height: 28px;border-radius: 7px">
                                                        <svg viewBox="0 0 24 24" style="width: 64%;">
                                                            <path d="M12.62 20.81C12.28 20.93 11.72 20.93 11.38 20.81C8.48 19.82 2 15.69 2 8.68998C2 5.59998 4.49 3.09998 7.56 3.09998C9.38 3.09998 10.99 3.97998 12 5.33998C13.01 3.97998 14.63 3.09998 16.44 3.09998C19.51 3.09998 22 5.59998 22 8.68998C22 15.69 15.52 19.82 12.62 20.81Z" fill="<?=$is_in_wishlist ? '#ef4444' : 'none'?>" stroke="<?=$is_in_wishlist ? '#ef4444' : 'inherit'?>" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                                                        </svg>
                                                    </button>
                                                </div>
                                                <?php if (!empty($matched_coupon_code) && isMobile()) { ?>
                                                    <div class="act-new-service-card-discount Button-sc91" data-product-id="<?=esc_attr($product->get_id())?>">
                                                        مشاهده کد تخفیف
                                                    </div>
                                                <?php }else{ ?>
                                                    <p class="act-product-txt"><?=empty($settings[0]['description_short']) ?'': $settings[0]['description_short']?></p>
                                                    <?php
                                                }
                                                ?>                                                <?php
                                                if (!empty($settings[0]['label']) && $settings[0]['label'] != ''){?>
                                                    <div class="label-fjd84">
                                                        <img src="<?=empty($settings[0]['label']) ?'': $settings[0]['label']?>" class="logo_label">
                                                        <p class="label_title"><?=empty($settings[0]['label_title']) ?'': $settings[0]['label_title']?></p>
                                                    </div>
                                                    <?php
                                                }
                                                ?>
                                            </div>
                                        </div>
                                    </div>
                                    <?php
                                    $date_from = $product->get_date_on_sale_from();
                                    $date_to   = $product->get_date_on_sale_to();
                                    if ($product->is_on_sale() & ($date_from || $date_to)) {
                                        $sale_from_ts = $date_from ? $date_from->getTimestamp() : null;
                                        $sale_to_ts   = $date_to ? $date_to->getTimestamp() : null;
                                        if ($sale_from_ts && $sale_to_ts) {
                                            $now_ts = time();
                                            $total_duration = $sale_to_ts - $sale_from_ts;
                                            $elapsed = $now_ts - $sale_from_ts;

                                            $progress_percent = max(0, min(100, ($elapsed / $total_duration) * 100));
                                        } else {
                                            $progress_percent = 0;
                                        }
                                    }else{
                                        $sale_to_ts = null;
                                    }
                                    if (!$sale_to_ts){
                                        ?>
                                        <div class="act-hor-bor"></div>
                                        <?php
                                    }else{
                                        ?>
                                        <div class="flex justify-between flex-col">
                                            <div class="relative bg-neutral-100 style_ProductPromotionTimeline__progress__JnKWE" style="">
                                                <div class="absolute bg-primary-700 h-full left-0 top-0 style_ProductPromotionTimeline--active__oYyta" style="width: <?=$progress_percent?>%;"></div>
                                            </div>
                                            <span class="text-primary-700 text-body2-strong style_ProductPromotionTimeline__timer__zS6ZA1 text-left"><?= date('Y-m-d H:i:s', $sale_to_ts); ?></span>

                                        </div>
                                        <?php
                                    }
                                    ?>
                                    <div>
                                        <?php
                                        if(!empty($matched_coupon_code)){
                                            $usage_limit  = (int) $home_coupon_obj->get_usage_limit();
                                            $usage_count  = (int) $home_coupon_obj->get_usage_count();

                                            $remaining_uses = $usage_limit > 0
                                                ? max( 0, $usage_limit - $usage_count )
                                                : __( 'نامحدود', 'textdomain' );
                                            ?>
                                            <div class="">
                                                <div class="relative bg-neutral-100 style_ProductPromotionTimeline__progress__JnKWE">
                                                    <div class="absolute bg-primary-700 h-full left-0 top-0 style_ProductPromotionTimeline--active__oYyta" style="width: <?=($home_coupon_obj->get_usage_count()/($home_coupon_obj->get_usage_count()+$remaining_uses))*100?>%;"></div>
                                                </div>
                                                <div class="whitespace-nowrap flex justify-between pt-1">
                                                    <div class=""><span class="text-primary-700 text-body-strong ml-1"><?=($home_coupon_obj->get_usage_count()/($home_coupon_obj->get_usage_count()+$remaining_uses))*100?>%</span><span class="text-neutral-500 text-caption">فروش رفته</span></div>
                                                    <?php
                                                    if ($home_coupon_obj->get_date_expires()){
                                                        ?>
                                                        <div class="text-primary-700 text-body2-strong style_ProductPromotionTimeline__timer__zS6ZA"><?= $home_coupon_obj->get_date_expires() ? $home_coupon_obj->get_date_expires()->date_i18n( 'Y-m-d H:i:s' ) : 'بدون تاریخ انقضا'?></div>
                                                        <?php
                                                    }else{?>
                                                        <div class="text-primary-700 text-body2-strong style_ProductPromotionTimeline__timer__zS6ZA"></div>
                                                    <?php }
                                                    ?>
                                                </div>
                                            </div>
                                            <?php
                                        }
                                        ?>
                                        <div class="act-product-card-footer">
                                            <a href="<?=the_permalink()?>" class="act-special-carousel-card-buy-box-option">جزئیات</a>
                                            <div class="act-product-price-box">
                                                <?php
                                                if ( $product->is_on_sale() ) {?>
                                                    <div class="act-product-price-box-top">
                                                        <div class="act-product-price-off-price"><?=number_format_usd($regular)?></div>
                                                        <div class="act-product-price-off-percent">  <?=get_discount_percent($product)?> ٪       </div>


                                                    </div>
                                                    <?php
                                                }
                                                ?>
                                                <div class="act-product-price<?=$product->is_on_sale() ? ' bpt' : ''?>">
                                                    <?php
                                                    if($final_price > 0){?>
                                                        <div id="priceValue" data-id="<?=$product->get_id()?>" data-target="<?=payment_usd($product->is_on_sale() ? $sale :$regular)?>"><?=number_format_usd($product->is_on_sale() ? $sale : $regular)?></div><span>تومان</span>
                                                        <?php
                                                    }else{
                                                        ?>
                                                        <div class="act-product-price-free">رایگان</div>
                                                        <?php
                                                    }
                                                    ?>
                                                </div>
                                            </div>
                                        </div>
                                        <?php
                                        if (isset($delivery['two']) && $delivery['two'] == 'on' || product_available($product->get_id())){
                                            if (\Giftmax\Modules\UserModel::setting("buy") === true){
                                                ?>
                                                <button type="button" class="act-special-carousel-card-buy-box-but Button-aca48 pointer" data-product-id="<?=$product->get_id()?>">
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="26" height="26" viewBox="0 0 26 26" fill="currentcolor">
                                                        <path d="M17.875 9.34916C17.4308 9.34916 17.0625 8.98083 17.0625 8.53666V7.04166C17.0625 5.90416 16.575 4.79916 15.73 4.03C14.8742 3.25 13.7692 2.8925 12.5992 3.00083C10.6492 3.185 8.9375 5.17833 8.9375 7.25833V8.30916C8.9375 8.75333 8.56917 9.12166 8.125 9.12166C7.68083 9.12166 7.3125 8.75333 7.3125 8.30916V7.2475C7.3125 4.33333 9.66333 1.64666 12.4475 1.37583C14.0725 1.22417 15.6325 1.73333 16.8242 2.8275C18.005 3.9 18.6875 5.43833 18.6875 7.04166V8.53666C18.6875 8.98083 18.3192 9.34916 17.875 9.34916Z"></path>
                                                        <path d="M16.2498 24.6457H9.7498C4.7448 24.6457 3.81314 22.3165 3.5748 20.0523L2.7623 13.5632C2.64314 12.3932 2.5998 10.714 3.7373 9.45734C4.7123 8.374 6.32647 7.854 8.66647 7.854H17.3331C19.684 7.854 21.2981 8.38484 22.2623 9.45734C23.389 10.714 23.3565 12.3932 23.2373 13.5415L22.4248 20.0523C22.1865 22.3165 21.2548 24.6457 16.2498 24.6457ZM8.66647 9.479C6.83564 9.479 5.57897 9.8365 4.9398 10.5515C4.40897 11.1365 4.23564 12.0357 4.37647 13.379L5.18897 19.8682C5.37314 21.6015 5.8498 23.0315 9.7498 23.0315H16.2498C20.1498 23.0315 20.6265 21.6123 20.8106 19.8898L21.6231 13.379C21.764 12.0573 21.5906 11.1582 21.0598 10.5623C20.4206 9.8365 19.164 9.479 17.3331 9.479H8.66647Z"></path>
                                                        <path d="M16.7045 14.2458C16.0979 14.2458 15.6104 13.7583 15.6104 13.1624C15.6104 12.5666 16.0979 12.0791 16.6937 12.0791C17.2895 12.0791 17.777 12.5666 17.777 13.1624C17.777 13.7583 17.3004 14.2458 16.7045 14.2458Z"></path>
                                                        <path d="M9.12151 14.2458C8.51484 14.2458 8.02734 13.7583 8.02734 13.1624C8.02734 12.5666 8.51484 12.0791 9.11068 12.0791C9.70651 12.0791 10.194 12.5666 10.194 13.1624C10.194 13.7583 9.71734 14.2458 9.12151 14.2458Z"></path>
                                                    </svg>
                                                    افزودن به سبد خرید
                                                </button>
                                                <?php
                                            }else{?>
                                                <button type="button" class="btn btn-buy-disable mb-2" >خرید از سایت غیرفعال هست</button>
                                                <?php
                                            }
                                        }else{
                                            echo '<div class="inaJSDge8">ناموجود</div>';
                                        }
                                        ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endwhile; ?>
                </div>
                <span class="swiper-notification" aria-live="assertive" aria-atomic="true"></span>
            </div>
        <?php
        else :
        ?>
         <div class="w-full flex justify-center fhDGSJDF sfje5">
             <p>محصولی در این دسته بندی قرار نداره</p>
         </div>
        <?php
        endif;
        wp_reset_postdata();

        $html = ob_get_clean();
        $extra_description = get_term_meta($term->term_id, 'extra_description', true);

        return new \WP_REST_Response([
            'success' => true,
            'html'    => $html,
            'description'=> $extra_description,
        ], 200);
    }
    public function comment_api_function(){
        if (!is_user_logged_in()) {
            echo json_encode(['status' => false,'message'=>'ابتدا باید وارد شوید!']);
            return;
        }

        $user = wp_get_current_user();
        $product_id = intval($_POST['product_id']);
        $comment_content = sanitize_textarea_field($_POST['comment']);
        $rating = intval($_POST['rating']);
        if ($rating < 1 || $rating > 5) {
            echo json_encode(['status' => false,'message'=>'امتیاز نامعتبر است']);
            return;
        }
        $raw_points = isset($_POST['points']) ? wp_unslash($_POST['points']) : [];
        $comment_points = [];

        if (is_array($raw_points)) {
            foreach ($raw_points as $point) {
                $point = trim(sanitize_text_field($point));
                if ($point !== '') {
                    $comment_points[] = $point;
                }
            }
        } elseif (is_string($raw_points)) {
            $point = trim(sanitize_text_field($raw_points));
            if ($point !== '') {
                $comment_points[] = $point;
            }
        }

        if (!wc_customer_bought_product($user->user_email, $user->ID, $product_id)) {
            echo json_encode(['status' => false,'message'=>'فقط خریداران محصول می‌توانند نظر ثبت کنند']);
            return;
        }

        $comment_id = wp_insert_comment([
            'comment_post_ID' => $product_id,
            'comment_author' => $user->display_name,
            'comment_author_email' => $user->user_email,
            'comment_content' => $comment_content,
            'comment_type' => 'review',
            'user_id' => $user->ID,
            'comment_approved' => 0
        ]);

        if ($comment_id) {
            add_comment_meta($comment_id, 'rating', $rating);
            if (!empty($comment_points)) {
                add_comment_meta($comment_id, 'comment_points', $comment_points, true);
            }
            echo json_encode(['status' => true,'message'=>'نظر شما با موفقیت ثبت شد']);
            return;
        }
        echo json_encode(['status' => false,'message'=>'خطا در ثبت نظر']);
    }
    public function update_wallet_discount( \WP_REST_Request $request ) {

        if ( ! is_user_logged_in() ) {
            return new \WP_REST_Response([
                'status' => false,
                'message' => 'unauthorized'
            ], 401);
        }

        // تضمین آماده بودن Woo
        if ( ! WC()->session ) WC()->initialize_session();
        if ( ! WC()->cart ) WC()->initialize_cart();

        $cart = WC()->cart;

        if ( $cart->is_empty() ) {
            return new \WP_REST_Response([
                'status' => false,
                'message' => 'سبد خرید خالی است'
            ], 400);
        }

        $use_wallet = (int) $request->get_param('useWallet');
        WC()->session->set('use_wallet', $use_wallet);
        WC()->session->set('wallet_dirty', microtime(true));

        $cart->calculate_totals();
        if ($use_wallet){
            $available = (UserModel::wallet()) -  $cart->get_subtotal();
        }else{
            $available = (UserModel::wallet());
        }
        return new \WP_REST_Response([
            'success'   => true,
            'subtotal' => number_format_usd( $cart->get_subtotal() ),
            'total'    => number_format_usd( $cart->get_total('edit') ),
            'dtotal'   => number_format( $cart->get_total('edit') ),
            'available'   =>$available,
        ], 200);
    }
    public function coupon_api_function( \WP_REST_Request $request ) {

        if ( ! class_exists('WooCommerce') ) {
            wp_send_json_error([
                'message' => 'ووکامرس فعال نیست'
            ]);
        }

        if ( null === WC()->session ) {
            WC()->initialize_session();
        }

        if ( null === WC()->customer ) {
            WC()->customer = new \WC_Customer( get_current_user_id(), true );
        }

        if ( null === WC()->cart ) {
            WC()->cart = new \WC_Cart();
        }

        $coupon_code = wc_format_coupon_code(
            wp_unslash( $request->get_param('coupon') )
        );
        $payment_type = WC()->session->get('payment_type');
        if ( $payment_type !== 'r' ) {
            wp_send_json_error([
                'message' => 'کد تخفیف فقط در پرداخت ریالی قابل استفاده است'
            ]);
        }
        if (WC()->session->get('payment_type') !== 'r') {
            WC()->session->set('wallet_discount', 0);

            $cart = WC()->cart;
            if ( $cart ) {
                foreach ( $cart->get_fees() as $key => $fee ) {
                    if ( $fee->name === 'Wallet discount' ) {
                        $cart->remove_fee( $key );
                    }
                }
                $cart->calculate_totals();
            }
        }
        if ( empty($coupon_code) ) {
            echo json_encode(['status' => false,'message' => 'کد تخفیف وارد نشده است']);
            return;

        }

        $cart = WC()->cart;

        if ( $cart->is_empty() ) {
            echo json_encode(['status' => false, 'message' => 'سبد خرید خالی است']);
            return;
        }

        $cart->remove_coupons();

        try {
            $coupon = new \WC_Coupon( $coupon_code );

            if ( ! $coupon->get_id() ) {
                throw new \Exception('کد تخفیف معتبر نیست');
            }

            $result = $cart->apply_coupon( $coupon_code );

            if ( ! $result ) {
                throw new \Exception(
                    wc_get_notices('error')[0]['notice'] ?? 'امکان اعمال کد تخفیف وجود ندارد'
                );
            }

            $cart->calculate_totals();

        } catch ( \Exception $e ) {
            wp_send_json_error([
                'message' => $e->getMessage()
            ]);
        }
        $cart_product_discount = 0;

        foreach ( WC()->cart->get_cart() as $cart_item ) {
            $product = $cart_item['data'];
            $qty     = (int) $cart_item['quantity'];
            $regular_price = (float) $product->get_regular_price();
            $line_total    = $cart_item['line_total'];

            $cart_product_discount += ($regular_price * $qty) - $line_total;
        }

        $total_discount = $cart_product_discount;
        WC()->session->set('rial_coupon', $coupon_code);

        echo json_encode([
            'status' => true,
            'message' => 'کد تخفیف با موفقیت اعمال شد',
            'summary' => [
                'subtotal' => number_format_usd( $cart->get_subtotal() ),
                'discount' => number_format_usd( $total_discount ),
                'total'    => number_format_usd( $cart->get_total('edit') ),
            ]
        ]);
    }
    public function payment_methods_api_function(\WP_REST_Request $request) {

        if ( ! class_exists('WooCommerce') ) {
            wp_send_json_error([
                'message' => 'ووکامرس فعال نیست'
            ]);
        }
        $method = $request->get_param('method');

        if ( null === WC()->session ) {
            WC()->initialize_session();
        }

        if ( null === WC()->customer ) {
            WC()->customer = new \WC_Customer( get_current_user_id(), true );
        }

        if ( null === WC()->cart ) {
            WC()->cart = new \WC_Cart();
        }
        WC()->cart->calculate_totals();

        $cart = WC()->cart;

        $cart_product_discount = 0;
        WC()->session->set('payment_type', $method);
        $stored_coupon = WC()->session->get('rial_coupon');
        if($method=='r') {
            if ( $stored_coupon && ! WC()->cart->has_discount( $stored_coupon ) ) {
                WC()->cart->apply_coupon( $stored_coupon );
                WC()->cart->calculate_totals();
            }
        }else{
            if ( $stored_coupon ) {
                WC()->cart->remove_coupon( $stored_coupon );
                WC()->cart->calculate_totals();
            }
        }
        foreach (WC()->cart->get_cart() as $cart_item) {
            $product = $cart_item['data'];
            $qty = (int)$cart_item['quantity'];
            $regular_price = (float)$product->get_regular_price();
            $line_total = $cart_item['line_total'];

            $cart_product_discount += ($regular_price * $qty) - $line_total;
        }

        $coupon_discount_total = WC()->cart->get_discount_total();
        $total_discount = $cart_product_discount + $coupon_discount_total;

        $update_dollar = null;
        $USD = UserModel::table("setting","meta_key","currency");
        if (!empty($USD)) {
            $currencies = json_decode($USD['meta_value'],true);
            foreach ($currencies as $currency) {
                if ($currency['symbol'] === 'USD') {
                    $usd_rate_updated_at = $currency['time'];
                    $dollar = $currency['dayClose'];
                    break;
                }
            }
        }
        if (!empty($usd_rate_updated_at)) {
            $usd_rate_updated_ts = strtotime($usd_rate_updated_at);
            if ($usd_rate_updated_ts !== false) {
                $elapsed_seconds = max(0,time()  - $usd_rate_updated_ts);
                if ($elapsed_seconds < 60) {
                    $update_dollar = $elapsed_seconds . ' ثانیه ';
                } else {
                    $elapsed_minutes = (int) floor($elapsed_seconds / 60);
                    $update_dollar = $elapsed_minutes . ' دقیقه ';
                }
            }
        }

        if($method=='r') {
            echo json_encode([
                'status' => true,
                'summary' => [
                    'subtotal' => '<span class="text-larger font-bold text-dark tracking-tighter pt-2 inline-block">' .  number_format_usd($cart->get_subtotal()+$total_discount) . '</span>' . "تومان",
                    'discount' => '<span class="text-larger font-bold text-red tracking-tighter pt-2 inline-block">'. number_format_usd($total_discount) .'</span>' . "تومان",
                    'total' => '<span class="text-lg font-bold text-green-dark tracking-tighter pt-2 inline-block">'. number_format_usd($cart->get_total('edit')) .'</span>' . "تومان",
                ]

            ]);
        }else{
            echo json_encode([
                'status' => true,
                'summary' => [
                    'subtotal' => '<span class="text-larger font-bold text-dark tracking-tighter pt-2 inline-block">' . number_format(($cart->get_subtotal() + $total_discount)/$dollar) . '</span>' . "دلار",
                    'discount' => '<span class="text-larger font-bold text-red tracking-tighter pt-2 inline-block">'. number_format($total_discount/$dollar) .'</span>' . "دلار",
                    'dollar' => '<span class="text-lg font-bold text-green-dark tracking-tighter pt-2 inline-block">'. number_format($dollar) .'</span>' . "تومان",
                    'update_dollar' => $update_dollar,
                    'total' => '<div class="flex flex-col ai-end gap-3"><div><span class="text-lg font-bold text-green-dark tracking-tighter pt-2 inline-block">'. number_format_usd($cart->get_total('edit')) .'</span>تومان' . "</div>" .
                        '<div><span class="text-lg font-bold text-green-dark tracking-tighter pt-2 inline-block">'. number_format($cart->get_total('edit')/$dollar) .'</span>دلار' . "</div>" . '</div>',
                ]

            ]);
        }
    }
    private static function suspiciousOrder($order)
    {
        global $wpdb;
        $db = \Giftmax\Modules\Db::getLnstance();
        $records = $db->first("SELECT * FROM `{$wpdb->prefix}setting` WHERE `meta_key`='suspicious_order'");
        if (empty($records)){
            return false;
        }
        $record = json_decode($records['meta_value'], true);

        if (!$order) {
            return;
        }
        if ($order->get_status() !== 'completed' && $order->get_status() !== 'card-not-verified') {
            $order->update_meta_data('_suspicious_order', 0);
            $order->save();
            return;
        }
        if ($order->get_total() < $record[0]['minTotal']) {
            $order->update_meta_data('_suspicious_order', 0);
            $order->save();
            return;
        }

        $customer_id = $order->get_customer_id();

        if (!$customer_id) {
            $order->update_meta_data('_suspicious_order', 0);
            $order->save();
            return;
        }

        $orders = wc_get_orders([
                'customer_id' => $customer_id,
                'status'      => ['completed','card-not-verified'],
                'limit'       => 1,
                'orderby'     => 'date',
                'order'       => 'DESC',
                'exclude'     => [$order->get_id()],
                'return'      => 'objects',
        ]);
        if (empty($orders)) {
            $order->update_meta_data('_suspicious_order', 0);
            $order->save();
            return;
        }

        $last_order = $orders[0];

        $diff = $order->get_date_created()->getTimestamp() - $last_order->get_date_created()->getTimestamp();

        if ($diff <= ($record[0]['minutes'] * 60)) {
            $order->update_meta_data('_suspicious_order', 1);
            $order->save();
        }else{
            $order->update_meta_data('_suspicious_order', 0);
            $order->save();
        }
    }
    public function payment_api_function(\WP_REST_Request $request) {
        if (is_user_blocked()) {
            echo json_encode([
                'status'  => false,
                'message' => 'شما بلاک شده اید'
            ]);
            exit();
        }
        if (!class_exists('WooCommerce')) {
            return new \WP_REST_Response([
                'message' => 'ووکامرس فعال نیست'
            ], 400);
        }
        $buyer_ip = giftmax_get_user_ip();
        if ( ! giftmax_is_iran_ip($buyer_ip) ) {
            echo json_encode([
                'status'  => false,
                'message' => 'پرداخت فقط از طریق IP ایران امکان‌پذیر است.'
            ]);
            exit();
        }
        if (null === WC()->session) {
            WC()->initialize_session();
        }
        if (null === WC()->customer) {
            WC()->customer = new \WC_Customer(get_current_user_id(), true);
        }
        if (null === WC()->cart) {
            WC()->cart = new \WC_Cart();
        }

        $gateway = sanitize_text_field($request->get_param('gateway'));
        $number = $request->get_param('number');
        if (!in_array($gateway, ['zibal', 'paystar', 'Payment4'], true)) {
            return new \WP_REST_Response([
                'status' => false,
                'message' => 'درگاه پرداخت نامعتبر است'
            ], 200);
        }

        if (WC()->payment_gateways()->payment_gateways()[$gateway]->enabled != 'yes') {
            return new \WP_REST_Response([
                'status' => false,
                'message' => 'درگاه پرداخت غیرفعال است'
            ], 200);
        }

        $user = wp_get_current_user();
        $u    = UserModel::table('user_identity', 'user_id', $user->ID);
        if (!$u['is_verified']){
            return new \WP_REST_Response([
                'status' => false,
                'message' => 'برای پرداخت شما اول باید احراز هویت را کامل کنید'
            ], 200);
        }
        $cart = WC()->cart;
        if ($cart->is_empty()) {
            return new \WP_REST_Response([
                'status' => false,
                'message' => 'سبد خرید خالی است'
            ], 200);
        }
        $amount = $cart->get_total('edit');
        $vip = isset($u['account_type']) && $u['account_type'] != 'vip';
        global $wpdb;
        $db = Db::getLnstance();
        $order = null;

        try {
            $order = wc_create_order([
                'customer_id' => $user->ID,
            ]);
            $order->set_customer_id($user->ID);
            $order->set_billing_first_name($user->first_name);
            $order->set_billing_last_name($user->last_name);
            $order->set_billing_phone($user->user_login);
            $order->save();
            $has_preorder = false;

            foreach ($cart->get_cart() as $item) {
                $product = wc_get_product($item['product_id']);
                if (!$product) {
                    continue;
                }
                $delivery = get_post_meta($product->get_id(), 'delivery', true);

                $is_preorder = (
                        isset($delivery['two']) &&
                        $delivery['two'] === 'on'
                );

                if ($is_preorder) {
                    $has_preorder = true;
                }
                if (!$is_preorder) {
                    $available_licenses = $db->query("SELECT licence_id FROM {$wpdb->prefix}product_licences WHERE product_id = :product_id AND licence_status='available' ORDER BY sort_order ASC", array('product_id' => $product->get_id()));
                    if (!$available_licenses) {
                        return new \WP_REST_Response([
                                'status' => false,
                                'message' => 'در حال حاضر لایسنسی برای محصول ' . $product->name . ' نداریم لطفا برای ادامه تراکنش ایم محصول رو از سبد خرید حذف کنید '
                        ]);
                    }
                    if (count($available_licenses) < $item['quantity']) {
                        return new \WP_REST_Response([
                                'status' => false,
                                'message' => 'در حال حاضر ' . count($available_licenses) . ' لایسنس برای محصول ' . $product->name . 'داریم لطفا تعداد محصول را مطابق به تعداد لایسنس ها موجود کنید'
                        ]);
                    }
                }
                if ($product->get_price() == 0 || $product->get_price() == ''){
                    return new \WP_REST_Response([
                            'status' => false,
                            'message' => 'برای پرداخت ' . $product->name . ' را از سبد خرید حذف کنید'
                    ], 200);
                }
               $order->add_product($product, $item['quantity']);
            }

            $order->update_meta_data('_has_preorder_items', $has_preorder);
            $points = (int) WC()->session->get( 'total_cart_points', 0 );
            $wallet_discount = (int) WC()->session->get( 'wallet_discount', 0 );
            $use_wallet = (int) WC()->session->get( 'use_wallet', true );
            $rial_coupon = WC()->session->get( 'rial_coupon');
            $order->set_payment_method($gateway);
            $order->update_status('pending', 'در انتظار پرداخت');
            $order->update_meta_data('_total_cart_points', $points);
            $order->update_meta_data('_wallet_discount', $wallet_discount);
            $order->update_meta_data('_use_wallet', $use_wallet);
            $order->update_meta_data('_rial_coupon', $rial_coupon);
            $order->update_meta_data('_buyer_ip', $buyer_ip);
            $order->save();
            if ($amount ==0){
                add_filter(
                    'woocommerce_email_enabled_customer_completed_order',
                    '__return_false'
                );
                try {
                    $order->update_status('completed', 'سفارش به صورت خودکار پس از پرداخت تکمیل شد');
                    $order->save();
                } catch (\Throwable $e) {
                    error_log(
                        '[PAYMENT VERIFY API] Order completed but email failed: ' .
                        $e->getMessage()
                    );
                }
                $applied_coupons =  $order->get_meta( '_rial_coupon');
                if ( !empty( $applied_coupons ) ) {
                    try {
                        $coupon = new \WC_Coupon($applied_coupons);
                        if (!$coupon->get_id()) {
                            $order->add_order_note('⚠️ کد تخفیف ' . $applied_coupons . ' در سیستم یافت نشد.');
                            throw new \Exception('Coupon not found.');
                        }

                        $usage_count = (int)$coupon->get_usage_count();
                        $coupon->set_usage_count($usage_count + 1);
                        $coupon->save();

                        $order->add_order_note(
                                sprintf(
                                        '✅ کد تخفیف "%s" با موفقیت در آمار ووکامرس ثبت شد. (استفاده %d)',
                                        $applied_coupons,
                                        $usage_count + 1
                                )
                        );

                        $order->save();

                        if (!in_array($applied_coupons, $order->get_coupon_codes())) {
                            $order->apply_coupon($applied_coupons);
                            $order->save();
                        }
                    } catch (\Exception $e) {
                        $order->add_order_note('❌ خطا در ثبت کد تخفیف: ' . $e->getMessage());
                    }
                }
                $use_wallet = $order->get_meta( '_use_wallet', true );
                $user_id = get_current_user_id();
                if ($use_wallet) {
                    $discount = $order->get_meta( '_wallet_discount', true );
                    $wallet = $db->first( "SELECT * FROM {$wpdb->prefix}wallet WHERE user_id = :user_id", array('user_id'=>$user_id ));
                    $discount = abs($discount);
                    $wallet_bal = $wallet['balance'];
                    if ($wallet_bal > 0) {
                        $new_balance = floatval($wallet_bal) - $discount;
                        $new_balance = max(0.0, $new_balance);
                        $db->query('START TRANSACTION');
                        $db->modify("UPDATE {$wpdb->prefix}wallet SET balance=:balance WHERE id=:id", array(
                                        'balance' => $new_balance,
                                        'id' => $wallet['id']
                                )
                        );
                        $db->insert("INSERT INTO `{$wpdb->prefix}wallet_transactions` (`id`, `user_id`,`method`, `method_id`, `amount`, `type`, `description`, `created_at`) VALUES (NULL, :user_id,'wallet', :method_id, :amount, 'debit', :description, :created_at)", array(
                                        'user_id' => $user_id,
                                        'method_id' => $wallet['id'],
                                        'amount' => $discount,
                                        'description' => 'کسری از قیمت سبد خرید',
                                        'created_at' => date('Y-m-d H:i:s')
                                )
                        );
                        $db->query( 'COMMIT' );
                    }
                }
                $total_points = $order->get_meta( '_total_cart_points', true );
                if ($total_points !=0){
                    $points = $db->first( "SELECT * FROM {$wpdb->prefix}user_points WHERE user_id = :user_id", array('user_id'=>$user_id ));
                    if (!empty($points)) {
                        $db->modify("UPDATE {$wpdb->prefix}user_points SET points=:points WHERE id=:id", array(
                                        'points'=> (int)$points['points'] + (int)$total_points,
                                        'id'=>$points['id']
                                )
                        );
                    }else{
                        $db->insert("INSERT INTO `{$wpdb->prefix}user_points` (`id`, `user_id`, `points`) VALUES (NULL, :user_id, :points)",array(
                                        'user_id'=>$user_id,
                                        'points'=> (int)$total_points,
                                )
                        );
                        $points['id'] = $db->lastInsertId();
                    }
                    $db->insert("INSERT INTO `{$wpdb->prefix}wallet_transactions` (`id`, `user_id`,`method`, `method_id`, `amount`, `type`, `description`, `created_at`) VALUES (NULL, :user_id,'points', :method_id, :amount, 'credit', :description, :created_at)",array(
                                    'user_id'=>$user_id,
                                    'method_id'=>$points['id'],
                                    'amount'=>$total_points,
                                    'description'=>'دریافت امتیاز خرید',
                                    'created_at'=>date('Y-m-d H:i:s')
                            )
                    );
                }
                $hasIncompleteLicence = false;
                foreach ($order->get_items() as $item_id => $item) {
                    $reserved_licence_ids = [];
                    $product_id = $item->get_product_id();
                    $delivery   = get_post_meta( $product_id, 'delivery', true );
                    $product = wc_get_product( $product_id );
                    $product_name = $product->get_name();
                    $product_permalink = $product->get_permalink();
                    $product_img = get_the_post_thumbnail_url($product_id, 'product_discount');
                    if ( isset( $delivery['two'] ) && $delivery['two'] === 'on'){
                        $delivery_time = isset( $delivery['time'] ) ? absint( $delivery['time'] ) : 0;
                        $dataLincesns = $order->get_date_created()
                                ? (clone $order->get_date_created())
                                        ->modify( '+'.$delivery_time.' hour' )
                                        ->date( 'Y/m/d H:i' )
                                : $delivery_time;
                        $dataLincesns = gjdate($dataLincesns,"d M Y، H:i");
                        $body = '<div class="flex justify-between"> <div> محصول <a href="'.$product_permalink.'" target="_blank">'.$product_name.'</a> در سبد خرید شما به صورت <span class="pre-sale__span">پیش فروش</span> می‌باشد و تا '.$delivery_time.' ساعت آینده لایسنس آن تحویل شما داده می‌شود. </div> <div class="flex gap-2 s2ged"> <img class="w-[87px]" src="'.$product_img.'" alt="'.$product_name.'"> <div class="c-badge rounded-sm badge-orange text-2xs -mt-1 flex flex-col"> <div>تا '.$dataLincesns.'</div> <div>لایسنس موجود میشود</div> </div> </div> </div>';
                        $db->insert("INSERT INTO `{$wpdb->prefix}notifications` (`userId`,`body`,`title`,`status`,`is_active`,`created_at`) VALUES (:user_id,:body,:title,'show',1,NOW())", array(
                                'user_id' => $user_id,
                                'title' => 'محصول پیش فروش در سبد خرید',
                                'body' => $body
                        ));
                        UserModel::alert($user_id,$db->lastInsertId());
                    }else{
                        $manage_stock = get_post_meta($product_id, '_manage_stock', true);
                        if ($manage_stock == 'yes') {
                            $count = $db->first("SELECT COUNT(*) AS total FROM `{$wpdb->prefix}product_licences` WHERE product_id = :product_id AND licence_status = 'available'",array('product_id'=>$product_id))['total'];
                            update_post_meta($product_id, '_stock', $count);
                            if($count >=1) {
                                update_post_meta($product_id, '_stock_status', 'instock');
                            }
                        }
                    }
                    $is_preorder = (
                            isset($delivery['two']) &&
                            $delivery['two'] === 'on'
                    );

                    if ($is_preorder) {
                        continue;
                    }

                    $requested = (int)$item['quantity'];

                    try {

                        $db->query("START TRANSACTION");

                        $licences = $db->query(" SELECT licence_id FROM {$wpdb->prefix}product_licences WHERE product_id = :product_id AND licence_status='available' ORDER BY sort_order ASC LIMIT {$requested} FOR UPDATE ",[
                                'product_id'=>$product->get_id()
                        ]);
                        foreach ($licences as $licence){
                            $reserved_licence_ids[] = $licence['licence_id'];
                            $db->modify(" UPDATE {$wpdb->prefix}product_licences SET licence_status='assigned', assigned_at=:assigned_at, order_id=:order_id WHERE licence_id=:licence_id ",[
                                    'assigned_at'=>current_time('mysql'),
                                    'order_id'=>$order->get_id(),
                                    'licence_id'=>$licence['licence_id']
                            ]);
                        }

                        $db->query("COMMIT");

                        if(count($licences) < $requested){

                            $hasIncompleteLicence = true;

                            $incompleteProducts[] = [
                                    'product'   => $product->get_name(),
                                    'requested' => $requested,
                                    'assigned'  => count($licences)
                            ];
                        }

                    }catch(Exception $e){

                        $db->query("ROLLBACK");
                        throw $e;

                    }
                    if (!empty($reserved_licence_ids) && is_array($reserved_licence_ids)) {
                        $item->update_meta_data(
                                '_reserved_licence_ids',
                                json_encode($reserved_licence_ids)
                        );
                        $item->save();
                    }
                }
                if($hasIncompleteLicence){

                    $order->update_meta_data('_giftmax_incomplete_licence', 1);
                    $order->update_meta_data('_giftmax_incomplete_products', $incompleteProducts);
                    $order->save();
                    $note = "کمبود لایسنس:\n";

                    foreach($incompleteProducts as $row){

                        $missing = $row['requested'] - $row['assigned'];

                        $note .= "{$row['product']} : {$row['assigned']} تحویل شد، {$missing} عدد موجود نبود.\n";
                    }

                    $order->add_order_note($note);
                }
                self::suspiciousOrder($order);
                self::clear_checkout_cart($order->get_user_id());
                echo json_encode([
                    'status' => true,
                    'url' => home_url('/profile/invoices/'.$order->get_id())
                ]);
                exit();
            }else {
                self::clear_checkout_cart($order->get_user_id());
                switch ($gateway) {
                    case 'zibal':
                        $order->set_total($amount);
                        $order->save();
                        return $this->start_zibal_payment($order, $amount * 10);
                    case 'paystar':
                        $order->set_total($amount);
                        $order->save();
                        return $this->start_paystar_payment($order, $amount * 10);
                    case 'Payment4':
                        $order->set_total($amount);
                        $order->save();
                        return $this->start_payment4_payment($order);
                }
            }
        }catch ( Throwable $e ) { // هر گونه خطا یا exception
            if ($order) {
                $order->delete();
            }
            return new \WP_REST_Response(
                [
                    'status'  => false,
                    'message' => $e->getMessage(),
                    'file'    => $e->getFile(),
                    'line'    => $e->getLine(),
                ],
                200
            );
        }
    }
    private function start_paystar_payment($order, $amount){
        $paystar = get_option('woocommerce_paystar_settings');
        $sign_key = $paystar['sign'];
        $gateway_id = $paystar['gateway_id'];
        if ( empty( $gateway_id ) || empty( $sign_key ) ) {
            return new \WP_REST_Response(
                [ 'message' => __( 'تنظیمات PayStar به‌طور کامل تنظیم نشده‌اند.', 'giftmax' ) ],
                500
            );
        }
        $order_id     = $order->get_id();
        $callback_url = home_url( '/wp-json/api/v1/payment-verify/paystar');

        $sign_data = $amount . '#' . $order_id . '#' . $callback_url;
        $sign      = hash_hmac( 'SHA512', $sign_data, $sign_key );
        $user = get_userdata($order->get_user_id());
        $body = [
            'amount'    => $amount,
            'order_id'  => $order_id,
            'callback'  => $callback_url,
            'sign'      => $sign,
            'name'      => "$user->first_name $user->last_name",
            'description' => 'پرداخت سفارش #' . $order_id,
            'callback_method' => 0
        ];
        $response = wp_remote_post( 'https://core.paystar.ir/api/pardakht/create', [
            'headers' => [
                'Content-Type'  => 'application/json',
                'Authorization' => 'Bearer ' . $gateway_id,
            ],
            'body'    => wp_json_encode( $body ),
            'timeout' => 30,
        ] );
        if ( is_wp_error( $response ) ) {
            return new \WP_REST_Response(
                [ 'message' => __( 'خطا در ارتباط با درگاه PayStar.', 'giftmax' ) ],
                500
            );
        }

        $res = json_decode( wp_remote_retrieve_body( $response ), true );

        if ( isset($res['status']) && $res['status']==1 ) {
            $payment_url = 'https://core.paystar.ir/api/pardakht/payment?token=' . $res['data']['token'];
            $order->update_meta_data( '_paystar_ref_num', $res['data']['ref_num']);
            $order->update_meta_data( 'payment_amount', $res['data']['payment_amount']);
            $order->save();
            return new \WP_REST_Response(
                [
                    'status' => true,
                    'url'    => $payment_url,
                ],
                200
            );
        }

        $error_msg = '';
        if ( ! empty( $res['errors'] ) ) {
            $error_msg = implode( "\n", $res['errors'] );
        } elseif ( ! empty( $res['message'] ) ) {
            $error_msg = $res['message'];
        } else {
            $error_msg = __( 'خطا در درگاه PayStar', 'giftmax' );
        }

        $order->update_status( 'failed', __( 'خطا در اتصال به درگاه PayStar', 'giftmax' ) );
        $order->save();

        return new \WP_REST_Response(
            [
                'status'  => false,
                'message' => $error_msg,
            ],
            500
        );
    }
    private function start_zibal_payment($order, $amount) {
        $zibal = get_option('woocommerce_zibal_settings');

        $merchant = $zibal['api_key'];
        $callback = home_url('/wp-json/api/v1/payment-verify/zibal') . '?order_id=' . $order->get_id();
        $parameters = [
            "merchant" => $merchant,
            "callbackUrl" => $callback,
            "amount" => (int) $amount,
            "orderId" => $order->get_id(),
            "mobile" => get_userdata($order->get_user_id())->user_login,
            "description" => "پرداخت سفارش #" . $order->get_id()
        ];
        $response = $this->postToZibal('request', $parameters);
        if (isset($response->result) && $response->result == 100) {
            $order->update_meta_data('_zibal_trackId', $response->trackId);
            $order->save();

            echo json_encode([
                'status' => true,
                'url' => "https://gateway.zibal.ir/start/" . $response->trackId
            ]);
            exit();
        }
        add_filter(
            'woocommerce_email_enabled_customer_completed_order',
            '__return_false'
        );
        $order->update_status( 'failed', ( 'خطا در اتصال به درگاه Zibal') );
        $order->save();
        echo json_encode([
            'status' => false,
            'message' => $response->message ?? 'خطا در اتصال به درگاه Zibal'
        ]);
    }
    private function postToZibal($path, $parameters)
    {
        $url = 'https://gateway.zibal.ir/v1/' . $path;

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($parameters));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        $response = curl_exec($ch);
        curl_close($ch);

        return json_decode($response);
    }
    private function start_payment4_payment($order){
        $apiKey = get_option('woocommerce_payment4_settings')['api_key'];
        $url    = "https://service.payment4.com/api/v1/payment";

        $callbackUrl = home_url('/wp-json/api/v1/payment-verify/payment4');
        $payload = [
            "amount"       => intval($order->get_total()),
            "callbackUrl"  => $callbackUrl,
            "callbackParams" => ["order_id" => $order->get_id()],
            "webhookUrl"     => $callbackUrl,
            "webhookParams"  => ["order_id" => $order->get_id()],
            "language"       => "fa",
            "currency"       => "USD",
            "sandBox"        => true
        ];

        $headers = [
            "x-api-key: $apiKey",
            "Content-Type: application/json"
        ];

        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));

        $response = curl_exec($ch);
        $httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);

        curl_close($ch);
        $responseData = json_decode($response, true);
        if (isset($responseData['paymentUrl'])) {
            if (!empty($responseData['paymentUrl'])) {
                $order->update_meta_data('_zibal_trackId', $response->trackId);
                echo json_encode([
                    'status' => true,
                    'url' => $responseData['paymentUrl']
                ]);
                return;
            }
            echo json_encode([
                'status' => false,
                'message' => $responseData['message'] ?? 'خطا در ایجاد پرداخت'
            ]);
            $order->update_status( 'failed', __( 'خطا در اتصال به درگاه payment4', 'giftmax' ) );
            $order->save();
            exit();
        }

        echo json_encode([
            'status' => false,
            'message' => 'درخواست پرداخت با شکست مواجه شد'
        ]);
        $order->update_status( 'failed', __( 'خطا در اتصال به درگاه payment4', 'giftmax' ) );
        $order->save();
    }
    public function payment4_verify_api_function(\WP_REST_Request $request)
    {
        $paymentUid  = $request->get_param('paymentUid');
        $order_id = $request->get_param('order_id');
        if (!$paymentUid || !$order_id) {
            header('Location:'.home_url());
            exit;
        }

        $order    = wc_get_order($order_id);
        if (!$order) {
            header('Location:'.home_url());
            exit;
        }

        $apiKey = get_option('woocommerce_payment4_settings')['api_key'];

        $url = "https://service.payment4.com/api/v1/payment/verify";
        $headers = [
            "x-api-key: $apiKey",
            "Content-Type: application/json"
        ];
        $payload = [
            "paymentUid" =>$paymentUid,
            "amount" => $order->get_total(),
            "currency" => "USD"
        ];

        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "PUT");
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));

        $response = curl_exec($ch);
        $httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        global $wpdb;
        $db = \Giftmax\Modules\Db::getLnstance();
        if ( null === WC()->session ) {
            WC()->initialize_session();
        }
        if ( null === WC()->customer ) {
            WC()->customer = new \WC_Customer( $order->get_user_id(), true );
        }
        if ( null === WC()->cart ) {
            WC()->cart = new \WC_Cart();
        }
        if ($httpcode != 200) {
            add_filter(
                'woocommerce_email_enabled_customer_completed_order',
                '__return_false'
            );

            try {
                $order->update_status('failed', 'پرداخت توسط کاربر لغو شد');

                $order->save();
            } catch (\Throwable $e) {
                error_log(
                    '[PAYMENT VERIFY API] Order completed but email failed: ' .
                    $e->getMessage()
                );
            }

            header('Content-Type: text/html; charset=utf-8');
            header("Refresh: 5; url=" . home_url());
            View::render("/inc/templates/template-parts/payment/fail.php");
            exit;
        }
        $res = json_decode($response, true);
        if ((!empty($res['paymentStatus']) && !empty($res['verified'])) || ($res['paymentStatus'] ?? '') == 'ACCEPTABLE' || ($res['paymentStatus'] ?? '') == 'SUCCESS'){
            $order->add_order_note('پرداخت موفق Payment4 - TrackID: ' . $paymentUid);
            add_filter(
                'woocommerce_email_enabled_customer_completed_order',
                '__return_false'
            );

            try {
                $order->update_status(
                    'completed',
                    'سفارش به صورت خودکار پس از پرداخت تکمیل شد'
                );
                $order->save();
            } catch (\Throwable $e) {
                error_log(
                    '[PAYMENT VERIFY API] Order completed but email failed: ' .
                    $e->getMessage()
                );
            }
            $user_id =  $order->get_user_id();
            $applied_coupons =  $order->get_meta( '_rial_coupon');
            if ( !empty( $applied_coupons ) ) {
                try {
                    $coupon = new \WC_Coupon($applied_coupons);
                    if (!$coupon->get_id()) {
                        $order->add_order_note('⚠️ کد تخفیف ' . $applied_coupons . ' در سیستم یافت نشد.');
                        throw new \Exception('Coupon not found.');
                    }

                    $usage_count = (int)$coupon->get_usage_count();
                    $coupon->set_usage_count($usage_count + 1);
                    $coupon->save();

                    $order->add_order_note(
                            sprintf(
                                    '✅ کد تخفیف "%s" با موفقیت در آمار ووکامرس ثبت شد. (استفاده %d)',
                                    $applied_coupons,
                                    $usage_count + 1
                            )
                    );

                    $order->save();

                    if (!in_array($applied_coupons, $order->get_coupon_codes())) {
                        $order->apply_coupon($applied_coupons);
                        $order->save();
                    }
                } catch (\Exception $e) {
                    $order->add_order_note('❌ خطا در ثبت کد تخفیف: ' . $e->getMessage());
                }
            }
            $total_points = $order->get_meta( '_total_cart_points', true );
            if ($total_points !=0){
                $points = $db->first( "SELECT * FROM {$wpdb->prefix}user_points WHERE user_id = :user_id", array('user_id'=>$user_id ));
                if (!empty($points)) {
                    $db->modify("UPDATE {$wpdb->prefix}user_points SET points=:points WHERE id=:id", array(
                                    'points'=> (int)$points['points'] + (int)$total_points,
                                    'id'=>$points['id']
                            )
                    );
                }else{
                    $db->insert("INSERT INTO `{$wpdb->prefix}user_points` (`id`, `user_id`, `points`) VALUES (NULL, :user_id, :points)",array(
                                    'user_id'=>$user_id,
                                    'points'=> (int)$total_points,
                            )
                    );
                    $points['id'] = $db->lastInsertId();
                }
                $db->insert("INSERT INTO `{$wpdb->prefix}wallet_transactions` (`id`, `user_id`,`method`, `method_id`, `amount`, `type`, `description`, `created_at`) VALUES (NULL, :user_id,'points', :method_id, :amount, 'credit', :description, :created_at)",array(
                                'user_id'=>$user_id,
                                'method_id'=>$points['id'],
                                'amount'=>$total_points,
                                'description'=>'دریافت امتیاز خرید',
                                'created_at'=>date('Y-m-d H:i:s')
                        )
                );
            }
            $hasIncompleteLicence = false;
            $incompleteProducts = [];
            foreach ($order->get_items() as $item_id => $item) {
                $reserved_licence_ids = [];
                $product_id = $item->get_product_id();
                $delivery   = get_post_meta( $product_id, 'delivery', true );
                $product = wc_get_product( $product_id );
                $product_name = $product->get_name();
                $product_permalink = $product->get_permalink();
                $product_img = get_the_post_thumbnail_url($product_id, 'product_discount');
                $manage_stock = get_post_meta($product_id, '_manage_stock', true);
                if ( isset( $delivery['two'] ) && $delivery['two'] === 'on'){
                    $delivery_time = isset( $delivery['time'] ) ? absint( $delivery['time'] ) : 0;
                    $dataLincesns = $order->get_date_created()
                            ? (clone $order->get_date_created())
                                    ->modify( '+'.$delivery_time.' hour' )
                                    ->date( 'Y/m/d H:i' )
                            : $delivery_time;
                    $dataLincesns = gjdate($dataLincesns,"d M Y، H:i");
                    $body = '<div class="flex justify-between"> <div> محصول <a href="'.$product_permalink.'" target="_blank">'.$product_name.'</a> در سبد خرید شما به صورت <span class="pre-sale__span">پیش فروش</span> می‌باشد و تا '.$delivery_time.' ساعت آینده لایسنس آن تحویل شما داده می‌شود. </div> <div class="flex gap-2 s2ged"> <img class="w-[87px]" src="'.$product_img.'" alt="'.$product_name.'"> <div class="c-badge rounded-sm badge-orange text-2xs -mt-1 flex flex-col"> <div>تا '.$dataLincesns.'</div> <div>لایسنس موجود میشود</div> </div> </div> </div>';
                    $db->insert("INSERT INTO `{$wpdb->prefix}notifications` (`userId`,`body`,`title`,`status`,`is_active`,`created_at`) VALUES (:user_id,:body,:title,'show',1,NOW())", array(
                            'user_id' => $user_id,
                            'title' => 'محصول پیش فروش در سبد خرید',
                            'body' => $body
                    ));
                    UserModel::alert($user_id,$db->lastInsertId());
                }else{
                    $manage_stock = get_post_meta($product_id, '_manage_stock', true);
                    if ($manage_stock == 'yes') {
                        $count = $db->first("SELECT COUNT(*) AS total FROM `{$wpdb->prefix}product_licences` WHERE product_id = :product_id AND licence_status = 'available'",array('product_id'=>$product_id))['total'];
                        update_post_meta($product_id, '_stock', $count);
                        if($count >=1) {
                            update_post_meta($product_id, '_stock_status', 'instock');
                        }
                    }
                }
                $is_preorder = (
                        isset($delivery['two']) &&
                        $delivery['two'] === 'on'
                );

                if ($is_preorder) {
                    continue;
                }

                $requested = (int)$item['quantity'];

                try {

                    $db->query("START TRANSACTION");

                    $licences = $db->query(" SELECT licence_id FROM {$wpdb->prefix}product_licences WHERE product_id = :product_id AND licence_status='available' ORDER BY sort_order ASC LIMIT {$requested} FOR UPDATE ",[
                            'product_id'=>$product->get_id()
                    ]);

                    foreach ($licences as $licence){
                        $reserved_licence_ids[] = $licence['licence_id'];
                        $db->modify(" UPDATE {$wpdb->prefix}product_licences SET licence_status='assigned', assigned_at=:assigned_at, order_id=:order_id WHERE licence_id=:licence_id ",[
                                'assigned_at'=>current_time('mysql'),
                                'order_id'=>$order_id,
                                'licence_id'=>$licence['licence_id']
                        ]);
                    }

                    $db->query("COMMIT");

                    if(count($licences) < $requested){

                        $hasIncompleteLicence = true;

                        $incompleteProducts[] = [
                                'product'   => $product->get_name(),
                                'requested' => $requested,
                                'assigned'  => count($licences)
                        ];
                    }

                }catch(Exception $e){

                    $db->query("ROLLBACK");
                    throw $e;

                }
                if (!empty($reserved_licence_ids) && is_array($reserved_licence_ids)) {
                    $item->update_meta_data(
                            '_reserved_licence_ids',
                            json_encode($reserved_licence_ids)
                    );
                    $item->save();
                }
            }
            if($hasIncompleteLicence){

                $order->update_meta_data('_giftmax_incomplete_licence', 1);
                $order->update_meta_data('_giftmax_incomplete_products', $incompleteProducts);
                $order->save();
                $note = "کمبود لایسنس:\n";

                foreach($incompleteProducts as $row){

                    $missing = $row['requested'] - $row['assigned'];

                    $note .= "{$row['product']} : {$row['assigned']} تحویل شد، {$missing} عدد موجود نبود.\n";
                }

                $order->add_order_note($note);
            }
            $paid_date = $order->get_date_paid();
            $paid_date_fa = $paid_date ? wp_date('Y-m-d H:i', $paid_date->getTimestamp()) : '-';
            self::suspiciousOrder($order);
            header('Content-Type: text/html; charset=utf-8');
            header("Refresh: 3; url=" . home_url('/profile/invoices/'  . $order_id));
            View::render("/inc/templates/template-parts/payment/success.php", ['gateway' => 'Payment4', 'paid_date_fa' => $paid_date_fa, 'order_number' => $order->get_order_number(), 'amount' => $order->get_total()]);
            exit;
        }
        elseif ($response && $response->result == 201){
            header('Content-Type: text/html; charset=utf-8');
            header("Refresh: 3; url=" . home_url('/profile/invoices/'  . $order_id));
            View::render("/inc/templates/template-parts/payment/verifed.php", ['gateway'=>'Payment4']);
            exit;
        }
    }
    private function verify_cart($userID,$card_number):bool{
        $token = 'd5497c98fc9a28300406dd8ee66bac5b531fc598';
        $user = UserModel::table('user_identity','user_id',$userID);
        if(UserModel::setting("check_card_with_national_code_zohal") === true) {
            $result = v1::callZohalService(
                'https://service.zohal.io/api/v0/services/inquiry/check_card_with_national_code',
                [
                    'birth_date' => fa_to_en_numbers(decrypt_data($user['birth_date_enc'])),
                    'card_number' => $_POST['value'],
                    'national_code' => fa_to_en_numbers(decrypt_data($user['national_id_enc']))
                ],
                $token
            );

        }elseif(UserModel::setting("check_card_with_national_code_jibit") === true) {
            $jbt = Jibit::getLnstance();
            $endpoint = '/services/matching';
            $birthDate = fa_to_en_numbers(decrypt_data($user['birth_date_enc']));
            $res =  $jbt->api_request('GET', $endpoint, [
                    'cardNumber' =>  $_POST['value'],
                    'nationalCode' => fa_to_en_numbers(decrypt_data($user['national_id_enc'])),
                    'birthDate' => str_replace('/','',$birthDate),
            ], null, true);
            if ($res['code'] == 200){
                $result['status'] = true;
            }else{
                $result['status'] = false;
            }
        }else{
            $result['status'] = false;
        }
        if ($result['status'] === true) {
            global $wpdb;
            $db = Db::getLnstance();
            $db->insert("INSERT INTO `{$wpdb->prefix}user_bank_cards` (`user_id`, `card_number_enc`, `card_last4`, `is_default`, `is_active`,`ip`,`created_at`) VALUES (:user_id, :card_number, :card_last4, :is_default, :is_active,:ip,:created_at) ON DUPLICATE KEY UPDATE card_number_enc = VALUES(card_number_enc), card_last4 = VALUES(card_last4), is_default = VALUES(is_default), is_active = VALUES(is_active)",array(
                'user_id'     => $userID,
                'card_number' => encrypt_data($card_number),
                'card_last4'  => substr($card_number, -4),
                'ip'  => encrypt_data(giftmax_get_user_ip()),
                'is_default'  => 0,
                'is_active'   => 1,
                'created_at'   => date('Y-m-d H:i:s'),
            ));
            return true;
        }else{
            return false;
        }
    }
    private function extractCardDigits($maskedCardNumber) {
        $maskedCardNumber = preg_replace('/[\s-]/', '', $maskedCardNumber);

        if (preg_match('/^(\d+)\*+(\d+)$/', $maskedCardNumber, $matches)) {
            return [
                'prefix' => $matches[1],  // ارقام اول
                'suffix' => $matches[2],  // ارقام آخر
                'prefix_length' => strlen($matches[1]),
                'suffix_length' => strlen($matches[2])
            ];
        }

        if (preg_match('/^\*+(\d+)$/', $maskedCardNumber, $matches)) {
            return [
                'prefix' => '',
                'suffix' => $matches[1],
                'prefix_length' => 0,
                'suffix_length' => strlen($matches[1])
            ];
        }

        if (preg_match('/^(\d+)\*+$/', $maskedCardNumber, $matches)) {
            return [
                'prefix' => $matches[1],
                'suffix' => '',
                'prefix_length' => strlen($matches[1]),
                'suffix_length' => 0
            ];
        }

        return null;
    }
    private function verify_result_ok($order,$numberCartInPay,$order_id,$gateway)
    {
        global $wpdb;
        $db = Db::getLnstance();
        $user_id = $order->get_user_id();
        $user = UserModel::table('user_identity', 'user_id', $user_id);
        $verify = false;
        $is_exist = 0;
        $numberCart = null;
        if (isset($user['account_type']) && $user['account_type'] === 'vip') {
            $verify = true;
        } elseif ($extracted = $this->extractCardDigits($numberCartInPay)) {
            global $wpdb;
            $db = Db::getLnstance();

            $cards = $db->query(
                "SELECT card_number_enc, phone FROM `{$wpdb->prefix}user_bank_cards` WHERE `user_id` = :user_id AND `is_active` = 1",
                ['user_id' => $user_id]
            );
            $matchedCard = null;

            foreach ($cards as $record) {
                $fullCardNumber = decrypt_data($record['card_number_enc']);

                $prefix_match = ($extracted['prefix_length'] === 0 ||
                    strncmp($fullCardNumber, $extracted['prefix'], $extracted['prefix_length']) === 0);

                $suffix_match = ($extracted['suffix_length'] === 0 ||
                    substr_compare($fullCardNumber, $extracted['suffix'], -$extracted['suffix_length'], $extracted['suffix_length']) === 0);

                if ($prefix_match && $suffix_match) {
                    $matchedCard = $fullCardNumber;

                    if (empty($record['phone'])) {
                        $is_exist = 0;
                        $verify = true;
                    } else {
                        $is_exist = 1;
                        $verify = false;
                    }
                    break;
                }
            }

            $numberCart = $matchedCard ?? $numberCartInPay;
        }
            try {
                $order->update_meta_data('_card_pay', $numberCart);
                $order->update_status(
                    'completed',
                    'سفارش به صورت خودکار پس از پرداخت تکمیل شد'
                );
                $order->save();
            } catch (\Throwable $e) {
                error_log(
                    '[PAYMENT VERIFY API] Order completed but email failed: ' .
                    $e->getMessage()
                );
            }
        if (!$verify) {
            try {
                $order->update_status('card-not-verified', 'تایید نشدن کارت');
                $order->update_meta_data('_is_exist', $is_exist);
                $order->save();
            } catch (\Throwable $e) {
                error_log('[PAYMENT VERIFY API] Card verification failed but status update failed: ' . $e->getMessage());
            }
        }
        $applied_coupons =  $order->get_meta( '_rial_coupon');
        if ( !empty( $applied_coupons ) ) {
            try {
	                $coupon = new \WC_Coupon($applied_coupons);
	                    if (!$coupon->get_id()) {
	                        $order->add_order_note('⚠️ کد تخفیف ' . $applied_coupons . ' در سیستم یافت نشد.');
	                        throw new \Exception('Coupon not found.');
	                    }

                    $usage_count = (int)$coupon->get_usage_count();
                    $coupon->set_usage_count($usage_count + 1);
                    $coupon->save();

                    $order->add_order_note(
                        sprintf(
                            '✅ کد تخفیف "%s" با موفقیت در آمار ووکامرس ثبت شد. (استفاده %d)',
                            $applied_coupons,
                            $usage_count + 1
                        )
                    );

                    $order->save();

                    if (!in_array($applied_coupons, $order->get_coupon_codes())) {
                        $order->apply_coupon($applied_coupons);
                        $order->save();
                    }
            } catch (\Exception $e) {
                $order->add_order_note('❌ خطا در ثبت کد تخفیف: ' . $e->getMessage());
            }
        }
        $use_wallet = $order->get_meta( '_use_wallet', true );
        if ($use_wallet) {
            $discount = $order->get_meta( '_wallet_discount', true );
            $wallet = $db->first( "SELECT * FROM {$wpdb->prefix}wallet WHERE user_id = :user_id", array('user_id'=>$user_id ));
            $discount = abs($discount);
            $wallet_bal = $wallet['balance'];
	            if ($wallet_bal > 0) {
	                $new_balance = $wallet_bal - $discount;
	                $new_balance = max(0.0, $new_balance);
	                $db->query('START TRANSACTION');
	                $db->modify("UPDATE {$wpdb->prefix}wallet SET balance=:balance WHERE id=:id", array(
	                        'balance' => $new_balance,
	                        'id' => $wallet['id']
	                    )
	                );
	                $db->insert("INSERT INTO `{$wpdb->prefix}wallet_transactions` (`id`, `user_id`,`method`, `method_id`, `amount`, `type`, `description`, `created_at`) VALUES (NULL, :user_id,'wallet', :method_id, :amount, 'debit', :description, :created_at)", array(
	                        'user_id' => $user_id,
	                        'method_id' => $wallet['id'],
	                        'amount' => $discount,
	                        'description' => 'کسری از قیمت سبد خرید',
	                        'created_at' => date('Y-m-d H:i:s')
	                    )
	                );
	                $db->query( 'COMMIT' );
	            }
	        }
        $total_points = $order->get_meta( '_total_cart_points', true );
        if ($total_points !=0){
            $points = $db->first( "SELECT * FROM {$wpdb->prefix}user_points WHERE user_id = :user_id", array('user_id'=>$user_id ));
            if (!empty($points)) {
                $db->modify("UPDATE {$wpdb->prefix}user_points SET points=:points WHERE id=:id", array(
                        'points'=> (int)$points['points'] + (int)$total_points,
                        'id'=>$points['id']
                    )
                );
            }else{
                $db->insert("INSERT INTO `{$wpdb->prefix}user_points` (`id`, `user_id`, `points`) VALUES (NULL, :user_id, :points)",array(
                        'user_id'=>$user_id,
                        'points'=> (int)$total_points,
                    )
                );
                $points['id'] = $db->lastInsertId();
            }
            $db->insert("INSERT INTO `{$wpdb->prefix}wallet_transactions` (`id`, `user_id`,`method`, `method_id`, `amount`, `type`, `description`, `created_at`) VALUES (NULL, :user_id,'points', :method_id, :amount, 'credit', :description, :created_at)",array(
                    'user_id'=>$user_id,
                    'method_id'=>$points['id'],
                    'amount'=>$total_points,
                    'description'=>'دریافت امتیاز خرید',
                    'created_at'=>date('Y-m-d H:i:s')
                )
            );
        }
        $hasIncompleteLicence = false;
        $incompleteProducts = [];
        foreach ($order->get_items() as $item_id => $item) {
            $reserved_licence_ids = [];
            $product_id = $item->get_product_id();
            $delivery   = get_post_meta( $product_id, 'delivery', true );
            $product = wc_get_product( $product_id );
            $product_name = $product->get_name();
            $product_permalink = $product->get_permalink();
            $product_img = get_the_post_thumbnail_url($product_id, 'product_discount');
            $is_preorder = (isset($delivery['two']) && $delivery['two'] === 'on');

            if ( $is_preorder){
                $delivery_time = isset( $delivery['time'] ) ? absint( $delivery['time'] ) : 0;
                $dataLincesns = $order->get_date_created()
                    ? (clone $order->get_date_created())
                        ->modify( '+'.$delivery_time.' hour' )
                        ->date( 'Y/m/d H:i' )
                    : $delivery_time;
                $dataLincesns = gjdate($dataLincesns,"d M Y، H:i");
                $body = '<div class="flex justify-between"> <div> محصول <a href="'.$product_permalink.'" target="_blank">'.$product_name.'</a> در سبد خرید شما به صورت <span class="pre-sale__span">پیش فروش</span> می‌باشد و تا '.$delivery_time.' ساعت آینده لایسنس آن تحویل شما داده می‌شود. </div> <div class="flex gap-2 s2ged"> <img class="w-[87px]" src="'.$product_img.'" alt="'.$product_name.'"> <div class="c-badge rounded-sm badge-orange text-2xs -mt-1 flex flex-col"> <div>تا '.$dataLincesns.'</div> <div>لایسنس موجود میشود</div> </div> </div> </div>';
                $db->insert("INSERT INTO `{$wpdb->prefix}notifications` (`userId`,`body`,`title`,`status`,`is_active`,`created_at`) VALUES (:user_id,:body,:title,'show',1,NOW())", array(
                    'user_id' => $user_id,
                    'title' => 'محصول پیش فروش در سبد خرید',
                    'body' => $body
                ));
                UserModel::alert($user_id,$db->lastInsertId());
            }else{
                $manage_stock = get_post_meta($product_id, '_manage_stock', true);
                if ($manage_stock == 'yes') {
                    $count = $db->first("SELECT COUNT(*) AS total FROM `{$wpdb->prefix}product_licences` WHERE product_id = :product_id AND licence_status = 'available'",array('product_id'=>$product_id))['total'];
                    update_post_meta($product_id, '_stock', $count);
                    if($count >=1) {
                        update_post_meta($product_id, '_stock_status', 'instock');
                    }
                }
            }


                if ($is_preorder) {
                    continue;
                }

                $requested = (int)$item['quantity'];

                try {

                    $db->query("START TRANSACTION");

                    $licences = $db->query(" SELECT licence_id FROM {$wpdb->prefix}product_licences WHERE product_id = :product_id AND licence_status='available' ORDER BY sort_order ASC LIMIT {$requested} FOR UPDATE ",[
                            'product_id'=>$product->get_id()
                    ]);

                    foreach ($licences as $licence){
                        $reserved_licence_ids[] = $licence['licence_id'];
                        $db->modify(" UPDATE {$wpdb->prefix}product_licences SET licence_status='assigned', assigned_at=:assigned_at, order_id=:order_id WHERE licence_id=:licence_id ",[
                                'assigned_at'=>current_time('mysql'),
                                'order_id'=>$order_id,
                                'licence_id'=>$licence['licence_id']
                        ]);
                    }

                    $db->query("COMMIT");

                    if(count($licences) < $requested){

                        $hasIncompleteLicence = true;

                        $incompleteProducts[] = [
                                'product'   => $product->get_name(),
                                'requested' => $requested,
                                'assigned'  => count($licences)
                        ];
                    }

                }catch(Exception $e){

                    $db->query("ROLLBACK");
                    throw $e;

                }

            if (!empty($reserved_licence_ids) && is_array($reserved_licence_ids)) {
                $item->update_meta_data(
                        '_reserved_licence_ids',
                        json_encode($reserved_licence_ids)
                );
                $item->save();
            }
        }
        if($hasIncompleteLicence){

            $order->update_meta_data('_giftmax_incomplete_licence', 1);
            $order->update_meta_data('_giftmax_incomplete_products', $incompleteProducts);
            $order->save();
            $note = "کمبود لایسنس:\n";

            foreach($incompleteProducts as $row){

                $missing = $row['requested'] - $row['assigned'];

                $note .= "{$row['product']} : {$row['assigned']} تحویل شد، {$missing} عدد موجود نبود.\n";
            }

            $order->add_order_note($note);
        }
        $paid_date = $order->get_date_paid();
        $paid_date_fa = $paid_date ? wp_date('Y-m-d H:i', $paid_date->getTimestamp()) : '-';
        self::suspiciousOrder($order);
        header("Refresh: 5; url=" . home_url('/profile/invoices/'  . $order_id));
        header('Content-Type: text/html; charset=utf-8');
        View::render("/inc/templates/template-parts/payment/success.php", ['gateway' => $gateway, 'paid_date_fa' => $paid_date_fa, 'order_number' => $order->get_order_number(), 'amount' => $order->get_total()]);
    }
    private function findUtf16Index($text, $search)
    {
        // تبدیل متن به UTF-16LE
        $utf16Text = mb_convert_encoding($text, 'UTF-16LE', 'UTF-8');
        $utf16Search = mb_convert_encoding($search, 'UTF-16LE', 'UTF-8');

        $textLength = strlen($utf16Text);
        $searchLength = strlen($utf16Search);

        $position = 0;
        while ($position <= $textLength - $searchLength) {
            $found = true;
            for ($i = 0; $i < $searchLength; $i++) {
                if ($utf16Text[$position + $i] !== $utf16Search[$i]) {
                    $found = false;
                    break;
                }
            }

            if ($found) {
                // ایندکس بر اساس تعداد کاراکترهای UTF-16
                return $position / 2;
            }
            $position++;
        }

        return null;
    }
    function payment__verify_api_function(\WP_REST_Request $request)
    {
        $trackId  = $request->get_param('trackId');
        $success  = $request->get_param('success');
        $order_id = $request->get_param('order_id');
        if (!$trackId || !$order_id) {
            header('Location:'.home_url());
            exit;
        }

        $order = wc_get_order($order_id);

        if (!$order) {
            wp_safe_redirect(home_url());
            exit;
        }
        $zibal_trackId = $order->get_meta('_zibal_trackId');
        if($trackId != $zibal_trackId){
            wp_safe_redirect(home_url());
            exit;
        }
        if ( null === WC()->session ) {
            WC()->initialize_session();
        }
        if ( null === WC()->customer ) {
            WC()->customer = new \WC_Customer( $order->get_user_id(), true );
        }
        if ( null === WC()->cart ) {
            WC()->cart = new \WC_Cart();
        }
        if ((int)$success !== 1) {
            add_filter(
                'woocommerce_email_enabled_customer_completed_order',
                '__return_false'
            );

            try {
                $order->update_status('failed', 'پرداخت توسط کاربر لغو شد');

                $order->save();
            } catch (\Throwable $e) {
                error_log(
                    '[PAYMENT VERIFY API] Order completed but email failed: ' .
                    $e->getMessage()
                );
            }
            header('Content-Type: text/html; charset=utf-8');
            View::render("/inc/templates/template-parts/payment/fail.php");
            exit;
        }
        $zibal = get_option('woocommerce_zibal_settings');
        $apiKey = $zibal['api_key'];
        $response = $this->postToZibal('verify', [
            'merchant' => $apiKey,
            'trackId'  => $trackId,
        ]);
        if ($response && $response->result == 100) {
            $order->add_order_note('پرداخت موفق زیبال - TrackID: ' . $trackId);
            add_filter(
                'woocommerce_email_enabled_customer_completed_order',
                '__return_false'
            );
            self::verify_result_ok($order,$response->cardNumber,$order_id,'زیبال');
        }
        elseif ($response && $response->result == 201){
            header("Refresh: 3; url=" . home_url('/profile/invoices/'  . $order_id));
            header('Content-Type: text/html; charset=utf-8');
            View::render("/inc/templates/template-parts/payment/verifed.php", ['gateway'=>'زیبال']);
            exit;
        }
    }
    function paystar_verify_api_function()
    {
        $status        = $_POST['status'];
        $ref_num       = $_POST['ref_num'];
        $order_id      = $_POST['order_id'];
        if (!isset($_POST['ref_num']) || !isset($_POST['order_id'])) {
            wp_redirect(home_url());
            exit;
        }

        $order = wc_get_order($order_id);
        if (!$order) {
            wp_redirect(home_url());
            exit;
        }
        $paystar_ref_num = $order->get_meta('_paystar_ref_num');
        if($ref_num != $paystar_ref_num){
            wp_safe_redirect(home_url());
            exit;
        }

        if (null === WC()->session) {
            WC()->initialize_session();
        }
        if (null === WC()->customer) {
            WC()->customer = new \WC_Customer($order->get_user_id(), true);
        }
        if (null === WC()->cart) {
            WC()->cart = new \WC_Cart();
        }

        if ($status !== 1) {
            $order->update_status('failed', 'پرداخت توسط کاربر لغو شد');
            $order->update_meta_data('_check_payment',true);
            $order->save();
            header("Refresh: 3; url=" . home_url());
            header('Content-Type: text/html; charset=utf-8');
            View::render("/inc/templates/template-parts/payment/fail.php");
            exit;
        }
        if ($order->get_meta('_check_payment')){
            header("Refresh: 3; url=" . home_url('/profile/invoices/'  . $order_id));
            header('Content-Type: text/html; charset=utf-8');
            View::render("/inc/templates/template-parts/payment/verifed.php", ['gateway'=>'پی استار']);
            exit();
        }
        $paystar = get_option('woocommerce_paystar_settings');
        $sign_key = $paystar['sign'];
        $gateway_id = $paystar['gateway_id'];

        if (empty( $gateway_id ) || empty( $sign_key )) {
            $order->update_status('failed', 'تنظیمات PayStar به‌طور کامل تنظیم نشده‌اند.');
            exit;
        }
        $card_number   = $_POST['card_number'];
        $tracking_code = $_POST['tracking_code'];
        $amount        = $order->get_meta("payment_amount");
        $sign_data = $amount . '#' . $ref_num . '#' . $card_number . '#' . $tracking_code;
        $sign      = hash_hmac( 'sha512', $sign_data, $sign_key );

        $body_params = [
                'amount'  => $amount,
                'ref_num' => $ref_num,
                'sign'    => $sign,
        ];
        $body_json = wp_json_encode( $body_params );

        $response = wp_remote_post(
                'https://core.paystar.ir/api/pardakht/verify',
                [
                        'headers' => [
                                'Accept'        => 'application/json',
                                'Content-Type'  => 'application/json',
                                'Authorization' => 'Bearer ' . $gateway_id,
                        ],
                        'body'    => $body_json,
                        'timeout' => 30,
                ]
        );

        if ( is_wp_error( $response ) ) {
            error_log( 'PayStar Verify – WP Error: ' . $response->get_error_message() );
            $order->update_status( 'failed', 'خطا در ارتباط با پی‌استار' );
            $order->save();
            return false;
        }

        $body   = wp_remote_retrieve_body( $response );
        $result = json_decode( $body, true );

        if ( json_last_error() !== JSON_ERROR_NONE ) {
            error_log( 'PayStar Verify – JSON decode error: ' . json_last_error_msg() );
            return false;
        }

        $code = wp_remote_retrieve_response_code( $response );
        if ( $code !== 200 ) {
            error_log( "PayStar Verify – HTTP Code: {$code}" );
            wp_redirect(home_url());
            return false;
        }

        if (isset($result['data']['ref_num'])) {
            $order->payment_complete($result['data']['ref_num'] ?? $tracking_code);
            $order->add_order_note('پرداخت موفق پی استار - Ref: ' . ($result['data']['ref_num'] ?? '-'));
            $order->update_meta_data('_check_payment',true);
            $order->save();
            add_filter(
                'woocommerce_email_enabled_customer_completed_order',
                '__return_false'
            );
            self::verify_result_ok($order,$result['data']['card_number'],$order_id,'پی استار');
        }
        $order->update_status('failed', 'تراکنش توسط پی استار تایید نشد');

        header('Content-Type: text/html; charset=utf-8');
        header("Refresh: 5; url=" . home_url());
        View::render("/inc/templates/template-parts/payment/fail.php");
        exit;
    }
    public function update_cart_qty_api_function() {
        if (is_user_blocked()) {
            return wp_send_json_error( [ 'message' => 'شما بلاک شده اید' ] );
        }
        if(UserModel::setting("buy") === false){
            return wp_send_json_error( [ 'message' => 'خرید از سایت فعلا غیر فعال میباشد' ] );
        }
        if ( null === WC()->session )      WC()->initialize_session();
        if ( null === WC()->customer )     WC()->customer = new \WC_Customer( get_current_user_id(), true );
        if ( null === WC()->cart )         WC()->cart = new \WC_Cart();
        WC()->cart->get_cart();
        WC()->cart->calculate_totals();

        $cart_item_key = sanitize_text_field( $_POST['cart_item_key'] ?? '' );
        $cart_item_keySend = $cart_item_key ;
        $quantity      = max( 0, intval( $_POST['quantity'] ?? 1 ) ); // min 1
        $quantityNew = $quantity;
        if ( empty( $cart_item_key ) ) {
            return wp_send_json_error( [ 'message' => 'محصول یافت نشد' ] );
        }

        $cart_item = WC()->cart->get_cart_item( $cart_item_key );
        if ( ! $cart_item ) {
            return wp_send_json_error( [ 'message' => 'محصول در سبد خرید وجود ندارد' ] );
        }
        $product_id=$cart_item['product_id'];
        $current_qty = $cart_item['quantity'];
        $delta       = $quantity - $current_qty;

        $delivery = get_post_meta($cart_item['product_id'], 'delivery', true);
        $item_removed = false;
        if (isset($delivery['one']) && $delivery['one'] == 'on') {
            global $wpdb;
            $db   = Db::getLnstance();

            if ( $delta > 0 ) {
                $free_licences = $db->query("SELECT COUNT(*) AS total FROM {$wpdb->prefix}product_licences WHERE product_id = :product_id AND licence_status = 'available' ORDER BY sort_order ASC",
                    array(
                        'product_id' => $cart_item['product_id'],
                    )
                );
                if (!$free_licences){
                    return \wp_send_json_error( [ 'message' =>"لایسنس فعالی وجود ندارد"] );
                }
                if ( $free_licences[0]['total'] < $quantity ) {
                    return \wp_send_json_error( [ 'message' => 'این تعداد لایسنس در حال حاضر موجود نیست' ] );
                }
            }
            if ( $quantity <= 0 ) {
                WC()->cart->remove_cart_item( $cart_item_key );
                $item_removed = true;
            }
        }else{
            if ($quantity <= 0) {
                WC()->cart->remove_cart_item( $cart_item_key );
                $item_removed = true;
            }
        }

        WC()->cart->set_quantity( $cart_item_key, $quantity );
        WC()->cart->calculate_totals();
        $cart_product_discount = 0;
        $cart_items = [];
        $total      = 0; // نهایی
        foreach (WC()->cart->get_cart() as $cart_item) {
            $product = $cart_item['data'];
            if ($cart_item['product_id'] == $product_id){
                $price_original_total = (float) $product->get_regular_price() * $quantity;
                $price_final_total    = $cart_item['line_total'];
            }
            $qty = (int)$cart_item['quantity'];
            $regular_price = (float)$product->get_regular_price();
            $line_total = $cart_item['line_total'];

            $cart_product_discount += ($regular_price * $qty) - $line_total;
            $total    += $line_total;

            $cart_items[] = [
                'product_id'      => $cart_item['product_id'],
                'name'            => $product->get_name(),
                'url'             => get_permalink($cart_item['product_id']),
                'qty'             => $cart_item['quantity'],
                'price_regular'   => number_format_usd($regular_price * (int)  $cart_item['quantity']),
                'price_sale'      => number_format_usd($cart_item['line_total']),
                'image'           => $product->get_image_id()
                    ? wp_get_attachment_image_url($product->get_image_id(),'product_discount')
                    : wc_placeholder_img_src(),
            ];
        }

        $coupon_discount_total = WC()->cart->get_discount_total();
        $total_discount = $cart_product_discount + $coupon_discount_total;
        $is_cart_empty = WC()->cart->is_empty();
        if ($is_cart_empty) {
            WC()->cart->empty_cart(true);
            WC()->session->set('cart_created_time', null);
            WC()->session->set('rial_coupon', null);
            WC()->session->set('wallet_dirty', null);
            WC()->session->set('use_wallet', null);
            WC()->cart->remove_coupons();
            WC()->session->set_customer_session_cookie(true);
        }
        $total_points = 0;

        foreach ( WC()->cart->get_cart() as $cart_item_key => $cart_item ) {

            $product  = $cart_item['data'];
            $quantity = $cart_item['quantity'];

            $settings = get_post_meta($product->get_id(), 'giftmax_box_setting', true);

            $item_points = empty($settings[0]['purchaseScore']) ? 0 : $settings[0]['purchaseScore'];

            $line_points = $item_points * $quantity;

            WC()->cart->cart_contents[ $cart_item_key ]['points'] = $line_points;

            $total_points += $line_points;
        }

        WC()->session->set( 'total_cart_points', $total_points );
        return \wp_send_json_success([
            'message'       => $item_removed
                ? ( $is_cart_empty ? 'سبد خرید خالی شد' : 'محصول حذف شد' )
                : 'سبد خرید بروزرسانی شد',

            'action'        => $item_removed
                ? ( $is_cart_empty ? 'cart_empty' : 'item_removed' )
                : 'qty_updated',
            'cart_item_key' => $cart_item_keySend,
            'new_quantity'  => $quantityNew,
            'total_points'  => $total_points,
            'item' => [
                'final_total'    => number_format_usd($price_final_total),
                'original_total' => $price_original_total > $price_final_total
                    ? number_format_usd($price_original_total)
                    : null
            ],
            'mini' => [
                'items_count' => WC()->cart->get_cart_contents_count(),
                'subtotal'    => number_format_usd(WC()->cart->get_subtotal()+$cart_product_discount),
                'discount'    => number_format_usd($cart_product_discount),
                'total'       => number_format_usd($total),
                'totalUSD'       => ($total),
                'items'       => $cart_items
            ],
            'cart' => [
                'subtotal'=> $_POST['gateway'] == 'r' ? number_format_usd(WC()->cart->get_subtotal()) : number_format(WC()->cart->get_subtotal()),
                'total'=> $_POST['gateway'] == 'r' ? number_format_usd(WC()->cart->get_total('edit')) : WC()->cart->get_total('edit'),
                'discount'=> $_POST['gateway'] == 'r' ? number_format_usd($total_discount) : number_format($total_discount)
            ]
        ] );
    }
    public function posts_api_function(){
        $category = $_POST['category'];
        ob_start();
        $posts_per_page = 6;
        $orderby        = 'date';
        $order          = 'DESC';
        $args   = [
            'posts_per_page'=> $posts_per_page,
            'orderby'       => $orderby,
            'order'         => $order,
            'no_found_rows' => true,
        ];
        if(!empty( $_POST['category'])){
            $category_slug  = $category;
            $cat_obj = get_category_by_slug( $category_slug );
            $cat_id  = ( $cat_obj ) ? $cat_obj->term_id : 0;
            $args['category'] = $cat_id;
            $linkCat = get_category_link($cat_obj);
            $nameEnCat = giftmax_get_term_english_name($cat_obj);
            $nameCat = $cat_obj->name;
        }else{
            $nameCat = "همه";
            $nameEnCat = "All";
            $linkCat = home_url('/blogs');
        }
        $posts  = get_posts( $args );

        if ( ! empty( $posts ) ) {
            if (!empty($posts[0]->ID) || !empty($posts[1]->ID)){
                $Post_right = array(
                    empty($posts[0]->ID) ? 'no' : $posts[0]->ID,
                    empty($posts[1]->ID) ? 'no' : $posts[1]->ID
                )
                ?>
                <div class="act-blogs-first-box">
                    <?php
                    foreach ($Post_right as $item){
                        if ($item == 'no'){
                            continue;
                        }
                        ?>
                        <div class="act-blog-first-card">
                            <a href="<?=get_permalink($item)?>" class="act-blog-card">
                                <div class="act-blog-card-inner">
                                    <div class="act-blog-card-img-box">
                                        <img decoding="async" src="<?=get_the_post_thumbnail_url($item)?>" alt="">
                                        <span class="act-blog-card-img-box-label"><?=get_the_category($item)[0]->name?></span></div>
                                    <div class="act-blog-card-content">
                                        <h4 class="act-product-title"><?=get_the_title($item)?></h4>
                                        <div class="act-blog-card-text"><?=get_the_excerpt($item)?></div>
                                        <div class="act-blog-card-footer">
                                            <div class="act-blog-card-footer-read-time"><div class="flex align-items-center ml-1"><i class="icon-eye"></i><p><?= view_giftmax($item)?></p></div><div class="flex align-items-center"><i class="icon-user"></i><?=giftmax_get_author_full_name(get_post_author_id($item))?></div><div class="flex align-items-center blog_clock-view"><i class="icon-clock"></i><?=gjdate(get_the_date('Y-m-d',$item),"d M Y")?></div></div>
                                            <div class="act-blog-card-link">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="26" height="26" viewBox="0 0 26 26" fill="currentcolor">
                                                    <path d="M15.0559 8.6175C14.9551 8.71827 14.8173 8.78191 14.6582 8.78191L8.7821 8.78191L8.7821 14.658C8.7821 14.9656 8.52755 15.2201 8.21996 15.2201C7.91236 15.2201 7.6578 14.9656 7.6578 14.658L7.6578 8.21976C7.6578 7.91216 7.91236 7.65761 8.21995 7.65761L14.6582 7.65761C14.9658 7.65761 15.2203 7.91216 15.2203 8.21976C15.2256 8.37355 15.1567 8.51674 15.0559 8.6175Z"></path>
                                                    <path d="M17.6333 17.6332C17.4159 17.8506 17.0553 17.8506 16.8379 17.6332L7.9124 8.7077C7.69496 8.49027 7.69496 8.12964 7.9124 7.91221C8.12983 7.69477 8.49046 7.69477 8.70789 7.91221L17.6333 16.8377C17.8508 17.0551 17.8508 17.4157 17.6333 17.6332Z"></path>
                                                </svg>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <?php
                    }
                    ?>
                </div>
                <?php
            }
            if (!empty($posts[2]->ID)){
                ?>
                <a href="<?=get_permalink($posts[2]->ID)?>" class="act-blog-card fDjf5">
                    <div class="act-blog-card-inner">
                        <div class="act-blog-card-img-box">
                            <img decoding="async" src="<?=get_the_post_thumbnail_url($posts[2]->ID)?>" alt="">
                            <span class="act-blog-card-img-box-label"><?=get_the_category($posts[2]->ID)[0]->name?></span>
                        </div>
                        <div class="act-blog-card-content">
                            <h4 class="act-product-title"><?=get_the_title($posts[2]->ID)?></h4>
                            <div class="act-blog-card-text"><?=get_the_excerpt($posts[2]->ID)?></div>
                        </div>
                        <div class="act-blog-card-footer">
                            <div class="act-blog-card-footer-read-time"><div class="flex align-items-center ml-1"><i class="icon-eye"></i><p><?= view_giftmax($posts[2]->ID)?></p></div><div class="flex align-items-center"><i class="icon-user"></i><?=giftmax_get_author_full_name(get_post_author_id($posts[2]->ID))?></div><div class="flex align-items-center blog_clock-view"><i class="icon-clock"></i><?=gjdate(get_the_date('Y-m-d',$posts[2]->ID),"d M Y")?></div></div>
                            <div class="act-blog-card-link">
                                <svg xmlns="http://www.w3.org/2000/svg" width="26" height="26" viewBox="0 0 26 26" fill="currentcolor">
                                    <path d="M15.0559 8.6175C14.9551 8.71827 14.8173 8.78191 14.6582 8.78191L8.7821 8.78191L8.7821 14.658C8.7821 14.9656 8.52755 15.2201 8.21996 15.2201C7.91236 15.2201 7.6578 14.9656 7.6578 14.658L7.6578 8.21976C7.6578 7.91216 7.91236 7.65761 8.21995 7.65761L14.6582 7.65761C14.9658 7.65761 15.2203 7.91216 15.2203 8.21976C15.2256 8.37355 15.1567 8.51674 15.0559 8.6175Z"></path>
                                    <path d="M17.6333 17.6332C17.4159 17.8506 17.0553 17.8506 16.8379 17.6332L7.9124 8.7077C7.69496 8.49027 7.69496 8.12964 7.9124 7.91221C8.12983 7.69477 8.49046 7.69477 8.70789 7.91221L17.6333 16.8377C17.8508 17.0551 17.8508 17.4157 17.6333 17.6332Z"></path>
                                </svg>

                            </div>
                        </div>
                    </div>
                </a>
                <?php
            }
            if (!empty($posts[3]->ID) || !empty($posts[4]->ID) || !empty($posts[5]->ID)){
                $Post_left = array(
                    empty($posts[3]->ID) ? 'no' : $posts[3]->ID,
                    empty($posts[4]->ID) ? 'no' : $posts[4]->ID,
                    empty($posts[5]->ID) ? 'no' : $posts[5]->ID
                );
                ?>
                <div class="act-blogs-last-box">
                    <?php
                    foreach ($Post_left as $value) {
                        if ($value == 'no'){
                            continue;
                        }
                        ?>
                        <div class="act-blog-last-card">
                            <a href="<?=get_permalink($value)?>" class="act-blog-card">
                                <div class="act-blog-card-inner">
                                    <div class="act-blog-card-img-box">
                                        <img decoding="async" src="<?=get_the_post_thumbnail_url($value)?>" alt="">
                                    </div>
                                    <div class="act-blog-card-content">
                                        <h4 class="act-product-title"><?=get_the_title($value)?></h4>
                                        <div class="act-blog-card-text"><?=get_the_excerpt($value)?></div>
                                        <div class="act-blog-card-footer">
                                            <div class="act-blog-card-footer-read-time"><div class="flex align-items-center ml-1"><i class="icon-eye"></i><p><?= view_giftmax($posts[2]->ID)?></p></div><div class="flex align-items-center"><i class="icon-user"></i><?=giftmax_get_author_full_name(get_post_author_id($posts[2]->ID))?></div><div class="flex align-items-center blog_clock-view"><i class="icon-clock"></i><?=gjdate(get_the_date('Y-m-d',$posts[2]->ID),"d M Y")?></div></div>
                                            <div class="act-blog-card-link">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="26" height="26" viewBox="0 0 26 26" fill="currentcolor">
                                                    <path d="M15.0559 8.6175C14.9551 8.71827 14.8173 8.78191 14.6582 8.78191L8.7821 8.78191L8.7821 14.658C8.7821 14.9656 8.52755 15.2201 8.21996 15.2201C7.91236 15.2201 7.6578 14.9656 7.6578 14.658L7.6578 8.21976C7.6578 7.91216 7.91236 7.65761 8.21995 7.65761L14.6582 7.65761C14.9658 7.65761 15.2203 7.91216 15.2203 8.21976C15.2256 8.37355 15.1567 8.51674 15.0559 8.6175Z"></path>
                                                    <path d="M17.6333 17.6332C17.4159 17.8506 17.0553 17.8506 16.8379 17.6332L7.9124 8.7077C7.69496 8.49027 7.69496 8.12964 7.9124 7.91221C8.12983 7.69477 8.49046 7.69477 8.70789 7.91221L17.6333 16.8377C17.8508 17.0551 17.8508 17.4157 17.6333 17.6332Z"></path>
                                                </svg>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <?php
                    }
                    ?>
                </div>
                <?php
            }
        }else{?>
            <div class=" cart-panel ">
                <div class="flex mx-auto"><span>مقاله در این دسته وجود ندارد!</span></div>
            </div>
            <?php
        }
        $output = ob_get_clean();
        echo json_encode(['html' => $output,'name'=>$nameCat,'name_en'=>$nameEnCat,'link'=>$linkCat]);
    }
}
