<?php

namespace Giftmax\Api\versen;

use Giftmax\Modules\Jibit;

use Giftmax\Modules\Db;
use Giftmax\Modules\UserModel;
use Giftmax\Modules\View;

if (!defined('ABSPATH')) {
    exit;
}

class v2
{

    public function __construct()
    {
        add_action('rest_api_init', [$this, 'All_api_routes']);
    }

    public function All_api_routes()
    {
        register_rest_route('api/v2', '/wallet_amount', array(
                'methods' => 'POST',
                'callback' => [$this, 'wallet_amount_api_function'],
                'permission_callback' => function () {
                    return is_user_logged_in();
                }
        ));
        register_rest_route('api/v2', '/points', array(
                'methods' => 'POST',
                'callback' => [$this, 'points_api_function'],
                'permission_callback' => function () {
                    return is_user_logged_in();
                }
        ));
        register_rest_route('api/v2', '/verify', array(
                'methods' => 'GET',
                'callback' => [$this, 'verify_api_function'],
                'permission_callback' => "__return_true"
        ));
        register_rest_route('api/v2', '/image', array(
                'methods' => 'POST',
                'callback' => [$this, 'image_api_function'],
                'permission_callback' => function () {
                    return is_user_logged_in();
                }
        ));
        register_rest_route('api/v2', '/document_info', array(
                'methods' => 'POST',
                'callback' => [$this, 'document_info_api_function'],
                'permission_callback' => function () {
                    return is_user_logged_in();
                }
        ));
        register_rest_route('api/v2', '/RegistryPhone', array(
                'methods' => 'POST',
                'callback' => [$this, 'RegistryPhone_api_function'],
                'permission_callback' => function () {
                    return is_user_logged_in();
                }
        ));
        register_rest_route('api/v2', '/landline-phone', array(
                'methods' => 'POST',
                'callback' => [$this, 'landlinePhoneApiFunction'],
                'permission_callback' => function () {
                    return is_user_logged_in();
                }
        ));
        register_rest_route('api/v2', '/otp', array(
                'methods' => 'POST',
                'callback' => [$this, 'otp_api_function'],
                'permission_callback' => function () {
                    return is_user_logged_in();
                }
        ));
        register_rest_route('api/v2', '/verifyCard', array(
                'methods' => 'POST',
                'callback' => [$this, 'verifyCard_api_function'],
                'permission_callback' => function () {
                    return is_user_logged_in();
                }
        ));
        register_rest_route('api/v2', '/addCart', array(
                'methods' => 'POST',
                'callback' => [$this, 'addCart_api_function'],
                'permission_callback' => function () {
                    return is_user_logged_in();
                }
        ));
        register_rest_route('api/v2', '/userCart', array(
                'methods' => 'POST',
                'callback' => [$this, 'userCart_api_function'],
                'permission_callback' => function () {
                    return is_user_logged_in();
                }
        ));
        register_rest_route('api/v2', '/notifications', array(
                'methods' => 'POST',
                'callback' => [$this, 'notifications_api_function'],
                'permission_callback' => function () {
                    return is_user_logged_in();
                }
        ));
        register_rest_route('api/v2', '/notif', array(
                'methods' => 'POST',
                'callback' => [$this, 'notif_api_function'],
                'permission_callback' => function () {
                    return is_user_logged_in();
                }
        ));
        register_rest_route('api/v2', '/availability_alert_subscribe', array(
                'methods' => 'POST',
                'callback' => [$this, 'availability_alert_subscribe_api_function'],
                'permission_callback' => "__return_true"
        ));
        register_rest_route('api/v2', '/discount', array(
                'methods' => 'POST',
                'callback' => [$this, 'discount_api_function'],
                'permission_callback' => "__return_true"
        ));
        register_rest_route('api/v2', '/wishlist_toggle', array(
                'methods' => 'POST',
                'callback' => [$this, 'wishlist_toggle_api_function'],
                'permission_callback' => function () {
                    return is_user_logged_in();
                }
        ));
        register_rest_route('api/v2', '/wishlist_status', array(
                'methods' => 'POST',
                'callback' => [$this, 'wishlist_status_api_function'],
                'permission_callback' => function () {
                    return is_user_logged_in();
                }
        ));
        register_rest_route('api/v2', '/wishlist_list', array(
                'methods' => 'POST',
                'callback' => [$this, 'wishlist_list_api_function'],
                'permission_callback' => function () {
                    return is_user_logged_in();
                }
        ));
        register_rest_route('api/v2', '/post', array(
                'methods' => 'POST',
                'callback' => [$this, 'post_api_function'],
                'permission_callback' => function () {
                    return is_user_logged_in();
                }
        ));
        register_rest_route('api/v2', '/changePassword', array(
                'methods' => 'POST',
                'callback' => [$this, 'changePassword_api_function'],
                'permission_callback' => function () {
                    return is_user_logged_in();
                }
        ));
        register_rest_route('api/v2', '/changePasswordOtp', array(
                'methods' => 'POST',
                'callback' => [$this, 'changePasswordOtp_api_function'],
                'permission_callback' => function () {
                    return is_user_logged_in();
                }
        ));
        register_rest_route('api/v2', '/pupCart', array(
                'methods' => 'POST',
                'callback' => [$this, 'pupCart_api_function'],
                'permission_callback' => '__return_true'
        ));
        register_rest_route('api/v2', '/filters', array(
                'methods' => 'POST',
                'callback' => [$this, 'filters_api_function'],
                'permission_callback' => "__return_true"
        ));
        register_rest_route('api/v2', '/selectCategory', array(
                'methods' => 'POST',
                'callback' => [$this, 'selectCategory_api_function'],
                'permission_callback' => "__return_true"
        ));
        register_rest_route('api/v2', '/prices', array(
                'methods' => 'POST',
                'callback' => [$this, 'prices_api_function'],
                'permission_callback' => "__return_true"
        ));
        register_rest_route('api/v2', '/compact', array(
                'methods' => 'POST',
                'callback' => [$this, 'compact_api_function'],
                'permission_callback' => "__return_true"
        ));
        register_rest_route('api/v2', '/getCart', array(
                'methods' => 'POST',
                'callback' => [$this, 'getCart_api_function'],
                'permission_callback' => "__return_true"
        ));
        register_rest_route('api/v2', '/updateCartQty', array(
                'methods' => 'POST',
                'callback' => [$this, 'updateCartQty_api_function'],
                'permission_callback' => "__return_true"
        ));
        register_rest_route('api/v2', '/contact', array(
                'methods' => 'POST',
                'callback' => [$this, 'contact_api_function'],
                'permission_callback' => "__return_true"
        ));
        register_rest_route('api/v2', '/coupon', array(
                'methods' => 'POST',
                'callback' => [$this, 'coupon_api_function'],
                'permission_callback' => "__return_true"
        ));
        register_rest_route('api/v2', '/ForgestPassword', array(
                'methods' => 'POST',
                'callback' => [$this, 'ForgestPassword_api_function'],
                'permission_callback' => function () {
                    return is_user_logged_in();
                }
        ));
        register_rest_route('api/v2', '/download', array(
                'methods' => 'POST',
                'callback' => [$this, 'download_api_function'],
                'permission_callback' => function () {
                    return is_user_logged_in();
                }
        ));
    }

    public function download_api_function()
    {
        if (!isset($_POST['hash'])) {
            echo json_encode(['status' => false, 'message' => 'اطلاعات ناقص هست']);
            exit();
        }
        $hash = decrypt_data($_POST['hash']);
        $data = explode('|', $hash);
        $licence = \Giftmax\Modules\LicenseManager::ShowLicense($data[1], $data[2]);
        if (!empty($licence) && !is_null($licence['file_id']) && $data[0] === $licence['file_id']) {
            $file = UserModel::table('product_licences_file', 'file_id', $licence['file_id']);
            if (filter_var($file['url'], FILTER_VALIDATE_URL)) {
                $file = str_replace(
                        site_url('/'),
                        ABSPATH,
                        $file['url']
                );
            } else {
                $file = $file['url'];
            }

            header('Content-Type: application/octet-stream');
            header('Content-Disposition: attachment; filename="' . basename($file) . '"');
            header('Content-Length: ' . filesize($file));

            readfile($file);

            exit;
        } else {
            echo json_encode(['status' => false, 'message' => 'دسترسی دانلود ندارید']);
            exit();
        }
    }

    public function coupon_api_function()
    {
        if (!isset($_POST['id'])) {
            echo json_encode(['status' => false, 'message' => "مقادیر کامل نیست"]);
            exit();
        }
        $coupon_obj = new \WC_Coupon($_POST['id']);
        $products = $coupon_obj->get_product_ids();

        $discount_type = $coupon_obj->get_discount_type();
        $amount = (float)$coupon_obj->get_amount();

        switch ($discount_type) {

            case 'percent':
                $discount_text = $amount . '٪';
                break;

            case 'fixed_cart':
                $discount_text = number_format_usd($amount) . "تومان";
                break;

            case 'fixed_product':
                $discount_text = number_format_usd($amount) . "تومان";
                break;

            default:
                $discount_text = 'نامشخص';
        }

        $expiry_date = $coupon_obj->get_date_expires();
        if ($expiry_date) {
            $dashboard_coupon_description = gjdate($expiry_date->date_i18n('Y/m/d'), 'd M Y');
        } else {
            $dashboard_coupon_description = 'بدون انقضا';
        }
        $usage_limit = $coupon_obj->get_usage_limit();
        $usage_count = $coupon_obj->get_usage_count();
        if ($usage_limit) {
            $remaining = max(0, $usage_limit - $usage_count);
        } else {
            $remaining = 'نامحدود';
        }
        $products_link = [];

        foreach ($products as $product_id) {
            $product = wc_get_product($product_id);

            if (!$product) {
                continue;
            }

            $products_link[] = ['name' => esc_html($product->get_name()), 'link' => esc_url($product->get_permalink())];
        }
        echo json_encode(array('status' => true, 'code' => $coupon_obj->get_code(), 'products' => $products_link, 'remaining' => $remaining, 'discount' => $discount_text, 'expiry' => $dashboard_coupon_description));
    }

    public function contact_api_function()
    {
        $text = $_POST['text'];
        $subject = $_POST['subject'];
        $email = $_POST['email'];
        $name = $_POST['name'];
        if (empty($name) || empty($email) || empty($subject) || empty($text)) {
            $response_data = array(
                    'status' => false,
                    'message' => 'لطفاً تمام فیلدها را تکمیل کنید.'
            );
            return new \WP_REST_Response($response_data, 200);
        }
        if (!is_email($email)) {
            $response_data = array(
                    'status' => false,
                    'message' => 'ایمیل معتبر نیست.'
            );
            return new \WP_REST_Response($response_data, 200);
        }
        global $wpdb;
        $db = Db::getLnstance();
        $db->insert("INSERT INTO `{$wpdb->prefix}contact` (`id`, `name`, `email`, `subject`, `message`, `ip_address`, `user_agent`, `status`, `created_at`) VALUES (NULL, :name,:email,:subject,:message,:ip_address,:user_agent ,'0', :created_at)", array(
                'name' => $name,
                'email' => $email,
                'subject' => $subject,
                'message' => $text,
                'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? '',
                'ip_address' => giftmax_get_user_ip(),
                'created_at' => date('Y-m-d H:i:s')
        ));
        if ($db) {
            $response_data = array(
                    'status' => true
            );
            return new \WP_REST_Response($response_data, 200);
        } else {
            $response_data = array(
                    'status' => false,
                    'message' => 'خطا در ثبت.'
            );
            return new \WP_REST_Response($response_data, 200);
        }
    }

    public function prices_api_function()
    {
        $product_ids = isset($_POST['ids']) && is_array($_POST['ids']) ? $_POST['ids'] : array();

        if (empty($product_ids)) {
            return new \WP_Error('missing_product_ids', 'No product IDs provided.', array('status' => 400));
        }

        $product_prices = array();

        $product_ids = array_map('intval', $product_ids);
        $product_ids = array_filter(array_unique($product_ids));

        if (empty($product_ids)) {
            return new WP_Error('invalid_product_ids', 'Invalid product IDs provided.', array('status' => 400));
        }


        foreach ($product_ids as $product_id) {
            $product = \wc_get_product($product_id);

            if ($product) {
                $price = $product->get_price();
                $product_prices[$product_id] = $price;
            } else {
                $product_prices[$product_id] = null;
            }
        }
        $response = new \WP_REST_Response($product_prices, 200);
        return $response;
    }

    public function ForgestPassword_api_function()
    {
        $user = wp_get_current_user();
        v1::sendOTP_mobile($user->user_login);
        $response_data = array(
                'status' => true
        );
        return new \WP_REST_Response($response_data, 200);
    }

    public function changePassword_api_function()
    {
        $current_pass = $_POST['currentPassword'];
        $new_pass = $_POST['newPassword'];
        $confirm_pass = $_POST['rePassword'];

        $user = wp_get_current_user();
        $user_id = $user->ID;

        if (empty($current_pass) || empty($new_pass) || empty($confirm_pass)) {
            return new \WP_REST_Response([
                    'status' => false,
                    'message' => 'همه فیلدها باید پر شوند.'
            ], 200);
        }

        if ($new_pass !== $confirm_pass) {
            $errors = 'رمز عبور جدید و تکرار آن مطابقت ندارند.';
            return new \WP_REST_Response([
                    'status' => false,
                    'message' => $errors
            ], 200);
        }

        if (strlen($new_pass) < 8) {
            $errors = 'رمز عبور جدید باید حداقل ۸ کاراکتر باشد.';
            return new \WP_REST_Response([
                    'status' => false,
                    'message' => $errors
            ], 200);
        }

        if (!wp_check_password($current_pass, $user->user_pass, $user_id)) {
            $errors = 'رمز عبور فعلی صحیح نیست.';
            return new \WP_REST_Response([
                    'status' => false,
                    'message' => $errors
            ], 200);
        }
        wp_set_password($new_pass, $user_id);
        wp_set_auth_cookie($user_id);
        wp_set_current_user($user_id);
        return new \WP_REST_Response([
                'status' => true,
                'html' => 'OK'
        ], 200);
    }

    public function changePasswordOtp_api_function()
    {
        $otp = $_POST['otp'];
        $new_pass = $_POST['newPassword'];
        $confirm_pass = $_POST['rePassword'];

        $user = wp_get_current_user();
        $user_id = $user->ID;

        if (empty($otp) || empty($new_pass) || empty($confirm_pass)) {
            return new \WP_REST_Response([
                    'status' => false,
                    'message' => 'همه فیلدها باید پر شوند.'
            ], 200);
        }
        $records = UserModel::exitOtp($user->user_login, 'otp', $_POST['otp']);
        if (!empty($records)) {
            if (strtotime($records['otp_expiry']) > time()) {
                $number = UserModel::phone($user->user_login);
                if ($number) {
                    if ($new_pass !== $confirm_pass) {
                        $errors = 'رمز عبور جدید و تکرار آن مطابقت ندارند.';
                        return new \WP_REST_Response([
                                'status' => false,
                                'message' => $errors
                        ], 200);
                    }

                    if (strlen($new_pass) < 8) {
                        $errors = 'رمز عبور جدید باید حداقل ۸ کاراکتر باشد.';
                        return new \WP_REST_Response([
                                'status' => false,
                                'message' => $errors
                        ], 200);
                    }

                    wp_set_password($new_pass, $user_id);
                    wp_set_auth_cookie($user_id);
                    wp_set_current_user($user_id);
                    UserModel::otpDelete($records['id']);
                    return new \WP_REST_Response([
                            'status' => true,
                            'html' => 'OK'
                    ], 200);
                } else {
                    $errors = 'خطایی رخ داد.';
                    return new \WP_REST_Response([
                            'status' => false,
                            'close' => true,
                            'message' => $errors
                    ], 200);
                }
            } else {
                UserModel::otpDelete($records['id']);
                $response_data = array(
                        'status' => false,
                        'close' => true,
                        'message' => 'کد شما منقضی شده'
                );
            }
            return new \WP_REST_Response($response_data, 200);

        } else {
            $errors = 'کد ارسالی درست نیست.';
            return new \WP_REST_Response([
                    'status' => false,
                    'message' => $errors
            ], 200);
        }
    }

    function discount_api_function()
    {
        $product_id = isset($_POST['id']) ? absint($_POST['id']) : 0;
        $product = wc_get_product($product_id);
        if (!$product) {
            wp_send_json_error(['message' => 'محصول پیدا نشد.']);
        }
        $coupon_posts = get_posts([
                'post_type' => 'shop_coupon',
                'post_status' => 'publish',
                'numberposts' => -1,
                'fields' => 'ids',
        ]);

        $codes = [];
        foreach ($coupon_posts as $coupon_id) {
            $coupon = new \WC_Coupon($coupon_id);

            $expires = $coupon->get_date_expires();
            if ($expires && $expires->getTimestamp() < current_time('timestamp')) {
                continue;
            }

            if ($coupon->is_valid_for_product($product)) {
                $limit = $coupon->get_usage_limit();
                $used = $coupon->get_usage_count();
                $remaining = ($limit && $limit > 0) ? max(0, $limit - $used) : null;
                $expires = $coupon->get_date_expires();
                $expires_at = $expires ? gjdate($expires->date_i18n('Y/m/d'),"d M Y") : null;

                $discount_type = $coupon->get_discount_type();
                $amount = (float)$coupon->get_amount();
                $discount_text = '';
                if ($coupon->get_free_shipping()) {
                    $discount_text = 'ارسال رایگان';
                } elseif ($discount_type === 'percent') {
                    $discount_text = rtrim(rtrim(number_format($amount, 2, '.', ''), '0'), '.') . '%';
                } elseif ($discount_type === 'fixed_cart' || $discount_type === 'fixed_product') {
                    $discount_text = wc_price($amount);
                }

                $codes[] = [
                        'code' => $coupon->get_code(),
                        'remaining' => $remaining,
                        'limit' => $limit,
                        'used' => $used,
                        'expires' => $expires_at,
                        'discount_text' => $discount_text,
                ];
            }
        }

        wp_send_json_success(['codes' => $codes]);
    }

    function notifications_api_function()
    {
        $id = isset($_POST['id']) ? absint($_POST['id']) : 0;
        $user_id = get_current_user_id();
        if ($id <= 0 || $user_id <= 0) {
            return new \WP_REST_Response([
                    'status' => false,
                    'message' => 'درخواست نامعتبر است'
            ], 400);
        }

        $db = Db::getLnstance();
        global $wpdb;

        $notification = $db->first("SELECT `Id`,`userId` FROM `{$wpdb->prefix}notifications` WHERE `Id`=:Id AND `is_active`=1 AND (`userId` IS NULL OR `userId`=0 OR `userId`=:user_id)", array(
                'Id' => $id,
                'user_id' => $user_id,
        ));

        if (empty($notification)) {
            return new \WP_REST_Response([
                    'status' => false,
                    'message' => 'اعلان یافت نشد'
            ], 404);
        }

        $db->insert("INSERT INTO `{$wpdb->prefix}notification_reads` (`notification_id`,`user_id`,`seen_at`) VALUES (:notification_id,:user_id,NOW()) ON DUPLICATE KEY UPDATE `seen_at` = VALUES(`seen_at`)", array(
                'notification_id' => $id,
                'user_id' => $user_id,
        ));
        $db->modify("UPDATE `{$wpdb->prefix}notifications` SET `status`='read' WHERE `Id`=:Id AND `userId`=:user_id", array(
                'Id' => $id,
                'user_id' => $user_id,
        ));
        UserModel::deleteAlert($user_id, $id);
        return new \WP_REST_Response([
                'status' => true,
                'html' => 'OK'
        ], 200);
    }

    function notif_api_function()
    {
        $id = isset($_POST['id']) ? absint($_POST['id']) : 0;
        $user_id = get_current_user_id();
        if ($id <= 0 || $user_id <= 0) {
            return new \WP_REST_Response([
                    'status' => false,
                    'message' => 'درخواست نامعتبر است'
            ], 400);
        }

        $db = Db::getLnstance();
        global $wpdb;

        $notification = $db->first("SELECT Id,userId,body,title FROM `{$wpdb->prefix}notifications` WHERE `Id`=:Id AND `is_active`=1 AND (`userId` IS NULL OR `userId`=0 OR `userId`=:user_id)", array(
                'Id' => $id,
                'user_id' => $user_id,
        ));

        if (empty($notification)) {
            return new \WP_REST_Response([
                    'status' => false,
                    'message' => 'اعلان یافت نشد'
            ], 404);
        }
        if ($_POST['method'] == 'r') {
            $db->insert("INSERT INTO `{$wpdb->prefix}notification_reads` (`notification_id`,`user_id`,`seen_at`) VALUES (:notification_id,:user_id,NOW()) ON DUPLICATE KEY UPDATE `seen_at` = VALUES(`seen_at`)", array(
                    'notification_id' => $id,
                    'user_id' => $user_id,
            ));
            $db->modify("UPDATE `{$wpdb->prefix}notifications` SET `status`='read' WHERE `Id`=:Id AND `userId`=:user_id", array(
                    'Id' => $id,
                    'user_id' => $user_id,
            ));
            UserModel::deleteAlert($user_id, $id);
        }
        unset($notification['Id']);
        unset($notification['userId']);
        $notification['body'] = wp_kses_post($notification['body']);
        return new \WP_REST_Response([
                'status' => true,
                'html' => 'OK',
                'notification' => $notification
        ], 200);
    }

    public function post_api_function(\WP_REST_Request $request)
    {
        $user_id = get_current_user_id();
        if ($user_id <= 0) {
            return new \WP_REST_Response([
                    'status' => false,
                    'message' => 'ابتدا وارد شوید'
            ], 401);
        }

        $title = sanitize_text_field($request->get_param('title'));
        $content = wp_kses_post($request->get_param('content'));
        $category = absint($request->get_param('category'));

        if ($title === '' || $content === '' || $category <= 0) {
            return new \WP_REST_Response([
                    'status' => false,
                    'message' => 'عنوان، متن یا دسته‌بندی را وارد کنید'
            ], 422);
        }

        if (!term_exists($category, 'category')) {
            return new \WP_REST_Response([
                    'status' => false,
                    'message' => 'دسته‌بندی نامعتبر است'
            ], 422);
        }

        if (!giftmax_user_can_submit_article($user_id)) {
            return new \WP_REST_Response([
                    'status' => false,
                    'message' => 'شما مجاز به ارسال مقاله نیستید'
            ], 403);
        }

        $post_id = wp_insert_post([
                'post_type' => 'post',
                'post_status' => 'pending',
                'post_author' => $user_id,
                'post_title' => $title,
                'post_content' => $content,
                'post_category' => [$category],
        ], true);

        if (is_wp_error($post_id) || !$post_id) {
            return new \WP_REST_Response([
                    'status' => false,
                    'message' => 'خطا در ثبت مقاله'
            ], 500);
        }

        update_post_meta($post_id, '_giftmax_submitted_from_frontend', 1);

        return new \WP_REST_Response([
                'status' => true,
                'message' => 'مقاله با موفقیت ثبت شد و در انتظار تایید است'
        ], 200);
    }

    private function normalize_mobile_number($mobile_raw)
    {
        $mobile = is_string($mobile_raw) ? trim($mobile_raw) : '';
        if ($mobile === '') {
            return '';
        }

        $mobile = strtr($mobile, array(
                '۰' => '0', '۱' => '1', '۲' => '2', '۳' => '3', '۴' => '4',
                '۵' => '5', '۶' => '6', '۷' => '7', '۸' => '8', '۹' => '9',
        ));
        $mobile = preg_replace('/\D+/', '', $mobile);

        if (strpos($mobile, '98') === 0 && strlen($mobile) === 12) {
            $mobile = '0' . substr($mobile, 2);
        } elseif (strpos($mobile, '0098') === 0 && strlen($mobile) === 14) {
            $mobile = '0' . substr($mobile, 4);
        } elseif (strpos($mobile, '9') === 0 && strlen($mobile) === 10) {
            $mobile = '0' . $mobile;
        }

        return $mobile;
    }

    private function get_current_user_mobile($user_id)
    {
        $user_id = (int)$user_id;
        if ($user_id <= 0) {
            return '';
        }

        $user = get_userdata($user_id);
        $candidate = '';
        if ($user && !empty($user->user_login)) {
            $candidate = $this->normalize_mobile_number($user->user_login);
        }
        if ($candidate === '') {
            $candidate = $this->normalize_mobile_number(get_user_meta($user_id, 'billing_phone', true));
        }

        if (preg_match('/^09\d{9}$/', $candidate)) {
            return $candidate;
        }

        return '';
    }

    function availability_alert_subscribe_api_function()
    {
        $product_id = isset($_POST['product_id']) ? absint($_POST['product_id']) : 0;
        $channel = isset($_POST['channel']) ? sanitize_key($_POST['channel']) : '';
        $user_id = get_current_user_id();

        if (!is_user_logged_in()) {
            return new \WP_REST_Response([
                    'status' => false,
                    'message' => 'برای فعال‌سازی نوتیفیکیشن ابتدا وارد حساب کاربری شوید'
            ], 200);
        }
        if ($product_id <= 0) {
            return new \WP_REST_Response([
                    'status' => false,
                    'message' => 'محصول معتبر نیست'
            ], 200);
        }

        $product = wc_get_product($product_id);
        if (!$product || get_post_type($product_id) !== 'product') {
            return new \WP_REST_Response([
                    'status' => false,
                    'message' => 'محصول یافت نشد'
            ], 200);
        }

        if (!in_array($channel, array('notification', 'sms'), true)) {
            return new \WP_REST_Response([
                    'status' => false,
                    'message' => 'روش ارسال نامعتبر است'
            ], 200);
        }

        $mobile = '';
        if ($channel === 'sms') {
            $mobile = $this->get_current_user_mobile($user_id);
            if (!preg_match('/^09\d{9}$/', $mobile)) {
                return new \WP_REST_Response([
                        'status' => false,
                        'message' => 'شماره موبایل معتبر نیست'
                ], 200);
            }
        }

        $target_user_id = $channel === 'notification' ? (int)$user_id : (int)$user_id;
        $target_mobile = $channel === 'sms' ? $mobile : '';

        $db = Db::getLnstance();
        global $wpdb;
        $table = $wpdb->prefix . 'product_availability_alerts';
        $records = $db->query("SELECT * FROM $table WHERE `product_id`=:product_id AND `user_id`=:user_id AND `mobile`=:mobile AND `channel`=:channel AND `is_sent`=0", array(
                'product_id' => $product_id,
                'user_id' => $target_user_id,
                'mobile' => $target_mobile,
                'channel' => $channel
        ));
        if (empty($records)) {
            $db->insert("INSERT INTO `{$table}` (`product_id`,`user_id`,`mobile`,`channel`,`is_sent`,`created_at`,`sent_at`) VALUES (:product_id,:user_id,:mobile,:channel,0,NOW(),NULL) ON DUPLICATE KEY UPDATE `is_sent`=0,`created_at`=NOW(),`sent_at`=NULL", array(
                    'product_id' => $product_id,
                    'user_id' => $target_user_id,
                    'mobile' => $target_mobile,
                    'channel' => $channel,
            ));
        }

        return new \WP_REST_Response([
                'status' => true,
                'message' => 'درخواست ثبت شد، به محض موجود شدن اطلاع می‌دهیم'
        ], 200);
    }

    function wishlist_toggle_api_function()
    {
        $product_id = isset($_POST['product_id']) ? absint($_POST['product_id']) : 0;
        $user_id = get_current_user_id();
        if ($product_id <= 0 || $user_id <= 0 || get_post_type($product_id) !== 'product' || !is_user_logged_in()) {
            return new \WP_REST_Response([
                    'status' => false,
                    'message' => 'درخواست نامعتبر است'
            ], 400);
        }

        $db = Db::getLnstance();
        global $wpdb;
        $table = $wpdb->prefix . 'user_wishlist';

        $exists = $db->first("SELECT `id` FROM `{$table}` WHERE `user_id`=:user_id AND `product_id`=:product_id", array(
                'user_id' => $user_id,
                'product_id' => $product_id,
        ));

        if (!empty($exists)) {
            $db->modify("DELETE FROM `{$table}` WHERE `user_id`=:user_id AND `product_id`=:product_id", array(
                    'user_id' => $user_id,
                    'product_id' => $product_id,
            ));
            $in_wishlist = false;
            $message = 'از علاقه‌مندی‌ها حذف شد';
        } else {
            $db->insert("INSERT INTO `{$table}` (`user_id`,`product_id`,`created_at`) VALUES (:user_id,:product_id,NOW())", array(
                    'user_id' => $user_id,
                    'product_id' => $product_id,
            ));
            $in_wishlist = true;
            $message = 'به علاقه‌مندی‌ها اضافه شد';
        }

        $count = $db->first("SELECT COUNT(*) AS total FROM `{$table}` WHERE `user_id`=:user_id", array(
                'user_id' => $user_id,
        ));

        return new \WP_REST_Response([
                'status' => true,
                'in_wishlist' => $in_wishlist,
                'message' => $message
        ], 200);
    }

    function wishlist_status_api_function()
    {
        $product_id = isset($_POST['product_id']) ? absint($_POST['product_id']) : 0;
        $user_id = get_current_user_id();
        if ($product_id <= 0 || $user_id <= 0 || get_post_type($product_id) !== 'product') {
            return new \WP_REST_Response([
                    'status' => false,
                    'message' => 'درخواست نامعتبر است'
            ], 400);
        }

        $db = Db::getLnstance();
        global $wpdb;
        $table = $wpdb->prefix . 'user_wishlist';

        $exists = $db->first("SELECT `id` FROM `{$table}` WHERE `user_id`=:user_id AND `product_id`=:product_id", array(
                'user_id' => $user_id,
                'product_id' => $product_id,
        ));
        $count = $db->first("SELECT COUNT(*) AS total FROM `{$table}` WHERE `user_id`=:user_id", array(
                'user_id' => $user_id,
        ));

        return new \WP_REST_Response([
                'status' => true,
                'in_wishlist' => !empty($exists),
                'count' => !empty($count) ? (int)$count['total'] : 0
        ], 200);
    }

    function wishlist_list_api_function()
    {
        $user_id = get_current_user_id();
        if ($user_id <= 0) {
            return new \WP_REST_Response([
                    'status' => false,
                    'message' => 'درخواست نامعتبر است'
            ], 400);
        }

        $db = Db::getLnstance();
        global $wpdb;
        $table = $wpdb->prefix . 'user_wishlist';
        $rows = $db->query("SELECT `product_id` FROM `{$table}` WHERE `user_id`=:user_id ORDER BY `created_at` DESC", array(
                'user_id' => $user_id,
        ));

        $product_ids = array();
        if (!empty($rows)) {
            foreach ($rows as $row) {
                $product_ids[] = (int)$row['product_id'];
            }
        }

        return new \WP_REST_Response([
                'status' => true,
                'product_ids' => $product_ids
        ], 200);
    }

    public function userCart_api_function()
    {
        $userId = get_current_user_id();
        global $wpdb;
        $db = Db::getLnstance();
        if (isset($_POST['m'])) {
            $defaultCard = $db->query("SELECT * FROM `{$wpdb->prefix}user_bank_cards` WHERE `user_id`=:user_id AND `is_active`=1 AND phone IS NULL", array('user_id' => $userId));
            ob_start();
            if (!empty($defaultCard)) {
                foreach ($defaultCard as $card) {
                    $cardNumber = rtrim(
                            chunk_split(decrypt_data($card['card_number_enc']), 4, '-'),
                            '-'
                    );
                    ?>
                    <div class="selectCartUser">
                        <div class="flex justify-between">
                            <div class="flex justify-between align-items-center">
                                <img loading="lazy" width="28" height="28" decoding="async" data-nimg="1"
                                     class="w-24 sm:w-28 h-auto ml-2"
                                     src="<?= detectBankImage(decrypt_data($card['card_number_enc'])) ?>"
                                     style="color: transparent;">
                                <p><?= $cardNumber ?></p>
                            </div>
                            <div class="flex justify-between align-items-center relative">
                                <div class="bank-card_user_status success">
                                    تحت مالکیت شما
                                </div>
                                <div class="w-[50px] lottie-container absolute -right-50"
                                     data-lottie-url="<?= get_template_directory_uri() ?>/assets/img/wsl/card-done.json"></div>
                            </div>
                        </div>
                    </div>
                <?php }
            } else {
                ?>
                <div class="flex justify-center lg:w-100">کارت برای شما ثبت نشده</div>
            <?php }
            $output = ob_get_clean();
        } else {
            $defaultCard = $db->query("SELECT * FROM `{$wpdb->prefix}user_bank_cards` WHERE `user_id`=:user_id AND `is_active`=1", array('user_id' => $userId));
            ob_start();
            if (!empty($defaultCard)) {
                foreach ($defaultCard as $card) {
                    $cardNumber = rtrim(
                            chunk_split(decrypt_data($card['card_number_enc']), 4, '-'),
                            '-'
                    );
                    ?>
                    <div class="selectCartUser">
                        <div class="flex justify-between">
                            <div class="flex justify-between align-items-center">
                                <img loading="lazy" width="28" height="28" decoding="async" data-nimg="1"
                                     class="w-24 sm:w-28 h-auto ml-2"
                                     src="<?= detectBankImage(decrypt_data($card['card_number_enc'])) ?>"
                                     style="color: transparent;">
                                <p><?= $cardNumber ?></p>
                            </div>
                            <?php
                            if (empty($card['phone'])) {
                                ?>
                                <div class="flex justify-between align-items-center relative">
                                    <div class="bank-card_user_status success">
                                        تحت مالکیت شما
                                    </div>
                                    <div class="w-[50px] lottie-container absolute -right-50"
                                         data-lottie-url="<?= get_template_directory_uri() ?>/assets/img/wsl/card-done.json"></div>
                                </div>
                                <?php
                            } else {
                                ?>
                                <div class="flex justify-between align-items-center relative">
                                    <div class="bank-card_user_status danger">
                                        مالک شما نیستید
                                    </div>
                                    <div class="w-[50px] lottie-container absolute -right-50"
                                         data-lottie-url="<?= get_template_directory_uri() ?>/assets/img/wsl/card-error.json"></div>
                                </div>
                            <?php }
                            ?>
                        </div>
                    </div>
                <?php }
            } else {
                ?>
                <div class="flex justify-center lg:w-100">کارت برای شما ثبت نشده</div>
            <?php }
            $output = ob_get_clean();
        }
        return ['html' => $output];
    }

    public static function otpCardVerify($phone, $otp, $hash, $order = null, $is_exist = null)
    {
        global $wpdb;
        $db = Db::getLnstance();
        $records = UserModel::exitOtp($phone, 'otp', $otp);
        if (!empty($records)) {
            if (strtotime($records['otp_expiry']) > time()) {
                UserModel::otpDelete($records['id']);
                $response_data = array('status' => true);
                if (is_null($order)) {
                    $db->modify("UPDATE `{$wpdb->prefix}user_bank_cards` SET `is_active` = '1' WHERE `hash` = :hash", array(
                            'hash' => $hash
                    ));
                } else {
                    if (!$is_exist) {
                        $db->modify("UPDATE `{$wpdb->prefix}user_bank_cards` SET `is_active` = '1' WHERE `hash` = :hash", array(
                                'hash' => $hash
                        ));
                    }
                    $disable_completed_email = function ($enabled, $email) {
                        return false;
                    };
                    add_filter('woocommerce_email_enabled_customer_completed_order', $disable_completed_email, 10, 2);
                    $order->update_status('completed', 'تایید شدن کارت');
                    remove_filter('woocommerce_email_enabled_customer_completed_order', $disable_completed_email, 10);
                    $order->save();
                    $response_data['url'] = home_url('/profile/invoices/' . $order->get_id());
                }
            } else {
                UserModel::otpDelete($records['id']);
                $response_data = array(
                        'status' => false,
                        'closed' => true,
                        'message' => 'کد شما منقضی شده'
                );
            }
        } else {
            $response_data = array(
                    'status' => false,
                    'closed' => false,
                    'message' => 'کد وروردی صحیح نمیباشد'
            );
        }
        return $response_data;
    }

    public function verifyCard_api_function()
    {
        if (isset($_POST['drg'])) {
            $hash = decrypt_data($_POST['drg']);
            $record = UserModel::table('user_bank_cards', 'hash', $hash);
            $response_data = $this->otpCardVerify(decrypt_data($record['phone']), $_POST['otp'], $hash);
            $cards = [];
            global $wpdb;
            $db = Db::getLnstance();
            $records = $db->query("SELECT card_number_enc,birth_date,phone,national_code,first_name,last_name,user_id FROM `{$wpdb->prefix}user_bank_cards` WHERE user_id=:user_id AND is_active=1", array('user_id' => $record['user_id']));
            foreach ($records as $record) {
                $user = get_userdata($record['user_id']);
                $cardNumber = rtrim(
                        chunk_split(decrypt_data($record['card_number_enc']), 4, '-'),
                        '-'
                );
                if (!empty($record['phone'])) {
                    $FullName = decrypt_data($record['first_name']) . ' ' . decrypt_data($record['last_name']);
                } else {
                    $FullName = $user->first_name . ' ' . $user->last_name;
                }
                ob_start();
                ?>
                <div class="V10-3-Bank">
                    <?php
                    $cardSetting = detectBankImageBg($cardNumber, 'v1');
                    if (empty($record['phone'])) {
                        $userdata = UserModel::table('user_identity', 'user_id', $user->ID);
                        ?>
                        <span class="numberCard"
                              style="bottom: <?= $cardSetting['positionText'] ?>px;<?= $cardSetting != null ? "color:" . $cardSetting['color'] : '' ?>"><?= $cardNumber ?></span>
                        <img alt="bank" loading="lazy" src="<?= $cardSetting['img'] ?>">
                        <span class="number-user"
                              style="bottom: <?= $cardSetting["Box"]["y"] ?>px;color:<?= $cardSetting["Box"]["color"] ?>"><?= $user->user_login ?></span>
                        <span class="birthday-user"
                              style="bottom: <?= $cardSetting["Box"]["y"] ?>px;color:<?= $cardSetting["Box"]["color"] ?>"><?= decrypt_data($userdata['birth_date_enc']) ?></span>
                        <span class="national__code-user"
                              style="bottom: <?= $cardSetting["Box"]["y"] ?>px;color:<?= $cardSetting["Box"]["color"] ?>"><?= decrypt_data($userdata['national_id_enc']) ?></span>
                        <span class="full__name-user"
                              style="bottom: <?= $cardSetting["Box"]["y"] ?>px;right: <?= $cardSetting["Box"]["x"] ?>%;color:<?= $cardSetting["Box"]["color"] ?>"><?= $user->first_name . ' ' . $user->last_name ?></span>

                        <?php
                    } else {
                        ?>
                        <span class="numberCard"
                              style="bottom: <?= $cardSetting['positionText'] ?>px;<?= $cardSetting != null ? "color:" . $cardSetting['color'] : '' ?>"><?= $cardNumber ?></span>
                        <span class="number-user"
                              style="bottom: <?= $cardSetting["Box"]["y"] ?>px;color:<?= $cardSetting["Box"]["color"] ?>"><?= decrypt_data($record['phone']) ?></span>
                        <span class="birthday-user"
                              style="bottom: <?= $cardSetting["Box"]["y"] ?>px;color:<?= $cardSetting["Box"]["color"] ?>"><?= decrypt_data($record['birth_date']) ?></span>
                        <span class="national__code-user"
                              style="bottom: <?= $cardSetting["Box"]["y"] ?>px;color:<?= $cardSetting["Box"]["color"] ?>"><?= decrypt_data($record['national_code']) ?></span>
                        <span class="full__name-user"
                              style="bottom: <?= $cardSetting["Box"]["y"] ?>px;right: <?= $cardSetting["Box"]["x"] ?>%;color:<?= $cardSetting["Box"]["color"] ?>"><?= $record['first_name'] . ' ' . $record['last_name'] ?></span>
                        <img alt="bank" loading="lazy" src="<?= $cardSetting['img'] ?>">
                    <?php }
                    ?>
                </div>
                <?php
                $html = ob_get_clean();
                ob_start();
                ?>
                <div class="bank-card-content">
                    <div class="flex justify-end align-items-center">
                        <div class="bank-card__top">
                            <div class="bank-card__logo" aria-hidden="true">
                                <img loading="lazy" decoding="async" data-nimg="1" class="h-auto"
                                     src="<?= detectBankImage(decrypt_data($record['card_number_enc'])) ?>"
                                     style="color: transparent;width: 20px" data-booster-processed="true">
                            </div>
                        </div>
                        <div class="bank-card__number"><?= $cardNumber ?></div>
                    </div>
                    <?php
                    if (empty($card['phone'])) {
                        ?>
                        <div class="flex justify-between align-items-center relative">
                            <div class="bank-card_user_status success">
                                تحت مالکیت شما
                            </div>
                            <div class="w-[50px] lottie-container absolute -right-50"
                                 data-lottie-url="<?= get_template_directory_uri() ?>/assets/img/wsl/card-done.json"></div>
                        </div>
                        <?php
                    } else {
                        ?>
                        <div class="flex justify-between align-items-center relative">
                            <div class="bank-card_user_status danger">
                                مالک شما نیستید
                            </div>
                            <div class="w-[50px] lottie-container absolute -right-50"
                                 data-lottie-url="<?= get_template_directory_uri() ?>/assets/img/wsl/card-error.json"></div>
                        </div>
                    <?php }
                    ?>
                </div>
                <?php
                $htmlV2 = ob_get_clean();
                $cards[] = [
                        "card_number" => $cardNumber,
                        "fullName" => $FullName,
                        "name" => detectBankByCardNumber($cardNumber),
                        "html" => $html,
                        "htmlV2" => $htmlV2,
                ];
            }
            $response_data['card'] = $cards;
            echo json_encode($response_data);
        } elseif (isset($_POST['hash'])) {
            $hash = $_POST['hash'];
            $record = UserModel::table('user_bank_cards', 'hash', $hash);
            $response_data = $this->otpCardVerify(get_userdata($record['user_id'])->user_login, $_POST['otp'], $hash);
            $cards = [];
            global $wpdb;
            $db = Db::getLnstance();
            $records = $db->query("SELECT card_number_enc,birth_date,phone,national_code,first_name,last_name,user_id FROM `{$wpdb->prefix}user_bank_cards` WHERE user_id=:user_id AND is_active=1", array('user_id' => $record['user_id']));
            foreach ($records as $record) {
                $user = get_userdata($record['user_id']);
                $cardNumber = rtrim(
                        chunk_split(decrypt_data($record['card_number_enc']), 4, '-'),
                        '-'
                );
                if (!empty($record['phone'])) {
                    $FullName = decrypt_data($record['first_name']) . ' ' . decrypt_data($record['last_name']);
                } else {
                    $FullName = $user->first_name . ' ' . $user->last_name;
                }
                ob_start();
                ?>
                <div class="V10-3-Bank">
                    <?php
                    $cardSetting = detectBankImageBg($cardNumber, 'v1');
                    if (empty($record['phone'])) {
                        $userdata = UserModel::table('user_identity', 'user_id', $user->ID);
                        ?>
                        <span class="numberCard"
                              style="bottom: <?= $cardSetting['positionText'] ?>px;<?= $cardSetting != null ? "color:" . $cardSetting['color'] : '' ?>"><?= $cardNumber ?></span>
                        <img alt="bank" loading="lazy" src="<?= $cardSetting['img'] ?>">
                        <span class="number-user"
                              style="bottom: <?= $cardSetting["Box"]["y"] ?>px;color:<?= $cardSetting["Box"]["color"] ?>"><?= $user->user_login ?></span>
                        <span class="birthday-user"
                              style="bottom: <?= $cardSetting["Box"]["y"] ?>px;color:<?= $cardSetting["Box"]["color"] ?>"><?= decrypt_data($userdata['birth_date_enc']) ?></span>
                        <span class="national__code-user"
                              style="bottom: <?= $cardSetting["Box"]["y"] ?>px;color:<?= $cardSetting["Box"]["color"] ?>"><?= decrypt_data($userdata['national_id_enc']) ?></span>
                        <span class="full__name-user"
                              style="bottom: <?= $cardSetting["Box"]["y"] ?>px;right: <?= $cardSetting["Box"]["x"] ?>%;color:<?= $cardSetting["Box"]["color"] ?>"><?= $user->first_name . ' ' . $user->last_name ?></span>

                        <?php
                    } else {
                        ?>
                        <span class="numberCard"
                              style="bottom: <?= $cardSetting['positionText'] ?>px;<?= $cardSetting != null ? "color:" . $cardSetting['color'] : '' ?>"><?= $cardNumber ?></span>
                        <span class="number-user"
                              style="bottom: <?= $cardSetting["Box"]["y"] ?>px;color:<?= $cardSetting["Box"]["color"] ?>"><?= decrypt_data($record['phone']) ?></span>
                        <span class="birthday-user"
                              style="bottom: <?= $cardSetting["Box"]["y"] ?>px;color:<?= $cardSetting["Box"]["color"] ?>"><?= decrypt_data($record['birth_date']) ?></span>
                        <span class="national__code-user"
                              style="bottom: <?= $cardSetting["Box"]["y"] ?>px;color:<?= $cardSetting["Box"]["color"] ?>"><?= decrypt_data($record['national_code']) ?></span>
                        <span class="full__name-user"
                              style="bottom: <?= $cardSetting["Box"]["y"] ?>px;right: <?= $cardSetting["Box"]["x"] ?>%;color:<?= $cardSetting["Box"]["color"] ?>"><?= $record['first_name'] . ' ' . $record['last_name'] ?></span>
                        <img alt="bank" loading="lazy" src="<?= $cardSetting['img'] ?>">
                    <?php }
                    ?>
                </div>
                <?php
                $html = ob_get_clean();
                ob_start();
                ?>
                <div class="bank-card-content">
                    <div class="flex justify-end align-items-center">
                        <div class="bank-card__top">
                            <div class="bank-card__logo" aria-hidden="true">
                                <img loading="lazy" decoding="async" data-nimg="1" class="h-auto"
                                     src="<?= detectBankImage(decrypt_data($record['card_number_enc'])) ?>"
                                     style="color: transparent;width: 20px" data-booster-processed="true">
                            </div>
                        </div>
                        <div class="bank-card__number"><?= $cardNumber ?></div>
                    </div>
                    <?php
                    if (empty($card['phone'])) {
                        ?>
                        <div class="flex justify-between align-items-center relative">
                            <div class="bank-card_user_status success">
                                تحت مالکیت شما
                            </div>
                            <div class="w-[50px] lottie-container absolute -right-50"
                                 data-lottie-url="<?= get_template_directory_uri() ?>/assets/img/wsl/card-done.json"></div>
                        </div>
                        <?php
                    } else {
                        ?>
                        <div class="flex justify-between align-items-center relative">
                            <div class="bank-card_user_status danger">
                                مالک شما نیستید
                            </div>
                            <div class="w-[50px] lottie-container absolute -right-50"
                                 data-lottie-url="<?= get_template_directory_uri() ?>/assets/img/wsl/card-error.json"></div>
                        </div>
                    <?php }
                    ?>
                </div>
                <?php
                $htmlV2 = ob_get_clean();
                $cards[] = [
                        "card_number" => $cardNumber,
                        "fullName" => $FullName,
                        "name" => detectBankByCardNumber($cardNumber),
                        "html" => $html,
                        "htmlV2" => $htmlV2,
                ];
            }
            $response_data['card'] = $cards;
            echo json_encode($response_data);
        } elseif (isset($_POST['data'])) {
            $dataAjax = explode('||', decrypt_data($_POST['data']['hash']));
            $order = wc_get_order(decrypt_id($dataAjax[0]));
            if (!$order) {
                echo json_encode([
                        'status' => false,
                        'message' => 'سفارش یافت نشد',
                        'percent' => 0,
                        'close' => true
                ]);
                exit();
            }
            $is_exist = $order->get_meta('_is_exist', true);
            $cardPay = $order->get_meta('_card_pay', true);
            if ($dataAjax[1] == 'otp') {
                $user_id = get_current_user_id();
                $phone = UserModel::table('user_bank_cards', 'card_number_enc', encrypt_data($cardPay), "user_id", $user_id)['phone'];
                $response_data = $this->otpCardVerify(decrypt_data($phone), $_POST['data']['otp'], $dataAjax[2], $order, $is_exist);
                if ($response_data['status'] === true) {
                    $response_data['close'] = true;
                    $response_data['percent'] = 100;
                } else {
                    $response_data['percent'] = 90;
                }
                echo json_encode($response_data);
            } elseif ($dataAjax[1] == 'register') {
                if (!isset($_POST['data']) && !isset($data['phone-number']) && !isset($data['day']) && !isset($data['month']) && !isset($data['year']) && !isset($data['national-code'])) {
                    echo json_encode(["status" => false, "percent" => 0, "message" => "اطلاعات معتبر نیست", "close" => true]);
                }
                $data = $_POST['data'];
                $phoneNumber = $data['phone-number'];
                $day = $data['day'];
                $month = $data['month'];
                $year = $data['year'];
                $nationalCode = $data['national-code'];
                $firstName = $data['firstName'];
                $lastName = $data['lastName'];
                $cartNumber = $cardPay;
                if (!validateIranianMobile($phoneNumber)) {
                    echo json_encode(["status" => false, "percent" => 50, "message" => "شماره تلفن معتبر نیست"]);
                    exit;
                } elseif (!preg_match('/^(0?[1-9]|[12][0-9]|3[01])$/', $day) || !preg_match('/^(0?[1-9]|1[0-2])$/', $month) || !preg_match('/^[0-9]{4}$/', $year)) {
                    echo json_encode(["status" => false, "percent" => 50, "message" => "تاریخ تولد معتبر نیست"]);
                    exit;
                } elseif (empty($firstName)) {
                    echo json_encode(["status" => false, "percent" => 50, "message" => "نام وارد نشده است"]);
                    exit;
                } elseif (empty($lastName)) {
                    echo json_encode(["status" => false, "percent" => 50, "message" => "نام خانوادگی وارد نشده است"]);
                    exit;
                } elseif (!preg_match('/^[0-9]{10}$/', $nationalCode)) {
                    echo json_encode(["status" => false, "percent" => 50, "message" => "کدملی معتبر نیست"]);
                    exit;
                } elseif (!isCardNumberValid($cartNumber)) {
                    echo json_encode(["status" => false, "percent" => 50, "message" => "کارت معتبر نیست", "close" => true]);
                    exit;
                }
                $token = 'd5497c98fc9a28300406dd8ee66bac5b531fc598';
                $birthDate = $year . '/' . $month . '/' . $day;
                $jbt = Jibit::getLnstance();
                if (UserModel::setting("shahkar_zohal") === true) {
                    $result = v1::callZohalService(
                            'https://service.zohal.io/api/v0/services/inquiry/shahkar',
                            [
                                    'mobile' => $phoneNumber,
                                    'national_code' => $nationalCode
                            ],
                            $token
                    );

                    if ($result['status'] !== true) {
                        return new \WP_REST_Response([
                                'status' => false,
                                $result,
                                "percent" => 50
                        ], 200);
                    }
                } elseif (UserModel::setting("shahkar_jibit") === true) {
                    $endpoint = '/services/matching';
                    $res = $jbt->api_request('GET', $endpoint, [
                            'mobileNumber' => $phoneNumber,
                            'nationalCode' => $nationalCode
                    ], null, true);
                    if ($res['code'] !== 200) {
                        return new \WP_REST_Response([
                                'status' => false,
                                'message' => $res['body']['message'],
                                "percent" => 50
                        ], 200);
                    }
                }
                if (UserModel::setting("check_card_with_national_code_zohal") === true) {
                    $result = v1::callZohalService(
                            'https://service.zohal.io/api/v0/services/inquiry/check_card_with_national_code',
                            [
                                    'birth_date' => $birthDate,
                                    'card_number' => $cartNumber,
                                    'national_code' => $nationalCode
                            ],
                            $token
                    );

                    if ($result['status'] !== true) {
                        return new \WP_REST_Response([
                                'status' => false,
                                $result,
                                "percent" => 75
                        ], 200);
                    }
                } elseif (UserModel::setting("check_card_with_national_code_jibit") === true) {
                    $endpoint = '/services/matching';
                    $res = $jbt->api_request('GET', $endpoint, [
                            'cardNumber' => $cartNumber,
                            'nationalCode' => $nationalCode,
                            'birthDate' => $year . $month . $day
                    ], null, true);
                    if ($res['code'] !== 200) {
                        return new \WP_REST_Response([
                                'status' => false,
                                'message' => $res['body']['message'],
                                "percent" => 75
                        ], 200);
                    }
                }
                $user_id = get_current_user_id();
                global $wpdb;
                $db = Db::getLnstance();
                $records = UserModel::table('user_bank_cards', 'card_number_enc', encrypt_data($cartNumber), 'is_active', 0);
                $hash = generateHash();
                if (!empty($records)) {
                    $db->modify("DELETE FROM `{$wpdb->prefix}user_bank_cards` WHERE `id` = :id", array("id" => $records['id']));
                }
                $db->insert("INSERT INTO `{$wpdb->prefix}user_bank_cards` (`user_id`,`hash`, `card_number_enc`, `card_last4`, `phone`, `birth_date`, `national_code`,`first_name` ,`last_name`, `is_active`, `ip`, `created_at`) VALUES (:user_id, :hash,:card_number, :card_last4, :phone, :birth_date,:national_code,:first_name,:last_name,0,:ip,:created_at)", array(
                        'user_id' => $user_id,
                        'card_number' => encrypt_data($cartNumber),
                        'first_name' => $firstName,
                        'last_name' => $lastName,
                        'card_last4' => substr($cartNumber, -4),
                        'phone' => encrypt_data($phoneNumber),
                        'birth_date' => encrypt_data($birthDate),
                        'national_code' => encrypt_data($nationalCode),
                        'ip' => encrypt_data(giftmax_get_user_ip()),
                        'created_at' => date('Y-m-d H:i:s'),
                        'hash' => $hash
                ));
                $otp = mt_rand(100000, 999999);
                $expiry = date("Y-m-d H:i:s", strtotime("+20 minutes"));
                UserModel::expiryEnd();
                $records = UserModel::exitOtp($phoneNumber);
                if (!empty($records) && strtotime($records['otp_expiry']) < time()) {
                    UserModel::otpDelete($records['id']);
                }
                if (empty($records)) {
                    UserModel::otp($phoneNumber, $otp, $expiry);
                }
                $url = "https://portal.avanak.ir/rest/SendOTP";
                $url = $url . "?" . "Token=" . urlencode("1ACAAF7BC85B6AB3B54E5381A72EDCDC67D7BF06");
                $url = $url . "&" . "Length=6";
                $url = $url . "&" . "Number=" . $phoneNumber;
                $url = $url . "&" . "OptionalCode=" . $otp;

                $json = file_get_contents($url);
                if ($json->ErrorCode == 0) {
                    echo json_encode(["status" => true, "percent" => 90, 'html' => '<div class="Hint--primary-mwFS2H Hint__padding-nRd4K4 radius Hint__iconStart-bpg5ZO mb-3" data-testid="hint-wrapper"><div class="d-flex ai-center"><div class="d-flex Hint__titleSlot-yPP6H0" data-testid="icon-wrapper"><svg style="width: 24px; height: 24px; fill: #1ab1d4;"><path d="M2 12c0 5.523 4.477 10 10 10s10-4.477 10-10c0-5.523-4.477-10-10-10s-10 4.477-10 10zM12 7c0.552 0 1 0.448 1 1s-0.448 1-1 1c-0.552 0-1-0.448-1-1s0.448-1 1-1zM10 10h3v7h-2v-5h-1v-2z"></path></svg></div><span class="mr-2 text-body-1 color-brand-primary-700 Hint__padding--title-AHG0eM">کد تأیید شما به شماره &lrm;' . $phoneNumber . '&rlm; ارسال گردید. خواهشمندیم برای تکمیل مراحل، آن را در محل تعیین&zwnj;شده وارد فرمایید. </span></div></div><p class="mb-2 color-n-700 text-body-1 mb-2" data-testid="form-label">کد otp را وارد کنید</p><div class="_wrap_87tyg_1 _input_pjp0p_66"> <input type="text" class="_input_87tyg_11" data-method="order" name="otp" inputmode="numeric"> <div class="_digit_87tyg_33"><span></span></div> <div class="_digit_87tyg_33"><span></span></div> <div class="_digit_87tyg_33"><span></span></div> <div class="_digit_87tyg_33"><span></span></div> <div class="_digit_87tyg_33"><span></span></div> <div class="_digit_87tyg_33"><span></span></div> </div><input class="hidden" type="hidden" name="hash" value="' . encrypt_data($dataAjax[0] . "||" . 'otp||' . $hash) . '">']);
                } else {
                    echo json_encode(["status" => false, "message" => "خطایی پیش آمده", "percent" => 0]);
                }
            }
        }
    }

    public function addCart_api_function()
    {
        if (!is_valid_card_number($_POST['value'])) {
            echo json_encode([
                    'status' => false,
                    'message' => 'اطلاعات وارد شده معتبر نیست'
            ]);
            exit;
        }
        $userID = get_current_user_id();
        global $wpdb;
        $db = Db::getLnstance();
        $is_exist = $db->first("SELECT * FROM `{$wpdb->prefix}user_bank_cards` WHERE `user_id`=:user_id AND `card_number_enc` =:card_number_enc", array('user_id' => $userID, 'card_number_enc' => encrypt_data($_POST['value'])));
        if (is_array($is_exist) && !empty($is_exist) && $is_exist['is_active'] == 1) {
            echo json_encode([
                    'status' => false,
                    'message' => 'شماره کارت وجود دارد!'
            ]);
            exit();
        }
        global $wpdb;
        $db = Db::getLnstance();
        if (is_array($is_exist) && !empty($is_exist) && $is_exist['is_active'] == 0) {
            if (empty($is_exist['phone'])) {
                $phoneNumber = get_userdata($userID)->user_login;
            } else {
                $phoneNumber = decrypt_data($is_exist['phone']);
            }
            $otp = mt_rand(100000, 999999);
            $expiry = date("Y-m-d H:i:s", strtotime("+2 minutes"));
            UserModel::expiryEnd();
            $records = UserModel::exitOtp($phoneNumber);
            if (!empty($records) && strtotime($records['otp_expiry']) < time()) {
                UserModel::otpDelete($records['id']);
            }
            if (empty($records)) {
                UserModel::otp($phoneNumber, $otp, $expiry);
            }
            $url = "https://portal.avanak.ir/rest/SendOTP";
            $url = $url . "?" . "Token=" . urlencode("1ACAAF7BC85B6AB3B54E5381A72EDCDC67D7BF06");
            $url = $url . "&" . "Length=6";
            $url = $url . "&" . "Number=" . $phoneNumber;
            $url = $url . "&" . "OptionalCode=" . $otp;

            $json = file_get_contents($url);
            if ($json->ErrorCode != 0) {
                echo json_encode(["status" => false, "message" => "خطایی پیش آمده در ارسال OTP", "percent" => 90]);
            }
            if (empty($is_exist['phone'])) {
                return [
                        'status' => true,
                        'verify' => true,
                        'hash' => $is_exist['hash']
                ];
            } else {
                return [
                        'status' => true,
                        'verify' => true,
                        'drg' => encrypt_data($is_exist['hash'])
                ];
            }
        } else {
            $token = 'd5497c98fc9a28300406dd8ee66bac5b531fc598';
            $user = UserModel::table('user_identity', 'user_id', $userID);
            if (UserModel::setting("check_card_with_national_code_zohal") === true) {
                $result = v1::callZohalService(
                        'https://service.zohal.io/api/v0/services/inquiry/check_card_with_national_code',
                        [
                                'birth_date' => fa_to_en_numbers(decrypt_data($user['birth_date_enc'])),
                                'card_number' => $_POST['value'],
                                'national_code' => fa_to_en_numbers(decrypt_data($user['national_id_enc']))
                        ],
                        $token
                );

            } elseif (UserModel::setting("check_card_with_national_code_jibit") === true) {
                $jbt = Jibit::getLnstance();
                $endpoint = '/services/matching';
                $birthDate = fa_to_en_numbers(decrypt_data($user['birth_date_enc']));
                $res = $jbt->api_request('GET', $endpoint, [
                        'cardNumber' => $_POST['value'],
                        'birthDate' => str_replace('/', '', $birthDate),
                        'nationalCode' => fa_to_en_numbers(decrypt_data($user['national_id_enc']))
                ], null, true);
                if ($res['code'] == 200) {
                    $result['status'] = true;
                } else {
                    $result['status'] = false;
                }
            } else {
                $result['status'] = false;
            }
            if ($result['status']) {
                $hash = generateHash();
                $db->insert("INSERT INTO `{$wpdb->prefix}user_bank_cards` (`user_id`,`hash`, `card_number_enc`, `card_last4`, `is_active`,`ip`,`created_at`) VALUES (:user_id,:hash ,:card_number, :card_last4, :is_active,:ip,:created_at)", array(
                        'user_id' => $userID,
                        'hash' => $hash,
                        'card_number' => encrypt_data($_POST['value']),
                        'card_last4' => substr($_POST['value'], -4),
                        'is_active' => 0,
                        'ip' => encrypt_data(giftmax_get_user_ip()),
                        'created_at' => date('Y-m-d H:i:s'),
                ));
                $phoneNumber = get_userdata($userID)->user_login;
                $otp = mt_rand(100000, 999999);
                $expiry = date("Y-m-d H:i:s", strtotime("+2 minutes"));
                UserModel::expiryEnd();
                $records = UserModel::exitOtp($phoneNumber);
                if (!empty($records) && strtotime($records['otp_expiry']) < time()) {
                    UserModel::otpDelete($records['id']);
                }
                if (empty($records)) {
                    UserModel::otp($phoneNumber, $otp, $expiry);
                }
                $url = "https://portal.avanak.ir/rest/SendOTP";
                $url = $url . "?" . "Token=" . urlencode("1ACAAF7BC85B6AB3B54E5381A72EDCDC67D7BF06");
                $url = $url . "&" . "Length=6";
                $url = $url . "&" . "Number=" . $phoneNumber;
                $url = $url . "&" . "OptionalCode=" . $otp;

                $json = file_get_contents($url);
                if ($json->ErrorCode != 0) {
                    echo json_encode(["status" => false, "message" => "خطایی پیش آمده در ارسال otp", "percent" => 90]);
                }
                return [
                        'status' => true,
                        'verify' => true,
                        'hash' => $hash
                ];
            }
            return [
                    'status' => true,
                    'verify' => false,
                    'card_number' => encrypt_data($_POST['value']),
            ];
        }
    }

    public function pupCart_api_function()
    {
        if (!is_user_logged_in()) {
            return [
                    'status' => false,
                    'message' => 'ابتدا وارد شوید',
                    'url' => home_url('/login-register')
            ];
        }
        ob_start();
        if (null === WC()->session) WC()->initialize_session();
        if (null === WC()->customer) WC()->customer = new \WC_Customer(get_current_user_id(), true);
        if (null === WC()->cart) WC()->cart = new \WC_Cart();
        ?>
        <div class="<?= WC()->cart && WC()->cart->get_cart() && is_user_logged_in() ? 'cart-preview__grid cart-preview__grid--board ' : '' ?> cart-panel ">
            <?php

            if (WC()->cart && WC()->cart->get_cart() && is_user_logged_in()) {

                $cart_items = WC()->cart->get_cart();
                ?>
                <div class="flex flex-col lg:w-70 justify-between md:h-stretch">
                    <div class="flex md:h-380">
                        <div class="cart-panel--list">
                            <div>
                                <div class="flex justify-between">
                                    <div class="act-our-services-carousel-head-title">
                                        <div class="act-our-services-carousel-head-title-divs">
                                            <div class="act-our-services-carousel-head-title-div1 tsc54b"></div>
                                        </div>
                                        <div class="act-our-services-carousel-head-title-content">
                                            <h5>سبد <strong>خرید</strong></h5>
                                            <p class="tsc54">SHOPPING CART</p>
                                        </div>
                                    </div>
                                    <span class="SJf5GS"><?= (WC()->cart) ? WC()->cart->get_cart_contents_count() : 0 ?></span>
                                </div>
                                <div class="cart-list">
                                    <?php
                                    if (!isMobile()) {
                                        ?>
                                        <table class="cart-table">
                                            <thead>
                                            <tr>
                                                <th>محصول</th>
                                                <th>تعداد</th>
                                                <th>قیمت واحد</th>
                                                <th>جمع کل</th>
                                            </tr>
                                            </thead>
                                            <tbody>
                                            <?php
                                            foreach ($cart_items as $cart_item_key => $cart_item) {

                                                $product = $cart_item['data']; // آبجکت محصول
                                                $product_id = $product->get_id();
                                                $name = $product->get_name();
                                                $quantity = $cart_item['quantity'];
                                                $regular_price = $product->get_regular_price();
                                                $sale_price = $product->get_sale_price();
                                                $price = $product->get_price(); // قیمت نهایی
                                                $subtotal = $cart_item['line_subtotal']; // جمع جزء
                                                $total = $cart_item['line_total']; // جمع با تخفیف
                                                $thumbnail = $product->get_image(); // تصویر محصول (HTML)
                                                $permalink = $product->get_permalink();


                                                ?>
                                                <tr data-mini-item="<?= $cart_item_key ?>">
                                                    <td>
                                                        <div class="flex">
                                                            <div class="self-center">
                                                                <a class="font-size-14 text-dark font-bold tracking-tight leading-xs"
                                                                   href="<?= $permalink ?>"><?= $name ?></a></div>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <div class="rounded bg-light flex flex-row-reverse transition-opacity h-40 w-112">
                                                            <button type="button" class="pl-6 mini-quantity__btn"
                                                                    data-mini-decrease="">
                                                                <?php
                                                                if ($quantity == 1) {
                                                                    ?>
                                                                    <i class="icon-delete text-xs text-red-dark text-opacity-90 bg-white shadow-sm block text-center rounded-sm w-28 h-28 !leading-[28px]"></i>
                                                                    <?php
                                                                } else {
                                                                    ?>
                                                                    <i class="icon-minus text-[9px] text-gray pt-1 bg-white shadow-sm block text-center rounded-sm w-28 h-28 !leading-[28px]"></i>

                                                                    <?php
                                                                }
                                                                ?>
                                                            </button>
                                                            <div class="grow text-center flex flex-col justify-center leading-1">
                                                                <div class="pt-2 text-dark font-bold tracking-tighter text-sm after:loading after:border-blue transition-colors after:text-3xs"
                                                                     data-mini-qty><?= $quantity ?></div>
                                                            </div>
                                                            <button type="button" class="pr-6 mini-quantity__btn"
                                                                    data-mini-increase="">
                                                                <i class="bg-white shadow-sm text-gray rounded-sm icon-plus text-[9px] block text-center pt-1 w-28 h-28 !leading-[28px]"></i>
                                                            </button>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <div class="leading-1 pt-2 grow">
                                                            <?php
                                                            if ($product->is_on_sale()) {
                                                                ?>
                                                                <span class="ml-6 font-size-13 text-sm font-bold text-red opacity-85 tracking-tighter mb-2 block line-through"><?= number_format_usd($regular_price) ?></span>
                                                                <?php
                                                            }
                                                            ?>
                                                            <div class="text-2xs font-size-13 text-gray font-medium tracking-tight"><span
                                                                        class="text-lg font-bold text-dark tracking-tighter pt-2 inline-block"><?= number_format_usd($product->is_on_sale() ? $sale_price : $regular_price) ?></span>
                                                                تومان
                                                            </div>
                                                        </div>
                                                    </td>
                                                    <?php
                                                    $regular_price = (float)$product->get_regular_price();
                                                    $quantity = (int)$cart_item['quantity'];

                                                    $price_original_total = $regular_price * $quantity;
                                                    $price_final_total = $cart_item['line_total'];
                                                    ?>
                                                    <td>
                                                        <div class="leading-1 pt-2 grow">
                                                            <?php
                                                            if ($price_original_total > $price_final_total) { ?>
                                                                <span class="ml-6 font-size-13text-sm font-bold text-red opacity-85 tracking-tighter mb-2 block line-through"><?= number_format_usd($price_original_total) ?></span>
                                                                <?php
                                                            }
                                                            ?>
                                                            <div class="text-2xs text-gray font-medium tracking-tight"><span
                                                                        class="font-size-13 text-lg font-bold text-dark tracking-tighter pt-2 inline-block"><?= number_format_usd($price_final_total) ?></span>
                                                                تومان
                                                            </div>
                                                        </div>
                                                    </td>
                                                </tr>
                                                <?php
                                            }
                                            ?>
                                            </tbody>
                                        </table>
                                        <?php
                                    } else {
                                        ?>
                                        <div class="cart-list">
                                            <?php
                                            foreach ($cart_items as $cart_item_key => $cart_item) {

                                                $product = $cart_item['data'];
                                                $name = $product->get_name();
                                                $permalink = $product->get_permalink();
                                                $thumbnail = $product->get_image(); // تصویر محصول (HTML)

                                                ?>
                                                <div class="p-20 border-b border-gray-300 last:!border-b-0"
                                                     data-mini-item="<?= $cart_item_key ?>">
                                                    <div class="flex">
                                                        <div class="pt-4 self-center grow pl-12">
                                                            <a class="text-normal text-dark font-bold tracking-tight leading-xs block"
                                                               href="<?= $permalink ?>"><?= $name ?></a>
                                                            <div class="leading-xs mt-6 space-y-5"></div>
                                                        </div>
                                                        <a class="shrink-0" href="<?= $permalink ?>">
                                                            <div class="relative">
                                                                <img alt="<?= $name ?>" loading="lazy" width="72"
                                                                     height="72" decoding="async" data-nimg="1"
                                                                     class="shrink-0 rounded block w-60"
                                                                     src="<?= wp_get_attachment_image_url($product->get_image_id(), 'product_discount') ?>"
                                                                     style="color: transparent;">
                                                            </div>
                                                        </a>
                                                    </div>
                                                    <div class="flex items-start mt-12">
                                                        <div class="leading-1 pt-2 grow self-center">
                                                            <?php
                                                            $regular_price = (float)$product->get_regular_price();
                                                            $quantity = (int)$cart_item['quantity'];

                                                            $price_original_total = $regular_price * $quantity;
                                                            $price_final_total = $cart_item['line_total'];
                                                            ?>
                                                            <div class="leading-1 pt-2 grow">
                                                                <?php
                                                                if ($price_original_total > $price_final_total) { ?>
                                                                    <span class="ml-6 font-size-13text-sm font-bold text-red opacity-85 tracking-tighter mb-2 block line-through"><?= number_format_usd($price_original_total) ?></span>
                                                                    <?php
                                                                }
                                                                ?>
                                                                <div class="text-2xs text-gray font-medium tracking-tight"><span
                                                                            class="font-size-13 text-lg font-bold text-dark tracking-tighter pt-2 inline-block"><?= number_format_usd($price_final_total) ?></span>
                                                                    تومان
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="rounded bg-light flex flex-row-reverse transition-opacity h-40 w-112"
                                                             style="width: 30% !important;">
                                                            <button type="button" class="pl-6 mini-quantity__btn"
                                                                    data-mini-decrease="">
                                                                <?php
                                                                if ($quantity == 1) {
                                                                    ?>
                                                                    <i class="icon-delete text-xs text-red-dark text-opacity-90 bg-white shadow-sm block text-center rounded-sm w-28 h-28 !leading-[28px]"></i>
                                                                    <?php
                                                                } else {
                                                                    ?>
                                                                    <i class="icon-minus text-[9px] text-gray pt-1 bg-white shadow-sm block text-center rounded-sm w-28 h-28 !leading-[28px]"></i>

                                                                    <?php
                                                                }
                                                                ?>
                                                            </button>
                                                            <div class="grow text-center flex flex-col justify-center leading-1">
                                                                <div class="pt-2 text-dark font-bold tracking-tighter text-sm after:loading after:border-blue transition-colors after:text-3xs"
                                                                     data-mini-qty><?= $quantity ?></div>
                                                            </div>
                                                            <button type="button" class="pr-6 mini-quantity__btn"
                                                                    data-mini-increase="">
                                                                <i class="bg-white shadow-sm text-gray rounded-sm icon-plus text-[9px] block text-center pt-1 w-28 h-28 !leading-[28px]"></i>
                                                            </button>
                                                        </div>
                                                    </div>
                                                </div>
                                                <?php
                                            }
                                            ?>
                                        </div>
                                        <?php
                                    }
                                    ?>
                                </div>
                            </div>
                            <div>
                                <div class="flex justify-between<?= !isMobile() ? '' : ' flex-col' ?>">
                                    <?php
                                    $total_points = 0;

                                    foreach (WC()->cart->get_cart() as $cart_item_key => $cart_item) {

                                        $product = $cart_item['data'];
                                        $quantity = $cart_item['quantity'];

                                        $settings = get_post_meta($product->get_id(), 'giftmax_box_setting', true);

                                        $item_points = empty($settings[0]['purchaseScore']) ? 0 : $settings[0]['purchaseScore'];

                                        $line_points = $item_points * $quantity;

                                        WC()->cart->cart_contents[$cart_item_key]['points'] = $line_points;

                                        $total_points += $line_points;
                                    }

                                    WC()->session->set('total_cart_points', $total_points);
                                    if (!isMobile()) {
                                        ?>
                                        <div class="cart-timer" role="status">
                                            <p class="eyebrow font-size-13">مهلت تکمیل خرید</p>
                                            <h3 class="cart-timer__value" data-cart-timer=""></h3>
                                        </div>
                                        <div class="cart__purchaseScore">
                                            <i class="icon-star"></i>
                                            شما بابت این خرید <strong class="font-bold"
                                                                      id="total_points"><?= number_format($total_points) ?>
                                                امتیاز</strong> دریافت میکنید!
                                        </div>
                                        <?php
                                    } else {
                                        ?>
                                        <div class="tracking-tight alert text-xs font-normal rounded-none px-16 lg:px-28 py-8 lg:py-12 flex items-center border-y border-dashed lg:mt-20 timerBox justify-between"
                                             style="background: linear-gradient(135deg, rgba(99, 102, 241, 0.08), rgba(139, 92, 246, 0.15)); border-color: rgb(203, 181, 255);">
                                            <p class="eyebrow font-size-13">مهلت تکمیل خرید</p>
                                            <h3 class="cart-timer__value" data-cart-timer=""></h3>
                                        </div>
                                        <div class="tracking-tight alert alert-primary bg-primary bg-opacity-[0.12] text-xs font-normal rounded-none px-16 lg:px-28 py-8 lg:py-12 flex items-center border-y border-primary border-dashed border-opacity-50 lg:mt-20 pointBox">
                                            <i class="icon-star text-[#D19411] text-xs ml-8 -mr-2"></i>
                                            <div class="grow pst-4 flex align-items-center">شما بابت این خرید <strong
                                                        class="font-bold"><?= number_format($total_points) ?></strong>
                                                دریافت میکنید!
                                            </div>
                                        </div>
                                        <?php
                                    }
                                    ?>
                                </div>
                            </div>
                        </div>
                        <div class="cart-panel--invoice">
                            <div class="act-our-services-carousel-head-title">
                                <div class="act-our-services-carousel-head-title-divs">
                                    <div class="act-our-services-carousel-head-title-div1 tsc54b"></div>
                                </div>
                                <div class="act-our-services-carousel-head-title-content">
                                    <h5>احراز <strong>هویت</strong></h5>
                                    <p class="tsc54">IDENTITY VERIFICATION</p>
                                </div>
                            </div>
                            <?php
                            $user = wp_get_current_user();
                            $u = UserModel::table('user_identity', 'user_id', $user->ID);
                            $isVip = (isset($u['account_type']) && $u['account_type'] === 'vip');
                            ?>
                            <div class="profile-content">
                                <div class="profile-section-container">
                                    <div class="profile-section c-box__info <?= $isVip ? 'w-full' : '' ?>">
                                        <div>IP<span><?= giftmax_get_user_ip() ?></span></div>
                                        <?php
                                        ?>
                                        <div>
                                            شماره تلفن
                                            <span><?= $user->user_login ?></span>
                                        </div>
                                        <div>
                                            تلفن ثابت
                                            <?php
                                            if (!empty($u['landline_phone'])) {
                                                ?>
                                                <span><?= decrypt_data($u['landline_phone']) ?></span>
                                                <?php
                                            } else {
                                                ?>
                                                <div class="Button-lp56">تایید تلفن ثابت</div>
                                                <?php
                                            }
                                            ?>
                                        </div>
                                        <div>
                                            کدملی<span><?= !empty($u['national_id_enc']) ? decrypt_data($u['national_id_enc']) : '' ?></span>
                                        </div>
                                        <div>تاریخ
                                            تولد<span><?= !empty($u['birth_date_enc']) ? decrypt_data($u['birth_date_enc']) : '' ?></span>
                                        </div>
                                        <div>سطح اکانت
                                            <?php
                                            if (isset($u['account_type']) && $u['account_type'] == 'vip') {
                                                ?>
                                                <span style="
    background-color: #ff9100;
    color: #FFF;
    padding: 0 10px;
    border-radius: 8px;
">ویژه</span>
                                                <?php
                                            } else {
                                                ?>
                                                <span style="background-color: #ff0000; color: #FFF; padding: 3px; border-radius: 8px; font-size: 12px; line-height: 1; display: flex; align-items: center;">معمولی</span>
                                            <?php }
                                            ?>
                                        </div>
                                    </div>
                                </div>

                                <script>
                                    window.vip = <?= $isVip ? 1 : 0; ?>;
                                </script>
                                <?php
                                global $wpdb;
                                $db = \Giftmax\Modules\Db::getLnstance();
                                $records = $db->first("SELECT * FROM `{$wpdb->prefix}setting` WHERE `meta_key`='stp'");
                                if (!empty($records)) {
                                    $record = json_decode($records['meta_value'], true);
                                    if ($isVip) {
                                        ?>
                                        <div class="profile-section-container">
                                            <div class="profile-section px-[16px]">
                                                <div class="flex justify-between">
                                                    <div class="flex justify-between lg:w-50">
                                                        <h5>امتیاز وفاداری </h5>
                                                        <p class="wejF5 profile-bpp"><?= number_format(UserModel::points()) ?></p>
                                                    </div>
                                                    <button class="Button-cc65 sdJHS56">
                                                        تبدیل به اعتبار
                                                    </button>
                                                </div>
                                            </div>
                                            <p class="profile-text-info"><?= 'هر' . number_format($record[0]['points']) . ' امتیاز معادل است با' . number_format($record[0]['toman']) ?></p>
                                        </div>

                                        <div class="profile-section-container mt-3">
                                            <div class="profile-section px-[16px]" style="margin-bottom: 0">
                                                <div class="flex justify-between align-items-center">
                                                    <div class="flex flex-col">
                                                        <h5>کیف پول</h5>
                                                    </div>
                                                    <button class="Button-oc64 sdJHS56">
                                                        افزایش
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                        <?php
                                    } else {
                                        ?>
                                        <div class="flex justify-between profile-section-container">
                                            <div class="lg:w-60">
                                                <div class="profile-section px-[10px]">
                                                    <div class="flex justify-between">
                                                        <div class="flex justify-between lg:w-50">
                                                            <h5>امتیاز </h5>
                                                            <p class="wejF5 profile-bpp"><?= number_format(UserModel::points()) ?></p>
                                                        </div>
                                                        <button class="Button-cc65 sdJHS56">
                                                            تبدیل به اعتبار
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="lg:w-40 mr-1">
                                                <div class="profile-section px-[10px]">
                                                    <div class="flex justify-between align-items-center">
                                                        <div class="flex flex-col">
                                                            <h5>کیف پول</h5>
                                                        </div>
                                                        <button class="Button-oc64 sdJHS56">
                                                            افزایش
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="profile-section-container">
                                            <p class="profile-text-info"><?= 'هر' . number_format($record[0]['points']) . ' امتیاز معادل است با' . number_format($record[0]['toman']) ?></p>
                                        </div>
                                        <?php
                                    }
                                }
                                if (!$isVip) {
                                    $db = Db::getLnstance();
                                    global $wpdb;
                                    $cards = $db->query(
                                            "SELECT * FROM `{$wpdb->prefix}user_bank_cards` WHERE `user_id` = :user_id AND `is_active`=1",
                                            array('user_id' => $user->ID)
                                    );
                                    ?>
                                    <div class="profile-section-container">
                                        <div class="card-grid card-grid--swiper profile-section"
                                             style="margin-bottom: 0">
                                            <duv class="flex justify-between">
                                                <div class="profile-section-section-name">
                                                    <div class="flex justify-between gap-2">
                                                        <span>کارت های بانکی</span>
                                                        <?php
                                                        if (!empty($cards) && count($cards) != 0) {
                                                            ?>
                                                            <p class="profile-bpp"><?= count($cards) ?></p>
                                                            <?php
                                                        } else {
                                                            ?>
                                                            <p class="profile-bpp">0</p>
                                                            <?php
                                                        }
                                                        ?>
                                                    </div>
                                                </div>
                                                <button class="Button-ac45">افزودن</button>
                                            </duv>
                                            <?php
                                            if (!empty($cards)) {
                                                ?>
                                                <div class="swiper bank-cards-swiper">
                                                    <div class="swiper-wrapper">
                                                        <?php foreach ($cards as $card) {
                                                            $cardNumber = rtrim(
                                                                    chunk_split(decrypt_data($card['card_number_enc']), 4, '-'),
                                                                    '-'
                                                            );
                                                            ?>
                                                            <div class="swiper-slide">
                                                                <article class="bank-card">
                                                                    <div class="bank-card-content">
                                                                        <div class="flex justify-end align-items-center">
                                                                            <div class="bank-card__top">
                                                                                <div class="bank-card__logo"
                                                                                     aria-hidden="true">
                                                                                    <img loading="lazy" decoding="async"
                                                                                         data-nimg="1" class="h-auto"
                                                                                         src="<?= detectBankImage(decrypt_data($card['card_number_enc'])) ?>"
                                                                                         style="color: transparent;width: 20px"
                                                                                         data-booster-processed="true">
                                                                                </div>
                                                                            </div>
                                                                            <div class="bank-card__number"><?= $cardNumber ?></div>
                                                                        </div>
                                                                        <?php
                                                                        if (empty($card['phone'])) {
                                                                            ?>
                                                                            <div class="flex justify-between align-items-center relative">
                                                                                <div class="bank-card_user_status success">
                                                                                    تحت مالکیت شما
                                                                                </div>
                                                                                <div class="w-[50px] lottie-container absolute -right-50"
                                                                                     data-lottie-url="<?= get_template_directory_uri() ?>/assets/img/wsl/card-done.json"></div>
                                                                            </div>
                                                                            <?php
                                                                        } else {
                                                                            ?>
                                                                            <div class="flex justify-between align-items-center relative">
                                                                                <div class="bank-card_user_status danger">
                                                                                    مالک شما نیستید
                                                                                </div>
                                                                                <div class="w-[50px] lottie-container absolute -right-50"
                                                                                     data-lottie-url="<?= get_template_directory_uri() ?>/assets/img/wsl/card-error.json"></div>
                                                                            </div>
                                                                        <?php }
                                                                        ?>
                                                                    </div>
                                                                    <div class="V10-3-Bank">
                                                                        <?php
                                                                        $cardSetting = detectBankImageBg($cardNumber, 'v1');
                                                                        if (empty($card['phone'])) {
                                                                            $user = get_userdata($card['user_id']);
                                                                            $userdata = UserModel::table('user_identity', 'user_id', $card['user_id']);
                                                                            ?>
                                                                            <span class="numberCard"
                                                                                  style="bottom: <?= $cardSetting['positionText'] ?>px;<?= !is_null($cardSetting['color']) ? "color:" . $cardSetting['color'] : '' ?>"><?= $cardNumber ?></span>
                                                                            <img alt="bank" loading="lazy"
                                                                                 src="<?= $cardSetting['img'] ?>">
                                                                            <span class="number-user"
                                                                                  style="bottom: <?= $cardSetting["Box"]["y"] ?>px;color:<?= $cardSetting["Box"]["color"] ?>"><?= $user->user_login ?></span>
                                                                            <span class="birthday-user"
                                                                                  style="bottom: <?= $cardSetting["Box"]["y"] ?>px;color:<?= $cardSetting["Box"]["color"] ?>"><?= decrypt_data($userdata['birth_date_enc']) ?></span>
                                                                            <span class="national__code-user"
                                                                                  style="bottom: <?= $cardSetting["Box"]["y"] ?>px;color:<?= $cardSetting["Box"]["color"] ?>"><?= decrypt_data($userdata['national_id_enc']) ?></span>
                                                                            <span class="full__name-user"
                                                                                  style="bottom: <?= $cardSetting["Box"]["y"] ?>px;color:<?= $cardSetting["Box"]["color"] ?>"><?= $user->first_name . ' ' . $user->last_name ?></span>

                                                                            <?php
                                                                        } else {
                                                                            ?>
                                                                            <span class="numberCard"
                                                                                  style="bottom: <?= $cardSetting['positionText'] ?>px;<?= !is_null($cardSetting['color']) ? "color:" . $cardSetting['color'] : '' ?>"><?= $cardNumber ?></span>
                                                                            <span class="number-user"
                                                                                  style="bottom: <?= $cardSetting["Box"]["y"] ?>px;color:<?= $cardSetting["Box"]["color"] ?>"><?= decrypt_data($card['phone']) ?></span>
                                                                            <span class="birthday-user"
                                                                                  style="bottom: <?= $cardSetting["Box"]["y"] ?>px;color:<?= $cardSetting["Box"]["color"] ?>"><?= decrypt_data($card['birth_date']) ?></span>
                                                                            <span class="national__code-user"
                                                                                  style="bottom: <?= $cardSetting["Box"]["y"] ?>px;color:<?= $cardSetting["Box"]["color"] ?>"><?= decrypt_data($card['national_code']) ?></span>
                                                                            <span class="full__name-user"
                                                                                  style="bottom: <?= $cardSetting["Box"]["y"] ?>px;color:<?= $cardSetting["Box"]["color"] ?>"><?= $card['first_name'] . ' ' . $card['last_name'] ?></span>
                                                                            <img alt="bank" loading="lazy"
                                                                                 src="<?= $cardSetting['img'] ?>">
                                                                        <?php }
                                                                        ?>
                                                                    </div>
                                                                </article>
                                                            </div>

                                                            <?php
                                                        } ?>
                                                    </div>
                                                </div>
                                                <?php
                                            } else {
                                                ?>
                                                <div class="flex justify-center align-items-center px-[10px]">
                                                    <div class="lottie-container w-[50px]"
                                                         data-lottie-url="<?= get_template_directory_uri() ?>/assets/img/wsl/card.json"></div>
                                                    <div class="text-body2-strong text-[#027275]">کارت بانکی ثبت نشده
                                                    </div>
                                                </div>
                                                <?php
                                            }
                                            ?>
                                        </div>
                                    </div>
                                    <?php
                                }
                                ?>
                            </div>
                        </div>
                    </div>
                    <div class="ktfb">
                        <h4>نکات مهم :</h4>
                        <p> 1. سبد خرید شما تا زمانی که پرداخت نهایی انجام نشه، قطعی رزرو نشده.لطفاً تا ۵ دقیقه آینده
                            سفارشتون رو تکمیل و پرداخت کنید، وگرنه آیتم‌های داخل سبد به صورت خودکار آزاد و حذف
                            می‌شن.</p>
                        <p> 2. در صورت تکمیل سفارش و انجام فرایند احراز هویت و تحویل محصول خریداری شده ،فاکتور قابل عودت
                            و برگشت به هیچ وجه ممکن نخواهد بود.</p>
                        <p>3. درصورت عودت هرگونه وجهی ، 10% ارزش افزوده از مبلغ واریزی کسر و باقیمانده مبلغ طی 24 ساعت
                            کاری به همان کارت بانکی که خرید شده است عودت خواهد شد.</p>
                    </div>
                </div>

                <div class="cart-panel--payment lg:w-30 md:h-stretch">
                    <div class="act-our-services-carousel-head-title">
                        <div class="act-our-services-carousel-head-title-divs">
                            <div class="act-our-services-carousel-head-title-div1 tsc54b"></div>
                        </div>
                        <div class="act-our-services-carousel-head-title-content">
                            <h5><strong>پرداخت</strong></h5>
                            <p class="tsc54">PAYMENT</p>
                        </div>
                    </div>
                    <div class="flex justify-between" style="margin: 21px 0">
                        <button class="payment active Button-pr44">
                            <div>پرداخت ریالی</div>
                        </button>
                        <button class="payment Button-pu44">
                            <div>پرداخت با رمز ارز ها</div>
                        </button>
                    </div>
                    <div class="invoice-board">
                        <div class="flex flex-col relative grow">
                            <div class="grow before:loading">
                                <div class="space-y-10 lg:space-y-12 lg:sticky lg:top-28">
                                    <?php
                                    $cart_product_discount = 0;

                                    foreach (WC()->cart->get_cart() as $cart_item) {
                                        $product = $cart_item['data'];
                                        $qty = (int)$cart_item['quantity'];
                                        $regular_price = (float)$product->get_regular_price();
                                        $line_total = $cart_item['line_total'];

                                        $cart_product_discount += ($regular_price * $qty) - $line_total;
                                    }

                                    $total_discount = $cart_product_discount;
                                    ?>
                                    <div class="flex items-center leading-xs"><span
                                                class="grow text-xs tracking-tight font-medium text-dark">قیمت کل</span>
                                        <div class="text-2xs text-gray font-medium tracking-tight"
                                             data-summary="subtotal">
                                                <span
                                                        class="text-larger font-bold text-dark tracking-tighter pt-2 inline-block"><?= number_format_usd(WC()->cart->get_subtotal() + $total_discount) ?></span>
                                            تومان
                                        </div>
                                    </div>
                                    <div class="flex items-center leading-xs"><span
                                                class="grow text-xs tracking-tight font-medium text-dark">تخفیف سبد خرید</span>
                                        <div class="text-2xs text-gray font-medium tracking-tight"
                                             data-summary="discount">
                                            <span class="text-larger font-bold text-red tracking-tighter pt-2 inline-block"><?= number_format_usd($total_discount) ?></span>
                                            تومان
                                        </div>
                                    </div>
                                    <div class="flex items-center leading-xs">
                                        <div class="grow">
                                            <span class="block text-xs tracking-tight font-medium text-dark">کد تخفیف</span>
                                        </div>
                                        <button type="button"
                                                class="btn !w-28 !text-5xs !text-green-dark !pt-2 !h-28 btn-white btn-icon icon-plus relative Button-cc59"
                                                aria-label="افزودن کد تخفیف"></button>
                                    </div>
                                    <div class="flex items-center leading-xs justify-between Box-cs65">
                                        <div class="flex flex-col">
                                            <span class="grow text-xs tracking-tight font-medium text-dark pt-1">استفاده از کیف پول</span>
                                            <span id="balance"
                                                  class="grow text-xs tracking-tight font-medium text-dark pt-1 <?= empty(UserModel::wallet()) || !empty(UserModel::wallet()) && UserModel::wallet() == 0 ? 'hidden' : '' ?>"
                                                  style=" color: #a7a7a7; font-size: 12px; "><?= number_format(UserModel::wallet()) ?> تومان</span>
                                        </div>
                                        <div class="text-2xs text-gray font-medium tracking-tight">
                                            <label for="wallet" class="input-label start w40_1">
                                                <span class="start-label"></span>
                                                <?php
                                                if (!empty(UserModel::wallet()) && UserModel::wallet() != 0) {
                                                    ?>
                                                    <input id="wallet" type="checkbox"
                                                           class="input" <?= WC()->session->get('use_wallet', false) ? 'checked' : '' ?>>
                                                    <?php
                                                }
                                                ?>
                                                <span class="input-check"
                                                      style="<?= empty(UserModel::wallet()) || !empty(UserModel::wallet()) && UserModel::wallet() == 0 ? 'cursor: no-drop;' : '' ?>"></span>
                                            </label>
                                        </div>
                                    </div>
                                    <div class="hr-p"></div>
                                    <div class="flex items-center leading-xs"><span
                                                class="grow text-xs tracking-tight font-medium text-dark pt-1">مبلغ قابل پرداخت</span>
                                        <div class="text-2xs text-gray font-medium tracking-tight" data-summary="total">
                                            <span class="text-lg font-bold text-green-dark tracking-tighter pt-2 inline-block"><?= number_format_usd(WC()->cart->get_total('edit')) ?></span>
                                            تومان
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="border rounded mt-14 lg:mt-16 gateway-row flex">
                                <button type="button"
                                        class="border-l w-full text-right border-gray-300 last:!border-l-0 py-16 px-14 flex items-center Button-p4"
                                        data-gateway="zibal">
                                    <div class="pt-2 grow leading-1 tracking-tight">
                                        <span class="block text-xs text-dark font-bold">پرداخت آنلاین</span>
                                        <span class="block text-2xs font-normal text-dark mt-8">درگاه پرداخت زیبال</span>
                                    </div>
                                    <i class="w-20 h-20 text-center rounded-circle text-4xs pl-1 ml-4 !leading-[22px] icon-check transition-colors text-white bg-green bg-opacity-100"></i>
                                </button>
                                <button type="button"
                                        class="border-l w-full text-right border-gray-300 last:!border-l-0 py-16 px-14 flex items-center Button-p4"
                                        data-gateway="paystar">
                                    <div class="pt-2 grow leading-1 tracking-tight">
                                        <span class="block text-xs text-dark font-bold">پرداخت آنلاین</span>
                                        <span class="block text-2xs font-normal text-dark mt-8">درگاه پرداخت پی استار</span>
                                    </div>
                                    <i class="w-20 h-20 text-center rounded-circle bg-gray bg-opacity-15 text-4xs pl-1 ml-4 !leading-[22px] icon-check text-transparent transition-colors"></i>
                                </button>
                            </div>
                            <div class="css-transition-opacity after:loading !absolute inset-x-0 inset-y-0 bg-white bg-opacity-50 is-loading after:border-gray after:border-opacity-75 after:h-24 after:w-24 after:border-[3px] z-10 rounded-bl-lg"></div>
                        </div>
                    </div>
                    <div class="swiper supported__brands hidden">
                        <div class="swiper-wrapper">
                            <div class="swiper-slide">
                                <img alt="" loading="lazy" width="1000" height="120" decoding="async"
                                     data-nimg="1" class="block dark:hidden" style="color:transparent"
                                     src="<?= get_template_directory_uri() ?>/assets/img/assets.jpeg"></div>
                            <div class="swiper-slide">
                                <img alt="" loading="lazy" width="1000" height="120" decoding="async"
                                     data-nimg="1" class="block dark:hidden" style="color:transparent"
                                     src="<?= get_template_directory_uri() ?>/assets/img/assets.jpeg"></div>
                            <div class="swiper-slide">
                                <img alt="" loading="lazy" width="1000" height="120" decoding="async"
                                     data-nimg="1" class="block dark:hidden" style="color:transparent"
                                     src="<?= get_template_directory_uri() ?>/assets/img/assets.jpeg"></div>
                            <div class="swiper-slide">
                                <img alt="" loading="lazy" width="1000" height="120" decoding="async"
                                     data-nimg="1" class="block dark:hidden" style="color:transparent"
                                     src="<?= get_template_directory_uri() ?>/assets/img/assets.jpeg"></div>
                        </div>
                    </div>
                    <button class="btn btn--gradient btn--block Button-pcu48">ثبت سفارش</button>
                    <p class="payment--alert">کاربر گرامی <?= "$user->first_name $user->last_name" ?> ، خواهشمند است در
                        هنگام پرداخت دقت فرمایید؛ زیرا جنس و کد دریافتی تحت هیچ شرایطی قابل عودت نمی‌باشد.</p>
                </div>
                <?php
            } else {
                if (!is_user_logged_in()) {
                    echo "<div class='flex mx-auto'><span>برای دسترسی به سبد خرید لاگین کنید</span></div>";
                } else if (empty(WC()->cart) || empty(WC()->cart->get_cart())) {
                    echo "<div class='flex mx-auto'><span>سبد خرید شما خالی است</span></div>";
                }
            }
            ?>
        </div>
        <?php
        $output = ob_get_clean();
        return [
                'status' => true,
                'html' => $output,
                'empty' => empty(WC()->cart) || empty(WC()->cart->get_cart()) ? true : false,
                'v' => $isVip ? 1 : 0
        ];
    }

    public function updateCartQty_api_function(\WP_REST_Request $request)
    {
        if (is_user_blocked()) {
            return wp_send_json_error(['message' => 'شما بلاک شده اید']);
        }

        if (UserModel::setting("buy") === false) {
            return wp_send_json_error(['message' => 'خرید از سایت فعلا غیر فعال میباشد']);
        }

        if (null === WC()->session) WC()->initialize_session();
        if (null === WC()->customer) WC()->customer = new \WC_Customer(get_current_user_id(), true);
        if (null === WC()->cart) WC()->cart = new \WC_Cart();

        WC()->cart->get_cart();
        WC()->cart->calculate_totals();

        $product_id = absint($_POST['product_id'] ?? 0);
        $quantity = max(0, absint($_POST['quantity'] ?? 1));

        if (!$product_id) {
            return wp_send_json_error(['message' => 'محصول نامعتبر است']);
        }

        $cart_item_key = null;
        $cart_item = null;

        foreach (WC()->cart->get_cart() as $key => $item) {
            if ((int)$item['product_id'] === $product_id) {
                $cart_item_key = $key;
                $cart_item = $item;
                break;
            }
        }

        if (!$cart_item_key || !$cart_item) {
            return wp_send_json_error(['message' => 'محصول در سبد خرید وجود ندارد']);
        }

        $current_qty = (int)$cart_item['quantity'];
        $delta = $quantity - $current_qty;

        $delivery = get_post_meta($product_id, 'delivery', true);

        if (isset($delivery['one']) && $delivery['one'] === 'on') {

            global $wpdb;
            $db = Db::getLnstance();
            if ($delta > 0) {

                $free_licences = $db->query("SELECT licence_id  FROM {$wpdb->prefix}product_licences WHERE product_id = :product_id AND licence_status = 'available' ORDER BY sort_order ASC", ['product_id' => $product_id]);

                if (!$free_licences) {
                    return wp_send_json_error(['message' => 'لایسنس فعالی وجود ندارد']);
                }
                if (count($free_licences) <= $current_qty) {
                    return \wp_send_json_error(['message' => 'در حال حاضر لایسنس فعالی موجود نیست.']);
                }
                if (count($free_licences) < $delta) {
                    return wp_send_json_error(['message' => 'این تعداد لایسنس در حال حاضر موجود نیست']);
                }
                WC()->session->set('cart', WC()->cart->cart_contents);
            }
            if ($quantity <= 0) {
                WC()->cart->remove_cart_item($cart_item_key);
                $item_removed = true;
            }
        } else {
            if ($quantity <= 0) {
                WC()->cart->remove_cart_item($cart_item_key);
                $item_removed = true;
            }
        }

        WC()->cart->set_quantity($cart_item_key, $quantity);
        $cart_product_discount = 0;
        $cart_items = [];
        $subtotal = 0; // بدون تخفیف
        $total = 0; // نهایی
        $discount = 0;
        foreach (WC()->cart->get_cart() as $cart_item) {
            $product = $cart_item['data'];
            if ($cart_item['product_id'] == $product_id) {
                $price_original_total = (float)$product->get_regular_price() * $quantity;
                $price_final_total = $cart_item['line_total'];
            }
            $qty = (int)$cart_item['quantity'];
            $regular_price = (float)$product->get_regular_price();
            $line_total = $cart_item['line_total'];

            $cart_product_discount += ($regular_price * $qty) - $line_total;
            $line_subtotal = (float)$cart_item['line_subtotal'];

            $total += $line_total;

            $cart_items[] = [
                    'product_id' => $cart_item['product_id'],
                    'url' => get_permalink($cart_item['product_id']),
                    'name' => $product->get_name(),
                    'qty' => $cart_item['quantity'],
                    'price_regular' => number_format_usd($regular_price * (int)$cart_item['quantity']),
                    'price_sale' => number_format_usd($cart_item['line_total']),
                    'image' => $product->get_image_id()
                            ? wp_get_attachment_image_url($product->get_image_id(), 'product_discount')
                            : wc_placeholder_img_src(),
            ];
        }
        $coupon_discount_total = WC()->cart->get_discount_total();
        $total_discount = $cart_product_discount + $coupon_discount_total;
        $is_cart_empty = WC()->cart->is_empty();
        $total_points = 0;

        foreach (WC()->cart->get_cart() as $cart_item_key => $cart_item) {

            $product = $cart_item['data'];
            $quantity = $cart_item['quantity'];

            $settings = get_post_meta($product->get_id(), 'giftmax_box_setting', true);

            $item_points = empty($settings[0]['purchaseScore']) ? 0 : $settings[0]['purchaseScore'];

            $line_points = $item_points * $quantity;

            WC()->cart->cart_contents[$cart_item_key]['points'] = $line_points;

            $total_points += $line_points;
        }

        WC()->session->set('total_cart_points', $total_points);
        return \wp_send_json_success([
                'message' => $item_removed
                        ? ($is_cart_empty ? 'سبد خرید خالی شد' : 'محصول حذف شد')
                        : 'سبد خرید بروزرسانی شد',

                'action' => $item_removed
                        ? ($is_cart_empty ? 'cart_empty' : 'item_removed')
                        : 'qty_updated',
                'cart_item_key' => $cart_item_key,
                'new_quantity' => $quantity,
                'total_points' => $total_points,
                'item' => [
                        'final_total' => number_format_usd($price_final_total),
                        'original_total' => $price_original_total > $price_final_total
                                ? number_format_usd($price_original_total)
                                : null
                ],
                'mini' => [
                        'items_count' => WC()->cart->get_cart_contents_count(),
                        'subtotal' => number_format_usd(WC()->cart->get_subtotal() + $cart_product_discount),
                        'discount' => number_format_usd($cart_product_discount),
                        'total' => number_format_usd($total),
                        'totalUSD' => ($total),
                        'items' => $cart_items
                ],
                'cart' => [
                        'subtotal' => $_POST['gateway'] == 'r' ? number_format_usd(WC()->cart->get_subtotal()) : number_format(WC()->cart->get_subtotal()),
                        'total' => $_POST['gateway'] == 'r' ? number_format_usd(WC()->cart->get_total('edit')) : WC()->cart->get_total('edit'),
                        'discount' => $_POST['gateway'] == 'r' ? number_format_usd($total_discount) : number_format($total_discount)
                ]
        ]);
    }

    public function getCart_api_function()
    {
        if (is_user_logged_in()) {
            if (null === WC()->session) {
                WC()->session = new \WC_Session_Handler();
                WC()->session->init();
            }


            // Cart
            if (null === WC()->cart) {
                WC()->cart = new \WC_Cart();
            }
            WC()->cart->get_cart();
            if (WC()->cart && WC()->cart->get_cart()) {
                ob_start();
                $cart_items = WC()->cart->get_cart();
                ?>
                <div class="cart--list mb-auto">
                    <?php
                    $total_points = 0;

                    foreach ($cart_items as $cart_item_key => $cart_item) {
                        $product = $cart_item['data'];
                        $date_from = $product->get_date_on_sale_from();
                        $date_to = $product->get_date_on_sale_to();
                        $regular_price = (float)$product->get_regular_price();
                        $quantity = (int)$cart_item['quantity'];

                        $price_original_total = $regular_price * $quantity;
                        $price_final_total = $cart_item['line_total'];

                        $settings = get_post_meta($product->get_id(), 'giftmax_box_setting', true);
                        if ($product->is_on_sale() & ($date_from || $date_to)) {
                            $sale_to = $product->get_date_on_sale_to();
                            $sale_to_ts = $sale_to ? $sale_to->getTimestamp() : null;
                        } else {
                            $sale_to_ts = null;
                        }

                        $settings = get_post_meta($product->get_id(), 'giftmax_box_setting', true);

                        $item_points = empty($settings[0]['purchaseScore']) ? 0 : $settings[0]['purchaseScore'];

                        $line_points = $item_points * $quantity;

                        WC()->cart->cart_contents[$cart_item_key]['points'] = $line_points;

                        $total_points += $line_points;
                        ?>
                        <div class="px-16 lg:px-28 pb-16 lg:pb-20 lg:mb-16 mb-12 border-b border-gray-300 last:!mb-0 last:!pb-0 last:!border-0 pt-4">
                            <div class="flex">
                                <div class="pt-4 self-center grow pl-12">
                                    <a class="text-sm text-dark font-bold tracking-tight leading-xs block"
                                       href="<?= $product->get_permalink() ?>"><?= $product->get_name() ?></a>
                                    <div class="flex items-start mt-10">
                                        <div class="leading-1 pt-2 grow self-center">
                                            <?php
                                            if ($price_original_total > $price_final_total) { ?>
                                                <span class="text-sm font-bold text-red opacity-85 tracking-tighter mb-2 block line-through">
                                <?= number_format_usd($price_original_total) ?>
                            </span>
                                            <?php } ?>
                                            <div class="text-2xs text-gray font-medium tracking-tight">
                                                <span class="font-bold text-dark tracking-tighter pt-2 inline-block text-larger"><?= number_format_usd($price_final_total) ?></span>
                                                تومان
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <a class="shrink-0" href="<?= $product->get_permalink() ?>">
                                    <div class="relative">
                                        <?php
                                        $attachment_id = $product->get_image_id();
                                        $image_url = wp_get_attachment_url($attachment_id);
                                        ?>
                                        <img alt="<?= $product->get_name() ?>" loading="lazy" decoding="async"
                                             data-nimg="1" class="shrink-0 block w-90 rounded-sm"
                                             src="<?= $image_url ?>" style="color: transparent;">
                                    </div>
                                </a>
                            </div>
                        </div>
                        <?php
                    }
                    WC()->session->set('total_cart_points', $total_points);
                    ?>
                </div>
                <div class="tracking-tight alert alert-primary bg-primary bg-opacity-[0.12] text-xs font-normal rounded-none px-16 lg:px-28 py-8 lg:py-12 flex items-center border-y border-primary border-dashed border-opacity-50 mt-16 lg:mt-20">
                    <i class="icon-star text-[#D19411] text-xs ml-8 -mr-2"></i>
                    <div class="grow pst-4">شما بابت این خرید <strong class="font-bold"><?= $total_points ?>
                            امتیاز</strong> دریافت میکنید!
                    </div>
                </div>
                <div class="flex flex-col relative p-16 lg:p-28">
                    <div class="grow">
                        <div class="space-y-10 lg:space-y-12 lg:sticky lg:top-28">
                            <div class="flex items-center leading-xs"><span
                                        class="grow text-xs tracking-tight font-medium text-dark">قیمت کل</span>
                                <div class="text-2xs text-gray font-medium tracking-tight"><span
                                            class="text-larger font-bold text-dark tracking-tighter pt-2 inline-block"><?= number_format_usd(WC()->cart->get_subtotal()) ?></span>
                                    تومان
                                </div>
                            </div>
                            <?php
                            $cart_product_discount = 0;

                            foreach (WC()->cart->get_cart() as $cart_item) {
                                $product = $cart_item['data'];
                                $qty = (int)$cart_item['quantity'];
                                $regular_price = (float)$product->get_regular_price();
                                $line_total = $cart_item['line_total'];

                                $cart_product_discount += ($regular_price * $qty) - $line_total;
                            }

                            $total_discount = $cart_product_discount;
                            ?>
                            <div class="flex items-center leading-xs"><span
                                        class="grow text-xs tracking-tight font-medium text-dark">تخفیف سبد خرید</span>
                                <div class="text-2xs text-gray font-medium tracking-tight"><span
                                            class="text-larger font-bold text-red tracking-tighter pt-2 inline-block"><?= number_format_usd($total_discount) ?></span>
                                    تومان
                                </div>
                            </div>
                            <div class="flex items-center leading-xs">
                                <div class="grow">
                                    <span class="block text-xs tracking-tight font-medium text-dark">کد تخفیف</span>
                                </div>
                                <button type="button"
                                        class="btn !w-28 !text-5xs !text-green-dark !pt-2 !h-28 btn-white btn-icon icon-plus relative Button-cc59"
                                        aria-label="افزودن کد تخفیف"></button>
                            </div>
                            <div class="flex items-center leading-xs justify-between Box-cs65">
                                <div class="flex flex-col">
                                    <span class="grow text-xs tracking-tight font-medium text-dark pt-1">استفاده از کیف پول</span>
                                    <span class="grow text-xs tracking-tight font-medium text-dark pt-1 <?= empty(UserModel::wallet()) || !empty(UserModel::wallet()) && UserModel::wallet() == 0 ? 'hidden' : '' ?>"
                                          style=" color: #a7a7a7; font-size: 12px; "><?= number_format(UserModel::wallet()) ?> تومان</span>
                                </div>
                                <div class="text-2xs text-gray font-medium tracking-tight">
                                    <label for="walletApi" class="input-label start w40_1">
                                        <span class="start-label"></span>
                                        <?php
                                        if (!empty(UserModel::wallet()) && UserModel::wallet() != 0) {
                                            ?>
                                            <input id="walletApi" type="checkbox"
                                                   class="input" <?= WC()->session->get('use_wallet', false) ? 'checked' : '' ?>>
                                            <?php
                                        }
                                        ?>
                                        <span class="input-check"
                                              style="<?= empty(UserModel::wallet()) || !empty(UserModel::wallet()) && UserModel::wallet() == 0 ? 'cursor: no-drop;' : '' ?>"></span>
                                    </label>
                                </div>
                            </div>
                            <div class="hr-p"></div>
                            <div class="flex items-center leading-xs"><span
                                        class="grow text-xs tracking-tight font-medium text-dark pt-1">مبلغ قابل پرداخت</span>
                                <div class="flex flex-col align-items-end">
                                    <div class="text-2xs text-gray font-medium tracking-tight">
                            <span
                                    class="text-lg font-bold text-green-dark tracking-tighter pt-2 inline-block"
                                    data-summary="total"><?= number_format_usd(WC()->cart->get_total('edit')) ?></span>
                                        تومان
                                    </div>
                                    <div class="text-2xs text-gray font-medium tracking-tight">
                            <span
                                    class="text-lg font-bold text-green-dark tracking-tighter pt-2 inline-block"
                                    data-summary="dtotal"><?= number_format(WC()->cart->get_total('edit')) ?></span>
                                        دلار
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="border rounded mt-14 lg:mt-16">
                        <button type="button"
                                class="border-b w-full text-right border-gray-300 last:!border-b-0 py-16 px-14 flex items-center Button-p5"
                                data-gateway="zibal">
                            <div class="pt-2 grow leading-1 tracking-tight">
                                <span class="block text-xs text-dark font-bold">پرداخت آنلاین</span>
                                <span class="block text-2xs font-normal text-dark mt-8">درگاه پرداخت زیبال</span>
                            </div>
                            <i class="w-20 h-20 text-center rounded-circle text-4xs pl-1 ml-4 !leading-[22px] icon-check transition-colors text-white bg-green bg-opacity-100"></i>
                        </button>
                        <button type="button"
                                class="border-b w-full text-right border-gray-300 last:!border-b-0 py-16 px-14 flex items-center Button-p5"
                                data-gateway="paystar">
                            <div class="pt-2 grow leading-1 tracking-tight">
                                <span class="block text-xs text-dark font-bold">پرداخت آنلاین</span>
                                <span class="block text-2xs font-normal text-dark mt-8">درگاه پرداخت پی استار</span>
                            </div>
                            <i class="w-20 h-20 text-center rounded-circle bg-gray bg-opacity-15 text-4xs pl-1 ml-4 !leading-[22px] icon-check text-transparent transition-colors"></i>
                        </button>
                        <button type="button"
                                class="border-b w-full text-right border-gray-300 last:!border-b-0 py-16 px-14 flex items-center Button-p5"
                                data-gateway="Payment4">
                            <div class="pt-2 grow leading-1 tracking-tight">
                                <span class="block text-xs text-dark font-bold">پرداخت دلاری</span>
                                <span class="block text-2xs font-normal text-dark mt-8">Payment4</span>
                            </div>
                            <i class="w-20 h-20 text-center rounded-circle bg-gray bg-opacity-15 text-4xs pl-1 ml-4 !leading-[22px] icon-check text-transparent transition-colors"></i>
                        </button>
                    </div>
                    <div class="ktfb border-0">
                        <h4>نکات مهم :</h4>
                        <p> 1. سبد خرید شما تا زمانی که پرداخت نهایی انجام نشه، قطعی رزرو نشده.لطفاً تا ۵ دقیقه آینده
                            سفارشتون رو تکمیل و پرداخت کنید، وگرنه آیتم‌های داخل سبد به صورت خودکار آزاد و حذف
                            می‌شن.</p>
                        <p> 2. در صورت تکمیل سفارش و انجام فرایند احراز هویت و تحویل محصول خریداری شده ،فاکتور قابل عودت
                            و برگشت به هیچ وجه ممکن نخواهد بود.</p>
                        <p>3. درصورت عودت هرگونه وجهی ، 10% ارزش افزوده از مبلغ واریزی کسر و باقیمانده مبلغ طی 24 ساعت
                            کاری به همان کارت بانکی که خرید شده است عودت خواهد شد.</p>
                    </div>
                    <div class="css-transition-opacity after:loading !absolute inset-x-0 inset-y-0 bg-white bg-opacity-50 is-loading after:border-gray after:border-opacity-75 after:h-24 after:w-24 after:border-[3px] z-10 rounded-bl-lg"></div>
                </div>
                <?php
                $html = ob_get_clean(); // مهم
                return new \WP_REST_Response([
                        'status' => true,
                        'html' => $html
                ], 200);
            }
        } else {
            return new \WP_REST_Response([
                    'status' => true,
                    'redirect' => true,
                    'url' => home_url('/login-register')
            ], 200);
        }

    }

    public function compact_api_function()
    {
        ob_start();
        $term_id = $_POST['term_id'];
        $selected_region = $_POST['region'] ?? null; // ریجن انتخاب شده از درخواست

        $term = get_term($term_id, 'product_cat');

        if (is_wp_error($term) || !$term) {
            return new \WP_REST_Response([
                    'success' => false,
                    'html' => ''
            ], 400);
        }

        $term_name = $term->name;
        $extra_description = get_term_meta($term_id, 'extra_description', true);
        ?>
        <div class="grow overflow-hidden">
            <div class="relative flex flex-col h-full">
                <div class="flex items-start mb-1 shrink-0">
                    <div class="grow ml-12 pt-4 self-center">
                        <div class="text-normal font-bold text-dark leading-xs tracking-tighter"><?= $term_name ?></div>
                    </div>
                </div>
                <?php if (!empty($extra_description)): ?>
                    <div class="pb-20">
                        <div class="alert alert-sm alert-orange text-2xs leading-sm font-normal rounded-sm"><?= $extra_description ?></div>
                    </div>
                <?php endif; ?>
                <?php
                $region_args = [
                        'post_type' => 'product',
                        'posts_per_page' => -1,
                        'fields' => 'ids',
                        'tax_query' => [
                                [
                                        'taxonomy' => 'product_cat',
                                        'field' => 'term_id',
                                        'terms' => $term_id,
                                ]
                        ],
                        'meta_query' => [
                                [
                                        'key' => 'giftmax_box_setting',
                                        'compare' => 'EXISTS'
                                ]
                        ]
                ];

                $region_query = new \WP_Query($region_args);
                $regions = [];

                foreach ($region_query->posts as $pid) {
                    $settings = get_post_meta($pid, 'giftmax_box_setting', true);
                    if (!empty($settings[0]['logo_region'])) {
                        $regions[] = $settings[0]['logo_region'];
                    }
                }
                $regions = array_unique($regions);
                wp_reset_postdata();
                if (!$selected_region && !empty($regions)) {
                    $selected_region = $regions[0];
                }

                if (!empty($regions)):
                    ?>
                    <div class="relative before:absolute before:top-full before:hidden hover:before:block mb-6">
                        <button type="button"
                                class="btn border !bg-white rounded flex items-center !text-dark w-full py-11 lg:py-10 px-16">
                            <img alt="ریجن انتخاب شده" loading="lazy" width="20" height="20" decoding="async"
                                 data-nimg="1" class="w-18 lg:w-28 h-auto r-border-6"
                                 src="<?= get_template_directory_uri() . '/assets/flag/' . $selected_region ?>.svg"
                                 style="color: transparent;">
                            <span class="grow text-right">ریجن انتخاب شده: <?= regionPersian($selected_region) ?></span>
                            <i class="icon-angle-down text-5xs pts-4 px-2"></i>
                        </button>
                        <div class="dropdown-menu top-full w-full right-0 rounded bg-white transition-all z-50 mt-8 origin-top-right shadow-none border overflow-hidden">
                            <div class="grid grid-cols-2 gap-1">
                                <?php foreach ($regions as $r): ?>
                                    <button class="btn !bg-white rounded-none text-xs hover:bg-opacity-50 shadow-[-1px_0,0_1px] shadow-gray-300 flex items-center !text-dark w-full py-10 px-16 Button-cse54"
                                            data-region="<?= $r ?>">
                                        <span class="grow text-right"><?= regionPersian($r) ?></span>
                                        <img alt="ریجن انتخاب شده" loading="lazy" width="20" height="20"
                                             decoding="async" data-nimg="1" class="w-18 lg:w-28 h-auto r-border-6"
                                             src="<?= get_template_directory_uri() . '/assets/flag/' . $r ?>.svg"
                                             style="color: transparent;">
                                    </button>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>

                <?php
                $args = [
                        'post_type' => 'product',
                        'tax_query' => [
                                [
                                        'taxonomy' => 'product_cat',
                                        'field' => 'term_id',
                                        'terms' => $term_id,
                                ]
                        ],
                        'meta_query' => [
                                'relation' => 'OR',

                                [
                                        'key' => 'giftmax_setting_order',
                                        'compare' => 'EXISTS',
                                        'type' => 'NUMERIC',
                                ],

                                [
                                        'key' => 'giftmax_setting_order',
                                        'compare' => 'NOT EXISTS',
                                ],
                        ],


                        'orderby' => [
                                'meta_value_num' => 'ASC',
                                'date' => 'DESC',
                        ],
                        'order' => 'ASE',
                ];

                $query = new \WP_Query($args);
                if ($query->have_posts()):
                    $countAll = 0;
                    $countNotAvailable = 0;
                    ?>
                    <div class="pb-24 lg:pb-28 lg:pt-6">
                        <?php while ($query->have_posts()): $query->the_post();
                            global $product;
                            $countAll++;
                            $delivery = get_post_meta($product->get_id(), 'delivery', true);
                            $is_presale = isset($delivery['two']) && $delivery['two'] == 'on';
                            if (!$is_presale && !product_available($product->get_id())) {
                                $countNotAvailable++;
                                continue;
                            }
                            $regular = $product->get_regular_price();
                            $sale = $product->get_sale_price();
                            $final_price = $product->is_on_sale() && $sale > 0 ? $sale : $regular;
                            $product_id = $product->get_id();
                            $quantity = 0;
                            if (null === WC()->session) WC()->initialize_session();
                            if (null === WC()->cart) WC()->cart = new \WC_Cart();
                            if (WC()->cart) {
                                foreach (WC()->cart->get_cart() as $cart_item) {
                                    if ((int)$cart_item['product_id'] === (int)$product_id) {
                                        $quantity = (int)$cart_item['quantity'];
                                        break;
                                    }
                                }
                            }
                            ?>
                            <div class="pb-20 mb-20 border-b border-gray-300 last:!mb-0 last:!pb-0 last:!border-none"
                                 data-product-id="<?= $product->get_id() ?>">
                                <div class="">
                                    <div class="flex items-start">
                                        <div class="text-sm text-dark font-bold tracking-tight leading-[22px] grow"><?= get_the_title() ?></div>
                                    </div>
                                    <div class="flex items-center mt-6 min-h-[38px] justify-between">
                                        <?php if ($quantity > 0) : ?>
                                            <div class="rounded bg-light w-104 h-36 flex flex-row-reverse transition-opacity"
                                                 data-product-id="<?= $product_id ?>">
                                                <button type="button" class="pl-6 mini-quantity__btn"
                                                        data-ajax-mini-decrease>
                                                    <?php if ($quantity == 1): ?>
                                                        <i class="icon-delete text-xs text-red-dark text-opacity-90 bg-white shadow-sm block text-center rounded-sm w-28 h-28 !leading-[28px]"></i>
                                                    <?php else: ?>
                                                        <i class="icon-minus text-[9px] text-gray pt-1 bg-white shadow-sm block text-center rounded-sm w-28 h-28 !leading-[28px]"></i>
                                                    <?php endif; ?>
                                                </button>

                                                <div class="grow text-center flex flex-col justify-center leading-1">
                                                    <div class="pt-2 text-dark font-bold tracking-tighter text-sm"
                                                         data-ajax-mini-qty><?= $quantity ?></div>
                                                </div>

                                                <button type="button" class="pr-6 mini-quantity__btn"
                                                        data-ajax-mini-increase>
                                                    <i class="bg-white shadow-sm text-gray rounded-sm icon-plus text-[9px] block text-center pt-1 w-28 h-28 !leading-[28px]"></i>
                                                </button>
                                            </div>
                                        <?php else : ?>
                                            <button type="button"
                                                    class="btn-ajax after:border-blue Button-bfa48"
                                                    data-product-id="<?= $product_id ?>">
                                                افزودن به سبد
                                            </button>
                                        <?php endif; ?>
                                        <div class="leading-1 pt-2">
                                            <?php if ($product->is_on_sale()): ?>
                                                <span class="ml-6 text-sm font-bold text-red-darker opacity-85 tracking-tighter mb-2 block line-through"><?= number_format_usd($regular) ?></span>
                                            <?php endif; ?>
                                            <div class="text-2xs text-gray font-medium tracking-tight">
                                                <?php if ($final_price > 0): ?>
                                                    <span class="text-larger font-bold text-dark tracking-tighter pt-2 inline-block"><?= number_format_usd($final_price) ?></span> تومان
                                                <?php else: ?>
                                                    <div class="act-product-price-free">رایگان</div>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endwhile; ?>
                    </div>
                    <?php
                    if ($countAll == $countNotAvailable) {
                        ?>
                        <div class="flex justify-between items-center py-20">
                            <div class="flex justify-between items-center w-full flex-col">
                                <img class="" src="<?= get_template_directory_uri() . '/assets/img/ticket_img.png' ?>"
                                     alt="empty">
                                <p class="text-body2-strong py-20">محصولی در این دسته بندی موجود نمیباشد!</p>
                            </div>
                        </div>
                        <?php
                    }
                endif; ?>
            </div>

        </div>
        <?php

        wp_reset_postdata();

        if (null === WC()->session) {
            WC()->session = new \WC_Session_Handler();
            WC()->session->init();
        }

        if (null === WC()->cart) {
            WC()->cart = new \WC_Cart();
        }
        WC()->cart->get_cart();
        $products_by_region = [];
        foreach ($regions as $region_code) {
            $args = [
                    'post_type' => 'product',
                    'posts_per_page' => -1,
                    'tax_query' => [
                            [
                                    'taxonomy' => 'product_cat',
                                    'field' => 'term_id',
                                    'terms' => $term_id,
                            ]
                    ],
                    'meta_query' => [
                            [
                                    'key' => 'giftmax_box_setting',
                                    'value' => 's:11:"logo_region";s:' . strlen($region_code) . ':"' . sanitize_text_field($region_code) . '"',
                                    'compare' => 'LIKE'
                            ]
                    ]
            ];

            $query = new \WP_Query($args);
            $products = [];

            while ($query->have_posts()): $query->the_post();
                global $product;
                $delivery = get_post_meta($product->get_id(), 'delivery', true);
                $is_presale = isset($delivery['two']) && $delivery['two'] == 'on' || product_available($product->get_id());
                if (!$is_presale) continue;

                $regular = $product->get_regular_price();
                $sale = $product->get_sale_price();

                $regular = is_numeric($regular) ? (float)$regular : 0;
                $sale = is_numeric($sale) ? (float)$sale : 0;

                $final_price = ($product->is_on_sale() && $sale > 0) ? $sale : $regular;

                $products[] = [
                        'id' => $product->get_id(),
                        'title' => get_the_title(),
                        'regular' => number_format_usd($regular),
                        'sale' => number_format_usd($sale),
                        'final_price' => number_format_usd($final_price),
                ];

            endwhile;

            $products_by_region[$region_code] = $products;
            wp_reset_postdata();
        }

        return new \WP_REST_Response([
                'status' => true,
                'html' => ob_get_clean(),
                'cart' => WC()->cart && WC()->cart->get_cart(),
                'productsByRegion' => wp_json_encode($products_by_region)
        ], 200);
    }

    public function selectCategory_api_function()
    {
        ob_start();
        ?>
        <?php
        $categories = get_terms(array(
                'taxonomy' => 'product_cat',
                'hide_empty' => false,
        ));
        if (!empty($categories) && !is_wp_error($categories)) :
            ?>
            <div class="grid grid-cols-1 2xs:grid-cols-2 gap-4 2xs:gap-6">
                <?php foreach ($categories as $category) : ?>
                    <div class="flex items-center p-8 rounded border Category-bf54"
                         data-category-id="<?= esc_attr($category->term_id) ?>">
                        <div class="pts-4 pr-4 pl-8 text-xs font-medium tracking-tighter text-dark leading-[18px] grow pointer"><?= $category->name ?></div>
                        <?php
                        $thumbnail_id = get_term_meta($category->term_id, 'thumbnail_id', true);
                        if ($thumbnail_id) {
                            $image = wp_get_attachment_url($thumbnail_id);
                            echo '<div class="rounded-lg shrink-0 w-40 h-40 flex align-items-center justify-center" style="background-color: #00d1b2"><img src="' . esc_url($image) . '" alt="' . esc_attr($category->name) . '" loading="lazy" decoding="async" class="rounded-sm shrink-0 w-30" style="color: transparent;"></div>';
                        } else {
                            echo '<div class="skeleton w-40 h-40 rounded-sm shrink-0"></div>';
                        }
                        ?>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif;
        $output = ob_get_clean();
        echo json_encode(['status' => true, 'html' => $output]);
    }

    public function otp_api_function()
    {
        $records = UserModel::exitOtp($_POST['value'], 'otp', $_POST['otp']);
        if (!empty($records)) {
            if (strtotime($records['otp_expiry']) > time()) {
                UserModel::otpDelete($records['id']);
                $db = Db::getLnstance();
                global $wpdb;
                $user_id = get_current_user_id();
                $db->modify("UPDATE `{$wpdb->prefix}user_identity` SET `landline_phone` = :landline_phone,updated_at=:updated_at WHERE `user_id` = :user_id", array('landline_phone' => encrypt_data($_POST['value']), 'user_id' => $user_id, 'updated_at' => date('Y-m-d H:i:s')));
                $response_data = array('status' => true);
            } else {
                UserModel::otpDelete($records['id']);
                $response_data = array(
                        'status' => false,
                        'closed' => true,
                        'message' => 'کد شما منقضی شده'
                );
            }
            echo json_encode($response_data);
        } else {
            $response_data = array(
                    'status' => false,
                    'closed' => false,
                    'message' => 'کد وروردی صحیح نمیباشد'
            );
            echo json_encode($response_data);
        }
    }

    public function RegistryPhone_api_function()
    {
        if (!isset($_POST['phoneNumber']) && !isset($_POST['cartNumber']) && !isset($_POST['day']) && !isset($_POST['month']) && !isset($_POST['year']) && !isset($_POST['nationalCode'])) {
            echo json_encode(["status" => false, "message" => "اطلاعات ناقص است", "close" => true]);
            exit;
        }
        $phoneNumber = $_POST['phoneNumber'];
        $cartNumber = decrypt_data($_POST['cartNumber']);
        $day = $_POST['day'];
        $month = $_POST['month'];
        $year = $_POST['year'];
        $nationalCode = $_POST['nationalCode'];
        $firstName = $_POST['firstName'];
        $lastName = $_POST['lastName'];
        if (!validateIranianMobile($phoneNumber)) {
            echo json_encode(["status" => false, "percent" => 50, "message" => "شماره تلفن معتبر نیست"]);
            exit;
        } elseif (!preg_match('/^(0?[1-9]|[12][0-9]|3[01])$/', $day) || !preg_match('/^(0?[1-9]|1[0-2])$/', $month) || !preg_match('/^[0-9]{4}$/', $year)) {
            echo json_encode(["status" => false, "percent" => 50, "message" => "تاریخ تولد معتبر نیست"]);
            exit;
        } elseif (empty($firstName)) {
            echo json_encode(["status" => false, "percent" => 50, "message" => "نام وارد نشده است"]);
            exit;
        } elseif (empty($lastName)) {
            echo json_encode(["status" => false, "percent" => 50, "message" => "نام خانوادگی وارد نشده است"]);
            exit;
        } elseif (!preg_match('/^[0-9]{10}$/', $nationalCode)) {
            echo json_encode(["status" => false, "percent" => 50, "message" => "کدملی معتبر نیست"]);
            exit;
        } elseif (!isCardNumberValid($cartNumber)) {
            echo json_encode(["status" => false, "percent" => 50, "message" => "کارت معتبر نیست", "close" => true]);
            exit;
        }
        $token = 'd5497c98fc9a28300406dd8ee66bac5b531fc598';
        $birthDate = $year . '/' . $month . '/' . $day;
        $jbt = Jibit::getLnstance();
        if (UserModel::setting("shahkar_zohal") === true) {
            $result = v1::callZohalService(
                    'https://service.zohal.io/api/v0/services/inquiry/shahkar',
                    [
                            'mobile' => $phoneNumber,
                            'national_code' => $nationalCode
                    ],
                    $token
            );

            if ($result['status'] !== true) {
                return new \WP_REST_Response([
                        'status' => false,
                        $result,
                        "percent" => 50
                ], 200);
            }
        } elseif (UserModel::setting("shahkar_jibit") === true) {
            $endpoint = '/services/matching';
            $res = $jbt->api_request('GET', $endpoint, [
                    'mobileNumber' => $phoneNumber,
                    'nationalCode' => $nationalCode
            ], null, true);
            if ($res['code'] !== 200) {
                return new \WP_REST_Response([
                        'status' => false,
                        'message' => $res['body']['message'],
                        "percent" => 50
                ], 200);
            }
        }
        if (UserModel::setting("check_card_with_national_code_zohal") === true) {
            $result = v1::callZohalService(
                    'https://service.zohal.io/api/v0/services/inquiry/check_card_with_national_code',
                    [
                            'birth_date' => $birthDate,
                            'card_number' => $cartNumber,
                            'national_code' => $nationalCode
                    ],
                    $token
            );

            if ($result['status'] !== true) {
                return new \WP_REST_Response([
                        'status' => false,
                        $result,
                        "percent" => 75
                ], 200);
            }
        } elseif (UserModel::setting("check_card_with_national_code_jibit") === true) {
            $endpoint = '/services/matching';
            $res = $jbt->api_request('GET', $endpoint, [
                    'cardNumber' => $cartNumber,
                    'nationalCode' => $nationalCode,
                    'birthDate' => $year . $month . $day
            ], null, true);
            if ($res['code'] !== 200) {
                return new \WP_REST_Response([
                        'status' => false,
                        'message' => $res['body']['message'],
                        "percent" => 75
                ], 200);
            }
        }
        $user_id = get_current_user_id();
        global $wpdb;
        $db = Db::getLnstance();
        $records = UserModel::table('user_bank_cards', 'card_number_enc', encrypt_data($cartNumber), 'is_active', 0, 1);
        $hash = generateHash();
        if (!empty($records)) {
            $db->modify("DELETE FROM `{$wpdb->prefix}user_bank_cards` WHERE `id` = :id", array("id" => $records['id']));
        }
        $db->insert("INSERT INTO `{$wpdb->prefix}user_bank_cards` (`user_id`,`hash`, `card_number_enc`, `card_last4`, `phone`, `birth_date`, `national_code`,`first_name` ,`last_name`, `is_active`, `ip`, `created_at`) VALUES (:user_id, :hash,:card_number, :card_last4, :phone, :birth_date,:national_code,:first_name,:last_name,0,:ip,:created_at)", array(
                'user_id' => $user_id,
                'card_number' => encrypt_data($cartNumber),
                'first_name' => $firstName,
                'last_name' => $lastName,
                'card_last4' => substr($cartNumber, -4),
                'phone' => encrypt_data($phoneNumber),
                'birth_date' => encrypt_data($birthDate),
                'national_code' => encrypt_data($nationalCode),
                'ip' => encrypt_data(giftmax_get_user_ip()),
                'created_at' => date('Y-m-d H:i:s'),
                'hash' => $hash
        ));
        $otp = mt_rand(100000, 999999);
        $expiry = date("Y-m-d H:i:s", strtotime("+2 minutes"));
        UserModel::expiryEnd();
        $records = UserModel::exitOtp($phoneNumber);
        if (!empty($records) && strtotime($records['otp_expiry']) < time()) {
            UserModel::otpDelete($records['id']);
        }
        if (empty($records)) {
            UserModel::otp($phoneNumber, $otp, $expiry);
        }
        if (\Giftmax\Modules\UserModel::setting("otpAudio") === true) {
            $url = "https://portal.avanak.ir/rest/SendOTP";
            $url = $url . "?" . "Token=" . urlencode("1ACAAF7BC85B6AB3B54E5381A72EDCDC67D7BF06");
            $url = $url . "&" . "Length=6";
            $url = $url . "&" . "Number=" . $phoneNumber;
            $url = $url . "&" . "OptionalCode=" . $otp;

            $json = file_get_contents($url);
            if ($json->ErrorCode == 0) {
                echo json_encode(["status" => true, "percent" => 90, 'drg' => encrypt_data($hash)]);
            } else {
                echo json_encode(["status" => false, "message" => "خطایی پیش آمده", "percent" => 0]);
            }
        } elseif (\Giftmax\Modules\UserModel::setting("otpSms") === true) {
            $baseUrl = "https://edge.ippanel.com/v1/api/send";
            $token = "wns0sWEioLyJejB0g0olFj-PVlL2Yt5O2G94prP-BXg=";
            $data = [
                    "sending_type" => "pattern",
                    "from_number" => "+983000505",
                    "code" => "xpvkq2fmvzmqvr6",
                    "recipients" => [$phoneNumber],
                    "params" => [
                            "otp" => $otp,
                            "otp_link" => $otp,
                    ],
            ];

            $ch = curl_init($baseUrl);
            curl_setopt($ch, CURLOPT_HTTPHEADER, [
                    "Content-Type: application/json; charset=utf-8",
                    "Content-Type: application/json",
                    "Authorization: $token"
            ]);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data, JSON_UNESCAPED_UNICODE));

            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);
            echo json_encode(["status" => true, "percent" => 90, 'drg' => encrypt_data($hash)]);
        }
    }

    public function landlinePhoneApiFunction()
    {
        if (!isset($_POST['value'])) {
            echo json_encode(["status" => false, "message" => "اطلاعات ناقص است", "close" => true]);
            exit;
        }
        $otp = mt_rand(100000, 999999);
        $expiry = date("Y-m-d H:i:s", strtotime("+2 minutes"));
        UserModel::expiryEnd();
        $records = UserModel::exitOtp($_POST['value']);
        if (!empty($records) && strtotime($records['otp_expiry']) < time()) {
            UserModel::otpDelete($records['id']);
        }
        if (empty($records)) {
            UserModel::otp($_POST['value'], $otp, $expiry);
        }
        $url = "https://portal.avanak.ir/rest/SendOTP";
        $url = $url . "?" . "Token=" . urlencode("1ACAAF7BC85B6AB3B54E5381A72EDCDC67D7BF06");
        $url = $url . "&" . "Length=6";
        $url = $url . "&" . "Number=" . $_POST['value'];
        $url = $url . "&" . "OptionalCode=" . $otp;

        $json = file_get_contents($url);
        if ($json->ErrorCode == 0) {
            echo json_encode(["status" => true]);
        } else {
            echo json_encode(["status" => false, "message" => "خطایی پیش آمده"]);
        }
    }

    public function document_info_api_function()
    {
        $user_id = get_current_user_id();
        $u = UserModel::table('user_identity', 'user_id', $user_id);
        if (!empty($u['landline_phone'])) {
            $elapsedSeconds = strtotime(date("Y-m-d H:i:s")) - strtotime($u['updated_at']);
            $elapsedMinutes = $elapsedSeconds / 60;
            $remainingMinutes = max(0, 15 - $elapsedMinutes);
            $timer = round($remainingMinutes, 2);
            if ($timer > 1) {
                $landline_phone = 0;
            } else {
                $landline_phone = 1;
            }
        } else {
            $landline_phone = 1;
        }
        if (!isset($_POST['img']) || !$user_id || $landline_phone) {
            $response_data = array('status' => false, 'message' => "شما اجازه ثبت را ندارید");
            echo json_encode($response_data);
            exit();
        }
        $db = Db::getLnstance();
        global $wpdb;
        if ($_POST['select_val'] == 0) {
            $type_media = "National_card__img";
        } elseif ($_POST['select_val'] == 1) {
            $type_media = "Birth_certificate";
        }

        $verification_code = isset($_POST['verification_code']) ? sanitize_text_field(wp_unslash($_POST['verification_code'])) : '';
        $verification_date = isset($_POST['verification_date']) ? sanitize_text_field(wp_unslash($_POST['verification_date'])) : '';
        if (!empty($verification_code)) {
            update_user_meta($user_id, 'giftmax_verification_note_code', $verification_code);
        }
        if (!empty($verification_date)) {
            update_user_meta($user_id, 'giftmax_verification_note_date', $verification_date);
        }

        $records = $db->first("SELECT * FROM `{$wpdb->prefix}documents` WHERE `user_id` = :user_id AND (`accepted`=0 OR `accepted`=2)", array('user_id' => $user_id));
        if (empty($records)) {
            $db->insert("INSERT INTO `{$wpdb->prefix}documents` (`id`, `user_id`, `doc_type`, `document`, `accepted`) VALUES (NULL, :user_id, :doc_type, :document, :accepted)", array(
                    'user_id' => $user_id,
                    'doc_type' => $type_media,
                    'document' => $_POST['img'],
                    'accepted' => 0
            ));

            $response_data = array('status' => true, 'message' => "ثبت شد");
        } else {
            $response_data = array('status' => false, 'message' => "شما اجازه ثبت این مدرک را ندارید");
        }
        echo json_encode($response_data);

    }

    private function media_handle($file_id, $post_id, $post_data = array(), $overrides = array('test_form' => false))
    {
        require_once(ABSPATH . 'wp-admin/includes/media.php');
        require_once(ABSPATH . 'wp-admin/includes/file.php');
        require_once(ABSPATH . 'wp-admin/includes/post.php');
        require_once(ABSPATH . 'wp-admin/includes/image.php');
        $time = current_time('mysql');
        $post = get_post($post_id);

        if ($post) {
            if ('page' !== $post->post_type && substr($post->post_date, 0, 4) > 0) {
                $time = $post->post_date;
            }
        }

        $file = wp_handle_upload($_FILES[$file_id], $overrides, $time);

        if (isset($file['error'])) {
            $response_data = array(
                    'stats' => false,
                    'message' => "خطای آپلود",
            );

            echo json_encode($response_data);
            exit();
        }

        $name = $_FILES[$file_id]['name'];
        $ext = pathinfo($name, PATHINFO_EXTENSION);
        $name = wp_basename($name, ".$ext");

        $url = $file['url'];
        $type = $file['type'];
        $file = $file['file'];
        $title = sanitize_text_field($name);
        $content = '';
        $excerpt = '';

        if (preg_match('#^audio#', $type)) {
            $meta = wp_read_audio_metadata($file);

            if (!empty($meta['title'])) {
                $title = $meta['title'];
            }

            if (!empty($title)) {

                if (!empty($meta['album']) && !empty($meta['artist'])) {
                    $content .= sprintf(__('"%1$s" from %2$s by %3$s.'), $title, $meta['album'], $meta['artist']);
                } elseif (!empty($meta['album'])) {
                    $content .= sprintf(__('"%1$s" from %2$s.'), $title, $meta['album']);
                } elseif (!empty($meta['artist'])) {
                    $content .= sprintf(__('"%1$s" by %2$s.'), $title, $meta['artist']);
                } else {
                    $content .= sprintf(__('"%s".'), $title);
                }
            } elseif (!empty($meta['album'])) {

                if (!empty($meta['artist'])) {
                    $content .= sprintf(__('%1$s by %2$s.'), $meta['album'], $meta['artist']);
                } else {
                    $content .= $meta['album'] . '.';
                }
            } elseif (!empty($meta['artist'])) {

                $content .= $meta['artist'] . '.';

            }

            if (!empty($meta['year'])) {
                $content .= ' ' . sprintf(__('Released: %d.'), $meta['year']);
            }

            if (!empty($meta['track_number'])) {
                $track_number = explode('/', $meta['track_number']);

                if (is_numeric($track_number[0])) {
                    if (isset($track_number[1]) && is_numeric($track_number[1])) {
                        $content .= ' ' . sprintf(
                                /* translators: Audio file track information. 1: Audio track number, 2: Total audio tracks. */
                                        __('Track %1$s of %2$s.'),
                                        number_format_i18n($track_number[0]),
                                        number_format_i18n($track_number[1])
                                );
                    } else {
                        $content .= ' ' . sprintf(
                                        __('Track %s.'),
                                        number_format_i18n($track_number[0])
                                );
                    }
                }
            }

            if (!empty($meta['genre'])) {
                $content .= ' ' . sprintf(__('Genre: %s.'), $meta['genre']);
            }

        } elseif (str_starts_with($type, 'image/')) {
            $image_meta = wp_read_image_metadata($file);

            if ($image_meta) {
                if (trim($image_meta['title']) && !is_numeric(sanitize_title($image_meta['title']))) {
                    $title = $image_meta['title'];
                }

                if (trim($image_meta['caption'])) {
                    $excerpt = $image_meta['caption'];
                }
            }
        }

        $attachment = array_merge(
                array(
                        'post_mime_type' => $type,
                        'guid' => $url,
                        'post_parent' => $post_id,
                        'post_title' => $title,
                        'post_content' => $content,
                        'post_excerpt' => $excerpt,
                ),
                $post_data
        );

        unset($attachment['ID']);

        $attachment_id = wp_insert_attachment($attachment, $file, $post_id, true);

        if (!is_wp_error($attachment_id)) {
            if (!headers_sent()) {
                header('X-WP-Upload-Attachment-ID: ' . $attachment_id);
            }
            wp_update_attachment_metadata($attachment_id, wp_generate_attachment_metadata($attachment_id, $file));
        }

        return $attachment_id;
    }

    public function image_api_function($data)
    {
        if (!isset($_FILES['file'])) {
            $response_data = array(
                    'stats' => false,
                    'message' => "فایلی موجود نیست",
            );

            echo json_encode($response_data);
            exit();
        }
        $attachment_id = self::media_handle('file', 0);

        if (is_wp_error($attachment_id)) {
            $response_data = array(
                    'stats' => false,
                    'message' => $attachment_id->get_error_message(),
            );

            echo json_encode($response_data);
            exit();
        }

        $file_url = wp_get_attachment_url($attachment_id);

        $response_data = array(
                'stats' => true,
                'file_url' => $file_url,
        );

        echo json_encode($response_data);
    }

    private function postToZibal($path, $parameters)
    {
        $url = 'https://gateway.zibal.ir/v1/' . $path;

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($parameters));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        $response = curl_exec($ch);
        curl_close($ch);

        return json_decode($response);
    }

    public function wallet_amount_api_function()
    {
        $amount = $_POST["wallet_amount"];
        $recoords_Vip = UserModel::table("user_identity", "user_id", get_current_user_id());
        if (!empty($recoords_Vip['landline_phone'])) {
            if ($recoords_Vip['is_vip']) {
                $landline_phone = 0;
            } else {
                $elapsedSeconds = strtotime(date("Y-m-d H:i:s")) - strtotime($recoords_Vip['updated_at']);
                $elapsedMinutes = $elapsedSeconds / 60;
                $remainingMinutes = max(0, 15 - $elapsedMinutes);
                $timer = round($remainingMinutes, 2);
                if ($timer > 1) {
                    $landline_phone = 0;
                } else {
                    $landline_phone = 1;
                }
            }
        } else {
            $landline_phone = 1;
        }
        if ($landline_phone) {
            echo json_encode([
                    'status' => false,
                    'message' => 'برای افزایش موجودی ابتدا باید شماره تلفن ثابت احراز بشه',
                    'n' => true
            ]);
            exit();
        }
        if (WC()->payment_gateways()->payment_gateways()['zibal']->enabled != 'yes') {
            echo json_encode([
                    'status' => false,
                    'message' => 'درگاه پرداخت غیرفعال است'
            ]);
            exit();
        }
        if ($amount <100000){
            echo json_encode([
                'status' => false,
                'message' => "قیمت کمتر از 100 هزار ریال هست"
            ]);
            exit();
        }
        if ($amount > 2000000000) {
            echo json_encode([
                    'status' => false,
                    'message' => "قیمت کمتر 2,000,000,000 ریال باشد"
            ]);
            exit();
        }
        $hash = generateHash();
        $db = Db::getLnstance();
        global $wpdb;
        $userId = get_current_user_id();
        $db->insert("INSERT INTO `{$wpdb->prefix}wallet_payments` (`id`, `user_id`, `hash`, `amount`, `created_at`, `status`) VALUES (NULL, :user_id, :hash, :amount, :created_at, 0)", array(
                'user_id' => $userId,
                'hash' => $hash,
                'amount' => $amount,
                'created_at' => date('Y-m-d H:i:s')
        ));
        $zibal = get_option('woocommerce_zibal_settings');
        $merchant = $zibal['api_key'];
        $callback = home_url('/wp-json/api/v2/verify') . '?hash=' . $hash;
        global $wpdb;
        $db = Db::getLnstance();
        $allowedCards = [];
        if (is_array($recoords_Vip) && $recoords_Vip['account_type'] == 'normal') {
            $cards = $db->query("SELECT * FROM `{$wpdb->prefix}user_bank_cards` WHERE user_id=:user_id AND `is_active` = 1 AND phone IS NULL", array('user_id' => get_current_user_id()));
            if (!empty($cards)) {
                foreach ($cards as $card) {
                    $allowedCards[] = str_replace('-', '', decrypt_data($card['card_number_enc']));
                }
            } else {
                return new \WP_REST_Response([
                        'status' => false,
                        'message' => 'لطفا اول کارتی که مالک آن خودتان هستید را ثبت کنید'
                ], 200);
            }
        }
        $parameters = [
                "merchant" => $merchant,
                "callbackUrl" => $callback,
                "amount" => (int)$amount,
                "description" => " شارژ کیف پول" . number_format($amount),
                "allowedCards" => $allowedCards,
        ];
        $response = $this->postToZibal('request', $parameters);
        if (isset($response->result) && $response->result == 100) {
            $db->modify("UPDATE `{$wpdb->prefix}wallet_payments` SET `gateway_tx_id` = :gateway_tx_id WHERE `hash` = :hash", array(
                    'gateway_tx_id' => $response->trackId,
                    'hash' => $hash,
            ));
            echo json_encode([
                    'status' => true,
                    'url' => "https://gateway.zibal.ir/start/" . $response->trackId
            ]);
            exit();
        }

        echo json_encode([
                'status' => false,
                'message' => $response->message ?? 'خطا در اتصال به درگاه Zibal'
        ]);
    }

    public function verify_api_function($request)
    {
        $trackId = $request->get_param('trackId');
        $success = $request->get_param('success');
        $hash = $request->get_param('hash');
        if (!$trackId || !$hash) {
            header('Location:' . home_url());
            exit;
        }
        global $wpdb;
        $db = \Giftmax\Modules\Db::getLnstance();
        if ((int)$success !== 1) {
            $time = date('Y-m-d H:i:s');
            $db->modify("UPDATE `{$wpdb->prefix}wallet_payments` SET `status` = 0,`updated_at`=:updated_at WHERE `hash` = :hash", array(
                    'updated_at' => $time,
                    'hash' => $hash,
            ));
            header('Content-Type: text/html; charset=utf-8');
            View::render("/inc/templates/template-parts/payment/fail.php");
            exit;
        }
        $zibal = get_option('woocommerce_zibal_settings');
        $apiKey = $zibal['api_key'];
        $response = $this->postToZibal('verify', [
                'merchant' => $apiKey,
                'trackId' => $trackId,
        ]);
        if ($response && $response->result == 100) {
            $time = date('Y-m-d H:i:s');
            $db->modify("UPDATE `{$wpdb->prefix}wallet_payments` SET `status` = 1,`updated_at`=:updated_at WHERE `hash` = :hash", array(
                    'updated_at' => $time,
                    'hash' => $hash,
            ));
            $records = $db->first("SELECT * FROM `{$wpdb->prefix}wallet_payments` WHERE `hash` = :hash", array(
                    'hash' => $hash,
            ));
            $wallet = $db->first("SELECT * FROM `{$wpdb->prefix}wallet` WHERE `user_id` = :user_id", array(
                    'user_id' => $records['user_id'],
            ));
            $db->insert("INSERT INTO `{$wpdb->prefix}wallet_transactions` (`id`, `user_id`,`method`, `method_id`, `amount`, `type`, `description`, `created_at`) VALUES (NULL, :user_id,'wallet', :method_id, :amount, 'credit', :description, :created_at)", array(
                            'user_id' => $records['user_id'],
                            'method_id' => $records['id'],
                            'amount' => (float)($records['amount']) / 10,
                            'description' => 'افزایش موجودی',
                            'created_at' => date('Y-m-d H:i:s')
                    )
            );
            $db->modify("UPDATE `{$wpdb->prefix}wallet` SET `balance` = :balance WHERE `id` = :id", array(
                    'id' => $wallet['id'],
                    'balance' => (float)($records['amount'] / 10) + $wallet['balance']
            ));
            header('Content-Type: text/html; charset=utf-8');
            header("Refresh: 3; url=" . home_url('/profile/wallet'));
            View::render("/inc/templates/template-parts/payment/success.php", ['gateway' => 'زیبال', 'paid_date_fa' => $time]);
            exit;
        } elseif ($response && $response->result == 201) {
            header('Content-Type: text/html; charset=utf-8');
            header("Refresh: 3; url=" . home_url('/profile/wallet'));
            View::render("/inc/templates/template-parts/payment/verifed.php", ['gateway' => 'زیبال']);
            exit;
        }
    }

    private function loyaltyPointsToToman(int $totalPoints, int $pointsPerUnit = 100, int $moneyPerUnit = 10000): array
    {
        $convertiblePoints = intdiv($totalPoints, $pointsPerUnit) * $pointsPerUnit;

        $money = ($convertiblePoints / $pointsPerUnit) * $moneyPerUnit;
        $remainingPoints = $totalPoints - $convertiblePoints;

        return [
                'convertedPoints' => $convertiblePoints,
                'money' => $money,
                'remainingPoints' => $remainingPoints,
        ];
    }

    public function points_api_function()
    {
        $points = UserModel::points();
        global $wpdb;
        $db = \Giftmax\Modules\Db::getLnstance();
        $records = $db->first("SELECT * FROM `{$wpdb->prefix}setting` WHERE `meta_key`='stp'");
        if (empty($records)) {
            echo json_encode([
                    'status' => false,
                    'message' => 'تنظیمات ست نشده',
            ]);
            exit();
        }
        $record = json_decode($records['meta_value'], true);

        $res = self::loyaltyPointsToToman($points, $record[0]['points'], $record[0]['toman']);
        $user_id = get_current_user_id();
        $db = \Giftmax\Modules\Db::getLnstance();
        global $wpdb;
        $wallet = $db->first("SELECT * FROM `{$wpdb->prefix}wallet` WHERE `user_id` = :user_id", array(
                'user_id' => $user_id,
        ));
        $upoints = $db->first("SELECT * FROM `{$wpdb->prefix}user_points` WHERE `user_id` = :user_id", array(
                'user_id' => $user_id,
        ));
        if ($res['convertedPoints'] > 0) {
            $db->insert("INSERT INTO `{$wpdb->prefix}wallet_transactions` (`id`, `user_id`,`method`, `method_id`, `amount`, `type`, `description`, `created_at`) VALUES (NULL, :user_id,'points', :method_id, :amount, 'debit', :description, :created_at)", array(
                            'user_id' => $user_id,
                            'method_id' => $upoints['id'],
                            'amount' => (float)($res['convertedPoints']),
                            'description' => 'تبدیل امتیاز به اعتبار',
                            'created_at' => date('Y-m-d H:i:s')
                    )
            );
            if (empty($wallet)) {
                $db->insert("INSERT INTO `{$wpdb->prefix}wallet` (`id`, `user_id`, `balance`) VALUES (NULL, :user_id, '0.00')", array('user_id' => $user_id));
                $wallet['id'] = $db->lastInsertId();
            }
            $db->insert("INSERT INTO `{$wpdb->prefix}wallet_transactions` (`id`, `user_id`,`method`, `method_id`, `amount`, `type`, `description`, `created_at`) VALUES (NULL, :user_id,'wallet', :method_id, :amount, 'credit', :description, :created_at)", array(
                            'user_id' => $user_id,
                            'method_id' => $wallet['id'],
                            'amount' => (float)($res['money']),
                            'description' => 'افزایش موجودی',
                            'created_at' => date('Y-m-d H:i:s')
                    )
            );
            $db->modify("UPDATE `{$wpdb->prefix}wallet` SET `balance` = :balance WHERE `id` = :id", array(
                    'id' => $wallet['id'],
                    'balance' => (float)($res['money']) + $wallet['balance']
            ));
            $db->modify("UPDATE `{$wpdb->prefix}user_points` SET `points` = :points WHERE `id` = :id", array(
                    'id' => $upoints['id'],
                    'points' => $res['remainingPoints']
            ));
            echo json_encode([
                    'status' => true,
                    'message' => 'تبدیل امتیاز انجام شد',
                    'points' => number_format($res['remainingPoints']),
                    'balance' => number_format((float)($res['money']) + $wallet['balance']),
            ]);
        } else {
            echo json_encode([
                    'status' => false,
                    'message' => 'موجودی کافی نمیباشد',
            ]);
        }
    }

    public function filters_api_function()
    {

        ob_start();
        $giftmax_is_user_logged_in = is_user_logged_in();
        $giftmax_wishlist_ids = $giftmax_is_user_logged_in ? giftmax_get_user_wishlist_product_ids() : [];
        ?>
        <div class="act-shop-products-grid act-cols-2 fhDGSJDF justify-start-ipt" style="position: relative;">
            <?php

            $paged = isset($_POST['page']) ? absint($_POST['page']) : 1;

            $args = [
                    'post_type' => 'product',
                    'posts_per_page' => 16,
                    'paged' => $paged,
                    'order' => 'ASC',
                    'orderby' => [
                            'meta_value_num' => 'ASC',
                            'date' => 'DESC',
                    ]
            ];

            /* ---------- TAX QUERY (CATEGORY) ---------- */
            if (!empty($_POST['newFilters']['id']) || !empty($_POST['id'])) {

                $args['tax_query'] = [[
                        'taxonomy' => 'product_cat',
                        'field' => 'term_id',
                        'terms' => !empty($_POST['newFilters']['id'])
                                ? array_map('absint', (array)$_POST['newFilters']['id'])
                                : absint($_POST['id']),
                ]];
            }
            if (!empty($_POST['key'])) {
                $args['s'] = $_POST['key'];
            }

            /* ---------- META QUERY INIT ---------- */
            $args['meta_query'] = [
                    'relation' => 'AND',
                    [
                            'relation' => 'OR',
                            [
                                    'key' => 'giftmax_setting_order',
                                    'compare' => 'EXISTS',
                                    'type' => 'NUMERIC',
                            ],
                            [
                                    'key' => 'giftmax_setting_order',
                                    'compare' => 'NOT EXISTS',
                            ],
                    ],
            ];

            /* ---------- PRICE FILTER ---------- */
            if (isset($_POST['min_price'], $_POST['max_price'])) {

                $min_price = $_POST['min_price'];
                $max_price = $_POST['max_price'];

                $args['meta_query'][] = [
                        'key' => '_price',
                        'value' => [$min_price, $max_price],
                        'compare' => 'BETWEEN',
                        'type' => 'NUMERIC',
                ];
            }

            /* ---------- REGION FILTER (MULTI) ---------- */
            $selected_regions = $_POST['newFilters']['region'] ?? [];

            if (!is_array($selected_regions)) {
                $selected_regions = [$selected_regions];
            }

            if (!empty($selected_regions)) {

                $region_meta_query = ['relation' => 'OR'];

                foreach ($selected_regions as $region) {
                    $region_meta_query[] = [
                            'key' => 'giftmax_box_setting',
                            'value' => 's:11:"logo_region";s:' . strlen($region) . ':"' . sanitize_text_field($region) . '"',
                            'compare' => 'LIKE'
                    ];
                }
                $args['meta_query'][] = $region_meta_query;
            }
            $args['meta_key'] = 'giftmax_setting_order';
            /* ---------- QUERY ---------- */
            $home_coupon_objects = [];
            $home_coupon_ids = get_posts([
                    'post_type' => 'shop_coupon',
                    'post_status' => 'publish',
                    'numberposts' => -1,
                    'fields' => 'ids',
            ]);

            if (!empty($home_coupon_ids)) {
                foreach ($home_coupon_ids as $home_coupon_id) {
                    $home_coupon_objects[] = new \WC_Coupon($home_coupon_id);
                }
            }
            $query = new \WP_Query($args);
            if ($query->have_posts()) {
                while ($query->have_posts()) {
                    $query->the_post();
                    global $product;
                    $regular = $product->get_regular_price();
                    $sale = $product->get_sale_price();
                    $final_price = $product->is_on_sale() && $sale > 0 ? $sale : $regular;
                    $img = get_the_post_thumbnail_url(get_the_ID(), 'product_discount');
                    $settings = get_post_meta($product->get_id(), 'giftmax_box_setting', true);
                    $img = get_the_post_thumbnail_url(get_the_ID(), 'product_discount');
                    $delivery = get_post_meta($product->get_id(), 'delivery', true);
                    $sale_to = $product->get_date_on_sale_to();
                    $sale_to_ts = $sale_to ? $sale_to->getTimestamp() : null;
                    $matched_coupon_code = '';

                    if (!empty($home_coupon_objects)) {
                        foreach ($home_coupon_objects as $home_coupon_obj) {
                            $expires_at = $home_coupon_obj->get_date_expires();

                            if ($expires_at && $expires_at->getTimestamp() < current_time('timestamp')) {
                                continue;
                            }

                            if ($home_coupon_obj->is_valid_for_product($product)) {
                                $matched_coupon_code = $home_coupon_obj->get_code();
                                break;
                            }
                        }
                    }
                    ?>
                    <div class="act-new-service-card">
                        <?php if (!empty($matched_coupon_code) && !isMobile()) { ?>
                            <div class="act-new-service-card-discount Button-sc91"
                                 data-product-id="<?= esc_attr($product->get_id()) ?>">
                                <div class="anScr"></div>
                                <div class="anSct">مشاهده کد تخفیف</div>
                                <div class="anScl"></div>
                            </div>
                        <?php } ?>
                        <div class="act-new-service-card-inner">
                            <div <?= isset($delivery['two']) && $delivery['two'] == 'on' || product_available($product->get_id()) ? '' : 'class="NdhJD5"' ?>>
                                <div class="act-new-service-card-inner-top">
                                    <a href="<?= get_permalink() ?>">
                                        <div class="act-new-service-card-inner-top-img-box relative">
                                            <img loading="lazy" decoding="async" width="32" height="33"
                                                 src="<?= $img ?>"
                                                 class="attachment-post-thumbnail size-post-thumbnail wp-post-image"
                                                 alt="">
                                            <?php
                                            if (!empty($settings[0]['logo_region'])) {
                                                ?>
                                                <div class="logo_region">
                                                    <img src="<?= empty($settings[0]['logo_region']) ?: get_template_directory_uri() . '/assets/flag/' . $settings[0]['logo_region'] . '.svg' ?>">
                                                </div>
                                                <?php
                                            }
                                            $date_from = $product->get_date_on_sale_from();
                                            $date_to = $product->get_date_on_sale_to();
                                            if ($date_from || $date_to) {
                                                ?>
                                                <div class="logo_detail"
                                                     style="top: 7px;right: 7px;background-color: transparent;">
                                                    <img width="33" height="29"
                                                         src="<?= get_template_directory_uri() ?>/assets/img/svg/Amazings.svg">
                                                </div>
                                                <?php
                                            } elseif ($product->is_on_sale()) {
                                                ?>
                                                <div class="logo_detail" style="top: 7px;right: 7px;">
                                                    <img src="<?= get_template_directory_uri() ?>/assets/img/svg/percent.svg">
                                                </div>
                                                <?php
                                            }
                                            ?>
                                        </div>
                                    </a>
                                    <div class="act-new-service-card-inner-top-txt-box" <?= !empty($settings[0]['label']) && $settings[0]['label'] != '' ? 'style="gap:2px"' : '' ?>>
                                        <a href="<?= get_permalink() ?>">
                                            <h4 class="act-product-title"><?= get_the_title() ?></h4>
                                            <?php
                                            if (!empty($settings[0]['sub_head'])) echo "<p class='act-product-title-en'>" . $settings[0]['sub_head'] . "</p>";
                                            ?>
                                        </a>
                                        <div class="flex justify-between">
                                            <div class="flex">
                                                <?php
                                                $tooltip = isset($delivery['description']) ? $delivery['description'] : '';
                                                ?>
                                                <div class="act-product-option-box__nw <?= isset($delivery['two']) && $delivery['two'] == 'on' ? 'pre-sale wiki wiki__holder js-dk-wiki-trigger' : 'same-day' ?>" <?= isset($delivery['two']) && $delivery['two'] == 'on' ? 'data-tooltip="' . $tooltip . '"' : '' ?>><?= isset($delivery['two']) && $delivery['two'] == 'on' ? 'پیش فروش' : 'تحویل آنی' ?></div>
                                                <div class="purchaseScore wiki wiki__holder js-dk-wiki-trigger"
                                                     data-tooltip="با خرید این گیفت کارت <?= empty($settings[0]['purchaseScore']) ? 0 : $settings[0]['purchaseScore'] ?> امتیاز دریافت میکنید">
                                                    <i class="icon-star"></i><?= empty($settings[0]['purchaseScore']) ? 0 : $settings[0]['purchaseScore'] ?>
                                                </div>
                                            </div>
                                            <?php $is_in_wishlist = in_array((int)$product->get_id(), $giftmax_wishlist_ids, true); ?>
                                            <button class="add-to__favorites Button-alu84 <?= $is_in_wishlist ? 'is-active' : '' ?>"
                                                    data-product-id="<?= esc_attr($product->get_id()) ?>"
                                                    data-auth="<?= $giftmax_is_user_logged_in ? '1' : '0' ?>"
                                                    style="width: 28px;height: 28px;border-radius: 7px">
                                                <svg viewBox="0 0 24 24" style="width: 64%;">
                                                    <path d="M12.62 20.81C12.28 20.93 11.72 20.93 11.38 20.81C8.48 19.82 2 15.69 2 8.68998C2 5.59998 4.49 3.09998 7.56 3.09998C9.38 3.09998 10.99 3.97998 12 5.33998C13.01 3.97998 14.63 3.09998 16.44 3.09998C19.51 3.09998 22 5.59998 22 8.68998C22 15.69 15.52 19.82 12.62 20.81Z"
                                                          fill="<?= $is_in_wishlist ? '#ef4444' : 'none' ?>"
                                                          stroke="<?= $is_in_wishlist ? '#ef4444' : 'inherit' ?>"
                                                          stroke-width="1.5" stroke-linecap="round"
                                                          stroke-linejoin="round"></path>
                                                </svg>
                                            </button>
                                        </div>
                                        <?php if (!empty($matched_coupon_code) && isMobile()) { ?>
                                            <div class="act-new-service-card-discount Button-sc91"
                                                 data-product-id="<?= esc_attr($product->get_id()) ?>">
                                                مشاهده کد تخفیف
                                            </div>
                                        <?php } else { ?>
                                            <p class="act-product-txt"><?= empty($settings[0]['description_short']) ? '' : $settings[0]['description_short'] ?></p>
                                            <?php
                                        }
                                        ?>                                        <?php
                                        if (!empty($settings[0]['label']) && $settings[0]['label'] != '') {
                                            ?>
                                            <div class="label-fjd84">
                                                <img src="<?= empty($settings[0]['label']) ? '' : $settings[0]['label'] ?>"
                                                     class="logo_label">
                                                <p class="label_title"><?= empty($settings[0]['label_title']) ? '' : $settings[0]['label_title'] ?></p>
                                            </div>
                                            <?php
                                        }
                                        ?>
                                    </div>
                                </div>
                            </div>
                            <?php
                            $date_from = $product->get_date_on_sale_from();
                            $date_to = $product->get_date_on_sale_to();
                            if ($product->is_on_sale() & ($date_from || $date_to)) {
                                $sale_from_ts = $date_from ? $date_from->getTimestamp() : null;
                                $sale_to_ts = $date_to ? $date_to->getTimestamp() : null;
                                if ($sale_from_ts && $sale_to_ts) {
                                    $now_ts = time();
                                    $total_duration = $sale_to_ts - $sale_from_ts;
                                    $elapsed = $now_ts - $sale_from_ts;

                                    $progress_percent = max(0, min(100, ($elapsed / $total_duration) * 100));
                                } else {
                                    $progress_percent = 0;
                                }
                            } else {
                                $sale_to_ts = null;
                            }
                            if (!$sale_to_ts) {
                                ?>
                                <div class="act-hor-bor"></div>
                                <?php
                            } else {
                                ?>
                                <div class="flex justify-between flex-col">
                                    <div class="relative bg-neutral-100 style_ProductPromotionTimeline__progress__JnKWE"
                                         style="">
                                        <div class="absolute bg-primary-700 h-full left-0 top-0 style_ProductPromotionTimeline--active__oYyta"
                                             style="width: <?= $progress_percent ?>%;"></div>
                                    </div>
                                    <span class="text-primary-700 text-body2-strong style_ProductPromotionTimeline__timer__zS6ZA1 text-left"><?= date('Y-m-d H:i:s', $sale_to_ts); ?></span>

                                </div>
                                <?php
                            }
                            ?>
                            <div>
                                <?php
                                if (!empty($matched_coupon_code)) {
                                    $usage_limit = (int)$home_coupon_obj->get_usage_limit();
                                    $usage_count = (int)$home_coupon_obj->get_usage_count();

                                    $remaining_uses = $usage_limit > 0
                                            ? max(0, $usage_limit - $usage_count)
                                            : __('نامحدود', 'textdomain');
                                    ?>
                                    <div class="">
                                        <div class="relative bg-neutral-100 style_ProductPromotionTimeline__progress__JnKWE">
                                            <div class="absolute bg-primary-700 h-full left-0 top-0 style_ProductPromotionTimeline--active__oYyta"
                                                 style="width: <?= ($home_coupon_obj->get_usage_count() / ($home_coupon_obj->get_usage_count() + $remaining_uses)) * 100 ?>%;"></div>
                                        </div>
                                        <div class="whitespace-nowrap flex justify-between pt-1">
                                            <div class=""><span
                                                        class="text-primary-700 text-body-strong ml-1"><?= ($home_coupon_obj->get_usage_count() / ($home_coupon_obj->get_usage_count() + $remaining_uses)) * 100 ?>%</span><span
                                                        class="text-neutral-500 text-caption">فروش رفته</span></div>
                                            <?php
                                            if ($home_coupon_obj->get_date_expires()) {
                                                ?>
                                                <div class="text-primary-700 text-body2-strong style_ProductPromotionTimeline__timer__zS6ZA"><?= $home_coupon_obj->get_date_expires() ? $home_coupon_obj->get_date_expires()->date_i18n('Y-m-d H:i:s') : 'بدون تاریخ انقضا' ?></div>
                                                <?php
                                            } else {
                                                ?>
                                                <div class="text-primary-700 text-body2-strong style_ProductPromotionTimeline__timer__zS6ZA"></div>
                                            <?php }
                                            ?>
                                        </div>
                                    </div>
                                    <?php
                                }
                                ?>
                                <div class="act-product-card-footer">
                                    <a href="<?= the_permalink() ?>" class="act-special-carousel-card-buy-box-option">جزئیات</a>
                                    <div class="act-product-price-box">
                                        <?php
                                        if ($sale && $regular > $sale) { ?>
                                            <div class="act-product-price-box-top">
                                                <div class="act-product-price-off-price"><?= number_format_usd($regular) ?></div>
                                                <div class="act-product-price-off-percent">  <?= get_discount_percent($product) ?>
                                                    ٪
                                                </div>


                                            </div>
                                            <?php
                                        }
                                        ?>
                                        <div class="act-product-price<?= $product->is_on_sale() ? ' bpt' : '' ?>">
                                            <?php
                                            if ($final_price > 0) {
                                                ?>
                                                <div id="priceValue" data-id="<?= $product->get_id() ?>"
                                                     data-target="<?= payment_usd($product->is_on_sale() ? $sale : $regular) ?>"><?= number_format_usd($product->is_on_sale() ? $sale : $regular) ?></div>
                                                <span>تومان</span>
                                                <?php
                                            } else {
                                                ?>
                                                <div class="act-product-price-free">رایگان</div>
                                                <?php
                                            }
                                            ?>
                                        </div>
                                    </div>
                                </div>
                                <?php
                                if (isset($delivery['two']) && $delivery['two'] == 'on' || product_available($product->get_id())) {
                                    if (\Giftmax\Modules\UserModel::setting("buy") === true) {
                                        ?>
                                        <button type="button"
                                                class="act-special-carousel-card-buy-box-but Button-aca49 pointer"
                                                data-product-id="<?= $product->get_id() ?>">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="26" height="26"
                                                 viewBox="0 0 26 26" fill="currentcolor">
                                                <path d="M17.875 9.34916C17.4308 9.34916 17.0625 8.98083 17.0625 8.53666V7.04166C17.0625 5.90416 16.575 4.79916 15.73 4.03C14.8742 3.25 13.7692 2.8925 12.5992 3.00083C10.6492 3.185 8.9375 5.17833 8.9375 7.25833V8.30916C8.9375 8.75333 8.56917 9.12166 8.125 9.12166C7.68083 9.12166 7.3125 8.75333 7.3125 8.30916V7.2475C7.3125 4.33333 9.66333 1.64666 12.4475 1.37583C14.0725 1.22417 15.6325 1.73333 16.8242 2.8275C18.005 3.9 18.6875 5.43833 18.6875 7.04166V8.53666C18.6875 8.98083 18.3192 9.34916 17.875 9.34916Z"></path>
                                                <path d="M16.2498 24.6457H9.7498C4.7448 24.6457 3.81314 22.3165 3.5748 20.0523L2.7623 13.5632C2.64314 12.3932 2.5998 10.714 3.7373 9.45734C4.7123 8.374 6.32647 7.854 8.66647 7.854H17.3331C19.684 7.854 21.2981 8.38484 22.2623 9.45734C23.389 10.714 23.3565 12.3932 23.2373 13.5415L22.4248 20.0523C22.1865 22.3165 21.2548 24.6457 16.2498 24.6457ZM8.66647 9.479C6.83564 9.479 5.57897 9.8365 4.9398 10.5515C4.40897 11.1365 4.23564 12.0357 4.37647 13.379L5.18897 19.8682C5.37314 21.6015 5.8498 23.0315 9.7498 23.0315H16.2498C20.1498 23.0315 20.6265 21.6123 20.8106 19.8898L21.6231 13.379C21.764 12.0573 21.5906 11.1582 21.0598 10.5623C20.4206 9.8365 19.164 9.479 17.3331 9.479H8.66647Z"></path>
                                                <path d="M16.7045 14.2458C16.0979 14.2458 15.6104 13.7583 15.6104 13.1624C15.6104 12.5666 16.0979 12.0791 16.6937 12.0791C17.2895 12.0791 17.777 12.5666 17.777 13.1624C17.777 13.7583 17.3004 14.2458 16.7045 14.2458Z"></path>
                                                <path d="M9.12151 14.2458C8.51484 14.2458 8.02734 13.7583 8.02734 13.1624C8.02734 12.5666 8.51484 12.0791 9.11068 12.0791C9.70651 12.0791 10.194 12.5666 10.194 13.1624C10.194 13.7583 9.71734 14.2458 9.12151 14.2458Z"></path>
                                            </svg>
                                            افزودن به سبد خرید
                                        </button>
                                        <?php
                                    } else {
                                        echo '<button type="button" class="btn btn-buy-disable mb-2" >خرید از سایت غیرفعال هست</button>';
                                    }
                                } else {
                                    echo '<div class="inaJSDge8">ناموجود</div>';
                                }
                                ?>
                            </div>
                        </div>
                    </div>
                    <?php
                }
            }
            ?>

        </div>
        <?php
        $total_pages = $query->max_num_pages;

        if ($total_pages > 1) :
            $current_page = max(1, $paged);
            ?>
            <div class="navigation pagination act-shop-pagination">
                <div class="navigation pagination act-shop-pagination">
                    <div class="nav-links">

                        <?php for ($i = 1; $i <= $total_pages; $i++) : ?>
                            <?php if ($i == $current_page) : ?>
                                <span aria-current="page" class="page-numbers current"><?= $i ?></span>
                            <?php else : ?>
                                <a class="page-numbers a--page-numbers pointer" data-page="<?= $i ?>"><?= $i ?></a>
                            <?php endif; ?>
                        <?php endfor; ?>

                    </div>

                    <div class="act-vb"></div>

                    <div class="act-pagination-arrows">
                        <!-- Prev -->
                        <?php if ($current_page > 1) : ?>
                        <a class="prev page-numbers a--page-numbers pointer" data-page="<?= $current_page - 1 ?>">
                            <?php else : ?>
                            <a class="prev page-numbers a--page-numbers act-disabled">
                                <?php endif; ?>
                                <!-- SVG Prev -->
                                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20"
                                     fill="currentColor">
                                    <path d="M12.0253 15.6833C11.8669 15.6833 11.7086 15.625 11.5836 15.5C11.3419 15.2583 11.3419 14.8583 11.5836 14.6166L16.2003 9.99998L11.5836 5.38331C11.3419 5.14164 11.3419 4.74164 11.5836 4.49998C11.8253 4.25831 12.2253 4.25831 12.4669 4.49998L17.5253 9.55831C17.7669 9.79998 17.7669 10.2 17.5253 10.4416L12.4669 15.5C12.3419 15.625 12.1836 15.6833 12.0253 15.6833Z"/>
                                    <path d="M16.942 10.625H2.91699C2.57533 10.625 2.29199 10.3417 2.29199 10C2.29199 9.65833 2.57533 9.375 2.91699 9.375H16.942C17.2837 9.375 17.567 9.65833 17.567 10C17.567 10.3417 17.2837 10.625 16.942 10.625Z"/>
                                </svg>
                            </a>

                            <!-- Next -->
                            <?php if ($current_page < $total_pages) : ?>
                            <a class="next page-numbers a--page-numbers pointer" data-page="<?= $current_page + 1 ?>">
                                <?php else : ?>
                                <a class="next page-numbers a--page-numbers act-disabled">
                                    <?php endif; ?>
                                    <!-- SVG Next -->
                                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20"
                                         fill="currentColor">
                                        <path d="M7.97474 4.31669C8.13307 4.31669 8.29141 4.37502 8.41641 4.50002C8.65807 4.74169 8.65807 5.14169 8.41641 5.38336L3.79974 10L8.41641 14.6167C8.65807 14.8584 8.65807 15.2584 8.41641 15.5C8.17474 15.7417 7.77474 15.7417 7.53307 15.5L2.47474 10.4417C2.23307 10.2 2.23307 9.80002 2.47474 9.55836L7.53307 4.50002C7.65807 4.37502 7.81641 4.31669 7.97474 4.31669Z"/>
                                        <path d="M3.05801 9.375L17.083 9.375C17.4247 9.375 17.708 9.65833 17.708 10C17.708 10.3417 17.4247 10.625 17.083 10.625L3.05801 10.625C2.71634 10.625 2.43301 10.3417 2.43301 10C2.43301 9.65833 2.71634 9.375 3.05801 9.375Z"/>
                                    </svg>
                                </a>
                    </div>
                </div>
            </div>
        <?php endif;
        wp_reset_postdata();
        $output = ob_get_clean();
        echo json_encode(['status' => true, 'html' => $output]);
    }
}
