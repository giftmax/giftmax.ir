<?php
/**
 * Template Name: صفحه خروج (Logout)
 * Template Post Type: page
 */
get_header();   // هدر قالب

// -------------------- محتوای صفحه --------------------
?>
    <div class="logout-container">
        <?php
        $logout_url = wp_logout_url( home_url() ); // تغییر کنید اگر می‌خواهید به صفحه‌ی دیگر هدایت شوید
        ?>
        <a href="<?php echo esc_url( $logout_url ); ?>" class="btn-logout">خروج از حساب کاربری</a>
    </div>
<?php
// -------------------- پایان صفحه --------------------
get_footer();
