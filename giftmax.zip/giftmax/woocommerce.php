<?php
namespace Giftmax;
use Giftmax\Modules\View;

get_header();

if(is_singular('product')){
    View::render("/inc/templates/product/page/single.php");
}else
    View::render("/inc/templates/product/page/archive.php");
get_footer(); ?>
