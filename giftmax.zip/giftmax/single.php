<?php

get_header();
?>
    <main>
        <div class="container-xl-w mx-auto mt-32">
            <nav class="rad-breadcrumb rad-woo-bread">
                <?php
                // ۱. صفحه اصلی
                echo '<a class="kp-pl" href="'.get_home_url().'"> صفحه اصلی  </a> ';
                echo '<span class="sep"><svg xmlns="http://www.w3.org/2000/svg" width="1" height="24" viewBox="0 0 1 24" stroke="currentcolor"> <line x1="0.5" y1="2.18557e-08" x2="0.499999" y2="24"></line> </svg></span>';

                $cats = get_the_category();
                if ($cats) {
                    $cat = $cats[0];
                    $cat_link = get_category_link( $cat->term_id );
                    echo '<a class="kp-pl" href="'. get_bloginfo('url').'/blogs/">مقالات</a> ';
                    echo '<span class="sep"><svg xmlns="http://www.w3.org/2000/svg" width="1" height="24" viewBox="0 0 1 24" stroke="currentcolor"> <line x1="0.5" y1="2.18557e-08" x2="0.499999" y2="24"></line> </svg></span>';
                    echo '<a class="kp-pl" href="'. esc_url($cat_link).'">'.$cat->cat_name.'</a> ';
                    echo '<span class="sep"><svg xmlns="http://www.w3.org/2000/svg" width="1" height="24" viewBox="0 0 1 24" stroke="currentcolor"> <line x1="0.5" y1="2.18557e-08" x2="0.499999" y2="24"></line> </svg></span>';
                }
                ?>
                <span class="kp-pn"><?php the_title(); ?></span>
            </nav>

        </div>
        <div class="container-xl-w mx-auto flex lg:mt-8">
            <?php
            $post_id   = get_the_ID();
            $categories = wp_get_post_categories( $post_id );

            if ( empty( $categories ) ) {
                return;
            }

            /* ---------- 2. ساخت کوئری  ---------- */
            $args = array(
                    'posts_per_page' => 4,
                    'post_status'    => 'publish',
                    'orderby'        => 'date',
                    'order'          => 'DESC',
            );

            $related = new WP_Query( $args );
            ?>
            <div class="<?=$related->have_posts() ? 'lg:w-75' : 'w-full'?> content_box__single">
                <div class="act-blog-page-title">
                    <h1><?=get_the_title()?></h1>
                </div>
                <div class="flex justify-between box__main flex-col">
                    <div class="w-full flex justify-center">
                        <img src="<?=get_the_post_thumbnail_url() ?>" class="img_single">
                    </div>
                    <div class="w-full mt-3">
                        <div class="product_meta flex">
                                <span class="publish_date detail-container">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="currentcolor">
                                        <path d="M16.7502 3.56V2C16.7502 1.59 16.4102 1.25 16.0002 1.25C15.5902 1.25 15.2502 1.59 15.2502 2V3.5H8.75023V2C8.75023 1.59 8.41023 1.25 8.00023 1.25C7.59023 1.25 7.25023 1.59 7.25023 2V3.56C4.55023 3.81 3.24023 5.42 3.04023 7.81C3.02023 8.1 3.26023 8.34 3.54023 8.34H20.4602C20.7502 8.34 20.9902 8.09 20.9602 7.81C20.7602 5.42 19.4502 3.81 16.7502 3.56Z"></path><path d="M20 9.83984H4C3.45 9.83984 3 10.2898 3 10.8398V16.9998C3 19.9998 4.5 21.9998 8 21.9998H16C19.5 21.9998 21 19.9998 21 16.9998V10.8398C21 10.2898 20.55 9.83984 20 9.83984ZM9.21 18.2098C9.16 18.2498 9.11 18.2998 9.06 18.3298C9 18.3698 8.94 18.3998 8.88 18.4198C8.82 18.4498 8.76 18.4698 8.7 18.4798C8.63 18.4898 8.57 18.4998 8.5 18.4998C8.37 18.4998 8.24 18.4698 8.12 18.4198C7.99 18.3698 7.89 18.2998 7.79 18.2098C7.61 18.0198 7.5 17.7598 7.5 17.4998C7.5 17.2398 7.61 16.9798 7.79 16.7898C7.89 16.6998 7.99 16.6298 8.12 16.5798C8.3 16.4998 8.5 16.4798 8.7 16.5198C8.76 16.5298 8.82 16.5498 8.88 16.5798C8.94 16.5998 9 16.6298 9.06 16.6698C9.11 16.7098 9.16 16.7498 9.21 16.7898C9.39 16.9798 9.5 17.2398 9.5 17.4998C9.5 17.7598 9.39 18.0198 9.21 18.2098ZM9.21 14.7098C9.02 14.8898 8.76 14.9998 8.5 14.9998C8.24 14.9998 7.98 14.8898 7.79 14.7098C7.61 14.5198 7.5 14.2598 7.5 13.9998C7.5 13.7398 7.61 13.4798 7.79 13.2898C8.07 13.0098 8.51 12.9198 8.88 13.0798C9.01 13.1298 9.12 13.1998 9.21 13.2898C9.39 13.4798 9.5 13.7398 9.5 13.9998C9.5 14.2598 9.39 14.5198 9.21 14.7098ZM12.71 18.2098C12.52 18.3898 12.26 18.4998 12 18.4998C11.74 18.4998 11.48 18.3898 11.29 18.2098C11.11 18.0198 11 17.7598 11 17.4998C11 17.2398 11.11 16.9798 11.29 16.7898C11.66 16.4198 12.34 16.4198 12.71 16.7898C12.89 16.9798 13 17.2398 13 17.4998C13 17.7598 12.89 18.0198 12.71 18.2098ZM12.71 14.7098C12.66 14.7498 12.61 14.7898 12.56 14.8298C12.5 14.8698 12.44 14.8998 12.38 14.9198C12.32 14.9498 12.26 14.9698 12.2 14.9798C12.13 14.9898 12.07 14.9998 12 14.9998C11.74 14.9998 11.48 14.8898 11.29 14.7098C11.11 14.5198 11 14.2598 11 13.9998C11 13.7398 11.11 13.4798 11.29 13.2898C11.38 13.1998 11.49 13.1298 11.62 13.0798C11.99 12.9198 12.43 13.0098 12.71 13.2898C12.89 13.4798 13 13.7398 13 13.9998C13 14.2598 12.89 14.5198 12.71 14.7098ZM16.21 18.2098C16.02 18.3898 15.76 18.4998 15.5 18.4998C15.24 18.4998 14.98 18.3898 14.79 18.2098C14.61 18.0198 14.5 17.7598 14.5 17.4998C14.5 17.2398 14.61 16.9798 14.79 16.7898C15.16 16.4198 15.84 16.4198 16.21 16.7898C16.39 16.9798 16.5 17.2398 16.5 17.4998C16.5 17.7598 16.39 18.0198 16.21 18.2098ZM16.21 14.7098C16.16 14.7498 16.11 14.7898 16.06 14.8298C16 14.8698 15.94 14.8998 15.88 14.9198C15.82 14.9498 15.76 14.9698 15.7 14.9798C15.63 14.9898 15.56 14.9998 15.5 14.9998C15.24 14.9998 14.98 14.8898 14.79 14.7098C14.61 14.5198 14.5 14.2598 14.5 13.9998C14.5 13.7398 14.61 13.4798 14.79 13.2898C14.89 13.1998 14.99 13.1298 15.12 13.0798C15.3 12.9998 15.5 12.9798 15.7 13.0198C15.76 13.0298 15.82 13.0498 15.88 13.0798C15.94 13.0998 16 13.1298 16.06 13.1698C16.11 13.2098 16.16 13.2498 16.21 13.2898C16.39 13.4798 16.5 13.7398 16.5 13.9998C16.5 14.2598 16.39 14.5198 16.21 14.7098Z"></path>
                                    </svg>
                                    <span class="detail-label">تاریخ انتشار : </span>
                                    <span><?=gjdate(get_the_date('Y-m-d') , "d M Y")?></span>
                                </span>
                            <span class="total_view detail-container">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="currentcolor"><path d="M21.25 9.14969C18.94 5.51969 15.56 3.42969 12 3.42969C10.22 3.42969 8.49 3.94969 6.91 4.91969C5.33 5.89969 3.91 7.32969 2.75 9.14969C1.75 10.7197 1.75 13.2697 2.75 14.8397C5.06 18.4797 8.44 20.5597 12 20.5597C13.78 20.5597 15.51 20.0397 17.09 19.0697C18.67 18.0897 20.09 16.6597 21.25 14.8397C22.25 13.2797 22.25 10.7197 21.25 9.14969ZM12 16.0397C9.76 16.0397 7.96 14.2297 7.96 11.9997C7.96 9.76969 9.76 7.95969 12 7.95969C14.24 7.95969 16.04 9.76969 16.04 11.9997C16.04 14.2297 14.24 16.0397 12 16.0397Z"></path><path d="M12.0004 9.13965C10.4304 9.13965 9.15039 10.4196 9.15039 11.9996C9.15039 13.5696 10.4304 14.8496 12.0004 14.8496C13.5704 14.8496 14.8604 13.5696 14.8604 11.9996C14.8604 10.4296 13.5704 9.13965 12.0004 9.13965Z"></path></svg>
                                <span class="detail-label">تعداد بازدید : </span>
                                <span><?= view_giftmax(get_the_ID())?></span>
                            </span>
                            <span class="author detail-container">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="currentcolor"><path d="M21 22H3C2.59 22 2.25 21.66 2.25 21.25C2.25 20.84 2.59 20.5 3 20.5H21C21.41 20.5 21.75 20.84 21.75 21.25C21.75 21.66 21.41 22 21 22Z"></path><path d="M19.0196 3.47967C17.0796 1.53967 15.1796 1.48967 13.1896 3.47967L11.9796 4.68967C11.8796 4.78967 11.8396 4.94967 11.8796 5.08967C12.6396 7.73967 14.7596 9.85967 17.4096 10.6197C17.4496 10.6297 17.4896 10.6397 17.5296 10.6397C17.6396 10.6397 17.7396 10.5997 17.8196 10.5197L19.0196 9.30967C20.0096 8.32967 20.4896 7.37967 20.4896 6.41967C20.4996 5.42967 20.0196 4.46967 19.0196 3.47967Z"></path><path d="M15.6103 11.5298C15.3203 11.3898 15.0403 11.2498 14.7703 11.0898C14.5503 10.9598 14.3403 10.8198 14.1303 10.6698C13.9603 10.5598 13.7603 10.3998 13.5703 10.2398C13.5503 10.2298 13.4803 10.1698 13.4003 10.0898C13.0703 9.8098 12.7003 9.4498 12.3703 9.0498C12.3403 9.0298 12.2903 8.9598 12.2203 8.8698C12.1203 8.7498 11.9503 8.5498 11.8003 8.3198C11.6803 8.1698 11.5403 7.9498 11.4103 7.7298C11.2503 7.4598 11.1103 7.1898 10.9703 6.9098C10.9491 6.86441 10.9286 6.81924 10.9088 6.77434C10.7612 6.44102 10.3265 6.34358 10.0688 6.60133L4.34032 12.3298C4.21032 12.4598 4.09032 12.7098 4.06032 12.8798L3.52032 16.7098C3.42032 17.3898 3.61032 18.0298 4.03032 18.4598C4.39032 18.8098 4.89032 18.9998 5.43032 18.9998C5.55032 18.9998 5.67032 18.9898 5.79032 18.9698L9.63032 18.4298C9.81032 18.3998 10.0603 18.2798 10.1803 18.1498L15.9016 12.4285C16.1612 12.1689 16.0633 11.7235 15.7257 11.5794C15.6877 11.5632 15.6492 11.5467 15.6103 11.5298Z"></path></svg>
                                <span class="detail-label">نویسنده : </span>
                                <span class="detail-content">
                                  <?=giftmax_get_author_full_name()?>
                                </span>
                            </span>
                            <span class="posted_in detail-container">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="currentcolor"><path d="M21.67 14.3L21.27 19.3C21.12 20.83 21 22 18.29 22H5.71001C3.00001 22 2.88001 20.83 2.73001 19.3L2.33001 14.3C2.25001 13.47 2.51001 12.7 2.98001 12.11C2.99001 12.1 2.99001 12.1 3.00001 12.09C3.55001 11.42 4.38001 11 5.31001 11H18.69C19.62 11 20.44 11.42 20.98 12.07C20.99 12.08 21 12.09 21 12.1C21.49 12.69 21.76 13.46 21.67 14.3Z" stroke="inherit" stroke-width="1.5" stroke-miterlimit="10"/> <path d="M3.5 11.43V6.28003C3.5 2.88003 4.35 2.03003 7.75 2.03003H9.02C10.29 2.03003 10.58 2.41003 11.06 3.05003L12.33 4.75003C12.65 5.17003 12.84 5.43003 13.69 5.43003H16.24C19.64 5.43003 20.49 6.28003 20.49 9.68003V11.47" stroke="inherit" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/> <path d="M9.42993 17H14.5699" stroke="inherit" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/></svg>
                                <span class="detail-label">دسته بندی : </span>
                                <span class="detail-content"><a href="<?=esc_url($cat_link)?>"><?=$cat->cat_name?></a></span>
                            </span>
                        </div>
                    </div>
                </div>
                <div  class="post-content entry-content mce-content-body">
                    <?=get_the_content(); ?>
                </div>
                <div class="act-hor-bor"></div>
                <div class="act-blog-tags-1st d-flex flex-wrap align-items-center justify-content-start">

                    <div class="act-blog-tags-title"> برچسب: </div>

                    <div class="act-blog-tags-main d-flex flex-wrap align-items-center justify-content-start">
                        <?php if ( has_tag() ) : /* وجود برچسب؟ */ ?>
                            <span class="tags">
                            <?php
                            the_tags( '', ', ', '' );
                            ?>
                        </span>
                        <?php else :?>
                            <div class="act-no-tags">بدون برچسب</div>
                        <?php endif; ?>
                    </div>

                </div>
            </div>

            <div class="lg:w-25">
                <?php
                $args = [
                        'post_type'      => 'product',
                        'posts_per_page' => -1,
                        'meta_query'     => [
                                'relation' => 'AND',

                                [
                                        'key'     => '_sale_price',
                                        'value'   => 0,
                                        'compare' => '>',
                                        'type'    => 'NUMERIC',
                                ]
                        ],
                ];

                $query = new \WP_Query($args);
                if ($query->have_posts()) {
                    ?>
                    <div class="mb-3">
                        <div class="act-new-service-carousel-1st" id="LoadCategory">
                            <div class="act-new-service-carousel-head d-flex align-items-center justify-content-between w-full">
                                <div class="act-2line-title-1st d-flex align-items-center justify-content-start act-2line-title-1stdred">
                                    <div class="act-2line-title-divs d-flex flex-column align-items-start">
                                        <div class="act-2line-title-div-1"></div>
                                        <div class="act-2line-title-div-2"></div>
                                    </div>
                                    <div class="act-2line-title-text">
                                        <div class="act-2line-title-text-1">
                                            <h4 class="act-2line-title-text-1">از تخفیف  <strong>جا نمونی</strong></h4>
                                        </div>
                                        <p class="act-2line-title-text-2">NO DISCOUNT</p>
                                    </div>
                                </div>
                                <div class="act-new-service-carousel-head-content">
                                    <div class="act-new-service-carousel-buttons">
                                        <div class="act-percent-but-r act-percent-but act-carousel-but" tabindex="0" role="button" aria-label="Previous slide" aria-controls="swiper-wrapper-5a458f817b4750df" aria-disabled="false">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="currentcolor">
                                                <path d="M14.4301 18.8201C14.2401 18.8201 14.0501 18.7501 13.9001 18.6001C13.6101 18.3101 13.6101 17.8301 13.9001 17.5401L19.4401 12.0001L13.9001 6.46012C13.6101 6.17012 13.6101 5.69012 13.9001 5.40012C14.1901 5.11012 14.6701 5.11012 14.9601 5.40012L21.0301 11.4701C21.3201 11.7601 21.3201 12.2401 21.0301 12.5301L14.9601 18.6001C14.8101 18.7501 14.6201 18.8201 14.4301 18.8201Z"></path>
                                                <path d="M20.33 12.75H3.5C3.09 12.75 2.75 12.41 2.75 12C2.75 11.59 3.09 11.25 3.5 11.25L20.33 11.25C20.74 11.25 21.08 11.59 21.08 12C21.08 12.41 20.74 12.75 20.33 12.75Z"></path>
                                            </svg>
                                        </div>
                                        <div class="act-percent-but-l act-percent-but act-carousel-but swiper-button-disabled" tabindex="-1" role="button" aria-label="Next slide" aria-controls="swiper-wrapper-5a458f817b4750df" aria-disabled="true">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="currentcolor">
                                                <path d="M9.56988 5.17988C9.75988 5.17988 9.94988 5.24988 10.0999 5.39988C10.3899 5.68988 10.3899 6.16988 10.0999 6.45988L4.55988 11.9999L10.0999 17.5399C10.3899 17.8299 10.3899 18.3099 10.0999 18.5999C9.80988 18.8899 9.32988 18.8899 9.03988 18.5999L2.96988 12.5299C2.67988 12.2399 2.67988 11.7599 2.96988 11.4699L9.03988 5.39988C9.18988 5.24988 9.37988 5.17988 9.56988 5.17988Z"></path>
                                                <path d="M3.67 11.25H20.5C20.91 11.25 21.25 11.59 21.25 12C21.25 12.41 20.91 12.75 20.5 12.75L3.67 12.75C3.26 12.75 2.92 12.41 2.92 12C2.92 11.59 3.26 11.25 3.67 11.25Z"></path>
                                            </svg>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="swiper percent-box-swiper">
                                <div class="swiper-wrapper" >
                                    <?php while ($query->have_posts()): $query->the_post();
                                        $product = wc_get_product(get_the_ID());
                                        $delivery = get_post_meta($product->get_id(), 'delivery', true);
                                        $pa =  ((isset($delivery['two']) && $delivery['two'] == 'on') || product_available($product->get_id()));
                                        if (!$pa){
                                            continue;
                                        }
                                        $regular = $product->get_regular_price();
                                        $sale    = $product->get_sale_price();

                                        $discount = round((($regular - $sale) / $regular) * 100);
                                        $img = get_the_post_thumbnail_url(get_the_ID(), 'product_discount');
                                        $title = get_the_title();
                                        $settings = get_post_meta(get_the_ID(), 'giftmax_box_setting', true);
                                        $date_from = $product->get_date_on_sale_from();
                                        $date_to   = $product->get_date_on_sale_to();
                                        if ($product->is_on_sale() && ($date_from || $date_to)) {
                                            $sale_to = $product->get_date_on_sale_to();
                                            $sale_to_ts = $sale_to ? $sale_to->getTimestamp() : null;
                                        }else{
                                            $sale_to_ts = null;
                                        }
                                        $tooltip = isset($delivery['description']) ? $delivery['description'] : '';
                                        ?>
                                        <div class="swiper-slide">
                                            <div class="act-percent-card">
                                                <div class="flex flex-col">
                                                    <div class="relative">
                                                        <div class="act-new-service-card-inner-top">
                                                            <a href="<?=get_permalink()?>">
                                                                <div class="flex dj45fd">
                                                                    <?php
                                                                    $tooltip = isset($delivery['description']) ? $delivery['description'] : '';
                                                                    ?>
                                                                    <div class="act-product-option-box__nw <?=isset($delivery['two']) && $delivery['two'] == 'on' ? 'pre-sale wiki wiki__holder js-dk-wiki-trigger' : 'same-day'?>" <?=isset($delivery['two']) && $delivery['two'] == 'on' ? 'data-tooltip="'. $tooltip .'"' :''?>><?=isset($delivery['two']) && $delivery['two'] == 'on' ? 'پیش فروش' : 'تحویل آنی'?></div>
                                                                    <div class="purchaseScore wiki wiki__holder js-dk-wiki-trigger" data-tooltip="با خرید این گیفت کارت <?=empty($settings[0]['purchaseScore']) ?0: $settings[0]['purchaseScore']?> امتیاز دریافت میکنید">
                                                                        <i class="icon-star"></i>
                                                                        <?=empty($settings[0]['purchaseScore']) ?0: $settings[0]['purchaseScore']?>
                                                                    </div>
                                                                    <?php
                                                                    if (!empty($settings[0]['label']) && $settings[0]['label'] != ''){?>
                                                                        <div class="label-fjd84">
                                                                            <img src="<?=empty($settings[0]['label']) ?'': $settings[0]['label']?>" class="logo_label">
                                                                            <p class="label_title"><?=empty($settings[0]['label_title']) ?'': $settings[0]['label_title']?></p>
                                                                        </div>
                                                                        <?php
                                                                    }
                                                                    ?>
                                                                </div>
                                                                <div class="act-new-service-card-inner-top-img-box relative aib36">
                                                                    <img loading="lazy" decoding="async" width="32" height="33" src="<?=$img?>" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="">
                                                                </div>
                                                            </a>
                                                        </div>
                                                        <?php
                                                        if (!empty($settings[0]['logo_region'])){
                                                            ?>
                                                            <div class="logo_region">
                                                                <img src="<?=empty($settings[0]['logo_region']) ?: get_template_directory_uri() . '/assets/flag/' . $settings[0]['logo_region'] . '.svg'?>">
                                                            </div>
                                                            <?php
                                                        }
                                                        ?>
                                                        <div class="act-product-price-off-percent">  <?=get_discount_percent($product)?> ٪       </div>
                                                    </div>
                                                    <div class="act-bar-left">
                                                        <div class="flex justify-between">
                                                            <a class="lg:w-80" href="<?=get_permalink()?>">
                                                                <h4 class="ellipsis"><?=get_the_title()?></h4>
                                                            </a>                                                            <?php
                                                            $giftmax_is_user_logged_in = is_user_logged_in();
                                                            $giftmax_wishlist_ids = $giftmax_is_user_logged_in ? giftmax_get_user_wishlist_product_ids() : [];
                                                            if ($giftmax_is_user_logged_in){
                                                                $is_in_wishlist = in_array((int) $product->get_id(), $giftmax_wishlist_ids, true); ?>
                                                                <button class="add-to__favorites Button-alu84 <?=$is_in_wishlist ? 'is-active' : ''?>" data-product-id="<?=esc_attr($product->get_id())?>" style="width: 28px;height: 28px;border-radius: 7px">
                                                                    <svg viewBox="0 0 24 24" style="width: 64%;">
                                                                        <path d="M12.62 20.81C12.28 20.93 11.72 20.93 11.38 20.81C8.48 19.82 2 15.69 2 8.68998C2 5.59998 4.49 3.09998 7.56 3.09998C9.38 3.09998 10.99 3.97998 12 5.33998C13.01 3.97998 14.63 3.09998 16.44 3.09998C19.51 3.09998 22 5.59998 22 8.68998C22 15.69 15.52 19.82 12.62 20.81Z" fill="<?=$is_in_wishlist ? '#ef4444' : 'none'?>" stroke="<?=$is_in_wishlist ? '#ef4444' : 'inherit'?>" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                                                                    </svg>
                                                                </button>
                                                                <?php
                                                            }
                                                            ?>
                                                        </div>
                                                        <?php
                                                        if(!empty($settings[0]['sub_head']) && !isMobile()) echo "<p class='act-product-title-en mb-1'>" . $settings[0]['sub_head'] . "</p>";
                                                        ?>
                                                        <div class="flex justify-between mb-1 kef4e">
                                                            <?php
                                                            if (!is_null($sale_to_ts)){
                                                                ?>
                                                                <img class="inline-block lg:w-30" src="<?=get_template_directory_uri()?>/assets/img/svg/IncredibleOffer.svg" alt="" title="" style="object-fit: contain;">
                                                                <div class="text-primary-700 text-body2-strong" style="display:block;"><i class="icon-clock mr-1"></i><span class="style_ProductPromotionTimeline__timer__zS6ZA"><?= date('Y-m-d H:i:s', $sale_to_ts); ?></span></div>

                                                                <?php
                                                            }else{ ?>
                                                                <img class="inline-block lg:w-30" src="<?=get_template_directory_uri()?>/assets/img/svg/Offer.svg" alt="" title="" style="object-fit: contain;">

                                                                <?php
                                                            }
                                                            ?>
                                                        </div>

                                                        <div class="flex justify-between w-full">
                                                            <?php
                                                            if (isset($delivery['two']) && $delivery['two'] == 'on' || product_available($product->get_id())){?>
                                                                <button data-product-id="<?=$product->get_id()?>" class="act-percent-card-buy-box-but Button-aca49 pointer" type="button">
                                                                    افزودن به سبد خرید
                                                                </button>
                                                            <?php }else{
                                                                echo '<div class="inaJSDge8" style="height: 30px">ناموجود</div>';
                                                            }?>
                                                            <div class="act-product-price-box">
                                                                <div class="act-product-price bpt">
                                                                    <div id="priceValue" data-id="<?=$product->get_id()?>" data-target="<?=$product->is_on_sale() ? $sale :$regular?>"><?=number_format_usd($sale)?></div>
                                                                    <span>تومان</span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endwhile; ?>
                                </div>
                                <span class="swiper-notification" aria-live="assertive" aria-atomic="true"></span>
                            </div>
                        </div>
                    </div>
                    <?php
                }
                if ( $related->have_posts() ) : ?>
                    <div >
                        <div class="act-2line-title-1st d-flex align-items-center justify-content-start act-2line-title-1stdred">
                            <div class="act-2line-title-divs d-flex flex-column align-items-start">
                                <div class="act-2line-title-div-1"></div>
                                <div class="act-2line-title-div-2"></div>
                            </div>
                            <div class="act-2line-title-text">
                                <div class="act-2line-title-text-1">
                                    <h4 class="act-2line-title-text-1">آخرین <strong>مقالات</strong></h4>
                                </div>
                                <p class="act-2line-title-text-2">Latest Articles</p>
                            </div>
                        </div>
                        <div class="Simillar-Blogs-card_1st">
                            <?php while ( $related->have_posts() ) : $related->the_post(); ?>
                                <a class="Simillar-Blogs-card act-bg-hover" href="<?=the_permalink()?>">
                                    <div class="act-bg-hover-inner Simillar-Blogs-card-inner d-flex flex-column justify-content-between">
                                        <div class="Simillar-Blogs-card-top d-flex">
                                            <img src="<?=get_the_post_thumbnail_url() ?>" alt="<?=get_the_title()?>" class="gp-blog-card-two-img">
                                            <h3 class="gpx-card-name oneline-show gp-blog-card-two-title"><?=get_the_title()?></h3>
                                        </div>


                                        <div class="act-blog-card-footer d-flex align-content-center justify-content-between">
                                            <div class="act-blog-card-footer-read-time">
                                                <div class="flex align-items-center ml-16 line-height-1"><i class="icon-eye"></i><p><?= view_giftmax(get_the_ID())?></p></div><div class="flex align-items-center line-height-1"><i class="icon-user"></i><?=giftmax_get_author_full_name()?><div class="flex align-items-center blog_clock-view d-none"><i class="icon-clock"></i><?=gjdate(get_the_date('Y-m-d',get_the_ID()),"d M Y")?></div></div>
                                            </div>
                                            <div class="act-blog-card-link">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="26" height="26" viewBox="0 0 26 26" fill="currentcolor">
                                                    <path d="M15.0559 8.6175C14.9551 8.71827 14.8173 8.78191 14.6582 8.78191L8.7821 8.78191L8.7821 14.658C8.7821 14.9656 8.52755 15.2201 8.21996 15.2201C7.91236 15.2201 7.6578 14.9656 7.6578 14.658L7.6578 8.21976C7.6578 7.91216 7.91236 7.65761 8.21995 7.65761L14.6582 7.65761C14.9658 7.65761 15.2203 7.91216 15.2203 8.21976C15.2256 8.37355 15.1567 8.51674 15.0559 8.6175Z"></path>
                                                    <path d="M17.6333 17.6332C17.4159 17.8506 17.0553 17.8506 16.8379 17.6332L7.9124 8.7077C7.69496 8.49027 7.69496 8.12964 7.9124 7.91221C8.12983 7.69477 8.49046 7.69477 8.70789 7.91221L17.6333 16.8377C17.8508 17.0551 17.8508 17.4157 17.6333 17.6332Z"></path>
                                                </svg>
                                            </div>
                                        </div>
                                    </div>
                                </a>
                            <?php endwhile; ?>
                        </div>
                    </div>

                <?php
                endif;
                $db = \Giftmax\modules\Db::getLnstance();
                global $wpdb;
                $records = $db->first("SELECT meta_value FROM `{$wpdb->prefix}setting` WHERE `meta_key`=:key",array('key'=>'ads'));
                if (!empty($records)){
                ?>
                <div class="mt-62">
                    <div class="act-2line-title-1st d-flex align-items-center justify-content-start">
                        <div class="act-2line-title-divs d-flex flex-column align-items-start">
                            <div class="act-2line-title-div-1"></div>
                            <div class="act-2line-title-div-2"></div>
                        </div>
                        <div class="act-2line-title-text">
                            <div class="act-2line-title-text-1">
                                <h4 class="act-2line-title-text-1"> <strong>تبلیغات</strong></h4>
                            </div>
                            <p class="act-2line-title-text-2">Ads</p>
                        </div>
                    </div>
                    <div class="flex flex-col gap-3 mt-22">
                        <?php
                        $records = json_decode($records['meta_value'],true);
                        foreach ($records as $record){?>
                            <a href="<?=$record['link']?>" class="Ads-Blogs-card">
                                <img src="<?=$record['img']?>" alt="ads blogs">
                            </a>
                            <?php
                        }
                        ?>
                    </div>
                    <?php
                    }
                    ?>
                </div>
    </main>
<?php
get_footer();
