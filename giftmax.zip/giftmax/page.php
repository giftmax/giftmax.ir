<?php
    get_header();
    if (is_page('profile') || is_page('ticket') || is_page('notifications') || is_page('blogs') || is_page('contact') || is_page('incredible-offers')) {
    ?>
    <main class="c-main js-layout-main-content<?= is_page('profile') ? ' c-profile-page' : ''?><?= is_page('ticket') || is_page('notifications') ? ' c-content-layout' : ''?>">
        <?php the_content(); ?>
    </main>
    <?php
    }else{
        ?>
        <main class="c-main js-layout-main-content container-2xl-w mx-auto mt-32">
            <?php the_content(); ?>
        </main>
<?php
    }
    get_footer();

?>
