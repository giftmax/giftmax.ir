
<?php

$post = get_post(0);
$leavename = false;
$sample = false;
$permalink = get_attachment_link($post, $leavename);
$permalink = str_ireplace(home_url(), '', $permalink);
$permalink = str_ireplace('/', '', $permalink);
if ($permalink != 'login-register'){
$args   = array(
    'post_type'      => 'shop_coupon',
    'posts_per_page' => -1,
    'post_status'    => 'publish',
);
$query  = new WP_Query( $args );
$output = '';

if (  $query->have_posts() ) {
?>
    <div class="swiper my-coupons-slider styles-discount__SJFg6">
                <div class="swiper-wrapper">
                    <?php
                    while ( $query->have_posts() ) {
                        $query->the_post();

                        $coupon_obj    = new WC_Coupon( get_the_ID() );
                        $products      = $coupon_obj->get_product_ids(); // not used here but you can
                        $discount_type = $coupon_obj->get_discount_type();
                        $amount        = $coupon_obj->get_amount();

                        switch ( $discount_type ) {
                            case 'percent':
                                $discount_text = $amount . '%';
                                break;
                            case 'fixed_cart':
                            case 'fixed_product':
                                $discount_text = number_format_usd( $amount) . ' تومان';
                                break;
                            default:
                                $discount_text = 'نامشخص';
                        }

                        $expiry_date   = $coupon_obj->get_date_expires();
                        if ( $expiry_date && $expiry_date->getTimestamp() < time() ) {
                            continue;
                        }
                        $usage_limit   = $coupon_obj->get_usage_limit();
                        $usage_count   = $coupon_obj->get_usage_count();
                        $remaining     = $usage_limit
                            ? max( 0, $usage_limit - $usage_count )
                            : 'نامحدود';
                        $remaining_co     = $usage_limit
                            ? max( 0, $usage_limit - $usage_count )
                            : 0;
                        ?>
                        <div class="swiper-slide">
                            <div class="close-wrapper__discount">
                                <div class="d-flex pointer" data-testid="close-wrapper"> <svg style="width: 24px; height: 24px; fill: var(--color-icon-high-emphasis);"> <path d="M12 11.0537C12 11.0537 16.2827 6.77342 17.8617 5.19523C18.1221 4.93492 18.5443 4.93492 18.8047 5.19523C19.0651 5.45553 19.0651 5.87753 18.8047 6.13783C17.2257 7.71602 12.9391 12 12.9391 12C12.9391 12 17.2257 16.284 18.8047 17.8622C19.0651 18.1225 19.0651 18.5445 18.8047 18.8047C18.5443 19.0651 18.1221 19.0651 17.8617 18.8048C16.2827 17.2266 12 12.9463 12 12.9463C12 12.9463 7.7173 17.2266 6.1383 18.8048C5.8779 19.0651 5.4557 19.0651 5.1953 18.8048C4.9349 18.5445 4.9349 18.1225 5.1953 17.8622C6.7743 16.284 11.0609 12 11.0609 12C11.0609 12 6.7743 7.71602 5.1953 6.13783C4.9349 5.87753 4.9349 5.45552 5.1953 5.19533C5.4557 4.93493 5.8779 4.93492 6.1383 5.19523C7.7173 6.77342 12 11.0537 12 11.0537Z"></path> </svg></div>
                            </div>
                            <div class="styles-discount-_slide__SJFg6 color-n-500 text-caption uikit-collections--FAf2Q md:h-54 h-auto">
                                <div class="relative w-full">

                                    <?php
                                    $links = [];

                                    foreach ( $products as $product_id ) {
                                        $product = wc_get_product( $product_id );

                                        if ( ! $product ) {
                                            continue;
                                        }
                                        $settings = get_post_meta($product_id, 'giftmax_box_setting', true);
                                        if (!empty($settings[0]['sub_head'])) {
                                            $links[] = sprintf(
                                                '<a class="ellipsis-1" href="%s"><h4 class="act-product-title">%s<span class="act-product-en">(%s)</span></h4></a>',
                                                esc_url($product->get_permalink()),
                                                esc_html($product->get_name()),
                                                $settings[0]['sub_head']
                                            );
                                        }else{
                                            $links[] = sprintf(
                                                '<a class="ellipsis-1" href="%s"><h4 class="act-product-title">%s</h4></a>',
                                                esc_url($product->get_permalink()),
                                                esc_html($product->get_name())
                                            );
                                        }
                                    }
                                    ?>
                                    <div class="flex justify-between md:gap-3 align-items-center flex-wrap">
                                        <div class="flex justify-between lg:w-50 md:w-15 align-items-center">
                                            <h4>کد تخفیف</h4>
                                            <div class="coupons kgjSF5 w-full md:w-70!">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="19" viewBox="0 0 18 19" fill="none"><path d="M15 7.47754H8.25C7.42157 7.47754 6.75 8.14911 6.75 8.97754V15.7275C6.75 16.556 7.42157 17.2275 8.25 17.2275H15C15.8284 17.2275 16.5 16.556 16.5 15.7275V8.97754C16.5 8.14911 15.8284 7.47754 15 7.47754Z" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path><path d="M3.75 11.9775H3C2.60218 11.9775 2.22064 11.8195 1.93934 11.5382C1.65804 11.2569 1.5 10.8754 1.5 10.4775V3.72754C1.5 3.32971 1.65804 2.94818 1.93934 2.66688C2.22064 2.38557 2.60218 2.22754 3 2.22754H9.75C10.1478 2.22754 10.5294 2.38557 10.8107 2.66688C11.092 2.94818 11.25 3.32971 11.25 3.72754V4.47754" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path></svg>
                                                <span style="line-height: 1"><?=$coupon_obj->get_code()?></span>
                                            </div>
                                        </div>
                                        <div class="w-[50px] flex justify-between align-items-center">
                                            <h3 >تعداد : <?=$remaining?></h3>
                                        </div>
                                        <div class="flex gap-3 md:w-30 w-auto SKDJ5">برای محصول: <?=implode('', $links)?></div>
                                        <p class="styles-discount__text w-auto md:w-15"> به اعتبار :<?=$discount_text?></p>
                                        <?php
                                        if ($expiry_date){
                                            ?>
                                            <div class="styles-discount__text2 w-auto md:w-16 flex justify-between align-items-center SODJr5">معتبر :
                                                <div class="act-special-carousel-head-timer special-offers-timer mt-0" data-due-date="<?=$expiry_date->date_i18n( 'Y-m-d H:i:s' ) ?>" style="margin-top: 0">

                                                    <div class="special-offers-timer-shadow"></div>
                                                    <div class="act-special-carousel-head-timer-item box">
                                                        <p class="sp-seconds">0</p><span>ثانیه</span>
                                                    </div>
                                                    <div class="act-special-carousel-head-timer-item-border">:</div>
                                                    <div class="act-special-carousel-head-timer-item box">
                                                        <p class="sp-minutes">0</p><span>دقیقه</span>
                                                    </div>
                                                    <div class="act-special-carousel-head-timer-item-border">:</div>
                                                    <div class="act-special-carousel-head-timer-item box">
                                                        <p class="sp-hours">0</p><span>ساعت</span>
                                                    </div>
                                                    <div class="act-special-carousel-head-timer-item-border">:</div>
                                                    <div class="act-special-carousel-head-timer-item box">
                                                        <p class="sp-days">0</p><span>روز</span>
                                                    </div>

                                                </div>
                                            </div>
                                            <?php
                                        }else{?>
                                            <div class="styles-discount__text2 lg:w:16 flex justify-end align-items-center">بدون تاریخ انقضا</div>
                                            <?php
                                        }
                                        ?>
                                        <div class="w-full md:w-16 flex relative justify-end">
                                            <div class="absolute h-8 w-8 child:rounded-circle child:bg-red top-8 right-0">
                                            <div class="animate-ping absolute inset-x-0 inset-y-0 opacity-75"></div>
                                            <div class="relative h-full w-full"></div>
                                            </div>
                                        <p> کد تخفیف یکبار مصرف میباشد دقت حاصل فرمایید!</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php
                    }
                    ?>
                </div>

    </div>
    <?php
}
    ?>
    <div id="go-to-blabla" class="">
        <?php
        if (is_user_logged_in()) {
        ?>
        <div class="btn-go sticky_toolbox pointer lottie-container" data-lottie-url="<?=get_template_directory_uri()?>/assets/img/wsl/support.json" onclick="window.location.href='<?=home_url('/ticket')?>'"  title="تیکت و پشتیبانی فنی"></div>
        <div class="btn-go icon-cart-o hidden md:flex sticky_toolbox pointer Cart-gd445 relative" title="سبد خرید"></div>
        <?php
        }
        ?>
        <div class="btn-go icon-arrow-up pointer"></div>
    </div>
        <div class="relative tp-contact-bor">
    <section class="container-xl-w mx-auto">
        <div class="tp-contact-bar">
            <div class="tp-contact-right">
                <div class="tp-phone-icon">
                    <i class="icon-phone-ring"></i>
                </div><div class="tp-contact-center">
                    <h3>سوالی دارید؟</h3>
                    <p>برای پاسخگویی به سوالات شما، هر روز به صورت ۲۴ ساعته در کنار شما هستیم</p>
                </div>
            </div>
            <div class="tp-contact-left">

                <div class="tp-btn Button-cu46 pointer">تماس با ما</div>
            </div>
        </div>
    </section></div>
<footer class="w-full bg_while pt-8">
    <div class="container-2xl-w mx-auto flex flex-col ">
        <div class="">
            <div class="d-flex">
                <div class="lg:w-40">
                    <ul class="nav nav-menu mb-xl-4 mb-3 md:flex hidden">
                        <li class="nav-item me-2">
                            <a href="<?=home_url('/faq')?>" class="nav-link text-light fw-medium py-1 px-2 rounded-1 overflow-hidden position-relative">
                                سوالات متداول                                    </a>
                        </li>
                        <li class="nav-item me-2">
                            <a href="<?=home_url('/our-rules')?>" class="nav-link text-light fw-medium py-1 px-2 rounded-1 overflow-hidden position-relative">
                                قوانین                                    </a>
                        </li>
                        <li class="nav-item me-2">
                            <a href="<?=home_url('/payment-methods')?>" class="nav-link text-light fw-medium py-1 px-2 rounded-1 overflow-hidden position-relative">
                                روش&zwnj;های پرداخت                                    </a>
                        </li>
                        <li class="nav-item me-2">
                            <a href="<?=home_url('/blog')?>" class="nav-link text-light fw-medium py-1 px-2 rounded-1 overflow-hidden position-relative">
                                وبلاگ                                    </a>
                        </li>
                        <li class="nav-item me-2">
                            <a href="<?=home_url('/about')?>" class="nav-link text-light fw-medium py-1 px-2 rounded-1 overflow-hidden position-relative">
                                درباره ما                                    </a>
                        </li>
                        <li class="nav-item me-2">
                            <a href="<?=home_url('/contact-us')?>" class="nav-link text-light fw-medium py-1 px-2 rounded-1 overflow-hidden position-relative">
                                تماس با ما                                    </a>
                        </li>
                    </ul>
                    <div class="flex items-center justify-between sx:flex-col">
                        <a href="/">
                        <img alt="<?=get_bloginfo('name')?>" loading="lazy" decoding="async" data-nimg="1" style="color:transparent" src="<?=get_template_directory_uri()?>/assets/img/logo.png">
                        </a>
                        <ul class="nav nav-social mt-xl-0 mt-lg-3 mt-0">
                            <?php
                            if(\Giftmax\Modules\UserModel::setting("email") == 'true'){?>
                                <li class="nav-item">
                                    <a href="mailto:<?=\Giftmax\Modules\UserModel::settingValue("email")?>" class="nav-link p-0 rounded-2 d-flex align-items-center justify-content-center text-light" rel="follow noopener noreferrer" aria-label="LinkedIn">
                                        <i class="icon-message-fill"></i>
                                    </a>
                                </li>
                                <?php
                            }
                            ?>
                    <?php
                    if(\Giftmax\Modules\UserModel::setting("telegram") == 'true'){?>
                        <li class="nav-item">
                            <a href="<?=\Giftmax\Modules\UserModel::settingValue("telegram")?>" class="nav-link p-0 rounded-2 d-flex align-items-center justify-content-center text-light" rel="follow noopener noreferrer" aria-label="LinkedIn">
                                <i class="icon-telegram"></i>
                            </a>
                        </li>
                        <?php
                    }
                    if(\Giftmax\Modules\UserModel::setting("instagram") == 'true'){?>
                        <li class="nav-item">
                            <a href="<?=\Giftmax\Modules\UserModel::settingValue("instagram")?>" class="nav-link p-0 rounded-2 d-flex align-items-center justify-content-center text-light" rel="follow noopener noreferrer" aria-label="LinkedIn">
                                <i class="icon-instagram"></i>
                            </a>
                        </li>
                        <?php
                    }
                    if(\Giftmax\Modules\UserModel::setting("whatsapp") == 'true'){?>
                        <li class="nav-item">
                            <a href="<?=\Giftmax\Modules\UserModel::settingValue("whatsapp")?>" class="nav-link p-0 rounded-2 d-flex align-items-center justify-content-center text-light" rel="follow noopener noreferrer" aria-label="LinkedIn">
                                <i class="icon-whatsapp"></i>
                            </a>
                        </li>
                        <?php
                    }
                    ?>
                        </ul>
                    </div>
                    <div class="text-dark text-2xs lg:text-xs mt-14 text-justify">
                        <p>گیفت مکث سامانه خرید آنلاین گیفت کارت و کارت هدیه با پرداخت ریالی و تحویل آنی و اتوماتیک است. در گیفت مکث مجموعه&zwnj;ای متنوع از کارتهای هدیه مناطق مختلف در دسترس شماست. پشتیبانی ۲۴ ساعته، سیستم همکاری در فروش، باشگاه مشتریان و امکان ارسال گیفت کارت هدیه تنها بخشی از امکانات گیفت مکث هستند.</p>
                    </div>
                </div>
                <div class="lg:w-60 md:p-20 xs:mt-5 pt-0 grid md:grid-cols-3">
                    <div class="list_meno">
                        <div class="box">
                        <div class="flex items-center justify-between toggle-header">
                            <h5 class="text-secondary text-lg font-bold tracking-tight">پرمخاطب‌ترین مطالب وبلاگ</h5><span class="toggle-icon"></span>
                        </div>
                        <ul class="mt-14">
                            <?php
                            $popular_posts = get_top_five_viewed_posts();

                            if ( $popular_posts->have_posts() ) {
                                while ( $popular_posts->have_posts() ) {
                                    $popular_posts->the_post();
                                    ?>
                                    <li>
                                        <a class="text-xs font-normal text-dark hover:text-blue-dark transition-colors block leading-xs ellipsis" href="<?php the_permalink(); ?>">
                                            <?php the_title(); ?>
                                        </a>
                                    </li>
                                    <?php
                                }
                                wp_reset_postdata();
                            } else {
                                echo '<p>مقاله‌ای یافت نشد.</p>';
                            }
                            ?>
                        </ul>
                    </div>
                    </div>
                    <div class="list_meno">
                        <div class="box">
                        <div class="flex items-center justify-between toggle-header">
                            <h5 class="text-secondary text-lg font-bold tracking-tight">دسترسی سریع</h5><span class="toggle-icon"></span>
                        </div>
                        <ul class="mt-14">
                            <?php
                            wp_nav_menu([
                                'theme_location' => 'quick-access',
                                'container'      => false,
                                'items_wrap'     => '%3$s',
                                'walker'         => new Custom_Menu_Walker('quick-access')
                            ]);
                            ?>
                        </ul>
                        </div>
                    </div>
                    <div class="list_meno">
                        <div class="box">

                        <div class="flex items-center justify-between toggle-header"><h5 class="text-secondary text-lg font-bold tracking-tight">راهنمایی و پشتیبانی</h5><span class="toggle-icon"></span> </div>
                        <ul class="mt-14">
                            <?php
                            wp_nav_menu([
                                'theme_location' => 'help-support',
                                'container'      => false,
                                'items_wrap'     => '%3$s',
                                'walker'         => new Custom_Menu_Walker('help-support')
                            ]);
                            ?>
                        </ul>
                    </div>
                    </div>
                </div>
            </div>
            <div class="flex justify-between sx:flex-col xs:mt-5">
                <?php
                if(\Giftmax\Modules\UserModel::setting("tel") == 'true'){?>
                <div class="box box2 rounded-3 fw-medium flex align-items-center justify-content-center justify-content-sm-start p-sm-3 p-2 h-76">
                    <i class="icon-phone-ring text-primary me-xl-4 me-sm-3 me-2"></i>
                    <div class="text-light">
                        <b class="d-block text-dark fw-bold">
                            خطوط پشتیبانی
                        </b>
                        (هر روز از ۱۰ الی ۱۷)
                    </div>
                    <div class="line d-block mx-xl-4 mx-sm-3 mx-2"></div>
                    <div class="number text-primary fw-bold">
                        <a href="tel:<?=str_replace('-','',\Giftmax\Modules\UserModel::settingValue("tel"))?>"><?=\Giftmax\Modules\UserModel::settingValue("tel")?></a>
                    </div>
                </div>
                <?php
                }
                ?>
                <div class="w-auto shrink-0 self-end xs:mt-5">
                    <div class="pb-2 flex flex-row-reverse justify-center space-x-8 lg:space-x-0 lg:space-y-12">
                        <div class="flex items-center justify-center [&amp;_*]:h-full [&amp;_*]:w-auto [&amp;_*]:cursor-pointer h-76 w-76 py-10 lg:py-15 rounded-sm lg:rounded border">
                            <img alt="" loading="lazy" width="125" height="136" src="<?=get_template_directory_uri()?>/assets/img/enamad.eb6d4465.png" onclick="window.open('https://trustseal.enamad.ir/?id=509557&amp;code=oP9eQzoWjHe1kvieYT8KnChBReEMkA6B', 'Popup', 'toolbar=no, location=no, statusbar=no, menubar=no, scrollbars=1, resizable=0,  top=30,width=600,height=500')"></div>
                        <div class="flex items-center justify-center [&amp;_*]:h-full [&amp;_*]:w-auto [&amp;_*]:cursor-pointer h-76 w-76 py-10 lg:py-15 rounded-sm lg:rounded border" style="margin-left: 10px">
                            <img alt="" loading="lazy" src="<?=get_template_directory_uri()?>/assets/img/samandehi.f5fb5e30.png"
                                 width="125"
                                 onclick="window.open('https://logo.samandehi.ir/Verify.aspx?id=370552&amp;p=xlaojyoeobpddshwdshwuiwk', 'Popup', 'toolbar=no, scrollbars=no, location=no, statusbar=no, menubar=no, resizable=0, width=450, height=630, top=30')">
                        </div>
                    </div>
                </div>
            </div>
            <div class="overflow-hidden relative mt-32 djde6s5" style="height: auto">
                <ul class="flex -m-2 flex-wrap">
                    <?php
                    wp_nav_menu([
                        'theme_location' => 'footer-menu',
                        'container'      => false,
                        'items_wrap'     => '%3$s',
                        'walker'         => new Custom_Menu_Walker('footer-menu')
                    ]);
                    ?>
                </ul>
            </div>
        </div>
        <div class="w-full lg:mt-8 rounded-lg mx-auto mb-10" style="border-top: 1px solid #DCDDE8;padding: 28px;">
            <div class="flex flex-col items-center">
                <div class="grow lg:pt-4 text-2xs lg:text-xs text-dark leading-xs text-center lg:text-right">تمامی حقوق
                    مادی و معنوی این وبسایت متعلق به <a class="text-primary-dark font-medium" href="/">گیفت مکس</a> می
                    باشد و هر گونه کپی برداری پیگرد قانونی دارد.
                </div>
            </div>
        </div>
    </div>
</footer>
    <div class="bg-white shadow-dropdown-reverse z-[900] bottom-0 fixed inset-x-0 pb-safe md:hidden">
        <ul class="flex">
            <li class="w-1/5">
                <?php
                if (get_current_section_base() == '/'){?>
                <a class="block py-8 w-full">
                    <div class="w-24 sh-24 flex justify-center items-center mx-auto relative">
                        <i class="text-gray pl-2 text-2xl icon-home"></i>
                    </div>
                    <span class="block text-center tracking-tighter leading-1 text-3xs font-normal text-gray mts-4">صفحه نخست</span>
                </a>
                <?php
                }else{
                ?>
                    <a class="block py-8 w-full" href="/">
                        <div class="w-24 h-24 flex justify-center items-center mx-auto relative">
                            <i class="text-gray pl-2 text-2xl icon-home-o"></i>
                        </div>
                        <span class="block text-center tracking-tighter leading-1 text-3xs font-normal text-gray mts-4">صفحه نخست</span>
                    </a>
                <?php
                }
                ?>
            </li>
            <li class="w-1/5">
                <a class="block py-8 w-full Button-bf14">
                    <div class="w-24 h-24 flex justify-center items-center mx-auto relative">
                        <i class="text-gray pl-2 text-xl icon-flash"></i>
                    </div>
                    <span class="block text-center tracking-tighter leading-1 text-3xs font-normal text-gray mts-4">خرید سریع</span>
                </a>
            </li>
            <?php
            if (is_user_logged_in()){
            ?>
                <li class="w-1/5 sdDHd3">
                <a class="block py-8 w-full Button-scm54">
                    <div class="w-24 h-24 flex justify-center items-center mx-auto relative">
                        <i class="text-white pl-2 text-xl icon-cart"></i>
                        <?php
                        if (WC()->cart && WC()->cart->get_cart_contents_count() > 0){
                        ?>
                        <span class="absolute bg-white shadow-[0_0_0_1_1461e2] text-4xs colr-1461e2 min-w-20 leading-1 rounded-pill right-full -mr-12 -bottom-1 px-5 font-bold text-center pt-4 pb-1 tracking-ultratight dir-ltr"><?=WC()->cart->get_cart_contents_count()?></span>
                        <?php
                        }
                        ?>
                    </div>
                    <span class="block text-center tracking-tighter leading-1 text-3xs font-bold text-gray mts-4">سبد خرید</span>
                </a>
            </li>
            <li class="w-1/5">
                <a class="block py-8 w-full Button-au65">
                    <div class="w-24 h-24 flex justify-center items-center mx-auto relative">
                        <i class="text-gray pl-2 text-xl <?=get_current_section_base() == '/profile' ? 'icon-user' : 'icon-user-o'?>"></i>
                    </div>
                    <span class="block text-center tracking-tighter leading-1 text-3xs font-normal text-gray mts-4">ناحیه کاربری</span>
                </a>
            </li>
                <?php
            }else{
                ?>
                <li class="w-1/5 sdDHd3">
                    <a class="block py-8 w-full" href="/login-register" target="_blank">
                        <div class="w-24 h-24 flex justify-center items-center mx-auto relative">
                            <i class="text-white pl-2 text-xl icon-cart"></i>
                        </div>
                        <span class="block text-center tracking-tighter leading-1 text-3xs font-bold text-gray mts-4">سبد خرید</span>
                    </a>
                </li>
            <li class="w-1/5">

            <a class="block py-8 w-full" href="/login-register" target="_blank">
                    <div class="w-24 h-24 flex justify-center items-center mx-auto relative">
                        <i class="text-gray pl-2 text-xl <?=get_current_section_base() == '/profile' ? 'icon-user' : 'icon-user-o'?>"></i>
                    </div>
                    <span class="block text-center tracking-tighter leading-1 text-3xs font-normal text-gray mts-4">ناحیه کاربری</span>
                </a>
            </li>
                <?php
            }
            ?>
            <li class="w-1/5">
                <a class="block py-8 w-full Button-cu46">
                    <div class="w-24 h-24 flex justify-center items-center mx-auto relative">
                        <i class="text-gray pl-2 text-xl icon-phone-ring-o"></i></div>
                    <span class="block text-center tracking-tighter leading-1 text-3xs font-normal text-gray mts-4">تماس با ما</span>
                </a>
            </li>
        </ul>
    </div>
    <?php
}
?>
</div>
<div class="toast-container"></div>
<div id="popper-root">
    <div class="absolute">
        <div id="snackbar-container" class="pos-fixed d-flex flex-column my-3 px-4 jc-center Snackbar__container-_86cf8 <?=isMobile() ? 'top-0' : 'bottom-0'?> left-1/2 -translate-x-1/2 z-1000" style="left: 50%; transform: translateX(-50%); width: 320px;z-index: 9999999;"></div>
    </div>
</div>
<div id="modal-root">
    <div class="absolute">
        <div class="ModalComponent__root-YwCAMP ModalComponent__root--desktop-JzGyNl ModalComponent__animation-JkgpfL ModalComponent__root--open-i5pSf7 ModalComponent__root--open__desktop-x1XDzU hidden">
            <div class="ModalComponent__content-XqD1rL ModalComponent__animation-JkgpfL ModalComponent__content--desktop-o5IbOt ModalComponent__content--border-md-4G9biy overflow-auto" style="transform: translateY(400%);">
                <div class="ModalComponent__header-l62jh_">
                    <div class="d-flex ai-center AppHeader__headerBorder-sqCler  jc-between ProfileModal__header-QU8G4w">
                        <p class="text-h5 color-n-700 text-h5 text-color-neutral-700">ارتباط با ما</p>
                        <div class="d-flex pointer pointer mr-2" data-testid="close-wrapper">
                            <svg style="width: 24px; height: 24px; fill: var(--color-icon-high-emphasis);"> <path d="M12 11.0537C12 11.0537 16.2827 6.77342 17.8617 5.19523C18.1221 4.93492 18.5443 4.93492 18.8047 5.19523C19.0651 5.45553 19.0651 5.87753 18.8047 6.13783C17.2257 7.71602 12.9391 12 12.9391 12C12.9391 12 17.2257 16.284 18.8047 17.8622C19.0651 18.1225 19.0651 18.5445 18.8047 18.8047C18.5443 19.0651 18.1221 19.0651 17.8617 18.8048C16.2827 17.2266 12 12.9463 12 12.9463C12 12.9463 7.7173 17.2266 6.1383 18.8048C5.8779 19.0651 5.4557 19.0651 5.1953 18.8048C4.9349 18.5445 4.9349 18.1225 5.1953 17.8622C6.7743 16.284 11.0609 12 11.0609 12C11.0609 12 6.7743 7.71602 5.1953 6.13783C4.9349 5.87753 4.9349 5.45552 5.1953 5.19533C5.4557 4.93493 5.8779 4.93492 6.1383 5.19523C7.7173 6.77342 12 11.0537 12 11.0537Z"></path> </svg>
                        </div>
                    </div>
                </div>
                <div class="uModalComponent__body-WvxQuY ModalComponent__body--default-sYpvC3 flex gap-2 flex-col">
                    <div class="flex gap-2 SHFJD5">
                        <?php
                        if(\Giftmax\Modules\UserModel::setting("tel") == 'true'){?>
                            <div class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame__div-container--D5edN <?=\Giftmax\Modules\UserModel::setting("email") == 'true'? 'lg:w-50' : 'w-full'?>">
                                <a href="tel:<?=str_replace('-','',\Giftmax\Modules\UserModel::settingValue("tel"))?>" class="flex items-center">
                                    <div class="uikit-atomic-Button-tel"><i class="icon-phone"></i></div>
                                    <span class="w-full"><?=\Giftmax\Modules\UserModel::settingValue("tel")?></span>
                                </a>
                            </div>
                            <?php
                        }
                        if(\Giftmax\Modules\UserModel::setting("email") == 'true'){?>
                            <div class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame__div-container--D5edN <?=\Giftmax\Modules\UserModel::setting("tel") == 'true'? 'lg:w-50' : 'w-full'?>">
                                <a href="mailto:<?=\Giftmax\Modules\UserModel::settingValue("email")?>" class="flex items-center">
                                    <div class="uikit-atomic-Button-email">
                                        <i class="icon-message-fill"></i>
                                    </div>
                                    <span class="w-full">پشتیبانی در ایمیل</span>
                                </a>
                            </div>
                            <?php
                        }
                        ?>
                    </div>
                    <?php
                    if(\Giftmax\Modules\UserModel::setting("telegram") == 'true'){?>

                        <div class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame__div-container--D5edN w-full">
                            <a href="<?=\Giftmax\Modules\UserModel::settingValue("telegram")?>" class="flex items-center">
                                <div class="uikit-atomic-Button-telegram w-38:h-33"><i class="icon-telegram"></i></div>
                                <span class="w-full">پشتیبانی آنلاین در تلگرام</span>
                            </a>
                        </div>
                        <?php
                    }
                    if(\Giftmax\Modules\UserModel::setting("instagram") == 'true'){?>

                        <div class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame__div-container--D5edN w-full">
                            <a href="<?=\Giftmax\Modules\UserModel::settingValue("instagram")?>" class="flex items-center">
                                <div class="uikit-atomic-Button-instagram w-38:h-33"><i class="icon-instagram"></i></div>
                                <span class="w-full">پشتیبانی آنلاین در اینستاگرام</span>
                            </a>
                        </div>
                        <?php
                    }
                    if(\Giftmax\Modules\UserModel::setting("whatsapp") == 'true'){?>
                        <div class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame__div-container--D5edN">
                            <a href="<?=\Giftmax\Modules\UserModel::settingValue("whatsapp")?>" class="flex items-center">
                                <div class="uikit-atomic-Button-whatsapp w-38:h-33"><i class="icon-whatsapp"></i></div>
                                <span class="w-full">پشتیبانی آنلاین در واتس&zwnj;اپ</span>
                            </a>
                        </div>
                        <?php
                    }
                    ?>
                    <div class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame__div-container--D5edN">
                        <a href="<?=home_url('/ticket')?>" class="flex items-center">
                            <div class="uikit-atomic-Button-support w-38:h-33"><i class="icon-support-fill"></i></div>
                            <span class="w-full">ارسال درخواست پشتیبانی</span>
                        </a>
                    </div>
                </div>
                <div class="grow-1"></div>
            </div>
        </div>
    </div>
</div>
<?php
 wp_footer(); ?>

</body>
</html>


