<?php if ($method !='search'){?>
<div class="flex gap-3">
    <div class="">
        <?php
        foreach ($users as $user) {
            $first_name = $user->first_name;
            $last_name  = $user->last_name;
            $user_login = $user->user_login;
            $balance = number_format(\Giftmax\model\UserModel::wallet($user->ID));
            ?>
            <div class="InvoiceCustomerInfo mt-3">
                <div class="InvoiceCustomerInfo__item">
                    <span class="InvoiceCustomerInfo__label">نام</span>
                    <span class="InvoiceCustomerInfo__value"><?="$first_name $last_name"?></span>

                </div>
                <div class="InvoiceCustomerInfo__divider InvoiceCustomerInfo__divider--v"></div>
                <div class="InvoiceCustomerInfo__item">
                    <span class="InvoiceCustomerInfo__label">شماره تلفن</span>
                    <span class="InvoiceCustomerInfo__value"><span><?=$user_login?></span></span>
                </div>
                <div class="InvoiceCustomerInfo__divider InvoiceCustomerInfo__divider--h"></div>
                <div class="InvoiceCustomerInfo__item">
                    <span class="InvoiceCustomerInfo__label">موجودی کیف پول</span>
                    <span class="InvoiceCustomerInfo__value"><span><?=$balance?></span></span>
                </div>
                <div class="InvoiceCustomerInfo__divider InvoiceCustomerInfo__divider--v"></div>
                <div class="InvoiceCustomerInfo__item">
                    <span class="InvoiceCustomerInfo__label">امتیاز</span>
                    <span class="InvoiceCustomerInfo__value"><span><?=number_format(\Giftmax\model\UserModel::points($user->ID))?></span></span>
                </div>
                <div class="InvoiceCustomerInfo__divider InvoiceCustomerInfo__divider--h"></div>
                <div class="InvoiceCustomerInfo__item">
                    <span class="InvoiceCustomerInfo__label"></span>
                    <span class="InvoiceCustomerInfo__value"><button class="Button-suw45" data-number="<?=$user_login?>">انتخاب</button></span>
                </div>
            </div>
            <?php
        }
        ?>
    </div>
    <div class="">
        <?php
        $records = \Giftmax\model\UserModel::walletTransactionsAll(8);
        foreach ($records as $record) {
        $user = get_userdata($record->user_ID);
        $first_name = $user->first_name;
        $last_name  = $user->last_name;
        $user_login = $user->user_login;
        ?>
        <div class="InvoiceCustomerInfo mt-3">
            <div class="InvoiceCustomerInfo__item">
                <span class="InvoiceCustomerInfo__label">نام</span>
                <span class="InvoiceCustomerInfo__value"><?="$first_name $last_name"?></span>

            </div>
            <div class="InvoiceCustomerInfo__divider InvoiceCustomerInfo__divider--v"></div>
            <div class="InvoiceCustomerInfo__item">
                <span class="InvoiceCustomerInfo__label">شماره تلفن</span>
                <span class="InvoiceCustomerInfo__value"><button class="Button-suw45" data-number="<?=$user_login?>"><?=$user_login?></button></span>
            </div>
            <div class="InvoiceCustomerInfo__divider InvoiceCustomerInfo__divider--h"></div>
            <div class="InvoiceCustomerInfo__item">
                <span class="InvoiceCustomerInfo__label">موجودی کیف پول</span>
                <span class="InvoiceCustomerInfo__value"><span><?=$record['description']?></span></span>
            </div>
            <div class="InvoiceCustomerInfo__divider InvoiceCustomerInfo__divider--h"></div>
            <div class="InvoiceCustomerInfo__item">
                <span class="InvoiceCustomerInfo__label">مقدار تراکنش</span>
                <span class="InvoiceCustomerInfo__value"><span><?=$record['amount']?></span></span>
            </div>
            <div class="InvoiceCustomerInfo__divider InvoiceCustomerInfo__divider--v"></div>
            <div class="InvoiceCustomerInfo__item">
                <span class="InvoiceCustomerInfo__label">تاریخ تراکنش</span>
                <span class="InvoiceCustomerInfo__value"><span dir="ltr"><?=gjdate($record['created_at'],"Y-m-d ،H:i")?></span></span>
            </div>
        </div>
    <?php
    }
    ?>
    </div>
</div>
<?php
}else{
    ?>
<div class="flex gap-3">
    <div style="width: 45%">
        <?php
        foreach ($users as $user) {
            $first_name = $user->first_name;
            $last_name  = $user->last_name;
            $user_login = $user->user_login;
            $balance = number_format(\Giftmax\model\UserModel::wallet($user->ID));
            ?>
            <div class="InvoiceCustomerInfo mt-3">
                <div class="InvoiceCustomerInfo__item">
                    <span class="InvoiceCustomerInfo__label">نام</span>
                    <span class="InvoiceCustomerInfo__value"><?="$first_name $last_name"?></span>

                </div>
                <div class="InvoiceCustomerInfo__divider InvoiceCustomerInfo__divider--v"></div>
                <div class="InvoiceCustomerInfo__item">
                    <span class="InvoiceCustomerInfo__label">شماره تلفن</span>
                    <span class="InvoiceCustomerInfo__value"><span><?=$user_login?></span></span>
                </div>
                <div class="InvoiceCustomerInfo__divider InvoiceCustomerInfo__divider--h"></div>
                <div class="InvoiceCustomerInfo__item">
                    <span class="InvoiceCustomerInfo__label">موجودی کیف پول</span>
                    <span class="InvoiceCustomerInfo__value"><span><?=$balance?></span></span>
                </div>
                <div class="InvoiceCustomerInfo__divider InvoiceCustomerInfo__divider--v"></div>
                <div class="InvoiceCustomerInfo__item">
                    <span class="InvoiceCustomerInfo__label">امتیاز</span>
                    <span class="InvoiceCustomerInfo__value"><span><?=number_format(\Giftmax\model\UserModel::points($user->ID))?></span></span>
                </div>
                <div class="InvoiceCustomerInfo__divider InvoiceCustomerInfo__divider--h"></div>
                <div class="InvoiceCustomerInfo__item">
                    <span class="InvoiceCustomerInfo__label"></span>
                    <span class="InvoiceCustomerInfo__value"><button class="Button-suw45" data-number="<?=$user_login?>">انتخاب</button></span>
                </div>
            </div>
            <?php
        }
        ?>
    </div>
    <div style="width: 55%">
        <?php
        if ($method == 'search' && count($users) == 1) {
            $records = \Giftmax\model\UserModel::walletTransactionsAllUser($users[0]->ID,8);
            foreach ($records as $record) {?>
                <div class="InvoiceCustomerInfo mt-3">
                    <div class="InvoiceCustomerInfo__item">
                        <span class="InvoiceCustomerInfo__label">موجودی کیف پول</span>
                        <span class="InvoiceCustomerInfo__value"><span><?=$record['description']?></span></span>
                    </div>
                    <div class="InvoiceCustomerInfo__divider InvoiceCustomerInfo__divider--h"></div>
                    <div class="InvoiceCustomerInfo__item">
                        <span class="InvoiceCustomerInfo__label">مقدار تراکنش</span>
                        <span class="InvoiceCustomerInfo__value"><span><?=$record['amount']?></span></span>
                    </div>
                    <div class="InvoiceCustomerInfo__divider InvoiceCustomerInfo__divider--v"></div>
                    <div class="InvoiceCustomerInfo__item">
                        <span class="InvoiceCustomerInfo__label">تاریخ تراکنش</span>
                        <span class="InvoiceCustomerInfo__value"><span dir="ltr"><?=gjdate($record['created_at'],"Y-m-d ،H:i")?></span></span>
                    </div>
                </div>
                <?php
            }
        }else{
            $records = \Giftmax\model\UserModel::walletTransactionsAll(8);
            foreach ($records as $record) {
                $user = get_userdata($record->user_ID);
                $first_name = $user->first_name;
                $last_name  = $user->last_name;
                $user_login = $user->user_login;
                ?>
                <div class="InvoiceCustomerInfo mt-3">
                    <div class="InvoiceCustomerInfo__item">
                        <span class="InvoiceCustomerInfo__label">نام</span>
                        <span class="InvoiceCustomerInfo__value"><?="$first_name $last_name"?></span>

                    </div>
                    <div class="InvoiceCustomerInfo__divider InvoiceCustomerInfo__divider--v"></div>
                    <div class="InvoiceCustomerInfo__item">
                        <span class="InvoiceCustomerInfo__label">شماره تلفن</span>
                        <span class="InvoiceCustomerInfo__value"><button class="Button-suw45" data-number="<?=$user_login?>"><?=$user_login?></button></span>
                    </div>
                    <div class="InvoiceCustomerInfo__divider InvoiceCustomerInfo__divider--h"></div>
                    <div class="InvoiceCustomerInfo__item">
                        <span class="InvoiceCustomerInfo__label">موجودی کیف پول</span>
                        <span class="InvoiceCustomerInfo__value"><span><?=$record['description']?></span></span>
                    </div>
                    <div class="InvoiceCustomerInfo__divider InvoiceCustomerInfo__divider--h"></div>
                    <div class="InvoiceCustomerInfo__item">
                        <span class="InvoiceCustomerInfo__label">مقدار تراکنش</span>
                        <span class="InvoiceCustomerInfo__value"><span><?=$record['amount']?></span></span>
                    </div>
                    <div class="InvoiceCustomerInfo__divider InvoiceCustomerInfo__divider--v"></div>
                    <div class="InvoiceCustomerInfo__item">
                        <span class="InvoiceCustomerInfo__label">تاریخ تراکنش</span>
                        <span class="InvoiceCustomerInfo__value"><span dir="ltr"><?=gjdate($record['created_at'],"Y-m-d ،H:i")?></span></span>
                    </div>
                </div>
                <?php
            }
        }
        ?>
    </div>
</div>
<?php
}
