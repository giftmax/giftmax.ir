<div class="d-flex Container-mirV2w mb-4 Container--withBorder-OdFFhL">
    <div class="ProfileLayout__tab-rvmH7A TabItem-CWkOsT TabItem__active-AZcc4O text-subtitle-strong false" data-testid="tab-wrapper" data-pw="tab-0">تنظیمات خرید</div>
</div>
<section class="d-grid grid-cols-2 mt-4">
    <div class=" d-flex flex-column  TableCell__cell-quNpHF col-span-2 col-span-1-lg  TableCell__cell--horizontalSeprator-oY3HN8 py-4">
        <div class="d-flex jc-between ai-center">
            <div class="flex-1">
                <div class="d-flex ai-center mb-2 gap-1">
                    <p class="text-body-1 color-n-500">خرید از سایت</p>
                </div>
            </div>
            <label for="buy" class="input-label start w40_1">
                <span class="start-label"></span>
                <input id="buy" type="checkbox" class="input" <?= \Giftmax\model\SiteModel::setting("buy") === true ? 'checked' : ''?>>
                <span class="input-check"></span>
            </label>
        </div>
    </div>
    <div class=" d-flex flex-column  TableCell__cell-quNpHF col-span-2 col-span-1-lg  TableCell__cell--horizontalSeprator-oY3HN8 py-4">
        <div class="d-flex jc-between ai-center">
            <div class="flex-1">
                <div class="d-flex ai-center mb-2 gap-1">
                    <p class="text-body-1 color-n-500">ارسال پیام به صاحب کارت</p>
                </div>
            </div>
            <div class="flex flex-col gap-15">
                <label for="otpAudio" class="input-label start">
                    <span class="start-label">صوتی</span>
                    <input id="otpAudio" type="checkbox" onclick="changeSwitch('otpSms')" class="input"  <?= \Giftmax\model\SiteModel::setting("otpAudio") === true ? 'checked' : '' ?>>
                    <span class="input-check"></span>
                </label>
                <label for="otpSms" class="input-label start">
                    <span class="start-label">پیامک</span>
                    <input id="otpSms" type="checkbox" onclick="changeSwitch('otpAudio')" class="input"  <?= \Giftmax\model\SiteModel::setting("otpSms") === true ? 'checked' : '' ?>>
                    <span class="input-check"></span>
                </label>
            </div>
        </div>
    </div>
    <div class=" d-flex flex-column  TableCell__cell-quNpHF col-span-2 col-span-1-lg  TableCell__cell--horizontalSeprator-oY3HN8 py-4">
        <div class="d-flex jc-between ai-center">
            <div class="flex-1">
                <div class="d-flex ai-center gap-1">
                    <p class="text-body-1 color-n-500">متغیر های تایین سفارش مشکوک</p>
                </div>
                <?php
                global $wpdb;
                $db = \Giftmax\modules\Db::getLnstance();
                $records = $db->first("SELECT * FROM `{$wpdb->prefix}setting` WHERE `meta_key`='suspicious_order'");
                if (!empty($records)){
                    $record = json_decode($records['meta_value'], true);
                    ?>
                    <p class="text-subtitle-strong flex-1"><?='دقیقه:' . number_format($record[0]['minutes']) . '| مبلغ سفارش به تومان:' . number_format($record[0]['minTotal'])?></p>
                    <?php
                }else{
                    echo '  <p class="text-subtitle-strong flex-1"></p>';
                }
                ?>
            </div>
            <button class="relative d-flex ai-center user-select-none btn-wc51H8 text-button-2 btn--text-se4oQM btn--primary-uiqWij btn--icon-ZPHT4g radius Button__medium-gIvke_ Button__textPrimary-IWW5Sd Button__prependIcon-hh7768 IconButton__button-RRc2H_ Button-so42" data-testid="button-wrapper" type="button">
                <div class="d-flex ai-center jc-center relative grow-1">
                    <div class="d-flex IconButton__prependIcon-mxVR2M p-4" data-testid="icon-wrapper">
                        تنظیمات
                    </div>
                </div>
            </button>
        </div>
    </div>
</section>