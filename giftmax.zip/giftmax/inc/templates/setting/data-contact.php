<div class="col-12">
    <div class="">
        <div class="c-bills__header">
            <div class="b-bills bills_number">ردیف</div>
            <div class="b-bills purchase_date">نام</div>
            <div class="b-bills bills_view">موضوع</div>
            <div class="b-bills bills_name">پیغام</div>
            <div class="b-bills purchase_date">ایمیل</div>

        </div>
        <div id="c-bills">
            <?php
            global $wpdb;
            $db = \Giftmax\modules\Db::getLnstance();
            $records = $db->query("SELECT * FROM `{$wpdb->prefix}contact`");

            if (!empty($records)){
                foreach ($records as $key=>$record) {
                    ?>
                    <div class="c-bills__body">
                        <div class="b-bills bills_number">
                            <span class="c-number"><?=$key+1?></span>
                        </div>
                        <div class="b-bills purchase_date">
                            <div class="c-color"><?=$record['name']?></div>
                        </div>
                        <div class="b-bills bills_view">
                            <div class="c-color "><?=$record['subject']?></div>
                        </div>
                        <div class="b-bills bills_name">
                            <div class="c-color " dir="rtl"><?=$record['message']?></div>
                        </div>
                        <div class="b-bills purchase_date">
                            <div class="c-color "><?=$record['email']?></div>
                        </div>
                    </div>
                    <?php
                }
            }else{
                ?>
                <div class="c-bills__body">
                    <div class="b-bills" style="width:100%;">
                        <div class="c-color">در حال حاضر رکورد جدیدی وجود ندارد</div>
                    </div>
                </div>
                <?php
            }
            ?>
        </div>
    </div>
</div>
