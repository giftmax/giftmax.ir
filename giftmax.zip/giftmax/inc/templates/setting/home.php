<style>
    .tox-tinymce-aux{
        z-index: 9999999!important;
    }
    .flex{
        display: flex;
    }
</style>
<div class="d-flex Container-mirV2w mb-4 Container--withBorder-OdFFhL">
    <div class="ProfileLayout__tab-rvmH7A TabItem-CWkOsT TabItem__active-AZcc4O text-subtitle-strong false" data-testid="tab-wrapper" data-pw="tab-0">تنظیمات صفحه اصلی</div>
</div>
<section class="d-grid grid-cols-2 mt-4">
    <div class=" d-flex flex-column  TableCell__cell-quNpHF col-span-2 col-span-1-lg  TableCell__cell--horizontalSeprator-oY3HN8 py-4">
        <div class="d-flex jc-between ai-center">
            <div class="flex-1">
                <div class="d-flex ai-center mb-2 gap-1">
                    <p class="text-body-1 color-n-500">دسته بندی وبلاگ</p>
                </div>
                <?php

                use Giftmax\modules\Db;
                $db = Db::getLnstance();
                global $wpdb;
                $records = \Giftmax\model\SiteModel::setting('category');
                if ($records){
                    $record = \Giftmax\model\SiteModel::table('setting','meta_key','category')['meta_value'];
                    $ids = array_map( 'intval', explode( ',', $record ) );
                // ۲. گرفتن دسته‌ها
                $categories = get_categories( array(
                    'include'    => $ids,          // فیلتر بر اساس ID
                    'hide_empty' => false,        // حتی دسته‌های خالی را هم ببر
                ) );

                // ۳. ساخت خروجی
                $output = array();
                foreach ( $categories as $cat ) {
                    $output[] = $cat->name;
                }
                ?>
                <p class="text-subtitle-strong flex-1"><?=join(',',$output)?></p>
                <?php
                }else{?>
                    <p class="text-subtitle-strong flex-1">وارد کنید</p>
                <?php }
                ?>
            </div>
            <button class="relative d-flex ai-center user-select-none btn-wc51H8 text-button-2 btn--text-se4oQM btn--primary-uiqWij btn--icon-ZPHT4g radius Button__medium-gIvke_ Button__textPrimary-IWW5Sd Button__prependIcon-hh7768 IconButton__button-RRc2H_ Button-cb54" data-testid="button-wrapper" type="button">
                <div class="d-flex ai-center jc-center relative grow-1">
                    <div class="d-flex IconButton__prependIcon-mxVR2M p-4" data-testid="icon-wrapper">
                        <svg data-testid="button-prepend-icon" style="width: 24px; height: 24px; fill: var(--color-icon-primary);"><path d="M15.293 3.293c0.391-0.391 1.024-0.391 1.414 0l4 4c0.391 0.391 0.391 1.024 0 1.414l-12 12c-0.188 0.188-0.442 0.293-0.707 0.293h-4c-0.552 0-1-0.448-1-1v-4c0-0.265 0.105-0.52 0.293-0.707l12-12zM5 16.414v2.586h2.586l11-11-2.586-2.586-11 11zM10 21l2-2h9v2h-11z"></path></svg>
                    </div>
                </div>
            </button>
        </div>
    </div>
    <div class=" d-flex flex-column  TableCell__cell-quNpHF col-span-2 col-span-1-lg  TableCell__cell--horizontalSeprator-oY3HN8 py-4">
        <div class="d-flex jc-between ai-center">
            <div class="flex-1">
                <div class="d-flex ai-center mb-2 gap-1">
                    <p class="text-body-1 color-n-500">توضیحات درباره سایت</p>
                </div>
                <?php
                $db = Db::getLnstance();
                global $wpdb;
                $records = $db->first("SELECT meta_value FROM `{$wpdb->prefix}setting` WHERE `meta_key`=:key",array('key'=>'description'));
                ?>
                <p class="text-subtitle-strong"><?=!empty($records) ? 'متن از قبل وارد شده': 'وارد کنید'?></p>            </div>
            <button class="relative d-flex ai-center user-select-none btn-wc51H8 text-button-2 btn--text-se4oQM btn--primary-uiqWij btn--icon-ZPHT4g radius Button__medium-gIvke_ Button__textPrimary-IWW5Sd Button__prependIcon-hh7768 IconButton__button-RRc2H_ Button-sd78" data-testid="button-wrapper" type="button">
                <div class="d-flex ai-center jc-center relative grow-1">
                    <div class="d-flex IconButton__prependIcon-mxVR2M p-4" data-testid="icon-wrapper">
                        <svg data-testid="button-prepend-icon" style="width: 24px; height: 24px; fill: var(--color-icon-primary);"><path d="M15.293 3.293c0.391-0.391 1.024-0.391 1.414 0l4 4c0.391 0.391 0.391 1.024 0 1.414l-12 12c-0.188 0.188-0.442 0.293-0.707 0.293h-4c-0.552 0-1-0.448-1-1v-4c0-0.265 0.105-0.52 0.293-0.707l12-12zM5 16.414v2.586h2.586l11-11-2.586-2.586-11 11zM10 21l2-2h9v2h-11z"></path></svg>
                    </div>
                </div>
            </button>
        </div>
    </div>
</section>
<div>
    <p class="text-body-1 color-n-500">اسلایدر صفحه ای</p>
    <div class="styles_box-_dXFga d-grid grid-cols-2" style="    gap: 0 12px;">
        <?php
        $records = \Giftmax\model\SiteModel::setting('slider');
        if (!$records){
            ?>
            <div class="styles_btn-_mLWvq">
                <div class="styles_btn--neutralOutlined__mLWvq Button-dw84">
                    <i class="icon-delete"></i>
                </div>
                <div>
                    <label class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--L7bcQ uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--normal--A6Ntt text-body-1 color-n-700 w-100">
                        <p class="mb-2 color-n-700 text-body-1 mb-2" data-testid="form-label"> سرتیتر </p>
                        <div class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame__input-container--D5edN px-2 d-flex ai-center">
                            <section class="grow-1 text-body-2-c">
                                <input class="px-2 TextField__input-_5fbdd text-subtitle w-100 TextField-e58168" type="text" name="slider[][title]" placeholder="بازی جدید زیادش خوبه"></section>
                        </div>
                    </label>
                    <label class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--L7bcQ uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--normal--A6Ntt text-body-1 color-n-700 w-100">
                        <p class="mb-2 color-n-700 text-body-1 mb-2" data-testid="form-label">توضیحات مختصر </p>
                        <div class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame__input-container--D5edN px-2 d-flex ai-center">
                            <section class="grow-1 text-body-2-c">
                                <input class="px-2 TextField__input-_5fbdd text-subtitle w-100 TextField-e58168" type="text" name="slider[][description]"></section>
                        </div>
                    </label>
                    <label class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--L7bcQ uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--normal--A6Ntt text-body-1 color-n-700 w-100">
                        <p class="mb-2 color-n-700 text-body-1 mb-2" data-testid="form-label"> متن دکمه </p>
                        <div class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame__input-container--D5edN px-2 d-flex ai-center">
                            <section class="grow-1 text-body-2-c">
                                <input class="px-2 TextField__input-_5fbdd text-subtitle w-100 TextField-e58168" type="text" name="slider[][button][title]"></section>
                        </div>
                    </label>
                    <label class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--L7bcQ uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--normal--A6Ntt text-body-1 color-n-700 w-100">
                        <p class="mb-2 color-n-700 text-body-1 mb-2" data-testid="form-label"> آدرس دکمه </p>
                        <div class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame__input-container--D5edN px-2 d-flex ai-center">
                            <section class="grow-1 text-body-2-c">
                                <input class="px-2 TextField__input-_5fbdd text-subtitle w-100 TextField-e58168" type="text" name="slider[][button][link]"></section>
                        </div>
                    </label>
                    <label class="flex uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--L7bcQ uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--normal--A6Ntt text-body-1 color-n-700 w-100">
                        <p class="mb-2 color-n-700 text-body-1 mb-2" data-testid="form-label"> رنگ اول </p>
                        <div style="width: 9%;">
                            <input class="px-2 TextField__input-_5fbdd text-subtitle w-100 TextField-e58168" type="color" name="slider[][color][one]">
                        </div>
                    </label>
                    <label class="flex uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--L7bcQ uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--normal--A6Ntt text-body-1 color-n-700 w-100">
                        <p class="mb-2 color-n-700 text-body-1 mb-2" data-testid="form-label"> رنگ دوم </p>
                        <div style="width: 9%;">
                            <input class="px-2 TextField__input-_5fbdd text-subtitle w-100 TextField-e58168" type="color" name="slider[][color][two]">
                        </div>
                    </label>
                    <label class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--L7bcQ uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--normal--A6Ntt text-body-1 color-n-700 w-100">
                        <p class="mb-2 color-n-700 text-body-1 mb-2" data-testid="form-label">عکس  </p>
                        <div style="display: flex; justify-content: space-between">
                            <div class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame__input-container--D5edN px-2 d-flex ai-center" style="width: calc(100% - 70px)">
                                <section class="grow-1 text-body-2-c">
                                    <input class="px-2 TextField__input-_5fbdd text-subtitle w-100 TextField-e58168 SliderImg" type="text" name="slider[][img]"></section>
                            </div>
                            <div class="Button--uai23" data-id="SliderImg">اپلود</div>
                        </div>
                    </label>
                </div>
            </div>
            <?php
        }else{
            $record = \Giftmax\model\SiteModel::table('setting','meta_key','slider')['meta_value'];
            $records = json_decode($record,true);
            foreach ($records as $record){?>
                <div class="styles_btn-_mLWvq">
                    <div class="styles_btn--neutralOutlined__mLWvq Button-dw84">
                        <i class="icon-delete"></i>
                    </div>
                    <div>
                        <label class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--L7bcQ uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--normal--A6Ntt text-body-1 color-n-700 w-100">
                            <p class="mb-2 color-n-700 text-body-1 mb-2" data-testid="form-label"> سرتیتر </p>
                            <div class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame__input-container--D5edN px-2 d-flex ai-center">
                                <section class="grow-1 text-body-2-c">
                                    <input class="px-2 TextField__input-_5fbdd text-subtitle w-100 TextField-e58168" type="text" name="slider[][title]" placeholder="بازی جدید زیادش خوبه" value="<?=$record['title']?>"></section>
                            </div>
                        </label>
                        <label class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--L7bcQ uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--normal--A6Ntt text-body-1 color-n-700 w-100">
                            <p class="mb-2 color-n-700 text-body-1 mb-2" data-testid="form-label">توضیحات مختصر </p>
                            <div class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame__input-container--D5edN px-2 d-flex ai-center">
                                <section class="grow-1 text-body-2-c">
                                    <input class="px-2 TextField__input-_5fbdd text-subtitle w-100 TextField-e58168" type="text" name="slider[][description]" value="<?=$record['description']?>"></section>
                            </div>
                        </label>
                        <label class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--L7bcQ uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--normal--A6Ntt text-body-1 color-n-700 w-100">
                            <p class="mb-2 color-n-700 text-body-1 mb-2" data-testid="form-label"> متن دکمه </p>
                            <div class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame__input-container--D5edN px-2 d-flex ai-center">
                                <section class="grow-1 text-body-2-c">
                                    <input class="px-2 TextField__input-_5fbdd text-subtitle w-100 TextField-e58168" type="text" name="slider[][button][title]" value="<?=$record['button']['title']?>"></section>
                            </div>
                        </label>
                        <label class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--L7bcQ uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--normal--A6Ntt text-body-1 color-n-700 w-100">
                            <p class="mb-2 color-n-700 text-body-1 mb-2" data-testid="form-label"> آدرس دکمه </p>
                            <div class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame__input-container--D5edN px-2 d-flex ai-center">
                                <section class="grow-1 text-body-2-c">
                                    <input class="px-2 TextField__input-_5fbdd text-subtitle w-100 TextField-e58168" type="text" name="slider[][button][link]" value="<?=$record['button']['link']?>"></section>
                            </div>
                        </label>
                        <label class="flex uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--L7bcQ uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--normal--A6Ntt text-body-1 color-n-700 w-100">
                            <p class="mb-2 color-n-700 text-body-1 mb-2" data-testid="form-label"> رنگ اول </p>
                            <div style="width: 9%;">
                                <input class="px-2 TextField__input-_5fbdd text-subtitle w-100 TextField-e58168" type="color" name="slider[][color][one]" value="<?=$record['color']['one']?>">
                            </div>
                        </label>
                        <label class="flex uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--L7bcQ uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--normal--A6Ntt text-body-1 color-n-700 w-100">
                            <p class="mb-2 color-n-700 text-body-1 mb-2" data-testid="form-label"> رنگ دوم </p>
                            <div style="width: 9%;">
                                <input class="px-2 TextField__input-_5fbdd text-subtitle w-100 TextField-e58168" type="color" name="slider[][color][two]" value="<?=$record['color']['two']?>">
                            </div>
                        </label>
                        <label class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--L7bcQ uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--normal--A6Ntt text-body-1 color-n-700 w-100">
                            <p class="mb-2 color-n-700 text-body-1 mb-2" data-testid="form-label">عکس  </p>
                            <div style="display: flex; justify-content: space-between">
                                <div class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame__input-container--D5edN px-2 d-flex ai-center" style="width: calc(100% - 70px)">
                                    <section class="grow-1 text-body-2-c">
                                        <input class="px-2 TextField__input-_5fbdd text-subtitle w-100 TextField-e58168 SliderImg" type="text" name="slider[][img]" value="<?=$record['img']?>"></section>
                                </div>'
                                <div class="Button--uai23" data-id="SliderImg">اپلود</div>
                            </div>
                        </label>
                    </div>
                </div>
                <?php
            }
        }
        ?>
    </div>
    <div class="flex justify-between">
        <button type="button" class="btn !w-28 !text-5xs !text-green-dark !pt-2 !h-28 btn-white btn-icon icon-plus relative Button-abs65"></button>

        <button type="button" class="btn btn-white Button-ss05">ثبت</button>
    </div>
</div>
<div>
    <p class="text-body-1 color-n-500">چهارتا باکس عکس</p>
    <div class="styles_box-_dXFgb d-grid grid-cols-2" style="gap: 0 12px;">
        <?php
        $records = \Giftmax\model\SiteModel::setting('img');
        if (!$records){
            ?>
            <div class="styles_btn-_mLWvq">
                <div class="styles_btn--neutralOutlined__mLWvq Button-dw84">
                    <i class="icon-delete"></i>
                </div>
                <div>
                    <label class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--L7bcQ uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--normal--A6Ntt text-body-1 color-n-700 w-100">
                        <p class="mb-2 color-n-700 text-body-1 mb-2" data-testid="form-label"> آدرس </p>
                        <div class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame__input-container--D5edN px-2 d-flex ai-center">
                            <section class="grow-1 text-body-2-c">
                                <input class="px-2 TextField__input-_5fbdd text-subtitle w-100 TextField-e58168" type="text" name="img[][link]"></section>
                        </div>
                    </label>
                    <label class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--L7bcQ uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--normal--A6Ntt text-body-1 color-n-700 w-100">
                        <p class="mb-2 color-n-700 text-body-1 mb-2" data-testid="form-label">عکس</p>
                        <div style="display: flex; justify-content: space-between">
                            <div class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame__input-container--D5edN px-2 d-flex ai-center" style="width: calc(100% - 70px)">
                                <section class="grow-1 text-body-2-c">
                                    <input class="px-2 TextField__input-_5fbdd text-subtitle w-100 TextField-e58168 boxImg" type="text" name="img[][img]"></section>
                            </div>
                            <div class="Button--uai23" data-id="boxImg">اپلود</div>
                        </div>
                    </label>
                </div>
            </div>
            <?php
        }else{
            $record = \Giftmax\model\SiteModel::table('setting','meta_key','img')['meta_value'];
            $records = json_decode($record,true);
        if (is_array($records) && !empty($records[0]['link']) && !empty($records[0]['img'])){
            foreach ($records as $record){?>
                <div class="styles_btn-_mLWvq">
                    <div class="styles_btn--neutralOutlined__mLWvq Button-dw84">
                        <i class="icon-delete"></i>
                    </div>
                    <div>
                        <label class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--L7bcQ uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--normal--A6Ntt text-body-1 color-n-700 w-100">
                            <p class="mb-2 color-n-700 text-body-1 mb-2" data-testid="form-label"> آدرس </p>
                            <div class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame__input-container--D5edN px-2 d-flex ai-center">
                                <section class="grow-1 text-body-2-c">
                                    <input class="px-2 TextField__input-_5fbdd text-subtitle w-100 TextField-e58168" type="text" name="img[][link]" value="<?=$record['link']?>"></section>
                            </div>
                        </label>
                        <label class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--L7bcQ uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--normal--A6Ntt text-body-1 color-n-700 w-100">
                            <p class="mb-2 color-n-700 text-body-1 mb-2" data-testid="form-label">عکس</p>
                            <div style="display: flex; justify-content: space-between">
                                <div class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame__input-container--D5edN px-2 d-flex ai-center" style="width: calc(100% - 70px)">
                                    <section class="grow-1 text-body-2-c">
                                        <input class="px-2 TextField__input-_5fbdd text-subtitle w-100 TextField-e58168 boxImg" type="text" name="img[][img]" value="<?=$record['img']?>"></section>
                                </div>
                                <div class="Button--uai23" data-id="boxImg">اپلود</div>
                            </div>
                        </label>
                    </div>
                </div>
                <?php
            }
        }else{
            ?>
        <div class="styles_btn-_mLWvq">
            <div class="styles_btn--neutralOutlined__mLWvq Button-dw84">
                <i class="icon-delete"></i>
            </div>
            <div>
                <label class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--L7bcQ uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--normal--A6Ntt text-body-1 color-n-700 w-100">
                    <p class="mb-2 color-n-700 text-body-1 mb-2" data-testid="form-label"> آدرس </p>
                    <div class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame__input-container--D5edN px-2 d-flex ai-center">
                        <section class="grow-1 text-body-2-c">
                            <input class="px-2 TextField__input-_5fbdd text-subtitle w-100 TextField-e58168" type="text" name="img[][link]"></section>
                    </div>
                </label>
                <label class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--L7bcQ uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--normal--A6Ntt text-body-1 color-n-700 w-100">
                    <p class="mb-2 color-n-700 text-body-1 mb-2" data-testid="form-label">عکس</p>
                    <div style="display: flex; justify-content: space-between">
                        <div class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame__input-container--D5edN px-2 d-flex ai-center" style="width: calc(100% - 70px)">
                            <section class="grow-1 text-body-2-c">
                                <input class="px-2 TextField__input-_5fbdd text-subtitle w-100 TextField-e58168 boxImg" type="text" name="img[][img]"></section>
                        </div>
                        <div class="Button--uai23" data-id="boxImg">اپلود</div>
                    </div>
                </label>
            </div>
        </div>
        <?php
        }
        }
        ?>
    </div>
    <div class="flex justify-between">
        <button type="button" class="btn !w-28 !text-5xs !text-green-dark !pt-2 !h-28 btn-white btn-icon icon-plus relative Button-abi"></button>

        <button type="button" class="btn btn-white Button-sib">ثبت</button>
    </div>
</div>
