<div class="d-flex Container-mirV2w mb-4 Container--withBorder-OdFFhL">
    <div class="ProfileLayout__tab-rvmH7A TabItem-CWkOsT TabItem__active-AZcc4O text-subtitle-strong false" data-testid="tab-wrapper" data-pw="tab-0">ارسال نوتیفیکیشن</div>
</div>
<label class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--L7bcQ uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--normal--A6Ntt text-body-1 color-n-700 w-100">
    <p class="mb-2 color-n-700 text-body-1 mb-2" data-testid="form-label"> سرتیتر </p>
    <div class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame__input-container--D5edN px-2 d-flex ai-center">
        <section class="grow-1 text-body-2-c">
            <input class="px-2 TextField__input-_5fbdd text-subtitle w-100 TextField-e58168" type="text" id="title">
        </section>
    </div>
</label>
<label class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--L7bcQ uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--normal--A6Ntt text-body-1 color-n-700 w-100">
    <p class="mb-2 color-n-700 text-body-1 mb-2" data-testid="form-label"> ارسال به شخص خاص </p>
    <div class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame__input-container--D5edN px-2 d-flex ai-center">
        <section class="grow-1 text-body-2-c">
            <input class="px-2 TextField__input-_5fbdd text-subtitle w-100 TextField-e58168" type="text" id="person">
        </section>
    </div>
</label>
<div class="user hidden"></div>
<label class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--L7bcQ uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--normal--A6Ntt text-body-1 color-n-700 w-100">
    <p class="mb-2 color-n-700 text-body-1 mb-2" data-testid="form-label"> متن اعلان </p>
    <textarea id="description"></textarea>
</label>
<button type="button" class="btn btn-white Button-sn05">ثبت</button>
<div class="d-flex Container-mirV2w mb-4 Container--withBorder-OdFFhL">
    <div class="ProfileLayout__tab-rvmH7A TabItem-CWkOsT TabItem__active-AZcc4O text-subtitle-strong false" data-testid="tab-wrapper" data-pw="tab-0">ارسال نوتیف انبوه</div>
</div>
<div class="flex gap-3">
    <div class="w-70">
        <label class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--L7bcQ uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--normal--A6Ntt text-body-1 color-n-700 w-100">
            <p class="mb-2 color-n-700 text-body-1 mb-2" data-testid="form-label"> عنوان نوتیف</p>
            <div class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame__input-container--D5edN px-2 d-flex ai-center">
                <section class="grow-1 text-body-2-c">
                    <input class="px-2 TextField__input-_5fbdd text-subtitle w-100 TextField-e58168" type="text" id="notif-title">
                </section>
            </div>
        </label>
        <label class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--L7bcQ uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--normal--A6Ntt text-body-1 color-n-700 w-100">
            <p class="mb-2 color-n-700 text-body-1 mb-2" data-testid="form-label"> متن </p>
            <textarea id="notif-description" class="px-1 TextField__textarea-df80b4 text-subtitle w-100 TextField-e58168" rows="4"></textarea>
        </label>
    </div>
    <div class="w-30">
        <label class=" =uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--L7bcQ uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--normal--A6Ntt text-body-1 color-n-700 w-100">
            <p class="mb-2 color-n-700 text-body-1 mb-2" data-testid="form-label">ارسال فقط به این لیست</p>
            <div class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame__input-container--D5edN px-2 d-flex ai-center">
                <section class="grow-1 text-body-2-c">
                    <input class="px-2 TextField__input-_5fbdd text-subtitle TextField-e58168 w-100" type="text" name="notif-white" id="listwhite">
                </section>
            </div>
        </label>
        <div class="listwhite_search hidden"></div>
        <label class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--L7bcQ uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--normal--A6Ntt text-body-1 color-n-700 w-100">
            <p class="mb-2 color-n-700 text-body-1 mb-2" data-testid="form-label">بلک لیست</p>
            <div class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame__input-container--D5edN px-2 d-flex ai-center">
                <section class="grow-1 text-body-2-c">
                    <input class="px-2 TextField__input-_5fbdd text-subtitle TextField-e58168 w-100" type="text" name="notif-block" id="listblock">
                </section>
            </div>
        </label>
        <div class="listblock_search hidden"></div>
    </div>
</div>
<div class="flex gap-7">
    <button type="button" class="btn btn-white Button-sn67">ارسال نوتیف توی سایت</button>
</div>
<script>
    jQuery(function (){
        tinymce.init({
            selector: "#description",
            plugins: "autoresize code link lists image",
            toolbar: "bold italic strikethrough backcolor | alignleft aligncenter alignright alignjustify |  bullist numlist  | image link",
            custom_elements: "~inline-token",
        });
        tinymce.init({
            selector: "#notif-description",
            plugins: "autoresize code link lists image",
            toolbar: "bold italic strikethrough backcolor | alignleft aligncenter alignright alignjustify |  bullist numlist  | image link",
            custom_elements: "~inline-token",
        });
    })
</script>