<div class="d-flex Container-mirV2w mb-4 Container--withBorder-OdFFhL">
    <div class="ProfileLayout__tab-rvmH7A TabItem-CWkOsT TabItem__active-AZcc4O text-subtitle-strong false" data-testid="tab-wrapper" data-pw="tab-0">تنظیمات تبلیغات </div>
</div>
<section class="mt-4 relative">
    <div class="styles_box-_dXFga">
        <?php
        $db = \Giftmax\Modules\Db::getLnstance();
        global $wpdb;
        $records = $db->first("SELECT meta_value FROM `{$wpdb->prefix}setting` WHERE `meta_key`=:key",array('key'=>'ads'));
        if (empty($records)){
        ?>
        <div class="styles_btn-_mLWvq">
            <div class="styles_btn--neutralOutlined__mLWvq Button-dw84">
                <i class="icon-delete"></i>
            </div>
            <div><label class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--L7bcQ uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--normal--A6Ntt text-body-1 color-n-700 w-100">
                    <p class="mb-2 color-n-700 text-body-1 mb-2" data-testid="form-label">لینک تبلیغات </p>
                    <div class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame__input-container--D5edN px-2 d-flex ai-center">
                        <section class="grow-1 text-body-2-c">
                            <input class="px-2 TextField__input-_5fbdd text-subtitle w-100 TextField-e58168" type="text" name="ads[][link]" placeholder="https://example.com"></section>
                    </div>
                </label>
                <label class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--L7bcQ uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--normal--A6Ntt text-body-1 color-n-700 w-100">
                    <p class="mb-2 color-n-700 text-body-1 mb-2" data-testid="form-label">عکس تبلیغات </p>
                    <div style="display: flex; justify-content: space-between">
                        <div class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame__input-container--D5edN px-2 d-flex ai-center" style="width: calc(100% - 70px)">
                            <section class="grow-1 text-body-2-c">
                                <input class="px-2 TextField__input-_5fbdd text-subtitle w-100 TextField-e58168 adsImg" type="text" name="ads[][img]"></section>
                        </div>
                        <div class="Button--uai23" data-id="adsImg">اپلود</div>
                    </div>
                </label>
            </div>
        </div>
        <?php
        }else{
            $records = json_decode($records['meta_value'],true);
            foreach ($records as $record){?>
                <div class="styles_btn-_mLWvq">
                    <div class="styles_btn--neutralOutlined__mLWvq Button-dw84">
                        <i class="icon-delete"></i>
                    </div>
                    <div><label class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--L7bcQ uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--normal--A6Ntt text-body-1 color-n-700 w-100">
                            <p class="mb-2 color-n-700 text-body-1 mb-2" data-testid="form-label">لینک تبلیغات</p>
                            <div class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame__input-container--D5edN px-2 d-flex ai-center">
                                <section class="grow-1 text-body-2-c">
                                    <input class="px-2 TextField__input-_5fbdd text-subtitle w-100 TextField-e58168" type="text" name="ads[][link]" placeholder="https://example.com" value="<?=$record['link']?>">
                                </section>
                            </div>
                        </label>
                        <label class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--L7bcQ uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--normal--A6Ntt text-body-1 color-n-700 w-100">
                            <p class="mb-2 color-n-700 text-body-1 mb-2" data-testid="form-label">عکس تبلیغات</p>
                            <div style="display: flex; justify-content: space-between">
                                <div class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame__input-container--D5edN px-2 d-flex ai-center" style="width: calc(100% - 70px)">
                                    <section class="grow-1 text-body-2-c">
                                        <input class="px-2 TextField__input-_5fbdd text-subtitle w-100 TextField-e58168 adsImg" type="text" name="ads[][img]" value="<?=$record['img']?>">
                                    </section>
                                </div>
                                <div class="Button--uai23" data-id="adsImg">اپلود</div>
                            </div>
                        </label>
                    </div>
                </div>
                <?php
            }
        }
        ?>
    </div>
    <div class="flex justify-between">
        <button type="button" class="btn !w-28 !text-5xs !text-green-dark !pt-2 !h-28 btn-white btn-icon icon-plus relative Button-adb65"></button>

        <button type="button" class="btn btn-white Button-sa45">ثبت</button>
    </div>
</section>