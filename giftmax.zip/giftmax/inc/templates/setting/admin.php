
<div class="d-flex Container-mirV2w mb-4 Container--withBorder-OdFFhL">
    <div class="ProfileLayout__tab-rvmH7A TabItem-CWkOsT TabItem__active-AZcc4O text-subtitle-strong false" data-testid="tab-wrapper" data-pw="tab-0">تنظیمات مدیریتی</div>
</div>
<section class="d-grid grid-cols-2 mt-4">
    <div class=" d-flex flex-column  TableCell__cell-quNpHF col-span-2 col-span-1-lg  TableCell__cell--horizontalSeprator-oY3HN8 py-4">
        <div class="d-flex jc-between ai-center">
            <div class="flex-1">
                <div class="d-flex ai-center gap-1">
                    <p class="text-body-1 color-n-500">جستجوی لایسنس</p>
                </div>
            </div>
            <button class="relative d-flex ai-center user-select-none btn-wc51H8 text-button-2 btn--text-se4oQM btn--primary-uiqWij btn--icon-ZPHT4g radius Button__medium-gIvke_ Button__textPrimary-IWW5Sd Button__prependIcon-hh7768 IconButton__button-RRc2H_ Button-sl21" data-testid="button-wrapper" type="button">
                <div class="d-flex ai-center jc-center relative grow-1">
                    <div class="d-flex IconButton__prependIcon-mxVR2M p-4" data-testid="icon-wrapper">
                        جستجو
                    </div>
                </div>
            </button>
        </div>
    </div>
    <div class=" d-flex flex-column  TableCell__cell-quNpHF col-span-2 col-span-1-lg  TableCell__cell--horizontalSeprator-oY3HN8 py-4">
        <div class="d-flex jc-between ai-center">
            <div class="flex-1">
                <div class="d-flex ai-center gap-1">
                    <p class="text-body-1 color-n-500">پنل کاربران</p>
                </div>
               </div>
            <button class="relative d-flex ai-center user-select-none btn-wc51H8 text-button-2 btn--text-se4oQM btn--primary-uiqWij btn--icon-ZPHT4g radius Button__medium-gIvke_ Button__textPrimary-IWW5Sd Button__prependIcon-hh7768 IconButton__button-RRc2H_ Button-pu47" data-testid="button-wrapper" type="button">
                <div class="d-flex ai-center jc-center relative grow-1">
                    <div class="d-flex IconButton__prependIcon-mxVR2M p-4" data-testid="icon-wrapper">
                        جستجو
                    </div>
                </div>
            </button>
        </div>
    </div>
    <div class=" d-flex flex-column  TableCell__cell-quNpHF col-span-2 col-span-1-lg  TableCell__cell--horizontalSeprator-oY3HN8 py-4">
        <div class="d-flex jc-between ai-center">
            <div class="flex-1">
                <div class="d-flex ai-center gap-1">
                    <p class="text-body-1 color-n-500">کارت بانکی</p>
                </div>
               </div>
            <button class="relative d-flex ai-center user-select-none btn-wc51H8 text-button-2 btn--text-se4oQM btn--primary-uiqWij btn--icon-ZPHT4g radius Button__medium-gIvke_ Button__textPrimary-IWW5Sd Button__prependIcon-hh7768 IconButton__button-RRc2H_ Button-bc57" data-testid="button-wrapper" type="button">
                <div class="d-flex ai-center jc-center relative grow-1">
                    <div class="d-flex IconButton__prependIcon-mxVR2M p-4" data-testid="icon-wrapper">
                        جستجو
                    </div>
                </div>
            </button>
        </div>
    </div>
    <div class=" d-flex flex-column  TableCell__cell-quNpHF col-span-2 col-span-1-lg  TableCell__cell--horizontalSeprator-oY3HN8 py-4">
        <div class="d-flex jc-between ai-center">
            <div class="flex-1">
                <div class="d-flex ai-center gap-1">
                    <p class="text-body-1 color-n-500">افزایش موجودی کیف پول کاربران</p>
                </div>
               </div>
            <button class="relative d-flex ai-center user-select-none btn-wc51H8 text-button-2 btn--text-se4oQM btn--primary-uiqWij btn--icon-ZPHT4g radius Button__medium-gIvke_ Button__textPrimary-IWW5Sd Button__prependIcon-hh7768 IconButton__button-RRc2H_ Button-drt57" data-testid="button-wrapper" type="button">
                <div class="d-flex ai-center jc-center relative grow-1">
                    <div class="d-flex IconButton__prependIcon-mxVR2M p-4" data-testid="icon-wrapper">
                        افزایش
                    </div>
                </div>
            </button>
        </div>
    </div>
    <div class=" d-flex flex-column  TableCell__cell-quNpHF col-span-2 col-span-1-lg  TableCell__cell--horizontalSeprator-oY3HN8 py-4">
        <div class="d-flex jc-between ai-center">
            <div class="flex-1">
                <div class="d-flex ai-center gap-1">
                    <p class="text-body-1 color-n-500">متغیر های تبدیل امتیاز به اعتبار</p>
                </div>
                <?php
                global $wpdb;
                $db = \Giftmax\Modules\Db::getLnstance();
                $records = $db->first("SELECT * FROM `{$wpdb->prefix}setting` WHERE `meta_key`='stp'");
                if (!empty($records)){
                $record = json_decode($records['meta_value'], true);
                ?>
                <p class="text-subtitle-strong flex-1"><?='هر' . number_format($record[0]['points']) . ' امتیاز معادل است با' . number_format($record[0]['toman'])?></p>
                <?php
                }else{
                    echo '  <p class="text-subtitle-strong flex-1"></p>';
                }
                ?>
            </div>
            <button class="relative d-flex ai-center user-select-none btn-wc51H8 text-button-2 btn--text-se4oQM btn--primary-uiqWij btn--icon-ZPHT4g radius Button__medium-gIvke_ Button__textPrimary-IWW5Sd Button__prependIcon-hh7768 IconButton__button-RRc2H_ Button-scpw4" data-testid="button-wrapper" type="button">
                <div class="d-flex ai-center jc-center relative grow-1">
                    <div class="d-flex IconButton__prependIcon-mxVR2M p-4" data-testid="icon-wrapper">
                        تنظیمات
                    </div>
                </div>
            </button>
        </div>
    </div>
    <div class="d-flex flex-column  TableCell__cell-quNpHF col-span-2 col-span-1-lg  TableCell__cell--horizontalSeprator-oY3HN8 py-4">
        <div class="d-flex jc-between ai-center">
            <div class="flex-1">
                <div class="d-flex ai-center gap-1">
                    <p class="text-body-1 color-n-500">دریافت لیست کاربران</p>
                </div>
                 </div>
            <button class="relative d-flex ai-center user-select-none btn-wc51H8 text-button-2 btn--text-se4oQM btn--primary-uiqWij btn--icon-ZPHT4g radius Button__medium-gIvke_ Button__textPrimary-IWW5Sd Button__prependIcon-hh7768 IconButton__button-RRc2H_ Button-giu18" data-testid="button-wrapper" type="button">
                <div class="d-flex ai-center jc-center relative grow-1">
                    <div class="d-flex IconButton__prependIcon-mxVR2M p-4" data-testid="icon-wrapper">
                دریافت
                    </div>
                </div>
            </button>
        </div>
    </div>
    <div class="d-flex flex-column  TableCell__cell-quNpHF col-span-2 col-span-1-lg  TableCell__cell--horizontalSeprator-oY3HN8 py-4">
        <div class="d-flex jc-between ai-center">
            <div class="flex-1">
                <div class="d-flex ai-center gap-1">
                    <p class="text-body-1 color-n-500">لیست کیف پول کاربران</p>
                </div>
                 </div>
            <button class="relative d-flex ai-center user-select-none btn-wc51H8 text-button-2 btn--text-se4oQM btn--primary-uiqWij btn--icon-ZPHT4g radius Button__medium-gIvke_ Button__textPrimary-IWW5Sd Button__prependIcon-hh7768 IconButton__button-RRc2H_ Button-swu64" type="button">
                <div class="d-flex ai-center jc-center relative grow-1">
                    <div class="d-flex IconButton__prependIcon-mxVR2M p-4" data-testid="icon-wrapper">
                نمایش
                    </div>
                </div>
            </button>
        </div>
    </div>
</section>
