<div id="content">
    <div class="container flex">

        <div class="col-12 mr24">
            <div class="c-bills">
                <div class="c-bills__header">
                    <div class="b-bills bills_number">ردیف</div>
                    <div class="b-bills bills_name">نام کاربر</div>
                    <div class="b-bills purchase_date">وضعیت احراز هویت</div>
                    <div class="b-bills bills_view">جزئیات</div>

                </div>
                <div id="c-bills">
                    <?php
                    $records = \Giftmax\model\UserModel::user_id__document();
                    if (!empty($records)){
                        foreach ($records as $key=>$record) {
                            $user = get_user_by('id', $record['user_id']);
                            $userdb = \Giftmax\model\SiteModel::table("user_identity","user_id",$record['user_id'])
                            ?>
                            <div class="c-bills__body">
                                <div class="b-bills bills_number">
                                    <span class="c-number"><?=$key+1?></span>
                                </div>
                                <div class="b-bills bills_name">
                                    <div class="c-color"><?="$user->first_name $user->last_name"?></div>
                                </div>
                                <div class="b-bills purchase_date">
                                    <div class="c-color "><?=$userdb['is_verified'] ? 'احراز شده' : 'احراز نشده'?></div>
                                </div>
                                <div class="b-bills bills_view">
                                    <div class="c-view Button-df45" data-id="<?=$record['user_id']?>">جزئیات</div>
                                </div>
                            </div>
                            <?php
                        }
                    }else{
                        ?>
                        <div class="c-bills__body">
                            <div class="b-bills" style="width:100%;">
                                <div class="c-color">در حال حاضر رکورد جدیدی وجود ندارد</div>
                            </div>
                        </div>
                    <?php
                    }
                    ?>
                </div>
            </div>
        </div>
    </div>
    <div class="ReactModalPortal pup" style="display: none"></div>
    <div class="ar-modal" style="opacity: 0; visibility: hidden;">
        <div class="ar-modal__container">
            <div class="ar-modal__box invoice-usages__usageModal">
                <div class="ar-modal__close">
                    ×
                </div>
                <div class="ar-modal__head">
                    <div class="ar-modal__title">
                        <div id="name_pup" class="flex align-items-center">احراز هویت</div>
                    </div>
                </div>
                <div class="ar-modal__content">
                    <div role="status" class="text-primary-500 margin-same-2 ar-spinner ar-spinner--border ar-spinner--primary"><svg viewBox="25 25 50 50"><circle cx="50" cy="50" r="20"></circle></svg></div>
                </div>
            </div>
        </div>
    </div>
    <div id="popper-root">
        <div class="absolute">
            <div id="snackbar-container" class="pos-fixed d-flex flex-column my-3 px-4 jc-center Snackbar__container-_86cf8 bottom-0 left-1/2 -translate-x-1/2 z-1000" style="left: 50%; transform: translateX(-50%); min-width: 320px;z-index: 9999999;"></div>
        </div>
    </div>
</div>
