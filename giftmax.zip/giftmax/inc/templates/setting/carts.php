<?php
if ($records){?>
    <div>
        <div class="c-bills__header">
            <div class="b-bills bills_number">ردیف</div>
            <div class="b-bills number-cart">شماره کارت</div>
            <div class="b-bills create-record">تاریخ ثبت</div>
            <div class="b-bills ip-send">IP</div>
            <div class="b-bills history-record">وضعیت استعلامی</div>
        </div>
        <div id="c-bills">
            <?php
            foreach ($records as $key=>$record){
                    $cardNumber = rtrim(
                        chunk_split(decrypt_data($record['card_number_enc']), 4, '-'),
                        '-'
                    );
            ?>
            <div class="c-bills__body">
                <div class="b-bills bills_number">
                    <span class="c-number"><?=$key+1?></span>
                </div>
                <div class="b-bills number-cart">
                    <div class="c-color"><?="$cardNumber"?></div>
                </div>
                <div class="b-bills create-record">
                    <div class="c-color " dir="rtl"><?=gjdate($record['created_at'],"d M Y, H:i")?></div>
                </div>
                <div class="b-bills ip-send">
                    <div class="c-color "><?=decrypt_data($record['ip'])?></div>
                </div>
                <div class="b-bills history-record">
                    <div class="c-color "><?=empty($record['phone']) ? 'مالکیت برای همین کاربر است':"این کارت متعلق به این کاربر نیست"?></div>
                </div>
            </div>
                <?php
            }
                ?>
        </div>
    </div>
<?php }else{?>
    <div class="c-bills">
        <div class="c-bills__header">
            <div class="b-bills bills_number">ردیف</div>
            <div class="b-bills number-cart">شماره کارت</div>
            <div class="b-bills create-record">تاریخ ثبت</div>
            <div class="b-bills ip-send">IP</div>
            <div class="b-bills history-record">وضعیت استعلامی</div>
        </div>
        <div id="c-bills">
            <div class="c-bills__body">
                <div class="b-bills" style="width:100%;">
                    <div class="c-color">در حال حاضر کارتی برای این کاربر وجود ندارد</div>
                </div>
            </div>
        </div>
    </div>
<?php }