<?php
if ($records){
    foreach ($records as $record){?>
            <div style="border: 1px solid #e6e6e6; margin-bottom: 10px; border-radius: 13px;padding: 10px;">
    <div class="flex justify-between">
        <p class="mb-2 color-n-700 text-body-1 mb-2 flex ai-center">تاریخ ثبت :<?=gjdate($record['created_at'],"d M Y ،H:i")?></p>
        <p class="mb-2 color-n-700 text-body-1 mb-2 flex ai-center">قیمت خریدار شما :<?=number_format($record['cost_price'])?></p>
        <?php
        if ($record['licence_status'] == 'assigned'){
            $status = '<span style=" display: inline-flex; align-items: center; justify-content: center;margin-right: 5px; padding: 0.05rem 0.8rem; border-radius: 999px; font-size: 0.82rem; font-weight: 600; background: rgba(255, 193, 59, 0.18); color: #b88315; ">لایسنس استفاده شده</span>';
        }elseif ($record['licence_status'] == 'available'){
            $status = '<span style=" display: inline-flex; align-items: center; justify-content: center;margin-right: 5px; padding: 0.05rem 0.8rem; border-radius: 999px; font-size: 0.82rem; font-weight: 600; background: rgba(76, 201, 146, 0.18); color: #1e9b6b; ">فعال</span>';
        }elseif ($record['licence_status'] == 'available'){
            $status = '<span style=" display: inline-flex; align-items: center; justify-content: center;margin-right: 5px; padding: 0.05rem 0.8rem; border-radius: 999px; font-size: 0.82rem; font-weight: 600; background: rgba(220, 53, 69, 0.18); color: #3b55ff; ">رزرو شده</span>';

        }
        ?>
        <div class="mb-2 color-n-700 text-body-1 mb-2 flex justify-between ai-center flex ai-center">وضعیت <?=$status?></div>
    </div>
    <div class="border-t-ccc"style=" margin-top: 10px; padding-top: 10px; ">
        <p class="text-subtitle-strong">اطلاعات محصول</p>
        <div class="">
        <?php
        $product = wc_get_product($record['product_id']);
        ?>
            <a class="text-body-1 color-n-500" href="<?=get_permalink($product->get_id())?>" target="_blank"><?=$product->name?></a>
        </div>
    </div>
    <?php
    if ($record['licence_status'] == 'assigned'){
    ?>
    <div class="border-t-ccc" style=" margin-top: 10px; padding-top: 10px; ">
        <p class="text-subtitle-strong">اطلاعات خریدار</p>
        <?php
        $order = wc_get_order($record['order_id']);
        if ($order){
        $user_id    = $order->get_customer_id();
        $user       = get_userdata($user_id);
        $first_name = $user->first_name;
        $last_name  = $user->last_name;
        $user_login = $user->user_login;
        $u = \Giftmax\model\SiteModel::table('user_identity', 'user_id', $user_id);
        $url = admin_url( "admin.php?page=wc-orders&action=edit&id={$record['order_id']}" )
        ?>
        <div class="InvoiceCustomerInfo">
            <div class="InvoiceCustomerInfo__item">
                <span class="InvoiceCustomerInfo__label">نام</span>
                <span class="InvoiceCustomerInfo__value"><button class="Button-iu64" data-number="<?=$user_login?>"><?="$first_name $last_name"?></button></span>

            </div>
            <div class="InvoiceCustomerInfo__divider InvoiceCustomerInfo__divider--v"></div>
            <div class="InvoiceCustomerInfo__item">
                <span class="InvoiceCustomerInfo__label">شناسه ملی</span>
                <span class="InvoiceCustomerInfo__value"><span><?=!empty($u['national_id_enc']) ? decrypt_data($u['national_id_enc']) : ''?></span></span>
            </div>
            <div class="InvoiceCustomerInfo__divider InvoiceCustomerInfo__divider--v"></div>
            <div class="InvoiceCustomerInfo__item">
                <span class="InvoiceCustomerInfo__label">شماره تلفن</span>
                <span class="InvoiceCustomerInfo__value"><span><?=$user_login?></span>
                </span>
            </div>
            <div class="InvoiceCustomerInfo__divider InvoiceCustomerInfo__divider--h"></div>
            <div class="InvoiceCustomerInfo__item">
                <span class="InvoiceCustomerInfo__label">سفارش</span>
                <span class="InvoiceCustomerInfo__value"><a href="<?=$url?>"><?=$record['order_id']?></a>
                </span>
            </div>
        </div>
            <?php
        }
            ?>
    </div>
        <?php
    }
        ?>
            </div>
<?php }
}else{?>
    <div class="flex justify-center">لایسنس موجود نمیباشد</div>
<?php }