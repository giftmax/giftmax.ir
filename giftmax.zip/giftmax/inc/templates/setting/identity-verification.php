<?php

use Giftmax\modules\Db;

?>
<div class="d-flex Container-mirV2w mb-4 Container--withBorder-OdFFhL">
    <div class="ProfileLayout__tab-rvmH7A TabItem-CWkOsT TabItem__active-AZcc4O text-subtitle-strong false" data-testid="tab-wrapper" data-pw="tab-0">تنظیمات ثبت نام و ورود</div>
</div>
<section class="d-grid grid-cols-2 mt-4">
    <div class=" d-flex flex-column  TableCell__cell-quNpHF col-span-2 col-span-1-lg  TableCell__cell--horizontalSeprator-oY3HN8 py-4">
        <div class="d-flex jc-between ai-center">
            <div class="flex-1">
                <div class="d-flex ai-center mb-2 gap-1">
                    <p class="text-body-1 color-n-500">استعلام شاهکار</p>
                </div>
            </div>
            <div class="flex flex-col gap-15">
                <label for="shahkar_zohal" class="input-label start">
                    <span class="start-label">زحل</span>
                    <input id="shahkar_zohal" type="checkbox" onclick="changeSwitch('shahkar_jibit')" class="input"  <?= \Giftmax\model\SiteModel::setting("shahkar_zohal") === true ? 'checked' : '' ?>>
                    <span class="input-check"></span>
                </label>
                <label for="shahkar_jibit" class="input-label start">
                    <span class="start-label">جیبیت</span>
                    <input id="shahkar_jibit" type="checkbox" onclick="changeSwitch('shahkar_zohal')" class="input"  <?= \Giftmax\model\SiteModel::setting("shahkar_jibit") === true ? 'checked' : '' ?>>
                    <span class="input-check"></span>
                </label>
            </div>
        </div>
    </div>
    <div class=" d-flex flex-column  TableCell__cell-quNpHF col-span-2 col-span-1-lg  TableCell__cell--horizontalSeprator-oY3HN8 py-4">
        <div class="d-flex jc-between ai-center">
            <div class="flex-1">
                <div class="d-flex ai-center mb-2 gap-1">
                    <p class="text-body-1 color-n-500">تطابق شماره کارت و کد ملی</p>
                </div>
            </div>
            <div class="flex flex-col gap-15">
                <label for="check_card_with_national_code_zohal" class="input-label start">
                    <span class="start-label">زحل</span>
                    <input id="check_card_with_national_code_zohal" type="checkbox" onclick="changeSwitch('check_card_with_national_code_jibit')" class="input" <?= \Giftmax\model\SiteModel::setting("check_card_with_national_code_zohal") === true ? 'checked' : ''?>>
                    <span class="input-check"></span>
                </label>
                <label for="check_card_with_national_code_jibit" class="input-label start">
                    <span class="start-label">جیبیت</span>
                    <input id="check_card_with_national_code_jibit" type="checkbox" onclick="changeSwitch('check_card_with_national_code_zohal')" class="input"  <?= \Giftmax\model\SiteModel::setting("check_card_with_national_code_jibit") === true ? 'checked' : '' ?>>
                    <span class="input-check"></span>
                </label>
            </div>
        </div>
    </div>
    <div class=" d-flex flex-column  TableCell__cell-quNpHF col-span-2 col-span-1-lg  TableCell__cell--horizontalSeprator-oY3HN8 py-4">
        <div class="d-flex jc-between ai-center">
            <div class="flex-1">
                <div class="d-flex ai-center mb-2 gap-1">
                    <p class="text-body-1 color-n-500">توضیحات مورد ثبت نام</p>
                </div>
                <?php
                $description = \Giftmax\model\SiteModel::table('setting','meta_key','description_register')['meta_value'];
                ?>
                <p class="text-subtitle-strong"><?=!empty($description) ? $description: 'وارد کنید'?></p>
            </div>
            <button class="relative d-flex ai-center user-select-none btn-wc51H8 text-button-2 btn--text-se4oQM btn--primary-uiqWij btn--icon-ZPHT4g radius Button__medium-gIvke_ Button__textPrimary-IWW5Sd Button__prependIcon-hh7768 IconButton__button-RRc2H_ Button-sdl78" data-testid="button-wrapper" type="button">
                <div class="d-flex ai-center jc-center relative grow-1">
                    <div class="d-flex IconButton__prependIcon-mxVR2M p-4" data-testid="icon-wrapper">
                        <svg data-testid="button-prepend-icon" style="width: 24px; height: 24px; fill: var(--color-icon-primary);"><path d="M15.293 3.293c0.391-0.391 1.024-0.391 1.414 0l4 4c0.391 0.391 0.391 1.024 0 1.414l-12 12c-0.188 0.188-0.442 0.293-0.707 0.293h-4c-0.552 0-1-0.448-1-1v-4c0-0.265 0.105-0.52 0.293-0.707l12-12zM5 16.414v2.586h2.586l11-11-2.586-2.586-11 11zM10 21l2-2h9v2h-11z"></path></svg>
                    </div>
                </div>
            </button>
        </div>
    </div>
    <div class=" d-flex flex-column  TableCell__cell-quNpHF col-span-2 col-span-1-lg  TableCell__cell--horizontalSeprator-oY3HN8 py-4">
        <div class="d-flex jc-between ai-center">
            <div class="flex-1">
                <div class="d-flex ai-center mb-2 gap-1">
                    <p class="text-body-1 color-n-500">ارسال کد صوتی</p>
                </div>
            </div>
            <label for="otpAudioLogin" class="input-label start w40_1">
                <span class="start-label"></span>
                <input id="otpAudioLogin" type="checkbox" class="input" <?= \Giftmax\model\SiteModel::setting("otpAudioLogin") === true ? 'checked' : '' ?>>
                <span class="input-check"></span>
            </label>
        </div>
    </div>
</section>