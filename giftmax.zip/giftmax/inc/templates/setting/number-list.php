
<?php
if (!empty($records)){
    foreach ($records as $record){
        ?>
        <div class="InvoiceCustomerInfo mt-3">
            <div class="InvoiceCustomerInfo__item">
                <span class="InvoiceCustomerInfo__label">شماره تلفن</span>
                <span class="InvoiceCustomerInfo__value"><span><?=$record['phone']?></span></span>
            </div>
        </div>
        <?php
    }
}else{
    ?>
    <div class="InvoiceCustomerInfo mt-3">
        <div class="InvoiceCustomerInfo__item justify-center">
            <span class="w-full flex justify-center">چیزی پیدا نشد</span>
        </div>
    </div>
    <?php
}