<?php
if ($user){?>
    <?php
    $first_name = $user->first_name;
    $last_name  = $user->last_name;
    $user_login = $user->user_login;
    $u = \Giftmax\Modules\UserModel::table('user_identity', 'user_id', $user->ID);
    ?>
    <div class="InvoiceCustomerInfo">
        <div class="InvoiceCustomerInfo__item">
            <span class="InvoiceCustomerInfo__label">نام</span>
            <span class="InvoiceCustomerInfo__value"><?="$first_name $last_name"?></span>

        </div>
        <div class="InvoiceCustomerInfo__divider InvoiceCustomerInfo__divider--v"></div>
        <div class="InvoiceCustomerInfo__item">
            <span class="InvoiceCustomerInfo__label">شناسه ملی</span>
            <span class="InvoiceCustomerInfo__value"><span><?=!empty($u['national_id_enc']) ? decrypt_data($u['national_id_enc']) : ''?></span></span>
        </div>
        <div class="InvoiceCustomerInfo__divider InvoiceCustomerInfo__divider--v"></div>
        <div class="InvoiceCustomerInfo__item">
            <span class="InvoiceCustomerInfo__label">شماره تلفن</span>
            <span class="InvoiceCustomerInfo__value"><span><?=$user_login?></span>
                </span>
        </div>
        <div class="InvoiceCustomerInfo__divider InvoiceCustomerInfo__divider--h"></div>
        <div class="InvoiceCustomerInfo__item">
            <span class="InvoiceCustomerInfo__label">تلفن ثابت</span>
            <span class="InvoiceCustomerInfo__value"><span><?=!empty($u['landline_phone']) ? decrypt_data($u['landline_phone']) : ''?></span>
        </div>
        <div class="InvoiceCustomerInfo__divider InvoiceCustomerInfo__divider--v"></div>
        <div class="InvoiceCustomerInfo__item">
            <span class="InvoiceCustomerInfo__label">احراز هویت</span>
            <span class="InvoiceCustomerInfo__value"><span><?=!empty($u['is_vip']) ? 'بله' : 'خیر'?></span></span>
        </div>
        <div class="InvoiceCustomerInfo__divider InvoiceCustomerInfo__divider--v"></div>
        <div class="InvoiceCustomerInfo__item">
            <span class="InvoiceCustomerInfo__label">تاریخ ثبت نام</span>
            <span class="InvoiceCustomerInfo__value"><span><?= gjdate($u['created_at'],'d M Y')?></span></span>
        </div>
        <div class="InvoiceCustomerInfo__divider InvoiceCustomerInfo__divider--h"></div>

        <?php
        $is_block = is_user_blocked($user->ID);
        if ($u['is_vip']){
            global $wpdb;
            $db = \Giftmax\Modules\Db::getLnstance();
            $National_card__img = $db->first("SELECT * FROM {$wpdb->prefix}documents WHERE user_id = :user_id AND doc_type = 'National_card__img' AND accepted=2 ",array('user_id' => $user->ID));
            $birth_certificate = $db->first("SELECT * FROM {$wpdb->prefix}documents WHERE user_id = :user_id AND doc_type = 'Birth_certificate' AND accepted=2 ",array('user_id' => $user->ID));
            ?>
            <div class="InvoiceCustomerInfo__divider InvoiceCustomerInfo__divider--v"></div>
            <div class="InvoiceCustomerInfo__item">
            <span class="InvoiceCustomerInfo__label">عکش کارت ملی</span>
            <span class="InvoiceCustomerInfo__value"><a href="<?=$National_card__img['document']?>" target="_blank">مشاهده</a></span>
        </div>
        <div class="InvoiceCustomerInfo__divider InvoiceCustomerInfo__divider--v"></div>
        <div class="InvoiceCustomerInfo__item">
            <span class="InvoiceCustomerInfo__label">عکش شناسنامه</span>
            <span class="InvoiceCustomerInfo__value"><a href="<?=$birth_certificate['document']?>" target="_blank">مشاهده</a></span>
        </div>
            <div class="InvoiceCustomerInfo__divider InvoiceCustomerInfo__divider--v"></div>
            <div class="InvoiceCustomerInfo__item">
                <span class="InvoiceCustomerInfo__label">بلاک</span>
                <span class="InvoiceCustomerInfo__value"><span><?= $is_block ? 'بله' : 'خیر'?></span></span>
            </div>
            <div class="InvoiceCustomerInfo__divider InvoiceCustomerInfo__divider--h"></div>
            <div class="InvoiceCustomerInfo__item">
                <span class="InvoiceCustomerInfo__label">عملیات بلاک</span>
                <span class="InvoiceCustomerInfo__value"><button class="Button-bu12" data-id="<?=$user->ID?>"><?= $is_block ? 'رفع مسدودی' : 'مسدود کردن'?></button></span>
            </div>
            <div class="InvoiceCustomerInfo__divider InvoiceCustomerInfo__divider--v"></div>
            <div class="InvoiceCustomerInfo__item">
                <span class="InvoiceCustomerInfo__label">کارت های بانکی</span>
                <span class="InvoiceCustomerInfo__value"><button class="Button-fw64" data-id="<?=$user->ID?>">مشاهده</button></span>
            </div>
            <?php
        }else{
            ?>

            <div class="InvoiceCustomerInfo__item">
                <span class="InvoiceCustomerInfo__label">بلاک</span>
                <span class="InvoiceCustomerInfo__value"><span><?= $is_block ? 'بله' : 'خیر'?></span></span>
            </div>
            <div class="InvoiceCustomerInfo__divider InvoiceCustomerInfo__divider--v"></div>
            <div class="InvoiceCustomerInfo__item">
                <span class="InvoiceCustomerInfo__label">عملیات بلاک</span>
                <span class="InvoiceCustomerInfo__value"><button class="Button-bu12" data-id="<?=$user->ID?>"><?= $is_block ? 'رفع مسدودی' : 'مسدود کردن'?></button></span>
            </div>
            <div class="InvoiceCustomerInfo__divider InvoiceCustomerInfo__divider--v"></div>
            <div class="InvoiceCustomerInfo__item">
                <span class="InvoiceCustomerInfo__label">کارت های بانکی</span>
                <span class="InvoiceCustomerInfo__value"><button class="Button-fw64" data-id="<?=$user->ID?>">مشاهده</button></span>
            </div>
            <?php
        }
            ?>
    </div>
<?php }else{?>
    <div class="flex justify-center">کاربری پیدا نشد</div>
<?php }