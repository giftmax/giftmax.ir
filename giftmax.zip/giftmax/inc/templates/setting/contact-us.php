<div class="d-flex Container-mirV2w mb-4 Container--withBorder-OdFFhL">
    <div class="ProfileLayout__tab-rvmH7A TabItem-CWkOsT TabItem__active-AZcc4O text-subtitle-strong false" data-testid="tab-wrapper" data-pw="tab-0">تنظیمات تماس با ما</div>
</div>
<section class="d-grid grid-cols-2 mt-4">
    <div class=" d-flex flex-column  TableCell__cell-quNpHF col-span-2 col-span-1-lg  TableCell__cell--horizontalSeprator-oY3HN8 py-4">
        <div class="d-flex jc-between ai-center">
            <div class="flex-1">
                <div class="d-flex ai-center mb-2 gap-1">
                    <p class="text-body-1 color-n-500">شماره تماس</p>
                </div>
                <p class="text-subtitle-strong flex-1"><?=\Giftmax\Modules\UserModel::setting("tel") == 'true' ?\Giftmax\Modules\UserModel::settingValue("tel") : 'وارد کنید'?></p>
            </div>
            <button class="relative d-flex ai-center user-select-none btn-wc51H8 text-button-2 btn--text-se4oQM btn--primary-uiqWij btn--icon-ZPHT4g radius Button__medium-gIvke_ Button__textPrimary-IWW5Sd Button__prependIcon-hh7768 IconButton__button-RRc2H_ Button-tb54" data-testid="button-wrapper" type="button">
                <div class="d-flex ai-center jc-center relative grow-1">
                    <div class="d-flex IconButton__prependIcon-mxVR2M p-4" data-testid="icon-wrapper">
                        <svg data-testid="button-prepend-icon" style="width: 24px; height: 24px; fill: var(--color-icon-primary);"><path d="M15.293 3.293c0.391-0.391 1.024-0.391 1.414 0l4 4c0.391 0.391 0.391 1.024 0 1.414l-12 12c-0.188 0.188-0.442 0.293-0.707 0.293h-4c-0.552 0-1-0.448-1-1v-4c0-0.265 0.105-0.52 0.293-0.707l12-12zM5 16.414v2.586h2.586l11-11-2.586-2.586-11 11zM10 21l2-2h9v2h-11z"></path></svg>
                    </div>
                </div>
            </button>
        </div>
    </div>
    <div class=" d-flex flex-column  TableCell__cell-quNpHF col-span-2 col-span-1-lg  TableCell__cell--horizontalSeprator-oY3HN8 py-4">
        <div class="d-flex jc-between ai-center">
            <div class="flex-1">
                <div class="d-flex ai-center mb-2 gap-1">
                    <p class="text-body-1 color-n-500">پشتیبانی آنلاین در تلگرام</p>
                </div>
                <p class="text-subtitle-strong flex-1"><?=\Giftmax\Modules\UserModel::setting("telegram") == 'true' ?\Giftmax\Modules\UserModel::settingValue("telegram") : 'وارد کنید'?></p>
            </div>
            <button class="relative d-flex ai-center user-select-none btn-wc51H8 text-button-2 btn--text-se4oQM btn--primary-uiqWij btn--icon-ZPHT4g radius Button__medium-gIvke_ Button__textPrimary-IWW5Sd Button__prependIcon-hh7768 IconButton__button-RRc2H_ Button-gb45" data-testid="button-wrapper" type="button">
                <div class="d-flex ai-center jc-center relative grow-1">
                    <div class="d-flex IconButton__prependIcon-mxVR2M p-4" data-testid="icon-wrapper">
                        <svg data-testid="button-prepend-icon" style="width: 24px; height: 24px; fill: var(--color-icon-primary);"><path d="M15.293 3.293c0.391-0.391 1.024-0.391 1.414 0l4 4c0.391 0.391 0.391 1.024 0 1.414l-12 12c-0.188 0.188-0.442 0.293-0.707 0.293h-4c-0.552 0-1-0.448-1-1v-4c0-0.265 0.105-0.52 0.293-0.707l12-12zM5 16.414v2.586h2.586l11-11-2.586-2.586-11 11zM10 21l2-2h9v2h-11z"></path></svg>
                    </div>
                </div>
            </button>
        </div>
    </div>
    <div class=" d-flex flex-column  TableCell__cell-quNpHF col-span-2 col-span-1-lg  TableCell__cell--horizontalSeprator-oY3HN8 py-4">
        <div class="d-flex jc-between ai-center">
            <div class="flex-1">
                <div class="d-flex ai-center mb-2 gap-1">
                    <p class="text-body-1 color-n-500">پشتیبانی آنلاین در اینستاگرام</p>
                </div>
                <p class="text-subtitle-strong flex-1"><?=\Giftmax\Modules\UserModel::setting("instagram") == 'true' ?\Giftmax\Modules\UserModel::settingValue("instagram") : 'وارد کنید'?></p>
            </div>
            <button class="relative d-flex ai-center user-select-none btn-wc51H8 text-button-2 btn--text-se4oQM btn--primary-uiqWij btn--icon-ZPHT4g radius Button__medium-gIvke_ Button__textPrimary-IWW5Sd Button__prependIcon-hh7768 IconButton__button-RRc2H_ Button-ib45" data-testid="button-wrapper" type="button">
                <div class="d-flex ai-center jc-center relative grow-1">
                    <div class="d-flex IconButton__prependIcon-mxVR2M p-4" data-testid="icon-wrapper">
                        <svg data-testid="button-prepend-icon" style="width: 24px; height: 24px; fill: var(--color-icon-primary);"><path d="M15.293 3.293c0.391-0.391 1.024-0.391 1.414 0l4 4c0.391 0.391 0.391 1.024 0 1.414l-12 12c-0.188 0.188-0.442 0.293-0.707 0.293h-4c-0.552 0-1-0.448-1-1v-4c0-0.265 0.105-0.52 0.293-0.707l12-12zM5 16.414v2.586h2.586l11-11-2.586-2.586-11 11zM10 21l2-2h9v2h-11z"></path></svg>
                    </div>
                </div>
            </button>
        </div>
    </div>
    <div class=" d-flex flex-column  TableCell__cell-quNpHF col-span-2 col-span-1-lg  TableCell__cell--horizontalSeprator-oY3HN8 py-4">
        <div class="d-flex jc-between ai-center">
            <div class="flex-1">
                <div class="d-flex ai-center mb-2 gap-1">
                    <p class="text-body-1 color-n-500">پشتیبانی آنلاین در واتساپ</p>
                </div>
                <p class="text-subtitle-strong flex-1"><?=\Giftmax\Modules\UserModel::setting("whatsapp") == 'true' ?\Giftmax\Modules\UserModel::settingValue("whatsapp") : 'وارد کنید'?></p>
            </div>
            <button class="relative d-flex ai-center user-select-none btn-wc51H8 text-button-2 btn--text-se4oQM btn--primary-uiqWij btn--icon-ZPHT4g radius Button__medium-gIvke_ Button__textPrimary-IWW5Sd Button__prependIcon-hh7768 IconButton__button-RRc2H_ Button-sb42" data-testid="button-wrapper" type="button">
                <div class="d-flex ai-center jc-center relative grow-1">
                    <div class="d-flex IconButton__prependIcon-mxVR2M p-4" data-testid="icon-wrapper">
                        <svg data-testid="button-prepend-icon" style="width: 24px; height: 24px; fill: var(--color-icon-primary);"><path d="M15.293 3.293c0.391-0.391 1.024-0.391 1.414 0l4 4c0.391 0.391 0.391 1.024 0 1.414l-12 12c-0.188 0.188-0.442 0.293-0.707 0.293h-4c-0.552 0-1-0.448-1-1v-4c0-0.265 0.105-0.52 0.293-0.707l12-12zM5 16.414v2.586h2.586l11-11-2.586-2.586-11 11zM10 21l2-2h9v2h-11z"></path></svg>
                    </div>
                </div>
            </button>
        </div>
    </div>
    <div class=" d-flex flex-column  TableCell__cell-quNpHF col-span-2 col-span-1-lg  TableCell__cell--horizontalSeprator-oY3HN8 py-4">
        <div class="d-flex jc-between ai-center">
            <div class="flex-1">
                <div class="d-flex ai-center mb-2 gap-1">
                    <p class="text-body-1 color-n-500">ایمیل</p>
                </div>
                <p class="text-subtitle-strong flex-1"><?=\Giftmax\Modules\UserModel::setting("email") == 'true' ?\Giftmax\Modules\UserModel::settingValue("email") : 'وارد کنید'?></p>
            </div>
            <button class="relative d-flex ai-center user-select-none btn-wc51H8 text-button-2 btn--text-se4oQM btn--primary-uiqWij btn--icon-ZPHT4g radius Button__medium-gIvke_ Button__textPrimary-IWW5Sd Button__prependIcon-hh7768 IconButton__button-RRc2H_ Button-eb65" data-testid="button-wrapper" type="button">
                <div class="d-flex ai-center jc-center relative grow-1">
                    <div class="d-flex IconButton__prependIcon-mxVR2M p-4" data-testid="icon-wrapper">
                        <svg data-testid="button-prepend-icon" style="width: 24px; height: 24px; fill: var(--color-icon-primary);"><path d="M15.293 3.293c0.391-0.391 1.024-0.391 1.414 0l4 4c0.391 0.391 0.391 1.024 0 1.414l-12 12c-0.188 0.188-0.442 0.293-0.707 0.293h-4c-0.552 0-1-0.448-1-1v-4c0-0.265 0.105-0.52 0.293-0.707l12-12zM5 16.414v2.586h2.586l11-11-2.586-2.586-11 11zM10 21l2-2h9v2h-11z"></path></svg>
                    </div>
                </div>
            </button>
        </div>
    </div>
</section>