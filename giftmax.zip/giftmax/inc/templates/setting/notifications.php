<div class="d-flex Container-mirV2w mb-4 Container--withBorder-OdFFhL">
    <div class="ProfileLayout__tab-rvmH7A TabItem-CWkOsT TabItem__active-AZcc4O text-subtitle-strong false" data-testid="tab-wrapper" data-pw="tab-0">تنظیمات بنر </div>
</div>
<section class="mt-4 relative">
    <div class=" d-flex flex-column col-span-2 col-span-1-lg py-4 " style="width: 25%">
        <div class="d-flex jc-between ai-center">
            <div class="flex-1">
                <div class="d-flex ai-center mb-2 gap-1">
                    <p class="text-body-1 color-n-500">بنر</p>
                </div>
            </div>
            <label for="banner" class="input-label start w40_1">
                <span class="start-label"> غیر فعال </span>
                <input id="banner" type="checkbox" class="input" <?=\Giftmax\Modules\UserModel::setting("banner") === true ? 'checked' : ''?>>
                <span class="input-check">  </span>
            </label>
        </div>
    </div>
    <div id="c-banner" class="<?=\Giftmax\Modules\UserModel::setting("banner") === true ? '' : 'hidden'?>">
    <div class="styles_box-_dXFga">
        <?php
        $db = \Giftmax\Modules\Db::getLnstance();
        global $wpdb;
        $records = $db->first("SELECT meta_value FROM `{$wpdb->prefix}setting` WHERE `meta_key`=:key",array('key'=>'notifications'));
        if (empty($records)){
        ?>
        <div class="styles_btn-_mLWvq">
            <div><label class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--L7bcQ uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--normal--A6Ntt text-body-1 color-n-700 w-100">
                    <p class="mb-2 color-n-700 text-body-1 mb-2" data-testid="form-label">لینک بنر </p>
                    <div class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame__input-container--D5edN px-2 d-flex ai-center">
                        <section class="grow-1 text-body-2-c">
                            <input class="px-2 TextField__input-_5fbdd text-subtitle w-100 TextField-e58168" type="text" name="notifications[][link]" placeholder="https://example.com"></section>
                    </div>
                </label>
                <label class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--L7bcQ uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--normal--A6Ntt text-body-1 color-n-700 w-100">
                    <p class="mb-2 color-n-700 text-body-1 mb-2" data-testid="form-label">عکس بنر دسکتاپ</p>
                    <div style="display: flex; justify-content: space-between">
                        <div class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame__input-container--D5edN px-2 d-flex ai-center" style="width: calc(100% - 70px)">
                            <section class="grow-1 text-body-2-c">
                                <input class="px-2 TextField__input-_5fbdd text-subtitle w-100 TextField-e58168 notificationsImgd" type="text" name="notifications[][img][d]"></section>
                        </div>
                        <div class="Button--uai23" data-id="notificationsImgd">اپلود</div>
                    </div>
                </label>
                <label class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--L7bcQ uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--normal--A6Ntt text-body-1 color-n-700 w-100">
                    <p class="mb-2 color-n-700 text-body-1 mb-2" data-testid="form-label">عکس بنر موبایل</p>
                    <div style="display: flex; justify-content: space-between">
                        <div class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame__input-container--D5edN px-2 d-flex ai-center" style="width: calc(100% - 70px)">
                            <section class="grow-1 text-body-2-c">
                                <input class="px-2 TextField__input-_5fbdd text-subtitle w-100 TextField-e58168 notificationsImgm" type="text" name="notifications[][img][m]"></section>
                        </div>
                        <div class="Button--uai23" data-id="notificationsImgm">اپلود</div>
                    </div>
                </label>
            </div>
        </div>
        <?php
        }else{
            $records = json_decode($records['meta_value'],true);
            foreach ($records as $record){?>
                <div class="styles_btn-_mLWvq">
                    <div><label class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--L7bcQ uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--normal--A6Ntt text-body-1 color-n-700 w-100">
                            <p class="mb-2 color-n-700 text-body-1 mb-2" data-testid="form-label">لینک بنر</p>
                            <div class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame__input-container--D5edN px-2 d-flex ai-center">
                                <section class="grow-1 text-body-2-c">
                                    <input class="px-2 TextField__input-_5fbdd text-subtitle w-100 TextField-e58168" type="text" name="notifications[][link]" placeholder="https://example.com" value="<?=$record['link']?>">
                                </section>
                            </div>
                        </label>
                        <label class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--L7bcQ uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--normal--A6Ntt text-body-1 color-n-700 w-100">
                            <p class="mb-2 color-n-700 text-body-1 mb-2" data-testid="form-label">عکس بنر دسکتاپ</p>
                            <div style="display: flex; justify-content: space-between">
                                <div class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame__input-container--D5edN px-2 d-flex ai-center" style="width: calc(100% - 70px)">
                                    <section class="grow-1 text-body-2-c">
                                        <input class="px-2 TextField__input-_5fbdd text-subtitle w-100 TextField-e58168 notificationsImgd" type="text" name="notifications[][img][d]" value="<?=$record['img']['d']?>">
                                    </section>
                                </div>
                                <div class="Button--uai23" data-id="notificationsImgd">اپلود</div>
                            </div>
                        </label>
                        <label class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--L7bcQ uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--normal--A6Ntt text-body-1 color-n-700 w-100">
                            <p class="mb-2 color-n-700 text-body-1 mb-2" data-testid="form-label">عکس بنر دسکتاپ</p>
                            <div style="display: flex; justify-content: space-between">
                                <div class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame__input-container--D5edN px-2 d-flex ai-center" style="width: calc(100% - 70px)">
                                    <section class="grow-1 text-body-2-c">
                                        <input class="px-2 TextField__input-_5fbdd text-subtitle w-100 TextField-e58168 notificationsImgm" type="text" name="notifications[][img][m]" value="<?=$record['img']['m']?>">
                                    </section>
                                </div>
                                <div class="Button--uai23" data-id="notificationsImgm">اپلود</div>
                            </div>
                        </label>
                    </div>
                </div>
                <?php
            }
        }
        ?>
    </div>
    <div class="flex justify-between">
        <button type="button" class="btn btn-white Button-sn45">ثبت</button>
    </div>
    </div>
</section>