<?php
if ($user){?>
    <?php
    $first_name = $user->first_name;
    $last_name  = $user->last_name;
    $u = \Giftmax\model\SiteModel::table('user_identity', 'user_id', $user->ID);
    ?>
        <input name="userId" value="<?=$user->ID?>" type="hidden">
    <div class="InvoiceCustomerInfo">
        <div class="InvoiceCustomerInfo__item">
            <span class="InvoiceCustomerInfo__label">نام</span>
            <span class="InvoiceCustomerInfo__value"><?="$first_name $last_name"?></span>

        </div>
        <div class="InvoiceCustomerInfo__divider InvoiceCustomerInfo__divider--v"></div>
        <div class="InvoiceCustomerInfo__item">
            <span class="InvoiceCustomerInfo__label">کارت های بانکی</span>
            <span class="InvoiceCustomerInfo__value"><button class="Button-fw64" data-id="<?=$user->ID?>">مشاهده</button></span>
        </div>
        <div class="InvoiceCustomerInfo__divider InvoiceCustomerInfo__divider--h"></div>
        <div class="InvoiceCustomerInfo__item">
            <span class="InvoiceCustomerInfo__label">موجودی کیف پول</span>
            <span class="InvoiceCustomerInfo__value"><span><?= number_format(\Giftmax\model\UserModel::wallet($user->ID)) ?>تومان</span></span>
        </div>
    </div>
    <label class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--L7bcQ uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--normal--A6Ntt text-body-1 color-n-700 w-100">
        <p class="mb-2 color-n-700 text-body-1 mb-2" data-testid="form-label"> افزایش موجودی </p>
        <div class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame__input-container--D5edN px-2 d-flex ai-center">
            <section class="grow-1 text-body-2-c">
                <input class="px-2 TextField__input-_5fbdd text-subtitle w-100 TextField-e58168" type="text" name="balance" placeholder="3000"></section>
        </div>
    </label>
    <div class="ModalComponent__footerContainer-rb1vEj mt-3">
        <div class="ProfileModal__footer-IVQdrc " style=" padding: 12px 0px; ">
            <button class="relative d-flex ai-center user-select-none btn-wc51H8 text-button-2 btn--primary-uiqWij radius Button__medium-gIvke_ Button__filledPrimary-OvgwGb ProfileBase__button-jvi4aR ProfileBase__button__modal-O3kjhU Button-bw41"
                    data-testid="button-wrapper" type="button">
                <div class="d-flex ai-center jc-center relative grow-1">تایید</div>
            </button>
        </div>
    </div>
<?php }else{?>
    <div class="flex justify-center">کاربری پیدا نشد</div>
<?php }