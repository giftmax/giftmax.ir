<div class="d-flex Container-mirV2w mb-4 Container--withBorder-OdFFhL">
    <div class="ProfileLayout__tab-rvmH7A TabItem-CWkOsT TabItem__active-AZcc4O text-subtitle-strong false" data-testid="tab-wrapper" data-pw="tab-0">دسته بندی ها خرید سریع</div>
</div>
<div style="
    margin-top: 44px;
">

    <div class="styles_box-_dXFga d-grid grid-cols-2" style="gap: 30px 12px;">
        <?php
        $db = \Giftmax\modules\Db::getLnstance();
        global $wpdb;
        $records = $db->first("SELECT meta_value FROM `{$wpdb->prefix}setting` WHERE `meta_key`=:key",array('key'=>'tab'));
        if (!empty($records) && !empty(json_decode($records['meta_value'],true))){
            $array = json_decode($records['meta_value'],true);
            foreach ($array as $key => $value){?>
                <div class="styles_btn-_mLWbq" data-slug="<?=$key?>">
                    <div class="styles_btn--neutralOutlined__mLWbq Button-dfs18">
                        <i class="icon-delete"></i>
                    </div>
                    <div class=" d-flex flex-column">
                        <div class="d-flex jc-between ai-start gap-14">
                            <div>
                                <label class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--L7bcQ uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--normal--A6Ntt text-body-1 color-n-700 w-100">
                                    <p class="mb-2 color-n-700 text-body-1 mb-2" data-testid="form-label"> نام تب </p>
                                    <div class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame__input-container--D5edN px-2 d-flex ai-center">
                                        <section class="grow-1 text-body-2-c">
                                            <input class="px-2 TextField__input-_5fbdd text-subtitle w-100 TextField-e58168" type="text" id="name" value="<?=$value['name']?>"></section>
                                    </div>
                                </label>
                                <label class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--L7bcQ uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--normal--A6Ntt text-body-1 color-n-700 w-100">
                                    <p class="mb-2 color-n-700 text-body-1 mb-2" data-testid="form-label"> نام انگلیسی تب </p>
                                    <div class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame__input-container--D5edN px-2 d-flex ai-center">
                                        <section class="grow-1 text-body-2-c">
                                            <input class="px-2 TextField__input-_5fbdd text-subtitle w-100 TextField-e58168" type="text" id="name_en" value="<?=$key?>"></section>
                                    </div>
                                </label>
                                <p class="text-subtitle-strong flex-1"></p>
                            </div>
                            <button class="relative d-flex ai-center user-select-none btn-wc51H8 text-button-2 btn--text-se4oQM btn--primary-uiqWij btn--icon-ZPHT4g radius Button__medium-gIvke_ Button__textPrimary-IWW5Sd Button__prependIcon-hh7768 IconButton__button-RRc2H_ Button-qfc65" data-testid="button-wrapper" type="button">
                                <div class="d-flex ai-center jc-center relative grow-1">
                                    <div class="d-flex IconButton__prependIcon-mxVR2M p-4" data-testid="icon-wrapper">
                                        <svg data-testid="button-prepend-icon" style="width: 24px; height: 24px; fill: var(--color-icon-primary);"><path d="M15.293 3.293c0.391-0.391 1.024-0.391 1.414 0l4 4c0.391 0.391 0.391 1.024 0 1.414l-12 12c-0.188 0.188-0.442 0.293-0.707 0.293h-4c-0.552 0-1-0.448-1-1v-4c0-0.265 0.105-0.52 0.293-0.707l12-12zM5 16.414v2.586h2.586l11-11-2.586-2.586-11 11zM10 21l2-2h9v2h-11z"></path></svg>
                                    </div>
                                </div>
                            </button>
                        </div>
                    </div>
                </div>
                <?php
            }
        }else{
        ?>
        <div class="styles_btn-_mLWbq">
            <div class="styles_btn--neutralOutlined__mLWbq Button-dfs18">
                <i class="icon-delete"></i>
            </div>
            <div class=" d-flex flex-column">
                <div class="d-flex jc-between ai-start gap-14">
                    <div>
                        <label class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--L7bcQ uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--normal--A6Ntt text-body-1 color-n-700 w-100">
                            <p class="mb-2 color-n-700 text-body-1 mb-2" data-testid="form-label"> نام تب </p>
                            <div class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame__input-container--D5edN px-2 d-flex ai-center">
                                <section class="grow-1 text-body-2-c">
                                    <input class="px-2 TextField__input-_5fbdd text-subtitle w-100 TextField-e58168" type="text" id="name"></section>
                            </div>
                        </label>
                        <label class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--L7bcQ uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--normal--A6Ntt text-body-1 color-n-700 w-100">
                            <p class="mb-2 color-n-700 text-body-1 mb-2" data-testid="form-label"> نام انگلیسی تب </p>
                            <div class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame__input-container--D5edN px-2 d-flex ai-center">
                                <section class="grow-1 text-body-2-c">
                                    <input class="px-2 TextField__input-_5fbdd text-subtitle w-100 TextField-e58168" type="text" id="name_en" ></section>
                            </div>
                        </label>
                        <p class="text-subtitle-strong flex-1"></p>
                    </div>
                    <button class="relative d-flex ai-center user-select-none btn-wc51H8 text-button-2 btn--text-se4oQM btn--primary-uiqWij btn--icon-ZPHT4g radius Button__medium-gIvke_ Button__textPrimary-IWW5Sd Button__prependIcon-hh7768 IconButton__button-RRc2H_ Button-qfc65" data-testid="button-wrapper" type="button">
                        <div class="d-flex ai-center jc-center relative grow-1">
                            <div class="d-flex IconButton__prependIcon-mxVR2M p-4" data-testid="icon-wrapper">
                                <svg data-testid="button-prepend-icon" style="width: 24px; height: 24px; fill: var(--color-icon-primary);"><path d="M15.293 3.293c0.391-0.391 1.024-0.391 1.414 0l4 4c0.391 0.391 0.391 1.024 0 1.414l-12 12c-0.188 0.188-0.442 0.293-0.707 0.293h-4c-0.552 0-1-0.448-1-1v-4c0-0.265 0.105-0.52 0.293-0.707l12-12zM5 16.414v2.586h2.586l11-11-2.586-2.586-11 11zM10 21l2-2h9v2h-11z"></path></svg>
                            </div>
                        </div>
                    </button>
                </div>
            </div>
        </div>
        <?php
        }
        ?>
    </div>
    <div class="flex justify-between">
        <button type="button" class="btn !w-28 !text-5xs !text-green-dark !pt-2 !h-28 btn-white btn-icon icon-plus relative Button-qfs65"></button>
    </div>
</div>