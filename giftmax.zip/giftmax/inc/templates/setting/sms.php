<?php
$token = "wns0sWEioLyJejB0g0olFj-PVlL2Yt5O2G94prP-BXg=";

$ch = curl_init('https://edge.ippanel.com/v1/api/payment/credit/mine');

curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER => [
                'Authorization: ' . $token,
                'Content-Type: application/json',
        ],
        CURLOPT_TIMEOUT => 30,
]);

$response = curl_exec($ch);

if (curl_errno($ch)) {
    die(curl_error($ch));
}

curl_close($ch);

$data = json_decode($response, true);
if (
        !isset($data['data']['credit']) ||
        !isset($data['meta']['status']) ||
        !$data['meta']['status']
) {
    $b =  "چیزی پیدا نشد";
}else{
    $b = number_format(floor($data['data']['credit'])) .  "<small style='margin-right: 2px'> ريال</small>";
}
?>
<div class="d-flex Container-mirV2w mb-4 Container--withBorder-OdFFhL justify-between">
    <div class="ProfileLayout__tab-rvmH7A TabItem-CWkOsT TabItem__active-AZcc4O text-subtitle-strong false" data-testid="tab-wrapper" data-pw="tab-0">ارسال پیامک</div>
    <div class="bwsp"><?=$b?></div>
</div>
<div class="flex gap-3">
    <div class="w-70">
        <label class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--L7bcQ uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--normal--A6Ntt text-body-1 color-n-700 w-100">
            <p class="mb-2 color-n-700 text-body-1 mb-2" data-testid="form-label"> نام پیامک(فقط براین نمایش توی سایت هست) </p>
            <div class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame__input-container--D5edN px-2 d-flex ai-center">
                <section class="grow-1 text-body-2-c">
                    <input class="px-2 TextField__input-_5fbdd text-subtitle w-100 TextField-e58168" type="text" id="title">
                </section>
            </div>
        </label>
        <div class="ptmcs">
            <button type="button" data-variable="{username}">
                شماره تلفن
            </button>
            <button type="button" data-variable="{name}">
                نام
            </button>
            <button type="button" data-variable="{lastname}">
                نام خانوداگی
            </button>
            <button type="button" data-variable="{fullname}">
                نام و نام خانوداگی
            </button>
        </div>
        <label class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--L7bcQ uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--normal--A6Ntt text-body-1 color-n-700 w-100">
            <p class="mb-2 color-n-700 text-body-1 mb-2" data-testid="form-label"> متن پیامک </p>
            <div class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame__input-container--D5edN uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame__input-container--textArea--qCxT1 px-2 d-flex ai-center p-2 ">
                <section class="grow-1 text-body-2-c">
                    <textarea id="message" name="description" class="px-1 TextField__textarea-df80b4 text-subtitle w-100 TextField-e58168" rows="4"></textarea>
                </section>
            </div>
        </label>
    </div>
    <div class="w-30">
        <label class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--L7bcQ uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--normal--A6Ntt text-body-1 color-n-700 w-100">
            <p class="mb-2 color-n-700 text-body-1 mb-2" data-testid="form-label"> زمان دلخواه ارسال (خالی بودن مساوی با ارسال آنی)</p>
            <div class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame__input-container--D5edN px-2 d-flex ai-center">
                <section class="grow-1 text-body-2-c">
                    <input class="px-2 TextField__input-_5fbdd text-subtitle w-100 TextField-e58168" type="text" id="time" placeholder="1405-05-01 21:20:00" dir="ltr">
                </section>
            </div>
        </label>
        <div class="setting_bot_send d-flex">
            <p class="P-setting_bot_send w60">ارسال به کاربران سایت</p>
            <label for="s-user" class="input-label start w40_1">
                <span class="start-label"></span>
                <input id="s-user" type="checkbox" class="input">
                <span class="input-check"></span>
            </label>
        </div>
        <label class=" =uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--L7bcQ uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--normal--A6Ntt text-body-1 color-n-700 w-100">
            <p class="mb-2 color-n-700 text-body-1 mb-2" data-testid="form-label">وایت لیست</p>
            <div class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame__input-container--D5edN px-2 d-flex ai-center">
                <section class="grow-1 text-body-2-c">
                    <input class="px-2 TextField__input-_5fbdd text-subtitle TextField-e58168 w-100" type="text" name="listwhite" id="listwhite">
                </section>
            </div>
        </label>
        <div class="listwhite_search hidden"></div>
        <label class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--L7bcQ uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--normal--A6Ntt text-body-1 color-n-700 w-100">
            <p class="mb-2 color-n-700 text-body-1 mb-2" data-testid="form-label">بلک لیست</p>
            <div class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame__input-container--D5edN px-2 d-flex ai-center">
                <section class="grow-1 text-body-2-c">
                    <input class="px-2 TextField__input-_5fbdd text-subtitle TextField-e58168 w-100" type="text" name="listblock" id="listblock">
                </section>
            </div>
        </label>
        <div class="listblock_search hidden"></div>
    </div>
</div>
<div class="flex gap-7">
    <button type="button" class="btn btn-white Button-ts47">ارسال تست پیامک به شماره خودتون</button>
    <button type="button" class="btn btn-white Button-ssa54">ثبت</button>
</div>
<div class="d-flex Container-mirV2w mb-4 Container--withBorder-OdFFhL">
    <div class="ProfileLayout__tab-rvmH7A TabItem-CWkOsT TabItem__active-AZcc4O text-subtitle-strong false" data-testid="tab-wrapper" data-pw="tab-0">لیست مخاطبین</div>
</div>
<div class="flex gap-3">
    <div class="w-30">
        <label class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--L7bcQ uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--normal--A6Ntt text-body-1 color-n-700 w-100">
            <p class="mb-2 color-n-700 text-body-1 mb-2" data-testid="form-label"> نام لیست</p>
            <div class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame__input-container--D5edN px-2 d-flex ai-center">
                <section class="grow-1 text-body-2-c">
                    <input class="px-2 TextField__input-_5fbdd text-subtitle w-100 TextField-e58168" type="text" name="list[title]">
                </section>
            </div>
        </label>
        <button type="button" class="btn btn-white Button-sln10">ثبت</button>
    </div>
    <div class="w-70">
        <label class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--L7bcQ uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--normal--A6Ntt text-body-1 color-n-700 w-100">
            <p class="mb-2 color-n-700 text-body-1 mb-2" data-testid="form-label">شماره های لیست (هر خط یک شماره)</p>
            <div class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame__input-container--D5edN uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame__input-container--textArea--qCxT1 px-2 d-flex ai-center p-2 ">
                <section class="grow-1 text-body-2-c">
                    <textarea name="list[numbers]" class="px-1 TextField__textarea-df80b4 text-subtitle w-100 TextField-e58168" rows="4"></textarea>
                </section>
            </div>
        </label>
    </div>
</div>
<div class="col-12 mt-3">
    <div class="">
        <div class="c-bills__header">
            <div class="b-bills bills_number">ردیف</div>
            <div class="b-bills w-75">نام</div>
            <div class="b-bills purchase_date">تاریخ ایجاد</div>
            <div class="b-bills purchase_date">عملیات</div>

        </div>
        <div id="list-number">
            <?php
            global $wpdb;
            $db = \Giftmax\modules\Db::getLnstance();
            $records = $db->query("SELECT * FROM `{$wpdb->prefix}sms_lists` ORDER BY created_at DESC ");

            if (!empty($records)){
                foreach ($records as $key=>$record) {
                    ?>
                    <div class="c-bills__body">
                        <div class="b-bills bills_number">
                            <span class="c-number"><?=$key+1?></span>
                        </div>
                        <div class="b-bills w-75">
                            <div class="c-color"><?=$record['name']?></div>
                        </div>
                        <div class="b-bills purchase_date"><div class="c-color"><?=gjdate($record['created_at'],"Y-m-d H:i")?></div> </div>
                        <div class="b-bills purchase_date flex gap-3">
                            <div class="c-view Button-sln89" data-id="<?=$record['id']?>">مشاهده</div>
                            <div class="c-view Button-dl54" data-id="<?=$record['id']?>">حذف</div>
                        </div>
                    </div>
                    <?php
                }
            }else{
                ?>
                <div class="c-bills__body">
                    <div class="b-bills" style="width:100%;">
                        <div class="c-color">در حال حاضر رکورد جدیدی وجود ندارد</div>
                    </div>
                </div>
                <?php
            }
            ?>
        </div>
    </div>
</div>
<div class="d-flex Container-mirV2w mb-4 Container--withBorder-OdFFhL">
    <div class="ProfileLayout__tab-rvmH7A TabItem-CWkOsT TabItem__active-AZcc4O text-subtitle-strong false" data-testid="tab-wrapper" data-pw="tab-0">وضعیت درحال ارسال</div>
</div>
<div class="col-12 mt-3">
    <div class="">
        <div class="c-bills__header">
            <div class="b-bills bills_number">ردیف</div>
            <div class="b-bills bills_name">نام</div>
            <div class="b-bills purchase_date">نوع</div>
            <div class="b-bills purchase_date">تعداد شماره ها</div>
            <div class="b-bills purchase_date">ارسال های موفق</div>
            <div class="b-bills purchase_date">ارسال های ناموفق</div>
            <div class="b-bills purchase_date">تاریخ ارسال</div>
            <div class="b-bills purchase_date">عملیات</div>
        </div>
        <div id="list-number">
            <?php
            global $wpdb;
            $db = \Giftmax\modules\Db::getLnstance();
            $records = $db->query("SELECT * FROM `{$wpdb->prefix}sms_campaigns` WHERE `send_at` >= :send_at ORDER BY created_at DESC ",['send_at'=>date('Y-m-d H:i:s')]);

            if (!empty($records)){
                foreach ($records as $key=>$record) {
                    ?>
                    <div class="c-bills__body">
                        <div class="b-bills bills_number">
                            <span class="c-number"><?=$key+1?></span>
                        </div>
                        <div class="b-bills bills_name">
                            <div class="c-color"><?=$record['title']?></div>
                        </div>
                        <div class="b-bills purchase_date">
                            <div class="c-color"><?=$record['type']?></div>
                        </div>
                        <div class="b-bills purchase_date">
                            <div class="c-color"><?=$record['total_count']?></div>
                        </div>
                        <div class="b-bills purchase_date">
                            <div class="c-color"><?=$record['sent_count']?></div>
                        </div>
                        <div class="b-bills purchase_date">
                            <div class="c-color"><?=$record['failed_count']?></div>
                        </div>
                        <div class="b-bills purchase_date">
                            <div class="c-color"><?=gjdate($record['send_at'],"Y-m-d H:i")?></div>
                        </div>
                        <div class="b-bills purchase_date flex" style="gap: 3px">
                            <div class="c-view Button-dsc14" data-id="<?=$record['id']?>">حذف</div>
                            <div class="c-view Button-dsc56" data-id="<?=$record['id']?>">جزئیات</div>
                        </div>
                    </div>
                    <?php
                }
            }else{
                ?>
                <div class="c-bills__body">
                    <div class="b-bills" style="width:100%;">
                        <div class="c-color">در حال حاضر رکورد جدیدی وجود ندارد</div>
                    </div>
                </div>
                <?php
            }
            ?>
        </div>
    </div>
</div>
<div class="d-flex Container-mirV2w mb-4 Container--withBorder-OdFFhL">
    <div class="ProfileLayout__tab-rvmH7A TabItem-CWkOsT TabItem__active-AZcc4O text-subtitle-strong false" data-testid="tab-wrapper" data-pw="tab-0">وضعیت ارسالی ها</div>
</div>
<div class="col-12 mt-3">
    <div class="">
        <div class="c-bills__header">
            <div class="b-bills bills_number">ردیف</div>
            <div class="b-bills bills_name">نام</div>
            <div class="b-bills purchase_date">نوع</div>
            <div class="b-bills purchase_date">تعداد شماره ها</div>
            <div class="b-bills purchase_date">ارسال های موفق</div>
            <div class="b-bills purchase_date">ارسال های ناموفق</div>
            <div class="b-bills purchase_date">تاریخ ارسال</div>
            <div class="b-bills purchase_date">عملیات</div>
        </div>
        <div id="list-number">
            <?php
            global $wpdb;
            $db = \Giftmax\modules\Db::getLnstance();
            $records = $db->query("SELECT * FROM `{$wpdb->prefix}sms_campaigns` WHERE `send_at` < :send_at ORDER BY created_at DESC ",['send_at'=>date('Y-m-d H:i:s')]);

            if (!empty($records)){
                foreach ($records as $key=>$record) {
                    ?>
                    <div class="c-bills__body">
                        <div class="b-bills bills_number">
                            <span class="c-number"><?=$key+1?></span>
                        </div>
                        <div class="b-bills bills_name">
                            <div class="c-color"><?=$record['title']?></div>
                        </div>
                        <div class="b-bills purchase_date">
                            <div class="c-color"><?=$record['type']?></div>
                        </div>
                        <div class="b-bills purchase_date">
                            <div class="c-color"><?=$record['total_count']?></div>
                        </div>
                        <div class="b-bills purchase_date">
                            <div class="c-color"><?=$record['sent_count']?></div>
                        </div>
                        <div class="b-bills purchase_date">
                            <div class="c-color"><?=$record['failed_count']?></div>
                        </div>
                        <div class="b-bills purchase_date">
                            <div class="c-color"><?=gjdate($record['send_at'],"Y-m-d H:i")?></div>
                        </div>
                        <div class="b-bills purchase_date flex" style="gap: 3px">
                            <div class="c-view Button-dsc14" data-id="<?=$record['id']?>">حذف</div>
                            <div class="c-view Button-dsc56" data-id="<?=$record['id']?>">جزئیات</div>
                        </div>
                    </div>
                    <?php
                }
            }else{
                ?>
                <div class="c-bills__body">
                    <div class="b-bills" style="width:100%;">
                        <div class="c-color">در حال حاضر رکورد جدیدی وجود ندارد</div>
                    </div>
                </div>
                <?php
            }
            ?>
        </div>
    </div>
</div>
<div class="ReactModalPortal pup" style="opacity: 0; visibility: hidden;"></div>
<div class="ar-modal" style="opacity: 0; visibility: hidden;">
    <div class="ar-modal__container">
        <div class="ar-modal__box invoice-usages__usageModal">
            <div class="ar-modal__close">
                ×
            </div>
            <div class="ar-modal__head">
                <div class="ar-modal__title">
                    <div id="name_pup" class="flex align-items-center">جزئیات پیام ارسالی</div>
                </div>
            </div>
            <div class="ar-modal__content">
                <div role="status" class="text-primary-500 margin-same-2 ar-spinner ar-spinner--border ar-spinner--primary"><svg viewBox="25 25 50 50"><circle cx="50" cy="50" r="20"></circle></svg></div>
            </div>
        </div>
    </div>
</div>

<script>
    jQuery(function ($) {
        $("#time").persianDatepicker({
            formatDate: "YYYY-0M-0D hh:mm",
            showGregorianDate: 0,
            timePicker: true
        });
    });
</script>
