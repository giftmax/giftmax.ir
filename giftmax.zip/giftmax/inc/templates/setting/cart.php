<?php
if ($records){
    foreach ($records as $record){
    $cardNumber = rtrim(
        chunk_split(decrypt_data($record['card_number_enc']), 4, '-'),
        '-'
    );
    $user  = get_userdata($record['user_id']);
    ?>
    <div class="InvoiceCustomerInfo">
        <div class="InvoiceCustomerInfo__item">
            <span class="InvoiceCustomerInfo__label">شماره کارت</span>
            <span class="InvoiceCustomerInfo__value"><?=$cardNumber?></span>

        </div>
        <div class="InvoiceCustomerInfo__divider InvoiceCustomerInfo__divider--v"></div>
        <div class="InvoiceCustomerInfo__item">
            <span class="InvoiceCustomerInfo__label">IP ثبت شده</span>
            <span class="InvoiceCustomerInfo__value"><span><?=decrypt_data($record['ip'])?></span></span>
        </div>
        <div class="InvoiceCustomerInfo__divider InvoiceCustomerInfo__divider--h"></div>
        <div class="InvoiceCustomerInfo__item">
            <span class="InvoiceCustomerInfo__label">تاریخ ثبت</span>
            <span class="InvoiceCustomerInfo__value"><span><?=gjdate($record['created_at'],"d M Y , H:i")?></span>
                </span>
        </div>
        <div class="InvoiceCustomerInfo__divider InvoiceCustomerInfo__divider--v"></div>
        <div class="InvoiceCustomerInfo__item">
            <span class="InvoiceCustomerInfo__label">کارت بانکی متعلق به همین حساب کاربری هست؟</span>
            <span class="InvoiceCustomerInfo__value"><span><?=!empty($record['phone']) ? "خیر" : 'بله'?></span>
        </div>
        <div class="InvoiceCustomerInfo__divider InvoiceCustomerInfo__divider--h"></div>
        <?php
        if (!empty($record['phone'])){
        ?>
        <div class="InvoiceCustomerInfo__item">
            <span class="InvoiceCustomerInfo__label">شماره تلفن</span>
            <span class="InvoiceCustomerInfo__value"><span><?=decrypt_data($record['phone'])?></span></span>
        </div>
            <div class="InvoiceCustomerInfo__divider InvoiceCustomerInfo__divider--v"></div>

        <div class="InvoiceCustomerInfo__item">
            <span class="InvoiceCustomerInfo__label">کدملی</span>
            <span class="InvoiceCustomerInfo__value"><span><?=decrypt_data($record['national_code'])?></span></span>
        </div>
            <div class="InvoiceCustomerInfo__divider InvoiceCustomerInfo__divider--v"></div>
        <div class="InvoiceCustomerInfo__item">
            <span class="InvoiceCustomerInfo__label">تاریخ تولد</span>
            <span class="InvoiceCustomerInfo__value"><span><?=decrypt_data($record['birth_date'])?></span></span>
        </div>
            <div class="InvoiceCustomerInfo__divider InvoiceCustomerInfo__divider--h"></div>
            <div class="InvoiceCustomerInfo__item">
                <span class="InvoiceCustomerInfo__label">نام و نام خانوادگی</span>
                <span class="InvoiceCustomerInfo__value"><span><?=$record['first_name'] . " " . $record['last_name']?></span></span>
            </div>
            <div class="InvoiceCustomerInfo__divider InvoiceCustomerInfo__divider--v"></div>
            <?php
        }
            ?>
        <div class="InvoiceCustomerInfo__item">
            <span class="InvoiceCustomerInfo__label">حسابی که کارت را ثبت کرده</span>
            <span class="InvoiceCustomerInfo__value"><button class="Button-iu64" data-number="<?=$user->user_login?>">مشاهده</button></span>
        </div>
    </div>
<?php }
}else{?>
    <div class="flex justify-center">کارت پیدا نشد</div>

<?php }