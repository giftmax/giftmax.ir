<?php
if ( ! defined( 'ABSPATH' ) ) exit; // ایمنی

$tabs = [
    'home'       => ( 'صفحه اصلی' ),
    'identity-verification' => ( 'احراز هویت و ثبت نام' ),
    'buy'   => ( 'خرید' ),
    'contact-us'   => ( 'تماس با ما' ),
    'data-contact'   => ( 'اطلاعات فرم تماس' ),
    'post'   => ( 'نوشته ها' ),
    'send-notifications'   => ( 'ارسال نوتیفیکیشن' ),
    'sms'   => ( 'پیامک' ),
    'quick-fast'   => ( 'خرید سریع' ),
    'notifications'   => ( 'هدر بنری' ),
    'faq'   => ( 'سوالات متداول' ),
    'admin'   => ( 'مدریت لایسنس و کاربران و کیف پول' )
];
?>
<main class="Container-ir55aD Container__desktop-PdSst_">
    <div class="d-grid gap-4 grid-cols-4 mt-6">
        <div class="col-span-1">
            <div class="bg-light radius-md mb-4 bg-light radius-md" id="profile-app-menu">
                <?php foreach ( $tabs as $slug => $label ) : ?>
                    <a href="<?php echo esc_url( add_query_arg( [ 'page' => 'theme-settings', 'tab' => $slug ] ) ); ?>">
                        <div class="px-4 color-n-700 <?php echo ( $current_tab === $slug ) ? 'ProfileMenuRow--active-D6Bb8E' : ''; ?>">
                            <div class="w-100  d-flex ai-center jc-start  py-3">
                                <p class="text-subtitle-strong mr-2"><?=esc_html( $label );?></p>
                            </div>
                            <div class="border-b w-100"></div>
                        </div>
                    </a>
                <?php endforeach; ?>
            </div>
        </div>
        <div class="col-span-3">
            <div class="bg-light radius-md px-8 py-6 ">
                <?php
                include get_template_directory() . '/inc/templates/setting/'. $current_tab . '.php';
                ?>
            </div>
        </div>
    </div>
</main>
<div id="popper-root">
    <div class="absolute">
        <div id="snackbar-container" class="pos-fixed d-flex flex-column my-3 px-4 jc-center Snackbar__container-_86cf8 bottom-0 left-1/2 -translate-x-1/2 z-1000" style="left: 50%; transform: translateX(-50%); width: 320px;z-index: 9999999;"></div>
    </div>
</div>