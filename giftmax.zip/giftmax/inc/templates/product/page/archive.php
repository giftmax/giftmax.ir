<?php
$current_cat = get_queried_object();
$term_id     = 0;
$term_type   = '';

$queried   = get_queried_object();
if ( $queried && property_exists( $queried, 'term_id' ) ) {
    $term_id  = $queried->term_id;
    $taxonomy = $queried->taxonomy;
}
$region_args = [
    'post_type'      => 'product',
    'posts_per_page' => -1,
    'fields'         => 'ids',
    'meta_query' => [
        [
            'key'     => 'giftmax_box_setting',
            'compare' => 'EXISTS'
        ]
    ]
];
if ( $term_id && in_array( $taxonomy, array( 'product_cat', 'product_tag' ), true ) ) {
    $args['tax_query'] = array(
        array(
            'taxonomy' => $taxonomy,
            'field'    => 'term_id',
            'terms'    => $term_id,
        ),
    );
    $region_args['tax_query'] = array(
        array(
            'taxonomy' => $taxonomy,
            'field'    => 'term_id',
            'terms'    => $term_id,
        ),
    );
}
$region_query = new WP_Query($region_args);

$regions = [];

foreach ($region_query->posts as $pid) {
    $settings = get_post_meta($pid, 'giftmax_box_setting', true);
    if (!empty($settings[0]['logo_region'])) {
        $regions[] = $settings[0]['logo_region'];
    }
}

$regions = array_unique($regions);
wp_reset_postdata();

?>
<main id="archive">
    <section class="container-2xl-w mx-auto mt-32 nav__box">
        <nav class="rad-breadcrumb rad-woo-bread">
            <a class="kp-pl" href="<?=home_url()?>">  صفحه اصلی  </a>
            <span class="sep">
                <svg xmlns="http://www.w3.org/2000/svg" width="1" height="24" viewBox="0 0 1 24" stroke="currentcolor">
                    <line x1="0.5" y1="2.18557e-08" x2="0.499999" y2="24"></line>
                </svg>
            </span>
            <span class="kp-pn" id="main_id" data-id="<?=$term_id?>"><?=$current_cat->name?></span>
        </nav>
    </section>
    <?php
    $args = [
        'post_type'      => 'product',
        'posts_per_page' => -1,
        'meta_query'     => [
            'relation' => 'AND',

            [
                'key'     => '_sale_price',
                'value'   => 0,
                'compare' => '>',
                'type'    => 'NUMERIC',
            ]
        ],
    ];

    $query = new \WP_Query($args);
    if ($query->have_posts()) {
        ?>
        <section class="container-xl-w mx-auto mt-18">
            <div class="act-new-service-carousel-1st" id="LoadCategory">
                <div class="act-new-service-carousel-head d-flex align-items-center justify-content-between">
                    <svg xmlns="http://www.w3.org/2000/svg" width="1281" height="75" viewBox="0 0 1281 75" fill="none" class="act-new-service-carousel-head-svg">
                        <path d="M1280.47 0.5H1000.91C986.771 0.5 979.703 0.5 973.764 2.99163C969.027 4.9789 964.838 8.07733 961.551 12.025C957.43 16.9747 955.361 23.7331 951.224 37.25C947.086 50.7669 945.017 57.5253 940.896 62.475C937.609 66.4227 933.42 69.5211 928.683 71.5084C922.744 74 915.676 74 901.54 74H412.882C399.847 74 393.329 74 387.813 71.8926C382.12 69.7177 377.167 65.9625 373.536 61.0686C370.017 56.3267 368.257 50.0512 364.737 37.5C361.217 24.9488 359.457 18.6733 355.938 13.9314C352.307 9.0375 347.353 5.2823 341.661 3.10737C336.145 1 329.627 1 316.592 1H0" stroke="url(#paint0_linear_29_20094)"></path>
                        <defs>
                            <linearGradient id="paint0_linear_29_20094" x1="29.4736" y1="0.500002" x2="1213.79" y2="-28.0511" gradientUnits="userSpaceOnUse">
                                <stop stop-color="#0B61FF" stop-opacity="0"></stop>
                                <stop offset="0.5" stop-color="#0B61FF"></stop>
                                <stop offset="1" stop-color="#0B61FF" stop-opacity="0"></stop>
                            </linearGradient>
                        </defs>
                    </svg>
                    <div class="act-our-services-carousel-head-title">
                        <div class="act-our-services-carousel-head-title-divs">
                            <div class="act-our-services-carousel-head-title-div1"></div>
                            <div class="act-our-services-carousel-head-title-div2"></div>
                        </div>
                        <div class="act-our-services-carousel-head-title-content">
                            <h5>
                            </h5><h5>از تخفیف <strong>جا نمونی</strong></h5>
                            <p>NO DISCOUNT</p>
                        </div>
                    </div>
                    <div class="act-new-service-carousel-head-content">

                        <div class="act-new-service-carousel-buttons">
                            <div class="act-percent-but-r act-percent-but act-carousel-but" tabindex="0" role="button" aria-label="Previous slide" aria-controls="swiper-wrapper-5a458f817b4750df" aria-disabled="false">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="currentcolor">
                                    <path d="M14.4301 18.8201C14.2401 18.8201 14.0501 18.7501 13.9001 18.6001C13.6101 18.3101 13.6101 17.8301 13.9001 17.5401L19.4401 12.0001L13.9001 6.46012C13.6101 6.17012 13.6101 5.69012 13.9001 5.40012C14.1901 5.11012 14.6701 5.11012 14.9601 5.40012L21.0301 11.4701C21.3201 11.7601 21.3201 12.2401 21.0301 12.5301L14.9601 18.6001C14.8101 18.7501 14.6201 18.8201 14.4301 18.8201Z"></path>
                                    <path d="M20.33 12.75H3.5C3.09 12.75 2.75 12.41 2.75 12C2.75 11.59 3.09 11.25 3.5 11.25L20.33 11.25C20.74 11.25 21.08 11.59 21.08 12C21.08 12.41 20.74 12.75 20.33 12.75Z"></path>
                                </svg>
                            </div>
                            <div class="act-percent-but-l act-percent-but act-carousel-but swiper-button-disabled" tabindex="-1" role="button" aria-label="Next slide" aria-controls="swiper-wrapper-5a458f817b4750df" aria-disabled="true">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="currentcolor">
                                    <path d="M9.56988 5.17988C9.75988 5.17988 9.94988 5.24988 10.0999 5.39988C10.3899 5.68988 10.3899 6.16988 10.0999 6.45988L4.55988 11.9999L10.0999 17.5399C10.3899 17.8299 10.3899 18.3099 10.0999 18.5999C9.80988 18.8899 9.32988 18.8899 9.03988 18.5999L2.96988 12.5299C2.67988 12.2399 2.67988 11.7599 2.96988 11.4699L9.03988 5.39988C9.18988 5.24988 9.37988 5.17988 9.56988 5.17988Z"></path>
                                    <path d="M3.67 11.25H20.5C20.91 11.25 21.25 11.59 21.25 12C21.25 12.41 20.91 12.75 20.5 12.75L3.67 12.75C3.26 12.75 2.92 12.41 2.92 12C2.92 11.59 3.26 11.25 3.67 11.25Z"></path>
                                </svg>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="swiper percent-box-swiper">
                    <div class="swiper-wrapper" >
                        <?php while ($query->have_posts()): $query->the_post();
                            $product = wc_get_product(get_the_ID());
                            $delivery = get_post_meta($product->get_id(), 'delivery', true);
                            $pa =  ((isset($delivery['two']) && $delivery['two'] == 'on') || product_available($product->get_id()));
                            if (!$pa){
                                continue;
                            }
                            $regular = $product->get_regular_price();
                            $sale    = $product->get_sale_price();

                            $discount = round((($regular - $sale) / $regular) * 100);
                            $img = get_the_post_thumbnail_url(get_the_ID(), 'product_discount');
                            $title = get_the_title();
                            $settings = get_post_meta(get_the_ID(), 'giftmax_box_setting', true);
                            $date_from = $product->get_date_on_sale_from();
                            $date_to   = $product->get_date_on_sale_to();
                            if ($product->is_on_sale() && ($date_from || $date_to)) {
                                $sale_to = $product->get_date_on_sale_to();
                                $sale_to_ts = $sale_to ? $sale_to->getTimestamp() : null;
                            }else{
                                $sale_to_ts = null;
                            }
                            $tooltip = isset($delivery['description']) ? $delivery['description'] : '';
                            ?>
                            <div class="swiper-slide">
                                <div class="act-percent-card">
                                    <div class="flex flex-col">
                                        <div class="relative">
                                            <div class="act-new-service-card-inner-top">
                                                <a href="<?=get_permalink()?>">
                                                    <div class="flex dj45fd">
                                                        <?php
                                                        $tooltip = isset($delivery['description']) ? $delivery['description'] : '';
                                                        ?>
                                                        <div class="act-product-option-box__nw <?=isset($delivery['two']) && $delivery['two'] == 'on' ? 'pre-sale wiki wiki__holder js-dk-wiki-trigger' : 'same-day'?>" <?=isset($delivery['two']) && $delivery['two'] == 'on' ? 'data-tooltip="'. $tooltip .'"' :''?>><?=isset($delivery['two']) && $delivery['two'] == 'on' ? 'پیش فروش' : 'تحویل آنی'?></div>
                                                        <div class="purchaseScore wiki wiki__holder js-dk-wiki-trigger" data-tooltip="با خرید این گیفت کارت <?=empty($settings[0]['purchaseScore']) ?0: $settings[0]['purchaseScore']?> امتیاز دریافت میکنید">
                                                            <i class="icon-star"></i>
                                                            <?=empty($settings[0]['purchaseScore']) ?0: $settings[0]['purchaseScore']?>
                                                        </div>
                                                        <?php
                                                        if (!empty($settings[0]['label']) && $settings[0]['label'] != ''){?>
                                                            <div class="label-fjd84">
                                                                <img src="<?=empty($settings[0]['label']) ?'': $settings[0]['label']?>" class="logo_label">
                                                                <p class="label_title"><?=empty($settings[0]['label_title']) ?'': $settings[0]['label_title']?></p>
                                                            </div>
                                                            <?php
                                                        }
                                                        ?>
                                                    </div>
                                                    <div class="act-new-service-card-inner-top-img-box relative aib36">
                                                        <img loading="lazy" decoding="async" width="32" height="33" src="<?=$img?>" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="">
                                                    </div>
                                                </a>
                                            </div>
                                            <?php
                                            if (!empty($settings[0]['logo_region'])){
                                                ?>
                                                <div class="logo_region">
                                                    <img src="<?=empty($settings[0]['logo_region']) ?: get_template_directory_uri() . '/assets/flag/' . $settings[0]['logo_region'] . '.svg'?>">
                                                </div>
                                                <?php
                                            }
                                            ?>
                                            <div class="act-product-price-off-percent">  <?=get_discount_percent($product)?> ٪       </div>
                                        </div>
                                        <div class="act-bar-left">
                                            <div class="flex justify-between">
                                                <a class="lg:w-80" href="<?=get_permalink()?>">
                                                    <h4 class="ellipsis"><?=get_the_title()?></h4>
                                                </a>                                                <?php
                                                $giftmax_is_user_logged_in = is_user_logged_in();
                                                $giftmax_wishlist_ids = $giftmax_is_user_logged_in ? giftmax_get_user_wishlist_product_ids() : [];
                                                if ($giftmax_is_user_logged_in){
                                                    $is_in_wishlist = in_array((int) $product->get_id(), $giftmax_wishlist_ids, true); ?>
                                                    <button class="add-to__favorites Button-alu84 <?=$is_in_wishlist ? 'is-active' : ''?>" data-product-id="<?=esc_attr($product->get_id())?>" style="width: 28px;height: 28px;border-radius: 7px">
                                                        <svg viewBox="0 0 24 24" style="width: 64%;">
                                                            <path d="M12.62 20.81C12.28 20.93 11.72 20.93 11.38 20.81C8.48 19.82 2 15.69 2 8.68998C2 5.59998 4.49 3.09998 7.56 3.09998C9.38 3.09998 10.99 3.97998 12 5.33998C13.01 3.97998 14.63 3.09998 16.44 3.09998C19.51 3.09998 22 5.59998 22 8.68998C22 15.69 15.52 19.82 12.62 20.81Z" fill="<?=$is_in_wishlist ? '#ef4444' : 'none'?>" stroke="<?=$is_in_wishlist ? '#ef4444' : 'inherit'?>" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                                                        </svg>
                                                    </button>
                                                    <?php
                                                }
                                                ?>
                                            </div>
                                            <?php
                                            if(!empty($settings[0]['sub_head']) && !isMobile()) echo "<p class='act-product-title-en mb-1'>" . $settings[0]['sub_head'] . "</p>";
                                            ?>
                                            <div class="flex justify-between mb-1 kef4e">
                                                <?php
                                                if (!is_null($sale_to_ts)){
                                                    ?>
                                                    <img class="inline-block lg:w-40" src="<?=get_template_directory_uri()?>/assets/img/svg/IncredibleOffer.svg" alt="" title="" style="object-fit: contain;">
                                                    <div class="text-primary-700 text-body2-strong" style="display:block;"><i class="icon-clock mr-1"></i><span class="style_ProductPromotionTimeline__timer__zS6ZA"><?= date('Y-m-d H:i:s', $sale_to_ts); ?></span></div>

                                                    <?php
                                                }else{ ?>
                                                    <img class="inline-block lg:w-40" src="<?=get_template_directory_uri()?>/assets/img/svg/Offer.svg" alt="" title="" style="object-fit: contain;">

                                                    <?php
                                                }
                                                ?>
                                            </div>

                                            <div class="flex justify-between w-full">
                                                <?php
                                                if (\Giftmax\Modules\UserModel::setting("buy") === true){

                                                    if (isset($delivery['two']) && $delivery['two'] == 'on' || product_available($product->get_id())){
                                                        if (\Giftmax\Modules\UserModel::setting("buy") === true) {
                                                            ?>
                                                            <button data-product-id="<?=$product->get_id()?>" class="act-percent-card-buy-box-but Button-aca49 pointer" type="button">
                                                                افزودن به سبد خرید
                                                            </button>
                                                            <?php
                                                        }else{
                                                            echo "<div></div>";
                                                        }
                                                    }else{
                                                        echo '<div class="inaJSDge8" style="height: 30px">ناموجود</div>';
                                                    }
                                                }else{
                                                    echo "<div></div>";
                                                }?>
                                                <div class="act-product-price-box">
                                                    <div class="act-product-price bpt">
                                                        <div id="priceValue" data-id="<?=$product->get_id()?>" data-target="<?=payment_usd($product->is_on_sale() ? $sale :$regular)?>"><?=number_format_usd($sale)?></div>
                                                        <span>تومان</span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endwhile; ?>
                    </div>
                    <span class="swiper-notification" aria-live="assertive" aria-atomic="true"></span>
                </div>
            </div>
        </section>
        <?php
    }
    $db = \Giftmax\Modules\Db::getLnstance();
    global $wpdb;

    $records = $db->first("SELECT meta_value FROM `{$wpdb->prefix}setting` WHERE `meta_key` = :key", ['key' => 'tab']);
    if (!empty($records) && !empty($records['meta_value'])){
    ?>
    <section class="container-xl-w mx-auto mt-32">
        <div class="act-new-service-carousel-1st">
            <div class="act-new-service-carousel-head d-flex align-items-center justify-content-between">
                <svg xmlns="http://www.w3.org/2000/svg" width="1281" height="75" viewBox="0 0 1281 75" fill="none" class="act-new-service-carousel-head-svg">
                    <path d="M1280.47 0.5H1000.91C986.771 0.5 979.703 0.5 973.764 2.99163C969.027 4.9789 964.838 8.07733 961.551 12.025C957.43 16.9747 955.361 23.7331 951.224 37.25C947.086 50.7669 945.017 57.5253 940.896 62.475C937.609 66.4227 933.42 69.5211 928.683 71.5084C922.744 74 915.676 74 901.54 74H412.882C399.847 74 393.329 74 387.813 71.8926C382.12 69.7177 377.167 65.9625 373.536 61.0686C370.017 56.3267 368.257 50.0512 364.737 37.5C361.217 24.9488 359.457 18.6733 355.938 13.9314C352.307 9.0375 347.353 5.2823 341.661 3.10737C336.145 1 329.627 1 316.592 1H0" stroke="url(#paint0_linear_29_20094)"></path>
                    <defs>
                        <linearGradient id="paint0_linear_29_20094" x1="29.4736" y1="0.500002" x2="1213.79" y2="-28.0511" gradientUnits="userSpaceOnUse">
                            <stop stop-color="#0B61FF" stop-opacity="0"></stop>
                            <stop offset="0.5" stop-color="#0B61FF"></stop>
                            <stop offset="1" stop-color="#0B61FF" stop-opacity="0"></stop>
                        </linearGradient>
                    </defs>
                </svg>
                <div class="act-our-services-carousel-head-title">
                    <div class="act-our-services-carousel-head-title-divs">
                        <div class="act-our-services-carousel-head-title-div1"></div>
                        <div class="act-our-services-carousel-head-title-div2"></div>
                    </div>
                    <div class="act-our-services-carousel-head-title-content">
                        <h5>خرید <strong>سریع</strong> </h5>
                        <p>QUICK PURCHASE</p>
                    </div>
                </div>
            </div>
            <?php
            $tabs = [];

            if (!empty($records) && !empty($records['meta_value'])) {

                $array = json_decode($records['meta_value'], true);

                if (!empty($array)) {

                    foreach ($array as $tab_key => $item) {

                        $tabs[$tab_key] = [
                            'name'  => $item['name'],
                            'ids'   => !empty($item['value']) ? explode(',', $item['value']) : []
                        ];
                    }
                }
            }
            ?>
            <div class="card-settings">
                <div class="card-settings__tabs">
                    <?php
                    $first = true;

                    foreach ($tabs as $key => $item): ?>
                        <button
                                class="card-settings__tab <?= $first ? 'card-settings__tab--active' : '' ?>"
                                data-tab="<?= esc_attr($key) ?>">
                            <?= esc_html($item['name']) ?>
                        </button>
                        <?php
                        $first = false;
                    endforeach;
                    ?>
                </div>
                <div class="card-settings__loading">
                    <span class="card-settings__spinner"></span>
                    <span>در حال بارگذاری...</span>
                </div>
                <div class="card-settings__panel">
                    <div class="flex">
                        <div class="card-settings__content">
                            <div class="card-settings__field card-settings__field--wide">
                                <label>نوع کارت</label>
                                <div>
                                    <select class="js-example-basic-single select2-hidden-accessible" name="cardType" id="cardType"></select>
                                </div>
                            </div>
                            <div class="card-settings__field">
                                <label>ریجن کارت</label>
                                <div>
                                    <select class="js-example-basic-single select2-hidden-accessible" id="cardRegion"></select>
                                </div>
                            </div>
                            <div class="card-settings__field">
                                <label>میزان اعتبار</label>
                                <div>
                                    <select class="js-example-basic-single select2-hidden-accessible" id="cardAmount"></select>
                                </div>
                            </div>
                        </div>

                        <div id="finalPrice">
                            <label>قیمت محصول</label>
                            <strong>-</strong>
                        </div>
                    </div>
                    <div class="card-settings__actions" id="card-settings__actions">
                    </div>
                </div>
            </div>
            <?php
            $products_data = [];

            foreach ($tabs as $t_key => $tab) {

                $products = wc_get_products([
                        'status' => 'publish',
                        'limit'  => -1,

                        'tax_query' => [
                                [
                                        'taxonomy' => 'product_cat',
                                        'field'    => 'term_id',
                                        'terms'    => $tab['ids'],
                                ]
                        ],
                        'meta_query' => [
                                'relation' => 'OR',

                                [
                                        'key'     => 'giftmax_setting_order',
                                        'compare' => 'EXISTS',
                                        'type'    => 'NUMERIC',
                                ],

                                [
                                        'key'     => 'giftmax_setting_order',
                                        'compare' => 'NOT EXISTS',
                                ],
                        ],

                        'orderby' => [
                                'meta_value_num' => 'ASC',
                                'date'           => 'DESC',
                        ],

                        'order' => 'ASC',
                ]);


                foreach ($products as $product) {

                    $delivery = get_post_meta($product->get_id(), 'delivery', true);
                    $is_presale = isset($delivery['two']) && $delivery['two'] == 'on';

                    if (!$is_presale && function_exists('product_available') && !product_available($product->get_id())) {
                        continue;
                    }

                    $pid = $product->get_id();

                    $cats = wp_get_post_terms($pid, 'product_cat');

                    $settings = get_post_meta($pid, 'giftmax_box_setting', true);
                    if (empty($settings[0]['logo_region'])) {
                        continue;
                    }

                    $region = $settings[0]['logo_region'];

                    foreach ($cats as $cat) {

                        if (!in_array($cat->term_id, $tab['ids'])) {
                            continue;
                        }

                        $category_key = sanitize_title($cat->name);

                        $products_data[$t_key][$category_key]['label'] = $cat->name;
                        $products_data[$t_key][$category_key]['regions_meta'][$region] = regionPersian($region);

                        $products_data[$t_key][$category_key]['regions'][$region][] = [
                                'id'    => $pid,
                                'title' => $product->get_name(),
                                'price' => number_format_usd($product->get_price()),
                        ];
                    }
                }
            }
            ?>
            <script>
                window.PRODUCTS = <?= json_encode($products_data, JSON_UNESCAPED_UNICODE); ?>;
            </script>
        </div>

    </section>

    <?php
    }
    ?>
    <section class="container-2xl-w mx-auto mt-32">
        <div class="act-new-service-carousel-1st" style="gap: 13px">
            <div class="act-new-service-carousel-head d-flex align-items-center justify-content-between">
                <svg xmlns="http://www.w3.org/2000/svg" width="1281" height="75" viewBox="0 0 1281 75" fill="none" class="act-new-service-carousel-head-svg">
                    <path d="M1280.47 0.5H1000.91C986.771 0.5 979.703 0.5 973.764 2.99163C969.027 4.9789 964.838 8.07733 961.551 12.025C957.43 16.9747 955.361 23.7331 951.224 37.25C947.086 50.7669 945.017 57.5253 940.896 62.475C937.609 66.4227 933.42 69.5211 928.683 71.5084C922.744 74 915.676 74 901.54 74H412.882C399.847 74 393.329 74 387.813 71.8926C382.12 69.7177 377.167 65.9625 373.536 61.0686C370.017 56.3267 368.257 50.0512 364.737 37.5C361.217 24.9488 359.457 18.6733 355.938 13.9314C352.307 9.0375 347.353 5.2823 341.661 3.10737C336.145 1 329.627 1 316.592 1H0" stroke="url(#paint0_linear_29_20094)"></path>
                    <defs>
                        <linearGradient id="paint0_linear_29_20094" x1="29.4736" y1="0.500002" x2="1213.79" y2="-28.0511" gradientUnits="userSpaceOnUse">
                            <stop stop-color="#0B61FF" stop-opacity="0"></stop>
                            <stop offset="0.5" stop-color="#0B61FF"></stop>
                            <stop offset="1" stop-color="#0B61FF" stop-opacity="0"></stop>
                        </linearGradient>
                    </defs>
                </svg>
                <div class="act-our-services-carousel-head-title">
                    <div class="act-our-services-carousel-head-title-divs">
                        <div class="act-our-services-carousel-head-title-div1"></div>
                        <div class="act-our-services-carousel-head-title-div2"></div>
                    </div>
                    <div class="act-our-services-carousel-head-title-content">
                        <h5> <strong>محصولات</strong> </h5>
                        <p>PRODUCTS</p>
                    </div>
                </div>
            </div>
            <div class="w-full">
                <div class="flex overflow-hidden mb-20">
                    <div class="flex justify-between lg:w-23 md:w-11">
                        <div class="act-our-services-carousel-head-title">
                            <div class="act-our-services-carousel-head-title-divs">
                                <div class="act-our-services-carousel-head-title-div1 tsc54b"></div>
                            </div>
                            <div class="act-our-services-carousel-head-title-content">
                                <h5>انتخاب <strong>کشور</strong> </h5>
                                <p class="tsc54">SELECT REGION</p>
                            </div>
                        </div>
                    </div>
                    <div class="swiper c-box__ceWU4d" data-cat="<?=$term_id?>">
                        <div class="swiper-wrapper">
                            <?php
                            foreach ($regions as $region){
                                ?>
                                <div data-id="<?=$region?>" class="act-catagory-card swiper-slide pointer button-ac85">
                                    <div class="act-catagory-card-inner">
                                        <div class="act-catagory-card-name">
                                            <div class="act-our-services-carousel-head-title-divs">
                                                <div class="act-our-services-carousel-head-title-div1" style="height: 15px;  margin-bottom: 4px;"></div>
                                                <div class="act-our-services-carousel-head-title-div2" style=" height: 12px;"></div>
                                            </div>
                                            <div class="act-catagory-name-text">
                                                <strong><?=regionPersian($region) ?></strong>
                                                <p><?=$region?></p>
                                            </div>
                                        </div>
                                        <div class="act-catagory-card-img">
                                            <img src="<?=get_template_directory_uri() . '/assets/flag/' .$region . '.svg'?>">
                                        </div>
                                    </div>
                                </div>
                                <?php
                            }
                            ?>
                        </div>
                        <div class="swiper-navigation-region w-full absolute">
                            <div class="swiper-button-region swiper-button-prev-region">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                                    <path d="M13.583 12l-4.293 4.293 1.414 1.414 5-5c0.39-0.391 0.39-1.024 0-1.414l-5-5-1.414 1.414 4.293 4.293z"></path>
                                </svg>
                            </div>
                            <div class="swiper-button-region swiper-button-next-region">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                                    <path d="M10.414 12l4.293 4.293-1.414 1.414-5-5c-0.391-0.391-0.391-1.024 0-1.414l5-5 1.414 1.414-4.293 4.293z"></path>
                                </svg>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="flex box_control">
            <div class="msjduf">
            <button class="act-filter-but">فیلتر ها</button>
            <div class="act-filter-box-1st">
                <svg xmlns="http://www.w3.org/2000/svg" fill="rgb(255, 255, 255)" viewBox="0 0 307.1503759398496 146.304" width="100%" height="146.304" class="act-filter-box-1st-bg">
                    <mask fill="white" id="path-1-inside-1_2005_10357">
                        <path d="M306 77C306 63.7452 295.255 53 282 53H209.738C202.332 53 195.341 49.5807 190.794 43.7347L163.984 9.26532C159.437 3.41931 152.446 0 145.039 0H24C10.7452 0 0 10.7452 0 24V552C0 565.255 10.7452 576 24 576H282C295.255 576 306 565.255 306 552V77Z"></path>
                    </mask>
                    <path d="M306 77C306 63.7452 295.255 53 282 53H209.738C202.332 53 195.341 49.5807 190.794 43.7347L163.984 9.26532C159.437 3.41931 152.446 0 145.039 0H24C10.7452 0 0 10.7452 0 24V552C0 565.255 10.7452 576 24 576H282C295.255 576 306 565.255 306 552V77Z"></path>
                    <path mask="url(#path-1-inside-1_2005_10357)" fill="rgba(11, 21, 48, 0.06)" class="act-filter-box-1st-bg-border" d="M163.984 9.26532L164.773 8.65138L163.984 9.26532ZM190.794 43.7347L190.004 44.3486L190.794 43.7347ZM282 53V54H209.738V53V52H282V53ZM190.794 43.7347L190.004 44.3486L163.194 9.87927L163.984 9.26532L164.773 8.65138L191.583 43.1207L190.794 43.7347ZM145.039 0V1H24V0V-1H145.039V0ZM0 24H1V552H0H-1V24H0ZM24 576V575H282V576V577H24V576ZM306 552H305V77H306H307V552H306ZM282 576V575C294.703 575 305 564.703 305 552H306H307C307 565.807 295.807 577 282 577V576ZM0 552H1C1 564.703 11.2975 575 24 575V576V577C10.1929 577 -1 565.807 -1 552H0ZM24 0V1C11.2974 1 1 11.2975 1 24H0H-1C-1 10.1929 10.1929 -1 24 -1V0ZM163.984 9.26532L163.194 9.87927C158.837 4.27683 152.137 1 145.039 1V0V-1C152.754 -1 160.037 2.56178 164.773 8.65138L163.984 9.26532ZM209.738 53V54C202.023 54 194.741 50.4382 190.004 44.3486L190.794 43.7347L191.583 43.1207C195.94 48.7232 202.64 52 209.738 52V53ZM282 53V52C295.807 52 307 63.1929 307 77H306H305C305 64.2974 294.703 54 282 54V53Z"></path>
                </svg>
                <div class="act-filter-box-head d-flex align-items-center justify-content-between w-100">
                    <div class="act-filter-box-head-text">
                        <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 18 18" fill="currentcolor" stroke="currentcolor"><path d="M7.44629 1.5708C8.45273 1.16128 9.5548 1.1629 10.5527 1.57178L14.7295 3.28076C15.3839 3.55159 15.9082 4.33745 15.9082 5.04053L15.9082 8.33252C15.9082 12.1131 13.1872 15.6225 9.44238 16.6636L9.43457 16.6655C9.29879 16.7069 9.1523 16.7261 9 16.7261C8.8857 16.7261 8.77458 16.7157 8.66895 16.6929L8.56543 16.6655L8.55664 16.6626C4.8056 15.6289 2.0918 12.1211 2.0918 8.33252L2.0918 5.04053C2.0918 4.33781 2.61562 3.55294 3.26953 3.28174L7.44727 1.57178L7.44629 1.5708ZM9 1.72607C8.58727 1.72607 8.18113 1.79621 7.78809 1.93506L7.62012 1.99854L3.44238 3.7085L3.44043 3.70947C3.18249 3.81696 2.96287 4.02923 2.81055 4.25537C2.65838 4.48137 2.54303 4.76583 2.54297 5.04736L2.54297 8.34033C2.54308 11.9402 5.12545 15.2482 8.67773 16.2319V16.231C8.8865 16.2921 9.11249 16.292 9.32129 16.231L9.32227 16.2319C12.8745 15.2482 15.4559 11.9402 15.4561 8.34033L15.4561 5.04736C15.456 4.76583 15.3416 4.48137 15.1895 4.25537C15.0372 4.02925 14.8175 3.817 14.5596 3.70947L14.5576 3.7085L10.3799 1.99854C9.93518 1.81736 9.47164 1.72609 9 1.72607Z" stroke-width="0.673278"></path><path d="M9 6.14941C9.95408 6.14941 10.7256 6.92092 10.7256 7.875C10.7256 8.82908 9.95408 9.60059 9 9.60059C8.04592 9.60059 7.27441 8.82908 7.27441 7.875C7.27441 6.92092 8.04592 6.14941 9 6.14941ZM9 6.60059C8.29658 6.60059 7.72559 7.17158 7.72559 7.875C7.72559 8.57842 8.29658 9.14941 9 9.14941C9.70342 9.14941 10.2744 8.57842 10.2744 7.875C10.2744 7.17158 9.70342 6.60059 9 6.60059Z" stroke-width="0.673278"></path><path d="M9 12.1875C8.6925 12.1875 8.4375 11.9325 8.4375 11.625V9.375C8.4375 9.0675 8.6925 8.8125 9 8.8125C9.3075 8.8125 9.5625 9.0675 9.5625 9.375V11.625C9.5625 11.9325 9.3075 12.1875 9 12.1875Z"></path></svg><p>فیلتر ها</p>
                    </div>
                    <div class="dp-remove-filters">
                        <div class="dp-remove-filters-x">
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="currentcolor">
                                <path d="M10.0003 18.9582C5.05866 18.9582 1.04199 14.9415 1.04199 9.99984C1.04199 5.05817 5.05866 1.0415 10.0003 1.0415C14.942 1.0415 18.9587 5.05817 18.9587 9.99984C18.9587 14.9415 14.942 18.9582 10.0003 18.9582ZM10.0003 2.2915C5.75033 2.2915 2.29199 5.74984 2.29199 9.99984C2.29199 14.2498 5.75033 17.7082 10.0003 17.7082C14.2503 17.7082 17.7087 14.2498 17.7087 9.99984C17.7087 5.74984 14.2503 2.2915 10.0003 2.2915Z"></path>
                                <path d="M7.64147 12.9831C7.48314 12.9831 7.3248 12.9248 7.1998 12.7998C6.95814 12.5581 6.95814 12.1581 7.1998 11.9165L11.9165 7.1998C12.1581 6.95814 12.5581 6.95814 12.7998 7.1998C13.0415 7.44147 13.0415 7.84147 12.7998 8.08314L8.08314 12.7998C7.96647 12.9248 7.7998 12.9831 7.64147 12.9831Z"></path>
                                <path d="M12.3581 12.9831C12.1998 12.9831 12.0415 12.9248 11.9165 12.7998L7.1998 8.08314C6.95814 7.84147 6.95814 7.44147 7.1998 7.1998C7.44147 6.95814 7.84147 6.95814 8.08314 7.1998L12.7998 11.9165C13.0415 12.1581 13.0415 12.5581 12.7998 12.7998C12.6748 12.9248 12.5165 12.9831 12.3581 12.9831Z"></path>
                            </svg>
                        </div>

                    </div>
                </div>
                <div class="act-filter-box-main" style="position: relative;">
                    <div class="shop-filters-items act-bg-hover">
                        <div class="act-bg-hover-inner">
                            <div class="shop-filters-items-head collapsed d-flex align-items-center justify-content-between flex-wrap" data-bs-toggle="collapse" data-bs-target="#act-faq-1" aria-expanded="false" type="button" aria-controls="act-faq-1">
                                <div class="shop-filters-items-head-right">
                                    <div class="shop-filters-items-head-right-icon-box">
                                        <div></div>
                                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none"><path d="M7 10.75H5C2.58 10.75 1.25 9.42 1.25 7V5C1.25 2.58 2.58 1.25 5 1.25H7C9.42 1.25 10.75 2.58 10.75 5V7C10.75 9.42 9.42 10.75 7 10.75ZM5 2.75C3.42 2.75 2.75 3.42 2.75 5V7C2.75 8.58 3.42 9.25 5 9.25H7C8.58 9.25 9.25 8.58 9.25 7V5C9.25 3.42 8.58 2.75 7 2.75H5Z" fill="#00D1B2"></path><path d="M19 10.75H17C14.58 10.75 13.25 9.42 13.25 7V5C13.25 2.58 14.58 1.25 17 1.25H19C21.42 1.25 22.75 2.58 22.75 5V7C22.75 9.42 21.42 10.75 19 10.75ZM17 2.75C15.42 2.75 14.75 3.42 14.75 5V7C14.75 8.58 15.42 9.25 17 9.25H19C20.58 9.25 21.25 8.58 21.25 7V5C21.25 3.42 20.58 2.75 19 2.75H17Z" fill="#00D1B2"></path><path d="M19 22.75H17C14.58 22.75 13.25 21.42 13.25 19V17C13.25 14.58 14.58 13.25 17 13.25H19C21.42 13.25 22.75 14.58 22.75 17V19C22.75 21.42 21.42 22.75 19 22.75ZM17 14.75C15.42 14.75 14.75 15.42 14.75 17V19C14.75 20.58 15.42 21.25 17 21.25H19C20.58 21.25 21.25 20.58 21.25 19V17C21.25 15.42 20.58 14.75 19 14.75H17Z" fill="#00D1B2"></path><path d="M7 22.75H5C2.58 22.75 1.25 21.42 1.25 19V17C1.25 14.58 2.58 13.25 5 13.25H7C9.42 13.25 10.75 14.58 10.75 17V19C10.75 21.42 9.42 22.75 7 22.75ZM5 14.75C3.42 14.75 2.75 15.42 2.75 17V19C2.75 20.58 3.42 21.25 5 21.25H7C8.58 21.25 9.25 20.58 9.25 19V17C9.25 15.42 8.58 14.75 7 14.75H5Z" fill="#00D1B2"></path></svg>                                    </div>
                                    <div class="shop-filters-items-head-right-text">
                                        <p>دسته بندی ها</p>
                                        <span>Categories</span>
                                    </div>
                                </div>
                                <div class="shop-filters-items-head-left">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="currentcolor">
                                        <path d="M15.0579 11.3998C14.8996 11.3998 14.7413 11.4581 14.6163 11.5831L9.99961 16.1998L5.38294 11.5831C5.14128 11.3415 4.74128 11.3415 4.49961 11.5831C4.25794 11.8248 4.25794 12.2248 4.49961 12.4665L9.55794 17.5248C9.79961 17.7665 10.1996 17.7665 10.4413 17.5248L15.4996 12.4665C15.7413 12.2248 15.7413 11.8248 15.4996 11.5831C15.3829 11.4581 15.2163 11.3998 15.0579 11.3998Z"></path>
                                        <path d="M10 2.29141C9.65833 2.29141 9.375 2.57474 9.375 2.91641V16.9414C9.375 17.2831 9.65833 17.5664 10 17.5664C10.3417 17.5664 10.625 17.2831 10.625 16.9414V2.91641C10.625 2.57474 10.3417 2.29141 10 2.29141Z"></path>
                                    </svg>
                                </div>
                            </div>
                            <div class="act-selected-filters-box"></div>

                            <div class="shop-filters-items-main collapse" id="act-faq-1">
                                <div class="shop-filters-items-main-content">
                                    <div class="act-hor-bor"></div>
                                    <?php
                                    $args = array(
                                        'taxonomy' => 'product_cat',
                                        'orderby' => 'name',
                                        'order' => 'ASC'
                                    );

                                    $categories = get_terms($args);
                                    if (!empty($categories)) {
                                        foreach ($categories as $category) {
                                            ?>
                                            <div class="act-bg-hover shop-filters-items-main-item act-filter-link pointer" data-id="<?=$category->term_id?>" data-param="product_cat">
                                                <div class="act-bg-hover-inner"><div class="shop-filters-items-main-item-tick">
                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="10" viewBox="0 0 14 10" fill="currentcolor">
                                                            <path d="M4.77 9.55667C4.50333 9.55667 4.25 9.45 4.06333 9.26333L0.29 5.49C-0.0966667 5.10333 -0.0966667 4.46333 0.29 4.07667C0.676667 3.69 1.31667 3.69 1.70333 4.07667L4.77 7.14333L11.6233 0.29C12.01 -0.0966667 12.65 -0.0966667 13.0367 0.29C13.4233 0.676667 13.4233 1.31667 13.0367 1.70333L5.47667 9.26333C5.29 9.45 5.03667 9.55667 4.77 9.55667Z"></path>
                                                        </svg>
                                                    </div>
                                                    <div class="shop-filters-items-main-item-text">
                                                        <p class="shop-filters-items-main-item-text-1"><?=$category->name?></p>
                                                    </div>
                                                </div>
                                            </div>
                                            <?php
                                        }
                                    }
                                    ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php if (!empty($regions)) : ?>
                        <div class="shop-filters-items act-bg-hover">
                            <div class="act-bg-hover-inner">
                                <div class="shop-filters-items-head d-flex align-items-center justify-content-between flex-wrap" data-bs-toggle="collapse" data-bs-target="#act-faq-2" aria-expanded="true" type="button" aria-controls="act-faq-2">
                                    <div class="shop-filters-items-head-right">
                                        <div class="shop-filters-items-head-right-icon-box">
                                            <div></div>
                                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                                <path d="M12 2.75C6.89 2.75 2.75 6.89 2.75 12C2.75 17.11 6.89 21.25 12 21.25C17.11 21.25 21.25 17.11 21.25 12C21.25 6.89 17.11 2.75 12 2.75Z" stroke="#00D1B2" stroke-width="1.5"></path>
                                                <path d="M3.5 12H20.5" stroke="#00D1B2" stroke-width="1.5" stroke-linecap="round"></path>
                                                <path d="M12 3.5C9.8 6 9.8 18 12 20.5              M12 3.5C14.2 6 14.2 18 12 20.5" stroke="#00D1B2" stroke-width="1.2" stroke-linecap="round"></path>
                                                <path d="M12 8.5C10.76 8.5 9.75 9.51 9.75 10.75C9.75 12.62 12 15.25 12 15.25C12 15.25 14.25 12.62 14.25 10.75C14.25 9.51 13.24 8.5 12 8.5Z" fill="#00D1B2"></path>
                                                <circle cx="12" cy="10.75" r="0.75" fill="white"></circle>
                                            </svg>
                                        </div>
                                        <div class="shop-filters-items-head-right-text">
                                            <p>ریجن</p>
                                            <span>Region</span>
                                        </div>
                                    </div>
                                    <div class="shop-filters-items-head-left">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="currentcolor">
                                            <path d="M15.0579 11.3998C14.8996 11.3998 14.7413 11.4581 14.6163 11.5831L9.99961 16.1998L5.38294 11.5831C5.14128 11.3415 4.74128 11.3415 4.49961 11.5831C4.25794 11.8248 4.25794 12.2248 4.49961 12.4665L9.55794 17.5248C9.79961 17.7665 10.1996 17.7665 10.4413 17.5248L15.4996 12.4665C15.7413 12.2248 15.7413 11.8248 15.4996 11.5831C15.3829 11.4581 15.2163 11.3998 15.0579 11.3998Z"></path>
                                            <path d="M10 2.29141C9.65833 2.29141 9.375 2.57474 9.375 2.91641V16.9414C9.375 17.2831 9.65833 17.5664 10 17.5664C10.3417 17.5664 10.625 17.2831 10.625 16.9414V2.91641C10.625 2.57474 10.3417 2.29141 10 2.29141Z"></path>
                                        </svg>
                                    </div>
                                </div>
                                <div class="act-selected-filters-box"></div>

                                <div class="shop-filters-items-main collapse show" id="act-faq-2">
                                    <div class="act-hor-bor"></div>
                                    <div class="shop-filters-items-main-content">
                                        <?php foreach ($regions as $region): ?>
                                            <div class="act-bg-hover shop-filters-items-main-item act-filter-region pointer" data-id="<?=$region?>" data-param="product_region">
                                                <div class="act-bg-hover-inner"><div class="shop-filters-items-main-item-tick">
                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="10" viewBox="0 0 14 10" fill="currentcolor">
                                                            <path d="M4.77 9.55667C4.50333 9.55667 4.25 9.45 4.06333 9.26333L0.29 5.49C-0.0966667 5.10333 -0.0966667 4.46333 0.29 4.07667C0.676667 3.69 1.31667 3.69 1.70333 4.07667L4.77 7.14333L11.6233 0.29C12.01 -0.0966667 12.65 -0.0966667 13.0367 0.29C13.4233 0.676667 13.4233 1.31667 13.0367 1.70333L5.47667 9.26333C5.29 9.45 5.03667 9.55667 4.77 9.55667Z"></path>
                                                        </svg>
                                                    </div>
                                                    <div class="shop-filters-items-main-item-text">
                                                        <p class="shop-filters-items-main-item-text-1"><?=regionPersian($region) ?></p>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php endforeach; ?>
                                    </div>
                                </div>
                            </div>


                        </div>
                    <?php endif; ?>
                    <div class="shop-filters-items act-bg-hover">
                        <div class="act-bg-hover-inner">
                            <div class="shop-filters-items-head collapsed d-flex align-items-center justify-content-between flex-wrap" data-bs-toggle="collapse" data-bs-target="#act-faq-3" aria-expanded="false" type="button" aria-controls="act-faq-3">
                                <div class="shop-filters-items-head-right">
                                    <div class="shop-filters-items-head-right-icon-box">
                                        <div></div>
                                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none"><path d="M3.93012 16.6301C3.74012 16.6301 3.55012 16.5601 3.40012 16.4101C3.11012 16.1201 3.11012 15.6401 3.40012 15.3501L15.3501 3.40012C15.6401 3.11012 16.1201 3.11012 16.4101 3.40012C16.7001 3.69012 16.7001 4.17012 16.4101 4.46012L4.46012 16.4201C4.32012 16.5601 4.12012 16.6301 3.93012 16.6301Z" fill="#00D1B2"></path><path d="M11.1 19.03C10.91 19.03 10.72 18.96 10.57 18.81C10.28 18.52 10.28 18.04 10.57 17.75L11.77 16.55C12.06 16.26 12.54 16.26 12.83 16.55C13.12 16.84 13.12 17.32 12.83 17.61L11.63 18.81C11.49 18.95 11.3 19.03 11.1 19.03Z" fill="#00D1B2"></path><path d="M13.7905 16.3401C13.6005 16.3401 13.4105 16.2701 13.2605 16.1201C12.9705 15.8301 12.9705 15.3501 13.2605 15.0601L15.6505 12.6701C15.9405 12.3801 16.4205 12.3801 16.7105 12.6701C17.0005 12.9601 17.0005 13.4401 16.7105 13.7301L14.3205 16.1201C14.1805 16.2601 13.9805 16.3401 13.7905 16.3401Z" fill="#00D1B2"></path><path d="M11.0999 22.7499C10.1199 22.7499 9.13991 22.1499 7.94991 20.9599L3.03991 16.0499C0.649914 13.6599 0.659914 12.1199 3.06991 9.70991L9.70991 3.06991C12.1199 0.659914 13.6599 0.649914 16.0499 3.03991L20.9599 7.94991C23.3499 10.3399 23.3399 11.8799 20.9299 14.2899L14.2899 20.9299C13.0799 22.1399 12.0899 22.7499 11.0999 22.7499ZM12.8999 2.74991C12.3799 2.74991 11.7199 3.17991 10.7699 4.12991L4.12991 10.7699C3.17991 11.7199 2.74991 12.3799 2.74991 12.8899C2.74991 13.4099 3.14991 14.0399 4.09991 14.9899L9.00991 19.8999C9.95991 20.8499 10.5799 21.2499 11.0999 21.2499C11.0999 21.2499 11.0999 21.2499 11.1099 21.2499C11.6299 21.2499 12.2799 20.8199 13.2299 19.8699L19.8699 13.2299C20.8199 12.2799 21.2499 11.6199 21.2499 11.1099C21.2499 10.5899 20.8499 9.95991 19.8999 9.00991L14.9899 4.09991C14.0499 3.14991 13.4199 2.74991 12.8999 2.74991Z" fill="#00D1B2"></path><path d="M22 22.75H2C1.59 22.75 1.25 22.41 1.25 22C1.25 21.59 1.59 21.25 2 21.25H22C22.41 21.25 22.75 21.59 22.75 22C22.75 22.41 22.41 22.75 22 22.75Z" fill="#00D1B2"></path></svg>                                    </div>
                                    <div class="shop-filters-items-head-right-text">
                                        <p>محدوده قیمت</p>                                        <span>Price Range</span>
                                    </div>
                                </div>
                                <div class="shop-filters-items-head-left">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="currentcolor">
                                        <path d="M15.0579 11.3998C14.8996 11.3998 14.7413 11.4581 14.6163 11.5831L9.99961 16.1998L5.38294 11.5831C5.14128 11.3415 4.74128 11.3415 4.49961 11.5831C4.25794 11.8248 4.25794 12.2248 4.49961 12.4665L9.55794 17.5248C9.79961 17.7665 10.1996 17.7665 10.4413 17.5248L15.4996 12.4665C15.7413 12.2248 15.7413 11.8248 15.4996 11.5831C15.3829 11.4581 15.2163 11.3998 15.0579 11.3998Z"></path>
                                        <path d="M10 2.29141C9.65833 2.29141 9.375 2.57474 9.375 2.91641V16.9414C9.375 17.2831 9.65833 17.5664 10 17.5664C10.3417 17.5664 10.625 17.2831 10.625 16.9414V2.91641C10.625 2.57474 10.3417 2.29141 10 2.29141Z"></path>
                                    </svg>
                                </div>
                            </div>
                            <div class="act-selected-filters-box"></div> <!-- اضافه&zwnj;شده برای نمایش نام فیلترهای فعال -->

                            <div class="shop-filters-items-main collapse" id="act-faq-3">
                                <div class="shop-filters-items-main-content">
                                    <div class="act-hor-bor"></div>
                                    <div class="act-price-filter-box">
                                        <div class="act-price-filter-inputs">
                                            <span class="act-price-sep">از</span>
                                            <div class="act-price-filter-inputs-inner">
                                                <input type="text" class="act-price-from" value="0" data-raw="0" placeholder="۲۵۰,۰۰۰">
                                                <div class="act-price-filter-inputs-inner-border"></div>
                                                <div class="act-price-filter-inputs-inner-text"> تومان </div>
                                            </div>
                                        </div>
                                        <div class="act-price-filter-inputs">
                                            <span class="act-price-sep">تا</span>
                                            <div class="act-price-filter-inputs-inner">
                                                <input type="text" class="act-price-to" value="32,500,000" data-raw="32500000" placeholder="۱۲٬۰۰۰,۰۰۰">
                                                <div class="act-price-filter-inputs-inner-border"></div>
                                                <div class="act-price-filter-inputs-inner-text"> تومان </div>
                                            </div>
                                        </div>
                                        <div class="act-price-filter-btns">
                                            <button type="button" class="act-price-reset">ریست</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
            <div class="flex flex-col gap-6" style="margin-right: 13px;width: 100%;">
            <div class="act-shop-products-grid act-cols-2 fhDGSJDF justify-start-ipt" style="position: relative;">
                <?php
                $giftmax_is_user_logged_in = is_user_logged_in();
                $giftmax_wishlist_ids = $giftmax_is_user_logged_in ? giftmax_get_user_wishlist_product_ids() : [];
                $paged = 1;
                 if (!empty( $_GET['page'])) {
                    $paged = $_GET['page'];
                }
                if ( $term_id && in_array( $taxonomy, array( 'product_cat', 'product_tag' ), true )){
                    $args = array(
                            'post_type' => 'product',
                            'posts_per_page' => 16,
                            'paged'          => $paged,
                            'tax_query' => array(
                                    array(
                                            'taxonomy' => 'product_cat',
                                            'field'    => 'term_id',
                                            'terms'    => $term_id,
                                    ),
                            ),
                            'meta_query' => [
                                    'relation' => 'OR',
                                    [
                                            'key'     => 'giftmax_setting_order',
                                            'compare' => 'EXISTS',
                                            'type'    => 'NUMERIC',
                                    ],

                                    [
                                            'key'     => 'giftmax_setting_order',
                                            'compare' => 'NOT EXISTS',
                                    ],
                            ],
                            'orderby' => [
                                    'meta_value_num' => 'ASC',
                                    'date'           => 'DESC',
                            ],
                            'order'    => 'ASE',
                    );
                } else{
                    $args = array(
                        'post_type' => 'product',
                        'posts_per_page' => 30,
                        'paged'          => $paged
                    );
                }
                $home_coupon_objects = [];
                $home_coupon_ids = get_posts([
                    'post_type'      => 'shop_coupon',
                    'post_status'    => 'publish',
                    'numberposts'    => -1,
                    'fields'         => 'ids',
                ]);

                if (!empty($home_coupon_ids)) {
                    foreach ($home_coupon_ids as $home_coupon_id) {
                        $home_coupon_objects[] = new \WC_Coupon($home_coupon_id);
                    }
                }
                $query = new WP_Query($args);
                if ($query->have_posts()) {
                    while ($query->have_posts()) {
                        $query->the_post();
                        global $product;
                        $regular = $product->get_regular_price();
                        $sale    = $product->get_sale_price();
                        $final_price = $product->is_on_sale() && $sale > 0 ? $sale : $regular;
                        $img = get_the_post_thumbnail_url(get_the_ID(), 'product_discount');
                        $settings = get_post_meta($product->get_id(), 'giftmax_box_setting', true);
                        $img = get_the_post_thumbnail_url(get_the_ID(), 'product_discount');
                        $delivery = get_post_meta($product->get_id(), 'delivery', true);
                        $sale_to = $product->get_date_on_sale_to();
                        $sale_to_ts = $sale_to ? $sale_to->getTimestamp() : null;
                        $matched_coupon_code = '';

                        if (!empty($home_coupon_objects)) {
                            foreach ($home_coupon_objects as $home_coupon_obj) {
                                $expires_at = $home_coupon_obj->get_date_expires();

                                if ($expires_at && $expires_at->getTimestamp() < current_time('timestamp')) {
                                    continue;
                                }

                                if ($home_coupon_obj->is_valid_for_product($product)) {
                                    $matched_coupon_code = $home_coupon_obj->get_code();
                                    break;
                                }
                            }
                        }
                        ?>
                        <div class="act-new-service-card">
                            <?php if (!empty($matched_coupon_code) && !isMobile()) { ?>
                                <div class="act-new-service-card-discount Button-sc91" data-product-id="<?=esc_attr($product->get_id())?>">
                                    <div class="anScr"></div>
                                    <div class="anSct">مشاهده کد تخفیف</div>
                                    <div class="anScl"></div>
                                </div>
                            <?php } ?>
                            <div class="act-new-service-card-inner">
                                <div <?=isset($delivery['two']) && $delivery['two'] == 'on' || product_available($product->get_id()) ?'':'class="NdhJD5"'?>>
                                    <div class="act-new-service-card-inner-top">
                                        <a href="<?=get_permalink()?>">
                                        <div class="act-new-service-card-inner-top-img-box relative">
                                            <img loading="lazy" decoding="async" width="32" height="33" src="<?=$img?>" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="">
                                            <?php
                                            if (!empty($settings[0]['logo_region'])){
                                                ?>
                                                <div class="logo_region">
                                                    <img src="<?=empty($settings[0]['logo_region']) ?: get_template_directory_uri() . '/assets/flag/' . $settings[0]['logo_region'] . '.svg'?>">
                                                </div>
                                                <?php
                                            }
                                            $date_from = $product->get_date_on_sale_from();
                                            $date_to   = $product->get_date_on_sale_to();
                                            if ($product->is_on_sale() & ($date_from || $date_to)){                                                ?>
                                                <div class="logo_detail" style="top: 7px;right: 7px;background-color: transparent;">
                                                    <img width="33" height="29" src="<?=get_template_directory_uri()?>/assets/img/svg/Amazings.svg">
                                                </div>
                                                <?php
                                            } elseif ($product->is_on_sale()){
                                                ?>
                                                <div class="logo_detail" style="top: 7px;right: 7px;">
                                                    <img src="<?=get_template_directory_uri()?>/assets/img/svg/percent.svg">
                                                </div>
                                                <?php
                                            }
                                            ?>
                                        </div>
                                        </a>
                                        <div class="act-new-service-card-inner-top-txt-box" <?=!empty($settings[0]['label']) && $settings[0]['label'] != '' ? 'style="gap:2px"' : ''?>>
                                            <a href="<?=get_permalink()?>">
                                                <h4 class="act-product-title"><?=get_the_title()?></h4>
                                                <?php
                                                if(!empty($settings[0]['sub_head'])) echo "<p class='act-product-title-en'>" . $settings[0]['sub_head'] . "</p>";
                                                ?>
                                            </a>
                                          <div class="flex justify-between">
                                              <div class="flex">
                                                  <?php
                                                  $tooltip = isset($delivery['description']) ? $delivery['description'] : '';
                                                  ?>
                                                  <div class="act-product-option-box__nw <?=isset($delivery['two']) && $delivery['two'] == 'on' ? 'pre-sale wiki wiki__holder js-dk-wiki-trigger' : 'same-day'?>" <?=isset($delivery['two']) && $delivery['two'] == 'on' ? 'data-tooltip="'. $tooltip .'"' :''?>><?=isset($delivery['two']) && $delivery['two'] == 'on' ? 'پیش فروش' : 'تحویل آنی'?></div>
                                                  <div class="purchaseScore wiki wiki__holder js-dk-wiki-trigger" data-tooltip="با خرید این گیفت کارت <?=empty($settings[0]['purchaseScore']) ?0: $settings[0]['purchaseScore']?> امتیاز دریافت میکنید">
                                                      <i class="icon-star"></i><?=empty($settings[0]['purchaseScore']) ?0: $settings[0]['purchaseScore']?></div>
                                              </div>
                                                <?php
                                                if ($giftmax_is_user_logged_in){
                                                $is_in_wishlist = in_array((int) $product->get_id(), $giftmax_wishlist_ids, true); ?>
                                                <button class="add-to__favorites Button-alu84 <?=$is_in_wishlist ? 'is-active' : ''?>" data-product-id="<?=esc_attr($product->get_id())?>" data-auth="<?=$giftmax_is_user_logged_in ? '1' : '0'?>" style="width: 28px;height: 28px;border-radius: 7px">
                                                    <svg viewBox="0 0 24 24" style="width: 64%;">
                                                        <path d="M12.62 20.81C12.28 20.93 11.72 20.93 11.38 20.81C8.48 19.82 2 15.69 2 8.68998C2 5.59998 4.49 3.09998 7.56 3.09998C9.38 3.09998 10.99 3.97998 12 5.33998C13.01 3.97998 14.63 3.09998 16.44 3.09998C19.51 3.09998 22 5.59998 22 8.68998C22 15.69 15.52 19.82 12.62 20.81Z" fill="<?=$is_in_wishlist ? '#ef4444' : 'none'?>" stroke="<?=$is_in_wishlist ? '#ef4444' : 'inherit'?>" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                                                    </svg>
                                                </button>
                                                    <?php
                                                }
                                                    ?>
                                            </div>
                                            <?php if (!empty($matched_coupon_code) && isMobile()) { ?>
                                                <div class="act-new-service-card-discount Button-sc91" data-product-id="<?=esc_attr($product->get_id())?>">
                                                    مشاهده کد تخفیف
                                                </div>
                                            <?php }else{ ?>
                                                <p class="act-product-txt"><?=empty($settings[0]['description_short']) ?'': $settings[0]['description_short']?></p>
                                                <?php
                                            }
                                            ?>                                            <?php
                                            if (!empty($settings[0]['label']) && $settings[0]['label'] != ''){?>
                                                <div class="label-fjd84">
                                                    <img src="<?=empty($settings[0]['label']) ?'': $settings[0]['label']?>" class="logo_label">
                                                    <p class="label_title"><?=empty($settings[0]['label_title']) ?'': $settings[0]['label_title']?></p>
                                                </div>
                                                <?php
                                            }
                                            ?>
                                        </div>
                                    </div>
                                </div>
                                <?php
                                $date_from = $product->get_date_on_sale_from();
                                $date_to   = $product->get_date_on_sale_to();
                                if ($product->is_on_sale() & ($date_from || $date_to)) {
                                    $sale_from_ts = $date_from ? $date_from->getTimestamp() : null;
                                    $sale_to_ts   = $date_to ? $date_to->getTimestamp() : null;
                                    if ($sale_from_ts && $sale_to_ts) {
                                        $now_ts = time();
                                        $total_duration = $sale_to_ts - $sale_from_ts;
                                        $elapsed = $now_ts - $sale_from_ts;

                                        $progress_percent = max(0, min(100, ($elapsed / $total_duration) * 100));
                                    } else {
                                        $progress_percent = 0;
                                    }
                                }else{
                                    $sale_to_ts = null;
                                }
                                if (!$sale_to_ts){
                                    ?>
                                    <div class="act-hor-bor"></div>
                                    <?php
                                }else{
                                    ?>
                                    <div class="flex justify-between flex-col">
                                        <div class="relative bg-neutral-100 style_ProductPromotionTimeline__progress__JnKWE" style="">
                                            <div class="absolute bg-primary-700 h-full left-0 top-0 style_ProductPromotionTimeline--active__oYyta" style="width: <?=$progress_percent?>%;"></div>
                                        </div>
                                        <span class="text-primary-700 text-body2-strong style_ProductPromotionTimeline__timer__zS6ZA1 text-left"><?= date('Y-m-d H:i:s', $sale_to_ts); ?></span>

                                    </div>
                                    <?php
                                }
                                ?>
                                <div>
                                    <?php
                                    if(!empty($matched_coupon_code)){
                                        $usage_limit  = (int) $home_coupon_obj->get_usage_limit();
                                        $usage_count  = (int) $home_coupon_obj->get_usage_count();

                                        $remaining_uses = $usage_limit > 0
                                            ? max( 0, $usage_limit - $usage_count )
                                            : __( 'نامحدود', 'textdomain' );
                                        ?>
                                        <div class="">
                                            <div class="relative bg-neutral-100 style_ProductPromotionTimeline__progress__JnKWE">
                                                <div class="absolute bg-primary-700 h-full left-0 top-0 style_ProductPromotionTimeline--active__oYyta" style="width: <?=($home_coupon_obj->get_usage_count()/($home_coupon_obj->get_usage_count()+$remaining_uses))*100?>%;"></div>
                                            </div>
                                            <div class="whitespace-nowrap flex justify-between pt-1">
                                                <div class=""><span class="text-primary-700 text-body-strong ml-1"><?=($home_coupon_obj->get_usage_count()/($home_coupon_obj->get_usage_count()+$remaining_uses))*100?>%</span><span class="text-neutral-500 text-caption">فروش رفته</span></div>
                                                <?php
                                                if ($home_coupon_obj->get_date_expires()){
                                                    ?>
                                                    <div class="text-primary-700 text-body2-strong style_ProductPromotionTimeline__timer__zS6ZA"><?= $home_coupon_obj->get_date_expires() ? $home_coupon_obj->get_date_expires()->date_i18n( 'Y-m-d H:i:s' ) : 'بدون تاریخ انقضا'?></div>
                                                    <?php
                                                }else{?>
                                                    <div class="text-primary-700 text-body2-strong style_ProductPromotionTimeline__timer__zS6ZA"></div>
                                                <?php }
                                                ?>
                                            </div>
                                        </div>
                                        <?php
                                    }
                                    ?>
                                <div class="act-product-card-footer">
                                    <a href="<?=the_permalink()?>" class="act-special-carousel-card-buy-box-option">جزئیات</a>
                                    <div class="act-product-price-box">
                                            <?php
                                            if ( $sale && $regular > $sale ) {?>
                                                <div class="act-product-price-box-top">
                                                    <div class="act-product-price-off-price"><?=number_format_usd($regular)?></div>
                                                    <div class="act-product-price-off-percent">  <?=get_discount_percent($product)?> ٪       </div>


                                                </div>
                                                <?php
                                            }
                                            ?>
                                            <div class="act-product-price<?=$product->is_on_sale() ? ' bpt' : ''?>">
                                                <?php
                                                if($final_price > 0){?>
                                                    <div id="priceValue" data-id="<?=$product->get_id()?>" data-target="<?=$product->is_on_sale() ? $sale :$regular?>"><?=number_format_usd($product->is_on_sale() ? $sale : $regular)?></div>
                                                    <span>تومان</span>
                                                    <?php
                                                }else{
                                                    ?>
                                                    <div class="act-product-price-free">رایگان</div>
                                                    <?php
                                                }
                                                ?>
                                            </div>
                                        </div>
                                </div>
                                    <?php
                                    if (isset($delivery['two']) && $delivery['two'] == 'on' || product_available($product->get_id())){
                                        if (\Giftmax\Modules\UserModel::setting("buy") === true) {
                                            ?>
                                            <button type="button" class="act-special-carousel-card-buy-box-but Button-aca49 pointer" data-product-id="<?=$product->get_id()?>">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="26" height="26" viewBox="0 0 26 26" fill="currentcolor">
                                                    <path d="M17.875 9.34916C17.4308 9.34916 17.0625 8.98083 17.0625 8.53666V7.04166C17.0625 5.90416 16.575 4.79916 15.73 4.03C14.8742 3.25 13.7692 2.8925 12.5992 3.00083C10.6492 3.185 8.9375 5.17833 8.9375 7.25833V8.30916C8.9375 8.75333 8.56917 9.12166 8.125 9.12166C7.68083 9.12166 7.3125 8.75333 7.3125 8.30916V7.2475C7.3125 4.33333 9.66333 1.64666 12.4475 1.37583C14.0725 1.22417 15.6325 1.73333 16.8242 2.8275C18.005 3.9 18.6875 5.43833 18.6875 7.04166V8.53666C18.6875 8.98083 18.3192 9.34916 17.875 9.34916Z"></path>
                                                    <path d="M16.2498 24.6457H9.7498C4.7448 24.6457 3.81314 22.3165 3.5748 20.0523L2.7623 13.5632C2.64314 12.3932 2.5998 10.714 3.7373 9.45734C4.7123 8.374 6.32647 7.854 8.66647 7.854H17.3331C19.684 7.854 21.2981 8.38484 22.2623 9.45734C23.389 10.714 23.3565 12.3932 23.2373 13.5415L22.4248 20.0523C22.1865 22.3165 21.2548 24.6457 16.2498 24.6457ZM8.66647 9.479C6.83564 9.479 5.57897 9.8365 4.9398 10.5515C4.40897 11.1365 4.23564 12.0357 4.37647 13.379L5.18897 19.8682C5.37314 21.6015 5.8498 23.0315 9.7498 23.0315H16.2498C20.1498 23.0315 20.6265 21.6123 20.8106 19.8898L21.6231 13.379C21.764 12.0573 21.5906 11.1582 21.0598 10.5623C20.4206 9.8365 19.164 9.479 17.3331 9.479H8.66647Z"></path>
                                                    <path d="M16.7045 14.2458C16.0979 14.2458 15.6104 13.7583 15.6104 13.1624C15.6104 12.5666 16.0979 12.0791 16.6937 12.0791C17.2895 12.0791 17.777 12.5666 17.777 13.1624C17.777 13.7583 17.3004 14.2458 16.7045 14.2458Z"></path>
                                                    <path d="M9.12151 14.2458C8.51484 14.2458 8.02734 13.7583 8.02734 13.1624C8.02734 12.5666 8.51484 12.0791 9.11068 12.0791C9.70651 12.0791 10.194 12.5666 10.194 13.1624C10.194 13.7583 9.71734 14.2458 9.12151 14.2458Z"></path>
                                                </svg>
                                                افزودن به سبد خرید
                                            </button>
                                            <?php
                                        }else{
                                            echo '<button type="button" class="btn btn-buy-disable mb-2" >خرید از سایت غیرفعال هست</button>';
                                        }
                                    }
                                    else{
                                        echo '<div class="inaJSDge8">ناموجود</div>';
                                    }
                                    ?>
                                </div>
                            </div>
                        </div>
                        <?php
                    }
                }
                ?>

            </div>
                <?php
                $total_pages = $query->max_num_pages;

                if ( $total_pages > 1 ) :
                    $current_page = max(1, $paged);
                    ?>
                    <div class="navigation pagination act-shop-pagination">
                        <div class="navigation pagination act-shop-pagination">
                            <div class="nav-links">

                                <?php
                                if ( $term_id && in_array( $taxonomy, array( 'product_cat', 'product_tag' ), true )) {
                                    echo paginate_links(array(
                                        'base' => trailingslashit(get_term_link($term_id)) . '?page=%#%',
                                        'format' => '',
                                        'current' => $paged,
                                        'total' => $query->max_num_pages,
                                        'type' => 'plain',
                                        'prev_next' => false,
                                    ));
                                }else{
                                    for ($i = 1; $i <= $total_pages; $i++) :
                                       if ($i == $current_page) : ?>
                                            <span aria-current="page" class="page-numbers current"><?= $i ?></span>
                                        <?php else : ?>
                                            <a class="page-numbers a--page-numbers pointer" data-page="<?= $i ?>"><?= $i ?></a>
                                        <?php endif;
                                     endfor;
                                }
                                ?>

                            </div>

                            <div class="act-vb"></div>
                            <?php
                            if ($term_id && in_array( $taxonomy, array( 'product_cat', 'product_tag' ), true )){
                            ?>
                            <div class="act-pagination-arrows">
                                <!-- Prev -->
                                <?php if ( $current_page > 1 ) : ?>
                                <a class="prev page-numbers" href="<?=trailingslashit(get_term_link($current_cat)) . '?page='.($current_page - 1); ?>">
                                    <?php else : ?>
                                    <a class="prev page-numbers act-disabled">
                                        <?php endif; ?>
                                        <!-- SVG Prev -->
                                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="currentColor">
                                            <path d="M12.0253 15.6833C11.8669 15.6833 11.7086 15.625 11.5836 15.5C11.3419 15.2583 11.3419 14.8583 11.5836 14.6166L16.2003 9.99998L11.5836 5.38331C11.3419 5.14164 11.3419 4.74164 11.5836 4.49998C11.8253 4.25831 12.2253 4.25831 12.4669 4.49998L17.5253 9.55831C17.7669 9.79998 17.7669 10.2 17.5253 10.4416L12.4669 15.5C12.3419 15.625 12.1836 15.6833 12.0253 15.6833Z"/>
                                            <path d="M16.942 10.625H2.91699C2.57533 10.625 2.29199 10.3417 2.29199 10C2.29199 9.65833 2.57533 9.375 2.91699 9.375H16.942C17.2837 9.375 17.567 9.65833 17.567 10C17.567 10.3417 17.2837 10.625 16.942 10.625Z"/>
                                        </svg>
                                    </a>

                                    <!-- Next -->
                                    <?php if ( $current_page < $total_pages ) : ?>
                                    <a class="next page-numbers" href="<?=trailingslashit(get_term_link($current_cat)) . '?page='.($current_page + 1); ?>">
                                        <?php else : ?>
                                        <a class="next page-numbers act-disabled">
                                            <?php endif; ?>
                                            <!-- SVG Next -->
                                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="currentColor">
                                                <path d="M7.97474 4.31669C8.13307 4.31669 8.29141 4.37502 8.41641 4.50002C8.65807 4.74169 8.65807 5.14169 8.41641 5.38336L3.79974 10L8.41641 14.6167C8.65807 14.8584 8.65807 15.2584 8.41641 15.5C8.17474 15.7417 7.77474 15.7417 7.53307 15.5L2.47474 10.4417C2.23307 10.2 2.23307 9.80002 2.47474 9.55836L7.53307 4.50002C7.65807 4.37502 7.81641 4.31669 7.97474 4.31669Z"/>
                                                <path d="M3.05801 9.375L17.083 9.375C17.4247 9.375 17.708 9.65833 17.708 10C17.708 10.3417 17.4247 10.625 17.083 10.625L3.05801 10.625C2.71634 10.625 2.43301 10.3417 2.43301 10C2.43301 9.65833 2.71634 9.375 3.05801 9.375Z"/>
                                            </svg>
                                        </a>
                            </div>
                            <?php
                            }else{?>
                                <div class="act-pagination-arrows">
                                    <!-- Prev -->
                                    <?php if ( $current_page > 1 ) : ?>
                                    <a class="prev page-numbers" href="<?=home_url('/shop') . '?page='.($current_page - 1); ?>">
                                        <?php else : ?>
                                        <a class="prev page-numbers act-disabled">
                                            <?php endif; ?>
                                            <!-- SVG Prev -->
                                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="currentColor">
                                                <path d="M12.0253 15.6833C11.8669 15.6833 11.7086 15.625 11.5836 15.5C11.3419 15.2583 11.3419 14.8583 11.5836 14.6166L16.2003 9.99998L11.5836 5.38331C11.3419 5.14164 11.3419 4.74164 11.5836 4.49998C11.8253 4.25831 12.2253 4.25831 12.4669 4.49998L17.5253 9.55831C17.7669 9.79998 17.7669 10.2 17.5253 10.4416L12.4669 15.5C12.3419 15.625 12.1836 15.6833 12.0253 15.6833Z"/>
                                                <path d="M16.942 10.625H2.91699C2.57533 10.625 2.29199 10.3417 2.29199 10C2.29199 9.65833 2.57533 9.375 2.91699 9.375H16.942C17.2837 9.375 17.567 9.65833 17.567 10C17.567 10.3417 17.2837 10.625 16.942 10.625Z"/>
                                            </svg>
                                        </a>

                                        <!-- Next -->
                                        <?php if ( $current_page < $total_pages ) : ?>
                                        <a class="next page-numbers" href="<?=home_url('/shop') . '?page='.($current_page + 1); ?>">
                                            <?php else : ?>
                                            <a class="next page-numbers act-disabled">
                                                <?php endif; ?>
                                                <!-- SVG Next -->
                                                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="currentColor">
                                                    <path d="M7.97474 4.31669C8.13307 4.31669 8.29141 4.37502 8.41641 4.50002C8.65807 4.74169 8.65807 5.14169 8.41641 5.38336L3.79974 10L8.41641 14.6167C8.65807 14.8584 8.65807 15.2584 8.41641 15.5C8.17474 15.7417 7.77474 15.7417 7.53307 15.5L2.47474 10.4417C2.23307 10.2 2.23307 9.80002 2.47474 9.55836L7.53307 4.50002C7.65807 4.37502 7.81641 4.31669 7.97474 4.31669Z"/>
                                                    <path d="M3.05801 9.375L17.083 9.375C17.4247 9.375 17.708 9.65833 17.708 10C17.708 10.3417 17.4247 10.625 17.083 10.625L3.05801 10.625C2.71634 10.625 2.43301 10.3417 2.43301 10C2.43301 9.65833 2.71634 9.375 3.05801 9.375Z"/>
                                                </svg>
                                            </a>
                                </div>
                            <?php }
                            ?>
                        </div>
                    </div>
                <?php endif; wp_reset_postdata(); ?>
            </div>
        </div>
            </div>
        </div>
    </section>
    <?php
    if (!empty($current_cat->description)){
    ?>
    <section class="container-2xl-w mx-auto mt-32 mb-10">
        <div class="act-new-service-carousel-1st">
            <div class="act-new-service-carousel-head d-flex align-items-center justify-content-between">
                <svg xmlns="http://www.w3.org/2000/svg" width="1281" height="75" viewBox="0 0 1281 75" fill="none" class="act-new-service-carousel-head-svg">
                    <path d="M1280.47 0.5H1000.91C986.771 0.5 979.703 0.5 973.764 2.99163C969.027 4.9789 964.838 8.07733 961.551 12.025C957.43 16.9747 955.361 23.7331 951.224 37.25C947.086 50.7669 945.017 57.5253 940.896 62.475C937.609 66.4227 933.42 69.5211 928.683 71.5084C922.744 74 915.676 74 901.54 74H412.882C399.847 74 393.329 74 387.813 71.8926C382.12 69.7177 377.167 65.9625 373.536 61.0686C370.017 56.3267 368.257 50.0512 364.737 37.5C361.217 24.9488 359.457 18.6733 355.938 13.9314C352.307 9.0375 347.353 5.2823 341.661 3.10737C336.145 1 329.627 1 316.592 1H0" stroke="url(#paint0_linear_29_20094)"></path>
                    <defs>
                        <linearGradient id="paint0_linear_29_20094" x1="29.4736" y1="0.500002" x2="1213.79" y2="-28.0511" gradientUnits="userSpaceOnUse">
                            <stop stop-color="#0B61FF" stop-opacity="0"></stop>
                            <stop offset="0.5" stop-color="#0B61FF"></stop>
                            <stop offset="1" stop-color="#0B61FF" stop-opacity="0"></stop>
                        </linearGradient>
                    </defs>
                </svg>
                <div class="act-our-services-carousel-head-title">
                    <div class="act-our-services-carousel-head-title-divs">
                        <div class="act-our-services-carousel-head-title-div1"></div>
                        <div class="act-our-services-carousel-head-title-div2"></div>
                    </div>
                    <div class="act-our-services-carousel-head-title-content">
                        <h5> <strong>توضیحات</strong> </h5>
                        <p>Description</p>
                    </div>
                </div>
            </div>
            <div class="SJD83s">
                <div class="content-main"><?= wpautop(wp_kses_post($current_cat->description)) ?></div>
            </div>
        </div>
    </section>
    <?php
    }
    $category_slug  = 'ytr';
    $posts_per_page = 12;
    $orderby        = 'date';
    $order          = 'DESC';
    $cat_id = (int) get_term_meta($term_id, 'giftmax_blog_category_id', true);
    if ( $cat_id ) {
        $args = [
            'category' => $cat_id,
            'posts_per_page' => $posts_per_page,
            'orderby' => $orderby,
            'order' => $order,
            'no_found_rows' => true,
        ];
    $posts  = get_posts( $args );
    if (!empty($posts)){
    ?>
    <section class="container-2xl-w mx-auto mt-32 mb-10">
        <div class="act-new-service-carousel-1st">
            <div class="act-new-service-carousel-head d-flex align-items-center justify-content-between">
                <svg xmlns="http://www.w3.org/2000/svg" width="1281" height="75" viewBox="0 0 1281 75" fill="none" class="act-new-service-carousel-head-svg">
                    <path d="M1280.47 0.5H1000.91C986.771 0.5 979.703 0.5 973.764 2.99163C969.027 4.9789 964.838 8.07733 961.551 12.025C957.43 16.9747 955.361 23.7331 951.224 37.25C947.086 50.7669 945.017 57.5253 940.896 62.475C937.609 66.4227 933.42 69.5211 928.683 71.5084C922.744 74 915.676 74 901.54 74H412.882C399.847 74 393.329 74 387.813 71.8926C382.12 69.7177 377.167 65.9625 373.536 61.0686C370.017 56.3267 368.257 50.0512 364.737 37.5C361.217 24.9488 359.457 18.6733 355.938 13.9314C352.307 9.0375 347.353 5.2823 341.661 3.10737C336.145 1 329.627 1 316.592 1H0" stroke="url(#paint0_linear_29_20094)"></path>
                    <defs>
                        <linearGradient id="paint0_linear_29_20094" x1="29.4736" y1="0.500002" x2="1213.79" y2="-28.0511" gradientUnits="userSpaceOnUse">
                            <stop stop-color="#0B61FF" stop-opacity="0"></stop>
                            <stop offset="0.5" stop-color="#0B61FF"></stop>
                            <stop offset="1" stop-color="#0B61FF" stop-opacity="0"></stop>
                        </linearGradient>
                    </defs>
                </svg>
                <div class="act-our-services-carousel-head-title">
                    <div class="act-our-services-carousel-head-title-divs">
                        <div class="act-our-services-carousel-head-title-div1"></div>
                        <div class="act-our-services-carousel-head-title-div2"></div>
                    </div>
                    <div class="act-our-services-carousel-head-title-content">
                        <h5> مقالات<strong> مرتبط</strong> </h5>
                        <p>RELATED ARTICLES</p>
                    </div>
                </div>
                <div class="act-blog-head-content">
                    <div class="act-blog-buttons">
                        <div class="act-blog-head-but-r act-blog-head-but act-carousel-but" tabindex="0" role="button" aria-label="Previous slide">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="currentcolor">
                                <path d="M14.4301 18.8201C14.2401 18.8201 14.0501 18.7501 13.9001 18.6001C13.6101 18.3101 13.6101 17.8301 13.9001 17.5401L19.4401 12.0001L13.9001 6.46012C13.6101 6.17012 13.6101 5.69012 13.9001 5.40012C14.1901 5.11012 14.6701 5.11012 14.9601 5.40012L21.0301 11.4701C21.3201 11.7601 21.3201 12.2401 21.0301 12.5301L14.9601 18.6001C14.8101 18.7501 14.6201 18.8201 14.4301 18.8201Z"></path>
                                <path d="M20.33 12.75H3.5C3.09 12.75 2.75 12.41 2.75 12C2.75 11.59 3.09 11.25 3.5 11.25L20.33 11.25C20.74 11.25 21.08 11.59 21.08 12C21.08 12.41 20.74 12.75 20.33 12.75Z"></path>
                            </svg>
                        </div>
                        <div class="act-blog-head-but-l act-blog-head-but act-carousel-but swiper-button-disabled" tabindex="-1" role="button" aria-label="Next slide" aria-disabled="true">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="currentcolor">
                                <path d="M9.56988 5.17988C9.75988 5.17988 9.94988 5.24988 10.0999 5.39988C10.3899 5.68988 10.3899 6.16988 10.0999 6.45988L4.55988 11.9999L10.0999 17.5399C10.3899 17.8299 10.3899 18.3099 10.0999 18.5999C9.80988 18.8899 9.32988 18.8899 9.03988 18.5999L2.96988 12.5299C2.67988 12.2399 2.67988 11.7599 2.96988 11.4699L9.03988 5.39988C9.18988 5.24988 9.37988 5.17988 9.56988 5.17988Z"></path>
                                <path d="M3.67 11.25H20.5C20.91 11.25 21.25 11.59 21.25 12C21.25 12.41 20.91 12.75 20.5 12.75L3.67 12.75C3.26 12.75 2.92 12.41 2.92 12C2.92 11.59 3.26 11.25 3.67 11.25Z"></path>
                            </svg>
                        </div>
                    </div>
                </div>
            </div>
            <div class="swiper new-blog-swiper act-articles-swiper">
                <div class="swiper-wrapper">
                    <?php
                    foreach ($posts as $post) :
                        setup_postdata($post);
                        $thumb_url = get_the_post_thumbnail_url($post->ID, 'medium_large');
                        ?>
                        <div class="swiper-slide">
                            <div class="act-blog-card">
                                <div class="block bg-white rounded-lg lg:rounded-xl p-8 lg:p-16 h-full border shadow-none act-article-card relative justify-between">
                                    <a href="<?=esc_url(get_permalink($post))?>" class="block">
                                        <?php if (!empty($thumb_url)) : ?>
                                            <img alt="<?=esc_attr(get_the_title($post))?>" loading="lazy" width="400" height="200" decoding="async" class="rounded lg:rounded-lg w-full" src="<?=esc_url($thumb_url)?>">
                                        <?php endif; ?>
                                        <span class="act-blog-card-img-box-label"><?=get_the_category($post)[0]->name?></span>
                                    </a>
                                    <div class="px-12 pt-20 lg:pt-24 pb-6">
                                        <a href="<?=esc_url(get_permalink($post))?>" class="block">
                                            <h3 class="text-secondary text-sm lg:text-lg font-extrabold ellipsis-2"><?=esc_html(get_the_title($post))?></h3>
                                        </a>
                                        <div class="text-2xs lg:text-xs text-dark font-light mt-4 lg:mt-8 ellipsis-3"><?=get_the_excerpt($post)?></div>
                                    </div>
                                    <div class="act-blog-card-footer">
                                        <div class="act-blog-card-footer-read-time"><div class="flex align-items-center ml-1"><i class="icon-eye"></i><p><?= view_giftmax($post->ID)?></p></div><div class="flex align-items-center"><i class="icon-user"></i><?=giftmax_get_author_full_name(get_post_author_id($post->ID))?></div><div class="flex align-items-center blog_clock-view"><i class="icon-clock"></i><?=gjdate(get_the_date('Y-m-d',$post->ID),"d M Y")?></div></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php
                    endforeach;
                    wp_reset_postdata();
                    ?>
                </div>
            </div>
        </div>
    </section>
    <?php
    }
    }
    $faqs = get_term_meta($term_id, 'product_cat_faq', true);
    if (!empty($faqs)){
    ?>
    <section class="container-2xl-w mx-auto mt-32 mb-10">
        <div class="act-new-service-carousel-1st">
            <div class="act-new-service-carousel-head d-flex align-items-center justify-content-between">
                <svg xmlns="http://www.w3.org/2000/svg" width="1281" height="75" viewBox="0 0 1281 75" fill="none" class="act-new-service-carousel-head-svg">
                    <path d="M1280.47 0.5H1000.91C986.771 0.5 979.703 0.5 973.764 2.99163C969.027 4.9789 964.838 8.07733 961.551 12.025C957.43 16.9747 955.361 23.7331 951.224 37.25C947.086 50.7669 945.017 57.5253 940.896 62.475C937.609 66.4227 933.42 69.5211 928.683 71.5084C922.744 74 915.676 74 901.54 74H412.882C399.847 74 393.329 74 387.813 71.8926C382.12 69.7177 377.167 65.9625 373.536 61.0686C370.017 56.3267 368.257 50.0512 364.737 37.5C361.217 24.9488 359.457 18.6733 355.938 13.9314C352.307 9.0375 347.353 5.2823 341.661 3.10737C336.145 1 329.627 1 316.592 1H0" stroke="url(#paint0_linear_29_20094)"></path>
                    <defs>
                        <linearGradient id="paint0_linear_29_20094" x1="29.4736" y1="0.500002" x2="1213.79" y2="-28.0511" gradientUnits="userSpaceOnUse">
                            <stop stop-color="#0B61FF" stop-opacity="0"></stop>
                            <stop offset="0.5" stop-color="#0B61FF"></stop>
                            <stop offset="1" stop-color="#0B61FF" stop-opacity="0"></stop>
                        </linearGradient>
                    </defs>
                </svg>
                <div class="act-our-services-carousel-head-title">
                    <div class="act-our-services-carousel-head-title-divs">
                        <div class="act-our-services-carousel-head-title-div1"></div>
                        <div class="act-our-services-carousel-head-title-div2"></div>
                    </div>
                    <div class="act-our-services-carousel-head-title-content">
                        <h5> <strong>سوالات متداول</strong> </h5>
                        <p>Faq</p>
                    </div>
                </div>
            </div>
            <div class="act-faq apd5">
                <?php
                foreach ($faqs as $key => $item) {
                    ?>
                    <div class="act-faq_item <?=$key == 0 ?'collapsed': '' ?>">
                        <div class="act-questions">
                            <p class="text-only"><?=$item['question']?></p>
                            <div class="act-questions-flash" style="<?=$key == 0 ?'transform: rotate(0deg);': '' ?>">
                                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="currentcolor"><path d="M15.0579 11.3998C14.8996 11.3998 14.7413 11.4581 14.6163 11.5831L9.99961 16.1998L5.38294 11.5831C5.14128 11.3415 4.74128 11.3415 4.49961 11.5831C4.25794 11.8248 4.25794 12.2248 4.49961 12.4665L9.55794 17.5248C9.79961 17.7665 10.1996 17.7665 10.4413 17.5248L15.4996 12.4665C15.7413 12.2248 15.7413 11.8248 15.4996 11.5831C15.3829 11.4581 15.2163 11.3998 15.0579 11.3998Z"></path><path d="M10 2.29141C9.65833 2.29141 9.375 2.57474 9.375 2.91641V16.9414C9.375 17.2831 9.65833 17.5664 10 17.5664C10.3417 17.5664 10.625 17.2831 10.625 16.9414V2.91641C10.625 2.57474 10.3417 2.29141 10 2.29141Z"></path></svg>                                </div>
                        </div>
                        <div class="act-answer <?=$key == 0 ?'show':'' ?>">
                            <div class="act-answer-content">
                                <p class="text-only"><?=$item['answer']?></p>
                            </div>
                        </div>
                    </div>
                    <?php
                }
                ?>
            </div>
        </div>
    </section>
    <?php
    }
    ?>
</main>
