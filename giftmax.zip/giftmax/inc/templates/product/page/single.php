<style>
    @media (max-width: 768px) {
        #go-to-blabla {
            bottom: 154px;
        }
    }
</style>
<?php
global $post;
$product = wc_get_product( $post->ID );
$regular = $product->get_regular_price();
$sale    = $product->get_sale_price();
$price_history = get_post_meta($product->get_id(), '_giftmax_price_history', true) ;
if (!is_array($price_history)) {
    $price_history = array();
}
$cutoff = strtotime('-29 days', current_time('timestamp'));
$points = array();
foreach ($price_history as $key => $value) {
    $entry_ts = strtotime($key . ' 00:00:00');
    if ($entry_ts === false || $entry_ts < $cutoff) {
        continue;
    }
    $points[] = array(
        'v' => $value,
        'label' => gjdate($key,'Y-m-d'),
        'label_2' => gjdate($key,'d M'),
    );
}


$series_payload = wp_json_encode(array(
    'label' => '۳۰ روز',
    'points' => $points,
), JSON_UNESCAPED_UNICODE);
$a_settings = get_post_meta(get_the_ID(), 'giftmax_box_setting_All', true);
$settings = get_post_meta(get_the_ID(), 'giftmax_box_setting', true);
$cat_id =  get_post_meta(get_the_ID(), 'giftmax_blog_category_id', true);

$date_from = $product->get_date_on_sale_from();
$date_to   = $product->get_date_on_sale_to();
if ($product->is_on_sale() & ($date_from || $date_to)) {
    $sale_to = $product->get_date_on_sale_to();
    $sale_to_ts = $sale_to ? $sale_to->getTimestamp() : null;
}else{
    $sale_to_ts = null;
}
$delivery = get_post_meta($product->get_id(), 'delivery', true);
$is_available_for_purchase = ((isset($delivery['two']) && $delivery['two'] == 'on') || product_available($product->get_id()));
$alert_default_mobile = '';
if (is_user_logged_in()) {
    $current_user = wp_get_current_user();
    if (!empty($current_user->user_login)) {
        $alert_default_mobile = $current_user->user_login;
    }
    if (empty($alert_default_mobile)) {
        $alert_default_mobile = get_user_meta($current_user->ID, 'billing_phone', true);
    }
}
$countAvailable = !empty(\Giftmax\Modules\UserModel::table('product_licences','product_id',$product->get_id(),'licence_status','available',1))? count(\Giftmax\Modules\UserModel::table('product_licences','product_id',$product->get_id(),'licence_status','available',1)):0;
?>
<div class="z-[900] bg-white shadow-dropdown-reverse fixed inset-x-0 flex md:hidden flex-col" style="bottom: 60px;padding: 6px 10px">
    <div class="flex">
        <?php
        if ($is_available_for_purchase){
            ?>
            <div class="lg:w-50">
                <div class="xs:h-6 overflow-hidden">
                    <div class="product_slider-mobile flex flex-col gap-3" style="transform: translateY(0px); transition-duration: 300ms;">
                        <?php
                        if ((isset($delivery['one']) && $delivery['one'] == 'on') && $countAvailable <=3){
                            ?>
                            <div class="text-white gap-[6px] items-center flex rounded-lg p-[1px] pl-1.5 max-w-[fit-content] bg-[rgba(var(--color-black-rgb),0.6)] text-body2-strong-compact justify-start border-complete !border-[rgba(var(--color-white-rgb),0.2)]">
                                <div class="w-5 h-5 rounded-full overflow-hidden bg-white flex justify-center items-center">
                                    <div class="flex" aria-hidden="false">
                                        <div aria-hidden="true" style="width: 14px; height: 14px; line-height: 0;"><img class="w-full" src="<?=get_template_directory_uri()?>/assets/img/svg/54419b9303246cde131fcb5b251b86f2ab4aeb71_1716833765.svg" width="14" height="14" style="object-fit: cover;"></div>
                                    </div>
                                </div>
                                <p class="h-3.5 py-[1px] whitespace-nowrap">تنها <?=$countAvailable?> عدد در انبار باقی مانده</p>
                            </div>
                            <?php
                        }
                        ?>
                        <div class="text-white gap-[6px] items-center flex rounded-lg p-[1px] pl-1.5 max-w-[fit-content] bg-[rgba(var(--color-black-rgb),0.6)] text-body2-strong-compact justify-start border-complete !border-[rgba(var(--color-white-rgb),0.2)]">
                            <div class="w-5 h-5 rounded-full overflow-hidden bg-white flex justify-center items-center">
                                <div class="flex" aria-hidden="false">
                                    <div aria-hidden="true" style="width: 14px; height: 14px; line-height: 0;"><img class="w-full" src="<?=get_template_directory_uri()?>/assets/img/svg/54419b9303246cde131fcb5b251b86f2ab4aeb71_1716833765.svg" width="14" height="14" style="object-fit: cover;"></div>
                                </div>
                            </div>
                            <p class="h-3.5 py-[1px] whitespace-nowrap"><?=rand(1, 50)?>+ فروش در هفته گذشته</p>
                        </div>
                        <div class="text-white gap-[6px] items-center flex rounded-lg p-[1px] pl-1.5 max-w-[fit-content] bg-[rgba(var(--color-black-rgb),0.6)] text-body2-strong-compact justify-start border-complete !border-[rgba(var(--color-white-rgb),0.2)]">
                            <div class="w-5 h-5 rounded-full overflow-hidden bg-white flex justify-center items-center">
                                <div class="flex" aria-hidden="false">
                                    <div aria-hidden="true" style="width: 14px; height: 14px; line-height: 0;"><img class="w-full" src="<?=get_template_directory_uri()?>/assets/img/svg/b0d6bb54a0077253781cdce04f9e16a34edc5299_1716833794.svg" width="14" height="14" style="object-fit: cover;"></div>
                                </div>
                            </div>
                            <p class="h-3.5 py-[1px] whitespace-nowrap">در سبد خرید <?=rand(1, 25)?>+ نفر</p>
                        </div>
                    </div>
                </div>
            </div>
            <?php
        }
        ?>
        <div class="lg:w-50">
            <?php
            if ($sale_to_ts){
                ?>
                <div class="flex justify-between">
                    <div>
                        <img class="w-full inline-block" src="<?=get_template_directory_uri()?>/assets/img/svg/IncredibleOffer.svg" width="139" height="16" alt="" title="" style="object-fit: contain;">
                    </div>
                    <div class="flex items-center">
                        <div class="text-primary-700 text-body2-strong style_ProductPromotionTimeline__timer__zS6ZA"><?= date('Y-m-d H:i:s', $sale_to_ts); ?></div>
                    </div>
                </div>
                <?php
            }
            ?>
        </div>
    </div>
    <div class="flex">
        <div class="lg:w-50 flex align-items-center ai-start">

            <?php
            if ($is_available_for_purchase) {
                if (\Giftmax\Modules\UserModel::setting("buy") === true){
                    ?>
                    <button type="button" class="fjfYr25 btn-ajax after:border-blue Button-ac13" data-product-id="<?=get_the_ID()?>">افزودن به سبد خرید</button>
                    <?php
                }else{?>
                    <button type="button" class="btn btn-buy-disable2" >خرید از سایت غیرفعال هست</button>
                    <?php
                }
            }else{
                ?>
                <button
                        type="button"
                        class="fjfYr25 Button-stock-alert-toggle"
                        data-product-id="<?=esc_attr($product->get_id())?>"
                        data-default-mobile="<?=esc_attr($alert_default_mobile)?>"
                        style="color: #6c3bff !important;">
                    وقتی موجود شد خبرم کن
                </button>
                <?php
            }
            ?></div>
        <div class="lg:w-50 flex flex-col ai-end justify-center">
            <?php
            if ($product->is_on_sale()){
                ?>
                <div class="flex items-center justify-end w-full gap-1" data-theme-animation="price-container">
                    <span class="line-through text-body-2 ml-1 text-neutral-300" data-testid="price-no-discount"><?=number_format_usd($regular)?></span>
                    <div class="px-1 text-white rounded-large flex items-center justify-center ProductPrice_ProductPrice__discountWrapper__1Ru_1 bg-hint-object-error shrink-0 mr-1 mb-1">
                        <span class="text-body2-strong" data-testid="price-discount-percent"><?=get_discount_percent($product)?>٪</span>
                    </div>
                </div>
                <?php
            }
            ?>
            <div class="flex flex-row items-center">
                <?php
                if (number_format_usd($product->is_on_sale() ? $sale :$regular) != 0){?>
                    <span class="ml-1 text-neutral-800 text-h4-compact" style="font-size: 14px" data-testid="price-final" id="priceValue" data-id="<?=$product->get_id()?>" data-target="<?=payment_usd($product->is_on_sale() ? $sale :$regular)?>"><?=number_format_usd($product->is_on_sale() ? $sale :$regular)?></span>
                    <div style="font-size: 11px">
                        تومان
                    </div>
                    <?php
                }else{?>
                    <span class="ml-1 text-neutral-800 text-h4-compact" style="font-size: 14px" data-testid="price-final">رایگان</span>
                <?php }
                ?>
            </div>
        </div>
    </div>
</div>

<main class="woocommerce single_product__main">
    <?php
    $product_id = $product->get_id();        // یا همان $product_id که در کد قبلی استفاده می‌شد
    $valid_coupons = array();

    $args = array(
        'post_type'      => 'shop_coupon',
        'posts_per_page' => -1,
        'post_status'    => 'publish',
        'fields'         => 'ids',
    );
    $coupons_query = new WP_Query( $args );

    if ( $coupons_query->have_posts() ) :
        while ( $coupons_query->have_posts() ) : $coupons_query->the_post();

            $coupon_id = get_the_ID();
            $coupon   = new WC_Coupon( $coupon_id );
            $product_ids = $coupon->get_product_ids();
            if ( ! empty( $product_ids ) && ! in_array( $product_id, $product_ids ) ) {
                continue;
            }
            $expires = $coupon->get_date_expires();
            $expiry_text = $expires ? $expires->date_i18n( 'Y-m-d H:i:s' ) : 'بدون تاریخ انقضا';

            $usage_limit  = (int) $coupon->get_usage_limit();
            $usage_count  = (int) $coupon->get_usage_count();

            $remaining_uses = $usage_limit > 0
                ? max( 0, $usage_limit - $usage_count )
                : __( 'نامحدود', 'textdomain' );

            if ( $expires && $expires->getTimestamp() < current_time( 'timestamp', true ) ) {
                continue;            // اگر تاریخ گذشته باشد، رد می‌شود
            }


            if ( $usage_limit > 0 && $usage_count >= $usage_limit ) {
                continue;
            }
            $products      = $coupon->get_product_ids();
            $valid_coupons[] = array(
                'code'        => $coupon->get_code(),
                'type'        => $coupon->get_discount_type(),
                'amount'      => $coupon->get_amount(),
                'description' => $coupon->get_description(),
                'expiry_status'  =>  $expires ? true : false,
                'expiry'       => $expiry_text,
                'remaining'    => $remaining_uses,
                'usage_limit'    => $usage_limit,
                'total_used'   => $usage_count,
            );

        endwhile;
        wp_reset_postdata();

    endif;
    if ( !empty( $valid_coupons ) ) {
    ?>
    <div class="relative">
    <div class="style_ProductPromotionTimeline__Df56">
        <h4>کد تخفیف</h4>
        <div class="flex justify-between smt-3">
        <?php
        foreach ( $valid_coupons as $valid_coupon ) {
            ?>
        <div class="style_ProductPromotionTimeline__oYETa">
            <div class="coupons" style="width:100%">
                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="19" viewBox="0 0 18 19" fill="none"><path d="M15 7.47754H8.25C7.42157 7.47754 6.75 8.14911 6.75 8.97754V15.7275C6.75 16.556 7.42157 17.2275 8.25 17.2275H15C15.8284 17.2275 16.5 16.556 16.5 15.7275V8.97754C16.5 8.14911 15.8284 7.47754 15 7.47754Z" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path><path d="M3.75 11.9775H3C2.60218 11.9775 2.22064 11.8195 1.93934 11.5382C1.65804 11.2569 1.5 10.8754 1.5 10.4775V3.72754C1.5 3.32971 1.65804 2.94818 1.93934 2.66688C2.22064 2.38557 2.60218 2.22754 3 2.22754H9.75C10.1478 2.22754 10.5294 2.38557 10.8107 2.66688C11.092 2.94818 11.25 3.32971 11.25 3.72754V4.47754" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path></svg>
                <span style="line-height: 1"><?=$valid_coupon['code']?></span>
            </div>
            <?php
            if ($valid_coupon['usage_limit'] !=0){
            ?>
            <div class="mt-3">
                <div class="relative bg-neutral-100 style_ProductPromotionTimeline__progress__JnKWE">
                    <div class="absolute bg-primary-700 h-full left-0 top-0 style_ProductPromotionTimeline--active__oYyta" style="width: <?=($valid_coupon['total_used']/($valid_coupon['total_used']+$valid_coupon['remaining']))*100?>%;"></div>
                </div>
                <div class="whitespace-nowrap flex justify-between pt-1">
                    <div class=""><span class="text-primary-700 text-body-strong ml-1"><?=($valid_coupon['total_used']/($valid_coupon['total_used']+$valid_coupon['remaining']))*100?>%</span><span
                                class="text-neutral-500 text-caption">فروش رفته</span></div>
                    <?php
                    if ($valid_coupon['expiry_status']){
                    ?>
                    <div class="text-primary-700 text-body2-strong style_ProductPromotionTimeline__timer__zS6ZA"><?=$valid_coupon['expiry']?></div>
                    <?php
                    }else{?>
                        <div class="text-primary-700 text-body2-strong style_ProductPromotionTimeline__timer__zS6ZA"></div>
                    <?php }
                    ?>
                </div>
            </div>
            <?php
            }
            ?>
        </div>

            <?php
        }
        ?>
    </div>
    </div>
    </div>
    <?php
    }
    ?>
    <section class="product-hero container-xl-w mx-auto" <?=!empty($valid_coupons) ? 'style=padding-top:6.5rem;' : ''?> id="overview">
        <nav aria-label="مسیر دسترسی" class="breadcrumbs">
            <?php
            if ( function_exists('woocommerce_breadcrumb') ) {
                woocommerce_breadcrumb(array(
                    'wrap_before' => '<ol>',
                    'wrap_after'  => '</ol>',
                    'before'      => '<li>',
                    'after'       => '</li>',
                    'home'        => 'خانه',
                ));
            }
            ?>
        </nav>
        <div class="container product-hero__grid">
            <div class="flex flex-col xs:w-60 justify-content-between lg:w-75 xs:w-full">
                <div class="flex tyDD2s">
                    <div class="product-hero__media lg:w-40">
                        <?php
                        if ($sale_to_ts){
                            ?>
                            <div class="flex justify-between SD4ISd6" style="background-color: #FFF">
                                <div>
                                    <img class="w-full inline-block" src="<?=get_template_directory_uri()?>/assets/img/svg/IncredibleOffer.svg" width="139" height="16" alt="" title="" style="object-fit: contain;">
                                </div>
                            </div>
                            <?php
                        }
                        ?>
                        <div class="relative">
                            <div class="product-images-static">
                                <?php
                                if (!empty($settings[0]['label']) && $settings[0]['label'] != ''){?>
                                    <div class="label-pjd84" style="z-index: 5">
                                        <img src="<?=empty($settings[0]['label']) ?'': $settings[0]['label']?>" class="logo_label">
                                        <p class="label_title"><?=empty($settings[0]['label_title']) ?'': $settings[0]['label_title']?></p>
                                    </div>
                                    <?php
                                }
                                ?>
                                <div class="xs:w-[250px] relative hfSd4u flex align-items-center">
                                    <?php
                                if (has_post_thumbnail()) {
                                    $attachment_id = $product->get_image_id();
                                    $image_url = wp_get_attachment_url( $attachment_id );
                                    ?>
                                    <img src="<?= $image_url ?>">
                                    <?php
                                    }
                                if (!empty($settings[0]['logo_region'])){
                                    ?>
                                    <div class="logo_region" style="top: 10px;right: 58px;">
                                        <img src="<?=empty($settings[0]['logo_region']) ?: get_template_directory_uri() . '/assets/flag/' . $settings[0]['logo_region'] . '.svg'?>">
                                    </div>
                                    <?php
                                }
                                if ($sale_to_ts) {
                                    ?>
                                    <div class="logo_detail" style="top: 10px;right: 8px;background-color: transparent;">
                                        <img width="33" height="29" src="<?=get_template_directory_uri()?>/assets/img/svg/Amazings.svg">
                                    </div>
                                    <?php
                                } elseif ($product->is_on_sale()){
                                    ?>
                                    <div class="logo_detail" style="top: 10px;right: 8px;">
                                        <img src="<?=get_template_directory_uri()?>/assets/img/svg/percent.svg">
                                    </div>
                                    <?php
                                }
                                ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="product-hero__content lg:w-60">
                        <h1 class="relative">
                            <?php
                            echo the_title();
                            ?>
                            <span class="act-product-option-box__label <?=isset($delivery['two']) && $delivery['two'] == 'on' ? 'pre-sale_label' : 'same-day_label'?>"><?=isset($delivery['two']) && $delivery['two'] == 'on' ? 'پیش فروش' : 'تحویل آنی'?></span>
                            <?php
                            if (isset($delivery['two']) && $delivery['two'] == 'on'){
                                ?>
                                <div class="lottie-container lottie-pre_sale" data-lottie-url="<?=get_template_directory_uri()?>/assets/img/wsl/pre-sale.json"></div>
                                <?php
                            }
                            if (!empty($settings[0]['sub_head'])){?>
                            <span class="sub_head"><?=$settings[0]['sub_head']?></span>
                            <?php
                            }
                            ?>
                        </h1>
                        <?php
                        global $product;

                        $terms = get_the_terms( $product->get_id(), 'product_cat' );

                        if ( ! empty( $terms ) && ! is_wp_error( $terms ) ) :
                            ?>
                            <div class="product_meta">
                                <span class="posted_in detail-container">
                                    <span class="detail-label">دسته : </span>
                                    <span class="detail-content">
                                     <?php
                                     $cats = [];
                                     foreach ( $terms as $term ) {
                                         $cats[] = sprintf(
                                             '<a href="%s" rel="tag">%s</a>',
                                             esc_url( get_term_link( $term ) ),
                                             esc_html( $term->name )
                                         );
                                     }
                                     echo implode( ', ', $cats );
                                     ?>
                                    </span>
                                </span>
                            </div>
                        <?php endif;
                        if (!empty($settings[0]['purchaseScore'])){?>
                            <div class="purchaseScore">
                                <i class="icon-star"></i>
                                با خرید این گیفت کارت <strong class="font-bold"><?=$settings[0]['purchaseScore']?> امتیاز</strong> دریافت میکنید
                            </div>
                            <?php
                        }
                        ?>
                        <div class="fake_note modified_date">
                            <svg class="pack-theme" viewBox="0 0 24 24">
                                <path d="M8 2V5" stroke="inherit" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>
                                <path d="M16 2V5" stroke="inherit" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>
                                <path d="M3.5 9.08997H20.5" stroke="inherit" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>
                                <path d="M21 8.5V17C21 20 19.5 22 16 22H8C4.5 22 3 20 3 17V8.5C3 5.5 4.5 3.5 8 3.5H16C19.5 3.5 21 5.5 21 8.5Z" stroke="inherit" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>
                                <path d="M11.9955 13.7H12.0045" stroke="inherit" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                <path d="M8.29431 13.7H8.30329" stroke="inherit" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                <path d="M8.29431 16.7H8.30329" stroke="inherit" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>
                            <?php
                            $last_updated = get_option('giftmax_usd_rate_updated');
                            $now = time();
                            $seconds_ago = $now - strtotime($last_updated);

                            if ($seconds_ago < 60) {
                            $ksjd= "چند ثانیه قبل";
                            } elseif ($seconds_ago < 3600) {
                                $ksjd = "حدود " . round($seconds_ago / 60) . " دقیقه قبل";
                            } elseif ($seconds_ago < 86400) {
                                $ksjd=  "حدود " . round($seconds_ago / 3600) . " ساعت قبل";
                            } else {
                                $ksjd= "حدود " . round($seconds_ago / 86400) . " روز قبل";
                            }
                            ?>
                            تاریخ بروزرسانی : <div><?=$ksjd?> قمیت محصول بروز شده و با توجه به نرخ ارز نوسان خواهد داشت </div>
                        </div>
                        <?php
                        if (!empty($settings[0]['region']) || !empty($a_settings[0]['delivery_time']) || !empty($settings[0]['platforms']) || !empty($settings[0]['currency_unit'])) {
                            ?>
                            <div class="el_product-attributes box_attr_2">
                                <ul class="el_attribute-list">
                                    <?php
                                    if (!empty($settings[0]['region'])){?>
                                        <li>
                                            <span class="label">ریجن</span>
                                            <span class="value"><p><?=regionPersian($settings[0]['region'])?></p></span>
                                        </li>
                                        <?php
                                    }
                                    if (!empty($settings[0]['platforms'])){
                                        ?>
                                        <li>
                                            <span class="label">پلتفرم</span>
                                            <span class="value"><p><?=$settings[0]['platforms']?></p></span>
                                        </li>
                                        <?php
                                    }
                                    if (!empty($settings[0]['delivery_time'])){
                                        ?>
                                        <li>
                                            <span class="label">تحویل</span>
                                            <span class="value"><p><?=$settings[0]['delivery_time']?></p></span>
                                        </li>
                                        <?php
                                    }
                                    if (!empty($settings[0]['currency_unit'])){
                                        ?>
                                        <li>
                                            <span class="label">واحد پولی</span>
                                            <span class="value"><p><?=$settings[0]['currency_unit']?></p></span>
                                        </li>
                                        <?php
                                    }
                                    ?>
                                </ul>
                            </div>
                            <?php
                        }
                        if (isset($delivery['two']) && $delivery['two'] == 'on' && $delivery['description'] && isMobile()){
                            ?>
                            <div class="alert alert-sm alert-orange text-2xs leading-sm font-normal mt-3 mb-1 rounded-sm"><?=$delivery['description']?></div>
                            <?php
                        }
                        if (!empty($a_settings[0]['point'])){?>
                            <div class="custom_note_summary">
                                <svg class="pack-theme" viewBox="0 0 24 24"> <path d="M7.12988 18.3101H15.1299C17.8899 18.3101 20.1299 16.0701 20.1299 13.3101C20.1299 10.5501 17.8899 8.31006 15.1299 8.31006H4.12988" stroke="inherit" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"></path>
                                    <path d="M6.43012 10.8099L3.87012 8.24994L6.43012 5.68994" stroke="inherit" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path></svg>
                                <p><?=$a_settings[0]['point']?></p>
                            </div>
                        <?php }
                        if (isMobile()){
                        ?>
                        <button type="button" class="btn btn--outline btn--block Button-bf54 mb-2<?=!$is_available_for_purchase ? ' mt-3' : ''?>">خرید سریع</button>
                        <div class="flex justify-between">
                            <?php
                            if (!empty($settings[0]['linkUsing'])){?>
                                <a href="<?=$settings[0]['linkUsing']?>" class="product-single__link text-secondary w-100 d-flex align-items-center justify-center rounded-3">
                                    آموزش استفاده از محصول
                                </a>
                                <?php
                            }
                            $is_in_wishlist = false;
                            if (is_user_logged_in()) {
                                global $wpdb;
                                $wishlist_db = \Giftmax\Modules\Db::getLnstance();
                                $wishlist_item = $wishlist_db->first("SELECT `id` FROM `{$wpdb->prefix}user_wishlist` WHERE `user_id`=:user_id AND `product_id`=:product_id", array(
                                        'user_id' => get_current_user_id(),
                                        'product_id' => $product->get_id(),
                                ));
                                $is_in_wishlist = !empty($wishlist_item);
                                ?>
                                <button class="add-to__favorites Button-alu84 <?=$is_in_wishlist ? 'is-active' : ''?>" data-product-id="<?=esc_attr($product->get_id())?>" data-auth="<?=is_user_logged_in() ? '1' : '0'?>">
                                    <svg viewBox="0 0 24 24" style="width: 52%;">
                                        <path d="M12.62 20.81C12.28 20.93 11.72 20.93 11.38 20.81C8.48 19.82 2 15.69 2 8.68998C2 5.59998 4.49 3.09998 7.56 3.09998C9.38 3.09998 10.99 3.97998 12 5.33998C13.01 3.97998 14.63 3.09998 16.44 3.09998C19.51 3.09998 22 5.59998 22 8.68998C22 15.69 15.52 19.82 12.62 20.81Z" fill="<?=$is_in_wishlist ? '#ef4444' : 'none'?>" stroke="<?=$is_in_wishlist ? '#ef4444' : 'inherit'?>" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                                    </svg>
                                </button>
                                <?php
                            }
                            ?>
                        </div>
                        <button class="Button-cu46 support-buy">
                            <i class="icon-support"></i>
                            <div>سوالی دارید؟
                                <span>ارتباط با پشتیبانی</span>
                            </div>
                        </button>
                        <?php
                        }
                        ?>
                    </div>
                </div>
                <?php
                if(is_array($points) && count($points) >= 2){
                ?>
                <div class="flex justify-between">
                    <div class="w-auto"></div>
                    <div class="pt-16 w-full //md:w-60">
                        <div class="w-full bg-white bg-[#F2F3F5] overflow-hidden select-none [-webkit-user-select:none] [-webkit-touch-callout:none]">
                            <div class="rounded overflow-hidden">
                                <div class="p-3 flex items-center justify-between bg-[#F2F3F5] relative z-1">
                                    <div class="text-[10px] text-[#A2A2A2] flex"> تغییرات:<div class="change-percent flex"></div></div>
                                    <span class="text-[10px] text-[#A2A2A2]">قیمت (تومان)</span>
                                </div>
                                <div class="transition-all duration-300 select-none [-webkit-user-select:none] [-webkit-touch-callout:none]">
                                    <div class="relative w-full select-none [-webkit-user-select:none] [-webkit-touch-callout:none] cursor-crosshair">
                                        <div>
                                            <div id="priceChart" data-series='<?=esc_attr($series_payload)?>'></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php
                }
                ?>
            </div>
            <aside class="purchase-panel hidden md:flex" aria-labelledby="pricing">
                <?php
                if (!$is_available_for_purchase){
                    ?>
                    <div class="product_isNot_available">
                        این کالا فعلا موجود نیست!
                    </div>
                    <button type="button" class="btn btn--outline btn--block mb-2 Button-stock-alert-toggle" data-product-id="<?=esc_attr($product->get_id())?>" data-default-mobile="<?=esc_attr($alert_default_mobile)?>">
                        <svg style="width: 24px;height: 24px;fill: #6c3bff;"><path fill-rule="evenodd" d="M3.667 13.886A2.001 2.001 0 005 12V9a7 7 0 0114 0v3c0 .854.54 1.606 1.333 1.886a1 1 0 01.667.943V19a1 1 0 01-1 1H4a1 1 0 01-1-1v-4.17a1 1 0 01.667-.944zM19 18v-2.535A4 4 0 0117 12V9A5 5 0 007 9v3a4 4 0 01-2 3.465V18h14zm-7 5c-1.385 0-2.563-.835-3-2h6c-.437 1.165-1.615 2-3 2zm6.02-19.262l1.504-1.318a9.964 9.964 0 012.477 6.589h-2a7.964 7.964 0 00-1.981-5.27zM4 9.008c0-1.966.711-3.82 1.981-5.27L4.477 2.42A9.964 9.964 0 002 9.009h2z" clip-rule="evenodd"></path></svg>
                        وقتی موجود شد خبرم کن
                    </button>
                    <?php
                }
                ?>
                <div>
                    <?php
                    if ($sale_to_ts){
                        ?>
                        <div class="flex items-center SJDHEJDS">
                            <div class="deal_title">
                                <span class="deal_title_main">پیشنـهاد شگفت انگیـز</span>
                                <span class="deal_title_sub">فرصت باقی مانده</span>
                            </div>
                            <div class="d-flex product-offers-timer" data-due-date="<?= date('Y-m-d H:i:s', $sale_to_ts); ?>">
                                <div class="inner">
                                <span class="countdown-section">
                                    <span class="w-px rounded-full bg-stone-950/10"></span>
                                    <span class="countdown-amount"></span>
                                    <span class="countdown-period">روز</span>
                                </span>
                                    <span class="countdown-section">
                                        <span class="w-px rounded-full bg-stone-950/10"></span>
                                    <span class="countdown-amount"></span>
                                    <span class="countdown-period">ساعت</span>
                                </span>
                                    <span class="countdown-section">
                                        <span class="w-px rounded-full bg-stone-950/10"></span>
                                    <span class="countdown-amount"></span>
                                    <span class="countdown-period">دقیقه</span>
                                </span>
                                    <span class="countdown-section">
                                    <span class="countdown-amount"></span>
                                    <span class="countdown-period">ثانیه</span>
                                </span>
                                </div>
                            </div>
                        </div>
                        <?php
                    }
                    ?>
                    <div class="price-display">
                            <span class="price-display__label">قیمت نهایی</span>
                            <div class="d-flex flex-col mt-2">
                                <?php
                                if ($product->is_on_sale()){
                                    ?>
                                    <strong class="price-display__value card__originalPrice line-height-12" id="priceValue"><?=number_format_usd($regular)?></strong>
                                    <?php
                                }
                                ?>
                                <strong class="price-display__value line-height-27" id="priceValue" data-id="<?=$product->get_id()?>" data-target="<?=payment_usd($product->is_on_sale() ? $sale :$regular)?>"><?=number_format_usd($product->is_on_sale() ? $sale :$regular) != 0 ? number_format_usd($product->is_on_sale() ? $sale :$regular) . "تومان" : 'رایگان'?></strong>
                            </div>
                            <span class="price-display__note">پرداخت امن آنلاین • <?=isset($delivery['two']) && $delivery['two'] == 'on' ? 'پیش فروش' : 'ارسال کد آنی'?></span>
                    </div>
                </div>
                <div class="purchase-panel__actions">
                    <?php
                    if ($is_available_for_purchase){
                        ?>
                        <div class="overflow-hidden h-5 mt-3">
                            <div class="product‑slider" style="transform: translateY(0px); transition-duration: 300ms;">
                                <?php
                                if ((isset($delivery['one']) && $delivery['one'] == 'on') && $countAvailable <=3){
                                ?>
                                <div class="flex items-center h-5 overflow-hidden whitespace-nowrap">
                                    <div class="flex ml-1" aria-hidden="false">
                                        <div aria-hidden="true" style="width: 18px; height: 18px; line-height: 0;"><img class="w-full" src="<?=get_template_directory_uri()?>/assets/img/svg/54419b9303246cde131fcb5b251b86f2ab4aeb71_1716833765.svg" width="18" height="18" style="object-fit: cover;"></div>
                                    </div>
                                    <p class="text-body2-strong" style="color: rgb(211, 47, 47);">تنها <?=$countAvailable?> عدد در انبار باقی مانده</p>
                                </div>
                                <?php
                                }
                                ?>
                                <div class="flex items-center h-5 overflow-hidden whitespace-nowrap">
                                    <div class="flex ml-1" aria-hidden="false">
                                        <div aria-hidden="true" style="width: 18px; height: 18px; line-height: 0;"><img class="w-full" src="<?=get_template_directory_uri()?>/assets/img/svg/54419b9303246cde131fcb5b251b86f2ab4aeb71_1716833765.svg" width="18" height="18" style="object-fit: cover;"></div>
                                    </div>
                                    <p class="text-body2-strong" style="color: rgb(16, 126, 24);"><?=rand(1, 50)?>+ فروش در هفته گذشته</p>
                                </div>
                                <div class="flex items-center h-5 overflow-hidden whitespace-nowrap">
                                    <div class="flex ml-1" aria-hidden="false">
                                        <div aria-hidden="true" style="width: 18px; height: 18px; line-height: 0;"><img class="w-full" src="<?=get_template_directory_uri()?>/assets/img/svg/b0d6bb54a0077253781cdce04f9e16a34edc5299_1716833794.svg" width="18" height="18" style="object-fit: cover;"></div>
                                    </div>
                                    <p class="text-body2-strong" style="color: rgb(0, 126, 148);">در سبد خرید <?=rand(1, 25)?>+ نفر</p>
                                </div>
                            </div>
                        </div>
                        <?php
                        if (\Giftmax\Modules\UserModel::setting("buy") === true){
                        ?>
                            <button type="button" class="btn  btn--gradient btn--block Button-ac13 mb-2 animation-add-to-cart" data-product-id="<?php echo $product->get_id(); ?>"><span class="A-item">افزودن به سبد خرید</span><svg class="icon_add" viewBox="0 0 32 32"><path d="M11.201 4c-2.987 0-4.666-0.068-6.227 0.727-1.254 0.639-2.275 1.66-2.914 2.914-0.795 1.56-0.727 3.24-0.727 6.227v2.133c0 0.736 0.597 1.333 1.333 1.333v0c0.736 0 1.333-0.597 1.333-1.333v0-2.133c0-2.987 0.067-4.294 0.435-5.016 0.384-0.753 0.997-1.366 1.75-1.75 0.721-0.368 2.029-0.435 5.016-0.435h7.201c1.564 0 2.226 0.019 2.698 0.154 0.477 0.136 0.923 0.359 1.318 0.659 0.391 0.297 0.804 0.816 1.742 2.068l2.56 3.414c1.033 1.377 1.421 1.96 1.526 2.359 0.117 0.445 0.117 0.914 0 1.359-0.105 0.4-0.493 0.982-1.526 2.359l-2.56 3.414c-0.939 1.252-1.351 1.771-1.742 2.068-0.395 0.3-0.841 0.523-1.318 0.659-0.472 0.135-1.134 0.154-2.698 0.154h-5.068c-0.736 0-1.333 0.597-1.333 1.333v0c0 0.736 0.597 1.333 1.333 1.333v0h5.068c1.564 0 2.466 0.020 3.43-0.255 0.795-0.227 1.539-0.602 2.198-1.102 0.799-0.606 1.327-1.34 2.266-2.591l2.56-3.411c1.033-1.377 1.678-2.171 1.971-3.284 0.234-0.89 0.234-1.824 0-2.714-0.293-1.112-0.939-1.907-1.971-3.284l-2.56-3.411c-0.939-1.252-1.467-1.985-2.266-2.591-0.658-0.5-1.403-0.875-2.198-1.102-0.964-0.275-1.865-0.255-3.43-0.255zM22.667 16c0 1.473-1.194 2.667-2.667 2.667s-2.667-1.194-2.667-2.667c0-1.473 1.194-2.667 2.667-2.667s2.667 1.194 2.667 2.667zM5.333 18.667c-0.736 0-1.333 0.597-1.333 1.333v0 8c0 0.736 0.597 1.333 1.333 1.333v0c0.736 0 1.333-0.597 1.333-1.333v0-8c0-0.736-0.597-1.333-1.333-1.333v0zM1.333 22.667c-0.736 0-1.333 0.597-1.333 1.333v0c0 0.736 0.597 1.333 1.333 1.333v0h8c0.736 0 1.333-0.597 1.333-1.333v0c0-0.736-0.597-1.333-1.333-1.333v0z"></path</svg></button>
                        <?php
                        }else{?>
                            <button type="button" class="btn btn-buy-disable mb-2" >خرید از سایت غیرفعال هست</button>
                            <?php
                        }
                        if (isset($delivery['two']) && $delivery['two'] == 'on' && $delivery['description']){
                            ?>
                            <div class="alert alert-sm alert-orange text-2xs leading-sm font-normal mb-2 rounded-sm"><?=$delivery['description']?></div>
                    <?php
                        }
                    }
                    ?>
                    <button type="button" class="btn btn--outline btn--block Button-bf54 mb-2<?=!$is_available_for_purchase ? ' mt-3' : ''?>">خرید سریع</button>
                    <div class="flex justify-between">
                        <?php
                        if (!empty($settings[0]['linkUsing'])){?>
                            <a href="<?=$settings[0]['linkUsing']?>" class="product-single__link text-secondary w-100 d-flex align-items-center justify-center rounded-3">
                                آموزش استفاده از محصول
                            </a>
                            <?php
                        }
                        ?>
                        <?php
                        $is_in_wishlist = false;
                        if (is_user_logged_in()) {
                            global $wpdb;
                            $wishlist_db = \Giftmax\Modules\Db::getLnstance();
                            $wishlist_item = $wishlist_db->first("SELECT `id` FROM `{$wpdb->prefix}user_wishlist` WHERE `user_id`=:user_id AND `product_id`=:product_id", array(
                                'user_id' => get_current_user_id(),
                                'product_id' => $product->get_id(),
                            ));
                            $is_in_wishlist = !empty($wishlist_item);
                        ?>
                        <button class="add-to__favorites Button-alu84 <?=$is_in_wishlist ? 'is-active' : ''?>" data-product-id="<?=esc_attr($product->get_id())?>" data-auth="<?=is_user_logged_in() ? '1' : '0'?>">
                            <svg viewBox="0 0 24 24" style="width: 52%;">
                                <path d="M12.62 20.81C12.28 20.93 11.72 20.93 11.38 20.81C8.48 19.82 2 15.69 2 8.68998C2 5.59998 4.49 3.09998 7.56 3.09998C9.38 3.09998 10.99 3.97998 12 5.33998C13.01 3.97998 14.63 3.09998 16.44 3.09998C19.51 3.09998 22 5.59998 22 8.68998C22 15.69 15.52 19.82 12.62 20.81Z" fill="<?=$is_in_wishlist ? '#ef4444' : 'none'?>" stroke="<?=$is_in_wishlist ? '#ef4444' : 'inherit'?>" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                            </svg>
                        </button>
                        <?php
                        }
                        ?>
                    </div>
                    <button class="Button-cu46 support-buy">
                        <i class="icon-support"></i>
                        <div>سوالی دارید؟
                            <span>ارتباط با پشتیبانی</span>
                        </div>
                    </button>
                </div>
                <?php
                $rules = get_post_meta(get_the_ID(), 'giftmax_box_rules', true);
                if (!empty($rules) && isset($rules[0]['comment_switch']) && $rules[0]['comment_switch']=="on"){
                if (!empty($rules[0]['items']) && is_array($rules[0]['items'])) {
                    ?>
                <div class="product_sellinfo hidden md:block">
                    <span class="el_info_icon">
                        <svg class="pack-theme" viewBox="0 0 24 24">
                            <path d="M12.37 8.87988H17.62" stroke="inherit" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                            <path d="M6.38 8.87988L7.13 9.62988L9.38 7.37988" stroke="inherit" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                            <path d="M12.37 15.8799H17.62" stroke="inherit" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                            <path d="M6.38 15.8799L7.13 16.6299L9.38 14.3799" stroke="inherit" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                            <path d="M9 22H15C20 22 22 20 22 15V9C22 4 20 2 15 2H9C4 2 2 4 2 9V15C2 20 4 22 9 22Z" stroke="inherit" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                        </svg>                        قوانین استفاده
                    </span>
                    <ul>
                <?php
                    foreach ($rules[0]['items'] as $key => $item) {
                        ?>
                        <li>
                            <?=$item['description']?>
                        </li>
                        <?php
                    }
                }?>
                    </ul>
                </div>
                <?php
                }
                ?>
            </aside>
        </div>

        <?php
        if (!empty($rules) && isset($rules[0]['comment_switch']) && $rules[0]['comment_switch']=="on"){
        if (!empty($rules[0]['items']) && is_array($rules[0]['items'])) {
        ?>
        <div class="product_sellinfo block md:hidden">
                    <span class="el_info_icon">
                        <svg class="pack-theme" viewBox="0 0 24 24">
                            <path d="M12.37 8.87988H17.62" stroke="inherit" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                            <path d="M6.38 8.87988L7.13 9.62988L9.38 7.37988" stroke="inherit" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                            <path d="M12.37 15.8799H17.62" stroke="inherit" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                            <path d="M6.38 15.8799L7.13 16.6299L9.38 14.3799" stroke="inherit" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                            <path d="M9 22H15C20 22 22 20 22 15V9C22 4 20 2 15 2H9C4 2 2 4 2 9V15C2 20 4 22 9 22Z" stroke="inherit" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                        </svg>                        قوانین استفاده
                    </span>
            <ul>
                <?php
                foreach ($rules[0]['items'] as $key => $item) {
                ?>
                <li>
                    <?=$item['description']?>
                </li>
                <?php
                }
                }?>
            </ul>
        </div>
        <?php
        }
        ?>
    </section>
    <section class="container-xl-w mx-auto">
        <div class="act-product-title-bg">
            <div class="gp-product-tabs-nav">
                <?php
                if (!empty(trim(get_the_content()))){
                    ?>
                    <button class="gp-tab-btn" data-target="tab_1" type="button">
                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="currentcolor"><path d="M13.3333 1.66626H6.66667C3.75 1.66626 2.5 3.33293 2.5 5.83293V14.1663C2.5 16.6663 3.75 18.3329 6.66667 18.3329H13.3333C16.25 18.3329 17.5 16.6663 17.5 14.1663V5.83293C17.5 3.33293 16.25 1.66626 13.3333 1.66626ZM6.66667 10.2079H10C10.3417 10.2079 10.625 10.4913 10.625 10.8329C10.625 11.1746 10.3417 11.4579 10 11.4579H6.66667C6.325 11.4579 6.04167 11.1746 6.04167 10.8329C6.04167 10.4913 6.325 10.2079 6.66667 10.2079ZM13.3333 14.7913H6.66667C6.325 14.7913 6.04167 14.5079 6.04167 14.1663C6.04167 13.8246 6.325 13.5413 6.66667 13.5413H13.3333C13.675 13.5413 13.9583 13.8246 13.9583 14.1663C13.9583 14.5079 13.675 14.7913 13.3333 14.7913ZM15.4167 7.70793H13.75C12.4833 7.70793 11.4583 6.68293 11.4583 5.41626V3.74959C11.4583 3.40793 11.7417 3.12459 12.0833 3.12459C12.425 3.12459 12.7083 3.40793 12.7083 3.74959V5.41626C12.7083 5.99126 13.175 6.45793 13.75 6.45793H15.4167C15.7583 6.45793 16.0417 6.74126 16.0417 7.08293C16.0417 7.42459 15.7583 7.70793 15.4167 7.70793Z"></path></svg>
                        <span class="gp-btn-title">توضیحات محصول</span>
                    </button>
                    <?php
                }
                ?>
                <button class="gp-tab-btn" data-target="tab_3" type="button">
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="currentcolor"><path d="M12.992 10.3333V13.725C12.992 14.025 12.9587 14.3083 12.8837 14.5667C12.5753 15.7917 11.5587 16.5583 10.1587 16.5583H7.89199L5.37533 18.2333C5.00033 18.4917 4.50033 18.2167 4.50033 17.7667V16.5583C3.65033 16.5583 2.94199 16.275 2.45033 15.7833C1.95033 15.2833 1.66699 14.575 1.66699 13.725V10.3333C1.66699 8.75 2.65033 7.65833 4.16699 7.51667C4.27533 7.50833 4.38366 7.5 4.50033 7.5H10.1587C11.8587 7.5 12.992 8.63333 12.992 10.3333Z"></path><path d="M14.792 13.0001C15.8503 13.0001 16.742 12.6501 17.3587 12.0251C17.9837 11.4084 18.3337 10.5167 18.3337 9.45842V5.20841C18.3337 3.25008 16.7503 1.66675 14.792 1.66675H7.70866C5.75033 1.66675 4.16699 3.25008 4.16699 5.20841V5.83341C4.16699 6.06675 4.35033 6.25008 4.58366 6.25008H10.1587C12.417 6.25008 14.242 8.07508 14.242 10.3334V12.5834C14.242 12.8167 14.4253 13.0001 14.6587 13.0001H14.792Z"></path></svg>
                    <span class="gp-btn-title">دیدگاه های کاربران</span>
                </button>
            </div>
        </div>
    </section>
    <section class="container-xl-w mx-auto flex mt-18 sGsfe5">
        <div class="lg:w-75">
            <div class="gp-product-tabs-content">
                <?php
                if (!empty(trim(get_the_content()))){
                    ?>
                    <div class="gp-tab-content" id="tab_1">
                        <div class="gp-tab-content-inner-head">
                            <svg class="gp-tab-content-inner-head-svg" xmlns="http://www.w3.org/2000/svg" width="1281" height="75" viewBox="0 0 1281 75" fill="none">
                                <path d="M1280.47 0.5H1074.43C1060.3 0.5 1053.23 0.5 1047.29 2.99163C1042.55 4.9789 1038.36 8.07733 1035.08 12.025C1030.96 16.9747 1028.89 23.7331 1024.75 37.25C1020.61 50.7669 1018.54 57.5253 1014.42 62.475C1011.14 66.4227 1006.95 69.5211 1002.21 71.5084C996.271 74 989.203 74 975.067 74H591.882C578.847 74 572.329 74 566.813 71.8926C561.12 69.7177 556.167 65.9625 552.536 61.0686C549.017 56.3267 547.257 50.0512 543.737 37.5C540.217 24.9488 538.457 18.6733 534.938 13.9314C531.307 9.0375 526.353 5.2823 520.661 3.10737C515.145 1 508.627 1 495.592 1H0" stroke="url(#paint0_linear_26_6497)"></path>
                                <defs>
                                    <linearGradient id="paint0_linear_26_6497" x1="29.4736" y1="0.500002" x2="1213.79" y2="-28.0511" gradientUnits="userSpaceOnUse">
                                        <stop stop-color="#0B61FF" stop-opacity="0"></stop>
                                        <stop offset="0.5" stop-color="#0B61FF"></stop>
                                        <stop offset="1" stop-color="#0B61FF" stop-opacity="0"></stop>
                                    </linearGradient>
                                </defs>
                            </svg>

                            <div class="act-our-services-carousel-head-title">
                                <div class="act-our-services-carousel-head-title-divs">
                                    <div class="act-our-services-carousel-head-title-div1"></div>
                                    <div class="act-our-services-carousel-head-title-div2"></div>
                                </div>
                                <div class="act-our-services-carousel-head-title-content gp-tab-content-title">
                                    <h5>توضیحات <strong>محصول</strong></h5>                                        <p class="text-only">Product Description</p>
                                </div>
                            </div>
                            <div class="gp-tab-content-inner-head-text-box fhfjdfk5" style=" max-width: 410px; ">
                                <p class="gp-tab-content-inner-head-text ">
                                    با انتخاب
                                    <strong>محصول مناسب خود</strong>
                                    ، تجربه&zwnj;ای بدون دغدغه از استفاده از حساب&zwnj;های پریمیوم خواهید داشت.
                                </p>

                            </div>

                        </div>
                        <div class="gp-tab-content-inner mce-content-body">
                            <?=the_content()?>
                        </div>
                    </div>
                    <?php
                }

                    ?>
                <div class="gp-tab-content gp-commnets-tab-content" id="tab_3">
                    <div class="gp-tab-content-inner-head">

                        <svg class="gp-tab-content-inner-head-svg" xmlns="http://www.w3.org/2000/svg" width="1281" height="75" viewBox="0 0 1281 75" fill="none">
                            <path d="M1280.47 0.5H1074.43C1060.3 0.5 1053.23 0.5 1047.29 2.99163C1042.55 4.9789 1038.36 8.07733 1035.08 12.025C1030.96 16.9747 1028.89 23.7331 1024.75 37.25C1020.61 50.7669 1018.54 57.5253 1014.42 62.475C1011.14 66.4227 1006.95 69.5211 1002.21 71.5084C996.271 74 989.203 74 975.067 74H386.908C373.873 74 367.355 74 361.839 71.8926C356.147 69.7177 351.193 65.9625 347.562 61.0686C344.043 56.3267 342.283 50.0512 338.763 37.5C335.243 24.9488 333.483 18.6733 329.964 13.9314C326.333 9.0375 321.38 5.2823 315.687 3.10737C310.171 1 303.653 1 290.618 1L0 1" stroke="url(#paint0_linear_26_6509)"></path>
                            <defs>
                                <linearGradient id="paint0_linear_26_6509" x1="29.4736" y1="0.500002" x2="1213.79" y2="-28.0511" gradientUnits="userSpaceOnUse">
                                    <stop stop-color="#0B61FF" stop-opacity="0"></stop>
                                    <stop offset="0.5" stop-color="#0B61FF"></stop>
                                    <stop offset="1" stop-color="#0B61FF" stop-opacity="0"></stop>
                                </linearGradient>
                            </defs>
                        </svg>

                        <div class="act-our-services-carousel-head-title">
                            <div class="act-our-services-carousel-head-title-divs">
                                <div class="act-our-services-carousel-head-title-div1"></div>
                                <div class="act-our-services-carousel-head-title-div2"></div>
                            </div>
                            <div class="act-our-services-carousel-head-title-content gp-tab-content-title">
                                <h5>دیدگاه های <strong>کاربران</strong></h5>                                        <p class="text-only">User opinions</p>
                            </div>
                        </div>
                        <div class="gp-tab-content-inner-head-text-box">
                            <p class="gp-tab-content-inner-head-text ">
                                <strong>تجربه واقعی مشتریان</strong>
                                ما را بخوانید و ببینید چرا کاربران، خدمات ما را انتخاب می&zwnj;کنند.
                            </p>
                        </div>
                    </div>

                    <div class=" gp-tab-content-inner-customer-rew">

                        <?php
                        $user = wp_get_current_user();
                        ?>
                        <div id="reviews" class="woocommerce-Reviews act-product-reviews <?=!wc_customer_bought_product($user->user_email, $user->ID, $product->get_id()) || !empty($rules) && isset($rules[0]['comment_switch']) && $rules[0]['comment_switch']=="on" ?? 'd-flex'?>">
                            <div id="comments" class="act-product-comments <?=(!wc_customer_bought_product($user->user_email, $user->ID, $product->get_id()) || !empty($rules) && isset($rules[0]['comment_switch']) && $rules[0]['comment_switch']=="on") ?? 'lg:w-20'?>">
                                <?php
                                $comments = get_comments([
                                    'post_id' => $product->get_id(),
                                    'status'  => 'approve',
                                    'type'    => 'review'
                                ]);
                                if (!empty($comments)) {
                                    ?>
                                    <ol class="commentlist act-comment-list">
                                        <?php
                                        foreach ($comments as $comment) {
                                            $user_name = $comment->comment_author;
                                            if ($comment->user_id) {
                                                $ur = get_userdata($comment->user_id);
                                                if ($ur) {
                                                    $first = trim($ur->first_name);
                                                    $last  = trim($ur->last_name);

                                                    if ($first || $last) {
                                                        $user_name = trim($first . ' ' . $last);
                                                    } else {
                                                        $user_name = $ur->display_name;
                                                    }
                                                }
                                            }
                                            $rating = get_comment_meta($comment->comment_ID, 'rating', true);
                                            $comment_points = get_comment_meta($comment->comment_ID, 'comment_points', true);
                                            if (!is_array($comment_points)) {
                                                $comment_points = [];
                                            }

                                            ?>
                                            <li class="act-single-product-comment">
                                                <div class="act-comment-head">
                                                    <div class="act-comment-head-right">
                                                        <div class="act-comment-avatar">
                                                        </div>
                                                        <div class="act-comment-head-right-inner">
                                                            <div class="act-comment-author">
                                                                <div class="act-comment-author-name"><?=$user_name?></div>
                                                                <div class="act-comment-author-role">کاربر</div>
                                                            </div>
                                                            <div class="act-comment-rating">
                                                                <div class="act-comment-rating-starts">
                                                                    <?php
                                                                    for ($i = 1; $i <= $rating; $i++) {?>
                                                                        <svg class="act-star" width="15" height="14" viewBox="0 0 15 14" fill="currentcolor" xmlns="http://www.w3.org/2000/svg">
                                                                            <path d="M7.31445 0.5C7.34019 0.5 7.36145 0.507364 7.375 0.516602C7.38535 0.523702 7.39875 0.53724 7.40918 0.569336L8.72461 4.61719C8.87191 5.07034 9.29498 5.37695 9.77148 5.37695H14.0273C14.0613 5.37695 14.078 5.38685 14.0879 5.39453C14.1008 5.4046 14.1142 5.42195 14.1221 5.44629C14.13 5.47076 14.1296 5.49305 14.125 5.50879C14.1215 5.52082 14.1133 5.53776 14.0859 5.55762L10.6426 8.05957C10.257 8.33968 10.0959 8.83682 10.2432 9.29004L11.5586 13.3379C11.569 13.37 11.5648 13.3886 11.5605 13.4004C11.555 13.4157 11.543 13.4342 11.5225 13.4492C11.5018 13.4642 11.4802 13.4711 11.4639 13.4717C11.4513 13.4721 11.4318 13.4692 11.4043 13.4492L7.96094 10.9473C7.5755 10.6674 7.05341 10.6674 6.66797 10.9473L3.22461 13.4492C3.19712 13.4692 3.17759 13.4721 3.16504 13.4717C3.1487 13.4711 3.1271 13.4642 3.10645 13.4492C3.08587 13.4342 3.07387 13.4157 3.06836 13.4004C3.06414 13.3886 3.05993 13.37 3.07031 13.3379L4.38574 9.29004C4.533 8.83681 4.37186 8.33968 3.98633 8.05957L0.542969 5.55762C0.515656 5.53776 0.507452 5.52082 0.503906 5.50879C0.49931 5.49305 0.498887 5.47076 0.506836 5.44629C0.514743 5.42195 0.528109 5.4046 0.541016 5.39453C0.550944 5.38685 0.567581 5.37695 0.601562 5.37695H4.85742C5.33393 5.37695 5.757 5.07034 5.9043 4.61719L7.21973 0.569336C7.23016 0.53724 7.24356 0.523703 7.25391 0.516602C7.26746 0.507364 7.28871 0.5 7.31445 0.5Z"></path>
                                                                        </svg>
                                                                        <?php
                                                                    }
                                                                    for ($i = 1; $i <= 5-$rating; $i++) {?>
                                                                        <svg class="act-star-empty" width="15" height="14" viewBox="0 0 15 14" fill="none" stroke="currentcolor" xmlns="http://www.w3.org/2000/svg">
                                                                            <path d="M7.31445 0.5C7.34019 0.5 7.36145 0.507364 7.375 0.516602C7.38535 0.523702 7.39875 0.53724 7.40918 0.569336L8.72461 4.61719C8.87191 5.07034 9.29498 5.37695 9.77148 5.37695H14.0273C14.0613 5.37695 14.078 5.38685 14.0879 5.39453C14.1008 5.4046 14.1142 5.42195 14.1221 5.44629C14.13 5.47076 14.1296 5.49305 14.125 5.50879C14.1215 5.52082 14.1133 5.53776 14.0859 5.55762L10.6426 8.05957C10.257 8.33968 10.0959 8.83682 10.2432 9.29004L11.5586 13.3379C11.569 13.37 11.5648 13.3886 11.5605 13.4004C11.555 13.4157 11.543 13.4342 11.5225 13.4492C11.5018 13.4642 11.4802 13.4711 11.4639 13.4717C11.4513 13.4721 11.4318 13.4692 11.4043 13.4492L7.96094 10.9473C7.5755 10.6674 7.05341 10.6674 6.66797 10.9473L3.22461 13.4492C3.19712 13.4692 3.17759 13.4721 3.16504 13.4717C3.1487 13.4711 3.1271 13.4642 3.10645 13.4492C3.08587 13.4342 3.07387 13.4157 3.06836 13.4004C3.06414 13.3886 3.05993 13.37 3.07031 13.3379L4.38574 9.29004C4.533 8.83681 4.37186 8.33968 3.98633 8.05957L0.542969 5.55762C0.515656 5.53776 0.507452 5.52082 0.503906 5.50879C0.49931 5.49305 0.498887 5.47076 0.506836 5.44629C0.514743 5.42195 0.528109 5.4046 0.541016 5.39453C0.550944 5.38685 0.567581 5.37695 0.601562 5.37695H4.85742C5.33393 5.37695 5.757 5.07034 5.9043 4.61719L7.21973 0.569336C7.23016 0.53724 7.24356 0.523703 7.25391 0.516602C7.26746 0.507364 7.28871 0.5 7.31445 0.5Z"></path>
                                                                        </svg>
                                                                        <?php
                                                                    }
                                                                    ?>
                                                                </div>
                                                                <div class="act-comment-ratdiv"></div>
                                                                <span class="act-comment-rating-num">( <?=$rating?>.0)</span>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="act-hor-bor"></div>

                                                <div class="act-comment-content">
                                                    <?=   wpautop(esc_html($comment->comment_content)) ?>
                                                </div>
                                                <?php
                                                if (!empty($comment_points)) {
                                                    ?>
                                                    <div class="mt-3">
                                                        <p class="text-body2-strong color-n-700 mb-1">نکات مفید:</p>
                                                        <div class="sytle-cods_ddef">
                                                            <?php
                                                            foreach ($comment_points as $point_item) {
                                                                ?>
                                                                <div class="style-df__dkd4"><div class="flex justify-between align-items-center"><p class="text-body2-strong color-n-700 text-color-neutral-700"><?=esc_html($point_item)?></p></div></div>
                                                                <?php
                                                            }
                                                            ?>
                                                        </div>
                                                    </div>
                                                    <?php
                                                }
                                                ?>
                                            </li>
                                            <?php
                                        }
                                        ?>
                                    </ol>
                                    <?php
                                }else{
                                    ?>
                                    <p class="woocommerce-noreviews text-only">هنوز دیدگاهی ثبت نشده است.</p>
                                    <?php
                                }
                                ?>
                            </div>
                            <?php
                            if (is_user_logged_in()){
                                ?>
                                <div id="review_form_wrapper" class="act-review-form-wrapper <?=!empty($rules) && isset($rules[0]['comment_switch']) && $rules[0]['comment_switch']=="on" ?? 'lg:w-80'?>">
                                    <div id="review_form" class="act-review-form">

                                        <svg class="act-review-form-bg" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="955" height="372" viewBox="0 0 955 372" fill="currentcolor">
                                            <mask id="path-2-inside-1_26_6465" fill="white">
                                                <path d="M955 90C955 76.7451 944.255 66 931 66H701.738C694.332 66 687.341 62.5806 682.794 56.7345L645.873 9.2655C641.326 3.41937 634.335 0 626.929 0H24C10.7451 0 0 10.7452 0 24V536C0 549.255 10.7452 560 24 560H931C944.255 560 955 549.255 955 536V90Z"></path>
                                            </mask>
                                            <path d="M955 90C955 76.7451 944.255 66 931 66H701.738C694.332 66 687.341 62.5806 682.794 56.7345L645.873 9.2655C641.326 3.41937 634.335 0 626.929 0H24C10.7451 0 0 10.7452 0 24V536C0 549.255 10.7452 560 24 560H931C944.255 560 955 549.255 955 536V90Z"></path>
                                            <path d="M645.873 9.2655L646.663 8.65155L645.873 9.2655ZM682.794 56.7345L682.004 57.3484L682.794 56.7345ZM931 66V67H701.738V66V65H931V66ZM682.794 56.7345L682.004 57.3484L645.084 9.87946L645.873 9.2655L646.663 8.65155L683.583 56.1206L682.794 56.7345ZM626.929 0V1H24V0V-1H626.929V0ZM0 24H1V536H0H-1V24H0ZM24 560V559H931V560V561H24V560ZM955 536H954V90H955H956V536H955ZM931 560V559C943.703 559 954 548.703 954 536H955H956C956 549.807 944.807 561 931 561V560ZM0 536H1C1 548.703 11.2975 559 24 559V560V561C10.1929 561 -1 549.807 -1 536H0ZM24 0V1C11.2974 1 1 11.2974 1 24H0H-1C-1 10.1929 10.1929 -1 24 -1V0ZM645.873 9.2655L645.084 9.87946C640.727 4.27692 634.027 1 626.929 1V0V-1C634.644 -1 641.926 2.56189 646.663 8.65155L645.873 9.2655ZM701.738 66V67C694.023 67 686.741 63.4381 682.004 57.3484L682.794 56.7345L683.583 56.1206C687.94 61.7231 694.64 65 701.738 65V66ZM931 66V65C944.807 65 956 76.1929 956 90H955H954C954 77.2974 943.703 67 931 67V66Z" fill="#0B1530" fill-opacity="0.06" mask="url(#path-2-inside-1_26_6465)"></path>
                                        </svg>

                                        <div class="act-special-carousel-head">
                                            <h3> ثبت <strong> دیدگاه شما  </strong></h3>
                                        </div>

                                        <div id="respond" class="comment-respond">
                                            <h3 id="reply-title" class="comment-reply-title">
                                            </h3>
                                            <form method="post" id="commentform" class="comment-form">
                                                <div class="act-form-field act-form-textarea">
                                                    <label>دیدگاه شما</label>
                                                    <textarea placeholder="دیدگاه شما ..." id="comment" name="comment" cols="45" rows="6"></textarea>
                                                    <p class="form-submit">
                                                        <button type="submit" class="act-btn act-sabt-didgah">ثبت دیدگاه</button>
                                                        <input type="hidden" name="comment_post_ID" value="<?=$product->get_id()?>" id="comment_post_ID">
                                                    </p>
                                                </div>
                                                <div class="act-form-field-form">
                                                    <div class="act-form-field comment-form-rating">
                                                        <label for="rating">امتیاز</label>
                                                        <select name="rating" id="rating" required="" style="display:none;">
                                                            <option value="">انتخاب امتیاز...</option>
                                                            <option value="5">5.0</option>
                                                            <option value="4">4.0</option>
                                                            <option value="3">3.0</option>
                                                            <option value="2">2.0</option>
                                                            <option value="1">1.0</option>
                                                        </select>
                                                        <div class="act-comments-rating-box">
                                                            <span class="act-rating-max-label">5.0</span>
                                                            <ul class="act-rating-list">
                                                                <li data-value="5" class="active"><a href="#">5.0</a></li>
                                                                <li data-value="4" class=""><a href="#">4.0</a></li>
                                                                <li data-value="3" class=""><a href="#">3.0</a></li>
                                                                <li data-value="2"><a href="#">2.0</a></li>
                                                                <li data-value="1"><a href="#">1.0</a></li>
                                                            </ul>

                                                            <span class="act-rating-max">از ۵.۰</span>
                                                        </div>

                                                    </div>
                                                    <div class="act-form-field">
                                                        <label>نکات مفید</label>
                                                        <div class="flex justify-between align-items-center">
                                                            <input placeholder="مثال: اتصال راحت" class="lg:w-100 ml-1" name="point" type="text">
                                                            <button type="button" class="btn !text-5xs !pt-2 btn-white btn-icon icon-plus relative Button-ap45"></button>
                                                        </div>
                                                    </div>
                                                    <div class="div__point"></div>

                                                </div>
                                            </form>
                                        </div><!-- #respond -->
                                    </div>
                                </div>
                                <?php
                            }
                            ?>
                            <div class="clear"></div>
                        </div>
                    </div>
                </div>


            </div>
        </div>
        <div class="lg:w-25">
            <div class="styles_MiniBuyBox__stickyAnimation__uFMh2 hidden md:flex">
                <div class="SK5fD">
                    <div class="border-complete-b-200 pb-3 mb-3">
                        <?php
                        if ($sale_to_ts){
                            ?>
                            <div class="flex justify-between SD4ISd6">
                                <div>
                                    <img class="w-full inline-block" src="<?=get_template_directory_uri()?>/assets/img/svg/IncredibleOffer.svg" width="139" height="16" alt="" title="" style="object-fit: contain;">
                                </div>
                                <div class="flex items-center">
                                    <div class="text-primary-700 text-body2-strong style_ProductPromotionTimeline__timer__zS6ZA"><?= date('Y-m-d H:i:s', $sale_to_ts); ?></div>
                                </div>
                            </div>
                            <?php
                        }
                        ?>
                        <div class="mr-5">
                            <p class="ellipsis-2"><?=get_the_title()?></p>

                        </div>
                    </div>
                    <div>

                        <?php
                        if (!empty($settings[0]['purchaseScore'])){?>
                            <div class="purchaseScore" style="margin: 0 0 10px 0 !important;">
                                <i class="icon-star"></i>
                                با خرید این گیفت کارت <strong class="font-bold"><?=$settings[0]['purchaseScore']?> امتیاز</strong> دریافت میکنید
                            </div>
                            <?php
                        }
                        ?>
                        <div class="flex items-center mb-1">
                            <button type="button" class="btn btn--outline btn--block Button-bf54 ml-1" style="width: 33%;font-size: 12px;padding: 11px 10px;">خرید سریع</button>
                            <div class="flex justify-start relative flex-col items-end mr-auto text-h3">
                                <?php
                                if ($product->is_on_sale()){
                                    ?>
                                    <div class="flex items-center justify-end w-full gap-1" data-theme-animation="price-container">
                                        <span class="line-through text-body-2 ml-1 text-neutral-300" data-testid="price-no-discount"><?=number_format_usd($regular)?></span>
                                        <div class="px-1 text-white rounded-large flex items-center justify-center ProductPrice_ProductPrice__discountWrapper__1Ru_1 bg-hint-object-error shrink-0 mr-1 mb-1">
                                            <span class="text-body2-strong" data-testid="price-discount-percent"><?=get_discount_percent($product)?>٪</span>
                                        </div>
                                    </div>
                                    <?php
                                }
                                ?>
                                <div class="flex flex-row items-center">
                                    <span class="ml-1 text-neutral-800 text-h4-compact" data-testid="price-final" id="priceValue" data-id="<?=$product->get_id()?>" data-target="<?=payment_usd($product->is_on_sale() ? $sale :$regular)?>"><?=number_format_usd($product->is_on_sale() ? $sale :$regular)?></span>
                                    <div class="font-size-12">
                                        تومان
                                    </div>
                                </div>
                            </div>
                        </div>

                        <?php
                        if ($is_available_for_purchase){
                            ?>
                                <div class="overflow-hidden h-5 mb-3">
                                    <div class="product_slider" style="transform: translateY(0px); transition-duration: 300ms;">
                                <?php
                                if ((isset($delivery['one']) && $delivery['one'] == 'on') && $countAvailable <=3){
                                    ?>
                                    <div class="flex items-center h-5 overflow-hidden whitespace-nowrap">
                                        <div class="flex ml-1" aria-hidden="false">
                                            <div aria-hidden="true" style="width: 18px; height: 18px; line-height: 0;"><img class="w-full" src="<?=get_template_directory_uri()?>/assets/img/svg/54419b9303246cde131fcb5b251b86f2ab4aeb71_1716833765.svg" width="18" height="18" style="object-fit: cover;"></div>
                                        </div>
                                        <p class="text-body2-strong" style="color: rgb(211, 47, 47);">تنها <?=$countAvailable?> عدد در انبار باقی مانده</p>
                                    </div>
                                    <?php
                                }
                                ?>
                                <div class="flex items-center h-5 overflow-hidden whitespace-nowrap">
                                    <div class="flex ml-1" aria-hidden="false">
                                        <div aria-hidden="true" style="width: 18px; height: 18px; line-height: 0;"><img class="w-full" src="<?=get_template_directory_uri()?>/assets/img/svg/54419b9303246cde131fcb5b251b86f2ab4aeb71_1716833765.svg" width="18" height="18" style="object-fit: cover;"></div>
                                    </div>
                                    <p class="text-body2-strong" style="color: rgb(16, 126, 24);"><?=rand(1, 50)?>+ فروش در هفته گذشته</p>
                                </div>
                                <div class="flex items-center h-5 overflow-hidden whitespace-nowrap">
                                    <div class="flex ml-1" aria-hidden="false">
                                        <div aria-hidden="true" style="width: 18px; height: 18px; line-height: 0;"><img class="w-full" src="<?=get_template_directory_uri()?>/assets/img/svg/b0d6bb54a0077253781cdce04f9e16a34edc5299_1716833794.svg" width="18" height="18" style="object-fit: cover;"></div>
                                    </div>
                                    <p class="text-body2-strong" style="color: rgb(0, 126, 148);">در سبد خرید <?=rand(1, 25)?>+ نفر</p>
                                </div>
                            </div>
                                </div>
                            <?php
                            if (\Giftmax\Modules\UserModel::setting("buy") === true){
                                ?>
                                <button type="button" class="btn  btn--gradient btn--block Button-ac13 mb-2 animation-add-to-cart" data-product-id="<?php echo $product->get_id(); ?>"><span class="A-item">افزودن به سبد خرید</span><svg class="icon_add" viewBox="0 0 32 32"><path d="M11.201 4c-2.987 0-4.666-0.068-6.227 0.727-1.254 0.639-2.275 1.66-2.914 2.914-0.795 1.56-0.727 3.24-0.727 6.227v2.133c0 0.736 0.597 1.333 1.333 1.333v0c0.736 0 1.333-0.597 1.333-1.333v0-2.133c0-2.987 0.067-4.294 0.435-5.016 0.384-0.753 0.997-1.366 1.75-1.75 0.721-0.368 2.029-0.435 5.016-0.435h7.201c1.564 0 2.226 0.019 2.698 0.154 0.477 0.136 0.923 0.359 1.318 0.659 0.391 0.297 0.804 0.816 1.742 2.068l2.56 3.414c1.033 1.377 1.421 1.96 1.526 2.359 0.117 0.445 0.117 0.914 0 1.359-0.105 0.4-0.493 0.982-1.526 2.359l-2.56 3.414c-0.939 1.252-1.351 1.771-1.742 2.068-0.395 0.3-0.841 0.523-1.318 0.659-0.472 0.135-1.134 0.154-2.698 0.154h-5.068c-0.736 0-1.333 0.597-1.333 1.333v0c0 0.736 0.597 1.333 1.333 1.333v0h5.068c1.564 0 2.466 0.020 3.43-0.255 0.795-0.227 1.539-0.602 2.198-1.102 0.799-0.606 1.327-1.34 2.266-2.591l2.56-3.411c1.033-1.377 1.678-2.171 1.971-3.284 0.234-0.89 0.234-1.824 0-2.714-0.293-1.112-0.939-1.907-1.971-3.284l-2.56-3.411c-0.939-1.252-1.467-1.985-2.266-2.591-0.658-0.5-1.403-0.875-2.198-1.102-0.964-0.275-1.865-0.255-3.43-0.255zM22.667 16c0 1.473-1.194 2.667-2.667 2.667s-2.667-1.194-2.667-2.667c0-1.473 1.194-2.667 2.667-2.667s2.667 1.194 2.667 2.667zM5.333 18.667c-0.736 0-1.333 0.597-1.333 1.333v0 8c0 0.736 0.597 1.333 1.333 1.333v0c0.736 0 1.333-0.597 1.333-1.333v0-8c0-0.736-0.597-1.333-1.333-1.333v0zM1.333 22.667c-0.736 0-1.333 0.597-1.333 1.333v0c0 0.736 0.597 1.333 1.333 1.333v0h8c0.736 0 1.333-0.597 1.333-1.333v0c0-0.736-0.597-1.333-1.333-1.333v0z"></path</svg></button>
                                <?php
                            }else{?>
                                <button type="button" class="btn btn-buy-disable mb-2" >خرید از سایت غیرفعال هست</button>
                                <?php
                            }
                            ?>
                            <div class="flex justify-between">
                                <?php
                                if (!empty($settings[0]['linkUsing'])){?>
                                    <a href="<?=$settings[0]['linkUsing']?>" class="product-single__link text-secondary w-100 d-flex align-items-center justify-center rounded-3">
                                        آموزش استفاده از محصول
                                    </a>
                                    <?php
                                }
                                ?>
                            </div>

                            <?php
                        }
                        ?>
                        <?php
                        if (!$is_available_for_purchase) {
                            ?>
                            <button
                                    type="button"
                                    class="btn btn--outline btn--block mb-2 Button-stock-alert-toggle"
                                    data-product-id="<?=esc_attr($product->get_id())?>"
                                    data-default-mobile="<?=esc_attr($alert_default_mobile)?>"
                            >
                                <svg style="width: 24px;height: 24px;fill: #6c3bff;"><path fill-rule="evenodd" d="M3.667 13.886A2.001 2.001 0 005 12V9a7 7 0 0114 0v3c0 .854.54 1.606 1.333 1.886a1 1 0 01.667.943V19a1 1 0 01-1 1H4a1 1 0 01-1-1v-4.17a1 1 0 01.667-.944zM19 18v-2.535A4 4 0 0117 12V9A5 5 0 007 9v3a4 4 0 01-2 3.465V18h14zm-7 5c-1.385 0-2.563-.835-3-2h6c-.437 1.165-1.615 2-3 2zm6.02-19.262l1.504-1.318a9.964 9.964 0 012.477 6.589h-2a7.964 7.964 0 00-1.981-5.27zM4 9.008c0-1.966.711-3.82 1.981-5.27L4.477 2.42A9.964 9.964 0 002 9.009h2z" clip-rule="evenodd"></path></svg>
                                وقتی موجود شد خبرم کن
                            </button>
                            <?php
                        }
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <?php
    $faqs = get_post_meta($product->get_id(), 'giftmax_box_faq', true);
    if (!empty($faqs) && !empty($faqs[0]['comment_switch']) && $faqs[0]['comment_switch']=="on"){
        ?>
        <section class="container-xl-w mx-auto mt-18">
            <div class="act-faq-1st" id="tab_4">
                <svg xmlns="http://www.w3.org/2000/svg" fill="rgb(255, 255, 255)" viewBox="0 0 1280 145.75342465753423" width="100%" height="145.75342465753423" class="act-faq-svg-bg">
                    <mask fill="white" id="path-1-inside-1_29_20278">
                        <path d="M1280 90C1280 76.7451 1269.25 66 1256 66H1026.74C1019.33 66 1012.34 62.5806 1007.79 56.7345L970.873 9.2655C966.326 3.41937 959.335 0 951.929 0H24C10.7451 0 0 10.7452 0 24V536C0 549.255 10.7452 560 24 560H1256C1269.25 560 1280 549.255 1280 536V90Z"></path>
                    </mask>
                    <path d="M1280 90C1280 76.7451 1269.25 66 1256 66H1026.74C1019.33 66 1012.34 62.5806 1007.79 56.7345L970.873 9.2655C966.326 3.41937 959.335 0 951.929 0H24C10.7451 0 0 10.7452 0 24V536C0 549.255 10.7452 560 24 560H1256C1269.25 560 1280 549.255 1280 536V90Z"></path>
                    <path mask="url(#path-1-inside-1_29_20278)" class="act-faq-svg-border" fill="rgba(11, 21, 48, 0.06)" d="M970.873 9.2655L971.663 8.65155L970.873 9.2655ZM1007.79 56.7345L1007 57.3484L1007.79 56.7345ZM1256 66V67H1026.74V66V65H1256V66ZM1007.79 56.7345L1007 57.3484L970.084 9.87946L970.873 9.2655L971.663 8.65155L1008.58 56.1206L1007.79 56.7345ZM951.929 0V1H24V0V-1H951.929V0ZM0 24H1V536H0H-1V24H0ZM24 560V559H1256V560V561H24V560ZM1280 536H1279V90H1280H1281V536H1280ZM1256 560V559C1268.7 559 1279 548.703 1279 536H1280H1281C1281 549.807 1269.81 561 1256 561V560ZM0 536H1C1 548.703 11.2975 559 24 559V560V561C10.1929 561 -1 549.807 -1 536H0ZM24 0V1C11.2974 1 1 11.2974 1 24H0H-1C-1 10.1929 10.1929 -1 24 -1V0ZM970.873 9.2655L970.084 9.87946C965.727 4.27692 959.027 1 951.929 1V0V-1C959.644 -1 966.926 2.56189 971.663 8.65155L970.873 9.2655ZM1026.74 66V67C1019.02 67 1011.74 63.4381 1007 57.3484L1007.79 56.7345L1008.58 56.1206C1012.94 61.7231 1019.64 65 1026.74 65V66ZM1256 66V65C1269.81 65 1281 76.1929 1281 90H1280H1279C1279 77.2974 1268.7 67 1256 67V66Z"></path>
                </svg>

                <svg xmlns="http://www.w3.org/2000/svg" fill="rgb(255, 255, 255)" viewBox="0 0 362.94086021505376 104.868" width="100%" height="104.868" class="act-faq-svg-mobile-bg">
                    <mask fill="white" id="path-1-inside-1_229_10798">
                        <path d="M361 80C361 66.7452 350.255 56 337 56H234.738C227.332 56 220.34 52.5807 215.794 46.7346L186.651 9.26538C182.104 3.41931 175.113 0 167.706 0H24C10.7452 0 0 10.7452 0 24V947C0 960.255 10.7452 971 24 971H337C350.255 971 361 960.255 361 947V80Z"></path>
                    </mask>
                    <path d="M361 80C361 66.7452 350.255 56 337 56H234.738C227.332 56 220.34 52.5807 215.794 46.7346L186.651 9.26538C182.104 3.41931 175.113 0 167.706 0H24C10.7452 0 0 10.7452 0 24V947C0 960.255 10.7452 971 24 971H337C350.255 971 361 960.255 361 947V80Z"></path>
                    <path mask="url(#path-1-inside-1_229_10798)" class="act-faq-svg-mob-border" fill="rgba(11, 21, 48, 0.06)" d="M186.651 9.26538L187.44 8.65143L186.651 9.26538ZM215.794 46.7346L215.004 47.3485L215.794 46.7346ZM337 56V57H234.738V56V55H337V56ZM215.794 46.7346L215.004 47.3485L185.861 9.87933L186.651 9.26538L187.44 8.65143L216.583 46.1207L215.794 46.7346ZM167.706 0V1H24V0V-1H167.706V0ZM0 24H1V947H0H-1V24H0ZM24 971V970H337V971V972H24V971ZM361 947H360V80H361H362V947H361ZM337 971V970C349.703 970 360 959.703 360 947H361H362C362 960.807 350.807 972 337 972V971ZM0 947H1C1 959.703 11.2975 970 24 970V971V972C10.1929 972 -1 960.807 -1 947H0ZM24 0V1C11.2975 1 1 11.2974 1 24H0H-1C-1 10.1929 10.1929 -1 24 -1V0ZM186.651 9.26538L185.861 9.87933C181.504 4.27686 174.804 1 167.706 1V0V-1C175.421 -1 182.704 2.56183 187.44 8.65143L186.651 9.26538ZM234.738 56V57C227.023 57 219.741 53.4382 215.004 47.3485L215.794 46.7346L216.583 46.1207C220.94 51.7231 227.64 55 234.738 55V56ZM337 56V55C350.807 55 362 66.1929 362 80H361H360C360 67.2974 349.703 57 337 57V56Z"></path>
                </svg>

                <div class="act-faq-head">
                    <h4 class="act-faq-head-title">
                        <p>سوالات <strong>متــــــــداول</strong></p>      </h4>
                </div>
                <div class="act-faq-main">
                    <?php
                    foreach ($faqs[0]['items'] as $key => $item) {
                        ?>
                        <div class="act-faq-item" <?=count($faqs[0]['items'])>=2 ? 'style="width: 49%;"' : '' ?>>
                            <div class="act-questions" data-bs-toggle="collapse" data-bs-target="#act-faq-<?=$key?>" aria-expanded="true" type="button" aria-controls="act-faq-<?=$key?>">
                                <p class="text-only"><?=$item['question']?></p>
                                <div class="act-questions-flash">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="currentcolor"><path d="M15.0579 11.3998C14.8996 11.3998 14.7413 11.4581 14.6163 11.5831L9.99961 16.1998L5.38294 11.5831C5.14128 11.3415 4.74128 11.3415 4.49961 11.5831C4.25794 11.8248 4.25794 12.2248 4.49961 12.4665L9.55794 17.5248C9.79961 17.7665 10.1996 17.7665 10.4413 17.5248L15.4996 12.4665C15.7413 12.2248 15.7413 11.8248 15.4996 11.5831C15.3829 11.4581 15.2163 11.3998 15.0579 11.3998Z"></path><path d="M10 2.29141C9.65833 2.29141 9.375 2.57474 9.375 2.91641V16.9414C9.375 17.2831 9.65833 17.5664 10 17.5664C10.3417 17.5664 10.625 17.2831 10.625 16.9414V2.91641C10.625 2.57474 10.3417 2.29141 10 2.29141Z"></path></svg>                                </div>
                            </div>
                            <div class="act-answer collapse <?=$key>1 ?:'show' ?>" id="act-faq-<?=$key?>">
                                <div class="act-answer-content">
                                    <p class="text-only"><?=$item['answer']?></p>
                                </div>
                            </div>
                        </div>
                        <?php
                    }
                    ?>
                </div>
            </div>
        </section>
        <?php
    }
    global $product;
    $args = [
        'post_type'      => 'product',
        'posts_per_page' => -1,
        'meta_query'     => [
            'relation' => 'AND',
            [
                'key'     => '_sale_price',
                'value'   => 0,
                'compare' => '>',
                'type'    => 'NUMERIC',
            ]
        ],
    ];

    $query = new \WP_Query($args);
    if ($query->have_posts()) {
        ?>
        <section class="container-xl-w mx-auto mt-18">
            <div class="act-new-service-carousel-1st" id="LoadCategory">
                <div class="act-new-service-carousel-head d-flex align-items-center justify-content-between">
                    <svg xmlns="http://www.w3.org/2000/svg" width="1281" height="75" viewBox="0 0 1281 75" fill="none" class="act-new-service-carousel-head-svg">
                        <path d="M1280.47 0.5H1000.91C986.771 0.5 979.703 0.5 973.764 2.99163C969.027 4.9789 964.838 8.07733 961.551 12.025C957.43 16.9747 955.361 23.7331 951.224 37.25C947.086 50.7669 945.017 57.5253 940.896 62.475C937.609 66.4227 933.42 69.5211 928.683 71.5084C922.744 74 915.676 74 901.54 74H412.882C399.847 74 393.329 74 387.813 71.8926C382.12 69.7177 377.167 65.9625 373.536 61.0686C370.017 56.3267 368.257 50.0512 364.737 37.5C361.217 24.9488 359.457 18.6733 355.938 13.9314C352.307 9.0375 347.353 5.2823 341.661 3.10737C336.145 1 329.627 1 316.592 1H0" stroke="url(#paint0_linear_29_20094)"></path>
                        <defs>
                            <linearGradient id="paint0_linear_29_20094" x1="29.4736" y1="0.500002" x2="1213.79" y2="-28.0511" gradientUnits="userSpaceOnUse">
                                <stop stop-color="#0B61FF" stop-opacity="0"></stop>
                                <stop offset="0.5" stop-color="#0B61FF"></stop>
                                <stop offset="1" stop-color="#0B61FF" stop-opacity="0"></stop>
                            </linearGradient>
                        </defs>
                    </svg>
                    <div class="act-our-services-carousel-head-title">
                        <div class="act-our-services-carousel-head-title-divs">
                            <div class="act-our-services-carousel-head-title-div1"></div>
                            <div class="act-our-services-carousel-head-title-div2"></div>
                        </div>
                        <div class="act-our-services-carousel-head-title-content">
                            <h5>
                            </h5><h5>از تخفیف <strong>جا نمونی</strong></h5>
                            <p>NO DISCOUNT</p>
                        </div>
                    </div>
                    <div class="act-new-service-carousel-head-content">
                        <div class="act-new-service-carousel-buttons">
                            <div class="act-percent-but-r act-percent-but act-carousel-but" tabindex="0" role="button" aria-label="Previous slide" aria-controls="swiper-wrapper-5a458f817b4750df" aria-disabled="false">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="currentcolor">
                                    <path d="M14.4301 18.8201C14.2401 18.8201 14.0501 18.7501 13.9001 18.6001C13.6101 18.3101 13.6101 17.8301 13.9001 17.5401L19.4401 12.0001L13.9001 6.46012C13.6101 6.17012 13.6101 5.69012 13.9001 5.40012C14.1901 5.11012 14.6701 5.11012 14.9601 5.40012L21.0301 11.4701C21.3201 11.7601 21.3201 12.2401 21.0301 12.5301L14.9601 18.6001C14.8101 18.7501 14.6201 18.8201 14.4301 18.8201Z"></path>
                                    <path d="M20.33 12.75H3.5C3.09 12.75 2.75 12.41 2.75 12C2.75 11.59 3.09 11.25 3.5 11.25L20.33 11.25C20.74 11.25 21.08 11.59 21.08 12C21.08 12.41 20.74 12.75 20.33 12.75Z"></path>
                                </svg>
                            </div>
                            <div class="act-percent-but-l act-percent-but act-carousel-but swiper-button-disabled" tabindex="-1" role="button" aria-label="Next slide" aria-controls="swiper-wrapper-5a458f817b4750df" aria-disabled="true">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="currentcolor">
                                    <path d="M9.56988 5.17988C9.75988 5.17988 9.94988 5.24988 10.0999 5.39988C10.3899 5.68988 10.3899 6.16988 10.0999 6.45988L4.55988 11.9999L10.0999 17.5399C10.3899 17.8299 10.3899 18.3099 10.0999 18.5999C9.80988 18.8899 9.32988 18.8899 9.03988 18.5999L2.96988 12.5299C2.67988 12.2399 2.67988 11.7599 2.96988 11.4699L9.03988 5.39988C9.18988 5.24988 9.37988 5.17988 9.56988 5.17988Z"></path>
                                    <path d="M3.67 11.25H20.5C20.91 11.25 21.25 11.59 21.25 12C21.25 12.41 20.91 12.75 20.5 12.75L3.67 12.75C3.26 12.75 2.92 12.41 2.92 12C2.92 11.59 3.26 11.25 3.67 11.25Z"></path>
                                </svg>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="swiper percent-box-swiper">
                    <div class="swiper-wrapper" >
                        <?php while ($query->have_posts()): $query->the_post();
                            $product = wc_get_product(get_the_ID());
                            $delivery = get_post_meta($product->get_id(), 'delivery', true);
                            $pa =  ((isset($delivery['two']) && $delivery['two'] == 'on') || product_available($product->get_id()));
                            if (!$pa){
                                continue;
                            }
                            $regular = $product->get_regular_price();
                            $sale    = $product->get_sale_price();

                            $discount = round((($regular - $sale) / $regular) * 100);
                            $img = get_the_post_thumbnail_url(get_the_ID(), 'product_discount');
                            $title = get_the_title();
                            $settings = get_post_meta(get_the_ID(), 'giftmax_box_setting', true);
                            $date_from = $product->get_date_on_sale_from();
                            $date_to   = $product->get_date_on_sale_to();
                            if ($product->is_on_sale() && ($date_from || $date_to)) {
                                $sale_to = $product->get_date_on_sale_to();
                                $sale_to_ts = $sale_to ? $sale_to->getTimestamp() : null;
                            }else{
                                $sale_to_ts = null;
                            }
                            $tooltip = isset($delivery['description']) ? $delivery['description'] : '';
                            ?>
                            <div class="swiper-slide">
                                <div class="act-percent-card">
                                    <div class="flex flex-col">
                                        <div class="relative">
                                            <div class="act-new-service-card-inner-top">
                                                <a href="<?=get_permalink()?>">
                                                <div class="flex dj45fd">
                                                    <?php
                                                    $tooltip = isset($delivery['description']) ? $delivery['description'] : '';
                                                    ?>
                                                    <div class="act-product-option-box__nw <?=isset($delivery['two']) && $delivery['two'] == 'on' ? 'pre-sale wiki wiki__holder js-dk-wiki-trigger' : 'same-day'?>" <?=isset($delivery['two']) && $delivery['two'] == 'on' ? 'data-tooltip="'. $tooltip .'"' :''?>><?=isset($delivery['two']) && $delivery['two'] == 'on' ? 'پیش فروش' : 'تحویل آنی'?></div>
                                                    <div class="purchaseScore wiki wiki__holder js-dk-wiki-trigger" data-tooltip="با خرید این گیفت کارت <?=empty($settings[0]['purchaseScore']) ?0: $settings[0]['purchaseScore']?> امتیاز دریافت میکنید">
                                                        <i class="icon-star"></i>
                                                        <?=empty($settings[0]['purchaseScore']) ?0: $settings[0]['purchaseScore']?>
                                                    </div>
                                                    <?php
                                                    if (!empty($settings[0]['label']) && $settings[0]['label'] != ''){?>
                                                        <div class="label-fjd84">
                                                            <img src="<?=empty($settings[0]['label']) ?'': $settings[0]['label']?>" class="logo_label">
                                                            <p class="label_title"><?=empty($settings[0]['label_title']) ?'': $settings[0]['label_title']?></p>
                                                        </div>
                                                        <?php
                                                    }
                                                    ?>
                                                </div>
                                                    <div class="act-new-service-card-inner-top-img-box relative aib36">
                                                        <img loading="lazy" decoding="async" width="32" height="33" src="<?=$img?>" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="">
                                                    </div>
                                                </a>
                                            </div>
                                            <?php
                                            if (!empty($settings[0]['logo_region'])){
                                                ?>
                                                <div class="logo_region">
                                                    <img src="<?=empty($settings[0]['logo_region']) ?: get_template_directory_uri() . '/assets/flag/' . $settings[0]['logo_region'] . '.svg'?>">
                                                </div>
                                                <?php
                                            }
                                            ?>
                                            <div class="act-product-price-off-percent">  <?=get_discount_percent($product)?> ٪       </div>
                                        </div>
                                        <div class="act-bar-left">
                                            <div class="flex justify-between">
                                                <a class="lg:w-80" href="<?=get_permalink()?>">
                                                <h4 class="ellipsis"><?=get_the_title()?></h4>
                                                </a>
                                                <?php
                                                $giftmax_is_user_logged_in = is_user_logged_in();
                                                $giftmax_wishlist_ids = $giftmax_is_user_logged_in ? giftmax_get_user_wishlist_product_ids() : [];
                                                if ($giftmax_is_user_logged_in){
                                                    $is_in_wishlist = in_array((int) $product->get_id(), $giftmax_wishlist_ids, true); ?>
                                                    <button class="add-to__favorites Button-alu84 <?=$is_in_wishlist ? 'is-active' : ''?>" data-product-id="<?=esc_attr($product->get_id())?>" style="width: 28px;height: 28px;border-radius: 7px">
                                                        <svg viewBox="0 0 24 24" style="width: 64%;">
                                                            <path d="M12.62 20.81C12.28 20.93 11.72 20.93 11.38 20.81C8.48 19.82 2 15.69 2 8.68998C2 5.59998 4.49 3.09998 7.56 3.09998C9.38 3.09998 10.99 3.97998 12 5.33998C13.01 3.97998 14.63 3.09998 16.44 3.09998C19.51 3.09998 22 5.59998 22 8.68998C22 15.69 15.52 19.82 12.62 20.81Z" fill="<?=$is_in_wishlist ? '#ef4444' : 'none'?>" stroke="<?=$is_in_wishlist ? '#ef4444' : 'inherit'?>" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                                                        </svg>
                                                    </button>
                                                    <?php
                                                }
                                                ?>
                                            </div>

                                            <?php
                                            if(!empty($settings[0]['sub_head']) && !isMobile()) echo "<p class='act-product-title-en mb-1'>" . $settings[0]['sub_head'] . "</p>";
                                            ?>
                                            <div class="flex justify-between mb-1 kef4e">
                                                <?php
                                                if (!is_null($sale_to_ts)){
                                                    ?>
                                                    <img class="inline-block lg:w-40" src="<?=get_template_directory_uri()?>/assets/img/svg/IncredibleOffer.svg" alt="" title="" style="object-fit: contain;">
                                                    <div class="text-primary-700 text-body2-strong" style="display:block;"><i class="icon-clock mr-1"></i><span class="style_ProductPromotionTimeline__timer__zS6ZA"><?= date('Y-m-d H:i:s', $sale_to_ts); ?></span></div>

                                                    <?php
                                                }else{ ?>
                                                    <img class="inline-block lg:w-40" src="<?=get_template_directory_uri()?>/assets/img/svg/Offer.svg" alt="" title="" style="object-fit: contain;">

                                                    <?php
                                                }
                                                ?>
                                            </div>

                                            <div class="flex justify-between w-full">
                                                <?php
                                                if (isset($delivery['two']) && $delivery['two'] == 'on' || product_available($product->get_id())){
                                                    if (\Giftmax\Modules\UserModel::setting("buy") === true){
                                                    ?>
                                                    <button data-product-id="<?=$product->get_id()?>" class="act-percent-card-buy-box-but Button-ac13 pointer" type="button">
                                                        افزودن به سبد خرید
                                                    </button>

                                                <?php }
                                                else{
                                                    ?>
                                                <button class="btn btn-buy-disable">
                                                    امکان خرید فعلا وجود ندارد
                                                </button>
                                                <?php
                                                }
                                                }
                                                    else{
                                                    echo '<div class="inaJSDge8" style="height: 30px">ناموجود</div>';
                                                }?>
                                                <div class="act-product-price-box">
                                                    <div class="act-product-price bpt">
                                                        <div id="priceValue" data-id="<?=$product->get_id()?>" data-target="<?=payment_usd($product->is_on_sale() ? $sale :$regular)?>"><?=number_format_usd($sale)?></div>
                                                        <span>تومان</span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endwhile; ?>
                    </div>
                    <span class="swiper-notification" aria-live="assertive" aria-atomic="true"></span>
                </div>
            </div>
        </section>
        <?php
    }
    if (!$product instanceof WC_Product) {
        $product = wc_get_product(get_the_ID());
    }
    $giftmax_is_user_logged_in = is_user_logged_in();
    $giftmax_wishlist_ids = $giftmax_is_user_logged_in ? giftmax_get_user_wishlist_product_ids() : [];
    // دریافت دسته‌های محصول فعلی
    $terms = wp_get_post_terms($product->get_id(), 'product_cat', ['fields' => 'ids']);

    if (!empty($terms)) {

        $args = [
            'post_type'      => 'product',
            'posts_per_page' => 8,
            'post__not_in'   => [ $product->get_id() ], // محصول فعلی را حذف کن
            'orderby'        => 'rand',
            'tax_query'      => [
                [
                    'taxonomy' => 'product_cat',
                    'field'    => 'term_id',
                    'terms'    => $terms,
                ]
            ]
        ];
        $query = new WP_Query($args);

        if ($query->have_posts()) :
            ?>
            <section class="container-xl-w mx-auto mt-18">
                <div class="act-new-service-carousel-1st" id="LoadCategory">
                    <div class="act-new-service-carousel-head d-flex align-items-center justify-content-between">
                        <svg xmlns="http://www.w3.org/2000/svg" width="1281" height="75" viewBox="0 0 1281 75" fill="none" class="act-new-service-carousel-head-svg">
                            <path d="M1280.47 0.5H1000.91C986.771 0.5 979.703 0.5 973.764 2.99163C969.027 4.9789 964.838 8.07733 961.551 12.025C957.43 16.9747 955.361 23.7331 951.224 37.25C947.086 50.7669 945.017 57.5253 940.896 62.475C937.609 66.4227 933.42 69.5211 928.683 71.5084C922.744 74 915.676 74 901.54 74H412.882C399.847 74 393.329 74 387.813 71.8926C382.12 69.7177 377.167 65.9625 373.536 61.0686C370.017 56.3267 368.257 50.0512 364.737 37.5C361.217 24.9488 359.457 18.6733 355.938 13.9314C352.307 9.0375 347.353 5.2823 341.661 3.10737C336.145 1 329.627 1 316.592 1H0" stroke="url(#paint0_linear_29_20094)"></path>
                            <defs>
                                <linearGradient id="paint0_linear_29_20094" x1="29.4736" y1="0.500002" x2="1213.79" y2="-28.0511" gradientUnits="userSpaceOnUse">
                                    <stop stop-color="#0B61FF" stop-opacity="0"></stop>
                                    <stop offset="0.5" stop-color="#0B61FF"></stop>
                                    <stop offset="1" stop-color="#0B61FF" stop-opacity="0"></stop>
                                </linearGradient>
                            </defs>
                        </svg>
                        <div class="act-our-services-carousel-head-title">
                            <div class="act-our-services-carousel-head-title-divs">
                                <div class="act-our-services-carousel-head-title-div1"></div>
                                <div class="act-our-services-carousel-head-title-div2"></div>
                            </div>
                            <div class="act-our-services-carousel-head-title-content">
                                <h5>
                                </h5><h5>مربوط ترین <strong>مصحولات</strong></h5>
                                <p>RELATED PRODUOCTS</p>
                            </div>
                        </div>
                        <div class="act-new-service-carousel-head-content">

                            <a class="act-link-but" href="/shop" rel="nofollow">
                                مشاهده بیشتر                    <svg xmlns="http://www.w3.org/2000/svg" width="34" height="34" viewBox="0 0 34 34" fill="currentcolor">
                                    <path d="M20.0744 10.4295C20.2088 10.5639 20.2936 10.7477 20.2936 10.9599C20.2936 11.37 19.9542 11.7094 19.5441 11.7094L11.7094 11.7094L11.7094 19.5442C11.7094 19.9543 11.3699 20.2937 10.9598 20.2937C10.5497 20.2937 10.2103 19.9543 10.2103 19.5442L10.2103 10.9599C10.2103 10.5498 10.5497 10.2103 10.9598 10.2103L19.5441 10.2103C19.7562 10.2103 19.9401 10.2952 20.0744 10.4295Z"></path>
                                    <path d="M11.611 10.5501L23.5116 22.4507C23.8015 22.7406 23.8015 23.2215 23.5116 23.5114C23.2217 23.8013 22.7409 23.8013 22.451 23.5114L10.5504 11.6108C10.2605 11.3209 10.2605 10.84 10.5504 10.5501C10.8403 10.2602 11.3211 10.2602 11.611 10.5501Z"></path>
                                </svg>

                            </a>

                            <div class="act-vb"></div>
                            <div class="act-new-service-carousel-buttons">
                                <div class="act-new-service-carousel-head-but-r act-new-service-carousel-head-but act-carousel-but" tabindex="0" role="button" aria-label="Previous slide" aria-controls="swiper-wrapper-5a458f817b4750df" aria-disabled="false">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="currentcolor">
                                        <path d="M14.4301 18.8201C14.2401 18.8201 14.0501 18.7501 13.9001 18.6001C13.6101 18.3101 13.6101 17.8301 13.9001 17.5401L19.4401 12.0001L13.9001 6.46012C13.6101 6.17012 13.6101 5.69012 13.9001 5.40012C14.1901 5.11012 14.6701 5.11012 14.9601 5.40012L21.0301 11.4701C21.3201 11.7601 21.3201 12.2401 21.0301 12.5301L14.9601 18.6001C14.8101 18.7501 14.6201 18.8201 14.4301 18.8201Z"></path>
                                        <path d="M20.33 12.75H3.5C3.09 12.75 2.75 12.41 2.75 12C2.75 11.59 3.09 11.25 3.5 11.25L20.33 11.25C20.74 11.25 21.08 11.59 21.08 12C21.08 12.41 20.74 12.75 20.33 12.75Z"></path>
                                    </svg>
                                </div>
                                <div class="act-new-service-carousel-head-but-l act-new-service-carousel-head-but act-carousel-but swiper-button-disabled" tabindex="-1" role="button" aria-label="Next slide" aria-controls="swiper-wrapper-5a458f817b4750df" aria-disabled="true">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="currentcolor">
                                        <path d="M9.56988 5.17988C9.75988 5.17988 9.94988 5.24988 10.0999 5.39988C10.3899 5.68988 10.3899 6.16988 10.0999 6.45988L4.55988 11.9999L10.0999 17.5399C10.3899 17.8299 10.3899 18.3099 10.0999 18.5999C9.80988 18.8899 9.32988 18.8899 9.03988 18.5999L2.96988 12.5299C2.67988 12.2399 2.67988 11.7599 2.96988 11.4699L9.03988 5.39988C9.18988 5.24988 9.37988 5.17988 9.56988 5.17988Z"></path>
                                        <path d="M3.67 11.25H20.5C20.91 11.25 21.25 11.59 21.25 12C21.25 12.41 20.91 12.75 20.5 12.75L3.67 12.75C3.26 12.75 2.92 12.41 2.92 12C2.92 11.59 3.26 11.25 3.67 11.25Z"></path>
                                    </svg>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="swiper new-service-box-swiper">
                        <div class="swiper-wrapper" >
                            <?php
                            $home_coupon_objects = [];
                            $home_coupon_ids = get_posts([
                                'post_type'      => 'shop_coupon',
                                'post_status'    => 'publish',
                                'numberposts'    => -1,
                                'fields'         => 'ids',
                            ]);

                            if (!empty($home_coupon_ids)) {
                                foreach ($home_coupon_ids as $home_coupon_id) {
                                    $home_coupon_objects[] = new \WC_Coupon($home_coupon_id);
                                }
                            }
                            while ($query->have_posts()) : $query->the_post(); global $product;
                                $regular = $product->get_regular_price();
                                $sale    = $product->get_sale_price();
                                $final_price = $product->is_on_sale() && $sale > 0 ? $sale : $regular;
                                $img = get_the_post_thumbnail_url(get_the_ID(), 'product_discount');
                                $settings = get_post_meta($product->get_id(), 'giftmax_box_setting', true);
                                $matched_coupon_code = '';

                                if (!empty($home_coupon_objects)) {
                                    foreach ($home_coupon_objects as $home_coupon_obj) {
                                        $expires_at = $home_coupon_obj->get_date_expires();

                                        if ($expires_at && $expires_at->getTimestamp() < current_time('timestamp')) {
                                            continue;
                                        }

                                        if ($home_coupon_obj->is_valid_for_product($product)) {
                                            $matched_coupon_code = $home_coupon_obj->get_code();
                                            break;
                                        }
                                    }
                                }
                                $delivery = get_post_meta($product->get_id(), 'delivery', true);
                                $settings = get_post_meta(get_the_ID(), 'giftmax_box_setting', true);
                                ?>
                                <div class="swiper-slide">
                                    <div class="act-new-service-card <?=!empty($matched_coupon_code) ? 'has-discount' : ''?>">
                                        <?php if (!empty($matched_coupon_code) && !isMobile()) { ?>
                                            <div class="act-new-service-card-discount Button-sc91" data-product-id="<?=esc_attr($product->get_id())?>">
                                                <div class="anScr"></div>
                                                <div class="anSct">مشاهده کد تخفیف</div>
                                                <div class="anScl"></div>
                                            </div>
                                        <?php } ?>
                                        <div class="act-new-service-card-inner">
                                            <div <?=isset($delivery['two']) && $delivery['two'] == 'on' || product_available($product->get_id()) ?'':'class="NdhJD5"'?>>
                                                <div class="act-new-service-card-inner-top">
                                                    <a href="<?=get_permalink()?>">
                                                    <div class="act-new-service-card-inner-top-img-box relative">
                                                        <img loading="lazy" decoding="async" width="32" height="33" src="<?=$img?>" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="">
                                                        <?php
                                                        if (!empty($settings[0]['logo_region'])){
                                                            ?>
                                                            <div class="logo_region">
                                                                <img src="<?=empty($settings[0]['logo_region']) ?: get_template_directory_uri() . '/assets/flag/' . $settings[0]['logo_region'] . '.svg'?>">
                                                            </div>
                                                            <?php
                                                        }
                                                        $date_from = $product->get_date_on_sale_from();
                                                        $date_to   = $product->get_date_on_sale_to();
                                                        if ($product->is_on_sale() & ($date_from || $date_to)){
                                                            ?>
                                                            <div class="logo_detail" style="top: 6px;right: 7px;background-color: transparent;">
                                                                <img width="33" height="29" src="<?=get_template_directory_uri()?>/assets/img/svg/Amazings.svg">
                                                            </div>
                                                            <?php
                                                        } elseif ($product->is_on_sale()){
                                                            ?>
                                                            <div class="logo_detail" style="top: 6px;right: 7px;">
                                                                <img src="<?=get_template_directory_uri()?>/assets/img/svg/percent.svg">
                                                            </div>
                                                            <?php
                                                        }
                                                        ?>
                                                    </div>
                                                    </a>
                                                    <div class="act-new-service-card-inner-top-txt-box" <?=!empty($settings[0]['label']) && $settings[0]['label'] != '' ? 'style="gap:2px"' : ''?>>
                                                        <a href="<?=get_permalink()?>">
                                                            <h4 class="act-product-title"><?=get_the_title()?></h4>
                                                            <?php
                                                            if(!empty($settings[0]['sub_head'])) echo "<p class='act-product-title-en'>" . $settings[0]['sub_head'] . "</p>";
                                                            ?>
                                                        </a>
                                                        <div class="flex justify-between">
                                                            <div class="flex">
                                                                <?php
                                                                $tooltip = isset($delivery['description']) ? $delivery['description'] : '';
                                                                ?>
                                                                <div class="act-product-option-box__nw <?=isset($delivery['two']) && $delivery['two'] == 'on' ? 'pre-sale wiki wiki__holder js-dk-wiki-trigger' : 'same-day'?>" <?=isset($delivery['two']) && $delivery['two'] == 'on' ? 'data-tooltip="'. $tooltip .'"' :''?>><?=isset($delivery['two']) && $delivery['two'] == 'on' ? 'پیش فروش' : 'تحویل آنی'?></div>
                                                                <div class="purchaseScore product-purchaseScore__box wiki wiki__holder js-dk-wiki-trigger" data-tooltip="با خرید این گیفت کارت <?=empty($settings[0]['purchaseScore']) ?0: $settings[0]['purchaseScore']?> امتیاز دریافت میکنید"><i class="icon-star"></i><?=empty($settings[0]['purchaseScore']) ?0: $settings[0]['purchaseScore']?></div>
                                                            </div>
                                                            <?php
                                                            if ($giftmax_is_user_logged_in){
                                                            $is_in_wishlist = in_array((int) $product->get_id(), $giftmax_wishlist_ids, true); ?>
                                                            <button class="add-to__favorites Button-alu84 <?=$is_in_wishlist ? 'is-active' : ''?>" data-product-id="<?=esc_attr($product->get_id())?>" data-auth="<?=$giftmax_is_user_logged_in ? '1' : '0'?>" style="width: 28px;height: 28px;border-radius: 7px">
                                                                <svg viewBox="0 0 24 24" style="width: 64%;">
                                                                    <path d="M12.62 20.81C12.28 20.93 11.72 20.93 11.38 20.81C8.48 19.82 2 15.69 2 8.68998C2 5.59998 4.49 3.09998 7.56 3.09998C9.38 3.09998 10.99 3.97998 12 5.33998C13.01 3.97998 14.63 3.09998 16.44 3.09998C19.51 3.09998 22 5.59998 22 8.68998C22 15.69 15.52 19.82 12.62 20.81Z" fill="<?=$is_in_wishlist ? '#ef4444' : 'none'?>" stroke="<?=$is_in_wishlist ? '#ef4444' : 'inherit'?>" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                                                                </svg>
                                                            </button>
                                                            <?php
                                                            }
                                                            ?>
                                                        </div>
                                                        <?php if (!empty($matched_coupon_code) && isMobile()) { ?>
                                                            <div class="act-new-service-card-discount Button-sc91" data-product-id="<?=esc_attr($product->get_id())?>">
                                                                مشاهده کد تخفیف
                                                            </div>
                                                        <?php }else{ ?>
                                                            <p class="act-product-txt"><?=empty($settings[0]['description_short']) ?'': $settings[0]['description_short']?></p>
                                                            <?php
                                                        }
                                                        ?>                                                        <?php
                                                        if (!empty($settings[0]['label']) && $settings[0]['label'] != ''){?>
                                                            <div class="label-fjd84">
                                                                <img src="<?=empty($settings[0]['label']) ?'': $settings[0]['label']?>" class="logo_label">
                                                                <p class="label_title"><?=empty($settings[0]['label_title']) ?'': $settings[0]['label_title']?></p>
                                                            </div>
                                                            <?php
                                                        }
                                                        ?>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="act-hor-bor"></div>
                                            <div>
                                                <?php
                                                if(!empty($matched_coupon_code)){
                                                    $usage_limit  = (int) $home_coupon_obj->get_usage_limit();
                                                    $usage_count  = (int) $home_coupon_obj->get_usage_count();

                                                    $remaining_uses = $usage_limit > 0
                                                        ? max(0, $usage_limit - $usage_count)
                                                        : 'نامحدود';

                                                    // فقط اگر محدودیت استفاده وجود دارد، درصد را محاسبه کن
                                                    $percentage = 0;
                                                    if ($usage_limit > 0 && $usage_limit > $usage_count) {
                                                        $percentage = ($usage_count / $usage_limit) * 100;
                                                    } elseif ($usage_limit > 0 && $usage_limit <= $usage_count) {
                                                        $percentage = 100; // همه استفاده شده
                                                    }
                                                    ?>
                                                    <div class="">
                                                        <?php if ($usage_limit > 0): // فقط اگر محدودیت وجود دارد نوار پیشرفت نشان بده ?>
                                                            <div class="relative bg-neutral-100 style_ProductPromotionTimeline__progress__JnKWE">
                                                                <div class="absolute bg-primary-700 h-full left-0 top-0 style_ProductPromotionTimeline--active__oYyta" style="width: <?= $percentage ?>%;"></div>
                                                            </div>
                                                        <?php endif; ?>
                                                        <div class="whitespace-nowrap flex justify-between pt-1">
                                                            <?php if ($usage_limit > 0): ?>
                                                                <div class=""><span class="text-primary-700 text-body-strong ml-1"><?= round($percentage) ?>%</span><span class="text-neutral-500 text-caption">فروش رفته</span></div>
                                                            <?php else: ?>
                                                                <div><span class="text-neutral-500 text-caption">نامحدود</span></div>
                                                            <?php endif; ?>
                                                            <?php
                                                            if ($home_coupon_obj->get_date_expires()){
                                                                ?>
                                                                <div class="text-primary-700 text-body2-strong style_ProductPromotionTimeline__timer__zS6ZA"><?= $home_coupon_obj->get_date_expires()->date_i18n( 'Y-m-d H:i:s' ) ?></div>
                                                                <?php
                                                            }
                                                            ?>
                                                        </div>
                                                    </div>
                                                    <?php
                                                }
                                                ?>
                                            <div class="act-product-card-footer">
                                                <?php
                                                if (isset($delivery['two']) && $delivery['two'] == 'on' || product_available($product->get_id())){
                                                    if (\Giftmax\Modules\UserModel::setting("buy") === true){
                                                        ?>
                                                    <button type="button" class="act-special-carousel-card-buy-box-but Button-ac13 pointer" data-product-id="<?=$product->get_id()?>">
                                                        <svg xmlns="http://www.w3.org/2000/svg" width="26" height="26" viewBox="0 0 26 26" fill="currentcolor">
                                                            <path d="M17.875 9.34916C17.4308 9.34916 17.0625 8.98083 17.0625 8.53666V7.04166C17.0625 5.90416 16.575 4.79916 15.73 4.03C14.8742 3.25 13.7692 2.8925 12.5992 3.00083C10.6492 3.185 8.9375 5.17833 8.9375 7.25833V8.30916C8.9375 8.75333 8.56917 9.12166 8.125 9.12166C7.68083 9.12166 7.3125 8.75333 7.3125 8.30916V7.2475C7.3125 4.33333 9.66333 1.64666 12.4475 1.37583C14.0725 1.22417 15.6325 1.73333 16.8242 2.8275C18.005 3.9 18.6875 5.43833 18.6875 7.04166V8.53666C18.6875 8.98083 18.3192 9.34916 17.875 9.34916Z"></path>
                                                            <path d="M16.2498 24.6457H9.7498C4.7448 24.6457 3.81314 22.3165 3.5748 20.0523L2.7623 13.5632C2.64314 12.3932 2.5998 10.714 3.7373 9.45734C4.7123 8.374 6.32647 7.854 8.66647 7.854H17.3331C19.684 7.854 21.2981 8.38484 22.2623 9.45734C23.389 10.714 23.3565 12.3932 23.2373 13.5415L22.4248 20.0523C22.1865 22.3165 21.2548 24.6457 16.2498 24.6457ZM8.66647 9.479C6.83564 9.479 5.57897 9.8365 4.9398 10.5515C4.40897 11.1365 4.23564 12.0357 4.37647 13.379L5.18897 19.8682C5.37314 21.6015 5.8498 23.0315 9.7498 23.0315H16.2498C20.1498 23.0315 20.6265 21.6123 20.8106 19.8898L21.6231 13.379C21.764 12.0573 21.5906 11.1582 21.0598 10.5623C20.4206 9.8365 19.164 9.479 17.3331 9.479H8.66647Z"></path>
                                                            <path d="M16.7045 14.2458C16.0979 14.2458 15.6104 13.7583 15.6104 13.1624C15.6104 12.5666 16.0979 12.0791 16.6937 12.0791C17.2895 12.0791 17.777 12.5666 17.777 13.1624C17.777 13.7583 17.3004 14.2458 16.7045 14.2458Z"></path>
                                                            <path d="M9.12151 14.2458C8.51484 14.2458 8.02734 13.7583 8.02734 13.1624C8.02734 12.5666 8.51484 12.0791 9.11068 12.0791C9.70651 12.0791 10.194 12.5666 10.194 13.1624C10.194 13.7583 9.71734 14.2458 9.12151 14.2458Z"></path>
                                                        </svg>
                                                    </button>
                                                    <?php
                                                }else{
                                                        echo "<div></div>";
                                                    }
                                                }
                                                else{
                                                    echo '<div class="inaJSDge8">ناموجود</div>';
                                                }?>
                                                <div class="act-product-price-box">
                                                    <?php
                                                    if ( $sale && $regular > $sale ) {?>
                                                        <div class="act-product-price-box-top">
                                                            <div class="act-product-price-off-price"><?=number_format_usd($regular)?></div>
                                                            <div class="act-product-price-off-percent">  <?=get_discount_percent($product)?> ٪       </div>


                                                        </div>
                                                        <?php
                                                    }
                                                    ?>
                                                    <div class="act-product-price<?=$product->is_on_sale() ? ' bpt' : ''?>">
                                                        <?php
                                                        if($final_price > 0){?>
                                                            <div id="priceValue" data-id="<?=$product->get_id()?>" data-target="<?=payment_usd($product->is_on_sale() ? $sale :$regular)?>"><?=number_format_usd($product->is_on_sale() ? $sale : $regular)?></div>
                                                            <span>تومان</span>
                                                            <?php
                                                        }else{
                                                            ?>
                                                            <div class="act-product-price-free">رایگان</div>
                                                            <?php
                                                        }
                                                        ?>
                                                    </div>
                                                </div>
                                            </div>
                                            <a href="<?=the_permalink()?>" class="act-special-carousel-card-buy-box-option mt-1">جزئیات</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endwhile; ?>
                        </div>
                        <span class="swiper-notification" aria-live="assertive" aria-atomic="true"></span>
                    </div>
                </div>
            </section>
        <?php
        endif;
    }
    $category_slug  = 'ytr';
    $posts_per_page = 12;
    $orderby        = 'date';
    $order          = 'DESC';
    if ( $cat_id ) {
        $args = [
            'category' => $cat_id,
            'posts_per_page' => $posts_per_page,
            'orderby' => $orderby,
            'order' => $order,
            'no_found_rows' => true,
        ];
        $posts  = get_posts( $args );
        if (!empty($posts)){
            ?>
            <section class="container-2xl-w mx-auto mt-32 mb-10">
                <div class="act-new-service-carousel-1st">
                    <div class="act-new-service-carousel-head d-flex align-items-center justify-content-between">
                        <svg xmlns="http://www.w3.org/2000/svg" width="1281" height="75" viewBox="0 0 1281 75" fill="none" class="act-new-service-carousel-head-svg">
                            <path d="M1280.47 0.5H1000.91C986.771 0.5 979.703 0.5 973.764 2.99163C969.027 4.9789 964.838 8.07733 961.551 12.025C957.43 16.9747 955.361 23.7331 951.224 37.25C947.086 50.7669 945.017 57.5253 940.896 62.475C937.609 66.4227 933.42 69.5211 928.683 71.5084C922.744 74 915.676 74 901.54 74H412.882C399.847 74 393.329 74 387.813 71.8926C382.12 69.7177 377.167 65.9625 373.536 61.0686C370.017 56.3267 368.257 50.0512 364.737 37.5C361.217 24.9488 359.457 18.6733 355.938 13.9314C352.307 9.0375 347.353 5.2823 341.661 3.10737C336.145 1 329.627 1 316.592 1H0" stroke="url(#paint0_linear_29_20094)"></path>
                            <defs>
                                <linearGradient id="paint0_linear_29_20094" x1="29.4736" y1="0.500002" x2="1213.79" y2="-28.0511" gradientUnits="userSpaceOnUse">
                                    <stop stop-color="#0B61FF" stop-opacity="0"></stop>
                                    <stop offset="0.5" stop-color="#0B61FF"></stop>
                                    <stop offset="1" stop-color="#0B61FF" stop-opacity="0"></stop>
                                </linearGradient>
                            </defs>
                        </svg>
                        <div class="act-our-services-carousel-head-title">
                            <div class="act-our-services-carousel-head-title-divs">
                                <div class="act-our-services-carousel-head-title-div1"></div>
                                <div class="act-our-services-carousel-head-title-div2"></div>
                            </div>
                            <div class="act-our-services-carousel-head-title-content">
                                <h5> مقالات<strong> مرتبط</strong> </h5>
                                <p>RELATED ARTICLES</p>
                            </div>
                        </div>
                        <div class="act-blog-head-content">
                            <div class="act-blog-buttons">
                                <div class="act-blog-head-but-r act-blog-head-but act-carousel-but" tabindex="0" role="button" aria-label="Previous slide">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="currentcolor">
                                        <path d="M14.4301 18.8201C14.2401 18.8201 14.0501 18.7501 13.9001 18.6001C13.6101 18.3101 13.6101 17.8301 13.9001 17.5401L19.4401 12.0001L13.9001 6.46012C13.6101 6.17012 13.6101 5.69012 13.9001 5.40012C14.1901 5.11012 14.6701 5.11012 14.9601 5.40012L21.0301 11.4701C21.3201 11.7601 21.3201 12.2401 21.0301 12.5301L14.9601 18.6001C14.8101 18.7501 14.6201 18.8201 14.4301 18.8201Z"></path>
                                        <path d="M20.33 12.75H3.5C3.09 12.75 2.75 12.41 2.75 12C2.75 11.59 3.09 11.25 3.5 11.25L20.33 11.25C20.74 11.25 21.08 11.59 21.08 12C21.08 12.41 20.74 12.75 20.33 12.75Z"></path>
                                    </svg>
                                </div>
                                <div class="act-blog-head-but-l act-blog-head-but act-carousel-but swiper-button-disabled" tabindex="-1" role="button" aria-label="Next slide" aria-disabled="true">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="currentcolor">
                                        <path d="M9.56988 5.17988C9.75988 5.17988 9.94988 5.24988 10.0999 5.39988C10.3899 5.68988 10.3899 6.16988 10.0999 6.45988L4.55988 11.9999L10.0999 17.5399C10.3899 17.8299 10.3899 18.3099 10.0999 18.5999C9.80988 18.8899 9.32988 18.8899 9.03988 18.5999L2.96988 12.5299C2.67988 12.2399 2.67988 11.7599 2.96988 11.4699L9.03988 5.39988C9.18988 5.24988 9.37988 5.17988 9.56988 5.17988Z"></path>
                                        <path d="M3.67 11.25H20.5C20.91 11.25 21.25 11.59 21.25 12C21.25 12.41 20.91 12.75 20.5 12.75L3.67 12.75C3.26 12.75 2.92 12.41 2.92 12C2.92 11.59 3.26 11.25 3.67 11.25Z"></path>
                                    </svg>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="swiper new-blog-swiper act-articles-swiper">
                        <div class="swiper-wrapper">
                            <?php
                            foreach ($posts as $post) :
                                setup_postdata($post);
                                $thumb_url = get_the_post_thumbnail_url($post->ID, 'medium_large');
                                ?>
                                <div class="swiper-slide">
                                    <div class="act-blog-card">
                                        <div class="block bg-white rounded-lg lg:rounded-xl p-8 lg:p-16 h-full border shadow-none act-article-card relative justify-between">
                                            <a href="<?=esc_url(get_permalink($post))?>" class="block">
                                                <?php if (!empty($thumb_url)) : ?>
                                                    <img alt="<?=esc_attr(get_the_title($post))?>" loading="lazy" width="400" height="200" decoding="async" class="rounded lg:rounded-lg w-full" src="<?=esc_url($thumb_url)?>">
                                                <?php endif; ?>
                                                <span class="act-blog-card-img-box-label"><?=get_the_category()[0]->name?></span>
                                            </a>
                                            <div class="px-12 pt-20 lg:pt-24 pb-6">
                                                <a href="<?=esc_url(get_permalink($post))?>" class="block">
                                                    <h3 class="text-secondary text-sm lg:text-lg font-extrabold ellipsis-2"><?=esc_html(get_the_title($post))?></h3>
                                                </a>
                                                <div class="text-2xs lg:text-xs text-dark font-light mt-4 lg:mt-8 ellipsis-3"><?=get_the_excerpt($post)?></div>
                                            </div>
                                            <div class="act-blog-card-footer">
                                                <div class="act-blog-card-footer-read-time"><div class="flex align-items-center ml-1"><i class="icon-eye"></i><p><?= view_giftmax($post->ID)?></p></div><div class="flex align-items-center"><i class="icon-user"></i><?=giftmax_get_author_full_name(get_post_author_id($post->ID))?></div><div class="flex align-items-center blog_clock-view"><i class="icon-clock"></i><?=gjdate(get_the_date('Y-m-d',$post->ID),"d M Y")?></div></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php
                            endforeach;
                            wp_reset_postdata();
                            ?>
                        </div>
                    </div>
                </div>
            </section>
            <?php
        }
    }
    ?>
</main>
