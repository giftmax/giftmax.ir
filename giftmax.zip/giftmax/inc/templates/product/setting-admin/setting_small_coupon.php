<div class="setting_box__send">
    <h3>تنظیمات ارسال پیامک</h3>
    <div class="setting_bot_send d-flex">
        <p class="P-setting_bot_send w60">ارسال پیام</p>
        <label for="w-send" class="input-label start w40_1">
            <span class="start-label"></span>
            <input id="w-send" type="checkbox" name="coupon[status]" class="input">
            <span class="input-check"></span>
        </label>
    </div>
    <div class="hidden" id="couponBox">
        <div class="setting_bot_send d-flex">
            <p class="P-setting_bot_send w60">درج میزان تخفیف</p>
            <label class="input-label start w40_1">
                <span class="start-label"></span>
                <input type="checkbox" name="coupon[amount]" class="input">
                <span class="input-check"></span>
            </label>
        </div>
        <div class="setting_bot_send d-flex">
            <p class="P-setting_bot_send w60">درج تعداد موجودی تخفیف</p>
            <label class="input-label start w40_1">
                <span class="start-label"></span>
                <input type="checkbox" name="coupon[number]" class="input">
                <span class="input-check"></span>
            </label>
        </div>
        <div class="setting_bot_send d-flex">
            <p class="P-setting_bot_send w60">افزودن وایت لیست</p>
            <label class="input-label start w40_1">
                <span class="start-label"></span>
                <input type="checkbox" id="white-s" name="coupon[white]" class="input">
                <span class="input-check"></span>
            </label>
        </div>
        <label id="w-white" class="hidden uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--L7bcQ uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--normal--A6Ntt text-body-1 color-n-700 w-100">
            <p class="mb-2 color-n-700 text-body-1 mb-2" data-testid="form-label">اسم لیست را وارد کن</p>
            <div class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame__input-container--D5edN px-2 d-flex ai-center">
                <section class="grow-1 text-body-2-c">
                    <input class="px-2 TextField__input-_5fbdd text-subtitle TextField-e58168" type="text" id="listwhite" name="coupon[listwhite]">
                </section>
            </div>
        </label>
        <div class="listwhite_search hidden"></div>
        <div class="setting_bot_send d-flex">
            <p class="P-setting_bot_send w60">افزودن بلک لیست</p>
            <label class="input-label start w40_1">
                <span class="start-label"></span>
                <input type="checkbox" name="coupon[block]" class="input" id="block-s">
                <span class="input-check"></span>
            </label>
        </div>
        <label id="w-block" class="hidden uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--L7bcQ uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--normal--A6Ntt text-body-1 color-n-700 w-100">
            <p class="mb-2 color-n-700 text-body-1 mb-2" data-testid="form-label">اسم لیست را وارد کن</p>
            <div class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame__input-container--D5edN px-2 d-flex ai-center">
                <section class="grow-1 text-body-2-c">
                    <input class="px-2 TextField__input-_5fbdd text-subtitle TextField-e58168" type="text" name="coupon[listblock]" id="listblock" >
                </section>
            </div>
        </label>
        <div class="listblock_search hidden"></div>
        <div class="setting_bot_send d-flex">
            <p class="P-setting_bot_send w60">درج تاریخ انقضا</p>
            <label class="input-label start w40_1">
                <span class="start-label"></span>
                <input type="checkbox" name="coupon[expiry]" class="input">
                <span class="input-check"></span>
            </label>
        </div>
        <div class="setting_bot_send d-flex">
            <p class="P-setting_bot_send w60">ارسال سر ساعت مشخص</p>
            <label class="input-label start w40_1">
                <span class="start-label"></span>
                <input type="checkbox" name="coupon[time-input]" class="input" id="time-s">
                <span class="input-check"></span>
            </label>
        </div>
        <label id="w-time" class="hidden uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--L7bcQ uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--normal--A6Ntt text-body-1 color-n-700 w-100">
            <p class="mb-2 color-n-700 text-body-1 mb-2" data-testid="form-label"> زمان دلخواه ارسال</p>
            <div class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame__input-container--D5edN px-2 d-flex ai-center">
                <section class="grow-1 text-body-2-c">
                    <input class="px-2 TextField__input-_5fbdd text-subtitle w-100 TextField-e58168" style="margin: 0" name="coupon[time]" type="text" id="time" placeholder="1405-05-10 21:20:00" dir="ltr" value="<?=gjdate(date('Y-m-d H:i:s'))?>">
                </section>
            </div>
        </label>
        <div class="setting_bot_send d-flex">
            <p class="P-setting_bot_send w60">ارسال قبل از انقضا</p>
            <label class="input-label start w40_1">
                <span class="start-label"></span>
                <input type="checkbox" name="coupon[expiry]" class="input" id="expiry-date">
                <span class="input-check"></span>
            </label>
        </div>
        <label id="l_expiry-date" class="hidden uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--L7bcQ uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--normal--A6Ntt text-body-1 color-n-700 w-100">
            <p class="mb-2 color-n-700 text-body-1 mb-2" data-testid="form-label"> چند روز قبل از انقضا</p>
            <div class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame__input-container--D5edN px-2 d-flex ai-center">
                <section class="grow-1 text-body-2-c">
                    <input class="px-2 TextField__input-_5fbdd text-subtitle w-100 TextField-e58168" style="margin: 0" name="coupon[expiry-date]" type="text" id="time" placeholder="5" dir="ltr">
                </section>
            </div>
        </label>
        <div class="setting_bot_send d-flex">
            <p class="P-setting_bot_send w60">درج متن سفارشی </p>
            <label for="w-text_custom" class="input-label start w40_1">
                <span class="start-label"></span>
                <input type="checkbox" id="w-text_custom" name="coupon[input_text_custom]" class="input">
                <span class="input-check"></span>
            </label>
        </div>
        <div class="hidden" id="text_custom">
            <label class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--L7bcQ uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--normal--A6Ntt text-subtitle color-n-700  w-100">
                <p class="s-setting_bot_send w60">متن سفارشی</p>
                <div class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame__input-container--D5edN uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame__input-container--textArea--qCxT1 px-2 d-flex ai-center p-2 ">
                    <section class="grow-1 text-body-2-c">
                        <textarea name="coupon[text_custom]" class="px-1 TextField__textarea-df80b4 text-subtitle w-100 TextField-e58168" rows="4" style="padding: 0"></textarea>
                    </section>
                </div>
            </label>
        </div>
    </div>
</div>

