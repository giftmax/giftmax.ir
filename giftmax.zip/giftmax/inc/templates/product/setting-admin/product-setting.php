<?php
$settings = get_post_meta(get_the_ID(), 'giftmax_box_setting', true);
$a_settings = get_post_meta(get_the_ID(), 'giftmax_box_setting_All', true);
$rules = get_post_meta(get_the_ID(), 'giftmax_box_rules', true);
$faqs = get_post_meta(get_the_ID(), 'giftmax_box_faq', true);
$giftmax_setting_order = get_post_meta(get_the_ID(), 'giftmax_setting_order', true);
?>
<script>
    const product_id = <?=get_the_ID()?>;
</script>
<div class="panel-product">
    <ul class="product_options">
        <li class="plus_options">
            <a id="panel setting-all_a" onclick="tag_click('setting-all_a','setting-all')" href="#setting-all" style=""><span>تنظیمات کلی</span></a>
        </li>
        <li class="plus_options">
            <a id="panel setting-product__page_a" onclick="tag_click('setting-product__page_a','setting-product__page')" href="#setting-product__page_a" style=""><span>تنظیمات صفحه محصول</span></a>
        </li>
        <li class="plus_options">
            <a id="panel setting-product__training_a" onclick="tag_click('setting-product__training_a','setting-product__training')" href="#setting-product__training_a" style=""><span>قوانین و مقررات</span></a>
        </li>
        <li class="plus_options">
            <a id="panel setting-product__faq_a" onclick="tag_click('setting-product__faq_a','setting-product__faq')" href="#setting-product__faq_a" style=""><span>سؤالات متداول</span></a>
        </li>
        <li class="plus_options">
            <a id="panel setting-product__licences" onclick="tag_click('setting-product__licences_a','setting-product__licences')" href="#setting-product__licences_a" style=""><span>لایسنس</span></a>
        </li>
    </ul>
    <div class="option_group_box">
        <div id="setting-all" class="panel_box_giftmax" style="display: none;">
            <div class="headline">
                <span>
                    <span class="font-bold text-color">تنظیمات اولیه</span>
                    <span class="text-12">تنظیمات نمایشی محصول</span>
                </span>
            </div>
            <!--<div class="flex mt17">
                <span class="text-input-switch">غیر فعال</span>
                <div class="input-switch switch-info" dir="rtl">
                    <div class="input-inner rtl_switch">
                        <label class="input-label package-label" for="change_packages_list">
                            <input onchange="changePackageList()" type="checkbox" id="change_packages_list"
                                   name="giftmax_c_box[0][comment_switch]" class="input">
                            <span class="input-check"></span>
                        </label>
                    </div>
                </div>
                <span class="text-input-switch">فعال</span>
            </div>-->
            <div id="box_color" class="row mt17">
                <?php
                if (is_array($settings)) {
                    foreach ($settings as $key => $setting){
                        ?>
                        <div class="col-sm-12 mx-auto">
                            <div class="account-item-color">
                                <div class="receipt-header account-item-color-header">
                                    <div class="row flex-wrap">
                                        <div class="account-item-color-title col-sm-6">
                                        </div>

                                        <div class="account-item-color-secondary-title col-sm-6">
                                        </div>
                                    </div>
                                </div>

                                <div class="receipt-details account-item-color-details">

                                    <div class="account-item-color-data-value-row">
                                        <div class="row flex-wrap">
                                            <div class="account-item-color-data-label col-6">ترتیب نمایش :</div>

                                            <div class="input_purchase_status account-item-color-data-value col-6">
                                                <input type="text"
                                                       id="giftmax_setting_order"
                                                       class="payment-status"
                                                       name="giftmax_setting_order"
                                                       value="<?=$giftmax_setting_order?>">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="account-item-color-data-value-row">
                                        <div class="row flex-wrap">
                                            <div class="account-item-color-data-label col-6">توضیحات کوتاه محصول :</div>

                                            <div class="input_purchase_status account-item-color-data-value col-6">
                                                <input type="text"
                                                       id="giftmax_description_short_0"
                                                       class="payment-status"
                                                       name="giftmax_box_setting[0][description_short]"
                                                       value="<?=$setting['description_short']?>">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="account-item-color-data-value-row">
                                        <div class="row flex-wrap">
                                            <div class="account-item-color-data-label col-6"> اسم محصول به انگلیسی :</div>

                                            <div class="input_purchase_status account-item-color-data-value col-6">
                                                <input type="text"
                                                       id="giftmax_sub_head_0"
                                                       class="payment-status"
                                                       name="giftmax_box_setting[0][sub_head]"
                                                       value="<?=$setting['sub_head']?>">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="account-item-color-data-value-row">
                                        <div class="row flex-wrap">
                                            <div class="account-item-color-data-label col-6">امتیاز خرید این محصول :</div>

                                            <div class="input_purchase_status account-item-color-data-value col-6">
                                                <input type="text"
                                                       id="giftmax_description_short_0"
                                                       class="payment-status"
                                                       name="giftmax_box_setting[0][purchaseScore]"
                                                       value="<?=$setting['purchaseScore']?>">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="account-item-color-data-value-row">
                                        <div class="row flex-wrap">
                                            <div class="account-item-color-data-label col-6">لینک آموزش استفاده :</div>

                                            <div class="input_purchase_status account-item-color-data-value col-6">
                                                <input type="text"
                                                       id="giftmax_description_short_0"
                                                       class="payment-status"
                                                       name="giftmax_box_setting[0][linkUsing]"
                                                       value="<?=$setting['linkUsing']?>">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="account-item-color-data-value-row">
                                        <div class="row flex-wrap">
                                            <div class="account-item-color-data-label col-6">لوگوی ریجن:</div>
                                            <?php
                                            $selected_country = $setting['logo_region'] ?? '';
                                            ?>
                                            <div class="input_purchase_status account-item-color-data-value col-6">
                                                <select id="giftmax_logo_region_select"
                                                        name="giftmax_box_setting[0][logo_region]"
                                                        class="form-select js-example-basic-single" style="width: 300px;">
                                                    <option value="" >انتخاب کشور</option>
                                                    <option value="earth" <?=$selected_country == "earth" ? 'selected' : ''?>>گلوبال</option>
                                                    <option value="uk" <?=$selected_country == "uk" ? 'selected' : ''?>>انگلیس</option>
                                                    <option value="ar" <?=$selected_country == "ar" ? 'selected' : ''?>>آرژانتین</option>
                                                    <option value="au" <?=$selected_country == "au" ? 'selected' : ''?>>استرالیا</option>
                                                    <option value="ca" <?=$selected_country == "ca" ? 'selected' : ''?>>کانادا</option>
                                                    <option value="ae" <?=$selected_country == "ae" ? 'selected' : ''?>>امارات</option>
                                                    <option value="turkey" <?=$selected_country == "turkey" ? 'selected' : ''?>>ترکیه</option>
                                                    <option value="germany" <?=$selected_country == "germany" ? 'selected' : ''?>>آلمان</option>
                                                    <option value="india" <?=$selected_country == "india" ? 'selected' : ''?>>هند</option>
                                                    <option value="eu" <?=$selected_country == "eu" ? 'selected' : ''?>>اروپا</option>
                                                    <option value="us" <?=$selected_country == "us" ? 'selected' : ''?>>آمریکا</option>
                                                    <option value="az" <?=$selected_country == "az" ? 'selected' : ''?>>آدربایجان</option>
                                                    <option value="hk" <?=$selected_country == "hk" ? 'selected' : ''?>>هنگ هنگ</option>
                                                    <option value="tw" <?=$selected_country == "tw" ? 'selected' : ''?>>تایوان</option>
                                                    <option value="qa" <?=$selected_country == "qa" ? 'selected' : ''?>>قطر</option>
                                                    <option value="sa" <?=$selected_country == "sa" ? 'selected' : ''?>>عربستان</option>
                                                    <option value="ca" <?=$selected_country == "ca" ? 'selected' : ''?>>کانادا</option>
                                                    <option value="ru" <?=$selected_country == "ru" ? 'selected' : ''?>>روسیه</option>
                                                    <option value="ro" <?=$selected_country == "ro" ? 'selected' : ''?>>رومانی</option>
                                                    <option value="my" <?=$selected_country == "my" ? 'selected' : ''?>>مالزی</option>
                                                    <option value="gr" <?=$selected_country == "gr" ? 'selected' : ''?>>یونان</option>
                                                    <option value="cy" <?=$selected_country == "cy" ? 'selected' : ''?>>قبرس</option>
                                                    <option value="eg" <?=$selected_country == "eg" ? 'selected' : ''?>>مصر</option>
                                                    <option value="cn" <?=$selected_country == "cn" ? 'selected' : ''?>>چین</option>
                                                    <option value="at" <?=$selected_country == "at" ? 'selected' : ''?>>اتریش</option>
                                                    <option value="se" <?=$selected_country == "se" ? 'selected' : ''?>>سوئد</option>
                                                    <option value="dk" <?=$selected_country == "dk" ? 'selected' : ''?>>دانمارک</option>
                                                    <option value="hu" <?=$selected_country == "hu" ? 'selected' : ''?>>مجارستان</option>
                                                    <option value="nl" <?=$selected_country == "nl" ? 'selected' : ''?>>هلند</option>
                                                    <option value="fr" <?=$selected_country == "fr" ? 'selected' : ''?>>فرانسه</option>
                                                    <option value="vn" <?=$selected_country == "vn" ? 'selected' : ''?>>ویتنام</option>
                                                    <option value="br" <?=$selected_country == "br" ? 'selected' : ''?>>برزیل</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="account-item-color-data-value-row">
                                        <div class="row flex-wrap">
                                            <div class="account-item-color-data-label col-6"> ریجن:</div>

                                            <div class="input_purchase_status account-item-color-data-value col-6">
                                                <input type="text"
                                                       id="giftmax_region_0"
                                                       class="payment-status abandoned"
                                                       name="giftmax_box_setting[0][region]"
                                                       value="<?=$setting['region']?>">
                                            </div>
                                        </div>
                                    </div>

                                    <div class="account-item-color-data-value-row">
                                        <div class="row flex-wrap">
                                            <div class="account-item-color-data-label col-6">زمان تحویل:</div>

                                            <div class="input_purchase_status account-item-color-data-value col-6">
                                                <input type="text"
                                                       id="giftmax_delivery_time_0"
                                                       class="payment-status"
                                                       name="giftmax_box_setting[0][delivery_time]"
                                                       value="<?=$setting['delivery_time']?>">
                                            </div>
                                        </div>
                                    </div>

                                    <!-- پلتفرم‌ها -->
                                    <div class="account-item-color-data-value-row">
                                        <div class="row flex-wrap">
                                            <div class="account-item-color-data-label col-6">عکس بکگراند:</div>

                                            <div class="input_purchase_status account-item-color-data-value col-6">
                                                <input type="text"
                                                       id="giftmax_bg_url_0"
                                                       class="payment-status giftmax-media-field"
                                                       name="giftmax_box_setting[0][bg_url]"
                                                       value="<?=isset($setting['bg_url']) ? $setting['bg_url'] : ''?>">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="account-item-color-data-value-row">
                                        <div class="row flex-wrap">
                                            <div class="account-item-color-data-label col-6">پلتفرم‌:</div>

                                            <div class="input_purchase_status account-item-color-data-value col-6">
                                                <input type="text"
                                                       id="giftmax_platforms_0"
                                                       class="payment-status"
                                                       name="giftmax_box_setting[0][platforms]"
                                                       value="<?=$setting['platforms']?>">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="account-item-color-data-value-row">
                                        <div class="row flex-wrap">
                                            <div class="account-item-color-data-label col-6"> متن عکس :</div>

                                            <div class="input_purchase_status account-item-color-data-value col-6">
                                                <input type="text"
                                                       id="giftmax_text_img_0"
                                                       class="payment-status"
                                                       data-target="giftmax_text_img_0"
                                                       name="giftmax_box_setting[0][text_img]"
                                                       value="<?=isset($setting['text_img']) ? $setting['text_img'] : ''?>">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="account-item-color-data-value-row">
                                        <div class="row flex-wrap">
                                            <div class="account-item-color-data-label col-6">لوگوی پلتفرم‌:</div>

                                            <div class="input_purchase_status account-item-color-data-value col-6">
                                                <input type="text"
                                                       id="giftmax_logo_platforms_0"
                                                       class="payment-status giftmax-media-field"
                                                       data-target="giftmax_logo_platforms_0"
                                                       name="giftmax_box_setting[0][logo_platforms]"
                                                       value="<?=$setting['logo_platforms']?>">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="account-item-color-data-value-row">
                                        <div class="row flex-wrap">
                                            <div class="account-item-color-data-label col-6"> لیبل:</div>

                                            <div class="input_purchase_status account-item-color-data-value col-6">
                                                <input type="text"
                                                       id="giftmax_label_0"
                                                       class="payment-status giftmax-media-field"
                                                       data-target="giftmax_label_0"
                                                       name="giftmax_box_setting[0][label]"
                                                       value="<?=$setting['label']?>">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="account-item-color-data-value-row">
                                        <div class="row flex-wrap">
                                            <div class="account-item-color-data-label col-6">متن لیبل:</div>

                                            <div class="input_purchase_status account-item-color-data-value col-6">
                                                <input type="text"
                                                       id="giftmax_label_0"
                                                       class="payment-status"
                                                       data-target="giftmax_label_0"
                                                       name="giftmax_box_setting[0][label_title]"
                                                       value="<?=$setting['label_title']?>">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="account-item-color-data-value-row">
                                        <div class="row flex-wrap">
                                            <div class="account-item-color-data-label col-6">واحد پولی:</div>

                                            <div class="input_purchase_status account-item-color-data-value col-6">
                                                <input type="text"
                                                       id="giftmax_currency_unit_0"
                                                       class="payment-status"
                                                       name="giftmax_box_setting[0][currency_unit]"
                                                       value="<?= isset($setting['currency_unit']) ? esc_attr($setting['currency_unit']) : '' ?>">
                                            </div>
                                        </div>
                                    </div>

                                    <div class="account-item-color-data-value-row">
                                        <div class="row flex-wrap">
                                            <div class="account-item-color-data-label col-6">نماد واحد پولی:</div>

                                            <div class="input_purchase_status account-item-color-data-value col-6">
                                                <input type="text"
                                                       id="giftmax_currency_icon_0"
                                                       class="payment-status"
                                                       name="giftmax_box_setting[0][currency_icon]"
                                                       value="<?= isset($setting['currency_icon']) ? esc_attr($setting['currency_icon']) : '' ?>">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="account-item-color-data-value-row">
                                        <div class="row flex-wrap">
                                            <div class="account-item-color-data-label col-6">قیمت:</div>

                                            <div class="input_purchase_status account-item-color-data-value col-6">
                                                <input type="text"
                                                       id="giftmax_price_0"
                                                       class="payment-status"
                                                       name="giftmax_box_setting[0][price]"
                                                       value="<?= isset($setting['price']) ? esc_attr($setting['price']) : '' ?>">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>


                    <?php }
                } else { ?>
                    <div class="col-sm-12 mx-auto">
                        <div class="account-item-color">
                            <div class="receipt-header account-item-color-header">
                                <div class="row flex-wrap">
                                </div>
                            </div>
                            <div class="receipt-details account-item-color-details">
                                <div class="account-item-color-data-value-row">
                                    <div class="row flex-wrap">
                                        <div class="account-item-color-data-label col-6">ترتیب نمایش :</div>

                                        <div class="input_purchase_status account-item-color-data-value col-6">
                                            <input type="text"
                                                   id="giftmax_order_0"
                                                   class="payment-status"
                                                   name="giftmax_setting_order">
                                        </div>
                                    </div>
                                </div>
                                <div class="account-item-color-data-value-row">
                                    <div class="row flex-wrap">
                                        <div class="account-item-color-data-label col-6">توضیحات کوتاه محصول :</div>

                                        <div class="input_purchase_status account-item-color-data-value col-6">
                                            <input type="text"
                                                   id="giftmax_description_short_0"
                                                   class="payment-status"
                                                   name="giftmax_box_setting[0][description_short]">
                                        </div>
                                    </div>
                                </div>
                                <div class="account-item-color-data-value-row">
                                    <div class="row flex-wrap">
                                        <div class="account-item-color-data-label col-6"> اسم محصول به انگلیسی :</div>

                                        <div class="input_purchase_status account-item-color-data-value col-6">
                                            <input type="text"
                                                   id="giftmax_sub_head_0"
                                                   class="payment-status"
                                                   name="giftmax_box_setting[0][sub_head]">
                                        </div>
                                    </div>
                                </div>
                                <div class="account-item-color-data-value-row">
                                    <div class="row flex-wrap">
                                        <div class="account-item-color-data-label col-6">امتیاز خرید این محصول :</div>

                                        <div class="input_purchase_status account-item-color-data-value col-6">
                                            <input type="text"
                                                   id="giftmax_description_short_0"
                                                   class="payment-status"
                                                   name="giftmax_box_setting[0][purchaseScore]">
                                        </div>
                                    </div>
                                </div>
                                <div class="account-item-color-data-value-row">
                                    <div class="row flex-wrap">
                                        <div class="account-item-color-data-label col-6">لینک آموزش استفاده :</div>

                                        <div class="input_purchase_status account-item-color-data-value col-6">
                                            <input type="text"
                                                   id="giftmax_description_short_0"
                                                   class="payment-status"
                                                   name="giftmax_box_setting[0][linkUsing]"
                                            ">
                                        </div>
                                    </div>
                                </div>
                                <div class="account-item-color-data-value-row">
                                    <div class="row flex-wrap">
                                        <div class="account-item-color-data-label col-6">لوگوی ریجن:</div>

                                        <div class="input_purchase_status account-item-color-data-value col-6">
                                            <select id="giftmax_logo_region_select"
                                                    name="giftmax_box_setting[0][logo_region]"
                                                    class="form-select js-example-basic-single" style="width: 300px;">
                                                <option value="">انتخاب کشور</option>
                                                <option value="earth">گلوبال</option>
                                                <option value="uk">انگلیس</option>
                                                <option value="ar">آرژانتین</option>
                                                <option value="au">استرالیا</option>
                                                <option value="ca">کانادا</option>
                                                <option value="ae">امارات</option>
                                                <option value="turkey">ترکیه</option>
                                                <option value="germany">آلمان</option>
                                                <option value="india">هند</option>
                                                <option value="eu">اروپا</option>
                                                <option value="us">آمریکا</option>
                                                <option value="az">آدربایجان</option>
                                                <option value="hk">هنگ هنگ</option>
                                                <option value="tw">تایوان</option>
                                                <option value="qa">قطر</option>
                                                <option value="sa">عربستان</option>
                                                <option value="ca">کانادا</option>
                                                <option value="ru">روسیه</option>
                                                <option value="ro">رومانی</option>
                                                <option value="my">مالزی</option>
                                                <option value="gr">یونان</option>
                                                <option value="cy">قبرس</option>
                                                <option value="eg">مصر</option>
                                                <option value="cn">چین</option>
                                                <option value="at">اتریش</option>
                                                <option value="se">سوئد</option>
                                                <option value="dk">دانمارک</option>
                                                <option value="hu">مجارستان</option>
                                                <option value="nl">هلند</option>
                                                <option value="fr">فرانسه</option>
                                                <option value="vn">ویتنام</option>
                                                <option value="br">برزیل</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="account-item-color-data-value-row">
                                    <div class="row flex-wrap">
                                        <div class="account-item-color-data-label col-6"> ریجن:</div>

                                        <div class="input_purchase_status account-item-color-data-value col-6">
                                            <input type="text"
                                                   id="giftmax_region_0"
                                                   class="payment-status abandoned"
                                                   name="giftmax_box_setting[0][region]">
                                        </div>
                                    </div>
                                </div>

                                <div class="account-item-color-data-value-row">
                                    <div class="row flex-wrap">
                                        <div class="account-item-color-data-label col-6">زمان تحویل:</div>

                                        <div class="input_purchase_status account-item-color-data-value col-6">
                                            <input type="text"
                                                   id="giftmax_delivery_time_0"
                                                   class="payment-status"
                                                   name="giftmax_box_setting[0][delivery_time]">
                                        </div>
                                    </div>
                                </div>

                                <!-- پلتفرم‌ها -->
                                <div class="account-item-color-data-value-row">
                                    <div class="row flex-wrap">
                                        <div class="account-item-color-data-label col-6">عکس بکگراند:</div>

                                        <div class="input_purchase_status account-item-color-data-value col-6">
                                            <input type="text"
                                                   id="giftmax_bg_url_0"
                                                   class="payment-status giftmax-media-field"
                                                   name="giftmax_box_setting[0][bg_url]">
                                        </div>
                                    </div>
                                </div>
                                <div class="account-item-color-data-value-row">
                                    <div class="row flex-wrap">
                                        <div class="account-item-color-data-label col-6">پلتفرم‌:</div>

                                        <div class="input_purchase_status account-item-color-data-value col-6">
                                            <input type="text"
                                                   id="giftmax_platforms_0"
                                                   class="payment-status"
                                                   name="giftmax_box_setting[0][platforms]">
                                        </div>
                                    </div>
                                </div>
                                <div class="account-item-color-data-value-row">
                                    <div class="row flex-wrap">
                                        <div class="account-item-color-data-label col-6"> متن عکس :</div>

                                        <div class="input_purchase_status account-item-color-data-value col-6">
                                            <input type="text"
                                                   id="giftmax_text_img_0"
                                                   class="payment-status"
                                                   data-target="giftmax_text_img_0"
                                                   name="giftmax_box_setting[0][text_img]"
                                            >
                                        </div>
                                    </div>
                                </div>
                                <div class="account-item-color-data-value-row">
                                    <div class="row flex-wrap">
                                        <div class="account-item-color-data-label col-6">لوگوی پلتفرم‌:</div>

                                        <div class="input_purchase_status account-item-color-data-value col-6">
                                            <input type="text"
                                                   id="giftmax_logo_platforms_0"
                                                   class="payment-status giftmax-media-field"
                                                   data-target="giftmax_logo_platforms_0"
                                                   name="giftmax_box_setting[0][logo_platforms]">
                                        </div>
                                    </div>
                                </div>
                                <div class="account-item-color-data-value-row">
                                    <div class="row flex-wrap">
                                        <div class="account-item-color-data-label col-6"> لیبل:</div>

                                        <div class="input_purchase_status account-item-color-data-value col-6">
                                            <input type="text"
                                                   id="giftmax_label_0"
                                                   class="payment-status giftmax-media-field"
                                                   data-target="giftmax_label_0"
                                                   name="giftmax_box_setting[0][label]">
                                        </div>
                                    </div>
                                </div>
                                <div class="account-item-color-data-value-row">
                                    <div class="row flex-wrap">
                                        <div class="account-item-color-data-label col-6">متن لیبل:</div>

                                        <div class="input_purchase_status account-item-color-data-value col-6">
                                            <input type="text"
                                                   id="giftmax_label_0"
                                                   class="payment-status"
                                                   data-target="giftmax_label_0"
                                                   name="giftmax_box_setting[0][label_title]">
                                        </div>
                                    </div>
                                </div>
                                <div class="account-item-color-data-value-row">
                                    <div class="row flex-wrap">
                                        <div class="account-item-color-data-label col-6">واحد پولی:</div>

                                        <div class="input_purchase_status account-item-color-data-value col-6">
                                            <input type="text"
                                                   id="giftmax_currency_unit_0"
                                                   class="payment-status"
                                                   name="giftmax_box_setting[0][currency_unit]">
                                        </div>
                                    </div>
                                </div>

                                <div class="account-item-color-data-value-row">
                                    <div class="row flex-wrap">
                                        <div class="account-item-color-data-label col-6">نماد واحد پولی:</div>

                                        <div class="input_purchase_status account-item-color-data-value col-6">
                                            <input type="text"
                                                   id="giftmax_currency_icon_0"
                                                   class="payment-status"
                                                   name="giftmax_box_setting[0][currency_icon]">
                                        </div>
                                    </div>
                                </div>
                                <div class="account-item-color-data-value-row">
                                    <div class="row flex-wrap">
                                        <div class="account-item-color-data-label col-6">قیمت:</div>

                                        <div class="input_purchase_status account-item-color-data-value col-6">
                                            <input type="text"
                                                   id="giftmax_price_0"
                                                   class="payment-status"
                                                   name="giftmax_box_setting[0][price]">
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>

                <?php } ?>
            </div>
        </div>
        <div id="setting-product__page" class="panel_box_giftmax" style="display: none;">
            <div class="headline">
                <span>
                    <span class="font-bold text-color">صفحه محصول</span>
                    <span class="text-12">تنظیمات صفحه محصول</span>
                </span>
            </div>
            <!--<div class="flex mt17">
                <span class="text-input-switch">غیر فعال</span>
                <div class="input-switch switch-info" dir="rtl">
                    <div class="input-inner rtl_switch">
                        <label class="input-label package-label" for="change_packages_list">
                            <input onchange="changePackageList()" type="checkbox" id="change_packages_list"
                                   name="giftmax_c_box[0][comment_switch]" class="input">
                            <span class="input-check"></span>
                        </label>
                    </div>
                </div>
                <span class="text-input-switch">فعال</span>
            </div>-->
            <div id="box_color" class="row mt17">
                <?php
                if (is_array($a_settings)) {
                    foreach ($a_settings as $key => $a_setting){
                        ?>
                        <div class="col-sm-12 mx-auto">
                            <div class="account-item-color">
                                <div class="receipt-header account-item-color-header">
                                    <div class="row flex-wrap">
                                        <div class="account-item-color-title col-sm-6">
                                            <span class="title_id" title="">نکته توی هدر محصول</span>
                                        </div>

                                        <div class="account-item-color-secondary-title col-sm-6">
                                        </div>
                                    </div>
                                </div>

                                <div class="receipt-details account-item-color-details">

                                    <div class="account-item-color-data-value-row">
                                        <div class="row flex-wrap">
                                            <div class="account-item-color-data-label col-6">متن نکته :</div>

                                            <div class="input_purchase_status account-item-color-data-value col-6">
                                                <textarea
                                                        id="giftmax_point"
                                                        class="payment-status"
                                                        name="giftmax_box_setting_All[0][point]"><?=$a_setting['point']?></textarea>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php }
                } else { ?>
                    <div class="col-sm-12 mx-auto">
                        <div class="account-item-color">
                            <div class="receipt-header account-item-color-header">
                                <div class="row flex-wrap">
                                    <div class="account-item-color-title col-sm-6">
                                        <span class="title_id" title="">نکته توی هدر محصول</span>
                                    </div>

                                    <div class="account-item-color-secondary-title col-sm-6">

                                    </div>
                                </div>
                            </div>

                            <div class="receipt-details account-item-color-details">
                                <div class="account-item-color-data-value-row">
                                    <div class="row flex-wrap">
                                        <div class="account-item-color-data-label col-6">متن نکته :</div>

                                        <div class="input_purchase_status account-item-color-data-value col-6">
                                            <textarea
                                                    id="giftmax_point"
                                                    class="payment-status"
                                                    name="giftmax_box_setting_All[0][point]"></textarea>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php } ?>
            </div>
        </div>
        <div id="setting-product__training" class="panel_box_giftmax" style="display: none;">
            <div class="headline">
                <span>
                    <span class="font-bold text-color">قوانین و مقررات</span>
                    <span class="text-12">تنظیم قوانین محصول</span>
                </span>
            </div>
            <div class="flex mt17">
                <span class="text-input-switch">غیر فعال</span>
                <div class="input-switch switch-info" dir="rtl">
                    <div class="input-inner rtl_switch">
                        <label class="input-label package-label" for="change_product_training">
                            <input onchange="changePackageList('#change_product_training','.box_product_training')" type="checkbox" id="change_product_training"
                                   name="giftmax_box_rules[0][comment_switch]" class="input" <?=(!empty($rules[0]['comment_switch']) && $rules[0]['comment_switch']=="on") ? 'checked' : ''?>>
                            <span class="input-check"></span>
                        </label>
                    </div>
                </div>
                <span class="text-input-switch">فعال</span>
            </div>
            <div class="box_product_training" style="display:none;">
                <div id="box_rules" class="row mt17">
                    <?php
                    if (is_array($rules) && count($rules)) {
                    foreach ($rules as $index => $learn) {
                    if (!empty($learn['items']) && is_array($learn['items'])) {
                    foreach ($learn['items'] as $i => $item) {
                        ?>
                        <div class="col-sm-12 mx-auto mt-2">
                            <div class="account-item-color">
                                <div class="receipt-header account-item-color-header">
                                    <div class="row flex-wrap">
                                        <div class="account-item-color-title col-sm-6">
                                            <span class="title_id">آیتم شماره <?= $i?></span>
                                        </div>

                                        <div class="account-item-color-secondary-title col-sm-6">
                                        <span data--action="close" class="remodal-close" aria-label="Close">
                                            <span class="icon"></span>
                                        </span>
                                        </div>
                                    </div>
                                </div>

                                <div class="receipt-details account-item-color-details">
                                    <div class="account-item-color-data-value-row">
                                        <div class="row flex-wrap">
                                            <div class="account-item-color-data-label col-6">توضیح کوتاه :</div>

                                            <div class="input_purchase_status account-item-color-data-value col-6">
                                            <textarea
                                                    class="payment-status"
                                                    name="giftmax_box_rules[<?= $index ?>][items][<?= $i ?>][description]"><?= esc_textarea($item['description']) ?></textarea>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php }
                    ?>
                        <script>
                            let itemIndex = <?=$i?>;
                        </script>
                    <?php
                    }
                    }

                    } else { ?>
                        <script>
                            let itemIndex = 2;
                        </script>
                        <div class="col-sm-12 mx-auto mt-2">
                            <div class="account-item-color">
                                <div class="receipt-header account-item-color-header">
                                    <div class="row flex-wrap">
                                        <div class="account-item-color-title col-sm-6">
                                            <span class="title_id">آیتم شماره اول</span>
                                        </div>
                                        <div class="account-item-color-secondary-title col-sm-6">
                            <span data--action="close" class="remodal-close" aria-label="Close">
                                <span class="icon"></span>
                            </span>
                                        </div>
                                    </div>
                                </div>

                                <div class="receipt-details account-item-color-details">
                                    <div class="account-item-color-data-value-row">
                                        <div class="row flex-wrap">
                                            <div class="account-item-color-data-label col-6">توضیح کوتاه :</div>

                                            <div class="input_purchase_status account-item-color-data-value col-6">
                                <textarea class="payment-status"
                                          name="giftmax_box_rules[0][items][0][description]"></textarea>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php } ?>
                </div>
                <div class="account-item-info-button" style="">
                    <a href="#box_rules" id="rules_button" class="m_10_15">افزودن فاکتور جدید</a>
                </div>
            </div>
        </div>
        <div id="setting-product__faq" class="panel_box_giftmax" style="display: none;">
            <div class="headline">
                <span>
                    <span class="font-bold text-color">سؤالات متداول</span>
                </span>
            </div>
            <div class="flex mt17">
                <span class="text-input-switch">غیر فعال</span>
                <div class="input-switch switch-info" dir="rtl">
                    <div class="input-inner rtl_switch">
                        <label class="input-label package-label" for="change_product_faq">
                            <input onchange="changePackageList('#change_product_faq','.box_product_faq')" type="checkbox" id="change_product_faq"
                                   name="giftmax_box_faq[0][comment_switch]" class="input" <?=(!empty($faqs[0]['comment_switch']) && $faqs[0]['comment_switch']=="on") ? 'checked' : ''?>>
                            <span class="input-check"></span>
                        </label>
                    </div>
                </div>
                <span class="text-input-switch">فعال</span>
            </div>
            <div class="box_product_faq" style="display:none;">
                <div id="box_faq" class="row mt17">
                    <?php
                    if (is_array($faqs) && count($faqs)) {
                        ?>
                        <div class="col-sm-12 mx-auto">
                            <div class="account-item-color">
                                <div class="receipt-header account-item-color-header">
                                    <div class="row flex-wrap">
                                        <div class="account-item-color-title col-sm-6">
                                            <span class="title_id">توضیحات باکس</span>
                                        </div>
                                        <div class="account-item-color-secondary-title col-sm-6"></div>
                                    </div>
                                </div>

                                <div class="receipt-details account-item-color-details">
                                    <div class="account-item-color-data-value-row">
                                        <div class="row flex-wrap">
                                            <div class="input_purchase_status account-item-color-data-value col-6">
                                                <textarea class="payment-status"
                                                          name="giftmax_box_faq[0][description]"><?=$faqs[0]['description']?></textarea>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php
                        if (isset($faqs[0]) && isset($faqs[0]['items']) && is_array($faqs[0]['items'])) {
                            foreach ($faqs[0]['items'] as $key => $item) {
                                ?>
                                <div class="col-sm-12 mx-auto mt-2">
                                    <div class="account-item-color">
                                        <div class="receipt-header account-item-color-header">
                                            <div class="row flex-wrap">
                                                <div class="account-item-color-title col-sm-6">
                                                    <span class="title_id">سوال شماره <?=$key?></span>
                                                </div>
                                                <div class="account-item-color-secondary-title col-sm-6">
                            <span data--action="close" class="remodal-close" aria-label="Close">
                                <span class="icon"></span>
                            </span>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="receipt-details account-item-color-details">
                                            <div class="account-item-color-data-value-row">
                                                <div class="row flex-wrap">
                                                    <div class="account-item-color-data-label col-6">سوال  :</div>

                                                    <div class="input_purchase_status account-item-color-data-value col-6">
                                <textarea class="payment-status"
                                          name="giftmax_box_faq[0][items][<?=$key?>][question]"><?=$item['question']?></textarea>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="receipt-details account-item-color-details">
                                            <div class="account-item-color-data-value-row">
                                                <div class="row flex-wrap">
                                                    <div class="account-item-color-data-label col-6"> جواب :</div>

                                                    <div class="input_purchase_status account-item-color-data-value col-6">
                                <textarea class="payment-status"
                                          name="giftmax_box_faq[0][items][<?=$key?>][answer]"><?=$item['answer']?></textarea>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php
                            }}
                    } else { ?>
                        <div class="col-sm-12 mx-auto">
                            <div class="account-item-color">
                                <div class="receipt-header account-item-color-header">
                                    <div class="row flex-wrap">
                                        <div class="account-item-color-title col-sm-6">
                                            <span class="title_id">توضیحات باکس</span>
                                        </div>
                                        <div class="account-item-color-secondary-title col-sm-6"></div>
                                    </div>
                                </div>

                                <div class="receipt-details account-item-color-details">
                                    <div class="account-item-color-data-value-row">
                                        <div class="row flex-wrap">
                                            <div class="input_purchase_status account-item-color-data-value col-6">
                                                <textarea class="payment-status"
                                                          name="giftmax_box_faq[0][description]"></textarea>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-sm-12 mx-auto mt-2">
                            <div class="account-item-color">
                                <div class="receipt-header account-item-color-header">
                                    <div class="row flex-wrap">
                                        <div class="account-item-color-title col-sm-6">
                                            <span class="title_id">سوال شماره اول</span>
                                        </div>
                                        <div class="account-item-color-secondary-title col-sm-6">
                            <span data--action="close" class="remodal-close" aria-label="Close">
                                <span class="icon"></span>
                            </span>
                                        </div>
                                    </div>
                                </div>

                                <div class="receipt-details account-item-color-details">
                                    <div class="account-item-color-data-value-row">
                                        <div class="row flex-wrap">
                                            <div class="account-item-color-data-label col-6">سوال  :</div>

                                            <div class="input_purchase_status account-item-color-data-value col-6">
                                <textarea class="payment-status"
                                          name="giftmax_box_faq[1][items][1][question]"></textarea>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="receipt-details account-item-color-details">
                                    <div class="account-item-color-data-value-row">
                                        <div class="row flex-wrap">
                                            <div class="account-item-color-data-label col-6"> جواب :</div>

                                            <div class="input_purchase_status account-item-color-data-value col-6">
                                <textarea class="payment-status"
                                          name="giftmax_box_faq[1][items][1][answer]"></textarea>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php } ?>
                </div>
                <div class="account-item-info-button" style="">
                    <a href="#box_faq" id="faq_button" class="m_10_15">افزودن سوال جدید</a>
                </div>
            </div>
        </div>
        <div id="setting-product__licences" class="panel_box_giftmax is_active" style="display: block;">
            <div class="headline">
                <span>
                    <span class="font-bold text-color">لایسنس</span>
                </span>
            </div>
            <div class="box_product_licences">
                <div id="box_licences" class="mt17">
                    <div class="w-full">
                        <div class="account-item-color">
                            <div class="receipt-header account-item-color-header">
                                <div class="row flex-wrap">
                                    <div class="account-item-color-title col-sm-6">
                                        <span class="title_id">افزودن لایسنس</span>
                                    </div>
                                    <div class="account-item-color-secondary-title col-sm-6"></div>
                                </div>
                            </div>

                            <div class="receipt-details account-item-color-details">
                                <div class="account-item-color-data-value-row data-licences">
                                    <div class="flex mt2">
                                        <div class="input_purchase_status account-item-color-data-value col-6">
                                                <input class="payment-status"
                                                          name="giftmax_input_licences[1][code]" placeholder="لایسنس">
                                        </div>
                                        <div class="input_purchase_status account-item-color-data-value col-6">
                                                <input class="payment-status"
                                                          name="giftmax_input_licences[1][price]" placeholder="قیمت">
                                        </div>
                                        <div class="input_purchase_status account-item-color-data-value col-6">
                                                <input class="payment-status"
                                                          name="giftmax_input_licences[1][description]" placeholder="توضیحات">
                                        </div>
                                        <div class="CountNumberArray">1</div>
                                    </div>
                                </div>
                                <textarea class="payment-status"
                                          name="giftmax_textarea_licences" placeholder=" لایسنس ها"></textarea>
                                <button class="Button-sdf5">افزودن جدید</button>
                            </div>
                        </div>
                    </div>
                    <div class="flex justify-end w-full mt17">
                        <div class="flex">
                            <label>
                                <input type="file" accept=".zip,.rar" class="d-none" name="attachments" multiple="">
                                <span class="Button-afs45">افزودن فایل</span>
                            </label>
                            <button class="Button-ac41">ثبت کد ها</button>
                        </div>
                    </div>
                    <div class="w-full mt17">
                        <div class="c-bills__header">
                            <div class="b-bills bills_number" style="margin-right: 40px">ردیف</div>
                            <div class="b-bills bills_name">لایسنس</div>
                            <div class="b-bills purchase_date">تاریخ</div>
                            <div class="b-bills bills_pay">قیمت خرید</div>
                            <div class="b-bills bills_description">توضیحات</div>
                            <div class="b-bills bills_orders">عملیات</div>
                            <div class="b-bills bills_delete"></div>
                        </div>
                        <div id="c-bills">
                        <?php
                        $records = \Giftmax\Modules\LicenseManager::AdminLicense(get_the_ID());
                        if (!empty($records)){

                            ?>
                                <?php
                                foreach ($records as $key=>$record){
                                    $secureId = substr(hash('sha256', $record['licence_id'] . 'SALT_RANDOM_STRING'), 0, 16);
                                    ?>
                                    <div class="c-bills__body" data-id="<?= $secureId; ?>" data-order="<?= $record['sort_order']; ?>">
                                        <label class="label__checkbox">
                                            <input type="checkbox" value="<?=$secureId?>" class="d-none">
                                            <div class="div__checkbox"></div>
                                        </label>
                                        <div class="b-bills bills_number">
                                            <span class="c-number"><?=$key+1?></span></div>
                                        <div class="b-bills bills_name">
                                            <?php
                                            if (!is_null($record['file_id'])){
                                                $file = \Giftmax\Modules\UserModel::table('product_licences_file','file_id',$record['file_id']);

                                                $relative_path = ltrim(str_replace(ABSPATH, '', $file['url']), '/');
                                                ?>
                                                <div class="c-color download-file" data-url="<?=$relative_path?>"><?=$file['name']?></div>
                                                <?php
                                            }else{
                                                ?>
                                                <div class="c-color"><?=decrypt_data($record['licence_code'])?></div>
                                                <?php
                                            }
                                            ?>
                                        </div>
                                        <div class="b-bills purchase_date">
                                            <div class="c-color"><?=gjdate($record['created_at'],'Y/m/d H:i')?></div>
                                        </div>
                                        <div class="b-bills bills_pay">
                                            <div class="c-color"><?=!empty($record['cost_price']) ? number_format($record['cost_price']) : 0?></div>
                                        </div>
                                        <div class="b-bills bills_description flex justify-center">
                                            <?php
                                            if (!empty($record['description'])){?>
                                                    <div class="btn-cta Button-sd45" data-description="<?=$record['description']?>">نمایش</div>
                                            <?php }else{
                                                echo "-";
                                            }
                                            ?>
                                        </div>
                                        <div class="b-bills bills_orders" style=" margin: 0 6px; ">
                                            <div class="c-view vv-top"></div>
                                            <div class="c-view vv1"></div>
                                            <div class="c-view vv2"></div>
                                            <div class="c-view vv-bottom"></div>
                                        </div>
                                        <div class="b-bills bills_delete">
                                            <div class="btn-cta Button-dl45" data-id="<?=$secureId?>">حذف</div>
                                        </div>
                                    </div>
                                    <?php
                                }
                                ?>
                            <?php
                        }
                        ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>


<script>
    jQuery(document).ready(function ($) {
        <?php
        if (!empty($rules[0]['comment_switch']) && $rules[0]['comment_switch']=="on"){
        ?>
        changePackageList('#change_product_training','.box_product_training');
        <?php
        }if (!empty($faqs[0]['comment_switch']) && $faqs[0]['comment_switch']=="on"){
        ?>
        changePackageList('#change_product_faq','.box_product_faq');
        <?php
        }
        ?>
        $('.js-example-basic-single').select2({
            width: 'resolve',
            dir: 'rtl'
        });
    });
</script>
