<?php
require_once $_SERVER['DOCUMENT_ROOT'] . '/wp-load.php';
header("Content-Type: image/png");

ini_set('display_errors', 0);
error_reporting(0);

/* ----------------  ورودی‌ها  ---------------- */

$pid = isset($_GET['id']) ? intval($_GET['id']) : 0;
if (!$pid) exit('NO ID');

$product = wc_get_product($pid);
if (!$product) exit('NO PRODUCT');

$settings = get_post_meta($pid, 'giftmax_box_setting', true);

$price = isset($_GET['price']) ? intval($_GET['price']) : intval($product->get_regular_price());
if (!$price) $price = 10;

// نماد پول قابل تنظیم
$currency_symbol = isset($_GET['symbol']) ? $_GET['symbol'] : '$';

$region_url   = $settings[0]['logo_region']    ?? '';
$platform_url = $settings[0]['logo_platforms'] ?? '';


// URL آپلود → مسیر فایل
function gm_url_to_path($url) {
    if (!$url) return '';
    $upload = wp_upload_dir();
    if (strpos($url, $upload['baseurl']) === 0) {
        return $upload['basedir'] . substr($url, strlen($upload['baseurl']));
    }
    return $url;
}

// لود PNG/JPG/SVG به GD
function gm_load_image_any($file_path) {
    if (!$file_path || !file_exists($file_path)) return false;
    $ext = strtolower(pathinfo($file_path, PATHINFO_EXTENSION));

    if ($ext === 'png')  return imagecreatefrompng($file_path);
    if ($ext === 'jpg' || $ext === 'jpeg') return imagecreatefromjpeg($file_path);

    // SVG → PNG (در صورت داشتن Imagick)
    if ($ext === 'svg' && class_exists('Imagick')) {
        try {
            $im = new Imagick();
            $im->setBackgroundColor(new ImagickPixel('transparent'));
            $im->readImage($file_path);
            $im->setImageFormat("png");
            $tmp = sys_get_temp_dir() . '/gm_svg_' . md5($file_path) . '.png';
            $im->writeImage($tmp);
            $im->clear();
            $im->destroy();
            if (file_exists($tmp)) {
                return imagecreatefrompng($tmp);
            }
        } catch (Exception $e) {
            return false;
        }
    }

    return false;
}

// تبدیل تصویر به دایره
function gm_circle_crop($src, $size) {
    $dst = imagecreatetruecolor($size, $size);
    imagealphablending($dst, false);
    imagesavealpha($dst, true);

    $transparent = imagecolorallocatealpha($dst, 0, 0, 0, 127);
    imagefill($dst, 0, 0, $transparent);

    $w = imagesx($src);
    $h = imagesy($src);

    imagecopyresampled($dst, $src, 0, 0, 0, 0, $size, $size, $w, $h);

    $r = $size / 2;
    for ($x = 0; $x < $size; $x++) {
        for ($y = 0; $y < $size; $y++) {
            $dx = $x - $r;
            $dy = $y - $r;
            if ($dx*$dx + $dy*$dy > $r*$r) {
                imagesetpixel($dst, $x, $y, $transparent);
            }
        }
    }

    return $dst;
}

/* ----------------  بوم اصلی  ---------------- */

$width  = 931;
$height = 768;

// بوم
$img = imagecreatetruecolor($width, $height);
imagesavealpha($img, true);
$transparent = imagecolorallocatealpha($img, 0, 0, 0, 127);
imagefill($img, 0, 0, $transparent);

/* ----------------  کارت داخلی  ---------------- */

$card_margin = 80;
$card_w      = $width  - 2 * $card_margin;
$card_h      = $height - 2 * $card_margin;

// بوم کارت
$card = imagecreatetruecolor($card_w, $card_h);
imagesavealpha($card, true);
$transparent_card = imagecolorallocatealpha($card, 0, 0, 0, 127);
imagefill($card, 0, 0, $transparent_card);

/* گرادیانت شانسی برای کارت */

$color_sets = [
    [36, 84, 255],
    [12, 122, 255],
    [140, 0, 255],
    [0, 180, 255],
    [255, 80, 80],
];

$base = $color_sets[array_rand($color_sets)];
[$r1, $g1, $b1] = $base;
$r2 = min($r1 + 40, 255);
$g2 = min($g1 + 40, 255);
$b2 = min($b1 + 40, 255);

for ($y = 0; $y < $card_h; $y++) {
    $t = $y / $card_h;
    $r = (int)($r1 + ($r2 - $r1) * $t);
    $g = (int)($g1 + ($g2 - $g1) * $t);
    $b = (int)($b1 + ($b2 - $b1) * $t);
    $col = imagecolorallocate($card, $r, $g, $b);
    imageline($card, 0, $y, $card_w, $y, $col);
}

/* گوشه گرد ساده با ماسک خیلی سبک */

$mask = imagecreatetruecolor($card_w, $card_h);
imagesavealpha($mask, true);
$mask_trans = imagecolorallocatealpha($mask, 0, 0, 0, 127);
$mask_solid = imagecolorallocatealpha($mask, 0, 0, 0, 0);
imagefill($mask, 0, 0, $mask_trans);

$radius = 80;
$radius2 = $radius * $radius;

for ($x = 0; $x < $card_w; $x++) {
    for ($y = 0; $y < $card_h; $y++) {
        $inside = false;

        // بدنه اصلی
        if (($x >= $radius && $x <= $card_w - $radius) ||
            ($y >= $radius && $y <= $card_h - $radius)) {
            $inside = true;
        }

        // چهار گوشه
        if (pow($x - $radius, 2) + pow($y - $radius, 2) <= $radius2) $inside = true;
        if (pow($x - ($card_w - $radius), 2) + pow($y - $radius, 2) <= $radius2) $inside = true;
        if (pow($x - $radius, 2) + pow($y - ($card_h - $radius), 2) <= $radius2) $inside = true;
        if (pow($x - ($card_w - $radius), 2) + pow($y - ($card_h - $radius), 2) <= $radius2) $inside = true;

        imagesetpixel($mask, $x, $y, $inside ? $mask_solid : $mask_trans);
    }
}

// اعمال ماسک روی کارت
$card_final = imagecreatetruecolor($card_w, $card_h);
imagesavealpha($card_final, true);
imagefill($card_final, 0, 0, $transparent_card);

for ($x = 0; $x < $card_w; $x++) {
    for ($y = 0; $y < $card_h; $y++) {
        $alpha = (imagecolorat($mask, $x, $y) >> 24) & 0x7F;
        if ($alpha == 0) {
            $col = imagecolorat($card, $x, $y);
            imagesetpixel($card_final, $x, $y, $col);
        }
    }
}

// کپی کارت روی بوم اصلی
imagecopy($img, $card_final, $card_margin, $card_margin, 0, 0, $card_w, $card_h);

/* ----------------  پرچم (ریجن) – گرد  ---------------- */

$region_path = gm_url_to_path($region_url);
$flag_img    = gm_load_image_any($region_path);

if ($flag_img) {
    $flag_size   = 140;
    $flag_circle = gm_circle_crop($flag_img, $flag_size);

    // گوشه بالا-چپ کارت (نه کل تصویر)
    $fx = $card_margin + 40;
    $fy = $card_margin + 40;

    imagecopy($img, $flag_circle, $fx, $fy, 0, 0, $flag_size, $flag_size);

    imagedestroy($flag_img);
    imagedestroy($flag_circle);
}

/* ----------------  لوگوی پلتفرم – وسط کارت  ---------------- */

$platform_path = gm_url_to_path($platform_url);
$platform_img  = gm_load_image_any($platform_path);

if ($platform_img) {
    $pw = imagesx($platform_img);
    $ph = imagesy($platform_img);

    $target_h = 150; // ارتفاع نهایی لوگو
    $target_w = (int)($pw * ($target_h / $ph));

    // وسط افقی کارت
    $px = (int)($card_margin + ($card_w / 2) - ($target_w / 2));
    // پایین کارت با فاصله از پایین
    $py = (int)($card_margin + $card_h - $target_h - 120);

    imagecopyresampled(
        $img,
        $platform_img,
        $px, $py,
        0, 0,
        $target_w, $target_h,
        $pw, $ph
    );

    imagedestroy($platform_img);
}

/* ----------------  قیمت + نماد پول  ---------------- */

$white  = imagecolorallocate($img, 255, 255, 255);
$shadow = imagecolorallocatealpha($img, 0, 0, 0, 80);

$font = get_stylesheet_directory() . '/assets/font/Peyda-Bold.ttf';
$price_text = $price . ' ' . $currency_symbol;

// اگر فونت نیست، متن را رد کن تا خطا ندهد
if (file_exists($font)) {
    // سایه
    @imagettftext($img, 170, 0, 310+6, 330+6, $shadow, $font, $price_text);
    // متن
    @imagettftext($img, 170, 0, 310,   330,   $white,  $font, $price_text);
}

/* ----------------  خروجی  ---------------- */

imagepng($img);
imagedestroy($img);
