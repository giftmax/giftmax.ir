<?php
if (! $order instanceof \WC_Order) {
    return;
}
wp_nonce_field( 'giftmax_order_licences', 'giftmax_order_licences_nonce' );

?>
<style>
    .sfkdkd:focus{
        outline: none;
        box-shadow: none;
    }
    .Button-dlfa45 {
        background-color: #ebeff8;
        border: 1px solid #d8e4ff;
        font-size: 12px;
        border-radius: 5px;
        padding: 3px 7px;
        color: #000000;
        font-weight: 500;
        cursor: pointer;
    }
</style>
<div>
    <h3>افزودن لایسنس</h3>
    <p style="margin-bottom:8px;">فرمت: هر خط = <code>LICENCE_CODE</code></p>
</div>
<?php
$logger = function_exists( 'wc_get_logger' ) ? wc_get_logger() : null;
foreach ( $order->get_items() as $item_id => $item ) {
$product = $item->get_product();
$product_name = $product ? $product->get_name() : $item->get_name();
$delivery = get_post_meta($product->get_id(), 'delivery', true);

$is_preorder = isset($delivery['two']) && $delivery['two'] == 'on';

if($is_preorder) {
    $tps =  '<span style="background: #f39c12; color: white; padding: 3px 8px; border-radius: 5px; font-size: 12px;margin: 5px">پیش فروش</span>';
} else {
    $tps = '<span style="background: #77f312; color: white; padding: 3px 8px; border-radius: 5px; font-size: 12px;margin: 5px">آنی</span>';
}
?>
<div style="margin-bottom: 12px; border: 1px solid #e5e5e5; border-radius: 8px;">
    <div style="border-bottom: 1px solid #eee;padding: 10px;display: flex;justify-content: space-between;">
        <strong><?= esc_html( $product_name )?></strong>
        <?=$tps?>
    </div>
    <div style="display: flex;">
        <div style="width: 50%;padding: 10px">
            <?php
            $existing = $item->get_meta( '_reserved_licence_ids', true );
            $existing = is_string( $existing ) ? json_decode( $existing, true ) : $existing;
            if ( is_array( $existing ) && ! empty( $existing ) ) {
                ?>
                    <div style="display: flex;flex-direction: column;gap: 5px">
                    <?php
                foreach ( $existing as $lic_id ) {
                    $lic = \Giftmax\modules\LicenseManager::ShowLicense( $lic_id, $order->get_id() );

                        if (!is_null($lic['file_id'])){
                            $file = \Giftmax\model\SiteModel::table('product_licences_file','file_id',$lic['file_id']);

                            $relative_path = ltrim(str_replace(ABSPATH, '', $file['url']), '/');
                            $name = $file['name'];
                            $code = "<div class='download-file' data-url='$relative_path'>$name</div>";
                        }else{
                            $code = decrypt_data($lic['licence_code']);
                        }
                        if (!empty($lic['description'])){
                            $rDescription = $lic['description'];
                            $des = "<div style='margin-right: 10px'>$rDescription</div>";
                         }else{
                            $des =  "";
                        }
                    echo '<div style="display: flex;justify-content: space-between; align-items: center;"><span style="font-size: 13px; color: #767676;">' . ( $code ) . '</span> ' .  ($des) . ' <button class="Button-dlfa45" data-ei="'. encrypt_data($lic_id . '|' . $order->get_id()) .'">حذف</button></div>';
                }
                echo '</div>';
            }else{
                echo '<div>لایسنسی وجود ندارد</div>';
                    }
            ?>
        </div>
        <div style="border-right: 2px solid #e9edf5;width: 45%;padding: 10px">
            <div style="display: inline-flex; width: 100%; border-radius: 8px; overflow: hidden; padding: 4px; color: #333; border: 1px solid #ccc; background-color: #fff;">
                <textarea class="sfkdkd" style="font-size: 14px; font-weight: 325; line-height: 20px; letter-spacing: -.28px; flex-grow: 1; border: 0; outline: 0; resize: vertical; color: #333; padding: 4px; min-height: 48px; background-color: transparent;" type="text" rows="3"  name="giftmax_order_licences[<?= esc_attr( $item_id )?>]" placeholder="کد.."></textarea>
            </div>
        </div>
    </div>
</div>
<?php
}
?>
    <script>
        var wpApiSettingsGiftMax = {root:"<?= esc_url_raw(rest_url())?>",nonce:"<?=wp_create_nonce('wp_rest')?>"};
        jQuery(function (){
            jQuery(document).on('click', '.Button-dlfa45', function(e){
                e.preventDefault();
                let passCookie = document.cookie.includes('my_product_access=');
                if (!passCookie) {
                    if (!document.querySelector('.d5fsdf')) {
                        document.body.classList.add("lock-body-scroll");
                        $('#wpwrap').append(`<div class="d5fsdf"> <div class="form"> <h2>Password Security Product</h2> <input type="password" id="my_product_password"> <button type="button" class="giftmax-security-submit_license"> Send Data </button> </div></div>`)
                    }
                    return false;
                }
                const dataAjax = {
                    ei: jQuery(this).data('ei')
                }
                const button = jQuery(this);
                const ajaxOptions = {
                    url: `${wpApiSettingsGiftMax.root}api/v3/delete-licence`,
                    method: 'POST',
                    dataType: 'json',
                    data: dataAjax,
                    beforeSend: function (xhr) {
                        xhr.setRequestHeader('X-WP-Nonce', wpApiSettingsGiftMax.nonce);
                    },
                    success: function (response) {
                        if (!response.status){
                            alert(response.message);
                            return false;
                        }
                        button.closest('div').remove();
                    },
                    error: function (jqXHR, exception) {
                        if (jqXHR.status === 0) {
                            alert('Not connect.\n Verify Network.');
                        } else if (jqXHR.status == 404) {
                            alert('Requested page not found. [404]');
                        } else if (jqXHR.status == 500) {
                            alert('Internal Server Error [500].');
                        } else if (exception === 'parsererror') {
                            alert('Requested JSON parse failed.');
                            alert(jqXHR.message);
                        } else if (exception === 'timeout') {
                            alert('Time out error.');
                        } else if (exception === 'abort') {
                            alert('Ajax request aborted.');
                        } else {
                            alert('Uncaught Error.\n' + jqXHR.message);
                        }
                    }
                };
                jQuery.ajax(ajaxOptions);
                return false;
            });
        })
    </script>
