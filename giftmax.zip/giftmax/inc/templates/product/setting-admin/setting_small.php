<?php
$delivery = get_post_meta(get_the_ID(), 'delivery', true);
?>
<div class="setting_box__send">
    <h3>نوع تحویل</h3>
    <div class="setting_bot_send d-flex">
        <p class="P-setting_bot_send w60">آنی</p>
        <label for="p-autoPlaySwitch"class="input-label start w40_1">
            <span class="start-label"></span>
            <input id="p-autoPlaySwitch" type="checkbox" onclick="changeSwitch('#w-autoPlaySwitch')" name="delivery[one]" class="input">
            <span class="input-check"></span>
        </label>
    </div>
    <div class="setting_bot_send d-flex">
        <p class="P-setting_bot_send w60">پیش فروش</p>
        <label for="w-autoPlaySwitch" class="input-label start w40_1">
            <span class="start-label"></span>
            <input id="w-autoPlaySwitch" type="checkbox" onclick="changeSwitch('#p-autoPlaySwitch')" name="delivery[two]" class="input">
            <span class="input-check"></span>
        </label>
    </div>
    <div class="hidden" id="delivery_small">
        <p class="s-setting_bot_send w60">متن پیش فروش</p>
        <textarea id="delivery_description" name="delivery[description]" style="width: 100%"><?=isset($delivery['description']) ? $delivery['description'] : '' ?></textarea>
        <p class="s-setting_bot_send w60">زمان موجود (ساعت)</p>
        <input id="delivery_time" name="delivery[time]" placeholder="70" style="width: 100%" value="<?=isset($delivery['time']) ? $delivery['time'] : '' ?>">
    </div>
    <h3>عکس</h3>
    <div class="setting_bot_send d-flex">
        <p class="s-setting_bot_send w60">ساخت عکس</p>
        <label for="s-autoPlaySwitch"class="input-label start w40_1">
            <span class="start-label"></span>
            <input id="s-autoPlaySwitch" type="checkbox" name="create_img" class="input">
            <span class="input-check"></span>
        </label>
    </div>
</div>

<script>
    jQuery(document).ready(function ($) {
        <?php
        if (isset($delivery['two']) && $delivery['two'] == 'on'){
        ?>
        document.querySelector("#delivery_small").classList.toggle('hidden');
    <?php
        }
        if (!empty($delivery)){
        ?>
        document.querySelectorAll(`input[name='delivery[<?=isset($delivery['two']) && $delivery['two'] == 'on' ? 'two' : 'one'?>]']`)[0].checked = true;

        <?php
        }else{?>
        document.querySelectorAll(`input[name='delivery[one]`)[0].checked = true;
    <?php }
        ?>
        $(document).on('change','#w-autoPlaySwitch',function (){
            const w = $(this).is(':checked') ? 1 : 0;
            if (w){
                document.querySelector("#delivery_small").classList.toggle('hidden');
            }else{
                document.querySelector("#delivery_small").classList.toggle('hidden');
            }
        });
    });
</script>
