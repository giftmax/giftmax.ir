<?php
use Giftmax\model\UserModel;
?>
<div class="<?=WC()->cart &&  WC()->cart->get_cart() && is_user_logged_in() ? 'cart-preview__grid cart-preview__grid--board ' : ''?> cart-panel ">
    <?php

    if (WC()->cart &&  WC()->cart->get_cart() && is_user_logged_in()){
        $cart_items = WC()->cart->get_cart();
        ?>
        <div class="flex flex-col lg:w-70 justify-between md:h-stretch">
            <div class="flex md:h-380">
                <div class="cart-panel--list">
                    <div>
                        <div class="flex justify-between">
                            <div class="act-our-services-carousel-head-title">
                                <div class="act-our-services-carousel-head-title-divs">
                                    <div class="act-our-services-carousel-head-title-div1 tsc54b"></div>
                                </div>
                                <div class="act-our-services-carousel-head-title-content">
                                    <h5>سبد <strong>خرید</strong></h5>
                                    <p class="tsc54">SHOPPING CART</p>
                                </div>
                            </div>
                            <span class="SJf5GS"><?= ( WC()->cart ) ? WC()->cart->get_cart_contents_count() : 0?></span>
                        </div>
                        <div class="cart-list">
                            <?php
                            if(!isMobile()){
                                ?>
                                <table class="cart-table">
                                    <thead><tr><th>محصول</th><th>تعداد</th><th>قیمت واحد</th><th>جمع کل</th></tr></thead>
                                    <tbody>
                                    <?php
                                    foreach ( $cart_items as $cart_item_key => $cart_item ) {

                                        $product = $cart_item['data']; // آبجکت محصول
                                        $name = $product->get_name();
                                        $quantity = $cart_item['quantity'];
                                        $regular_price = $product->get_regular_price();
                                        $sale_price = $product->get_sale_price();
                                        $permalink = $product->get_permalink();

                                        ?>
                                        <tr data-mini-item="<?=$cart_item_key?>">
                                            <td>
                                                <div class="flex">
                                                    <div class="self-center">
                                                        <a class="font-size-14 text-dark font-bold tracking-tight leading-xs" href="<?=$permalink?>"><?=$name?></a></div>
                                                </div>
                                            </td>
                                            <td>
                                                <div class="rounded bg-light flex flex-row-reverse transition-opacity h-40 w-112">
                                                    <button type="button" class="pl-6 mini-quantity__btn" data-mini-decrease="">
                                                        <?php
                                                        if ($quantity == 1){
                                                            ?>
                                                            <i class="icon-delete text-xs text-red-dark text-opacity-90 bg-white shadow-sm block text-center rounded-sm w-28 h-28 !leading-[28px]"></i>
                                                            <?php
                                                        }else{
                                                            ?>
                                                            <i class="icon-minus text-[9px] text-gray pt-1 bg-white shadow-sm block text-center rounded-sm w-28 h-28 !leading-[28px]"></i>

                                                            <?php
                                                        }
                                                        ?>
                                                    </button>
                                                    <div class="grow text-center flex flex-col justify-center leading-1">
                                                        <div class="pt-2 text-dark font-bold tracking-tighter text-sm after:loading after:border-blue transition-colors after:text-3xs" data-mini-qty><?=$quantity?></div>
                                                    </div>
                                                    <button type="button" class="pr-6 mini-quantity__btn" data-mini-increase="">
                                                        <i class="bg-white shadow-sm text-gray rounded-sm icon-plus text-[9px] block text-center pt-1 w-28 h-28 !leading-[28px]"></i>
                                                    </button>
                                                </div>
                                            </td>
                                            <td>
                                                <div class="leading-1 pt-2 grow">
                                                    <?php
                                                    if ($product->is_on_sale()){
                                                        ?>
                                                        <span class="ml-6 font-size-13 text-sm font-bold text-red opacity-85 tracking-tighter mb-2 block line-through"><?=number_format_usd($regular_price)?></span>
                                                        <?php
                                                    }
                                                    ?>
                                                    <div class="text-2xs font-size-13 text-gray font-medium tracking-tight"><span
                                                            class="text-lg font-bold text-dark tracking-tighter pt-2 inline-block"><?=number_format_usd($product->is_on_sale() ? $sale_price : $regular_price)?></span>
                                                        تومان
                                                    </div>
                                                </div>
                                            </td>
                                            <?php
                                            $regular_price = (float) $product->get_regular_price();
                                            $quantity      = (int)  $cart_item['quantity'];

                                            $price_original_total = $regular_price * $quantity;
                                            $price_final_total    = $cart_item['line_total'];
                                            ?>
                                            <td>
                                                <div class="leading-1 pt-2 grow">
                                                    <?php
                                                    if ( $price_original_total > $price_final_total ) { ?>
                                                        <span class="ml-6 font-size-13text-sm font-bold text-red opacity-85 tracking-tighter mb-2 block line-through"><?=number_format_usd($price_original_total)?></span>
                                                        <?php
                                                    }
                                                    ?>
                                                    <div class="text-2xs text-gray font-medium tracking-tight"><span
                                                            class="font-size-13 text-lg font-bold text-dark tracking-tighter pt-2 inline-block"><?=number_format_usd($price_final_total)?></span>
                                                        تومان
                                                    </div>
                                                </div>
                                            </td>
                                        </tr>
                                        <?php
                                    }
                                    ?>
                                    </tbody>
                                </table>
                                <?php
                            }else{
                                ?>
                                <div class="cart-list">
                                    <?php
                                    foreach ( $cart_items as $cart_item_key => $cart_item ) {

                                        $product = $cart_item['data'];
                                        $name = $product->get_name();
                                        $permalink = $product->get_permalink();
                                        ?>
                                        <div class="p-20 border-b border-gray-300 last:!border-b-0" data-mini-item="<?=$cart_item_key?>">
                                            <div class="flex">
                                                <div class="pt-4 self-center grow pl-12">
                                                    <a class="text-normal text-dark font-bold tracking-tight leading-xs block" href="<?=$permalink?>"><?=$name?></a>
                                                    <div class="leading-xs mt-6 space-y-5"></div>
                                                </div>
                                                <a class="shrink-0" href="<?=$permalink?>">
                                                    <div class="relative">
                                                        <img alt="<?=$name?>" loading="lazy" width="72" height="72" decoding="async" data-nimg="1" class="shrink-0 rounded block w-60" src="<?=wp_get_attachment_image_url($product->get_image_id(),'product_discount')?>" style="color: transparent;">
                                                    </div>
                                                </a>
                                            </div>
                                            <div class="flex items-start mt-12">
                                                <div class="leading-1 pt-2 grow self-center">
                                                    <?php
                                                    $regular_price = (float) $product->get_regular_price();
                                                    $quantity      = (int)  $cart_item['quantity'];

                                                    $price_original_total = $regular_price * $quantity;
                                                    $price_final_total    = $cart_item['line_total'];
                                                    ?>
                                                    <div class="leading-1 pt-2 grow">
                                                        <?php
                                                        if ( $price_original_total > $price_final_total ) { ?>
                                                            <span class="ml-6 font-size-13text-sm font-bold text-red opacity-85 tracking-tighter mb-2 block line-through"><?=number_format_usd($price_original_total)?></span>
                                                            <?php
                                                        }
                                                        ?>
                                                        <div class="text-2xs text-gray font-medium tracking-tight"><span
                                                                class="font-size-13 text-lg font-bold text-dark tracking-tighter pt-2 inline-block"><?=number_format_usd($price_final_total)?></span>
                                                            تومان
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="rounded bg-light flex flex-row-reverse transition-opacity h-40 lg:w-60">
                                                    <button type="button" class="pl-6 mini-quantity__btn" data-mini-decrease="">
                                                        <?php
                                                        if ($quantity == 1){
                                                            ?>
                                                            <i class="icon-delete text-xs text-red-dark text-opacity-90 bg-white shadow-sm block text-center rounded-sm w-28 h-28 !leading-[28px]"></i>
                                                            <?php
                                                        }else{
                                                            ?>
                                                            <i class="icon-minus text-[9px] text-gray pt-1 bg-white shadow-sm block text-center rounded-sm w-28 h-28 !leading-[28px]"></i>

                                                            <?php
                                                        }
                                                        ?>
                                                    </button>
                                                    <div class="grow text-center flex flex-col justify-center leading-1">
                                                        <div class="pt-2 text-dark font-bold tracking-tighter text-sm after:loading after:border-blue transition-colors after:text-3xs" data-mini-qty><?=$quantity?></div>
                                                    </div>
                                                    <button type="button" class="pr-6 mini-quantity__btn" data-mini-increase="">
                                                        <i class="bg-white shadow-sm text-gray rounded-sm icon-plus text-[9px] block text-center pt-1 w-28 h-28 !leading-[28px]"></i>
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                        <?php
                                    }
                                    ?>
                                </div>
                                <?php
                            }
                            ?>
                        </div>
                    </div>
                    <div>
                        <div class="flex justify-between<?=!isMobile() ? '' : ' flex-col'?>">
                            <?php
                            $total_points = 0;

                            foreach ( WC()->cart->get_cart() as $cart_item_key => $cart_item ) {
                                $product  = $cart_item['data'];
                                $quantity = $cart_item['quantity'];
                                $settings = get_post_meta($product->get_id(), 'giftmax_box_setting', true);
                                $item_points = empty($settings[0]['purchaseScore']) ? 0 : $settings[0]['purchaseScore'];
                                $line_points = $item_points * $quantity;
                                WC()->cart->cart_contents[ $cart_item_key ]['points'] = $line_points;
                                $total_points += $line_points;
                            }
                            WC()->session->set( 'total_cart_points', $total_points );
                            if (!isMobile()){
                                ?>
                                <div class="cart-timer" role="status">
                                    <p class="eyebrow font-size-13">مهلت تکمیل خرید</p>
                                    <h3 class="cart-timer__value" data-cart-timer=""></h3>
                                </div>
                                <div class="cart__purchaseScore">
                                    <i class="icon-star"></i>
                                    شما بابت این خرید <strong class="font-bold" id="total_points"><?=number_format($total_points)?> امتیاز</strong> دریافت میکنید!
                                </div>
                                <?php
                            }else{?>
                                <div class="tracking-tight alert text-xs font-normal rounded-none px-16 lg:px-28 py-8 lg:py-12 flex items-center border-y border-dashed lg:mt-20 timerBox justify-between" style="background: linear-gradient(135deg, rgba(99, 102, 241, 0.08), rgba(139, 92, 246, 0.15)); border-color: rgb(203, 181, 255);">
                                    <p class="eyebrow font-size-13">مهلت تکمیل خرید</p>
                                    <h3 class="cart-timer__value" data-cart-timer=""></h3>
                                </div>
                                <div class="tracking-tight alert alert-primary bg-primary bg-opacity-[0.12] text-xs font-normal rounded-none px-16 lg:px-28 py-8 lg:py-12 flex items-center border-y border-primary border-dashed border-opacity-50 lg:mt-20 pointBox"><i class="icon-star text-[#D19411] text-xs ml-8 -mr-2"></i>
                                    <div class="grow pst-4 flex align-items-center">شما بابت این خرید <strong class="font-bold"><?=number_format($total_points)?></strong> دریافت میکنید!</div>
                                </div>
                                <?php
                            }
                            ?>
                        </div>
                    </div>
                </div>
                <div class="cart-panel--invoice">
                    <div class="act-our-services-carousel-head-title">
                        <div class="act-our-services-carousel-head-title-divs">
                            <div class="act-our-services-carousel-head-title-div1 tsc54b"></div>
                        </div>
                        <div class="act-our-services-carousel-head-title-content">
                            <h5>احراز <strong>هویت</strong> </h5>
                            <p class="tsc54">IDENTITY VERIFICATION</p>
                        </div>
                    </div>
                    <?php
                    $user = wp_get_current_user();
                    $u = \Giftmax\model\SiteModel::table('user_identity','user_id',$user->ID);
                    $isVip = (isset($u['account_type']) && $u['account_type'] === 'vip');
                    ?>
                    <div class="profile-content">
                        <div class="profile-section-container">
                            <div class="profile-section c-box__info <?=$isVip ? 'w-full' : ''?>">
                                <div>IP<span><?=giftmax_get_user_ip()?></span></div>
                                <?php
                                ?>
                                <div>
                                    شماره تلفن
                                    <span><?=$user->user_login?></span>
                                </div>
                                <div>
                                    تلفن ثابت
                                    <?php
                                    if (!empty($u['landline_phone'])){
                                        ?>
                                        <span><?=decrypt_data($u['landline_phone'])?></span>
                                        <?php
                                    }else{?>
                                        <div class="Button-lp56">تایید تلفن ثابت</div>
                                        <?php
                                    }
                                    ?>
                                </div>
                                <div>کدملی<span><?=!empty($u['national_id_enc']) ? decrypt_data($u['national_id_enc']) : ''?></span></div>
                                <div>تاریخ تولد<span><?=!empty($u['birth_date_enc']) ? decrypt_data($u['birth_date_enc']) : ''?></span></div>
                                <div>سطح اکانت
                                    <?php
                                    if (isset($u['account_type']) && $u['account_type'] == 'vip'){
                                        ?>
                                        <span style="
    background-color: #ff9100;
    color: #FFF;
    padding: 0 10px;
    border-radius: 8px;
">ویژه</span>
                                        <?php
                                    }else{?>
                                        <span style="background-color: #ff0000; color: #FFF; padding: 3px; border-radius: 8px; font-size: 12px; line-height: 1; display: flex; align-items: center;">معمولی</span>
                                    <?php }
                                    ?>
                                </div>
                            </div>
                        </div>

                        <script>
                            window.vip = <?= $isVip ? 1 : 0; ?>;
                        </script>
                        <?php
                        global $wpdb;
                        $db = \Giftmax\modules\Db::getLnstance();
                        $records = $db->first("SELECT * FROM `{$wpdb->prefix}setting` WHERE `meta_key`='stp'");
                        if (!empty($records)){
                            $record = json_decode($records['meta_value'], true);
                            if ($isVip){
                                ?>
                                <div class="profile-section-container">
                                    <div class="profile-section px-[16px]">
                                        <div class="flex justify-between">
                                            <div class="flex justify-between lg:w-50">
                                                <h5>امتیاز وفاداری </h5>
                                                <p class="wejF5 profile-bpp"><?=number_format(UserModel::points())?></p>
                                            </div>
                                            <button class="Button-cc65 sdJHS56">
                                                تبدیل به اعتبار
                                            </button>
                                        </div>
                                    </div>
                                    <p class="profile-text-info"><?='هر' . number_format($record[0]['points']) . ' امتیاز معادل است با' . number_format($record[0]['toman'])?></p>
                                </div>

                                <div class="profile-section-container mt-3">
                                    <div class="profile-section px-[16px]" style="margin-bottom: 0">
                                        <div class="flex justify-between align-items-center">
                                            <div class="flex flex-col">
                                                <h5>کیف پول</h5>
                                            </div>
                                            <button class="Button-oc64 sdJHS56">
                                                افزایش
                                            </button>
                                        </div>
                                    </div>
                                </div>
                                <?php
                            }else{
                                ?>
                                <div class="flex justify-between profile-section-container xs:flex-col">
                                    <?php
                                    if (isMobile()){?>
                                        <div class="w-full">
                                            <div class="profile-section px-[10px]">
                                                <div class="flex justify-between">
                                                    <div class="flex justify-between" style="width: 68%">
                                                        <h5>امتیاز </h5>
                                                        <p class="wejF5 profile-bpp" style="border-radius: 999px"><?=number_format(UserModel::points())?></p>
                                                    </div>
                                                    <button class="Button-cc65 sdJHS56">
                                                        تبدیل به اعتبار
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="w-full">
                                            <div class="profile-section px-[10px]">
                                                <div class="flex justify-between align-items-center">
                                                    <div class="flex flex-col">
                                                        <h5>کیف پول</h5>
                                                    </div>
                                                    <button class="Button-oc64 sdJHS56">
                                                        افزایش
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    <?php }else{?>
                                        <div class="lg:w-60">
                                            <div class="profile-section px-[10px]">
                                                <div class="flex justify-between">
                                                    <div class="flex justify-between lg:w-50">
                                                        <h5>امتیاز </h5>
                                                        <p class="wejF5 profile-bpp"><?=number_format(UserModel::points())?></p>
                                                    </div>
                                                    <button class="Button-cc65 sdJHS56">
                                                        تبدیل به اعتبار
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="lg:w-40 mr-1">
                                            <div class="profile-section px-[10px]">
                                                <div class="flex justify-between align-items-center">
                                                    <div class="flex flex-col">
                                                        <h5>کیف پول</h5>
                                                    </div>
                                                    <button class="Button-oc64 sdJHS56">
                                                        افزایش
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    <?php }
                                    ?>
                                </div>
                                <div class="profile-section-container">
                                    <p class="profile-text-info"><?='هر' . number_format($record[0]['points']) . ' امتیاز معادل است با' . number_format($record[0]['toman'])?></p>
                                </div>
                                <?php
                            }
                        }
                        if (!$isVip){
                            $cards = Giftmax\model\UserModel::cardsBankUser($user->ID);
                            ?>
                            <div class="profile-section-container">
                                <div class="card-grid card-grid--swiper profile-section" style="margin-bottom: 0">
                                    <duv class="flex justify-between">
                                        <div class="profile-section-section-name">
                                            <div class="flex justify-between gap-2">
                                                <span>کارت های بانکی</span>
                                                <?php
                                                if (!empty($cards) && count($cards) !=0){
                                                    ?>
                                                    <p class="profile-bpp"><?=count($cards)?></p>
                                                    <?php
                                                }else{
                                                    ?>
                                                    <p class="profile-bpp">0</p>
                                                    <?php
                                                }
                                                ?>
                                            </div>
                                        </div>
                                        <button class="Button-ac45">افزودن</button>
                                    </duv>
                                    <?php
                                    if (!empty($cards)) {
                                        ?>
                                        <div class="swiper bank-cards-swiper">
                                            <div class="swiper-wrapper">
                                                <?php foreach ($cards as $card) {
                                                    $cardNumber = rtrim(chunk_split(decrypt_data($card['card_number_enc']), 4, '-'), '-');
                                                    ?>
                                                    <div class="swiper-slide">
                                                        <article class="bank-card">
                                                            <div class="bank-card-content">
                                                                <div class="flex justify-end align-items-center">
                                                                    <div class="bank-card__top">
                                                                        <div class="bank-card__logo" aria-hidden="true">
                                                                            <img loading="lazy" decoding="async" data-nimg="1" class="h-auto" src="<?=detectBankImage(decrypt_data($card['card_number_enc']))?>" style="color: transparent;width: 20px" data-booster-processed="true">
                                                                        </div>
                                                                    </div>
                                                                    <div class="bank-card__number"><?=$cardNumber?></div>
                                                                </div>
                                                                <?php
                                                                if (empty($card['phone'])){
                                                                    ?>
                                                                    <div class="flex justify-between align-items-center relative">
                                                                        <div class="bank-card_user_status success">
                                                                            تحت مالکیت شما
                                                                        </div>
                                                                        <div class="w-[50px] lottie-container absolute -right-50" data-lottie-url="<?=get_template_directory_uri()?>/assets/img/wsl/card-done.json"></div>
                                                                    </div>
                                                                    <?php
                                                                }else{?>
                                                                    <div class="flex justify-between align-items-center relative">
                                                                        <div class="bank-card_user_status danger">
                                                                            مالک شما نیستید
                                                                        </div>
                                                                        <div class="w-[50px] lottie-container absolute -right-50" data-lottie-url="<?=get_template_directory_uri()?>/assets/img/wsl/card-error.json"></div>
                                                                    </div>
                                                                <?php }
                                                                ?>
                                                            </div>
                                                            <div class="V10-3-Bank">
                                                                <?php
                                                                $cardSetting = detectBankImageBg($cardNumber,'v1');
                                                                if (empty($card['phone'])){
                                                                    $user = get_userdata($card['user_id']);
                                                                    $userdata = UserModel::table('user_identity','user_id',$card['user_id']);
                                                                    ?>
                                                                    <span class="numberCard" style="bottom: <?=$cardSetting['positionText']?>px;<?=!is_null($cardSetting['color']) ? "color:" . $cardSetting['color'] : '' ?>"><?=$cardNumber?></span>
                                                                    <img alt="bank" loading="lazy" src="<?=$cardSetting['img']?>">
                                                                    <span class="number-user" style="bottom: <?=$cardSetting["Box"]["y"]?>px;color:<?=$cardSetting["Box"]["color"]?>"><?=$user->user_login?></span>
                                                                    <span class="birthday-user" style="bottom: <?=$cardSetting["Box"]["y"]?>px;color:<?=$cardSetting["Box"]["color"]?>"><?=decrypt_data($userdata['birth_date_enc'])?></span>
                                                                    <span class="national__code-user" style="bottom: <?=$cardSetting["Box"]["y"]?>px;color:<?=$cardSetting["Box"]["color"]?>"><?=decrypt_data($userdata['national_id_enc'])?></span>
                                                                    <span class="full__name-user" style="bottom: <?=$cardSetting["Box"]["y"]?>px;color:<?=$cardSetting["Box"]["color"]?>"><?=$user->first_name . ' ' . $user->last_name?></span>

                                                                    <?php
                                                                }else{
                                                                    ?>
                                                                    <span class="numberCard" style="bottom: <?=$cardSetting['positionText']?>px;<?=!is_null($cardSetting['color']) ? "color:" . $cardSetting['color'] : '' ?>"><?=$cardNumber?></span>
                                                                    <span class="number-user" style="bottom: <?=$cardSetting["Box"]["y"]?>px;color:<?=$cardSetting["Box"]["color"]?>"><?=decrypt_data($card['phone'])?></span>
                                                                    <span class="birthday-user" style="bottom: <?=$cardSetting["Box"]["y"]?>px;color:<?=$cardSetting["Box"]["color"]?>"><?=decrypt_data($card['birth_date'])?></span>
                                                                    <span class="national__code-user" style="bottom: <?=$cardSetting["Box"]["y"]?>px;color:<?=$cardSetting["Box"]["color"]?>"><?=decrypt_data($card['national_code'])?></span>
                                                                    <span class="full__name-user" style="bottom: <?=$cardSetting["Box"]["y"]?>px;color:<?=$cardSetting["Box"]["color"]?>"><?=$card['first_name'] . ' ' . $card['last_name']?></span>
                                                                    <img alt="bank" loading="lazy" src="<?=$cardSetting['img']?>">
                                                                <?php }
                                                                ?>
                                                            </div>
                                                        </article>
                                                    </div>

                                                    <?php
                                                } ?>
                                            </div>
                                        </div>
                                        <?php
                                    } else {
                                        ?>
                                        <div class="flex justify-center align-items-center px-[10px]">
                                            <div class="lottie-container w-[50px]" data-lottie-url="<?=get_template_directory_uri()?>/assets/img/wsl/card.json"></div>
                                            <div class="text-body2-strong text-[#027275]">کارت بانکی ثبت نشده</div>
                                        </div>
                                        <?php
                                    }
                                    ?>
                                </div>
                            </div>
                            <?php
                        }
                        ?>
                    </div>
                </div>
            </div>
            <div class="ktfb">
                <h4>نکات مهم :</h4>
                <p> 1.  سبد خرید شما تا زمانی که پرداخت نهایی انجام نشه، قطعی رزرو نشده.لطفاً تا ۵ دقیقه آینده سفارشتون رو تکمیل و پرداخت کنید، وگرنه آیتم‌های داخل سبد به صورت خودکار آزاد و حذف می‌شن.</p>
                <p> 2. در صورت تکمیل سفارش و انجام فرایند احراز هویت و تحویل محصول خریداری شده ،فاکتور قابل عودت و برگشت به هیچ وجه ممکن نخواهد بود.</p>
                <p>3. درصورت عودت هرگونه وجهی ، 10% ارزش افزوده از مبلغ واریزی کسر و باقیمانده مبلغ طی 24 ساعت کاری به همان کارت بانکی که خرید شده است عودت خواهد شد.</p>
            </div>
        </div>

        <div class="cart-panel--payment lg:w-30 md:h-stretch">
            <div class="act-our-services-carousel-head-title">
                <div class="act-our-services-carousel-head-title-divs">
                    <div class="act-our-services-carousel-head-title-div1 tsc54b"></div>
                </div>
                <div class="act-our-services-carousel-head-title-content">
                    <h5><strong>پرداخت</strong> </h5>
                    <p class="tsc54">PAYMENT</p>
                </div>
            </div>
            <div class="flex justify-between" style="margin: 21px 0">
                <button class="payment active Button-pr44"><div>پرداخت ریالی</div></button>
                <button class="payment Button-pu44"><div>پرداخت با رمز ارز ها</div></button>
            </div>
            <div class="invoice-board">
                <div class="flex flex-col relative grow">
                    <div class="grow before:loading">
                        <div class="space-y-10 lg:space-y-12 lg:sticky lg:top-28">
                            <?php
                            $cart_product_discount = 0;

                            foreach ( WC()->cart->get_cart() as $cart_item ) {
                                $product = $cart_item['data'];
                                $qty     = (int) $cart_item['quantity'];
                                $regular_price = (float) $product->get_regular_price();
                                $line_total    = $cart_item['line_total'];
                                $cart_product_discount += ($regular_price * $qty) - $line_total;
                            }

                            $total_discount        = $cart_product_discount;
                            ?>
                            <div class="flex items-center leading-xs"><span class="grow text-xs tracking-tight font-medium text-dark">قیمت کل</span>
                                <div class="text-2xs text-gray font-medium tracking-tight" data-summary="subtotal">
                                                <span
                                                    class="text-larger font-bold text-dark tracking-tighter pt-2 inline-block"><?=number_format_usd(WC()->cart->get_subtotal()+$total_discount)?></span>
                                    تومان
                                </div>
                            </div>
                            <div class="flex items-center leading-xs"><span
                                    class="grow text-xs tracking-tight font-medium text-dark">تخفیف سبد خرید</span>
                                <div class="text-2xs text-gray font-medium tracking-tight" data-summary="discount">
                                    <span class="text-larger font-bold text-red tracking-tighter pt-2 inline-block"><?= number_format_usd($total_discount) ?></span>
                                    تومان
                                </div>
                            </div>
                            <div class="flex items-center leading-xs">
                                <div class="grow">
                                    <span class="block text-xs tracking-tight font-medium text-dark">کد تخفیف</span>
                                </div>
                                <button type="button" class="btn !w-28 !text-5xs !text-green-dark !pt-2 !h-28 btn-white btn-icon icon-plus relative Button-cc59" aria-label="افزودن کد تخفیف"></button>
                            </div>
                            <div class="flex items-center leading-xs justify-between Box-cs65">
                                <div class="flex flex-col">
                                    <span class="grow text-xs tracking-tight font-medium text-dark pt-1">استفاده از کیف پول</span>
                                    <span id="balance" class="grow text-xs tracking-tight font-medium text-dark pt-1 <?=empty(\Giftmax\model\UserModel::wallet()) || !empty(UserModel::wallet()) && UserModel::wallet() ==0 ? 'hidden' : ''?>" style=" color: #a7a7a7; font-size: 12px; "><?=number_format(UserModel::wallet())?> تومان</span>
                                </div>
                                <div class="text-2xs text-gray font-medium tracking-tight">
                                    <label for="wallet" class="input-label start w40_1">
                                        <span class="start-label"></span>
                                        <?php
                                        if (!empty(UserModel::wallet()) && UserModel::wallet() != 0){
                                            ?>
                                            <input id="wallet" type="checkbox" class="input" <?= WC()->session->get('use_wallet',false) ? 'checked' : ''?>>
                                            <?php
                                        }
                                        ?>
                                        <span class="input-check" style="<?=empty(UserModel::wallet()) || !empty(UserModel::wallet()) && UserModel::wallet() ==0 ? 'cursor: no-drop;' : ''?>"></span>
                                    </label>
                                </div>
                            </div>
                            <div class="hr-p"></div>
                            <div class="flex items-center leading-xs"><span
                                    class="grow text-xs tracking-tight font-medium text-dark pt-1">مبلغ قابل پرداخت</span>
                                <div class="text-2xs text-gray font-medium tracking-tight" data-summary="total">
                                    <span class="text-lg font-bold text-green-dark tracking-tighter pt-2 inline-block"><?=number_format_usd( WC()->cart->get_total('edit'))?></span>
                                    تومان
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="border rounded mt-14 lg:mt-16 gateway-row flex">
                        <button type="button" class="border-l w-full text-right border-gray-300 last:!border-l-0 py-16 px-14 flex items-center Button-p4" data-gateway="zibal">
                            <div class="pt-2 grow leading-1 tracking-tight">
                                <span class="block text-xs text-dark font-bold">پرداخت آنلاین</span>
                                <span class="block text-2xs font-normal text-dark mt-8">درگاه پرداخت زیبال</span>
                            </div>
                            <i class="w-20 h-20 text-center rounded-circle text-4xs pl-1 ml-4 !leading-[22px] icon-check transition-colors text-white bg-green bg-opacity-100"></i>
                        </button>
                        <button type="button" class="border-l w-full text-right border-gray-300 last:!border-l-0 py-16 px-14 flex items-center Button-p4" data-gateway="paystar">
                            <div class="pt-2 grow leading-1 tracking-tight">
                                <span class="block text-xs text-dark font-bold">پرداخت آنلاین</span>
                                <span class="block text-2xs font-normal text-dark mt-8">درگاه پرداخت پی استار</span>
                            </div>
                            <i class="w-20 h-20 text-center rounded-circle bg-gray bg-opacity-15 text-4xs pl-1 ml-4 !leading-[22px] icon-check text-transparent transition-colors"></i>
                        </button>
                    </div>
                    <div class="css-transition-opacity after:loading !absolute inset-x-0 inset-y-0 bg-white bg-opacity-50 is-loading after:border-gray after:border-opacity-75 after:h-24 after:w-24 after:border-[3px] z-10 rounded-bl-lg"></div>
                </div>
            </div>
            <div class="swiper supported__brands hidden">
                <div class="swiper-wrapper">
                    <div class="swiper-slide">
                        <img alt="" loading="lazy" width="1000" height="120" decoding="async"
                             data-nimg="1" class="block dark:hidden" style="color:transparent"
                             src="<?=get_template_directory_uri()?>/assets/img/assets.jpeg"></div>
                    <div class="swiper-slide">
                        <img alt="" loading="lazy" width="1000" height="120" decoding="async"
                             data-nimg="1" class="block dark:hidden" style="color:transparent"
                             src="<?=get_template_directory_uri()?>/assets/img/assets.jpeg"></div>
                    <div class="swiper-slide">
                        <img alt="" loading="lazy" width="1000" height="120" decoding="async"
                             data-nimg="1" class="block dark:hidden" style="color:transparent"
                             src="<?=get_template_directory_uri()?>/assets/img/assets.jpeg"></div>
                    <div class="swiper-slide">
                        <img alt="" loading="lazy" width="1000" height="120" decoding="async"
                             data-nimg="1" class="block dark:hidden" style="color:transparent"
                             src="<?=get_template_directory_uri()?>/assets/img/assets.jpeg"></div>
                </div>
            </div>
            <button class="btn btn--gradient btn--block Button-pcu48">ثبت سفارش</button>
            <p class="payment--alert">کاربر گرامی <?="$user->first_name $user->last_name"?> ، خواهشمند است در هنگام پرداخت دقت فرمایید؛ زیرا جنس و کد دریافتی تحت هیچ شرایطی قابل عودت نمی‌باشد.</p>
        </div>
        <?php
    }else{
        if(!is_user_logged_in()){
            echo "<div class='flex mx-auto'><span>برای دسترسی به سبد خرید لاگین کنید</span></div>";
        }else if(empty(WC()->cart) || empty(WC()->cart->get_cart())){
            echo "<div class='flex mx-auto'><span>سبد خرید شما خالی است</span></div>";
        }
    }
    ?>
</div>