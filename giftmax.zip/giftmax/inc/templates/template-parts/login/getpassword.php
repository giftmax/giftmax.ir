<section class="h-screen d-flex flex-column jc-center ai-center">
    <div class="W3wYIMoFtWvsJZI8nfye w-100 d-flex flex-row-md">
        <form class="d-flex flex-column flex-1"><h1 class="color-n-900 mb-9 text-h5">رمز شما</h1>
            <p class="text-caption color-n-900 mb-4"><span>برای پنل رمز تعیین کنید تا امنیت آن حفظ شود:<br></span></p>
            <input class="d-none" type="text" name="userName" value="<?= $userName ?>">
            <input class="d-none" type="text" name="hash" value="<?=$hash?>">
            <label class="FormComponentFrame-sy77JE FormComponentFrame--normal-Tol9_4 mb-4">
                <p class="text-body-1 color-n-700 mb-2  text-right" data-testid="form-label">تعیین رمز</p>
                <div class="FormComponentFrame__input-container-fArle6 px-2 d-flex ai-center">
                    <section class="grow-1 text-body-2-c"><input
                                class="px-2 TextField__input-xuVYYy text-subtitle w-100 TextField-cJQfI5 TextField--primary-cAI5H3 color-n-700"
                                type="password" name="password" aria-label="password" placeholder=""
                                autocomplete="new-password" value=""></section>
                </div>
            </label>
            <span class="color-n-500 text-caption PasswordStrength__helper-DiMpWg  text-right" data-testid="isInputEmpty">انگلیسی / حداقل ۸ تایی / شامل حرف، عدد و نشانه</span>

            <div class="d-flex flex-column ai-start-md flex-1 QVKQ6PjasvqpZhgzjhtx">
                <button class="relative d-flex ai-center user-select-none uikit-atomic-ButtonBase-ButtonBase-module__btn--vgnTU text-button-1 uikit-atomic-ButtonBase-ButtonBase-module__btn--large--z9tJZ uikit-atomic-ButtonBase-ButtonBase-module__btn--primary--BJ1BU radius uikit-atomic-Button-Button-module__Button__large--eW66c uikit-atomic-Button-Button-module__Button__filledPrimary--isBw3 w-100 uikit-atomic-Button-Button-module__Button--TibOa Button-sp21" data-testid="button-wrapper" data-tag="jSBV1bczKB" type="submit">
                    <div class="d-flex ai-center jc-center relative grow-1">تایید</div>
                </button>
            </div>
        </form>
    </div>
</section>