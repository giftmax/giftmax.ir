<svg style="display:none;">
    <symbol id="arrowBack" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><title>
            arrowBack</title>
        <path d="M12.707 19.707l-1.414-1.414 5.293-5.293h-12.586v-2h12.586l-5.293-5.293 1.414-1.414 7 7c0.39 0.391 0.39 1.024 0 1.414l-7 7z"></path>
    </symbol>
    <symbol id="edit2" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><title>edit2</title>
        <path d="M15.293 3.293c0.391-0.391 1.024-0.391 1.414 0l4 4c0.391 0.391 0.391 1.024 0 1.414l-12 12c-0.188 0.188-0.442 0.293-0.707 0.293h-4c-0.552 0-1-0.448-1-1v-4c0-0.265 0.105-0.52 0.293-0.707l12-12zM5 16.414v2.586h2.586l11-11-2.586-2.586-11 11zM10 21l2-2h9v2h-11z">
        </path>
    </symbol>
</svg>
<section class="h-screen d-flex flex-column jc-center ai-center">
    <div class="W3wYIMoFtWvsJZI8nfye w-100 d-flex flex-row-md" data-otp="<?= \Giftmax\model\SiteModel::setting("otpAudioLogin") === true ? 'true' : 'false' ?>">
        <form class="d-flex flex-column flex-1">

            <div class=" d-flex flex-row ai-center mb-9">
                <h1 class="color-n-900 mr-5 text-h5">کد فعال&zwnj;سازی</h1></div>
            <p class="text-body-1 color-n-900 align-center
        mb-6">کد فعال&zwnj;سازی برای شما پیامک شده، لطفا کد را وارد کنید:</p>
            <input class="d-none" type="text" name="userName" value="<?=$userName?>">
            <a href="<?=home_url('/login-register')?>">
                <button class="relative d-flex ai-center user-select-none uikit-atomic-ButtonBase-ButtonBase-module__btn--vgnTU text-button-2 uikit-atomic-ButtonBase-ButtonBase-module__btn--primary--BJ1BU radius uikit-atomic-Button-Button-module__Button__medium--lj91O uikit-atomic-Button-Button-module__Button__filledPrimary--isBw3 uikit-atomic-Button-Button-module__Button__appendIcon--nkjE7 m-auto JeqA1oxSMo0JL646Ql52 uikit-atomic-Button-Button-module__Button--TibOa" data-testid="button-wrapper">
                    <div class="d-flex ai-center jc-center relative grow-1"><span class="text-body-1"><?=$userName?></span>
                        <div class="d-flex mr-2" data-testid="icon-wrapper">
                            <svg data-testid="button-append-icon" style="width: 24px; height: 24px; fill: var(--color-icon-primary);">
                                <use class="disable-events" xlink:href="#edit2"></use>
                            </svg>
                        </div>
                    </div>
                </button>
            </a>
            <div class="_wrap_87tyg_1 _input_pjp0p_66">
                <input type="text" class="_input_87tyg_11" data-method="login" inputmode="numeric">

                <div class="_digit_87tyg_33"><span></span></div>
                <div class="_digit_87tyg_33"><span></span></div>
                <div class="_digit_87tyg_33"><span></span></div>
                <div class="_digit_87tyg_33"><span></span></div>
                <div class="_digit_87tyg_33"><span></span></div>
                <div class="_digit_87tyg_33"><span></span></div>
            </div>
            <div class="d-flex mt-5 jc-center">
                <div class="d-flex text-body-2 color-text-high-emphasis pNnwhoGegGWZnsiA5MNB"> <div class="HRmXflgj_cRoqQlYQ4AI"> <div class="text-body2-strong color-brand-primary-700 SKjYxAE5y1LPRcDIO0Ax"> <span id="timer">02:00</span> </div> </div> مانده تا دریافت مجدد </div>
            </div>
        </form>

    </div>

</section>