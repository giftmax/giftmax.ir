<section class="h-screen d-flex flex-column jc-center ai-center">
    <div class="W3wYIMoFtWvsJZI8nfye w-100 d-flex flex-row-md">
        <div class="Q9tLx7RmVn2KpHc4sDua"></div>
        <form class="d-flex flex-column flex-1" data-gtm-form-interact-id="3">
            <a href="<?=home_url()?>">
                <img src="<?=get_template_directory_uri()?>/assets/img/logo.png">
            </a>
            <h1 class="text-body2-strong color-n-900 mb-9 text-h5">ورود یا ثبت نام</h1>
            <p class="text-body-1 color-n-900 mb-4 wrpzxqoY8gqAOiT0YZgh">سلام!
                به کیفت مکس خوش اومدید
                شماره موبایل خود را وارد کنید:</p>
            <label class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--L7bcQ uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--normal--A6Ntt">
                <p class="text-body-1 color-n-700 mb-2 text-right" data-testid="form-label">شماره موبایل </p>
                <div class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame__input-container--D5edN px-2 d-flex ai-center">
                    <section class="grow-1 text-body-2-c">
                        <input class="px-2 eFydYiN7dQ1Ds63mli7f text-subtitle w-100 jDSbpqUrUZFv23opBao9 color-n-700" type="tel" name="userName" placeholder="" autocomplete="email" value="" data-gtm-form-interact-field-id="3">
                    </section>
                </div>
            </label>
            <div class="d-flex flex-column ai-start-md flex-1 QVKQ6PjasvqpZhgzjhtx">
                <button class="relative d-flex ai-center user-select-none uikit-atomic-ButtonBase-ButtonBase-module__btn--vgnTU text-button-1 uikit-atomic-ButtonBase-ButtonBase-module__btn--large--z9tJZ uikit-atomic-ButtonBase-ButtonBase-module__btn--primary--BJ1BU radius uikit-atomic-Button-Button-module__Button__large--eW66c uikit-atomic-Button-Button-module__Button__filledPrimary--isBw3 w-100 uikit-atomic-Button-Button-module__Button--TibOa Button-lr54" data-testid="button-wrapper" data-tag="jSBV1bczKB" type="submit">
                    <div class="d-flex ai-center jc-center relative grow-1">تایید</div>
                </button>
            </div>
        </form>

    </div>

</section>
