<link rel="stylesheet" href="<?=get_stylesheet_directory_uri()?>/assets/css/payment.css">
<div class="container callback-card full-h">
    <mat-card class="mat-mdc-card mdc-card vertical-gap-10 p-4 w-[425px] mx-0 xs:mx-6">
        <div  class="mat-mdc-card-header d-block text-center">
            <div class="mat-mdc-card-header-text"></div>
            <div class="icon">
                <div>
                    <div role="img" class="mat-icon notranslate !h-[72px] !text-7xl !w-[72px] successful-icon mat-icon-no-color" aria-hidden="true" data-mat-icon-type="svg" data-mat-icon-name="successful">
                        <svg fill="none" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" fit="" height="100%"
                             width="100%" preserveAspectRatio="xMidYMid meet" focusable="false">
                            <defs></defs>
                            <path stroke="#ff4f00" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"
                                  d="M17 8l-5.565 6L9 11.375"></path>
                            <path stroke="#ff4f00" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"
                                  d="M17 8l-4.099 4.42a2 2 0 01-2.933 0L9 11.374"></path>
                            <path stroke="#0095da" stroke-linecap="round" stroke-width="1.5"
                                  d="M20 12a8 8 0 11-6-7.748"></path>
                        </svg>
                    </div>
                </div>
            </div>
            <div class="title text-success"> پرداخت شما قبلا تایید شده.</div>
        </div>
        <div class="mat-mdc-card-content">
            <div>
                <div class="fx-row fx-spacebetween-center">
                    <div class="key text-low-priority"> درگاه پرداخت</div>
                    <div class="value text-low-priority"><?=$gateway?></div>
                </div>
                <div class="separator !my-2"></div>
                <div class="fx-row fx-center-center gap-x-4 mt-8 no-capture">
                    <a href="<?=home_url()?>" color="primary" class="callback-success-btn text-2xl !h-12 mdc-button mdc-button--outlined mat-mdc-outlined-button mat-primary mat-mdc-button-base">
                        <span class="mat-mdc-button-persistent-ripple mdc-button__ripple"></span>
                        <span class="mdc-button__label">در حال انتقال به سایت ...</span>
                    </a>
                </div>
            </div>
        </div>
    </mat-card>
</div>