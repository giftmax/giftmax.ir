<link rel="stylesheet" href="<?=get_stylesheet_directory_uri()?>/assets/css/payment.css">
<div class="container callback-card full-h">
    <mat-card class="mat-mdc-card mdc-card vertical-gap-10 p-4 w-[425px] mx-0 xs:mx-6">
        <div  class="mat-mdc-card-header d-block text-center">
            <div class="mat-mdc-card-header-text"></div>
            <div class="icon">
                <div>
                    <div role="img" class="mat-icon notranslate !h-[72px] !text-7xl !w-[72px] fail-icon mat-icon-no-color" aria-hidden="true" data-mat-icon-type="svg" data-mat-icon-name="successful">
                        <svg fill="none" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" fit="" height="100%" width="100%" preserveAspectRatio="xMidYMid meet" focusable="false"><defs></defs><g stroke-linecap="round" stroke-width="1.5" clip-path="url('/callback/invoice/cab0d458-2c37-419f-98a7-1f9505554cbd?platform=ANDROID#ebclip0_1582_114562')"><path stroke="#ff4f00" stroke-linejoin="round" d="M9 9l6 6m0-6l-6 6M9 9l1.586 1.586a2 2 0 002.828 0L15 9M9 15l1.586-1.586a2 2 0 000-2.828L9 9"></path><path stroke="#ff4f00" stroke-linejoin="round" d="M9 15l1.586-1.586a2 2 0 012.828 0L15 15"></path><path stroke="#ff4f00" stroke-linejoin="round" d="M15 15l-1.586-1.586a2 2 0 010-2.828L15 9"></path><path stroke="#0095da" d="M12 20a8 8 0 100-16 8 8 0 000 16z"></path></g><defs><clipPath id="ebclip0_1582_114562"><path fill="#fff" d="M0 0h24v24H0z"></path></clipPath></defs></svg>
                    </div>
                </div>
            </div>
            <div class="title text-danger"> پرداخت شما انجام نشد.</div>
        </div>
        <div class="mat-mdc-card-content">
                <div class="fx-row fx-center-center gap-x-4 mt-8 no-capture">
                    <a href="<?=home_url()?>" color="primary" class="callback-success-btn text-2xl !h-12 mdc-button mdc-button--outlined mat-mdc-outlined-button mat-primary mat-mdc-button-base">
                        <span class="mat-mdc-button-persistent-ripple mdc-button__ripple"></span>
                        <span class="mdc-button__label">در حال انتقال به سایت ...</span>
                    </a>
                </div>
        </div>
    </mat-card>
</div>