<?php
use Giftmax\Modules\UserModel;


$current_user = wp_get_current_user();
$user_id = $current_user->ID;
$first_name = $current_user->first_name;
if (!isset(\Giftmax\Modules\UserModel::table("user_identity","user_id",$user_id)['account_type']) || \Giftmax\Modules\UserModel::table("user_identity","user_id",$user_id)['account_type']){
    $vip = 0;
}else{
    $vip = 1;
}
$recoords_Vip = UserModel::table("user_identity","user_id",$user_id);
if (is_array($recoords_Vip) && $recoords_Vip['account_type'] == 'vip'){
    $vip = 1;
}else{
    $vip = 0;
}
if ($vip){
    wp_redirect( esc_url( home_url( get_current_section_base())));
}
$db = \Giftmax\Modules\Db::getLnstance();
global $wpdb;
$National_card__img = $db->first("SELECT * FROM {$wpdb->prefix}documents WHERE user_id = :user_id AND doc_type = 'National_card__img' AND accepted=2 ",array('user_id' => $user_id));
$birth_certificate = $db->first("SELECT * FROM {$wpdb->prefix}documents WHERE user_id = :user_id AND doc_type = 'Birth_certificate' AND accepted=2 ",array('user_id' => $user_id));
$active_profile_tab = sanitize_key((string) get_query_var('profile_tab'));
$verification_note_code = get_user_meta($user_id, 'giftmax_verification_note_code', true);
if (empty($verification_note_code)) {
    $verification_note_code = (string) random_int(10000, 99999);
    update_user_meta($user_id, 'giftmax_verification_note_code', $verification_note_code);
}
$verification_note_date = gjdate(date("Y/m/d"),"Y/m/d");
if ($vip){
    wp_redirect( esc_url( home_url( get_current_section_base())));
}else{
    ?>
<main class="account-page">
    <section class="account-hero">
        <div class="container">
            <nav aria-label="مسیر دسترسی" class="breadcrumbs">
                <ol>
                    <li><a href="<?php echo site_url(); ?>">خانه</a></li>
                    <li aria-current="page">حساب کاربری</li>
                </ol>
            </nav>
        </div>
    </section>
    <section class="account-shell">
        <div class="container account-shell__layout">
            <aside class="account-sidebar" aria-label="منوی حساب کاربری">
                <div class="account-sidebar__card">
                    <div class="pb-28">
                        <div class="account-sidebar__header">
                            <div class="text-secondary font-bold tracking-tighter text-normal leading-xs grow"><?=$current_user->first_name . ' ' . $current_user->last_name?></div>
                            <?php
                            if (is_user_blocked()){
                                ?>
                                <div class="c-badge relative -top-2 text-2xs rounded-pill font-normal px-14">کاربر <span class="font-medium">مسدود </span></div>
                                <?php
                            }else{
                                ?>
                                <div class="c-badge relative -top-2 text-2xs rounded-pill font-normal px-14">کاربر <span class="font-medium"><?=$vip ?'ویژه': 'عادی'; ?></span></div>
                                <?php
                            }
                            ?>
                        </div>
                        <a class="alert alert-primary bg-primary bg-opacity-20 font-normal alert-sm flex items-start px-14 lg:px-16 mt-12" href="<?= esc_url( home_url( get_current_section_base() . '/wallet' ) ) ?>"><i class="icon-star pt-2 text-[#D19411] text-xs ml-8"></i><div class="grow">شما <strong class="font-bold"><?=number_format(UserModel::points())?> امتیاز</strong> دارید</div></a>
                    </div>
                    <?php
                    if (!empty($National_card__img) || !empty($birth_certificate)) {
                        $p = "100";
                    }elseif(is_array($recoords_Vip) && !$recoords_Vip['is_verified']){
                        $p = "30";
                    }else{
                        $p = "80";
                    }
                    if (!$vip){
                        ?>
                        <div class="account-progress">
                            <div class="account-progress__label">
                                <span>درصد تکمیل پروفایل</span>
                                <span><?=$p?>٪</span>
                            </div>
                            <div class="progress-bar">
                                <span style="width: <?=$p?>%"></span>
                            </div>
                            <?php
                            if($p != 100){
                                ?>
                                <button onclick="window.location.href='<?= esc_url( home_url( get_current_section_base() . '/verification' ) ) ?>'" type="button" class="btn btn--outline btn--block" data-panel-trigger="settings">تکمیل اطلاعات</button>
                                <?php
                            }
                            ?>
                        </div>
                        <?php
                    }
                    ?>
                    <a class="flex items-center py-16 leading-2 tracking-tight px-28 text-dark border-y border-gray border-opacity-[0.22] border-dashed relative before:absolute before:rounded-l before:transition-opacity before:w-4 before:bg-blue before:right-0 before:inset-y-16 before:opacity-0" href="<?= esc_url( home_url( get_current_section_base() . '/wallet' ) ) ?>"><div class="grow"><span class="font-medium text-xs block text-dark">موجودی کیف&zwnj;پول</span><div class="text-larger font-bold text-blue-dark tracking-tighter leading-1 pb-2 mt-3"><span class="text-gray"><?=number_format(UserModel::wallet()) != 0 ? number_format(UserModel::wallet()) : '-'?> تومان</span></div></div><div class="flex w-48 h-48 rounded-lg bg-blue-dark bg-opacity-10 items-center justify-center"><svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" class="w-22 h-22 fill-blue-dark"><path opacity="0.4" d="M18.04 13.55C17.62 13.96 17.38 14.55 17.44 15.18C17.53 16.26 18.52 17.05 19.6 17.05H21.5V18.24C21.5 20.31 19.81 22 17.74 22H6.26C4.19 22 2.5 20.31 2.5 18.24V11.51C2.5 9.44001 4.19 7.75 6.26 7.75H17.74C19.81 7.75 21.5 9.44001 21.5 11.51V12.95H19.48C18.92 12.95 18.41 13.17 18.04 13.55Z"></path><path d="M14.85 3.95V7.74999H6.26C4.19 7.74999 2.5 9.44 2.5 11.51V7.84002C2.5 6.65002 3.23 5.58997 4.34 5.16997L12.28 2.16997C13.52 1.70997 14.85 2.62 14.85 3.95Z"></path><path d="M22.56 13.9699V16.03C22.56 16.58 22.12 17.0299 21.56 17.0499H19.6C18.52 17.0499 17.53 16.2599 17.44 15.1799C17.38 14.5499 17.62 13.9599 18.04 13.5499C18.41 13.1699 18.92 12.95 19.48 12.95H21.56C22.12 12.97 22.56 13.4199 22.56 13.9699Z"></path><path d="M14 12.75H7C6.59 12.75 6.25 12.41 6.25 12C6.25 11.59 6.59 11.25 7 11.25H14C14.41 11.25 14.75 11.59 14.75 12C14.75 12.41 14.41 12.75 14 12.75Z"></path></svg></div></a>
                </div>

                <nav class="account-nav" role="tablist">

                    <a href="<?= esc_url( home_url( get_current_section_base() ) ) ?>"
                       class="account-nav__item <?= $active_profile_tab === '' ? 'active' : '' ?>"
                       role="tab">
                        <span class="icon icon-menu2"></span>
                        داشبورد
                    </a>

                    <a href="<?= esc_url( home_url( get_current_section_base() . '/orders' ) ) ?>"
                       class="account-nav__item <?= $active_profile_tab === 'orders' ? 'active' : '' ?>"
                       role="tab">
                        <span class="icon icon-order"></span>
                        سفارش‌های من
                    </a>
                    <a href="<?= esc_url( home_url( get_current_section_base() . '/list' ) ) ?>"
                       class="account-nav__item list-interest <?= $active_profile_tab === 'list' ? 'active' : '' ?>" role="tab">
                        <svg viewBox="0 0 24 24">
                            <path d="M12.62 20.81C12.28 20.93 11.72 20.93 11.38 20.81C8.48 19.82 2 15.69 2 8.68998C2 5.59998 4.49 3.09998 7.56 3.09998C9.38 3.09998 10.99 3.97998 12 5.33998C13.01 3.97998 14.63 3.09998 16.44 3.09998C19.51 3.09998 22 5.59998 22 8.68998C22 15.69 15.52 19.82 12.62 20.81Z" fill="none" stroke="inherit" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                        </svg>
                        لیست علاقه مندی
                    </a>
                    <a href="<?= esc_url( home_url( get_current_section_base() . '/deliveries' ) ) ?>"
                       class="account-nav__item <?= $active_profile_tab === 'deliveries' ? 'active' : '' ?>"
                       role="tab">
                        <span class="icon icon-flash"></span>
                        کدهای تحویل‌شده
                    </a>
                    <a href="<?= esc_url( home_url( get_current_section_base() . '/post' ) ) ?>"
                       class="account-nav__item <?= $active_profile_tab === 'post' ? 'active' : '' ?>"
                       role="tab">
                        <span class="icon icon-document"></span>
                        ارسال مقاله
                    </a>
                    <a href="<?= esc_url( home_url( get_current_section_base() . '/wallet' ) ) ?>"
                       class="account-nav__item <?= $active_profile_tab === 'wallet' ? 'active' : '' ?>"
                       role="tab">
                        <span class="icon icon-wallet"></span>
                        کیف پول و امتیاز
                    </a>
                    <?php
                    if (!$vip){
                        ?>
                        <a href="<?= esc_url( home_url( get_current_section_base() . '/verification' ) ) ?>"
                           class="account-nav__item <?= $active_profile_tab === 'verification' ? 'active' : '' ?>"
                           role="tab">
                            <span class="icon icon-verify"></span>
                            احراز هویت
                        </a>
                        <?php
                    }
                    ?>
                    <a href="<?= esc_url( home_url( get_current_section_base() . '/coupons' ) ) ?>"
                       class="account-nav__item <?= $active_profile_tab === 'coupons' ? 'active' : '' ?>"
                       role="tab">
                        <span class="icon icon-gift"></span>
                        کد های تخفیف
                    </a>
                    <a href="<?= esc_url( home_url( get_current_section_base() . '/cards' ) ) ?>"
                       class="account-nav__item <?= $active_profile_tab === 'cards' ? 'active' : '' ?>"
                       role="tab">
                        <span class="icon icon-card"></span>
                        کارت های بانکی
                    </a>
                    <a href="<?= esc_url( home_url( get_current_section_base() . '/user' ) ) ?>"
                       class="account-nav__item <?= $active_profile_tab === 'user' ? 'active' : '' ?>"
                       role="tab">
                        <span class="icon icon-user-o"></span>
                        تنظیمات حساب کاربری
                    </a>
                </nav>
            </aside>

            <div class="account-content">
                <div
                        class="account-panel active"
                        id="panel-verification"
                        data-panel="verification"
                        role="tabpanel"
                        aria-hidden="true"
                        tabindex="0"
                        hidden
                >
                    <div class="account-panel__header">
                        <div>
                            <h2>احراز هویت</h2>
                            <p>هنوز مدارک خود را اضافه نکرده‌اید. مدارک شما توسط کارشناسان بررسی می‌شود</p>
                        </div>
                    </div>
	                    <?php
	                    $records = $db->query("SELECT * FROM `{$wpdb->prefix}documents` WHERE `user_id` = :user_id",array('user_id' => $user_id));
                        $u = UserModel::table('user_identity','user_id',$user_id);
                        if (!empty($u['landline_phone'])) {
                            $elapsedSeconds = strtotime(date("Y-m-d H:i:s")) - strtotime($u['updated_at']);
                            $elapsedMinutes = $elapsedSeconds / 60;
                            $remainingMinutes = max(0, 15 - $elapsedMinutes);
                            $timer = round($remainingMinutes, 2);
                            if ($timer > 1){
                                $landline_phone = 1;
                            }else{
                                $landline_phone = 0;
                            }
                        }else{
                            $landline_phone = 0;
                        }
                        $has_only_rejected_documents = !empty($records) && is_array($records);
                        if ($has_only_rejected_documents) {
                            foreach ($records as $item) {
                                if (!isset($item['accepted']) || (int) $item['accepted'] !== 1) {
                                    $has_only_rejected_documents = false;
                                    break;
                                }
                            }
                        }
	                    if (!empty($records)){
	                        foreach ($records as $record){
	                            ?>
                            <div class=" d-flex flex-column  TableCell__cell-_0de25 col-span-2 py-4">
                                <div class="d-flex jc-between ai-center ">
                                    <div class="d-flex ai-center flex-1">
                                        <div class="radius-md  overflow-hidden TableCell__uploadImageButton-_1deeb" data-testid="image-wrapper" style="width: 70px; height: 70px;">
                                            <img class="w-100" src="<?=$record['document']?>" width="70" height="70" data-testid="image-defaultImage" style="object-fit: contain;">
                                        </div>
                                        <div class="d-flex flex-column flex-1 flex-wrap">
                                            <div class="d-flex ai-center">
	                                                <?php
	                                                if($record['doc_type']=="National_card__img"){
	                                                    $doc_type = "کارت ملی";
	                                                }elseif($record['doc_type']=="b___national_card__img"){
	                                                    $doc_type = "پشت کارت ملی";
	                                                }elseif($record['doc_type']=="Birth_certificate"){
	                                                    $doc_type = "شناسنامه";
	                                                }else{
	                                                    $doc_type = "مدرک شناسایی";
	                                                }
	                                                ?>
                                                <p class="text-subtitle-strong mb-2 ml-2 ProfileBase__ellipse-a1d8f1" style="--lines: 1;"><?=$doc_type?></p>
                                                <?php
                                                if ($record['accepted'] == 0){
                                                    $class = "Badge__info-_119b3";
                                                    $name = "در حال بررسی";
                                                }elseif ($record['accepted'] == 1){
                                                    $class = "Badge__error-c0a000";
                                                    $name = "رد شد";
                                                }else{
                                                    $class = "Badge__success-_57646";
                                                    $name = "تایید";
                                                }
                                                ?>
                                                <div class="d-inline-flex ai-center <?=$class?> text-no-wrap uikit-atomic-Badge-Badge-module__Badge--EYSe7 uikit-atomic-Badge-Badge-module__Badge--medium--mQBva px-3 text-body2-strong">
                                                    <?=$name?>
                                                </div>
                                            </div>
                                            <?php
                                            if ($record['accepted'] == 1){
                                                ?>
                                                <span class="Badge__error-c0a000 uilit-description">
                                                    <?=$record['description']?>
                                                </span>
                                                <?php
                                            }
                                            ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
	                            <?php
	                        }
                            if ($has_only_rejected_documents && !empty($u['landline_phone'])) {
                                ?>
                                <div class="mt-20 md:mt-24 lg:mt-28 pt-20 md:pt-24 lg:pt-28">
                                    <div class="md:pr-52 mt-10 md:mt-12">
                                        <div class="font-bold mb-4 md:mb-6 text-sm text-dark">مدارک شما رد شده‌اند</div>
                                        <div class="text-sm text-dark leading-sm">برای ادامه فرایند احراز هویت، مدرک اصلاح شده را دوباره بارگذاری کنید.</div>
                                        <div class="flex pt-16 md:pt-20 -mx-4 sm:-mx-12">
                                            <div class="grow px-4 sm:px-12 sm:basis-0">
                                                <div class="pb-8 flex items-center border-b-2 border-green"><i
                                                            class="w-24 h-24 rounded-circle hidden sm:flex items-center justify-center ml-8 shrink-0 text-green-dark bg-green bg-opacity-15 text-4xs pt-2 icon-check"></i><span
                                                            class="pt-4 leading-xs text-xs font-bold text-dark grow text-center sm:text-right whitespace-nowrap">نمونه قابل قبول</span>
                                                </div>
                                                <img alt="نمونه قابل قبول" loading="lazy" width="508" height="640"
                                                     decoding="async" data-nimg="1"
                                                     class="mt-20 max-h-[120px] sm:max-h-[140px] md:max-h-[160px] xl:max-h-[180px] block mx-auto w-auto cursor-pointer"
                                                     src="<?=get_template_directory_uri()?>/assets/img/acceptable-example.png"
                                                     style="color: transparent;"></div>
                                            <div class="grow px-4 sm:px-12 sm:basis-0">
                                                <div class="pb-8 flex items-center border-b-2 border-red"><i
                                                            class="w-24 h-24 rounded-circle hidden sm:flex items-center justify-center ml-8 shrink-0 text-red-dark bg-red bg-opacity-15 text-[8px] pt-2 icon-close"></i><span
                                                            class="pt-4 leading-xs text-xs font-bold text-dark grow text-center sm:text-right whitespace-nowrap">نمونه غیرقابل قبول</span>
                                                </div>
                                                <img alt="نمونه غیرقابل قبول" loading="lazy" width="1079" height="640"
                                                     decoding="async" data-nimg="1"
                                                     class="mt-20 max-h-[120px] sm:max-h-[140px] md:max-h-[160px] xl:max-h-[180px] block mx-auto w-auto cursor-pointer"
                                                     src="<?=get_template_directory_uri()?>/assets/img/unacceptable-example.png"
                                                     style="color: transparent;"></div>
                                        </div>
                                        <div class="bg-light pt-18 md:pt-22 px-20 md:px-24 pb-16 md:pb-20 rounded mt-16 md:mt-20 text-xs font-normal text-dark">
                                            <div class="font-bold mb-4">متنی که باید روی کاغذ نوشته شود:</div>
                                            <div>کد تایید گیفت مکس: <?=esc_html($verification_note_code)?></div>
                                            <div>تاریخ: <?=esc_html($verification_note_date)?></div>
                                            <div>نام، نام خانوادگی و امضا</div>
                                        </div>
                                        <div class="font-bold mb-4 md:mb-6 mt-16 md:mt-20 text-sm text-dark">نکات مهم:</div>
                                        <ul class="panel-text-list text-xs text-dark">
                                            <li>کد تایید حساب کاربری شما <strong><?=esc_html($verification_note_code)?></strong> است.</li>
                                            <li>احراز هویت در گیفت مکس فقط برای افراد <strong>بزرگتر از ۱۸ سال</strong>
                                                امکان پذیر است.
                                            </li>
                                            <li>مطمئن شوید که <strong>چهره شما</strong> و <strong>اطلاعات مدرک
                                                    شناسایی</strong> به خوبی دیده می&zwnj;شوند.
                                            </li>
                                            <li>پس از تایید مدارک، اطلاعات گیفت&zwnj;کارت های خریداری شده به صورت <strong>خودکار
                                                    و آنی</strong> ارسال میگردد.
                                            </li>
                                        </ul>
                                        <div class="flex flex-wrap items-start mt-16 sm:mt-20 md:mt-24">
                                            <button type="button" class="btn btn--gradient Button-uf78" data-verify-code="<?=esc_attr($verification_note_code)?>" data-verify-date="<?=esc_attr($verification_note_date)?>" style=" width: 35%">
                                                بارگذاری مجدد مدرک
                                            </button>
                                        </div>
                                    </div>
                                </div>
                                <?php
                            }
	                    }else{
	                        ?>
                            <div class="bg-primary bg-opacity-[0.12] border-y border-primary border-dashed border-opacity-50 px-24 md:px-28 xl:px-32 py-20 xl:py-24">
                                <h2 class="text-lg mb-8 md:mb-10 lg:mb-12">چرا باید احراز هویت را انجام بدهم؟</h2>
                                <ul class="panel-text-list text-sm text-dark">
                                    <li>اگر مسدود شده اید باید احراز هویت انجام بدهد تا دوباره دسترسی های شما باز بشه</li>
                                    <li>اگر میخواهید با کارت های ب جز کارت خود تراکنش انجام دهید و کیفت کارت خود را آنی دریافت کنید</li>
                                </ul>
                            </div>
                            <div>
                                <div>
                                    <div class="flex items-center">
                                        <div class="w-40 h-40 flex items-center justify-center rounded bg-green-dark bg-opacity-20">
                                            <i class="icon-check text-green-dark text-xs pt-2"></i>
                                        </div>
                                        <h2 class="pt-4 text-normal font-bold text-dark mr-12">تایید شماره موبایل</h2>
                                    </div>
                                </div>
                                <div class="mt-20 md:mt-24 lg:mt-28 pt-20 md:pt-24 lg:pt-28 border-t border-gray-300">
                                    <div class="flex items-center">
                                        <?php
                                        if ($landline_phone){
                                            ?>
                                            <div class="w-40 h-40 flex items-center justify-center rounded bg-green-dark bg-opacity-20">
                                                <i class="icon-check text-green-dark text-xs pt-2"></i>
                                            </div>
                                            <h2 class="pt-4 text-normal font-bold text-dark mr-12">تایید شماره تلفن ثابت</h2>
                                            <?php
                                        }else{?>
                                            <div class="w-40 h-40 flex items-center justify-center rounded bg-light">
                                                <span class="font-bold text-gray text-normal pt-4">2</span>
                                            </div>
                                            <h2 class="pt-4 text-normal font-bold text-dark mr-12">تایید شماره تلفن ثابت</h2>
                                            <?php
                                        }
                                        ?>

                                    </div>
                                    <?php
                                    if (!$landline_phone){
                                        ?>
                                        <div class="md:pr-52 mt-10 md:mt-12 verification-vb65">
                                            <label class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--L7bcQ uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame--normal--A6Ntt text-body-1 color-n-700 w-100"><p class="mb-2 color-n-700 text-body-1 mb-2" data-testid="form-label">شماره تلفن ثابت خود را وارد کنید </p><div class="uikit-collections-FormComponentFrame-FormComponentFrame-module__FormComponentFrame__input-container--D5edN px-2 d-flex ai-center"><section class="grow-1 text-body-2-c"><input class="px-2 TextField__input-_5fbdd text-subtitle w-100 TextField-e58168" type="text" name="value" placeholder="031123456789"></section></div></label>
                                            <div class="d-flex justify-end mt-3"> <button class="relative d-flex ai-center user-select-none btn-wc51H8 text-button-2 btn--primary-uiqWij radius Button__medium-gIvke_ Button__filledPrimary-OvgwGb ProfileBase__button-jvi4aR ProfileBase__button__modal-O3kjhU Button-con45" data-testid="button-wrapper" type="button" style="width: 25%"><div class="d-flex ai-center jc-center relative grow-1">تایید</div></button></div>

                                        </div>
                                        <?php
                                    }
                                    ?>
                                </div>
                                <?php
                                if ($landline_phone){
                                    ?>
                                    <div class="mt-20 md:mt-24 lg:mt-28 pt-20 md:pt-24 lg:pt-28 border-t border-gray-300">
                                        <div class="flex items-center">
                                            <div class="w-40 h-40 flex items-center justify-center rounded bg-light">
                                                <span class="font-bold text-gray text-normal pt-4">3</span>
                                            </div>
                                            <h2 class="pt-4 text-normal font-bold text-dark mr-12">احراز مدارک شناسایی</h2>
                                        </div>
                                        <div class="md:pr-52 mt-10 md:mt-12">
                                            <div class="text-sm text-dark leading-sm">با احراز مدارک شناسایی، <span
                                                        class="font-bolder">بدون محدودیت</span> از گیفت مکس استفاده کنید. همچنین
                                                پس از تایید مدارک، <span class="font-medium tracking-tight text-primary-dark">250 امتیاز</span>
                                                هدیه به حساب کاربری شما افزوده خواهد شد.
                                            </div>
                                            <div class="text-sm text-dark leading-sm mt-10 sm:mt-12">جهت تکمیل احراز هویت،
                                                <span>متن زیر را روی کاغذ نوشته</span> و <strong>مطابق نمونه</strong> همراه با
                                                <strong>یکی از مدارک شناسایی قابل قبول</strong> (کارت ملی، شناسنامه، گواهینامه،
                                                پاسپورت، کارت پایان خدمت) یک عکس <strong>واضح</strong> از خود گرفته و ارسال
                                                کنید.
                                            </div>
                                            <div class="flex pt-16 md:pt-20 -mx-4 sm:-mx-12">
                                                <div class="grow px-4 sm:px-12 sm:basis-0">
                                                    <div class="pb-8 flex items-center border-b-2 border-green"><i
                                                                class="w-24 h-24 rounded-circle hidden sm:flex items-center justify-center ml-8 shrink-0 text-green-dark bg-green bg-opacity-15 text-4xs pt-2 icon-check"></i><span
                                                                class="pt-4 leading-xs text-xs font-bold text-dark grow text-center sm:text-right whitespace-nowrap">نمونه قابل قبول</span>
                                                    </div>
                                                    <img alt="نمونه قابل قبول" loading="lazy" width="508" height="640"
                                                         decoding="async" data-nimg="1"
                                                         class="mt-20 max-h-[120px] sm:max-h-[140px] md:max-h-[160px] xl:max-h-[180px] block mx-auto w-auto cursor-pointer"
                                                         src="<?=get_template_directory_uri()?>/assets/img/acceptable-example.png"
                                                         style="color: transparent;"></div>
                                                <div class="grow px-4 sm:px-12 sm:basis-0">
                                                    <div class="pb-8 flex items-center border-b-2 border-red"><i
                                                                class="w-24 h-24 rounded-circle hidden sm:flex items-center justify-center ml-8 shrink-0 text-red-dark bg-red bg-opacity-15 text-[8px] pt-2 icon-close"></i><span
                                                                class="pt-4 leading-xs text-xs font-bold text-dark grow text-center sm:text-right whitespace-nowrap">نمونه غیرقابل قبول</span>
                                                    </div>
                                                    <img alt="نمونه غیرقابل قبول" loading="lazy" width="1079" height="640"
                                                         decoding="async" data-nimg="1"
                                                         class="mt-20 max-h-[120px] sm:max-h-[140px] md:max-h-[160px] xl:max-h-[180px] block mx-auto w-auto cursor-pointer"
                                                         src="<?=get_template_directory_uri()?>/assets/img/unacceptable-example.png"
                                                         style="color: transparent;"></div>
                                            </div>
                                            <div class="bg-light pt-18 md:pt-22 px-20 md:px-24 pb-16 md:pb-20 rounded mt-16 md:mt-20 text-xs font-normal text-dark">
                                                <div class="font-bold mb-4">متنی که باید روی کاغذ نوشته شود:</div>
                                                <div>کد تایید گیفت مکس: <?=esc_html($verification_note_code)?></div>
                                                <div>تاریخ: <?=esc_html($verification_note_date)?></div>
                                                <div>نام، نام خانوادگی و امضا</div>
                                            </div>
                                            <div class="font-bold mb-4 md:mb-6 mt-16 md:mt-20 text-sm text-dark">نکات مهم:</div>
                                            <ul class="panel-text-list text-xs text-dark">
                                                <li>کد تایید حساب کاربری شما <strong><?=esc_html($verification_note_code)?></strong> است.</li>
                                                <li>احراز هویت در گیفت مکس فقط برای افراد <strong>بزرگتر از ۱۸ سال</strong>
                                                    امکان پذیر است.
                                                </li>
                                                <li>مطمئن شوید که <strong>چهره شما</strong> و <strong>اطلاعات مدرک
                                                        شناسایی</strong> به خوبی دیده می&zwnj;شوند.
                                                </li>
                                                <li>پس از تایید مدارک، اطلاعات گیفت&zwnj;کارت های خریداری شده به صورت <strong>خودکار
                                                        و آنی</strong> ارسال میگردد.
                                                </li>
                                                <li class="before:hidden">
                                                    <div class="absolute h-8 w-8 child:rounded-circle child:bg-yellow top-8 right-0">
                                                        <div class="animate-ping absolute inset-x-0 inset-y-0 opacity-75"></div>
                                                        <div class="relative h-full w-full"></div>
                                                    </div>
                                                    <div class="text-dark">
                                                        شما تا
                                                        <strong id="timer_upload" data-timer="<?=$timer?>">  <?=$timer?> دقیقه</strong>
                                                        دیگر وقت دارید مدارک خود را ارسال کنید وگرنه باید  <strong>دوباره تلفن ثابت</strong> خود را احراز کنید
                                                    </div>
                                                </li>
                                            </ul>
                                            <div class="flex flex-wrap items-start mt-16 sm:mt-20 md:mt-24">
                                                <button type="button" class="btn btn--gradient Button-uf78" data-verify-code="<?=esc_attr($verification_note_code)?>" data-verify-date="<?=esc_attr($verification_note_date)?>" style=" width: 25%">
                                                    بارگذاری مدرک
                                                </button>
                                            </div>
                                        </div>
                                    </div>

                                    <?php
                                }else{?>
                                    <div class="mt-20 md:mt-24 lg:mt-28 pt-20 md:pt-24 lg:pt-28 border-t border-gray-300">
                                        <div class="flex items-center">
                                            <div class="w-40 h-40 flex items-center justify-center rounded bg-light">
                                                <span class="font-bold text-gray text-normal pt-4">3</span>
                                            </div>
                                            <h2 class="pt-4 text-normal font-bold text-dark mr-12">احراز مدارک شناسایی</h2>
                                        </div>
                                        <div class="md:pr-52 mt-10 md:mt-12" style=" cursor: none; pointer-events: none; filter: blur(4px); ">
                                            <div class="text-sm text-dark leading-sm">با احراز مدارک شناسایی، <span
                                                        class="font-bolder">بدون محدودیت</span> از گیفت مکس استفاده کنید. همچنین
                                                پس از تایید مدارک، <span class="font-medium tracking-tight text-primary-dark">250 امتیاز</span>
                                                هدیه به حساب کاربری شما افزوده خواهد شد.
                                            </div>
                                            <div class="text-sm text-dark leading-sm mt-10 sm:mt-12">جهت تکمیل احراز هویت،
                                                <span>متن زیر را روی کاغذ نوشته</span> و <strong>مطابق نمونه</strong> همراه با
                                                <strong>یکی از مدارک شناسایی قابل قبول</strong> (کارت ملی، شناسنامه، گواهینامه،
                                                پاسپورت، کارت پایان خدمت) یک عکس <strong>واضح</strong> از خود گرفته و ارسال
                                                کنید.
                                            </div>
                                            <div class="flex pt-16 md:pt-20 -mx-4 sm:-mx-12">
                                                <div class="grow px-4 sm:px-12 sm:basis-0">
                                                    <div class="pb-8 flex items-center border-b-2 border-green"><i
                                                                class="w-24 h-24 rounded-circle hidden sm:flex items-center justify-center ml-8 shrink-0 text-green-dark bg-green bg-opacity-15 text-4xs pt-2 icon-check"></i><span
                                                                class="pt-4 leading-xs text-xs font-bold text-dark grow text-center sm:text-right whitespace-nowrap">نمونه قابل قبول</span>
                                                    </div>
                                                    <img alt="نمونه قابل قبول" loading="lazy" width="508" height="640"
                                                         decoding="async" data-nimg="1"
                                                         class="mt-20 max-h-[120px] sm:max-h-[140px] md:max-h-[160px] xl:max-h-[180px] block mx-auto w-auto cursor-pointer"
                                                         src="<?=get_template_directory_uri()?>/assets/img/acceptable-example.png"
                                                         style="color: transparent;"></div>
                                                <div class="grow px-4 sm:px-12 sm:basis-0">
                                                    <div class="pb-8 flex items-center border-b-2 border-red"><i
                                                                class="w-24 h-24 rounded-circle hidden sm:flex items-center justify-center ml-8 shrink-0 text-red-dark bg-red bg-opacity-15 text-[8px] pt-2 icon-close"></i><span
                                                                class="pt-4 leading-xs text-xs font-bold text-dark grow text-center sm:text-right whitespace-nowrap">نمونه غیرقابل قبول</span>
                                                    </div>
                                                    <img alt="نمونه غیرقابل قبول" loading="lazy" width="1079" height="640"
                                                         decoding="async" data-nimg="1"
                                                         class="mt-20 max-h-[120px] sm:max-h-[140px] md:max-h-[160px] xl:max-h-[180px] block mx-auto w-auto cursor-pointer"
                                                         src="<?=get_template_directory_uri()?>/assets/img/unacceptable-example.png"
                                                         style="color: transparent;"></div>
                                            </div>
                                            <div class="bg-light pt-18 md:pt-22 px-20 md:px-24 pb-16 md:pb-20 rounded mt-16 md:mt-20 text-xs font-normal text-dark">
                                                <div class="font-bold mb-4">متنی که باید روی کاغذ نوشته شود:</div>
                                                <div>کد تایید گیفت مکس: </div>
                                                <div>تاریخ: </div>
                                                <div>نام، نام خانوادگی و امضا</div>
                                            </div>
                                            <div class="font-bold mb-4 md:mb-6 mt-16 md:mt-20 text-sm text-dark">نکات مهم:</div>
                                            <ul class="panel-text-list text-xs text-dark">
                                                <li>کد تایید حساب کاربری شما <strong></strong> است.</li>
                                                <li>احراز هویت در گیفت مکس فقط برای افراد <strong>بزرگتر از ۱۸ سال</strong>
                                                    امکان پذیر است.
                                                </li>
                                                <li>مطمئن شوید که <strong>چهره شما</strong> و <strong>اطلاعات مدرک
                                                        شناسایی</strong> به خوبی دیده می&zwnj;شوند.
                                                </li>
                                                <li>پس از تایید مدارک، اطلاعات گیفت&zwnj;کارت های خریداری شده به صورت <strong>خودکار
                                                        و آنی</strong> ارسال میگردد.
                                                </li>
                                            </ul>
                                        </div>
                                    </div>

                                    <?php
                                }
                                ?>
                            </div>
                        <?php
                    }
                    ?>
                </div>
            </div>
        </div>
    </section>
</main>
<?php
}