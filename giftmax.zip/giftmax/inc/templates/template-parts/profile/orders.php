<?php
if ( file_exists( __DIR__ . '/vendor/autoload.php' ) ) {
    require_once __DIR__ . '/vendor/autoload.php';
}
use Morilog\Jalali\Jalalian;
use Giftmax\Modules\UserModel;

function jalali_date($date)
{
    return Jalalian::fromDateTime($date)->format('%d %B %Y');
}

$current_user = wp_get_current_user();
$user_id = $current_user->ID;
$first_name = $current_user->first_name;
$recoords_Vip = UserModel::table("user_identity","user_id",$user_id);
if (is_array($recoords_Vip) && $recoords_Vip['account_type'] == 'vip'){
    $vip = 1;
}else{
    $vip = 0;
}
$db = \Giftmax\Modules\Db::getLnstance();
global $wpdb;
$National_card__img = $db->first("SELECT * FROM {$wpdb->prefix}documents WHERE user_id = :user_id AND doc_type = 'National_card__img' AND accepted=2 ",array('user_id' => $user_id));
$birth_certificate = $db->first("SELECT * FROM {$wpdb->prefix}documents WHERE user_id = :user_id AND doc_type = 'Birth_certificate' AND accepted=2 ",array('user_id' => $user_id));
$active_profile_tab = sanitize_key((string) get_query_var('profile_tab'));

?>
<main class="account-page">
    <section class="account-hero">
        <div class="container">
            <nav aria-label="مسیر دسترسی" class="breadcrumbs">
                <ol>
                    <li><a href="<?php echo site_url(); ?>">خانه</a></li>
                    <li aria-current="page">حساب کاربری</li>
                </ol>
            </nav>
        </div>
    </section>
    <section class="account-shell">
        <div class="container account-shell__layout">
            <aside class="account-sidebar" aria-label="منوی حساب کاربری">
                <div class="account-sidebar__card">
                    <div class="pb-28">
                        <div class="account-sidebar__header">
                            <div class="text-secondary font-bold tracking-tighter text-normal leading-xs grow"><?=$current_user->first_name . ' ' . $current_user->last_name?></div>
                            <?php
                            if (is_user_blocked()){
                                ?>
                                <div class="c-badge relative -top-2 text-2xs rounded-pill font-normal px-14">کاربر <span class="font-medium">مسدود </span></div>
                                <?php
                            }else{
                                ?>
                                <div class="c-badge relative -top-2 text-2xs rounded-pill font-normal px-14">کاربر <span class="font-medium"><?=$vip ?'ویژه': 'عادی'; ?></span></div>
                                <?php
                            }
                            ?>
                        </div>
                        <a class="alert alert-primary bg-primary bg-opacity-20 font-normal alert-sm flex items-start px-14 lg:px-16 mt-12" href="<?= esc_url( home_url( get_current_section_base() . '/wallet' ) ) ?>"><i class="icon-star pt-2 text-[#D19411] text-xs ml-8"></i><div class="grow">شما <strong class="font-bold"><?=number_format(UserModel::points())?> امتیاز</strong> دارید</div></a>
                    </div>
                    <?php
                    if (!empty($National_card__img) || !empty($birth_certificate)) {
                        $p = "100";
                    }elseif(is_array($recoords_Vip) && !$recoords_Vip['is_verified']){
                        $p = "30";
                    }else{
                        $p = "80";
                    }
                    if (!$vip){
                        ?>
                        <div class="account-progress">
                            <div class="account-progress__label">
                                <span>درصد تکمیل پروفایل</span>
                                <span><?=$p?>٪</span>
                            </div>
                            <div class="progress-bar">
                                <span style="width: <?=$p?>%"></span>
                            </div>
                            <?php
                            if($p != 100){
                                ?>
                                <button onclick="window.location.href='<?= esc_url( home_url( get_current_section_base() . '/verification' ) ) ?>'" type="button" class="btn btn--outline btn--block" data-panel-trigger="settings">تکمیل اطلاعات</button>
                                <?php
                            }
                            ?>
                        </div>
                        <?php
                    }
                    ?>
                    <a class="flex items-center py-16 leading-2 tracking-tight px-28 text-dark border-y border-gray border-opacity-[0.22] border-dashed relative before:absolute before:rounded-l before:transition-opacity before:w-4 before:bg-blue before:right-0 before:inset-y-16 before:opacity-0" href="<?= esc_url( home_url( get_current_section_base() . '/wallet' ) ) ?>"><div class="grow"><span class="font-medium text-xs block text-dark">موجودی کیف&zwnj;پول</span><div class="text-larger font-bold text-blue-dark tracking-tighter leading-1 pb-2 mt-3"><span class="text-gray"><?=number_format(UserModel::wallet()) != 0 ? number_format(UserModel::wallet()) : '-'?> تومان</span></div></div><div class="flex w-48 h-48 rounded-lg bg-blue-dark bg-opacity-10 items-center justify-center"><svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" class="w-22 h-22 fill-blue-dark"><path opacity="0.4" d="M18.04 13.55C17.62 13.96 17.38 14.55 17.44 15.18C17.53 16.26 18.52 17.05 19.6 17.05H21.5V18.24C21.5 20.31 19.81 22 17.74 22H6.26C4.19 22 2.5 20.31 2.5 18.24V11.51C2.5 9.44001 4.19 7.75 6.26 7.75H17.74C19.81 7.75 21.5 9.44001 21.5 11.51V12.95H19.48C18.92 12.95 18.41 13.17 18.04 13.55Z"></path><path d="M14.85 3.95V7.74999H6.26C4.19 7.74999 2.5 9.44 2.5 11.51V7.84002C2.5 6.65002 3.23 5.58997 4.34 5.16997L12.28 2.16997C13.52 1.70997 14.85 2.62 14.85 3.95Z"></path><path d="M22.56 13.9699V16.03C22.56 16.58 22.12 17.0299 21.56 17.0499H19.6C18.52 17.0499 17.53 16.2599 17.44 15.1799C17.38 14.5499 17.62 13.9599 18.04 13.5499C18.41 13.1699 18.92 12.95 19.48 12.95H21.56C22.12 12.97 22.56 13.4199 22.56 13.9699Z"></path><path d="M14 12.75H7C6.59 12.75 6.25 12.41 6.25 12C6.25 11.59 6.59 11.25 7 11.25H14C14.41 11.25 14.75 11.59 14.75 12C14.75 12.41 14.41 12.75 14 12.75Z"></path></svg></div></a>
                </div>

                <nav class="account-nav" role="tablist">

                    <a href="<?= esc_url( home_url( get_current_section_base() ) ) ?>"
                       class="account-nav__item <?= $active_profile_tab === '' ? 'active' : '' ?>"
                       role="tab">
                        <span class="icon icon-menu2"></span>
                        داشبورد
                    </a>

                    <a href="<?= esc_url( home_url( get_current_section_base() . '/orders' ) ) ?>"
                       class="account-nav__item <?= $active_profile_tab === 'orders' ? 'active' : '' ?>"
                       role="tab">
                        <span class="icon icon-order"></span>
                        سفارش‌های من
                    </a>
                    <a href="<?= esc_url( home_url( get_current_section_base() . '/list' ) ) ?>"
                       class="account-nav__item list-interest <?= $active_profile_tab === 'list' ? 'active' : '' ?>" role="tab">
                        <svg viewBox="0 0 24 24">
                            <path d="M12.62 20.81C12.28 20.93 11.72 20.93 11.38 20.81C8.48 19.82 2 15.69 2 8.68998C2 5.59998 4.49 3.09998 7.56 3.09998C9.38 3.09998 10.99 3.97998 12 5.33998C13.01 3.97998 14.63 3.09998 16.44 3.09998C19.51 3.09998 22 5.59998 22 8.68998C22 15.69 15.52 19.82 12.62 20.81Z" fill="none" stroke="inherit" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                        </svg>
                        لیست علاقه مندی
                    </a>
                    <a href="<?= esc_url( home_url( get_current_section_base() . '/deliveries' ) ) ?>"
                       class="account-nav__item <?= $active_profile_tab === 'deliveries' ? 'active' : '' ?>"
                       role="tab">
                        <span class="icon icon-flash"></span>
                        کدهای تحویل‌شده
                    </a>
                    <a href="<?= esc_url( home_url( get_current_section_base() . '/post' ) ) ?>"
                       class="account-nav__item <?= $active_profile_tab === 'post' ? 'active' : '' ?>"
                       role="tab">
                        <span class="icon icon-document"></span>
                        ارسال مقاله
                    </a>
                    <a href="<?= esc_url( home_url( get_current_section_base() . '/wallet' ) ) ?>"
                       class="account-nav__item <?= $active_profile_tab === 'wallet' ? 'active' : '' ?>"
                       role="tab">
                        <span class="icon icon-wallet"></span>
                        کیف پول و امتیاز
                    </a>
                    <?php
                    if (!$vip){
                        ?>
                        <a href="<?= esc_url( home_url( get_current_section_base() . '/verification' ) ) ?>"
                           class="account-nav__item <?= $active_profile_tab === 'verification' ? 'active' : '' ?>"
                           role="tab">
                            <span class="icon icon-verify"></span>
                            احراز هویت
                        </a>
                        <?php
                    }
                    ?>
                    <a href="<?= esc_url( home_url( get_current_section_base() . '/coupons' ) ) ?>"
                       class="account-nav__item <?= $active_profile_tab === 'coupons' ? 'active' : '' ?>"
                       role="tab">
                        <span class="icon icon-gift"></span>
                        کد های تخفیف
                    </a>
                    <a href="<?= esc_url( home_url( get_current_section_base() . '/cards' ) ) ?>"
                       class="account-nav__item <?= $active_profile_tab === 'cards' ? 'active' : '' ?>"
                       role="tab">
                        <span class="icon icon-card"></span>
                        کارت های بانکی
                    </a>
                    <a href="<?= esc_url( home_url( get_current_section_base() . '/user' ) ) ?>"
                       class="account-nav__item <?= $active_profile_tab === 'user' ? 'active' : '' ?>"
                       role="tab">
                        <span class="icon icon-user-o"></span>
                        تنظیمات حساب کاربری
                    </a>
                </nav>
            </aside>

            <div class="account-content">
                <div
                        class="account-panel active"
                        id="panel-orders"
                        data-panel="orders"
                        role="tabpanel"
                        aria-hidden="true"
                        tabindex="0"
                        hidden
                >
                    <div class="account-panel__div">
                        <div>
                            <h2>سفارش‌های من</h2>
                            <p>تمام خریدهای شما به تفکیک وضعیت، کد و تاریخ تحویل.</p>
                        </div>
                    </div>
                    <?php
                    $current_status = isset($_GET['status']) ? sanitize_text_field($_GET['status']) : 'all';
                    $paged =  1;
                    $per_page = 10;
                    $args = [
                            'customer_id' => $user_id,
                            'limit'       => $per_page,
                            'page'        => $paged,
                            'orderby'     => 'date',
                            'order'       => 'DESC',
                    ];
                    if ($current_status !== 'all') {
                        $args['status'] = $current_status;
                    }
                    ?>
                    <div class="filter-chips" role="toolbar" aria-label="فیلتر سفارش‌ها">
                        <?php
                        $statuses = [
                                'all' => 'همه سفارش‌ها',
                                'pending' => 'در انتظار پرداخت',
                                'card-not-verified' => 'مغایرت کارت بانکی',
                                'completed' => 'تحویل شده',
                                'cancelled' => 'لغو شده',
                        ];
                        foreach ($statuses as $key => $label) :
                            $active_class = $current_status === $key ? 'active' : '';
                            ?>
                            <a href="?status=<?php echo $key; ?>" class="chip <?php echo $active_class; ?>">
                                <?php echo $label; ?>
                            </a>
                        <?php endforeach; ?>
                    </div>
                    <?php
                    $orders = wc_get_orders($args);
                    if ($orders){
                        ?>
                        <div class="data-card">
                            <table class="table-list panel-table-list">
                                <thead><tr>
                                    <th>تاریخ سفارش</th>
                                    <th>مبلغ سفارش</th>
                                    <th>وضعیت سفارش</th>
                                    <th>وضعیت فروش</th>
                                    <th>وضعیت تحویل</th>
                                    <th></th>
                                </tr></thead>
                                <tbody>
                                <?php foreach ($orders as $dashboard_order):
                                    $dashboard_order_date = $dashboard_order->get_date_created();
                                    $dashboard_order_date = $dashboard_order_date ? $dashboard_order_date->date_i18n('Y/m/d') : '-';
                                    $suspiciousOrder = $dashboard_order->get_meta('_suspicious_order');
                                    $suspiciousOrder = !$vip && $suspiciousOrder == 1;
                                    if (!isMobile()){
                                        if ($dashboard_order->get_status() != 'card-not-verified'){
                                            $urlOrders = esc_url(home_url(get_current_section_base() . '/invoices/' . $dashboard_order->get_id()));
                                        }else{
                                            $urlOrders = esc_url(home_url(get_current_section_base() . '/orders'));
                                        }
                                        ?>
                                        <tr class="cursor-pointer">
                                            <td data-content="تاریخ سفارش">
                                                <div class="table-td-inner"><?=gjdate($dashboard_order_date,"d M Y")?></div>
                                            </td>
                                            <td data-content="تاریخ سفارش">
                                                <div class="table-td-inner"><?php
                                                    $gateway = $dashboard_order->get_payment_method();
                                                    if ( $gateway === 'payment4' ) {
                                                        $currency = 'USD';
                                                    } else {
                                                        $currency = 'IRR';
                                                    }
                                                    $amount = $dashboard_order->get_total();
                                                    echo gm_wc_price( $amount, array( 'currency' => $currency ) );
                                                    ?>
                                                </div>
                                            </td>
                                            <td data-content="وضعیت سفارش" class="py-7">
                                                <div class="table-td-inner">
                                                    <?php
                                                    if ($dashboard_order->get_status() == 'card-not-verified'){?>
                                                        <div class="flex gap-2">
                                                            <span class="badge status-pill--completed text-3xs">تکمیل شده</span>
                                                            <span class="badge status-pill--card-not-verified text-3xs">مغایرت کارت بانکی</span>
                                                        </div>
                                                        <span class="badge status-pill--pending text-3xs" style="margin-top: 3px;">تایید مالکیت کارت</span>
                                                        <?php
                                                    }elseif($suspiciousOrder == 1){?>
                                                        <div class="flex gap-2">
                                                            <span class="badge status-pill--completed text-3xs">تکمیل شده</span>
                                                            <span class="badge status-pill--pending text-3xs" style="margin-top: 3px;">سفارش مشکوک به فیشینگ</span>
                                                        </div>
                                                    <?php }
                                                    else{?>
                                                        <span class="badge status-pill--<?=$dashboard_order->get_status()?> text-3xs"><?= esc_html(wc_get_order_status_name($dashboard_order->get_status())) ?></span>
                                                        <?php
                                                    }
                                                    ?>
                                                </div>
                                            </td>
                                            <td data-content="وضعیت فروش">
                                                <?php
                                                $is_preorder = $dashboard_order->get_meta('_has_preorder_items');
                                                if(!$is_preorder) {?>
                                                    <div class="badge badge-primary text-3xs">تحویل آنی</div>
                                                    <?php
                                                }else{
                                                    $presale = get_max_presale_item_by_order_id($dashboard_order->get_id());
                                                    if ($presale['t'] && $presale['license_status'] != 2){?>
                                                        <div class="table-td-inner">
                                                            <span class="text-neutral-500 text-caption line-height-1">تحویل با تاخیر</span>
                                                            <div class="text-primary-700 text-body2-strong style_ProductPromotionTimeline__timer__zS6ZA1 line-height-1 mt-1"><?=$presale['ctt']?></div>
                                                        </div>
                                                        <?php
                                                    }else{
                                                        ?>
                                                        <div class="badge badge-info text-3xs">تحویل با تاخیر</div>
                                                        <?php
                                                    }
                                                }
                                                ?>
                                            </td>
                                            <td data-content="وضعیت تحویل">
                                                <?php
                                                if ($dashboard_order->get_status() == 'completed'){
                                                    if ($suspiciousOrder == 1){?>
                                                        <span class="badge status-pill--failed text-3xs">عدم تحویل</span>
                                                        <span class="badge status-pill--failed text-3xs">نیاز به تایید هویت</span>
                                                    <?php }
                                                    elseif ($is_preorder){
                                                        if ($presale['license_status'] == 0){
                                                            echo '<span class="badge status-pill--pending text-3xs">درحال تامین کالا</span>';
                                                        }elseif ($presale['license_status'] == 1){
                                                            echo '<span class="badge status-pill--checkout-draft text-3xs">در حال تحویل</span>';
                                                        }elseif ($presale['license_status'] == 2){
                                                            echo '<span class="badge status-pill--completed text-3xs">تحویل داده شد</span>';
                                                        }
                                                    }else{
                                                        ?>
                                                        <span class="badge status-pill--completed text-3xs">تحویل داده شد</span>
                                                        <?php
                                                    }
                                                }else if ($dashboard_order->get_status() == 'card-not-verified'){
                                                    ?>
                                                    <div class="flex justify-end">
                                                        <span class="badge status-pill--failed text-3xs">عدم تحویل</span>
                                                        <?php
                                                        $cardPay = $dashboard_order->get_meta( '_card_pay', true );
                                                        $isCheck = $dashboard_order->get_meta( '_is_card_pay', true );
                                                        $card = UserModel::table('user_bank_cards', 'card_number_enc', encrypt_data($cardPay),"user_id",$user_id);
                                                        if (!empty($card)) {
                                                            ?>
                                                            <span class="badge status-pill--completed text-3xs">تایید کارت</span>
                                                            <?php
                                                        }else{
                                                            ?>
                                                            <span class="badge status-pill--failed text-3xs">تایید کارت</span>
                                                            <?php
                                                        }
                                                        ?>
                                                        <span class="badge status-pill--failed text-3xs check-phone">تایید تلفن</span>
                                                    </div>
                                                    <?php
                                                }else if ($dashboard_order->get_status() != 'card-not-verified' && $dashboard_order->get_status() != 'completed'){
                                                    ?>
                                                    <span class="badge status-pill--failed text-3xs">عدم تحویل</span>
                                                    <?php
                                                }
                                                ?>
                                            </td>
                                            <td class="table-list-actions">
                                                <div class="table-td-inner flex justify-end pb-2 space-x-8 space-x-reverse align-items-center">
                                                    <?php
                                                    if ($dashboard_order->get_status() != 'card-not-verified'){
                                                        if ($suspiciousOrder == 1){?>
                                                            <a class="btn btn-2xs btn-white text-dark btn-view" href="<?= (home_url(get_current_section_base() . '/verification/')) ?>">احرازهویت</a>
                                                            <?php
                                                        }else{
                                                            ?>
                                                            <a class="btn btn-2xs btn-white text-dark btn-view" href="<?= esc_url(home_url(get_current_section_base() . '/invoices/' . $dashboard_order->get_id())) ?>">مشاهده</a>
                                                            <?php
                                                        }
                                                    }else{
                                                        if ($isCheck){?>
                                                        <svg class="Button-od94" data-number="<?=$cardPay?>" data-id="<?=encrypt_id($dashboard_order->get_id())?>" viewBox="0 0 24 24"><path fill-rule="evenodd" d="M2 12c0 5.523 4.477 10 10 10s10-4.477 10-10S17.523 2 12 2 2 6.477 2 12zm18 0a8 8 0 11-16 0 8 8 0 0116 0zm-10-2h3v7h-2v-5h-1v-2zm3-2a1 1 0 10-2 0 1 1 0 002 0z" clip-rule="evenodd"></path></svg>
                                                        <button class="btn btn-2xs btn-white text-dark btn-view Button-vcs788" data-id="<?=encrypt_id($dashboard_order->get_id())?>">تایید کارت</button>
                                                    <?php }else{?>
                                                            <svg class="Button-od94" data-number="<?=$cardPay?>" data-check="1" data-id="<?=encrypt_id($dashboard_order->get_id())?>" viewBox="0 0 24 24"><path fill-rule="evenodd" d="M2 12c0 5.523 4.477 10 10 10s10-4.477 10-10S17.523 2 12 2 2 6.477 2 12zm18 0a8 8 0 11-16 0 8 8 0 0116 0zm-10-2h3v7h-2v-5h-1v-2zm3-2a1 1 0 10-2 0 1 1 0 002 0z" clip-rule="evenodd"></path></svg>
                                                            <button class="btn btn-2xs btn-white text-dark btn-view Button-sc45" data-number="<?=$cardPay?>" data-id="<?=encrypt_id($dashboard_order->get_id())?>">تایید کارت</button>
                                                            <?php
                                                        }
                                                    }
                                                    ?>
                                                </div>
                                            </td>
                                        </tr>
                                        <?php
                                    }else{?>
                                        <tr class="cursor-pointer">
                                            <td data-content="شماره فاکتور">
                                                <div class="table-td-inner text-sm tracking-tight font-medium text-dark ellipsis">#<?= esc_html($dashboard_order->get_order_number()) ?></div>
                                            </td>
                                            <td data-content="تاریخ سفارش">
                                                <div class="table-td-inner"><?=gjdate($dashboard_order_date,"d M Y")?></div>
                                            </td>
                                            <td data-content="مبلغ سفارش">
                                                <div class="table-td-inner"><?php
                                                    $gateway = $dashboard_order->get_payment_method();
                                                    if ( $gateway === 'payment4' ) {
                                                        $currency = 'USD';
                                                    } else {
                                                        $currency = 'IRR';
                                                    }
                                                    $amount = $dashboard_order->get_total();
                                                    echo wc_price( $amount, array( 'currency' => $currency ) );
                                                    ?>
                                                </div>
                                            </td>
                                            <td data-content="وضعیت سفارش">
                                                <div class="table-td-inner">
                                                    <span class="badge status-pill--<?=$dashboard_order->get_status()?> text-3xs"><?= esc_html(wc_get_order_status_name($dashboard_order->get_status())) ?></span>
                                                </div>
                                            </td>
                                            <td data-content="وضعیت سفارش">
                                                <div class="table-td-inner">
                                                    <?php
                                                    if ($dashboard_order->get_status() == 'card-not-verified'){?>
                                                        <div class="flex gap-2">
                                                            <span class="badge status-pill--completed text-3xs">تکمیل شده</span>
                                                            <span class="badge status-pill--card-not-verified text-3xs">مغایرت کارت بانکی</span>
                                                        </div>
                                                        <span class="badge status-pill--pending text-3xs" style="margin-top: 3px;">تایید مالکیت کارت</span>
                                                        <?php
                                                    }elseif($suspiciousOrder == 1){?>
                                                        <div class="flex gap-2">
                                                            <span class="badge status-pill--completed text-3xs">تکمیل شده</span>
                                                            <span class="badge status-pill--pending text-3xs" style="margin-top: 3px;">سفارش مشکوک به فیشینگ</span>
                                                        </div>
                                                    <?php }else{?>
                                                        <span class="badge status-pill--<?=$dashboard_order->get_status()?> text-3xs"><?= esc_html(wc_get_order_status_name($dashboard_order->get_status())) ?></span>
                                                        <?php
                                                    }
                                                    ?>
                                                </div>
                                            </td>
                                            <td data-content="وضعیت تحویل">
                                                <div class="table-td-inner">
                                                    <?php
                                                    if ($dashboard_order->get_status() == 'completed'){
                                                        if ($suspiciousOrder == 1){?>
                                                            <span class="badge status-pill--failed text-3xs">عدم تحویل</span>
                                                            <span class="badge status-pill--failed text-3xs">نیاز به تایید هویت</span>
                                                        <?php }
                                                        elseif($is_preorder){
                                                            if ($presale['license_status'] == 0){
                                                                echo '<span class="badge status-pill--pending text-3xs">درحال تامین کالا</span>';
                                                            }elseif ($presale['license_status'] == 1){
                                                                echo '<span class="badge status-pill--checkout-draft text-3xs">در حال تحویل</span>';
                                                            }elseif ($presale['license_status'] == 2){
                                                                echo '<span class="badge status-pill--completed text-3xs">تحویل داده شد</span>';
                                                            }
                                                        }else{
                                                            ?>
                                                            <span class="badge status-pill--completed text-3xs">تحویل داده شد</span>
                                                            <?php
                                                        }
                                                    }else if ($dashboard_order->get_status() == 'card-not-verified'){
                                                        ?>
                                                        <div class="flex justify-between">
                                                            <span class="badge status-pill--failed text-3xs">عدم تحویل</span>
                                                            <?php
                                                            $cardPay = $dashboard_order->get_meta( '_card_pay', true );
                                                            $isCheck = $dashboard_order->get_meta( '_is_card_pay', true );
                                                            $card = UserModel::table('user_bank_cards', 'card_number_enc', encrypt_data($cardPay),"user_id",$user_id);
                                                            if (!empty($card)) {
                                                                ?>
                                                                <span class="badge status-pill--completed text-3xs">تایید کارت</span>
                                                                <?php
                                                            }else{
                                                                ?>
                                                                <span class="badge status-pill--failed text-3xs">تایید کارت</span>
                                                                <?php
                                                            }
                                                            ?>
                                                            <span class="badge status-pill--failed text-3xs check-phone">تایید تلفن</span>
                                                        </div>
                                                        <?php
                                                    }else if ($dashboard_order->get_status() != 'card-not-verified' && $dashboard_order->get_status() != 'completed'){
                                                        ?>
                                                        <span class="badge status-pill--failed text-3xs">عدم تحویل</span>
                                                        <?php
                                                    }
                                                    ?>
                                                </div>
                                            </td>
                                            <td class="table-list-actions">
                                                <div class="table-td-inner flex justify-end pb-2 space-x-8 space-x-reverse align-items-center">
                                                    <?php
                                                    if ($dashboard_order->get_status() != 'card-not-verified'){
                                                        if ($suspiciousOrder == 1){?>
                                                            <a class="btn btn-2xs btn-white text-dark btn-view" href="<?= (home_url(get_current_section_base() . '/verification/')) ?>">احرازهویت</a>
                                                            <?php
                                                        }else{
                                                            ?>
                                                            <a class="btn btn-2xs btn-white text-dark btn-view" href="<?= esc_url(home_url(get_current_section_base() . '/invoices/' . $dashboard_order->get_id())) ?>">مشاهده</a>
                                                            <?php
                                                        }
                                                    }else{
                                                        if ($isCheck){?>
                                                            <svg class="Button-od94" data-number="<?=$cardPay?>" data-id="<?=encrypt_id($dashboard_order->get_id())?>" viewBox="0 0 24 24"><path fill-rule="evenodd" d="M2 12c0 5.523 4.477 10 10 10s10-4.477 10-10S17.523 2 12 2 2 6.477 2 12zm18 0a8 8 0 11-16 0 8 8 0 0116 0zm-10-2h3v7h-2v-5h-1v-2zm3-2a1 1 0 10-2 0 1 1 0 002 0z" clip-rule="evenodd"></path></svg>
                                                            <button class="btn btn-2xs btn-white text-dark btn-view Button-vcs788" data-id="<?=encrypt_id($dashboard_order->get_id())?>">تایید کارت</button>
                                                        <?php }else{?>
                                                            <svg class="Button-od94" data-number="<?=$cardPay?>" data-check="1" data-id="<?=encrypt_id($dashboard_order->get_id())?>" viewBox="0 0 24 24"><path fill-rule="evenodd" d="M2 12c0 5.523 4.477 10 10 10s10-4.477 10-10S17.523 2 12 2 2 6.477 2 12zm18 0a8 8 0 11-16 0 8 8 0 0116 0zm-10-2h3v7h-2v-5h-1v-2zm3-2a1 1 0 10-2 0 1 1 0 002 0z" clip-rule="evenodd"></path></svg>
                                                            <button class="btn btn-2xs btn-white text-dark btn-view Button-sc45" data-number="<?=$cardPay?>" data-id="<?=encrypt_id($dashboard_order->get_id())?>">تایید کارت</button>
                                                            <?php
                                                        }}
                                                    ?>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php }
                                    ?>
                                <?php endforeach;
                                ?>
                                </tbody>
                            </table>
                        </div>
                        <?php
                        $total_orders = wc_get_orders([
                                'customer_id' => $user_id,
                                'limit'       => -1,
                        ]);

                        $total_pages = ceil(count($total_orders) / $per_page);
                        $window = 1;

                        $start = $paged - $window;
                        $end   = $paged + $window;

                        if ($start < 1) {
                            $end += (1 - $start);
                            $start = 1;
                        }

                        if ($end > $total_pages) {
                            $start -= ($end - $total_pages);
                            $end = $total_pages;
                        }

                        if ($start < 1) {
                            $start = 1;
                        }
                        echo '<div class="flex justify-end"><div class="v10__Pagination">';
                        for ($i = $start; $i <= $end; $i++) {
                            if ($i < 1){
                                continue;
                            }
                            if ($paged == $i){
                                echo '<button class="v10__Pagination-item Button-np54 active">' . $i . '</button>';
                            }else {
                                echo '<button class="v10__Pagination-item Button-np54" data-page="' . $i . '">' . $i . '</button>';
                            }
                        }
                        echo '</div></div> ';
                    } else{?>
                        <section class="p-5 TableCard--bodyMobile-tDS3OZ">
                            <div class="d-flex ai-center jc-center align-center w-100 h-100">
                                <div class="py-4 d-flex flex-column jc-center ai-center EmptyState__desktopContainer-ggZkIg">
                                    <div class="d-flex jc-center mb-3" data-testid="empty-src">
                                        <div data-testid="image-wrapper" style="width: 200px; height: 150px;">
                                            <img class="w-100" src="<?=get_template_directory_uri()?>/assets/img/ticket_img.png" width="200" height="150" data-testid="image-defaultImage" style="object-fit: contain;">
                                        </div>
                                    </div>
                                    <div class="text-h5 color-900">نتیجه&zwnj;ای پیدا نکردیم...</div>
                                    <div class="text-caption-strong color-500" data-testid="empty-description">
                                        <div>فیلتر ها رو تغییر دهید و سپس دوباره امتحان کنید.</div>
                                    </div>
                                </div>
                            </div>
                        </section>
                    <?php }?>
                </div>
            </div>
        </div>
    </section>
</main>
