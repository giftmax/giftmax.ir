<?php
use Giftmax\Modules\UserModel;

$profile_templates = [
    'orders' => 'orders',
    'deliveries' => 'deliveries',
    'wallet' => 'wallet',
    'verification' => 'verification',
    'invoices' => 'invoices',
    'coupons' => 'coupons',
    'cards' => 'cards',
];

$profile_tab = sanitize_key((string) get_query_var('profile_tab'));
$active_profile_tab = isset($profile_templates[$profile_tab]) ? $profile_tab : '';
$active_profile_template = $active_profile_tab !== '' ? __DIR__ . '/' . $profile_templates[$active_profile_tab] . '.php' : '';

$current_user = wp_get_current_user();
$user_id = $current_user->ID;
$first_name = $current_user->first_name;

$recoords_Vip = UserModel::table("user_identity","user_id",$user_id);
if (is_array($recoords_Vip) && $recoords_Vip['account_type'] == 'vip'){
    $vip = 1;
}else{
    $vip = 0;
}
$db = \Giftmax\Modules\Db::getLnstance();
global $wpdb;
$National_card__img = $db->first("SELECT * FROM {$wpdb->prefix}documents WHERE user_id = :user_id AND doc_type = 'National_card__img' AND accepted=2 ",array('user_id' => $user_id));
$birth_certificate = $db->first("SELECT * FROM {$wpdb->prefix}documents WHERE user_id = :user_id AND doc_type = 'Birth_certificate' AND accepted=2 ",array('user_id' => $user_id));

?>
<style>
    @media (min-width: 48rem) {
        .user-dashboard-last-orders, .user-dashboard-last-tickets,.user-dashboard-last-notification,.user-dashboard-cart {
            box-shadow: 0px 0 0 1px #a2a2a233 !important;
        }
        .md\:w-46{
            width: 46% !important;
        }
        .f2t5g{
            width: 52%;
            margin-left: 0;
        }
        .account-panel__section{
            background-color: #FFF !important;
            padding: 0 !important;
        }
        .account-panel__section .header{
            background: rgba(244, 247, 255, .8);
            padding: 0.8rem;
            border-radius: 14px;
            display: flex;
        }
        .account-panel__section .header .bg-white.rounded-sm{
            width: 14%;
            margin-left: 10px;
            padding: 10px;
            display: flex;
            flex-direction: column;
            justify-content: center;
        }
        .account-panel__section .header .user-dashboard-statistics{
            width: 85%;
            display: grid;
            grid-template-columns: repeat(4, minmax(0, 1fr)) !important;
        }
        .account-panel__section .header .user-dashboard-statistics-item-handler{
            width: auto;
        }
        .account-panel__section .header .user-dashboard-statistics-item {
            padding: 17px;
        }
    }
</style>
<main class="account-page">
    <section class="account-hero">
        <div class="container">
            <nav aria-label="مسیر دسترسی" class="breadcrumbs">
                <ol>
                    <li><a href="<?php echo site_url(); ?>">خانه</a></li>
                    <li aria-current="page">حساب کاربری</li>
                </ol>
            </nav>
        </div>
    </section>
    <section class="account-shell">
        <div class="container account-shell__layout">
            <aside class="account-sidebar" aria-label="منوی حساب کاربری">
                <div class="account-sidebar__card">
                    <div class="pb-28">
                        <div class="account-sidebar__header">
                            <div class="text-secondary font-bold tracking-tighter text-normal leading-xs grow"><?=$current_user->first_name . ' ' . $current_user->last_name?></div>
                            <?php
                            if (is_user_blocked()){
                                ?>
                                <div class="c-badge relative -top-2 text-2xs rounded-pill font-normal px-14">کاربر <span class="font-medium">مسدود </span></div>
                                <?php
                            }else{
                                ?>
                                <div class="c-badge relative -top-2 text-2xs rounded-pill font-normal px-14">کاربر <span class="font-medium"><?=$vip ?'ویژه': 'عادی'; ?></span></div>
                                <?php
                            }
                            ?>
                        </div>
                        <a class="alert alert-primary bg-primary bg-opacity-20 font-normal alert-sm flex items-start px-14 lg:px-16 mt-12" href="<?= esc_url( home_url( get_current_section_base() . '/wallet' ) ) ?>"><i class="icon-star pt-2 text-[#D19411] text-xs ml-8"></i><div class="grow">شما <strong class="font-bold"><?=number_format(UserModel::points())?> امتیاز</strong> دارید</div></a>
                    </div>
                        <?php
                        if (!empty($National_card__img) || !empty($birth_certificate)) {
                            $p = "100";
                        }elseif(is_array($recoords_Vip) && !$recoords_Vip['is_verified']){
                            $p = "30";
                        }else{
                            $p = "80";
                        }
                    if (!$vip){
                        ?>
                        <div class="account-progress">
                            <div class="account-progress__label">
                                <span>درصد تکمیل پروفایل</span>
                                <span><?=$p?>٪</span>
                            </div>
                            <div class="progress-bar">
                                <span style="width: <?=$p?>%"></span>
                            </div>
                            <?php
                            if($p != 100){
                                ?>
                                <button onclick="window.location.href='<?= esc_url( home_url( get_current_section_base() . '/verification' ) ) ?>'" type="button" class="btn btn--outline btn--block" data-panel-trigger="settings">تکمیل اطلاعات</button>
                                <?php
                            }
                            ?>
                        </div>
                        <?php
                    }
                    ?>
                    <a class="flex items-center py-16 leading-2 tracking-tight px-28 text-dark border-y border-gray border-opacity-[0.22] border-dashed relative before:absolute before:rounded-l before:transition-opacity before:w-4 before:bg-blue before:right-0 before:inset-y-16 before:opacity-0" href="<?= esc_url( home_url( get_current_section_base() . '/wallet' ) ) ?>"><div class="grow"><span class="font-medium text-xs block text-dark">موجودی کیف&zwnj;پول</span><div class="text-larger font-bold text-blue-dark tracking-tighter leading-1 pb-2 mt-3"><span class="text-gray"><?=number_format(UserModel::wallet()) != 0 ? number_format(UserModel::wallet()) : '-'?> تومان</span></div></div><div class="flex w-48 h-48 rounded-lg bg-blue-dark bg-opacity-10 items-center justify-center"><svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" class="w-22 h-22 fill-blue-dark"><path opacity="0.4" d="M18.04 13.55C17.62 13.96 17.38 14.55 17.44 15.18C17.53 16.26 18.52 17.05 19.6 17.05H21.5V18.24C21.5 20.31 19.81 22 17.74 22H6.26C4.19 22 2.5 20.31 2.5 18.24V11.51C2.5 9.44001 4.19 7.75 6.26 7.75H17.74C19.81 7.75 21.5 9.44001 21.5 11.51V12.95H19.48C18.92 12.95 18.41 13.17 18.04 13.55Z"></path><path d="M14.85 3.95V7.74999H6.26C4.19 7.74999 2.5 9.44 2.5 11.51V7.84002C2.5 6.65002 3.23 5.58997 4.34 5.16997L12.28 2.16997C13.52 1.70997 14.85 2.62 14.85 3.95Z"></path><path d="M22.56 13.9699V16.03C22.56 16.58 22.12 17.0299 21.56 17.0499H19.6C18.52 17.0499 17.53 16.2599 17.44 15.1799C17.38 14.5499 17.62 13.9599 18.04 13.5499C18.41 13.1699 18.92 12.95 19.48 12.95H21.56C22.12 12.97 22.56 13.4199 22.56 13.9699Z"></path><path d="M14 12.75H7C6.59 12.75 6.25 12.41 6.25 12C6.25 11.59 6.59 11.25 7 11.25H14C14.41 11.25 14.75 11.59 14.75 12C14.75 12.41 14.41 12.75 14 12.75Z"></path></svg></div></a>
                </div>

                <nav class="account-nav" role="tablist">

                    <a href="<?= esc_url( home_url( get_current_section_base() ) ) ?>"
                       class="account-nav__item <?= $active_profile_tab === '' ? 'active' : '' ?>"
                       role="tab">
                        <span class="icon icon-menu2"></span>
                        داشبورد
                    </a>

                    <a href="<?= esc_url( home_url( get_current_section_base() . '/orders' ) ) ?>"
                       class="account-nav__item <?= $active_profile_tab === 'orders' ? 'active' : '' ?>"
                       role="tab">
                        <span class="icon icon-order"></span>
                        سفارش‌های من
                    </a>
                    <a href="<?= esc_url( home_url( get_current_section_base() . '/list' ) ) ?>"
                       class="account-nav__item list-interest <?= $active_profile_tab === 'list' ? 'active' : '' ?>" role="tab">
                        <svg viewBox="0 0 24 24">
                            <path d="M12.62 20.81C12.28 20.93 11.72 20.93 11.38 20.81C8.48 19.82 2 15.69 2 8.68998C2 5.59998 4.49 3.09998 7.56 3.09998C9.38 3.09998 10.99 3.97998 12 5.33998C13.01 3.97998 14.63 3.09998 16.44 3.09998C19.51 3.09998 22 5.59998 22 8.68998C22 15.69 15.52 19.82 12.62 20.81Z" fill="none" stroke="inherit" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                        </svg>
                        لیست علاقه مندی
                    </a>
                    <a href="<?= esc_url( home_url( get_current_section_base() . '/deliveries' ) ) ?>"
                       class="account-nav__item <?= $active_profile_tab === 'deliveries' ? 'active' : '' ?>"
                       role="tab">
                        <span class="icon icon-flash"></span>
                        کدهای تحویل‌شده
                    </a>
                    <a href="<?= esc_url( home_url( get_current_section_base() . '/post' ) ) ?>"
                       class="account-nav__item <?= $active_profile_tab === 'post' ? 'active' : '' ?>"
                       role="tab">
                        <span class="icon icon-document"></span>
                        ارسال مقاله
                    </a>
                    <a href="<?= esc_url( home_url( get_current_section_base() . '/wallet' ) ) ?>"
                       class="account-nav__item <?= $active_profile_tab === 'wallet' ? 'active' : '' ?>"
                       role="tab">
                        <span class="icon icon-wallet"></span>
                        کیف پول و امتیاز
                    </a>
                    <?php
                    if (!$vip){
                        ?>
                        <a href="<?= esc_url( home_url( get_current_section_base() . '/verification' ) ) ?>"
                           class="account-nav__item <?= $active_profile_tab === 'verification' ? 'active' : '' ?>"
                           role="tab">
                            <span class="icon icon-verify"></span>
                            احراز هویت
                        </a>
                        <?php
                    }
                    ?>
                    <a href="<?= esc_url( home_url( get_current_section_base() . '/coupons' ) ) ?>"
                       class="account-nav__item <?= $active_profile_tab === 'coupons' ? 'active' : '' ?>"
                       role="tab">
                        <span class="icon icon-gift"></span>
                        کد های تخفیف
                    </a>
                    <a href="<?= esc_url( home_url( get_current_section_base() . '/cards' ) ) ?>"
                       class="account-nav__item <?= $active_profile_tab === 'cards' ? 'active' : '' ?>"
                       role="tab">
                        <span class="icon icon-card"></span>
                        کارت های بانکی
                    </a>
                    <a href="<?= esc_url( home_url( get_current_section_base() . '/user' ) ) ?>"
                       class="account-nav__item <?= $active_profile_tab === 'user' ? 'active' : '' ?>"
                       role="tab">
                        <span class="icon icon-user-o"></span>
                        تنظیمات حساب کاربری
                    </a>
                </nav>
            </aside>

            <div class="account-content">
                <?php if ($active_profile_tab !== ''): ?>
                    <?php
                    $tab_content_rendered = false;
                    if (is_readable($active_profile_template)) {
                        ob_start();
                        include $active_profile_template;
                        $template_output = (string) ob_get_clean();

                        if (preg_match('/<div class="account-content">(.*)<\/div>\s*<\/div>\s*<\/section>\s*<\/main>\s*$/is', $template_output, $matches)) {
                            echo trim($matches[1]);
                            $tab_content_rendered = true;
                        }
                    }
                    if (!$tab_content_rendered) {
                        ?>
                        <div class="account-panel active" role="tabpanel" aria-hidden="false" tabindex="0">
                            <div class="account-panel__section">
                                <div>
                                    <h3>خطا در بارگذاری</h3>
                                    <p>محتوای این بخش در حال حاضر قابل نمایش نیست.</p>
                                </div>
                            </div>
                        </div>
                        <?php
                    }
                    ?>
                <?php else: ?>
                <?php
                $dashboard_orders = wc_get_orders([
                    'customer_id' => $user_id,
                    'limit' => -1,
                    'orderby' => 'date',
                    'order' => 'DESC',
                ]);
                if (!is_array($dashboard_orders)) {
                    $dashboard_orders = [];
                }

                $dashboard_latest_orders = array_slice($dashboard_orders, 0, 7);
                $dashboard_total_products = 0;
                $dashboard_delivered_codes = 0;

                foreach ($dashboard_orders as $dashboard_order) {
                    $dashboard_status = $dashboard_order->get_status();
                    if (in_array($dashboard_status, ['cancelled', 'failed'], true)) {
                        continue;
                    }

                    foreach ($dashboard_order->get_items() as $dashboard_item) {
                        $dashboard_total_products += (int) $dashboard_item->get_quantity();

                        if (!in_array($dashboard_status, ['processing', 'completed'], true)) {
                            continue;
                        }

                        $licenses = $dashboard_item->get_meta('_reserved_licence_ids');
                        if (empty($licenses)) {
                            continue;
                        }

                        if (is_string($licenses)) {
                            $licenses = json_decode($licenses, true);
                        }

                        if (is_array($licenses)) {
                            $dashboard_delivered_codes += count($licenses);
                        }
                    }
                }

                $dashboard_ticket_records = $db->query(
                    "SELECT * FROM {$wpdb->prefix}ticket WHERE userId = :user_id AND rep_Id IS NULL ORDER BY ticketId DESC",
                    ['user_id' => $user_id]
                );
                if (!is_array($dashboard_ticket_records)) {
                    $dashboard_ticket_records = [];
                }
                $dashboard_ticket_count = count($dashboard_ticket_records);
                $dashboard_latest_tickets = array_slice($dashboard_ticket_records, 0, 3);

                wp_reset_postdata();
                    ?>
                <div class="account-panel active" id="panel-dashboard" data-panel="dashboard" role="tabpanel" aria-hidden="false" tabindex="0">
                    <div class="account-panel__section">
                        <div class="header">
                            <?php
                            if (!isMobile()){
                            ?>
                            <div class="bg-white rounded-sm">
                            <h3>داشبورد</h3>
                            <p>داشبورد کاربری</p>
                            </div>
                            <div class="user-dashboard-statistics">
                                <div class="user-dashboard-statistics-item-handler">
                                    <a href="<?= esc_url(home_url(get_current_section_base() . '/deliveries')) ?>">
                                        <div class="user-dashboard-statistics-item">
                                            <small>کد های تحویل داده شده</small>
                                            <strong><span><?= number_format($dashboard_delivered_codes) ?></span></strong>
                                        </div>
                                    </a>
                                </div>
                                <div class="user-dashboard-statistics-item-handler">
                                    <a href="<?= esc_url(home_url(get_current_section_base() . '/orders')) ?>">
                                        <div class="user-dashboard-statistics-item">
                                            <small>محصول خریداری شده</small>
                                            <strong><?= number_format($dashboard_total_products) ?></strong>
                                        </div>
                                    </a>
                                </div>
                                <div class="user-dashboard-statistics-item-handler">
                                    <a href="<?= esc_url(home_url('/ticket')) ?>">
                                        <div class="user-dashboard-statistics-item">
                                            <small>تیکت ارسال شده</small>
                                            <strong><?= number_format($dashboard_ticket_count) ?></strong>
                                        </div>
                                    </a>
                                </div>
                                <div class="user-dashboard-statistics-item-handler">
                                    <div class="user-dashboard-statistics-item">
                                        <div class="flex justify-between align-items-end">
                                            <div >
                                                <small>امتیاز وفاداری</small>
                                                <strong><?=number_format(UserModel::points())?></strong>
                                            </div>
                                            <button type="button" class="Button-cp54" style="width: 94px;height: 30px; border: 1px solid #e7e7e7; padding: 2px 8px; border-radius: 7px; color: #cccccc; font-size: 14px; ">تبدیل به اعتبار</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php
                            }else{
                                echo ' <h3>داشبورد</h3>
                            <p>داشبورد کاربری</p>';
                            }
                            ?>
                        </div>
                        <div>
                            <?php
                            if (!isMobile()){?>
                                <div class="flex justify-between flex-col sSj451">
                                    <div class="user-dashboard-last-tickets-handler">
                                        <div class="user-dashboard-last-tickets md:w-46<?= empty($dashboard_latest_tickets) ? ' empty-date' : '' ?>">
                                            <div class="user-dashboard-section-title">
                                                <i class="fi fi-rr-list-dropdown"></i>آخرین تیکت ها
                                                <div class="user-dashboard-section-title-button">
                                                    <a href="<?= esc_url(home_url('/ticket')) ?>">
                                                        <i class="icon-edit"></i>
                                                        ایجاد جدید
                                                    </a>
                                                </div>
                                            </div>
                                            <div class="user-dashboard-tickets-list">
                                                <?php if (!empty($dashboard_latest_tickets)): ?>
                                                    <table class="table-list panel-table-list">
                                                        <thead><tr><th>عنوان</th><th>تاریخ ایجاد</th><th>وضعیت</th><th></th></tr></thead>
                                                        <tbody>
                                                        <?php foreach ($dashboard_latest_tickets as $key => $dashboard_ticket): ?>
                                                            <?php
                                                            $ticket_id = isset($dashboard_ticket['ticketId']) ? (int) $dashboard_ticket['ticketId'] : 0;
                                                            $ticket_gid = $ticket_id * 2;
                                                            $ticket_title = !empty($dashboard_ticket['Issue']) ? $dashboard_ticket['Issue'] : 'بدون عنوان';
                                                            if ($dashboard_ticket['condition'] == 0){
                                                                $cls = 'Badge__info-st92ed';
                                                                $nm = "جدید";
                                                            }elseif ($dashboard_ticket['condition'] == 1){
                                                                $cls = 'Badge__info-16f59';
                                                                $nm = "درحال بررسی";
                                                            }elseif ($dashboard_ticket['condition'] == 2){
                                                                $cls = 'Badge__warning-MfubDgd';
                                                                $nm = "در انتظار جزئیات";
                                                            }elseif ($dashboard_ticket['condition'] == 3){
                                                                $cls = 'Badge__success-AVxEpg';
                                                                $nm = "حل شده";
                                                            }elseif ($dashboard_ticket['condition'] == 4){
                                                                $cls = 'Badge__neutral-XFzczo';
                                                                $nm = "بسته شده";
                                                            }
                                                            $ticket_time = !empty($dashboard_ticket['time']) ? giftmax_format_datetime_fa($dashboard_ticket['time']) : '-';
                                                            ?>
                                                            <tr class="cursor-pointer">
                                                                <td data-content="عنوان">
                                                                    <div class="table-td-inner text-sm tracking-tight font-medium text-dark ellipsis-1">
                                                                        <?=$ticket_title?>
                                                                    </div>
                                                                </td>
                                                                <td data-content="تاریخ ایجاد">
                                                                    <div class="table-td-inner"><?=$ticket_time?></div>
                                                                </td>
                                                                <td data-content="وضعیت">
                                                                    <div class="table-td-inner">
                                                                        <span class="badge <?=$cls?>"><?=$nm?></span>
                                                                    </div>
                                                                </td>
                                                                <td class="table-list-actions"><div class="table-td-inner flex justify-end pb-2 space-x-8 space-x-reverse"><a class="btn btn-2xs btn-white text-dark btn-view" href="<?= esc_url(home_url('/ticket/?gid=' . $ticket_gid)) ?>">مشاهده</a></div></td>
                                                            </tr>
                                                        <?php endforeach; ?>
                                                        </tbody>
                                                    </table>
                                                <?php else: ?>
                                                    <div class="user-dashboard-data-is-empty">
                                                        <img src="<?= esc_url(get_template_directory_uri() . '/assets/img/ticket_img.png') ?>">
                                                        <p>شما هیچ تیکتی در سیستم ارسال نکرده‌اید.</p>
                                                    </div>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <?php
                                        $dashboard_coupon_query = new WP_Query([
                                                'post_type' => 'shop_coupon',
                                                'posts_per_page' => 3,
                                        ]);
                                        ?>
                                        <div class="user-dashboard-last-tickets f2t5g<?= empty($dashboard_coupon_query->have_posts()) ? ' empty-date' : '' ?>">
                                            <div class="user-dashboard-section-title">
                                                <i class="fi fi-rr-list-dropdown"></i>کد تخفیف
                                                <div class="user-dashboard-section-title-button">
                                                    <a href="<?= esc_url(home_url('/profile/coupons')) ?>">
                                                        <i class="fi fi-rr-chart-pie-alt"></i>
                                                        مشاهده
                                                    </a>
                                                </div>
                                            </div>
                                            <div class="user-dashboard-tickets-list">
                                                <?php
                                                if (!empty($dashboard_coupon_query->have_posts())):?>
                                                    <table class="table-list panel-table-list">
                                                        <thead>
                                                        <tr>
                                                            <th>کد تخفیف</th>
                                                            <th>اعتبار تا</th>
                                                            <th>شامل</th>
                                                            <th></th>
                                                        </tr>
                                                        </thead>
                                                        <tbody>
                                                        <?php
                                                        foreach ($dashboard_coupon_query->posts as $i => $coupon) {
                                                            $dashboard_coupon_obj = new WC_Coupon($coupon->ID);
                                                            $products = $dashboard_coupon_obj->get_product_ids();

                                                            $discount_type = $dashboard_coupon_obj->get_discount_type();
                                                            $amount = (float)$dashboard_coupon_obj->get_amount();

                                                            switch ( $discount_type ) {

                                                                case 'percent':
                                                                    $discount_text = $amount . '٪';
                                                                    break;

                                                                case 'fixed_cart':
                                                                    $discount_text = number_format_usd( $amount ) . "تومان";
                                                                    break;

                                                                case 'fixed_product':
                                                                    $discount_text = number_format_usd( $amount ) . "تومان";
                                                                    break;

                                                                default:
                                                                    $discount_text = 'نامشخص';
                                                            }

                                                            $dashboard_coupon_code = $dashboard_coupon_obj->get_code();

                                                            $expiry_date = $dashboard_coupon_obj->get_date_expires();
                                                            if ($expiry_date) {
                                                                $dashboard_coupon_description =  gjdate($expiry_date->date_i18n('Y/m/d'),'d M Y');
                                                            }else{
                                                                $dashboard_coupon_description = 'بدون انقضا';
                                                            }
                                                            $usage_limit = $dashboard_coupon_obj->get_usage_limit();
                                                            $usage_count = $dashboard_coupon_obj->get_usage_count();
                                                            if ( $usage_limit ) {
                                                                $remaining = max( 0, $usage_limit - $usage_count );
                                                            } else {
                                                                $remaining = 'نامحدود';
                                                            }
                                                            ?>
                                                            <tr class="cursor-pointer">
                                                                <td data-content="کد تخفیف">
                                                                    <div class="table-td-inner text-sm tracking-tight font-medium text-dark ellipsis">
                                                                        <?= esc_html($dashboard_coupon_code) ?>
                                                                    </div>
                                                                </td>
                                                                <td data-content="اعتبار تا">
                                                                    <div class="table-td-inner"><?=$dashboard_coupon_description?></div>
                                                                </td>
                                                                <td class="table-list-actions" data-content="شامل">
                                                                    <div class="table-td-inner"><?=$discount_text?></div>
                                                                </td>
                                                                <td class="table-list-actions">
                                                                    <div class="table-td-inner flex justify-end pb-2 space-x-8 space-x-reverse">
                                                                        <button class="btn btn-2xs btn-white text-dark btn-view Button-ci56" data-id="<?=$coupon->ID?>">جزئیات</button>
                                                                    </div>
                                                                </td>
                                                            </tr>
                                                        <?php }
                                                        ?>
                                                        </tbody>
                                                    </table>
                                                <?php else: ?>
                                                    <div class="user-dashboard-data-is-empty">
                                                        <img src="<?= esc_url(get_template_directory_uri() . '/assets/img/ticket_img.png') ?>">
                                                        <p>کد تخفیفی پیدا نشد</p>
                                                    </div>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="user-dashboard-last-orders-handler">
                                        <div class="user-dashboard-last-orders last-orders <?= empty($dashboard_latest_orders) ? 'empty-date' : '' ?>" style="margin-left: 0">
                                            <div class="user-dashboard-section-title">
                                                <i class="fi fi-rr-marketplace"></i>آخرین سفارشات
                                                <div class="user-dashboard-section-title-button">
                                                    <a href="<?= esc_url(home_url('/shop')) ?>" target="_blank">
                                                        <i class="icon-cart-o"></i>
                                                        خرید جدید!
                                                    </a>
                                                </div>
                                            </div>

                                            <div class="user-dashboard-tickets-list">
                                                <?php if (!empty($dashboard_latest_orders)): ?>
                                                    <table class="table-list panel-table-list">
                                                        <thead><tr>
                                                            <th>شماره فاکتور</th>
                                                            <th>تاریخ سفارش</th>
                                                            <th>وضعیت سفارش</th>
                                                            <th>وضعیت فروش</th>
                                                            <th>وضعیت تحویل</th>
                                                            <th></th>
                                                        </tr></thead>
                                                        <tbody>
                                                        <?php foreach ($dashboard_latest_orders as $dashboard_order): ?>
                                                            <?php
                                                            $dashboard_order_date = $dashboard_order->get_date_created();
                                                            $dashboard_order_date = $dashboard_order_date ? $dashboard_order_date->date_i18n('Y/m/d') : '-';
                                                            if (!isMobile()){
                                                                if ($dashboard_order->get_status() != 'card-not-verified'){
                                                                    $urlOrders = esc_url(home_url(get_current_section_base() . '/invoices/' . $dashboard_order->get_id()));
                                                                }else{
                                                                    $urlOrders = esc_url(home_url(get_current_section_base() . '/orders'));
                                                                }
                                                                $suspiciousOrder = $dashboard_order->get_meta('_suspicious_order');
                                                                $suspiciousOrder = !$vip && $suspiciousOrder == 1;
                                                                ?>
                                                                <tr class="cursor-pointer">

                                                                    <td data-content="شماره فاکتور">
                                                                        <div class="table-td-inner text-sm tracking-tight font-medium text-dark ellipsis">#<?= esc_html($dashboard_order->get_order_number()) ?></div>
                                                                    </td>
                                                                    <td data-content="تاریخ سفارش">
                                                                        <div class="table-td-inner"><?=gjdate($dashboard_order_date,"d M Y")?></div>
                                                                    </td>
                                                                    <td data-content="وضعیت سفارش" class="py-7">
                                                                        <div class="table-td-inner">
                                                                            <?php
                                                                            if ($dashboard_order->get_status() == 'card-not-verified'){?>
                                                                                <div class="flex gap-2">
                                                                                    <span class="badge status-pill--completed text-3xs">تکمیل شده</span>
                                                                                    <span class="badge status-pill--card-not-verified text-3xs">مغایرت کارت بانکی</span>
                                                                                </div>
                                                                                <span class="badge status-pill--pending text-3xs" style="margin-top: 3px;">تایید مالکیت کارت</span>
                                                                                <?php
                                                                            }elseif($suspiciousOrder == 1){?>
                                                                                <div class="flex gap-2">
                                                                                    <span class="badge status-pill--completed text-3xs">تکمیل شده</span>
                                                                                    <span class="badge status-pill--pending text-3xs" style="margin-top: 3px;">سفارش مشکوک به فیشینگ</span>
                                                                                </div>
                                                                            <?php }
                                                                            else{?>
                                                                                <span class="badge status-pill--<?=$dashboard_order->get_status()?> text-3xs"><?= esc_html(wc_get_order_status_name($dashboard_order->get_status())) ?></span>
                                                                                <?php
                                                                            }
                                                                            ?>
                                                                        </div>
                                                                    </td>
                                                                    <td data-content="وضعیت فروش">
                                                                        <?php
                                                                        $is_preorder = $dashboard_order->get_meta('_has_preorder_items');
                                                                        if(!$is_preorder) {?>
                                                                            <div class="badge badge-primary text-3xs">تحویل آنی</div>
                                                                            <?php
                                                                        }else{
                                                                            $presale = get_max_presale_item_by_order_id($dashboard_order->get_id());
                                                                            if ($presale['t'] && $presale['license_status'] != 2){?>
                                                                                <div class="table-td-inner">
                                                                                    <span class="text-neutral-500 text-caption line-height-1">تحویل با تاخیر</span>
                                                                                    <div class="text-primary-700 text-body2-strong style_ProductPromotionTimeline__timer__zS6ZA1 line-height-1 mt-1"><?=$presale['ctt']?></div>
                                                                                </div>
                                                                                <?php
                                                                            }else{
                                                                                ?>
                                                                                <div class="badge badge-info text-3xs">تحویل با تاخیر</div>
                                                                                <?php
                                                                            }
                                                                        }
                                                                        ?>
                                                                    </td>
                                                                    <td data-content="وضعیت تحویل">
                                                                        <?php
                                                                        if ($dashboard_order->get_status() == 'completed'){
                                                                            if ($suspiciousOrder == 1){?>
                                                                                <span class="badge status-pill--failed text-3xs">عدم تحویل</span>
                                                                                <span class="badge status-pill--failed text-3xs">نیاز به تایید هویت</span>
                                                                            <?php }
                                                                            elseif ($is_preorder){
                                                                                if ($presale['license_status'] == 0){
                                                                                    echo '<span class="badge status-pill--pending text-3xs">درحال تامین کالا</span>';
                                                                                }elseif ($presale['license_status'] == 1){
                                                                                    echo '<span class="badge status-pill--checkout-draft text-3xs">در حال تحویل</span>';
                                                                                }elseif ($presale['license_status'] == 2){
                                                                                    echo '<span class="badge status-pill--completed text-3xs">تحویل داده شد</span>';
                                                                                }
                                                                            }else{
                                                                                ?>
                                                                                <span class="badge status-pill--completed text-3xs">تحویل داده شد</span>
                                                                                <?php
                                                                            }
                                                                        }else if ($dashboard_order->get_status() == 'card-not-verified'){
                                                                            ?>
                                                                            <div class="flex justify-between">
                                                                                <span class="badge status-pill--failed text-3xs">عدم تحویل</span>
                                                                                <?php
                                                                                $cardPay = $dashboard_order->get_meta( '_card_pay', true );
                                                                                $isCheck = $dashboard_order->get_meta( '_is_card_pay', true );
                                                                                $card = UserModel::table('user_bank_cards', 'card_number_enc', encrypt_data($cardPay),"user_id",$user_id);
                                                                                if (!empty($card)) {
                                                                                    ?>
                                                                                    <span class="badge status-pill--completed text-3xs">تایید کارت</span>
                                                                                    <?php
                                                                                }else{
                                                                                    ?>
                                                                                    <span class="badge status-pill--failed text-3xs">تایید کارت</span>
                                                                                    <?php
                                                                                }
                                                                                ?>
                                                                                <span class="badge status-pill--failed text-3xs check-phone">تایید تلفن</span>
                                                                            </div>
                                                                            <?php
                                                                        }else if ($dashboard_order->get_status() != 'card-not-verified' && $dashboard_order->get_status() != 'completed'){
                                                                            ?>
                                                                            <span class="badge status-pill--failed text-3xs">عدم تحویل</span>
                                                                            <?php
                                                                        }
                                                                        ?>
                                                                    </td>
                                                                    <td class="table-list-actions">
                                                                        <div class="table-td-inner flex justify-end pb-2 space-x-8 space-x-reverse align-items-center">
                                                                            <?php
                                                                            if ($dashboard_order->get_status() != 'card-not-verified'){
                                                                                if ($suspiciousOrder == 1){?>
                                                                                    <a class="btn btn-2xs btn-white text-dark btn-view" href="<?= (home_url(get_current_section_base() . '/verification/')) ?>">احرازهویت</a>
                                                                                    <?php
                                                                                }else{
                                                                                    ?>
                                                                                    <a class="btn btn-2xs btn-white text-dark btn-view" href="<?= esc_url(home_url(get_current_section_base() . '/invoices/' . $dashboard_order->get_id())) ?>">مشاهده</a>
                                                                                    <?php
                                                                                }
                                                                            }else{
                                                                                if ($isCheck){?>
                                                                                <svg class="Button-od94" data-number="<?=$cardPay?>" data-id="<?=encrypt_id($dashboard_order->get_id())?>" viewBox="0 0 24 24"><path fill-rule="evenodd" d="M2 12c0 5.523 4.477 10 10 10s10-4.477 10-10S17.523 2 12 2 2 6.477 2 12zm18 0a8 8 0 11-16 0 8 8 0 0116 0zm-10-2h3v7h-2v-5h-1v-2zm3-2a1 1 0 10-2 0 1 1 0 002 0z" clip-rule="evenodd"></path></svg>
                                                                                <button class="btn btn-2xs btn-white text-dark btn-view Button-vcs788" data-id="<?=encrypt_id($dashboard_order->get_id())?>">تایید کارت</button>
                                                                            <?php }else{?>
                                                                                <svg class="Button-od94" data-number="<?=$cardPay?>" data-check="1" data-id="<?=encrypt_id($dashboard_order->get_id())?>" viewBox="0 0 24 24"><path fill-rule="evenodd" d="M2 12c0 5.523 4.477 10 10 10s10-4.477 10-10S17.523 2 12 2 2 6.477 2 12zm18 0a8 8 0 11-16 0 8 8 0 0116 0zm-10-2h3v7h-2v-5h-1v-2zm3-2a1 1 0 10-2 0 1 1 0 002 0z" clip-rule="evenodd"></path></svg>
                                                                                <button class="btn btn-2xs btn-white text-dark btn-view Button-sc45" data-number="<?=$cardPay?>" data-id="<?=encrypt_id($dashboard_order->get_id())?>">تایید کارت</button>
                                                                                <?php
                                                                            } }
                                                                            ?>

                                                                        </div>
                                                                    </td>
                                                                </tr>
                                                                <?php
                                                            }
                                                         endforeach; ?>
                                                        </tbody>
                                                    </table>
                                                <?php else: ?>
                                                    <div class="user-dashboard-data-is-empty">
                                                        <img src="<?= esc_url(get_template_directory_uri() . '/assets/img/ticket_img.png') ?>">
                                                        <p>شما هیچ سفارشی در فروشگاه ایجاد نکرده‌اید.</p>
                                                    </div>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php }else{?>
                                <div class="flex justify-between flex-col sSj451">
                                    <div class="user-dashboard-last-orders-handler">
                                        <div class="user-dashboard-last-orders last-orders <?= empty($dashboard_latest_orders) ? 'empty-date' : '' ?>" style="margin-left: 0">
                                            <div class="user-dashboard-section-title">
                                                <i class="fi fi-rr-marketplace"></i>آخرین سفارشات
                                                <div class="user-dashboard-section-title-button">
                                                    <a href="<?= esc_url(home_url('/shop')) ?>" target="_blank">
                                                        <i class="icon-cart-o"></i>
                                                        خرید جدید!
                                                    </a>
                                                </div>
                                            </div>

                                            <div class="user-dashboard-tickets-list">
                                                <?php if (!empty($dashboard_latest_orders)): ?>
                                                    <table class="table-list panel-table-list">
                                                        <thead><tr>
                                                            <th>شماره فاکتور</th>
                                                            <th>تاریخ سفارش</th>
                                                            <th>وضعیت سفارش</th>
                                                            <th>وضعیت فروش</th>
                                                            <th>وضعیت تحویل</th>
                                                            <th></th>
                                                        </tr></thead>
                                                        <tbody>
                                                        <?php foreach ($dashboard_latest_orders as $dashboard_order): ?>
                                                            <?php
                                                            $dashboard_order_date = $dashboard_order->get_date_created();
                                                            $dashboard_order_date = $dashboard_order_date ? $dashboard_order_date->date_i18n('Y/m/d') : '-';
                                                            $suspiciousOrder = $dashboard_order->get_meta('_suspicious_order');
                                                            $suspiciousOrder = !$vip && $suspiciousOrder == 1;
                                                            if (isMobile()){?>
                                                                <tr class="cursor-pointer">
                                                                    <td data-content="شماره فاکتور">
                                                                        <div class="table-td-inner text-sm tracking-tight font-medium text-dark ellipsis">#<?= esc_html($dashboard_order->get_order_number()) ?></div>
                                                                    </td>
                                                                    <td data-content="تاریخ سفارش">
                                                                        <div class="table-td-inner"><?=gjdate($dashboard_order_date,"d M Y")?></div>
                                                                    </td>
                                                                    <td data-content="وضعیت سفارش">
                                                                        <div class="table-td-inner">
                                                                            <?php
                                                                            if ($dashboard_order->get_status() == 'card-not-verified'){?>
                                                                                <div class="flex gap-2">
                                                                                    <span class="badge status-pill--completed text-3xs">تکمیل شده</span>
                                                                                    <span class="badge status-pill--card-not-verified text-3xs">مغایرت کارت بانکی</span>
                                                                                </div>
                                                                                <span class="badge status-pill--pending text-3xs" style="margin-top: 3px;">تایید مالکیت کارت</span>
                                                                                <?php
                                                                            }elseif($suspiciousOrder == 1){?>
                                                                                <div class="flex gap-2">
                                                                                    <span class="badge status-pill--completed text-3xs">تکمیل شده</span>
                                                                                    <span class="badge status-pill--pending text-3xs" style="margin-top: 3px;">سفارش مشکوک به فیشینگ</span>
                                                                                </div>
                                                                            <?php }
                                                                            else{?>
                                                                                <span class="badge status-pill--<?=$dashboard_order->get_status()?> text-3xs"><?= esc_html(wc_get_order_status_name($dashboard_order->get_status())) ?></span>
                                                                                <?php
                                                                            }
                                                                            ?>
                                                                        </div>
                                                                    </td>
                                                                    <td data-content="وضعیت فروش">
                                                                        <div class="table-td-inner">
                                                                            <?php
                                                                            $is_preorder = $dashboard_order->get_meta('_has_preorder_items');
                                                                            if(!$is_preorder) {?>
                                                                                <div class="badge badge-primary text-3xs">تحویل آنی</div>
                                                                                <?php
                                                                            }else{
                                                                                $presale = get_max_presale_item_by_order_id($dashboard_order->get_id());
                                                                                if ($presale['t'] && $presale['license_status'] != 2){?>
                                                                                    <div class="table-td-inner">
                                                                                        <span class="text-neutral-500 text-caption line-height-1">تحویل با تاخیر</span>
                                                                                        <div class="text-primary-700 text-body2-strong style_ProductPromotionTimeline__timer__zS6ZA1 line-height-1 mt-1"><?=$presale['ctt']?></div>
                                                                                    </div>
                                                                                    <?php
                                                                                }else{
                                                                                    ?>
                                                                                    <div class="badge badge-info text-3xs">تحویل با تاخیر</div>
                                                                                    <?php
                                                                                }
                                                                            }
                                                                            ?>
                                                                        </div>
                                                                    </td>
                                                                    <td data-content="وضعیت تحویل">
                                                                        <div class="table-td-inner">
                                                                            <?php
                                                                            if ($dashboard_order->get_status() == 'completed'){
                                                                                if ($suspiciousOrder == 1){?>
                                                                                    <span class="badge status-pill--failed text-3xs">عدم تحویل</span>
                                                                                    <span class="badge status-pill--failed text-3xs">نیاز به تایید هویت</span>
                                                                                <?php }
                                                                                elseif ($is_preorder){
                                                                                    if ($presale['license_status'] == 0){
                                                                                        echo '<span class="badge status-pill--pending text-3xs">درحال تامین کالا</span>';
                                                                                    }elseif ($presale['license_status'] == 1){
                                                                                        echo '<span class="badge status-pill--checkout-draft text-3xs">در حال تحویل</span>';
                                                                                    }elseif ($presale['license_status'] == 2){
                                                                                        echo '<span class="badge status-pill--completed text-3xs">تحویل داده شد</span>';
                                                                                    }
                                                                                }else{
                                                                                    ?>
                                                                                    <span class="badge status-pill--completed text-3xs">تحویل داده شد</span>
                                                                                    <?php
                                                                                }
                                                                            }else if ($dashboard_order->get_status() == 'card-not-verified'){
                                                                                ?>
                                                                                <div class="flex justify-end">
                                                                                    <span class="badge status-pill--failed text-3xs">عدم تحویل</span>
                                                                                    <?php
                                                                                    $cardPay = $dashboard_order->get_meta( '_card_pay', true );
                                                                                    $isCheck = $dashboard_order->get_meta( '_is_card_pay', true );
                                                                                    $card = UserModel::table('user_bank_cards', 'card_number_enc', encrypt_data($cardPay),"user_id",$user_id);
                                                                                    if (!empty($card)) {
                                                                                        ?>
                                                                                        <span class="badge status-pill--completed text-3xs">تایید کارت</span>
                                                                                        <?php
                                                                                    }else{
                                                                                        ?>
                                                                                        <span class="badge status-pill--failed text-3xs">تایید کارت</span>
                                                                                        <?php
                                                                                    }
                                                                                    ?>
                                                                                    <span class="badge status-pill--failed text-3xs check-phone">تایید تلفن</span>
                                                                                </div>
                                                                                <?php
                                                                            }else if ($dashboard_order->get_status() != 'card-not-verified' && $dashboard_order->get_status() != 'completed'){
                                                                                ?>
                                                                                <span class="badge status-pill--failed text-3xs">عدم تحویل</span>
                                                                                <?php
                                                                            }
                                                                            ?>
                                                                        </div>
                                                                    </td>
                                                                    <td class="table-list-actions">
                                                                        <div class="table-td-inner flex justify-end pb-2 space-x-8 space-x-reverse align-items-center">
                                                                            <?php
                                                                            if ($dashboard_order->get_status() != 'card-not-verified'){
                                                                                if ($suspiciousOrder == 1){?>
                                                                                    <a class="btn btn-2xs btn-white text-dark btn-view" href="<?= (home_url(get_current_section_base() . '/verification/')) ?>">احرازهویت</a>
                                                                                    <?php
                                                                                }else{
                                                                                    ?>
                                                                                    <a class="btn btn-2xs btn-white text-dark btn-view" href="<?= esc_url(home_url(get_current_section_base() . '/invoices/' . $dashboard_order->get_id())) ?>">مشاهده</a>
                                                                                    <?php
                                                                                }
                                                                            }else{
                                                                                if ($isCheck){?>
                                                                                    <svg class="Button-od94" data-number="<?=$cardPay?>" data-id="<?=encrypt_id($dashboard_order->get_id())?>" viewBox="0 0 24 24"><path fill-rule="evenodd" d="M2 12c0 5.523 4.477 10 10 10s10-4.477 10-10S17.523 2 12 2 2 6.477 2 12zm18 0a8 8 0 11-16 0 8 8 0 0116 0zm-10-2h3v7h-2v-5h-1v-2zm3-2a1 1 0 10-2 0 1 1 0 002 0z" clip-rule="evenodd"></path></svg>
                                                                                    <button class="btn btn-2xs btn-white text-dark btn-view Button-vcs788" data-id="<?=encrypt_id($dashboard_order->get_id())?>">تایید کارت</button>
                                                                                <?php }else{?>
                                                                                    <svg class="Button-od94" data-number="<?=$cardPay?>" data-check="1" data-id="<?=encrypt_id($dashboard_order->get_id())?>" viewBox="0 0 24 24"><path fill-rule="evenodd" d="M2 12c0 5.523 4.477 10 10 10s10-4.477 10-10S17.523 2 12 2 2 6.477 2 12zm18 0a8 8 0 11-16 0 8 8 0 0116 0zm-10-2h3v7h-2v-5h-1v-2zm3-2a1 1 0 10-2 0 1 1 0 002 0z" clip-rule="evenodd"></path></svg>
                                                                                    <button class="btn btn-2xs btn-white text-dark btn-view Button-sc45" data-number="<?=$cardPay?>" data-id="<?=encrypt_id($dashboard_order->get_id())?>">تایید کارت</button>
                                                                                    <?php
                                                                                }
                                                                            }
                                                                            ?>
                                                                        </div>
                                                                    </td>
                                                                </tr>
                                                            <?php }
                                                            ?>
                                                        <?php endforeach; ?>
                                                        </tbody>
                                                    </table>
                                                <?php else: ?>
                                                    <div class="user-dashboard-data-is-empty">
                                                        <img src="<?= esc_url(get_template_directory_uri() . '/assets/img/ticket_img.png') ?>">
                                                        <p>شما هیچ سفارشی در فروشگاه ایجاد نکرده‌اید.</p>
                                                    </div>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                    <?php
                                    $dashboard_coupon_query = new WP_Query([
                                            'post_type' => 'shop_coupon',
                                            'posts_per_page' => 3,
                                    ]);
                                    ?>
                                    <div class="user-dashboard-last-tickets <?= empty($dashboard_coupon_query->have_posts()) ? 'empty-date' : '' ?>">
                                        <div class="user-dashboard-section-title">
                                            <i class="fi fi-rr-list-dropdown"></i>کد تخفیف
                                            <div class="user-dashboard-section-title-button">
                                                <a href="<?= esc_url(home_url('/profile/coupons')) ?>">
                                                    <i class="fi fi-rr-chart-pie-alt"></i>
                                                    مشاهده
                                                </a>
                                            </div>
                                        </div>
                                        <div class="user-dashboard-tickets-list">
                                            <?php
                                            if (!empty($dashboard_coupon_query->have_posts())):?>
                                                <table class="table-list panel-table-list">
                                                    <thead>
                                                    <tr>
                                                        <th>کد تخفیف</th>
                                                        <th>اعتبار تا</th>
                                                        <th>شامل</th>
                                                        <th></th>
                                                    </tr>
                                                    </thead>
                                                    <tbody>
                                                    <?php
                                                    foreach ($dashboard_coupon_query->posts as $i => $coupon) {
                                                        $dashboard_coupon_obj = new WC_Coupon($coupon->ID);
                                                        $products = $dashboard_coupon_obj->get_product_ids();

                                                        $discount_type = $dashboard_coupon_obj->get_discount_type();
                                                        $amount = (float)$dashboard_coupon_obj->get_amount();

                                                        switch ( $discount_type ) {

                                                            case 'percent':
                                                                $discount_text = $amount . '٪';
                                                                break;

                                                            case 'fixed_cart':
                                                                $discount_text = number_format_usd( $amount ) . "تومان";
                                                                break;

                                                            case 'fixed_product':
                                                                $discount_text = number_format_usd( $amount ) . "تومان";
                                                                break;

                                                            default:
                                                                $discount_text = 'نامشخص';
                                                        }

                                                        $dashboard_coupon_code = $dashboard_coupon_obj->get_code();

                                                        $expiry_date = $dashboard_coupon_obj->get_date_expires();
                                                        if ($expiry_date) {
                                                            $dashboard_coupon_description =  gjdate($expiry_date->date_i18n('Y/m/d'),'d M Y');
                                                        }else{
                                                            $dashboard_coupon_description = 'بدون انقضا';
                                                        }
                                                        $usage_limit = $dashboard_coupon_obj->get_usage_limit();
                                                        $usage_count = $dashboard_coupon_obj->get_usage_count();
                                                        if ( $usage_limit ) {
                                                            $remaining = max( 0, $usage_limit - $usage_count );
                                                        } else {
                                                            $remaining = 'نامحدود';
                                                        }
                                                        ?>
                                                        <tr class="cursor-pointer">
                                                            <td data-content="کد تخفیف">
                                                                <div class="table-td-inner text-sm tracking-tight font-medium text-dark ellipsis">
                                                                    <?= esc_html($dashboard_coupon_code) ?>
                                                                </div>
                                                            </td>
                                                            <td data-content="اعتبار تا">
                                                                <div class="table-td-inner"><?=$dashboard_coupon_description?></div>
                                                            </td>
                                                            <td class="table-list-actions" data-content="شامل">
                                                                <div class="table-td-inner"><?=$discount_text?></div>
                                                            </td>
                                                            <td class="table-list-actions">
                                                                <div class="table-td-inner flex justify-end pb-2 space-x-8 space-x-reverse">
                                                                    <button class="btn btn-2xs btn-white text-dark btn-view Button-ci56" data-id="<?=$coupon->ID?>">جزئیات</button>
                                                                </div>
                                                            </td>
                                                        </tr>
                                                    <?php }
                                                    ?>
                                                    </tbody>
                                                </table>
                                            <?php else: ?>
                                                <div class="user-dashboard-data-is-empty">
                                                    <img src="<?= esc_url(get_template_directory_uri() . '/assets/img/ticket_img.png') ?>">
                                                    <p>کد تخفیفی پیدا نشد</p>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="user-dashboard-last-tickets <?= empty($dashboard_latest_tickets) ? ' empty-date' : '' ?>">
                                        <div class="user-dashboard-section-title">
                                            <i class="fi fi-rr-list-dropdown"></i>آخرین تیکت ها
                                            <div class="user-dashboard-section-title-button">
                                                <a href="<?= esc_url(home_url('/ticket')) ?>">
                                                    <i class="icon-edit"></i>
                                                    ایجاد جدید
                                                </a>
                                            </div>
                                        </div>
                                        <div class="user-dashboard-tickets-list">
                                            <?php if (!empty($dashboard_latest_tickets)): ?>
                                                <table class="table-list panel-table-list">
                                                    <thead><tr><th>عنوان</th><th>تاریخ ایجاد</th><th>وضعیت</th><th></th></tr></thead>
                                                    <tbody>
                                                    <?php foreach ($dashboard_latest_tickets as $key => $dashboard_ticket): ?>
                                                        <?php
                                                        $ticket_id = isset($dashboard_ticket['ticketId']) ? (int) $dashboard_ticket['ticketId'] : 0;
                                                        $ticket_gid = $ticket_id * 2;
                                                        $ticket_title = !empty($dashboard_ticket['Issue']) ? $dashboard_ticket['Issue'] : 'بدون عنوان';
                                                        if ($dashboard_ticket['condition'] == 0){
                                                            $cls = 'Badge__info-st92ed';
                                                            $nm = "جدید";
                                                        }elseif ($dashboard_ticket['condition'] == 1){
                                                            $cls = 'Badge__info-16f59';
                                                            $nm = "درحال بررسی";
                                                        }elseif ($dashboard_ticket['condition'] == 2){
                                                            $cls = 'Badge__warning-MfubDgd';
                                                            $nm = "در انتظار جزئیات";
                                                        }elseif ($dashboard_ticket['condition'] == 3){
                                                            $cls = 'Badge__success-AVxEpg';
                                                            $nm = "حل شده";
                                                        }elseif ($dashboard_ticket['condition'] == 4){
                                                            $cls = 'Badge__neutral-XFzczo';
                                                            $nm = "بسته شده";
                                                        }
                                                        $ticket_time = !empty($dashboard_ticket['time']) ? giftmax_format_datetime_fa($dashboard_ticket['time']) : '-';
                                                        ?>
                                                        <tr class="cursor-pointer">
                                                            <td data-content="عنوان">
                                                                <div class="table-td-inner text-sm tracking-tight font-medium text-dark ellipsis-1">
                                                                    <?=$ticket_title?>
                                                                </div>
                                                            </td>
                                                            <td data-content="تاریخ ایجاد">
                                                                <div class="table-td-inner"><?=$ticket_time?></div>
                                                            </td>
                                                            <td data-content="وضعیت">
                                                                <div class="table-td-inner">
                                                                    <span class="badge <?=$cls?>"><?=$nm?></span>
                                                                </div>
                                                            </td>
                                                            <td class="table-list-actions"><div class="table-td-inner flex justify-end pb-2 space-x-8 space-x-reverse"><a class="btn btn-2xs btn-white text-dark btn-view" href="<?= esc_url(home_url('/ticket/?gid=' . $ticket_gid)) ?>">مشاهده</a></div></td>
                                                        </tr>
                                                    <?php endforeach; ?>
                                                    </tbody>
                                                </table>
                                            <?php else: ?>
                                                <div class="user-dashboard-data-is-empty">
                                                    <img src="<?= esc_url(get_template_directory_uri() . '/assets/img/ticket_img.png') ?>">
                                                    <p>شما هیچ تیکتی در سیستم ارسال نکرده‌اید.</p>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            <?php }
                            ?>
                            <div class="flex justify-between sSj45">
                                <div class="user-dashboard-last-notification-handler">
                                    <div class="user-dashboard-last-notification">
                                        <div class="user-dashboard-section-title">
                                           آخرین اطلاعیه ها
                                            <div class="user-dashboard-section-title-button">
                                                <a href="<?=home_url('/notifications')?>">مشاهده همه</a>
                                            </div>
                                        </div>
                                        <div class="user-dashboard-notifications-list">
                                            <?php
                                            $db = \Giftmax\Modules\Db::getLnstance();
                                            global $wpdb;
                                            $user_id = get_current_user_id();
                                            $records = $db->query("SELECT n.*,r.* FROM `{$wpdb->prefix}notifications` n LEFT JOIN `{$wpdb->prefix}notification_reads` r ON r.`notification_id` = n.`Id` AND r.`user_id` = :user_id WHERE n.`is_active`=1 AND (n.`userId` IS NULL OR n.`userId`=0 OR n.`userId`=:user_id) ORDER BY n.`Id` DESC Limit 4", array('user_id' => $user_id));
                                            if (!empty($records)){
                                                foreach ($records as $i => $record){
                                                    ?>
                                                    <div class="flex justify-between text-body-1 color-n-700 w-100 <?=empty($record['notification_id']) ? " notif-sa23" : ' notif-ra23'?> <?=count($records) != $i ? 'mb-3' : '' ?>" data-id="<?=$record['Id']?>">
                                                        <div class="flex gap-3 align-items-center">
                                                            <p class="notif-_count"><?=$i+1?></p>
                                                            <p class="mb-2 color-n-700 text-body-1 mb-2"><?=$record['title']?></p>
                                                        </div>
                                                        <div>
                                                            <?php
                                                            if (!empty($record['notification_id'])) {?>
                                                                <span class="notif-_status"> خوانده شده </span>
                                                            <?php }else{?>
                                                                <span class="notif-_status"> خوانده نشده </span>
                                                            <?php }
                                                            ?>
                                                        </div>
                                                    </div>
                                                    <?php
                                                }
                                            }else{
                                            ?>
                                            <div class="user-dashboard-search-not-found">
                                                <img src="<?=get_template_directory_uri() . '/assets/img/svg/data-empty.svg'?>">
                                                <h3>اطلاعیه ای پیدا نشد!</h3>
                                                <p>شما در این مدت  اطلاعیه ای ندارید.</p>
                                            </div>
                                            <?php
                                            }
                                            ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="user-dashboard-cart-handler">
                                    <div class="user-dashboard-cart">
                                        <div class="user-dashboard-section-title">
                                            کارت های بانکی
                                            <div class="user-dashboard-section-title-button">
                                                <a href="<?= esc_url( home_url( get_current_section_base() . '/cards' ) ) ?>">مشاهده همه </a>
                                            </div>
                                        </div>
                                        <div class="user-dashboard-cart-list">
                                            <?php
                                            global $wpdb;
                                            $db = \Giftmax\Modules\Db::getLnstance();
                                            $user = wp_get_current_user();
                                            $defaultCard = $db->query("SELECT * FROM `{$wpdb->prefix}user_bank_cards` WHERE `user_id`=:user_id Limit 5",array('user_id'=>$user_id));
                                            ob_start();
                                            if (!empty($defaultCard)){
                                            foreach ($defaultCard as $card) {
                                            $cardNumber = rtrim(
                                                chunk_split(decrypt_data($card['card_number_enc']), 4, '-'),
                                                '-'
                                            );
                                            ?>
                                            <div class="user-dashboard-cart-item flex justify-between">
                                                <div class="d-flex user-dashboard-single-install-data-title justify-between">
                                                    <div class="flex align-items-center">
                                                        <div class="bank-card__logo" aria-hidden="true">
                                                            <img loading="lazy" decoding="async" data-nimg="1" class="h-auto" src="<?=detectBankImage(decrypt_data($card['card_number_enc']))?>" style="color: transparent;width: 20px" data-booster-processed="true">
                                                        </div>
                                                        <h2 class="text-right font-bold"><?=$cardNumber?></h2>
                                                    </div>
                                                    <div class="user-dashboard-installation-single-meta">
                                                        <ul>
                                                            <?php
                                                            if (empty($card['phone'])){
                                                            ?>
                                                            <li class="nwp-tooltip-area nwp-tooltip-area-bottom flex">
                                                                <i class="icon-user"></i>
                                                                <span>دارنده کارت:  <?= $user->first_name . ' ' . $user->last_name ?></span>
                                                            </li>
                                                                <?php
                                                            }else{?>
                                                                <li class="nwp-tooltip-area nwp-tooltip-area-bottom flex">
                                                                    <i class="icon-user"></i>
                                                                    <span>دارنده کارت:  <?= $card['first_name'] . ' ' . $card['last_name'] ?></span>
                                                                </li>
                                                            <?php }
                                                            ?>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                            <?php
                                            }
                                            }else{?>
                                            <div class="user-dashboard-search-not-found">
                                                <img src="<?=get_template_directory_uri() . '/assets/img/svg/data-empty.svg'?>">
                                                <h3>اطلاعیه ای پیدا نشد!</h3>
                                                <p>شما در این مدت  اطلاعیه ای ندارید.</p>
                                            </div>
                                            <?php
                                            }
                                            ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </section>
</main>
