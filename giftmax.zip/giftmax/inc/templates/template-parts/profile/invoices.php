<?php

use Giftmax\model\UserModel;

$current_user = wp_get_current_user();
$user_id = $current_user->ID;
$first_name = $current_user->first_name;
$order_id = get_query_var('order_id');
$order = wc_get_order($order_id);

if (!$order) {
    echo '<p>سفارشی پیدا نشد!</p>';
    return;
}
$user_id    = $order->get_customer_id();
$user       = get_userdata($user_id);

$recoords_Vip = \Giftmax\model\SiteModel::table("user_identity","user_id",$user_id);
if (is_array($recoords_Vip) && $recoords_Vip['account_type'] == 'vip'){
    $vip = 1;
}else{
    $vip = 0;
}
if ($order->get_status() !== 'card-not-verified'){

$first_name = $user->first_name;
$last_name  = $user->last_name;
$user_login = $user->user_login;

$order_number  = $order->get_order_number();
$order_date    = $order->get_date_created() ? $order->get_date_created()->date('Y/m/d') : '';
$order_status  = wc_get_order_status_name($order->get_status());

$gateway       = $order->get_payment_method_title() ?: $order->get_payment_method();
$card_number   = $order->get_meta('_card_pay');
$buyer_ip       = $order->get_meta('_buyer_ip');
$u    = \Giftmax\model\SiteModel::table('user_identity', 'user_id', $user_id);
$gateway_id     = $order->get_payment_method();

$items = $order->get_items();
$db = \Giftmax\modules\Db::getLnstance();
global $wpdb;
$National_card__img = $db->first("SELECT * FROM {$wpdb->prefix}documents WHERE user_id = :user_id AND doc_type = 'National_card__img' AND accepted=2 ",array('user_id' => $user_id));
    $birth_certificate = $db->first("SELECT * FROM {$wpdb->prefix}documents WHERE user_id = :user_id AND doc_type = 'Birth_certificate' AND accepted=2 ",array('user_id' => $user_id));
$active_profile_tab = 'orders';
?>
    <svg style="display: none"><symbol id="delete" version="1.1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><title>delete</title><path d="M17 8h2v11c0 1.657-1.343 3-3 3h-8c-1.657 0-3-1.343-3-3v-11h2v11c0 0.552 0.448 1 1 1h8c0.552 0 1-0.448 1-1v-11zM4 7v-2h16v2h-16zM9 8h2v10h-2v-10zM13 8h2v10h-2v-10zM8 4v-2h8v2h-8z"></path></symbol><symbol id="add" version="1.1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><title>add</title><path d="M13 11h4v2h-4v4h-2v-4h-4v-2h4v-4h2v4zM12 22c-5.523 0-10-4.477-10-10s4.477-10 10-10c5.523 0 10 4.477 10 10s-4.477 10-10 10zM12 20c4.418 0 8-3.582 8-8s-3.582-8-8-8c-4.418 0-8 3.582-8 8s3.582 8 8 8z"></path></symbol></svg>
<main class="account-page">
    <section class="account-hero">
        <div class="container">
            <nav aria-label="مسیر دسترسی" class="breadcrumbs">
                <ol>
                    <li><a href="<?php echo site_url(); ?>">خانه</a></li>
                    <li aria-current="page">حساب کاربری</li>
                </ol>
            </nav>
        </div>
    </section>
    <section class="account-shell">
        <div class="container account-shell__layout">
            <aside class="account-sidebar" aria-label="منوی حساب کاربری">
                <div class="account-sidebar__card">
                    <div class="pb-28">
                        <div class="account-sidebar__header">
                            <div class="text-secondary font-bold tracking-tighter text-normal leading-xs grow"><?=$current_user->first_name . ' ' . $current_user->last_name?></div>
                            <?php
                            if (is_user_blocked()){
                                ?>
                                <div class="c-badge relative -top-2 text-2xs rounded-pill font-normal px-14">کاربر <span class="font-medium">مسدود </span></div>
                                <?php
                            }else{
                                ?>
                                <div class="c-badge relative -top-2 text-2xs rounded-pill font-normal px-14">کاربر <span class="font-medium"><?=$vip ?'ویژه': 'عادی'; ?></span></div>
                                <?php
                            }
                            ?>
                        </div>
                        <a class="alert alert-primary bg-primary bg-opacity-20 font-normal alert-sm flex items-start px-14 lg:px-16 mt-12" href="<?= esc_url( home_url( get_current_section_base() . '/wallet' ) ) ?>"><i class="icon-star pt-2 text-[#D19411] text-xs ml-8"></i><div class="grow">شما <strong class="font-bold"><?=number_format(UserModel::points())?> امتیاز</strong> دارید</div></a>
                    </div>
                    <?php
                    if (!empty($National_card__img) || !empty($birth_certificate)) {
                        $p = "100";
                    }elseif(is_array($recoords_Vip) && !$recoords_Vip['is_verified']){
                        $p = "30";
                    }else{
                        $p = "80";
                    }
                    if (!$vip){
                        ?>
                        <div class="account-progress">
                            <div class="account-progress__label">
                                <span>درصد تکمیل پروفایل</span>
                                <span><?=$p?>٪</span>
                            </div>
                            <div class="progress-bar">
                                <span style="width: <?=$p?>%"></span>
                            </div>
                            <?php
                            if($p != 100){
                                ?>
                                <button onclick="window.location.href='<?= esc_url( home_url( get_current_section_base() . '/verification' ) ) ?>'" type="button" class="btn btn--outline btn--block" data-panel-trigger="settings">تکمیل اطلاعات</button>
                                <?php
                            }
                            ?>
                        </div>
                        <?php
                    }
                    ?>
                    <a class="flex items-center py-16 leading-2 tracking-tight px-28 text-dark border-y border-gray border-opacity-[0.22] border-dashed relative before:absolute before:rounded-l before:transition-opacity before:w-4 before:bg-blue before:right-0 before:inset-y-16 before:opacity-0" href="<?= esc_url( home_url( get_current_section_base() . '/wallet' ) ) ?>"><div class="grow"><span class="font-medium text-xs block text-dark">موجودی کیف&zwnj;پول</span><div class="text-larger font-bold text-blue-dark tracking-tighter leading-1 pb-2 mt-3"><span class="text-gray"><?=number_format(UserModel::wallet()) != 0 ? number_format(UserModel::wallet()) : '-'?> تومان</span></div></div><div class="flex w-48 h-48 rounded-lg bg-blue-dark bg-opacity-10 items-center justify-center"><svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" class="w-22 h-22 fill-blue-dark"><path opacity="0.4" d="M18.04 13.55C17.62 13.96 17.38 14.55 17.44 15.18C17.53 16.26 18.52 17.05 19.6 17.05H21.5V18.24C21.5 20.31 19.81 22 17.74 22H6.26C4.19 22 2.5 20.31 2.5 18.24V11.51C2.5 9.44001 4.19 7.75 6.26 7.75H17.74C19.81 7.75 21.5 9.44001 21.5 11.51V12.95H19.48C18.92 12.95 18.41 13.17 18.04 13.55Z"></path><path d="M14.85 3.95V7.74999H6.26C4.19 7.74999 2.5 9.44 2.5 11.51V7.84002C2.5 6.65002 3.23 5.58997 4.34 5.16997L12.28 2.16997C13.52 1.70997 14.85 2.62 14.85 3.95Z"></path><path d="M22.56 13.9699V16.03C22.56 16.58 22.12 17.0299 21.56 17.0499H19.6C18.52 17.0499 17.53 16.2599 17.44 15.1799C17.38 14.5499 17.62 13.9599 18.04 13.5499C18.41 13.1699 18.92 12.95 19.48 12.95H21.56C22.12 12.97 22.56 13.4199 22.56 13.9699Z"></path><path d="M14 12.75H7C6.59 12.75 6.25 12.41 6.25 12C6.25 11.59 6.59 11.25 7 11.25H14C14.41 11.25 14.75 11.59 14.75 12C14.75 12.41 14.41 12.75 14 12.75Z"></path></svg></div></a>
                </div>

                <nav class="account-nav" role="tablist">

                    <a href="<?= esc_url( home_url( get_current_section_base() ) ) ?>"
                       class="account-nav__item <?= $active_profile_tab === '' ? 'active' : '' ?>"
                       role="tab">
                        <span class="icon icon-menu2"></span>
                        داشبورد
                    </a>

                    <a href="<?= esc_url( home_url( get_current_section_base() . '/orders' ) ) ?>"
                       class="account-nav__item <?= $active_profile_tab === 'orders' ? 'active' : '' ?>"
                       role="tab">
                        <span class="icon icon-order"></span>
                        سفارش‌های من
                    </a>
                    <a href="<?= esc_url( home_url( get_current_section_base() . '/list' ) ) ?>"
                       class="account-nav__item list-interest <?= $active_profile_tab === 'list' ? 'active' : '' ?>" role="tab">
                        <svg viewBox="0 0 24 24">
                            <path d="M12.62 20.81C12.28 20.93 11.72 20.93 11.38 20.81C8.48 19.82 2 15.69 2 8.68998C2 5.59998 4.49 3.09998 7.56 3.09998C9.38 3.09998 10.99 3.97998 12 5.33998C13.01 3.97998 14.63 3.09998 16.44 3.09998C19.51 3.09998 22 5.59998 22 8.68998C22 15.69 15.52 19.82 12.62 20.81Z" fill="none" stroke="inherit" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                        </svg>
                        لیست علاقه مندی
                    </a>
                    <a href="<?= esc_url( home_url( get_current_section_base() . '/deliveries' ) ) ?>"
                       class="account-nav__item <?= $active_profile_tab === 'deliveries' ? 'active' : '' ?>"
                       role="tab">
                        <span class="icon icon-flash"></span>
                        کدهای تحویل‌شده
                    </a>
                    <a href="<?= esc_url( home_url( get_current_section_base() . '/post' ) ) ?>"
                       class="account-nav__item <?= $active_profile_tab === 'post' ? 'active' : '' ?>"
                       role="tab">
                        <span class="icon icon-document"></span>
                        ارسال مقاله
                    </a>
                    <a href="<?= esc_url( home_url( get_current_section_base() . '/wallet' ) ) ?>"
                       class="account-nav__item <?= $active_profile_tab === 'wallet' ? 'active' : '' ?>"
                       role="tab">
                        <span class="icon icon-wallet"></span>
                        کیف پول و امتیاز
                    </a>
                    <?php
                    if (!$vip){
                        ?>
                        <a href="<?= esc_url( home_url( get_current_section_base() . '/verification' ) ) ?>"
                           class="account-nav__item <?= $active_profile_tab === 'verification' ? 'active' : '' ?>"
                           role="tab">
                            <span class="icon icon-verify"></span>
                            احراز هویت
                        </a>
                        <?php
                    }
                    ?>
                    <a href="<?= esc_url( home_url( get_current_section_base() . '/coupons' ) ) ?>"
                       class="account-nav__item <?= $active_profile_tab === 'coupons' ? 'active' : '' ?>"
                       role="tab">
                        <span class="icon icon-gift"></span>
                        کد های تخفیف
                    </a>
                    <a href="<?= esc_url( home_url( get_current_section_base() . '/cards' ) ) ?>"
                       class="account-nav__item <?= $active_profile_tab === 'cards' ? 'active' : '' ?>"
                       role="tab">
                        <span class="icon icon-card"></span>
                        کارت های بانکی
                    </a>
                    <a href="<?= esc_url( home_url( get_current_section_base() . '/user' ) ) ?>"
                       class="account-nav__item <?= $active_profile_tab === 'user' ? 'active' : '' ?>"
                       role="tab">
                        <span class="icon icon-user-o"></span>
                        تنظیمات حساب کاربری
                    </a>
                </nav>
            </aside>

            <div class="account-content">

                <div class="account-panel active" id="panel-wallet" data-panel="wallet" role="tabpanel" aria-hidden="false" tabindex="0">
                    <div class="account-panel__section">
                        <div class="invoice">
                            <section class="v10-3-6-ArSection invoice__sequenceNumber"><!---->
                                <div class="v10-3-6-ArSection__section v10-3-6-ArSection__section--content">
                                    <div class="InvoiceInfoBox">
                                        <div class="InvoiceInfoBox__iconBox">
                                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path fill-rule="evenodd" clip-rule="evenodd" d="M7 21H17C18.6569 21 20 19.6569 20 18V8.37167C20 7.57602 19.6839 6.81296 19.1213 6.25035L16.7497 3.87868C16.187 3.31607 15.424 3 14.6283 3H7C5.34315 3 4 4.34315 4 6V18C4 19.6569 5.34315 21 7 21Z" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"></path>
                                                <path d="M20 8.5H16.5C15.3954 8.5 14.5 7.60457 14.5 6.5V3" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"></path>
                                            </svg>
                                        </div>
                                        <div class="InvoiceInfoBox__content">
                                            <div class="InvoiceInfoBox__title"><span><?=$order_number?></span></div>
                                            <div class="InvoiceInfoBox__description">شماره فاکتور</div>
                                        </div>
                                    </div>
                                </div>
                            </section>
                            <section class="v10-3-6-ArSection invoice__issuedAt"><!---->
                                <div class="v10-3-6-ArSection__section v10-3-6-ArSection__section--content">
                                    <div class="InvoiceInfoBox">
                                        <div class="InvoiceInfoBox__iconBox">
                                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                                 xmlns="http://www.w3.org/2000/svg">
                                                <path d="M16 2V6" stroke="currentColor" stroke-width="1.8"
                                                      stroke-linecap="round" stroke-linejoin="round"></path>
                                                <path d="M8 2V6" stroke="currentColor" stroke-width="1.8"
                                                      stroke-linecap="round" stroke-linejoin="round"></path>
                                                <path d="M3 9H21" stroke="currentColor" stroke-width="1.8"
                                                      stroke-linecap="round" stroke-linejoin="round"></path>
                                                <path fill-rule="evenodd" clip-rule="evenodd"
                                                      d="M19 4H5C3.895 4 3 4.895 3 6V19C3 20.105 3.895 21 5 21H19C20.105 21 21 20.105 21 19V6C21 4.895 20.105 4 19 4Z"
                                                      stroke="currentColor" stroke-width="1.8" stroke-linecap="round"
                                                      stroke-linejoin="round"></path>
                                            </svg>
                                        </div>
                                        <div class="InvoiceInfoBox__content">
                                            <div class="InvoiceInfoBox__title"><span><?=gjdate($order_date,"d M Y")?></span></div>
                                            <div class="InvoiceInfoBox__description">تاریخ صدور</div>
                                        </div>
                                    </div>
                                </div>
                            </section>
                            <section class="v10-3-6-ArSection invoice__status"><!---->
                                <div class="v10-3-6-ArSection__section v10-3-6-ArSection__section--content">
                                    <div class="InvoiceInfoBox">
                                        <div class="InvoiceInfoBox__iconBox">
                                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                                 xmlns="http://www.w3.org/2000/svg"
                                                 class="invoice__status-icon invoice__status-icon--issued">
                                                <path fill-rule="evenodd" clip-rule="evenodd"
                                                      d="M12 21V21C7.029 21 3 16.971 3 12V12C3 7.029 7.029 3 12 3V3C16.971 3 21 7.029 21 12V12C21 16.971 16.971 21 12 21Z"
                                                      stroke="currentColor" stroke-width="1.8" stroke-linecap="round"
                                                      stroke-linejoin="round"></path>
                                                <path d="M12 17V12H11" stroke="currentColor" stroke-width="1.8"
                                                      stroke-linecap="round" stroke-linejoin="round"></path>
                                                <path d="M11.749 8C11.611 8 11.499 8.112 11.5 8.25C11.5 8.388 11.612 8.5 11.75 8.5C11.888 8.5 12 8.388 12 8.25C12 8.112 11.888 8 11.749 8"
                                                      stroke="currentColor" stroke-width="1.8" stroke-linecap="round"
                                                      stroke-linejoin="round"></path>
                                            </svg>
                                        </div>
                                        <div class="InvoiceInfoBox__content">
                                            <div class="InvoiceInfoBox__title"><span><?=$order_status?></span></div>
                                            <div class="InvoiceInfoBox__description">وضعیت</div>
                                        </div>
                                    </div>
                                </div>
                            </section>
                            <section class="v10-3-6-ArSection invoice__customer-info">
                                <div class="v10-3-6-ArSection__section v10-3-6-ArSection__section--div">
                                    <div><h6 class="v10-3-6-ArSection__title">مشخصات خرید</h6></div>
                                </div>
                                <div class="v10-3-6-ArSection__section v10-3-6-ArSection__section--content">
                                    <div class="InvoiceCustomerInfo">
                                        <div class="InvoiceCustomerInfo__item">
                                            <span class="InvoiceCustomerInfo__label">نام</span>
                                            <span class="InvoiceCustomerInfo__value"><?="$first_name $last_name"?></span>
                                        </div>
                                        <div class="<?=isMobile() ? 'InvoiceCustomerInfo__divider InvoiceCustomerInfo__divider--h' : 'InvoiceCustomerInfo__divider InvoiceCustomerInfo__divider--v'?>"></div>
                                        <div class="InvoiceCustomerInfo__item">
                                            <span class="InvoiceCustomerInfo__label">شناسه ملی</span>
                                            <span class="InvoiceCustomerInfo__value"><span><?=!empty($u['national_id_enc']) ? decrypt_data($u['national_id_enc']) : ''?></span></span>
                                        </div>
                                        <div class="InvoiceCustomerInfo__divider InvoiceCustomerInfo__divider--v"></div>
                                        <?php if (isset($u['account_type']) && $u['account_type'] == 'normal') {?>
                                            <div class="InvoiceCustomerInfo__item">
                                                <span class="InvoiceCustomerInfo__label">شماره کارت</span>
                                                <span class="InvoiceCustomerInfo__value"><span><?=!empty($card_number) ?$card_number : ''?></span></span>
                                            </div>
                                            <div class="InvoiceCustomerInfo__divider InvoiceCustomerInfo__divider--h"></div>
                                        <?php } ?>

                                        <div class="InvoiceCustomerInfo__item">
                                            <span class="InvoiceCustomerInfo__label">ای پی</span>
                                            <span class="InvoiceCustomerInfo__value"><span><?=!empty($buyer_ip) ? $buyer_ip : ''?></span></span>
                                        </div>
                                        <?php if (isset($u['account_type']) && $u['account_type'] == 'vip') {?>
                                            <div class="InvoiceCustomerInfo__divider InvoiceCustomerInfo__divider--h"></div>
                                            <?php
                                        }else{?>
                                            <div class="InvoiceCustomerInfo__divider InvoiceCustomerInfo__divider--v"></div>
                                        <?php } ?>
                                        <div class="InvoiceCustomerInfo__item">
                                            <span class="InvoiceCustomerInfo__label">شماره تلفن</span>
                                            <span class="InvoiceCustomerInfo__value"><bdi><?=$user_login?></bdi></span>
                                        </div>
                                        <div class="InvoiceCustomerInfo__divider InvoiceCustomerInfo__divider--v"></div>
                                        <div class="InvoiceCustomerInfo__item">
                                            <span class="InvoiceCustomerInfo__label">درگاه پرداخت</span>
                                            <?php
                                            $use_wallet = $order->get_meta( '_use_wallet', true );
                                            $gateway = '';
                                            if ($order->get_total() == 0){
                                                if ($use_wallet){
                                                    $gateway = 'wallet';
                                                }else{
                                                    $gateway = 'system';
                                                }
                                            }elseif ($use_wallet){
                                                $gateway = $gateway_id . ' + wallet';
                                            }else{
                                                $gateway = $gateway_id;
                                            }
                                            ?>
                                            <span class="InvoiceCustomerInfo__value"><bdi><?=$gateway?></bdi></span>
                                        </div>
                                        <div class="InvoiceCustomerInfo__divider InvoiceCustomerInfo__divider--v"></div>
                                        <div class="InvoiceCustomerInfo__item">
                                            <span class="InvoiceCustomerInfo__label">نوع فروش</span>
                                            <span class="InvoiceCustomerInfo__value"><bdi>خرد</bdi></span>
                                        </div>
                                    </div>
                                </div>
                            </section>
                            <section class="v10-3-6-ArSection invoice__items">
                                <div class="v10-3-6-ArSection__section v10-3-6-ArSection__section--content">
                                    <div class="v10-3-6-ArTable">
                                        <div class="v10-3-6-ArTable__tableWrapper">
                                            <table class="v10-3-6-ArTable__table">
                                                <thead>
                                                <tr class="v10-3-6-ArTableRow v10-3-6-ArTableRow--div">
                                                    <th class="v10-3-6-ArTableCell v10-3-6-ArTableCell--start v10-3-6-ArTableCell--div">محصول</th>
                                                    <th class="v10-3-6-ArTableCell v10-3-6-ArTableCell--start v10-3-6-ArTableCell--div">تحویل</th>
                                                    <th class="v10-3-6-ArTableCell v10-3-6-ArTableCell--start v10-3-6-ArTableCell--div">منطقهٔ قابل‌استفاده</th>
                                                    <th class="v10-3-6-ArTableCell v10-3-6-ArTableCell--start v10-3-6-ArTableCell--div"> قیمت واحد</th>
                                                    <th class="v10-3-6-ArTableCell v10-3-6-ArTableCell--start v10-3-6-ArTableCell--div"> تعداد </th>
                                                    <th class="v10-3-6-ArTableCell v10-3-6-ArTableCell--start v10-3-6-ArTableCell--div"> تخفیف </th>
                                                    <th class="v10-3-6-ArTableCell v10-3-6-ArTableCell--start v10-3-6-ArTableCell--div"> قیمت کل </th>
                                                </tr>
                                                </thead>
                                                <tbody>
                                                <?php foreach ($items as $item){
                                                $product_name = $item->get_name();
                                                $product      = $item->get_product(); // شیء محصول
                                                $quantity     = $item->get_quantity();
                                                $delivery   = get_post_meta( $product->get_id(), 'delivery', true );
                                                $settings = get_post_meta($product->get_id(), 'giftmax_box_setting', true);
                                                $regular_price = $product ? (float) $product->get_regular_price() : 0;
                                                $price_original_total = $regular_price * $quantity;
                                                $price_final_total = $item['line_total'];
                                                $discount_amount = $price_original_total - $price_final_total;
                                                $licenses = $item->get_meta('_reserved_licence_ids');
                                                ?>
                                                <tr class="v10-3-6-ArTableRow v10-3-6-ArTableRow--body v10-3-6-ArTableRow--striped">
                                                    <td class="v10-3-6-ArTableCell v10-3-6-ArTableCell--start v10-3-6-ArTableCell--body">
                                                        <?=$product_name?>
                                                    </td>
                                                    <td class="v10-3-6-ArTableCell v10-3-6-ArTableCell--start v10-3-6-ArTableCell--body">
                                                        <?php
                                                        if ( isset( $delivery['two'] ) && $delivery['two'] === 'on') {
                                                            $delivery_time = isset($delivery['time']) ? absint($delivery['time']) : 0;
                                                            $ctt = $order->get_date_created()
                                                                ? (clone $order->get_date_created())
                                                                    ->modify( '+'.$delivery_time.' hour' )
                                                                    ->date( 'Y/m/d H:i' )
                                                                : $delivery_time;
                                                            if ($order && $order->get_date_created()) {
                                                                $created = clone $order->get_date_created();
                                                                $deadline = clone $created;
                                                                $deadline->modify('+' . $delivery_time . ' hour');
                                                                $now = new DateTime('now', $created->getTimezone());
                                                                if ($now < $deadline) {
                                                                    $remaining_seconds = $deadline->getTimestamp() - $now->getTimestamp();
                                                                    $total_seconds = $delivery_time * 3600;
                                                                    if ($total_seconds > 0) {
                                                                        $progress_percent = (($total_seconds - $remaining_seconds) / $total_seconds) * 100;
                                                                    } else {
                                                                        $progress_percent = 0;
                                                                    }
                                                                    $formatted_percent = number_format($progress_percent, 2);?>
                                                                    <div class="table-td-inner">
                                                                        <div class="flex justify-between align-items-center">
                                                                            <span class="text-neutral-500 text-caption line-height-1">تحویل با تاخیر</span>
                                                                            <div class="text-primary-700 text-body2-strong style_ProductPromotionTimeline__timer__zS6ZA1 line-height-1"><?=$ctt?></div>
                                                                        </div>
                                                                    </div>
                                                                    <?php
                                                                }
                                                                else{
                                                                    echo "پیش فروش";
                                                                }
                                                            }else{
                                                                echo "پیش فروش";
                                                            }
                                                        }else{
                                                            echo "آنی";
                                                        }
                                                        ?>
                                                    </td>
                                                    <td class="v10-3-6-ArTableCell v10-3-6-ArTableCell--start v10-3-6-ArTableCell--body flex">
                                                        <?=!empty($settings[0]['logo_region']) ? regionPersian($settings[0]['logo_region']) . "<img width='15' class='mr-2' src='". get_template_directory_uri()."/assets/flag/" .$settings[0]['logo_region'] .".svg'>" : '-'?>
                                                    </td>
                                                    <td class="v10-3-6-ArTableCell v10-3-6-ArTableCell--start v10-3-6-ArTableCell--body">
                                                        <?=number_format_usd($regular_price)?>
                                                    </td>
                                                    <td class="v10-3-6-ArTableCell v10-3-6-ArTableCell--start v10-3-6-ArTableCell--body">
                                                        <?=number_format($quantity)?>
                                                    </td>
                                                    <td class="v10-3-6-ArTableCell v10-3-6-ArTableCell--start v10-3-6-ArTableCell--body">
                                                        <?=number_format_usd($discount_amount)?>
                                                    </td>
                                                    <td class="v10-3-6-ArTableCell v10-3-6-ArTableCell--start v10-3-6-ArTableCell--body">
                                                        <?=number_format_usd($price_final_total)?>
                                                    </td>
                                                </tr>
                                                <?php
                                                if ($order->get_status() !== 'card-not-verified' && $order->get_status() === 'completed'){
                                                ?>
                                                <tr class="v10-3-6-ArTableRow--body license-extra-row">
                                                    <td colspan="7" style="padding: 16px 20px;">
                                                        <?php
                                                    if ( isset( $delivery['two'] ) && $delivery['two'] === 'on' && empty($licenses)) {
                                                        echo "باتوجه به اینکه این محصول را شما بصورت پیش فروش خریداری نموده اید بمحض موجودی محصول تا اتمام زمان باقیمانده تحویل در همین بخش موجود و قابل مشاهده خواهد بود";
                                                    }elseif($licenses && !empty($licenses) && is_string($licenses)){
                                                        $licenses = json_decode($licenses, true);
                                                        ?>
                                                        <div class="licenses-header">
                                                            <span> کدهای لایسنس این محصول</span>
                                                        </div>

                                                        <div class="V10-3-6-licence_box">
                                                            <?php
                                                            foreach ($licenses as $license_code) {
                                                                $licence_code = \Giftmax\modules\LicenseManager::ShowLicense($license_code,$order_id);
                                                                if (empty($licence_code)){
                                                                    continue;
                                                                }
                                                                ?>
                                                                <div class="V10-3-6-licence_code">
                                                                    <button type="button" class="select-text copy-code-btn flex w-full bg-white border-b border-gray-300 last:border-b-0 rounded-0">
                                                                        <span class="self-center grow tracking-none text-left pt-2 font-normal pl-6 whitespace-pre-wrap break-words"><?=decrypt_data($licence_code['licence_code'])?></span>
                                                                        <i class="w-28 h-28 shrink-0 rounded-sm"></i>
                                                                    </button>
                                                                </div>

                                                                <?php
                                                            }
                                                            ?>
                                                        </div>
                                                        <?php
                                                    }
                                                        ?>
                                                    </td>
                                                </tr>
                                                    <?php
                                                    }
                                                    }
                                                    ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </section>
                            <section class="v10-3-6-ArSection invoice__summary">
                                <div class="v10-3-6-ArSection__section v10-3-6-ArSection__section--content d-flex xs:flex-col">
                                    <div class="md:w-60 w-full">
                                        <div class="v10-3-6-ArTable">
                                            <h4 style="margin-bottom: 10px">نکات مهم:</h4>
                                            <ul class="V10-3-6-ArUl">
                                                <li>هرگونه عودت وجه طبق مقرارت سایت و قوانین صنفی با کسر 10% مبلغ ارزش افزوده طی 24 ساعت کاری به همان شماره کارت خرید اناک گرفته از سایت انجام خواهد شد.</li>
                                                <li>هرگونه مغایرت کارت بانکی و عدم تایید احراز هویت بعد از ثثبت سفارش تنها از طریق مراجع قانونی و تایید احراز هویت مالکیت حساب طی فرایند 48 الی 72 ساعته انجام خواهد شد</li>
                                                <li>تمامی گیفت کارت های موجود در سایت اعم از تحویل آنی و پیش فروش 100% قانونی بوده و پیشنهاد میگردد بلافاصله بعد از ثبت سفارش اقدام به ریدیم کد خریداری شده انجام گیرد چنانچه کد خریداری شده استفاده نگردد و سپس بعد از 24 ساعت استفاده و مشکلی ایجاد گردد هیچ گونه عذری قابل پذیرش نمیباشد.</li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="md:w-40 w-full V10-3-6-Summary">
                                        <div class="v10-3-6-ArSection__section v10-3-6-ArSection__section--div">
                                            <div><h6 class="v10-3-6-ArSection__title">جمع صورت‌حساب</h6></div>
                                        </div>
                                        <div class="v10-3-6-ArTable">
                                            <?php
                                            $cart_product_discount = 0;
                                            foreach ( $items as $item) {
                                                $product = $item->get_product();
                                                $qty     = (float)$item->get_quantity();
                                                $regular_price = (float) $product->get_regular_price();
                                                $line_total    = (float)$item['line_total'];

                                                $cart_product_discount += ($regular_price * $qty) - $line_total;
                                            }

                                            $gateway = $order->get_payment_method();
                                            if ( $gateway === 'payment4' ) {
                                                $currency = 'USD';
                                                $subtotal = $order->get_subtotal() + $cart_product_discount;
                                                $total_discount =  $cart_product_discount;
                                            } else {
                                                $currency = "IRR";
                                                $subtotal = number_format_usd($order->get_subtotal() + $cart_product_discount);
                                                $total_discount = number_format_usd($cart_product_discount);
                                            }
                                            $amount = $order->get_total();
                                            $coupon = $order->get_meta( '_rial_coupon');
                                            ?>
                                            <div class="InvoiceCustomerInfo">
                                                <div class="InvoiceCustomerInfo__item">
                                                    <span class="InvoiceCustomerInfo__label">مجموع مبالغ فاکتور</span>
                                                    <span class="InvoiceCustomerInfo__value"><?=gm_wc_price( $subtotal,  $currency,false)?></span>
                                                </div>
                                                <div class="InvoiceCustomerInfo__divider InvoiceCustomerInfo__divider--h"></div>
                                                <div class="InvoiceCustomerInfo__item">
                                                    <span class="InvoiceCustomerInfo__label">جمع تخفیف</span>
                                                    <span class="InvoiceCustomerInfo__value"><bdi><?=gm_wc_price( $total_discount,$currency,false)?></bdi></span>
                                                </div>
                                                <div class="InvoiceCustomerInfo__divider InvoiceCustomerInfo__divider--v"></div>
                                                <div class="InvoiceCustomerInfo__item">
                                                    <span class="InvoiceCustomerInfo__label">مبلغ نهایی</span>
                                                    <span class="InvoiceCustomerInfo__value"><bdi><?=gm_wc_price( $amount,$currency )?></bdi></span>
                                                </div>
                                                <div class="InvoiceCustomerInfo__divider InvoiceCustomerInfo__divider--h"></div>
                                                <div class="InvoiceCustomerInfo__item">
                                                    <span class="InvoiceCustomerInfo__label">کد تخفیف</span>
                                                    <span class="InvoiceCustomerInfo__value"><bdi><?=!empty($coupon) ?$coupon : '-'?></bdi></span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </section>
                            <?php
                            if ($order->get_status() === 'completed'){
                                ?>
                                <button class="Button-sto10" data-id="<?=$order_id?>" data-hash="<?=encrypt_data("$order_id|order")?>">
                                    <span class="d-flex ai-center jc-center relative grow-1">ثبت درخواست پشتیبانی</span>
                                </button>
                                <?php
                            }
                            ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</main>
<?php
}else{
    header("Location:".home_url("/profile"));
}
