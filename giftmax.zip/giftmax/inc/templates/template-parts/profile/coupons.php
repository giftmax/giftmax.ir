<?php
use Giftmax\Modules\UserModel;

$current_user = wp_get_current_user();
$user_id = $current_user->ID;
$first_name = $current_user->first_name;

$recoords_Vip = UserModel::table("user_identity","user_id",$user_id);
if (is_array($recoords_Vip) && $recoords_Vip['account_type'] == 'vip'){
    $vip = 1;
}else{
    $vip = 0;
}
$db = \Giftmax\Modules\Db::getLnstance();
global $wpdb;
$National_card__img = $db->first("SELECT * FROM {$wpdb->prefix}documents WHERE user_id = :user_id AND doc_type = 'National_card__img' AND accepted=2 ",array('user_id' => $user_id));
$birth_certificate = $db->first("SELECT * FROM {$wpdb->prefix}documents WHERE user_id = :user_id AND doc_type = 'Birth_certificate' AND accepted=2 ",array('user_id' => $user_id));
$active_profile_tab = sanitize_key((string) get_query_var('profile_tab'));

?>
<main class="account-page">
    <section class="account-hero">
        <div class="container">
            <nav aria-label="مسیر دسترسی" class="breadcrumbs">
                <ol>
                    <li><a href="<?php echo site_url(); ?>">خانه</a></li>
                    <li aria-current="page">حساب کاربری</li>
                </ol>
            </nav>
        </div>
    </section>
    <section class="account-shell">
        <div class="container account-shell__layout">
            <aside class="account-sidebar" aria-label="منوی حساب کاربری">
                <div class="account-sidebar__card">
                    <div class="pb-28">
                        <div class="account-sidebar__header">
                            <div class="text-secondary font-bold tracking-tighter text-normal leading-xs grow"><?=$current_user->first_name . ' ' . $current_user->last_name?></div>
                            <?php
                            if (is_user_blocked()){
                                ?>
                                <div class="c-badge relative -top-2 text-2xs rounded-pill font-normal px-14">کاربر <span class="font-medium">مسدود </span></div>
                                <?php
                            }else{
                                ?>
                                <div class="c-badge relative -top-2 text-2xs rounded-pill font-normal px-14">کاربر <span class="font-medium"><?=$vip ?'ویژه': 'عادی'; ?></span></div>
                                <?php
                            }
                            ?>
                        </div>
                        <a class="alert alert-primary bg-primary bg-opacity-20 font-normal alert-sm flex items-start px-14 lg:px-16 mt-12" href="<?= esc_url( home_url( get_current_section_base() . '/wallet' ) ) ?>"><i class="icon-star pt-2 text-[#D19411] text-xs ml-8"></i><div class="grow">شما <strong class="font-bold"><?=number_format(UserModel::points())?> امتیاز</strong> دارید</div></a>
                    </div>
                    <?php
                    if (!empty($National_card__img) || !empty($birth_certificate)) {
                        $p = "100";
                    }elseif(is_array($recoords_Vip) && !$recoords_Vip['is_verified']){
                        $p = "30";
                    }else{
                        $p = "80";
                    }
                    if (!$vip){
                        ?>
                        <div class="account-progress">
                            <div class="account-progress__label">
                                <span>درصد تکمیل پروفایل</span>
                                <span><?=$p?>٪</span>
                            </div>
                            <div class="progress-bar">
                                <span style="width: <?=$p?>%"></span>
                            </div>
                            <?php
                            if($p != 100){
                                ?>
                                <button onclick="window.location.href='<?= esc_url( home_url( get_current_section_base() . '/verification' ) ) ?>'" type="button" class="btn btn--outline btn--block" data-panel-trigger="settings">تکمیل اطلاعات</button>
                                <?php
                            }
                            ?>
                        </div>
                        <?php
                    }
                    ?>
                    <a class="flex items-center py-16 leading-2 tracking-tight px-28 text-dark border-y border-gray border-opacity-[0.22] border-dashed relative before:absolute before:rounded-l before:transition-opacity before:w-4 before:bg-blue before:right-0 before:inset-y-16 before:opacity-0" href="<?= esc_url( home_url( get_current_section_base() . '/wallet' ) ) ?>"><div class="grow"><span class="font-medium text-xs block text-dark">موجودی کیف&zwnj;پول</span><div class="text-larger font-bold text-blue-dark tracking-tighter leading-1 pb-2 mt-3"><span class="text-gray"><?=number_format(UserModel::wallet()) != 0 ? number_format(UserModel::wallet()) : '-'?> تومان</span></div></div><div class="flex w-48 h-48 rounded-lg bg-blue-dark bg-opacity-10 items-center justify-center"><svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" class="w-22 h-22 fill-blue-dark"><path opacity="0.4" d="M18.04 13.55C17.62 13.96 17.38 14.55 17.44 15.18C17.53 16.26 18.52 17.05 19.6 17.05H21.5V18.24C21.5 20.31 19.81 22 17.74 22H6.26C4.19 22 2.5 20.31 2.5 18.24V11.51C2.5 9.44001 4.19 7.75 6.26 7.75H17.74C19.81 7.75 21.5 9.44001 21.5 11.51V12.95H19.48C18.92 12.95 18.41 13.17 18.04 13.55Z"></path><path d="M14.85 3.95V7.74999H6.26C4.19 7.74999 2.5 9.44 2.5 11.51V7.84002C2.5 6.65002 3.23 5.58997 4.34 5.16997L12.28 2.16997C13.52 1.70997 14.85 2.62 14.85 3.95Z"></path><path d="M22.56 13.9699V16.03C22.56 16.58 22.12 17.0299 21.56 17.0499H19.6C18.52 17.0499 17.53 16.2599 17.44 15.1799C17.38 14.5499 17.62 13.9599 18.04 13.5499C18.41 13.1699 18.92 12.95 19.48 12.95H21.56C22.12 12.97 22.56 13.4199 22.56 13.9699Z"></path><path d="M14 12.75H7C6.59 12.75 6.25 12.41 6.25 12C6.25 11.59 6.59 11.25 7 11.25H14C14.41 11.25 14.75 11.59 14.75 12C14.75 12.41 14.41 12.75 14 12.75Z"></path></svg></div></a>
                </div>

                <nav class="account-nav" role="tablist">

                    <a href="<?= esc_url( home_url( get_current_section_base() ) ) ?>"
                       class="account-nav__item <?= $active_profile_tab === '' ? 'active' : '' ?>"
                       role="tab">
                        <span class="icon icon-menu2"></span>
                        داشبورد
                    </a>

                    <a href="<?= esc_url( home_url( get_current_section_base() . '/orders' ) ) ?>"
                       class="account-nav__item <?= $active_profile_tab === 'orders' ? 'active' : '' ?>"
                       role="tab">
                        <span class="icon icon-order"></span>
                        سفارش‌های من
                    </a>
                    <a href="<?= esc_url( home_url( get_current_section_base() . '/list' ) ) ?>"
                       class="account-nav__item list-interest <?= $active_profile_tab === 'list' ? 'active' : '' ?>" role="tab">
                        <svg viewBox="0 0 24 24">
                            <path d="M12.62 20.81C12.28 20.93 11.72 20.93 11.38 20.81C8.48 19.82 2 15.69 2 8.68998C2 5.59998 4.49 3.09998 7.56 3.09998C9.38 3.09998 10.99 3.97998 12 5.33998C13.01 3.97998 14.63 3.09998 16.44 3.09998C19.51 3.09998 22 5.59998 22 8.68998C22 15.69 15.52 19.82 12.62 20.81Z" fill="none" stroke="inherit" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                        </svg>
                        لیست علاقه مندی
                    </a>
                    <a href="<?= esc_url( home_url( get_current_section_base() . '/deliveries' ) ) ?>"
                       class="account-nav__item <?= $active_profile_tab === 'deliveries' ? 'active' : '' ?>"
                       role="tab">
                        <span class="icon icon-flash"></span>
                        کدهای تحویل‌شده
                    </a>
                    <a href="<?= esc_url( home_url( get_current_section_base() . '/post' ) ) ?>"
                       class="account-nav__item <?= $active_profile_tab === 'post' ? 'active' : '' ?>"
                       role="tab">
                        <span class="icon icon-document"></span>
                        ارسال مقاله
                    </a>
                    <a href="<?= esc_url( home_url( get_current_section_base() . '/wallet' ) ) ?>"
                       class="account-nav__item <?= $active_profile_tab === 'wallet' ? 'active' : '' ?>"
                       role="tab">
                        <span class="icon icon-wallet"></span>
                        کیف پول و امتیاز
                    </a>
                    <?php
                    if (!$vip){
                        ?>
                        <a href="<?= esc_url( home_url( get_current_section_base() . '/verification' ) ) ?>"
                           class="account-nav__item <?= $active_profile_tab === 'verification' ? 'active' : '' ?>"
                           role="tab">
                            <span class="icon icon-verify"></span>
                            احراز هویت
                        </a>
                        <?php
                    }
                    ?>
                    <a href="<?= esc_url( home_url( get_current_section_base() . '/coupons' ) ) ?>"
                       class="account-nav__item <?= $active_profile_tab === 'coupons' ? 'active' : '' ?>"
                       role="tab">
                        <span class="icon icon-gift"></span>
                        کد های تخفیف
                    </a>
                    <a href="<?= esc_url( home_url( get_current_section_base() . '/cards' ) ) ?>"
                       class="account-nav__item <?= $active_profile_tab === 'cards' ? 'active' : '' ?>"
                       role="tab">
                        <span class="icon icon-card"></span>
                        کارت های بانکی
                    </a>
                    <a href="<?= esc_url( home_url( get_current_section_base() . '/user' ) ) ?>"
                       class="account-nav__item <?= $active_profile_tab === 'user' ? 'active' : '' ?>"
                       role="tab">
                        <span class="icon icon-user-o"></span>
                        تنظیمات حساب کاربری
                    </a>
                </nav>
            </aside>

            <div class="account-content">
                <div class="account-panel active" id="panel-coupons" role="tabpanel" aria-hidden="false" tabindex="0">
                    <div class="account-panel__section">
                        <div>
                            <h3>کد های تخفیف</h3>
                        </div>
                        <div class="data-card data-card__coupons">
                                    <table class="data-table data-table__coupons">
                                        <thead>
                                        <tr>
                                            <th>ردیف</th>
                                            <th>کد تخفیف</th>
                                            <th>محصول</th>
                                            <th>تعداد</th>
                                            <th>مقدار تخفیف</th>
                                            <th>تاریخ انقضا</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php
                                        $args = array(
                                            'post_type' => 'shop_coupon',
                                            'posts_per_page' => -1,
                                        );

                                        $coupons = new WP_Query($args);
                                        if ($coupons->have_posts()) {
                                        $count = $coupons->found_posts;

                                        foreach ($coupons->posts as $i => $coupon) {
                                            $coupon_obj = new WC_Coupon($coupon->ID);
                                            $products = $coupon_obj->get_product_ids();
                                            $discount_type = $coupon_obj->get_discount_type();
                                            $amount        = $coupon_obj->get_amount();

                                            switch ( $discount_type ) {

                                                case 'percent':
                                                    $discount_text = $amount . '٪';
                                                    break;

                                                case 'fixed_cart':
                                                    $discount_text = number_format_usd( $amount ) . "تومان";
                                                    break;

                                                case 'fixed_product':
                                                    $discount_text = number_format_usd( $amount ) . "تومان";
                                                    break;

                                                default:
                                                    $discount_text = 'نامشخص';
                                            }
                                            $expiry_date = $coupon_obj->get_date_expires();
                                            if ( $expiry_date ) {
                                                $expiry_formatted = $expiry_date->date_i18n('Y/m/d');
                                            } else {
                                                $expiry_formatted = 'بدون تاریخ انقضا';
                                            }

                                            if ($expiry_date && $expiry_date->getTimestamp() < current_time('timestamp')) {
                                                //continue;
                                            }
                                            $usage_limit = $coupon_obj->get_usage_limit();
                                            $usage_count = $coupon_obj->get_usage_count();
                                            if ( $usage_limit ) {
                                                $remaining = max( 0, $usage_limit - $usage_count );
                                            } else {
                                                $remaining = 'نامحدود';
                                            }

                                            ?>
                                        <tr>
                                            <td><?=$i+1?></td>
                                            <td>
                                                <div class="coupons">
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="19" viewBox="0 0 18 19" fill="none"><path d="M15 7.47754H8.25C7.42157 7.47754 6.75 8.14911 6.75 8.97754V15.7275C6.75 16.556 7.42157 17.2275 8.25 17.2275H15C15.8284 17.2275 16.5 16.556 16.5 15.7275V8.97754C16.5 8.14911 15.8284 7.47754 15 7.47754Z" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path><path d="M3.75 11.9775H3C2.60218 11.9775 2.22064 11.8195 1.93934 11.5382C1.65804 11.2569 1.5 10.8754 1.5 10.4775V3.72754C1.5 3.32971 1.65804 2.94818 1.93934 2.66688C2.22064 2.38557 2.60218 2.22754 3 2.22754H9.75C10.1478 2.22754 10.5294 2.38557 10.8107 2.66688C11.092 2.94818 11.25 3.32971 11.25 3.72754V4.47754" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path></svg>
                                                    <span style="line-height: 1"><?=$coupon_obj->get_code()?></span>
                                                </div>
                                            </td>
                                            <td>
                                                <?php
                                                $links = [];

                                                foreach ( $products as $product_id ) {
                                                    $product = wc_get_product( $product_id );

                                                    if ( ! $product ) {
                                                        continue;
                                                    }

                                                    $links[] = sprintf(
                                                        '<a href="%s" target="_blank">%s</a>',
                                                        esc_url( $product->get_permalink() ),
                                                        esc_html( $product->get_name() )
                                                    );
                                                }

                                                echo '<strong>' . implode(' | ', $links) . '</strong>';
                                                ?>
                                            </td>
                                            <td><?=$remaining?></td>
                                            <td><?=$discount_text?></td>
                                            <td><?=$expiry_formatted?></td>
                                        </tr>
                                        <?php
                                        }
                                        }else{?>
                                        <tr>
                                            <td colspan="6">کد تخفیفی وجود ندارد</td>
                                        </tr>
                                        <?php }
                                        ?>
                                        </tbody>
                                    </table>
                                </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</main>