<?php

use Giftmax\model\UserModel;


$current_user = wp_get_current_user();
$user_id = $current_user->ID;
$first_name = $current_user->first_name;
$recoords_Vip = \Giftmax\model\SiteModel::table("user_identity","user_id",$user_id);
if (is_array($recoords_Vip) && $recoords_Vip['account_type'] == 'vip'){
    $vip = 1;
}else{
    $vip = 0;
}
$db = \Giftmax\modules\Db::getLnstance();
global $wpdb;
$National_card__img = $db->first("SELECT * FROM {$wpdb->prefix}documents WHERE user_id = :user_id AND doc_type = 'National_card__img' AND accepted=2 ",array('user_id' => $user_id));
$birth_certificate = $db->first("SELECT * FROM {$wpdb->prefix}documents WHERE user_id = :user_id AND doc_type = 'Birth_certificate' AND accepted=2 ",array('user_id' => $user_id));
$active_profile_tab = sanitize_key((string) get_query_var('profile_tab'));
?>
<main class="account-page">
    <section class="account-hero">
        <div class="container">
            <nav aria-label="مسیر دسترسی" class="breadcrumbs">
                <ol>
                    <li><a href="<?php echo site_url(); ?>">خانه</a></li>
                    <li aria-current="page">حساب کاربری</li>
                </ol>
            </nav>
        </div>
    </section>
    <section class="account-shell">
        <div class="container account-shell__layout">
            <aside class="account-sidebar" aria-label="منوی حساب کاربری">
                <div class="account-sidebar__card">
                    <div class="pb-28">
                        <div class="account-sidebar__header">
                            <div class="text-secondary font-bold tracking-tighter text-normal leading-xs grow"><?=$current_user->first_name . ' ' . $current_user->last_name?></div>
                            <?php
                            if (is_user_blocked()){
                                ?>
                                <div class="c-badge relative -top-2 text-2xs rounded-pill font-normal px-14">کاربر <span class="font-medium">مسدود </span></div>
                                <?php
                            }else{
                                ?>
                                <div class="c-badge relative -top-2 text-2xs rounded-pill font-normal px-14">کاربر <span class="font-medium"><?=$vip ?'ویژه': 'عادی'; ?></span></div>
                                <?php
                            }
                            ?>
                        </div>
                        <a class="alert alert-primary bg-primary bg-opacity-20 font-normal alert-sm flex items-start px-14 lg:px-16 mt-12" href="<?= esc_url( home_url( get_current_section_base() . '/wallet' ) ) ?>"><i class="icon-star pt-2 text-[#D19411] text-xs ml-8"></i><div class="grow">شما <strong class="font-bold"><?=number_format(UserModel::points())?> امتیاز</strong> دارید</div></a>
                    </div>
                    <?php
                    if (!empty($National_card__img) || !empty($birth_certificate)) {
                        $p = "100";
                    }elseif(is_array($recoords_Vip) && !$recoords_Vip['is_verified']){
                        $p = "30";
                    }else{
                        $p = "80";
                    }
                    if (!$vip){
                        ?>
                        <div class="account-progress">
                            <div class="account-progress__label">
                                <span>درصد تکمیل پروفایل</span>
                                <span><?=$p?>٪</span>
                            </div>
                            <div class="progress-bar">
                                <span style="width: <?=$p?>%"></span>
                            </div>
                            <?php
                            if($p != 100){
                                ?>
                                <button onclick="window.location.href='<?= esc_url( home_url( get_current_section_base() . '/verification' ) ) ?>'" type="button" class="btn btn--outline btn--block" data-panel-trigger="settings">تکمیل اطلاعات</button>
                                <?php
                            }
                            ?>
                        </div>
                        <?php
                    }
                    ?>
                    <a class="flex items-center py-16 leading-2 tracking-tight px-28 text-dark border-y border-gray border-opacity-[0.22] border-dashed relative before:absolute before:rounded-l before:transition-opacity before:w-4 before:bg-blue before:right-0 before:inset-y-16 before:opacity-0" href="<?= esc_url( home_url( get_current_section_base() . '/wallet' ) ) ?>"><div class="grow"><span class="font-medium text-xs block text-dark">موجودی کیف&zwnj;پول</span><div class="text-larger font-bold text-blue-dark tracking-tighter leading-1 pb-2 mt-3"><span class="text-gray"><?=number_format(UserModel::wallet()) != 0 ? number_format(UserModel::wallet()) : '-'?> تومان</span></div></div><div class="flex w-48 h-48 rounded-lg bg-blue-dark bg-opacity-10 items-center justify-center"><svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" class="w-22 h-22 fill-blue-dark"><path opacity="0.4" d="M18.04 13.55C17.62 13.96 17.38 14.55 17.44 15.18C17.53 16.26 18.52 17.05 19.6 17.05H21.5V18.24C21.5 20.31 19.81 22 17.74 22H6.26C4.19 22 2.5 20.31 2.5 18.24V11.51C2.5 9.44001 4.19 7.75 6.26 7.75H17.74C19.81 7.75 21.5 9.44001 21.5 11.51V12.95H19.48C18.92 12.95 18.41 13.17 18.04 13.55Z"></path><path d="M14.85 3.95V7.74999H6.26C4.19 7.74999 2.5 9.44 2.5 11.51V7.84002C2.5 6.65002 3.23 5.58997 4.34 5.16997L12.28 2.16997C13.52 1.70997 14.85 2.62 14.85 3.95Z"></path><path d="M22.56 13.9699V16.03C22.56 16.58 22.12 17.0299 21.56 17.0499H19.6C18.52 17.0499 17.53 16.2599 17.44 15.1799C17.38 14.5499 17.62 13.9599 18.04 13.5499C18.41 13.1699 18.92 12.95 19.48 12.95H21.56C22.12 12.97 22.56 13.4199 22.56 13.9699Z"></path><path d="M14 12.75H7C6.59 12.75 6.25 12.41 6.25 12C6.25 11.59 6.59 11.25 7 11.25H14C14.41 11.25 14.75 11.59 14.75 12C14.75 12.41 14.41 12.75 14 12.75Z"></path></svg></div></a>
                </div>

                <nav class="account-nav" role="tablist">

                    <a href="<?= esc_url( home_url( get_current_section_base() ) ) ?>"
                       class="account-nav__item <?= $active_profile_tab === '' ? 'active' : '' ?>"
                       role="tab">
                        <span class="icon icon-menu2"></span>
                        داشبورد
                    </a>

                    <a href="<?= esc_url( home_url( get_current_section_base() . '/orders' ) ) ?>"
                       class="account-nav__item <?= $active_profile_tab === 'orders' ? 'active' : '' ?>"
                       role="tab">
                        <span class="icon icon-order"></span>
                        سفارش‌های من
                    </a>
                    <a href="<?= esc_url( home_url( get_current_section_base() . '/list' ) ) ?>"
                       class="account-nav__item list-interest <?= $active_profile_tab === 'list' ? 'active' : '' ?>" role="tab">
                        <svg viewBox="0 0 24 24">
                            <path d="M12.62 20.81C12.28 20.93 11.72 20.93 11.38 20.81C8.48 19.82 2 15.69 2 8.68998C2 5.59998 4.49 3.09998 7.56 3.09998C9.38 3.09998 10.99 3.97998 12 5.33998C13.01 3.97998 14.63 3.09998 16.44 3.09998C19.51 3.09998 22 5.59998 22 8.68998C22 15.69 15.52 19.82 12.62 20.81Z" fill="none" stroke="inherit" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                        </svg>
                        لیست علاقه مندی
                    </a>
                    <a href="<?= esc_url( home_url( get_current_section_base() . '/deliveries' ) ) ?>"
                       class="account-nav__item <?= $active_profile_tab === 'deliveries' ? 'active' : '' ?>"
                       role="tab">
                        <span class="icon icon-flash"></span>
                        کدهای تحویل‌شده
                    </a>
                    <a href="<?= esc_url( home_url( get_current_section_base() . '/post' ) ) ?>"
                       class="account-nav__item <?= $active_profile_tab === 'post' ? 'active' : '' ?>"
                       role="tab">
                        <span class="icon icon-document"></span>
                        ارسال مقاله
                    </a>
                    <a href="<?= esc_url( home_url( get_current_section_base() . '/wallet' ) ) ?>"
                       class="account-nav__item <?= $active_profile_tab === 'wallet' ? 'active' : '' ?>"
                       role="tab">
                        <span class="icon icon-wallet"></span>
                        کیف پول و امتیاز
                    </a>
                    <?php
                    if (!$vip){
                        ?>
                        <a href="<?= esc_url( home_url( get_current_section_base() . '/verification' ) ) ?>"
                           class="account-nav__item <?= $active_profile_tab === 'verification' ? 'active' : '' ?>"
                           role="tab">
                            <span class="icon icon-verify"></span>
                            احراز هویت
                        </a>
                        <?php
                    }
                    ?>
                    <a href="<?= esc_url( home_url( get_current_section_base() . '/coupons' ) ) ?>"
                       class="account-nav__item <?= $active_profile_tab === 'coupons' ? 'active' : '' ?>"
                       role="tab">
                        <span class="icon icon-gift"></span>
                        کد های تخفیف
                    </a>
                    <a href="<?= esc_url( home_url( get_current_section_base() . '/cards' ) ) ?>"
                       class="account-nav__item <?= $active_profile_tab === 'cards' ? 'active' : '' ?>"
                       role="tab">
                        <span class="icon icon-card"></span>
                        کارت های بانکی
                    </a>
                    <a href="<?= esc_url( home_url( get_current_section_base() . '/user' ) ) ?>"
                       class="account-nav__item <?= $active_profile_tab === 'user' ? 'active' : '' ?>"
                       role="tab">
                        <span class="icon icon-user-o"></span>
                        تنظیمات حساب کاربری
                    </a>
                </nav>
            </aside>

            <div class="account-content">

                <div class="account-panel active" id="panel-post" role="tabpanel" aria-hidden="false" tabindex="0">
                    <div>
                        <h2 class="text-lg grow pt-5">ارسال مقاله</h2>
                        <div class="text-sm text-dark mt-6 leading-sm">
                            ارسال مقاله در درج در سایت
                        </div>
                        <?php
                        if (!is_user_logged_in()) {
                            return '<p>برای ارسال مقاله ابتدا وارد حساب کاربری شوید.</p>';
                        }

                        $user_id = get_current_user_id();
                        if (!giftmax_user_can_submit_article($user_id)) {
                            echo '<p>شما دسترسی ارسال مقاله ندارید.</p>';
                            return false;
                        }

                        $categories = get_categories([
                            'taxonomy'   => 'category',
                            'hide_empty' => false,
                        ]);

                        ?>
                        <div class="grid grid-cols-2 gap-12 md:gap-16 mt-16 md:mt-20">
                            <div class="form-group col-span-2 md:col-span-1"><label class="form-label">موضوع</label>
                                <div class="input-group">
                                    <input class="form-control" spellcheck="false" placeholder="" type="text" value="" name="subject"></div>
                            </div>
                            <div class="form-group col-span-2 md:col-span-1">
                                <label class="form-label">دسته‌بندی</label>
                                <div class="input-group">
                                    <select id="giftmax_article_category" name="giftmax_article_category" required
                                            style="width:100%;">
                                        <option value="">انتخاب دسته‌بندی</option>
                                        <?php foreach ($categories as $cat): ?>
                                            <option value="<?php echo (int) $cat->term_id; ?>">
                                                <?php echo esc_html($cat->name); ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group col-span-2"><label class="form-label">متن مقاله</label>
                                <div class="input-group">
                                    <?php
                                    wp_editor('', 'giftmax_article_content_editor', [
                                        'textarea_name' => 'giftmax_article_content',
                                        'media_buttons' => false,
                                        'textarea_rows' => 12,
                                        'teeny'         => false, // ویرایشگر کلاسیک کامل
                                        'quicktags'     => true,
                                    ]);
                                    ?>
                                </div>
                            </div>
                        </div>
                        <div class="flex flex-wrap items-start mt-16 sm:mt-20 md:mt-24">
                            <button type="button" class="btn btn-blue btn-ajax sm:px-48 md:min-w-[200px] mt-20 sm:mt-0 w-full sm:w-auto Button-sp13">
                                ارسال
                            </button>
                        </div>
                    </div>
                    <div>
                        <h2 class="text-lg mb-8 md:mb-10 lg:mb-12">راهنما</h2>
                        <ul class="panel-text-list text-sm text-dark">
                            <li>برای هر موضوع فقط یک مقاله منتشر میشود و از تکرار یک مساله پرهیز کنید.</li>
                            <li>بعد از منشتر شدن مقاله امیتاز هدیه دریافت خواهید کرد</li>
                        </ul>
                    </div>
                    <div class="flex items-center pb-14 md:pb-18 pt-20 md:pt-24 lg:py-24 px-24 md:px-28 lg:px-32 border-t border-gray-300 -m-40">
                        <h2 class="text-lg grow">مقالات شما</h2>
                        <div class="alert alert-blue bg-blue font-normal alert-sm flex items-center px-14 lg:px-20 py-12">
                            <div class="grow font-bold text-normal leading-1"><?=number_format(count_user_posts($user_id, 'post'))?></div>
                        </div>
                    </div>
                    <?php
                    $args = array(
                        'author' => $user_id,
                        'post_type' => 'post',
                        'post_status' => 'publish', // فقط منتشر شده
                        'posts_per_page' => -1,
                        'orderby' => 'date',
                        'order' => 'DESC'
                    );

                    $user_posts = new WP_Query($args);
                    $published_count = $user_posts->found_posts;
                    if ($user_posts->have_posts()){
                    ?>
                    <div class="relative flex flex-col grow">
                        <div class="overflow-x-auto overflow-y-hidden px-24 md:px-28 lg:px-0 pb-24 md:pb-28 lg:pb-0 lg:last:pb-4 -m-40">
                            <table class="table-list panel-table-list">
                                <thead>
                                <tr>
                                    <th>مقاله</th>
                                    <th>امتیاز</th>
                                    <th>تاریخ</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php
                                while ($user_posts->have_posts()) { $user_posts->the_post();
                                    $points = max(0, (int) get_post_meta(get_the_ID(), '_giftmax_article_reward_points', true));
                                    ?>
                                <tr>
                                    <td data-content="مقاله" class="!items-start">
                                        <div class="table-td-inner">
                                            <a href="<?=get_permalink()?>" class="tracking-tight break-words font-normal text-dark" target="_blank"><?=get_the_title()?></a>
                                        </div>
                                    </td>
                                    <td data-content="امتیاز">
                                        <div class="table-td-inner"><span class="font-medium text-sm <?=$points !=0 ? 'text-green-dark' : ''?>"><?=$points !=0 ? '+' . number_format($points) : '-'?></span>
                                        </div>
                                    </td>
                                    <td data-content="تاریخ">
                                        <div class="table-td-inner"><?=gjdate(get_the_date('Y/m/d H:i'),"d M Y - H:i")?></div>
                                    </td>
                                </tr>
                                <?php
                                }
                                ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <?php
                    }
                    wp_reset_postdata();
                    ?>
                </div>
            </div>
        </div>
    </section>
</main>
<script>
    $('select').selectric();
</script>