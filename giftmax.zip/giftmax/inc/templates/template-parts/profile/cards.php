<?php
use Giftmax\Modules\Db;
use Giftmax\Modules\UserModel;

$current_user = wp_get_current_user();
$user_id = $current_user->ID;
$first_name = $current_user->first_name;
$recoords_Vip = UserModel::table("user_identity","user_id",$user_id);
if (is_array($recoords_Vip) && $recoords_Vip['account_type'] == 'vip'){
    $vip = 1;
}else{
    $vip = 0;
}
$db = \Giftmax\Modules\Db::getLnstance();
global $wpdb;
$National_card__img = $db->first("SELECT * FROM {$wpdb->prefix}documents WHERE user_id = :user_id AND doc_type = 'National_card__img' AND accepted=2 ",array('user_id' => $user_id));
$birth_certificate = $db->first("SELECT * FROM {$wpdb->prefix}documents WHERE user_id = :user_id AND doc_type = 'Birth_certificate' AND accepted=2 ",array('user_id' => $user_id));
$active_profile_tab = sanitize_key((string) get_query_var('profile_tab'));

?>
<main class="account-page">
    <section class="account-hero">
        <div class="container">
            <nav aria-label="مسیر دسترسی" class="breadcrumbs">
                <ol>
                    <li><a href="<?php echo site_url(); ?>">خانه</a></li>
                    <li aria-current="page">حساب کاربری</li>
                </ol>
            </nav>
        </div>
    </section>
    <section class="account-shell">
        <div class="container account-shell__layout">
            <aside class="account-sidebar" aria-label="منوی حساب کاربری">
                <div class="account-sidebar__card">
                    <div class="pb-28">
                        <div class="account-sidebar__header">
                            <div class="text-secondary font-bold tracking-tighter text-normal leading-xs grow"><?=$current_user->first_name . ' ' . $current_user->last_name?></div>
                            <?php
                            if (is_user_blocked()){
                                ?>
                                <div class="c-badge relative -top-2 text-2xs rounded-pill font-normal px-14">کاربر <span class="font-medium">مسدود </span></div>
                                <?php
                            }else{
                                ?>
                                <div class="c-badge relative -top-2 text-2xs rounded-pill font-normal px-14">کاربر <span class="font-medium"><?=$vip ?'ویژه': 'عادی'; ?></span></div>
                                <?php
                            }
                            ?>
                        </div>
                        <a class="alert alert-primary bg-primary bg-opacity-20 font-normal alert-sm flex items-start px-14 lg:px-16 mt-12" href="<?= esc_url( home_url( get_current_section_base() . '/wallet' ) ) ?>"><i class="icon-star pt-2 text-[#D19411] text-xs ml-8"></i><div class="grow">شما <strong class="font-bold"><?=number_format(UserModel::points())?> امتیاز</strong> دارید</div></a>
                    </div>
                    <?php
                    if (!empty($National_card__img) || !empty($birth_certificate)) {
                        $p = "100";
                    }elseif(is_array($recoords_Vip) && !$recoords_Vip['is_verified']){
                        $p = "30";
                    }else{
                        $p = "80";
                    }
                    if (!$vip){
                        ?>
                        <div class="account-progress">
                            <div class="account-progress__label">
                                <span>درصد تکمیل پروفایل</span>
                                <span><?=$p?>٪</span>
                            </div>
                            <div class="progress-bar">
                                <span style="width: <?=$p?>%"></span>
                            </div>
                            <?php
                            if($p != 100){
                                ?>
                                <button onclick="window.location.href='<?= esc_url( home_url( get_current_section_base() . '/verification' ) ) ?>'" type="button" class="btn btn--outline btn--block" data-panel-trigger="settings">تکمیل اطلاعات</button>
                                <?php
                            }
                            ?>
                        </div>
                        <?php
                    }
                    ?>
                    <a class="flex items-center py-16 leading-2 tracking-tight px-28 text-dark border-y border-gray border-opacity-[0.22] border-dashed relative before:absolute before:rounded-l before:transition-opacity before:w-4 before:bg-blue before:right-0 before:inset-y-16 before:opacity-0" href="<?= esc_url( home_url( get_current_section_base() . '/wallet' ) ) ?>"><div class="grow"><span class="font-medium text-xs block text-dark">موجودی کیف&zwnj;پول</span><div class="text-larger font-bold text-blue-dark tracking-tighter leading-1 pb-2 mt-3"><span class="text-gray"><?=number_format(UserModel::wallet()) != 0 ? number_format(UserModel::wallet()) : '-'?> تومان</span></div></div><div class="flex w-48 h-48 rounded-lg bg-blue-dark bg-opacity-10 items-center justify-center"><svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" class="w-22 h-22 fill-blue-dark"><path opacity="0.4" d="M18.04 13.55C17.62 13.96 17.38 14.55 17.44 15.18C17.53 16.26 18.52 17.05 19.6 17.05H21.5V18.24C21.5 20.31 19.81 22 17.74 22H6.26C4.19 22 2.5 20.31 2.5 18.24V11.51C2.5 9.44001 4.19 7.75 6.26 7.75H17.74C19.81 7.75 21.5 9.44001 21.5 11.51V12.95H19.48C18.92 12.95 18.41 13.17 18.04 13.55Z"></path><path d="M14.85 3.95V7.74999H6.26C4.19 7.74999 2.5 9.44 2.5 11.51V7.84002C2.5 6.65002 3.23 5.58997 4.34 5.16997L12.28 2.16997C13.52 1.70997 14.85 2.62 14.85 3.95Z"></path><path d="M22.56 13.9699V16.03C22.56 16.58 22.12 17.0299 21.56 17.0499H19.6C18.52 17.0499 17.53 16.2599 17.44 15.1799C17.38 14.5499 17.62 13.9599 18.04 13.5499C18.41 13.1699 18.92 12.95 19.48 12.95H21.56C22.12 12.97 22.56 13.4199 22.56 13.9699Z"></path><path d="M14 12.75H7C6.59 12.75 6.25 12.41 6.25 12C6.25 11.59 6.59 11.25 7 11.25H14C14.41 11.25 14.75 11.59 14.75 12C14.75 12.41 14.41 12.75 14 12.75Z"></path></svg></div></a>
                </div>

                <nav class="account-nav" role="tablist">

                    <a href="<?= esc_url( home_url( get_current_section_base() ) ) ?>"
                       class="account-nav__item <?= $active_profile_tab === '' ? 'active' : '' ?>"
                       role="tab">
                        <span class="icon icon-menu2"></span>
                        داشبورد
                    </a>

                    <a href="<?= esc_url( home_url( get_current_section_base() . '/orders' ) ) ?>"
                       class="account-nav__item <?= $active_profile_tab === 'orders' ? 'active' : '' ?>"
                       role="tab">
                        <span class="icon icon-order"></span>
                        سفارش‌های من
                    </a>
                    <a href="<?= esc_url( home_url( get_current_section_base() . '/list' ) ) ?>"
                       class="account-nav__item list-interest <?= $active_profile_tab === 'list' ? 'active' : '' ?>" role="tab">
                        <svg viewBox="0 0 24 24">
                            <path d="M12.62 20.81C12.28 20.93 11.72 20.93 11.38 20.81C8.48 19.82 2 15.69 2 8.68998C2 5.59998 4.49 3.09998 7.56 3.09998C9.38 3.09998 10.99 3.97998 12 5.33998C13.01 3.97998 14.63 3.09998 16.44 3.09998C19.51 3.09998 22 5.59998 22 8.68998C22 15.69 15.52 19.82 12.62 20.81Z" fill="none" stroke="inherit" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                        </svg>
                        لیست علاقه مندی
                    </a>
                    <a href="<?= esc_url( home_url( get_current_section_base() . '/deliveries' ) ) ?>"
                       class="account-nav__item <?= $active_profile_tab === 'deliveries' ? 'active' : '' ?>"
                       role="tab">
                        <span class="icon icon-flash"></span>
                        کدهای تحویل‌شده
                    </a>
                    <a href="<?= esc_url( home_url( get_current_section_base() . '/post' ) ) ?>"
                       class="account-nav__item <?= $active_profile_tab === 'post' ? 'active' : '' ?>"
                       role="tab">
                        <span class="icon icon-document"></span>
                        ارسال مقاله
                    </a>
                    <a href="<?= esc_url( home_url( get_current_section_base() . '/wallet' ) ) ?>"
                       class="account-nav__item <?= $active_profile_tab === 'wallet' ? 'active' : '' ?>"
                       role="tab">
                        <span class="icon icon-wallet"></span>
                        کیف پول و امتیاز
                    </a>
                    <?php
                    if (!$vip){
                        ?>
                        <a href="<?= esc_url( home_url( get_current_section_base() . '/verification' ) ) ?>"
                           class="account-nav__item <?= $active_profile_tab === 'verification' ? 'active' : '' ?>"
                           role="tab">
                            <span class="icon icon-verify"></span>
                            احراز هویت
                        </a>
                        <?php
                    }
                    ?>
                    <a href="<?= esc_url( home_url( get_current_section_base() . '/coupons' ) ) ?>"
                       class="account-nav__item <?= $active_profile_tab === 'coupons' ? 'active' : '' ?>"
                       role="tab">
                        <span class="icon icon-gift"></span>
                        کد های تخفیف
                    </a>
                    <a href="<?= esc_url( home_url( get_current_section_base() . '/cards' ) ) ?>"
                       class="account-nav__item <?= $active_profile_tab === 'cards' ? 'active' : '' ?>"
                       role="tab">
                        <span class="icon icon-card"></span>
                        کارت های بانکی
                    </a>
                    <a href="<?= esc_url( home_url( get_current_section_base() . '/user' ) ) ?>"
                       class="account-nav__item <?= $active_profile_tab === 'user' ? 'active' : '' ?>"
                       role="tab">
                        <span class="icon icon-user-o"></span>
                        تنظیمات حساب کاربری
                    </a>
                </nav>
            </aside>

            <div class="account-content">

                <div class="account-panel active" id="panel-card" role="tabpanel" aria-hidden="false" tabindex="0">
                    <div class="account-panel__div flex justify-between align-items-center">
                        <div>
                            <h2>کارت‌های بانکی</h2>
                        </div>
                        <button type="button" class="btn btn--gradient Button-ac54" style=" width: 25%">افزودن کارت</button>
                    </div>
                    <section class="bank-cards__account">
                        <header class="bank-cards__header">
                            <h2>کارت&zwnj;های اضافه&zwnj;شده</h2>
                            <p>کارت&zwnj;هایی که به حساب شما متصل شده&zwnj;اند.</p>
                        </header>
                        <?php
                        $user = wp_get_current_user();
                        global $wpdb;
                        $db = Db::getLnstance();
                        $defaultCard = $db->query("SELECT * FROM `{$wpdb->prefix}user_bank_cards` WHERE `user_id`=:user_id AND `is_active` = 1",array('user_id'=>$user_id));
                        ?>
                        <div class="<?=!empty($defaultCard) ? 'bank-cards__list' : 'flex'?>">
                            <?php
                          if (!empty($defaultCard)){
                            foreach ($defaultCard as $card) {
                            $cardNumber = rtrim(
                                chunk_split(decrypt_data($card['card_number_enc']), 4, '-'),
                                '-'
                            );
                            ?>
                            <article class="bank-card__account">
                                <div class="box">
                                    <div class="bank-card__top">
                                    <span class="bank-card__bank"><?=detectBankByCardNumber($cardNumber)?></span>
                                    <?php
                                    if (empty($card['phone'])){
                                    ?>
                                    <span class="bank-card__status">کارت شخصی</span>
                                        <?php
                                    }else{?>
                                        <span class="bank-card__status">کارت شخص دیگر</span>
                                    <?php }
                                    ?>
                                </div>
                                    <h3 class="bank-card__number"><?=$cardNumber?></h3>
                                    <div class="bank-card__meta">
                                    <?php
                                    if (empty($card['phone'])){
                                    ?>
                                    <span>دارنده کارت:  <?= $user->first_name . ' ' . $user->last_name ?></span>
                                    <?php
                                    }else{
                                        ?>
                                        <span>شماره تلفن ثبت شده:<?=decrypt_data($card['phone'])?></span>
                                    <?php }
                                    ?>
                                </div>
                                </div>
                                <div class="V10-3-Bank">
                                    <?php
                                    $cardSetting = detectBankImageBg($cardNumber,'v1');
                                    if (empty($card['phone'])){
                                        $userdata = UserModel::table('user_identity','user_id',$user_id);
                                        ?>
                                        <span class="numberCard" style="bottom: <?=$cardSetting['positionText']?>px;<?=$cardSetting != null ? "color:" . $cardSetting['color'] : '' ?>"><?=$cardNumber?></span>
                                        <img alt="bank" loading="lazy" src="<?=$cardSetting['img']?>">
                                        <span class="number-user" style="bottom: <?=$cardSetting["Box"]["y"]?>px;color:<?=$cardSetting["Box"]["color"]?>"><?=$user->user_login?></span>
                                        <span class="birthday-user" style="bottom: <?=$cardSetting["Box"]["y"]?>px;color:<?=$cardSetting["Box"]["color"]?>"><?=decrypt_data($userdata['birth_date_enc'])?></span>
                                        <span class="national__code-user" style="bottom: <?=$cardSetting["Box"]["y"]?>px;color:<?=$cardSetting["Box"]["color"]?>"><?=decrypt_data($userdata['national_id_enc'])?></span>
                                        <span class="full__name-user" style="bottom: <?=$cardSetting["Box"]["y"]?>px;color:<?=$cardSetting["Box"]["color"]?>"><?=$user->first_name . ' ' . $user->last_name?></span>

                                        <?php
                                    }else{
                                        ?>
                                        <span class="numberCard" style="bottom: <?=$cardSetting['positionText']?>px;<?=$cardSetting != null ? "color:" . $cardSetting['color'] : '' ?>"><?=$cardNumber?></span>
                                        <span class="number-user" style="bottom: <?=$cardSetting["Box"]["y"]?>px;color:<?=$cardSetting["Box"]["color"]?>"><?=decrypt_data($card['phone'])?></span>
                                            <span class="birthday-user" style="bottom: <?=$cardSetting["Box"]["y"]?>px;color:<?=$cardSetting["Box"]["color"]?>"><?=decrypt_data($card['birth_date'])?></span>
                                            <span class="national__code-user" style="bottom: <?=$cardSetting["Box"]["y"]?>px;color:<?=$cardSetting["Box"]["color"]?>"><?=decrypt_data($card['national_code'])?></span>
                                            <span class="full__name-user" style="bottom: <?=$cardSetting["Box"]["y"]?>px;color:<?=$cardSetting["Box"]["color"]?>"><?=$card['first_name'] . ' ' . $card['last_name']?></span>
                                        <img alt="bank" loading="lazy" src="<?=$cardSetting['img']?>">
                                    <?php }
                                    ?>
                                </div>
                            </article>
                            <?php
                            }
                            }else{
                                ?>
                                <div class="mx-auto">
                                    <img src="<?= esc_url(get_template_directory_uri() . '/assets/img/ticket_img.png') ?>">
                                    <p class="flex justify-center">کارتی ثبت نکرده اید</p>
                                </div>
                            <?php }
                            ?>
                        </div>
                    </section>
                </div>
            </div>
        </div>
    </section>
</main>
