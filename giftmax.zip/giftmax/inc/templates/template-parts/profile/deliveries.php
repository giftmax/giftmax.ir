<?php
use Giftmax\Modules\UserModel;


$current_user = wp_get_current_user();
$user_id = $current_user->ID;
$first_name = $current_user->first_name;
$recoords_Vip = UserModel::table("user_identity","user_id",$user_id);
if (is_array($recoords_Vip) && $recoords_Vip['account_type'] == 'vip'){
    $vip = 1;
}else{
    $vip = 0;
}
$db = \Giftmax\Modules\Db::getLnstance();
global $wpdb;
$National_card__img = $db->first("SELECT * FROM {$wpdb->prefix}documents WHERE user_id = :user_id AND doc_type = 'National_card__img' AND accepted=2 ",array('user_id' => $user_id));
$birth_certificate = $db->first("SELECT * FROM {$wpdb->prefix}documents WHERE user_id = :user_id AND doc_type = 'Birth_certificate' AND accepted=2 ",array('user_id' => $user_id));
$active_profile_tab = sanitize_key((string) get_query_var('profile_tab'));

?>
<main class="account-page">
    <section class="account-hero">
        <div class="container">
            <nav aria-label="مسیر دسترسی" class="breadcrumbs">
                <ol>
                    <li><a href="<?php echo site_url(); ?>">خانه</a></li>
                    <li aria-current="page">حساب کاربری</li>
                </ol>
            </nav>
        </div>
    </section>
    <section class="account-shell">
        <div class="container account-shell__layout">
            <aside class="account-sidebar" aria-label="منوی حساب کاربری">
                <div class="account-sidebar__card">
                    <div class="pb-28">
                        <div class="account-sidebar__header">
                            <div class="text-secondary font-bold tracking-tighter text-normal leading-xs grow"><?=$current_user->first_name . ' ' . $current_user->last_name?></div>
                            <?php
                            if (is_user_blocked()){
                                ?>
                                <div class="c-badge relative -top-2 text-2xs rounded-pill font-normal px-14">کاربر <span class="font-medium">مسدود </span></div>
                                <?php
                            }else{
                                ?>
                                <div class="c-badge relative -top-2 text-2xs rounded-pill font-normal px-14">کاربر <span class="font-medium"><?=$vip ?'ویژه': 'عادی'; ?></span></div>
                                <?php
                            }
                            ?>
                        </div>
                        <a class="alert alert-primary bg-primary bg-opacity-20 font-normal alert-sm flex items-start px-14 lg:px-16 mt-12" href="<?= esc_url( home_url( get_current_section_base() . '/wallet' ) ) ?>"><i class="icon-star pt-2 text-[#D19411] text-xs ml-8"></i><div class="grow">شما <strong class="font-bold"><?=number_format(UserModel::points())?> امتیاز</strong> دارید</div></a>
                    </div>
                    <?php
                    if (!empty($National_card__img) || !empty($birth_certificate)) {
                        $p = "100";
                    }elseif(is_array($recoords_Vip) && !$recoords_Vip['is_verified']){
                        $p = "30";
                    }else{
                        $p = "80";
                    }
                    if (!$vip){
                        ?>
                        <div class="account-progress">
                            <div class="account-progress__label">
                                <span>درصد تکمیل پروفایل</span>
                                <span><?=$p?>٪</span>
                            </div>
                            <div class="progress-bar">
                                <span style="width: <?=$p?>%"></span>
                            </div>
                            <?php
                            if($p != 100){
                                ?>
                                <button onclick="window.location.href='<?= esc_url( home_url( get_current_section_base() . '/verification' ) ) ?>'" type="button" class="btn btn--outline btn--block" data-panel-trigger="settings">تکمیل اطلاعات</button>
                                <?php
                            }
                            ?>
                        </div>
                        <?php
                    }
                    ?>
                    <a class="flex items-center py-16 leading-2 tracking-tight px-28 text-dark border-y border-gray border-opacity-[0.22] border-dashed relative before:absolute before:rounded-l before:transition-opacity before:w-4 before:bg-blue before:right-0 before:inset-y-16 before:opacity-0" href="<?= esc_url( home_url( get_current_section_base() . '/wallet' ) ) ?>"><div class="grow"><span class="font-medium text-xs block text-dark">موجودی کیف&zwnj;پول</span><div class="text-larger font-bold text-blue-dark tracking-tighter leading-1 pb-2 mt-3"><span class="text-gray"><?=number_format(UserModel::wallet()) != 0 ? number_format(UserModel::wallet()) : '-'?> تومان</span></div></div><div class="flex w-48 h-48 rounded-lg bg-blue-dark bg-opacity-10 items-center justify-center"><svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" class="w-22 h-22 fill-blue-dark"><path opacity="0.4" d="M18.04 13.55C17.62 13.96 17.38 14.55 17.44 15.18C17.53 16.26 18.52 17.05 19.6 17.05H21.5V18.24C21.5 20.31 19.81 22 17.74 22H6.26C4.19 22 2.5 20.31 2.5 18.24V11.51C2.5 9.44001 4.19 7.75 6.26 7.75H17.74C19.81 7.75 21.5 9.44001 21.5 11.51V12.95H19.48C18.92 12.95 18.41 13.17 18.04 13.55Z"></path><path d="M14.85 3.95V7.74999H6.26C4.19 7.74999 2.5 9.44 2.5 11.51V7.84002C2.5 6.65002 3.23 5.58997 4.34 5.16997L12.28 2.16997C13.52 1.70997 14.85 2.62 14.85 3.95Z"></path><path d="M22.56 13.9699V16.03C22.56 16.58 22.12 17.0299 21.56 17.0499H19.6C18.52 17.0499 17.53 16.2599 17.44 15.1799C17.38 14.5499 17.62 13.9599 18.04 13.5499C18.41 13.1699 18.92 12.95 19.48 12.95H21.56C22.12 12.97 22.56 13.4199 22.56 13.9699Z"></path><path d="M14 12.75H7C6.59 12.75 6.25 12.41 6.25 12C6.25 11.59 6.59 11.25 7 11.25H14C14.41 11.25 14.75 11.59 14.75 12C14.75 12.41 14.41 12.75 14 12.75Z"></path></svg></div></a>
                </div>

                <nav class="account-nav" role="tablist">

                    <a href="<?= esc_url( home_url( get_current_section_base() ) ) ?>"
                       class="account-nav__item <?= $active_profile_tab === '' ? 'active' : '' ?>"
                       role="tab">
                        <span class="icon icon-menu2"></span>
                        داشبورد
                    </a>

                    <a href="<?= esc_url( home_url( get_current_section_base() . '/orders' ) ) ?>"
                       class="account-nav__item <?= $active_profile_tab === 'orders' ? 'active' : '' ?>"
                       role="tab">
                        <span class="icon icon-order"></span>
                        سفارش‌های من
                    </a>
                    <a href="<?= esc_url( home_url( get_current_section_base() . '/list' ) ) ?>"
                       class="account-nav__item list-interest <?= $active_profile_tab === 'list' ? 'active' : '' ?>" role="tab">
                        <svg viewBox="0 0 24 24">
                            <path d="M12.62 20.81C12.28 20.93 11.72 20.93 11.38 20.81C8.48 19.82 2 15.69 2 8.68998C2 5.59998 4.49 3.09998 7.56 3.09998C9.38 3.09998 10.99 3.97998 12 5.33998C13.01 3.97998 14.63 3.09998 16.44 3.09998C19.51 3.09998 22 5.59998 22 8.68998C22 15.69 15.52 19.82 12.62 20.81Z" fill="none" stroke="inherit" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                        </svg>
                        لیست علاقه مندی
                    </a>
                    <a href="<?= esc_url( home_url( get_current_section_base() . '/deliveries' ) ) ?>"
                       class="account-nav__item <?= $active_profile_tab === 'deliveries' ? 'active' : '' ?>"
                       role="tab">
                        <span class="icon icon-flash"></span>
                        کدهای تحویل‌شده
                    </a>
                    <a href="<?= esc_url( home_url( get_current_section_base() . '/post' ) ) ?>"
                       class="account-nav__item <?= $active_profile_tab === 'post' ? 'active' : '' ?>"
                       role="tab">
                        <span class="icon icon-document"></span>
                        ارسال مقاله
                    </a>
                    <a href="<?= esc_url( home_url( get_current_section_base() . '/wallet' ) ) ?>"
                       class="account-nav__item <?= $active_profile_tab === 'wallet' ? 'active' : '' ?>"
                       role="tab">
                        <span class="icon icon-wallet"></span>
                        کیف پول و امتیاز
                    </a>
                    <?php
                    if (!$vip){
                        ?>
                        <a href="<?= esc_url( home_url( get_current_section_base() . '/verification' ) ) ?>"
                           class="account-nav__item <?= $active_profile_tab === 'verification' ? 'active' : '' ?>"
                           role="tab">
                            <span class="icon icon-verify"></span>
                            احراز هویت
                        </a>
                        <?php
                    }
                    ?>
                    <a href="<?= esc_url( home_url( get_current_section_base() . '/coupons' ) ) ?>"
                       class="account-nav__item <?= $active_profile_tab === 'coupons' ? 'active' : '' ?>"
                       role="tab">
                        <span class="icon icon-gift"></span>
                        کد های تخفیف
                    </a>
                    <a href="<?= esc_url( home_url( get_current_section_base() . '/cards' ) ) ?>"
                       class="account-nav__item <?= $active_profile_tab === 'cards' ? 'active' : '' ?>"
                       role="tab">
                        <span class="icon icon-card"></span>
                        کارت های بانکی
                    </a>
                    <a href="<?= esc_url( home_url( get_current_section_base() . '/user' ) ) ?>"
                       class="account-nav__item <?= $active_profile_tab === 'user' ? 'active' : '' ?>"
                       role="tab">
                        <span class="icon icon-user-o"></span>
                        تنظیمات حساب کاربری
                    </a>
                </nav>
            </aside>

            <div class="account-content">
                <div
                        class="account-panel active"
                        id="panel-deliveries"
                        data-panel="deliveries"
                        role="tabpanel"
                        aria-hidden="true"
                        tabindex="0"
                        hidden
                >
                    <div class="account-panel__div">
                        <div>
                            <h2>کدهای تحویل‌شده</h2>
                            <p>کدهای گیفت کارت فعال‌شده و وضعیت ریدیم برای هر سفارش.</p>
                        </div>
                    </div>
                    <?php
                    $user_id = get_current_user_id();

                    $orders = wc_get_orders([
                            'customer_id' => $user_id,
                            'status'      => ['card-not-verified','processing', 'completed'],
                            'limit'       => -1,
                    ]);
                    if (!empty($orders)) {
                        ?>
                        <table class="order-table panel-giftcards-table">
                            <tbody>
                            <?php
                            foreach ($orders as $order) {
                                foreach ($order->get_items() as $item) {
                                    $order_id = $order->get_id();
                                    $licenses = $item->get_meta('_reserved_licence_ids');
                                    $product_name = $item->get_name();
                                    $productId = $item->get_product_id();
                                    $created_at = $order->get_date_created() ? $order->get_date_created()->date('Y/m/d H:i') : ''
                                    ?>
                                    <tr>
                                        <?php
                                        if (!isMobile()){
                                            ?>
                                            <td>
                                                <div class="flex">
                                                    <a class="ml-20 shrink-0" href="<?=get_permalink($productId)?>">
                                                        <div class="relative">
                                                            <img alt="<?=$product_name?>" loading="lazy" width="100"
                                                                 decoding="async" data-nimg="1"
                                                                 class="shrink-0 rounded block"
                                                                 src="<?=get_the_post_thumbnail_url($productId, 'product_discount')?>"
                                                                 style="color: transparent;">
                                                            <div class="w-16 h-16 absolute -top-4 -right-4 rounded-xs bg-white shadow-[0_0_0_2px_#fff] overflow-hidden">
                                                            </div>
                                                        </div>
                                                    </a>
                                                    <div class="pts-4 self-center">
                                                        <div class="font-bold tracking-tight text-normal leading-xs">
                                                            <a class="text-dark" href="<?=get_permalink($productId)?>"><?=$product_name?></a></div>
                                                        <div class="leading-xs mt-6 space-y-5">
                                                            <div class="text-gray font-normal text-xs">تاریخ خرید:
                                                                <?=gjdate($created_at,'d M Y, H:i')?>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </td>
                                            <td>
                                            <div class="flex space-x-12 space-x-reverse justify-end">
                                                <div class="grow basis-0 md:grow-0 md:basis-auto"></div>
                                                <div class="relative before:absolute before:top-full before:hidden hover:before:block grow basis-0 md:grow-0 md:basis-auto md:min-w-128">
                                                    <?php
                                                    if ($order->get_status() !== 'card-not-verified'){
                                                        if (!empty($licenses)) {
                                                            if (is_string($licenses)) {
                                                                $licenses = json_decode($licenses, true);
                                                                if (is_array($licenses)) {
                                                                    ?>
                                                                    <button type="button" class="btn btn-primary btn-xs py-10 inline-flex items-center justify-center w-full Button-sc56">
                                                                        <i class="icon-eye text-xs -mr-2 pt-2 ml-8"></i>
                                                                        <span>مشاهده کد</span>
                                                                    </button>
                                                                    <div class="dropdown-menu absolute top-full rounded bg-white transition-all z-50 w-[300px] mt-12 left-0 right-auto shadow-dropdown origin-top-left overflow-hidden">
                                                                        <div class="dir-ltr max-h-[400px] overflow-y-auto minimal-scrollbar">
                                                                            <?php
                                                                            foreach ($licenses as $license_code) {
                                                                                $licence_code = \Giftmax\Modules\LicenseManager::ShowLicense($license_code,$order_id);
                                                                                if (empty($licence_code)){
                                                                                    continue;
                                                                                }
                                                                                ?>
                                                                                <?php
                                                                                if (is_null($licence_code['file_id'])){
                                                                                    ?>
                                                                                    <button type="button" class="select-text copy-code-btn flex w-full bg-white border-b border-gray-300 last:border-b-0 rounded-0 p-16 justify-between">
                                                                                        <span class="self-center grow tracking-none text-left pt-2 font-normal pl-6 whitespace-pre-wrap break-words"><?=decrypt_data($licence_code['licence_code'])?></span>
                                                                                        <i class="w-28 h-28 shrink-0 ml-8 rounded-sm"></i>
                                                                                    </button>
                                                                                    <?php
                                                                                }else{
                                                                                    $file = UserModel::table('product_licences_file','file_id',$licence_code['file_id']);
                                                                                    if (!empty($file)){
                                                                                        ?>
                                                                                        <div class="select-text flex w-full bg-white border-b border-gray-300 last:border-b-0 rounded-0 p-16 justify-between">
                                                                                            <div class="Button-df65" data-hash="<?=encrypt_data($licence_code['file_id'] . '|' . $license_code . '|' . $order_id)?>">دانلود فایل</div>
                                                                                            <div class="copy-code-btn flex">
                                                                                                <div class="flex">
                                                                                                    <div class="self-center tracking-none text-left  font-normal whitespace-pre-wrap break-words"> رمز فایل :</div>
                                                                                                    <span class="self-center tracking-none text-left pt-2 font-normal pl-6 whitespace-pre-wrap break-words" style="font-family: 'PeydaFaNumWeb'"><?=decrypt_data($file['password'])?></span>
                                                                                                </div>
                                                                                                <i class="w-28 h-28 shrink-0 ml-8 rounded-sm"></i>
                                                                                            </div>
                                                                                        </div>
                                                                                    <?php }
                                                                                }
                                                                                ?>
                                                                                <?php
                                                                            }
                                                                            ?>
                                                                        </div>
                                                                    </div>
                                                                    <?php
                                                                }else{
                                                                    $delivery   = get_post_meta( $productId, 'delivery', true );
                                                                    if ( isset( $delivery['two'] ) && $delivery['two'] === 'on') {
                                                                        $delivery_time = isset($delivery['time']) ? absint($delivery['time']) : 0;
                                                                        $ctt = $order->get_date_created()
                                                                                ? (clone $order->get_date_created())
                                                                                        ->modify( '+'.$delivery_time.' hour' )
                                                                                        ->date( 'Y/m/d H:i' )
                                                                                : $delivery_time;
                                                                        $ctt = gjdate($ctt,"d M Y، H:i");
                                                                        echo "<span class='c-badge rounded-sm badge-orange text-2xs -mt-1'> تا $ctt لایسنس موجود میشود </span>";
                                                                    }else{
                                                                        echo "<span class='c-badge rounded-sm badge-orange text-2xs -mt-1'>محصول بدون لایسنس</span>";
                                                                    }
                                                                }
                                                            }
                                                        }else{
                                                            $delivery   = get_post_meta( $productId, 'delivery', true );
                                                            if ( isset( $delivery['two'] ) && $delivery['two'] === 'on') {
                                                                $delivery_time = isset($delivery['time']) ? absint($delivery['time']) : 0;
                                                                $ctt = $order->get_date_created()
                                                                        ? (clone $order->get_date_created())
                                                                                ->modify( '+'.$delivery_time.' hour' )
                                                                                ->date( 'Y/m/d H:i' )
                                                                        : $delivery_time;
                                                                $cttj = gjdate($ctt,"d M Y، H:i");
                                                                echo "<span class='c-badge rounded-sm badge-orange text-2xs -mt-1'> تا $cttj لایسنس موجود میشود </span>";
                                                                if ($order && $order->get_date_created()) {
                                                                    $created = clone $order->get_date_created();
                                                                    $deadline = clone $created;
                                                                    $deadline->modify('+' . $delivery_time . ' hour');
                                                                    $now = new DateTime('now', $created->getTimezone());
                                                                    if ($now < $deadline) {
                                                                        $remaining_seconds = $deadline->getTimestamp() - $now->getTimestamp();
                                                                        $total_seconds = $delivery_time * 3600;
                                                                        $progress_percent = (($total_seconds - $remaining_seconds) / $total_seconds) * 100;
                                                                        $formatted_percent = number_format($progress_percent, 2);
                                                                        ?>
                                                                        <div class="mt-3">
                                                                            <div class="relative bg-neutral-100 style_ProductPromotionTimeline__progress__JnKWE">
                                                                                <div class="absolute bg-primary-700 h-full left-0 top-0 style_ProductPromotionTimeline--active__oYyta" style="width: <?=$formatted_percent?>%;"></div>
                                                                            </div>
                                                                            <div class="whitespace-nowrap flex justify-between pt-1">
                                                                                <div class=""><span class="text-primary-700 text-body-strong ml-1"><?=$formatted_percent?>%</span><span class="text-neutral-500 text-caption">زمان سپری شده</span></div>
                                                                                <div class="text-primary-700 text-body2-strong style_ProductPromotionTimeline__timer__zS6ZA1"><?= $ctt ?></div>
                                                                            </div>
                                                                        </div>
                                                                        <?php
                                                                    }
                                                                }
                                                            }else{
                                                                echo "<span class='c-badge rounded-sm badge-orange text-2xs -mt-1'>محصول بدون لایسنس</span>";
                                                            }
                                                        }
                                                    }else{
                                                        echo "<span class='c-badge rounded-sm badge-orange text-2xs -mt-1 Button-vcs788 font-bold pointer' data-id='".encrypt_id($order->get_id())."'>سفارش تایید نشده</span>";
                                                    }

                                                    ?>
                                                </div>
                                            </div>
                                            </td><?php
                                        }else{
                                            ?>
                                            <div class="flex">
                                                <div class="pt-4 self-center grow pl-12">
                                                    <div class="font-bold tracking-tight text-normal leading-xs">
                                                        <a class="text-dark" href="<?=get_permalink($productId)?>"><?=$product_name?></a></div>
                                                    <div class="leading-xs mt-6 space-y-5">
                                                        <div class="text-gray font-normal text-xs">تاریخ خرید: <?=gjdate($created_at,'d M Y, H:i')?>
                                                        </div>
                                                    </div>
                                                </div>
                                                <a class="shrink-0" href="<?=get_permalink($productId)?>">
                                                    <div class="relative"><img alt="<?=$product_name?>"
                                                                               loading="lazy" width="72" height="72"
                                                                               decoding="async" data-nimg="1"
                                                                               class="shrink-0 rounded block w-60"
                                                                               src="<?=get_the_post_thumbnail_url($productId, 'product_discount')?>"
                                                                               style="color: transparent;">
                                                    </div>
                                                </a>
                                            </div>
                                            <div class="flex space-x-8 md:space-x-12 !space-x-reverse mt-12">
                                                <div class="grow basis-0 md:grow-0 md:basis-auto"></div>
                                                <div class="grow basis-0 md:grow-0 md:basis-auto relative flex flex-col justify-end">
                                                    <?php
                                                    if ($order->get_status() !== 'card-not-verified'){
                                                        if (!empty($licenses)) {
                                                            if (is_string($licenses)) {
                                                                $licenses = json_decode($licenses, true);
                                                                if (is_array($licenses)) {
                                                                    ?>
                                                                    <button type="button" class="btn btn-primary btn-xs py-10 inline-flex items-center justify-center w-full Button-sc56">
                                                                        <i class="icon-eye text-xs -mr-2 pt-2 ml-8"></i>
                                                                        <span>مشاهده کد</span>
                                                                    </button>
                                                                    <div class="dropdown-menu absolute top-full rounded bg-white transition-all z-50 w-[300px] mt-12 left-0 right-auto shadow-dropdown origin-top-left overflow-hidden">
                                                                        <div class="dir-ltr max-h-[400px] overflow-y-auto minimal-scrollbar">
                                                                            <?php
                                                                            foreach ($licenses as $license_code) {
                                                                                $licence_code = \Giftmax\Modules\LicenseManager::ShowLicense($license_code,$order_id);
                                                                                if (empty($licence_code)){
                                                                                    continue;
                                                                                }
                                                                                ?>
                                                                                <button type="button" class="select-text copy-code-btn flex w-full bg-white border-b border-gray-300 last:border-b-0 rounded-0 p-16">
                                                                                    <span class="self-center grow tracking-none text-left pt-2 font-normal pl-6 whitespace-pre-wrap break-words"><?=decrypt_data($licence_code['licence_code'])?></span>
                                                                                    <i class="w-28 h-28 shrink-0 ml-8 rounded-sm"></i>
                                                                                </button>
                                                                                <?php
                                                                            }
                                                                            ?>
                                                                        </div>
                                                                    </div>
                                                                    <?php
                                                                }else{
                                                                    $delivery   = get_post_meta( $productId, 'delivery', true );
                                                                    if ( isset( $delivery['two'] ) && $delivery['two'] === 'on') {
                                                                        $delivery_time = isset($delivery['time']) ? absint($delivery['time']) : 0;
                                                                        $ctt = $order->get_date_created()
                                                                                ? (clone $order->get_date_created())
                                                                                        ->modify( '+'.$delivery_time.' hour' )
                                                                                        ->date( 'Y/m/d H:i' )
                                                                                : $delivery_time;
                                                                        $cttj = gjdate($ctt,"d M Y، H:i");
                                                                        echo "<span class='c-badge rounded-sm badge-orange text-2xs -mt-1'> تا $cttj لایسنس موجود میشود </span>";
                                                                        if ($order && $order->get_date_created()) {
                                                                            $created = clone $order->get_date_created();
                                                                            $deadline = clone $created;
                                                                            $deadline->modify('+' . $delivery_time . ' hour');
                                                                            $now = new DateTime('now', $created->getTimezone());
                                                                            if ($now < $deadline) {
                                                                                $remaining_seconds = $deadline->getTimestamp() - $now->getTimestamp();
                                                                                $total_seconds = $delivery_time * 3600;
                                                                                $progress_percent = (($total_seconds - $remaining_seconds) / $total_seconds) * 100;
                                                                                $formatted_percent = number_format($progress_percent, 2);
                                                                                ?>
                                                                                <div class="mt-3">
                                                                                    <div class="relative bg-neutral-100 style_ProductPromotionTimeline__progress__JnKWE">
                                                                                        <div class="absolute bg-primary-700 h-full left-0 top-0 style_ProductPromotionTimeline--active__oYyta" style="width: <?=$formatted_percent?>%;"></div>
                                                                                    </div>
                                                                                    <div class="whitespace-nowrap flex justify-between pt-1">
                                                                                        <div class=""><span class="text-primary-700 text-body-strong ml-1"><?=$formatted_percent?>%</span><span class="text-neutral-500 text-caption">زمان سپری شده</span></div>
                                                                                        <div class="text-primary-700 text-body2-strong style_ProductPromotionTimeline__timer__zS6ZA1"><?= $ctt ?></div>
                                                                                    </div>
                                                                                </div>
                                                                                <?php
                                                                            }
                                                                        }
                                                                    }else{
                                                                        echo "<span class='c-badge rounded-sm badge-orange text-2xs -mt-1'>محصول بدون لایسنس</span>";
                                                                    }
                                                                }
                                                            }
                                                        }else{
                                                            $delivery   = get_post_meta( $productId, 'delivery', true );
                                                            if ( isset( $delivery['two'] ) && $delivery['two'] === 'on') {
                                                                $delivery_time = isset($delivery['time']) ? absint($delivery['time']) : 0;
                                                                $ctt = $order->get_date_created()
                                                                        ? (clone $order->get_date_created())
                                                                                ->modify( '+'.$delivery_time.' hour' )
                                                                                ->date( 'Y/m/d H:i' )
                                                                        : $delivery_time;
                                                                $cttj = gjdate($ctt,"d M Y، H:i");
                                                                echo "<span class='c-badge rounded-sm badge-orange text-2xs -mt-1'> تا $cttj لایسنس موجود میشود </span>";
                                                                if ($order && $order->get_date_created()) {
                                                                    $created = clone $order->get_date_created();
                                                                    $deadline = clone $created;
                                                                    $deadline->modify('+' . $delivery_time . ' hour');
                                                                    $now = new DateTime('now', $created->getTimezone());
                                                                    if ($now < $deadline) {
                                                                        $remaining_seconds = $deadline->getTimestamp() - $now->getTimestamp();
                                                                        $total_seconds = $delivery_time * 3600;
                                                                        $progress_percent = (($total_seconds - $remaining_seconds) / $total_seconds) * 100;
                                                                        $formatted_percent = number_format($progress_percent, 2);
                                                                        ?>
                                                                        <div class="mt-3">
                                                                            <div class="relative bg-neutral-100 style_ProductPromotionTimeline__progress__JnKWE">
                                                                                <div class="absolute bg-primary-700 h-full left-0 top-0 style_ProductPromotionTimeline--active__oYyta" style="width: <?=$formatted_percent?>%;"></div>
                                                                            </div>
                                                                            <div class="whitespace-nowrap flex justify-between pt-1">
                                                                                <div class=""><span class="text-primary-700 text-body-strong ml-1"><?=$formatted_percent?>%</span><span class="text-neutral-500 text-caption">زمان سپری شده</span></div>
                                                                                <div class="text-primary-700 text-body2-strong style_ProductPromotionTimeline__timer__zS6ZA1"><?= $ctt ?></div>
                                                                            </div>
                                                                        </div>
                                                                        <?php
                                                                    }
                                                                }
                                                            }else{
                                                                echo "<span class='c-badge rounded-sm badge-orange text-2xs -mt-1'>محصول بدون لایسنس</span>";
                                                            }
                                                        }
                                                    }else{
                                                        echo "<span class='c-badge rounded-sm badge-orange text-2xs -mt-1 Button-vcs788 font-bold pointer' data-id='".encrypt_id($order->get_id())."'>سفارش تایید نشده</span>";
                                                    }
                                                    ?>
                                                </div>
                                            </div>
                                            <?php
                                        }
                                        ?>
                                    </tr>
                                    <?php
                                }
                            }
                            ?>
                            </tbody>
                        </table>
                        <?php
                    }else{?>
                        <div class="py-4 d-flex flex-column jc-center ai-center EmptyState__desktopContainer-ggZkIg">
                            <div class="d-flex jc-center mb-3" data-testid="empty-src">
                                <div data-testid="image-wrapper" style="width: 200px; height: 150px;"><img class="w-100" src="<?=get_template_directory_uri()?>/assets/img/ticket_img.png" width="200" height="150" data-testid="image-defaultImage" style="object-fit: contain;">
                                </div>
                            </div>
                            <div class="text-h5 color-900">نتیجه&zwnj;ای پیدا نکردیم...</div>
                        </div>
                    <?php }
                    ?>
                </div>
            </div>
        </div>
    </section>
</main>