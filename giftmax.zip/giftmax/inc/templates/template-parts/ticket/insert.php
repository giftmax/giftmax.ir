<div class="py-20 py-0-lg">
    <input type="hidden" name="gid" value="<?=$id?>">
    <input type="hidden" name="method" value="insert">
    <div>
        <div class="d-flex">
            <?php
            if(!empty($subset)){?>
            <div class="pl-10-lg border-l-200"><p class="text-body-2 color-n-600">دسته&zwnj;بندی</p>
                <p class="text-subtitle-strong color-n-700"><?=$subset?></p></div>
            <?php }?>
            <div class="pr-10-lg"><p class="text-body-2 color-n-600">موضوع</p>
                <p class="text-subtitle-strong color-n-700"><?=$object?></p></div>
        </div>
        <div class="d-flex flex-column gap-y-5 mt-5">
            <div>
                <div class="text-body-1 color-n-700 d-flex ai-center jc-between"><p>عنوان درخواست <span
                                class="color-hint-text-error">*</span></p></div>
                <p class="text-body-2 color-n-500"></p><label
                        class="FormComponentFrame-sy77JE FormComponentFrame--normal-Tol9_4 w-100">
                    <div class="FormComponentFrame__input-container-fArle6 px-2 d-flex ai-center">
                        <section class="grow-1 text-body-2-c"><input
                                    class="px-2 TextField__input-xuVYYy text-subtitle w-100 TextField-cJQfI5 TextField--primary-cAI5H3"
                                    type="text" name="title" value="" style=" width: 98% !important; "></section>
                        <div></div>
                    </div>
                    <p class="text-body-2 color-n-500 text-body-2" data-testid="form-helper">طول متن می&zwnj;تواند حداقل
                        ۳ کاراکتر و حداکثر ۵۰ کاراکتر باشد</p></label></div>
            <div>
                <div class="text-body-1 color-n-700 d-flex ai-center jc-between"><p>متن درخواست <span
                                class="color-hint-text-error">*</span></p></div>
                <p class="text-body-2 color-n-500"></p><label
                        class="FormComponentFrame-sy77JE FormComponentFrame--normal-Tol9_4 w-100">
                    <div class="FormComponentFrame__input-container-fArle6 FormComponentFrame__input-container--textArea-cSHd6F px-2 d-flex ai-center p-2">
                        <section class="grow-1 text-body-2-c"><textarea
                                    class="px-1 TextField__textarea-n0jqnE text-subtitle w-100 TextField-cJQfI5 TextField--primary-cAI5H3"
                                    name="description" placeholder="چه درخواستی دارید؟" maxlength="500"
                                    rows="3"></textarea></section>
                        <div></div>
                    </div>
                    <p class="text-body-2 color-n-500 text-body-2" data-testid="form-helper">
                    <div class="d-flex jc-between"><p>طول متن می&zwnj;تواند حداقل ۱ کاراکتر و حداکثر ۵۰۰ کاراکتر
                            باشد</p>
                        <p class="align-left color-n-500 text-caption-strong shrink-0" id="fgjHD6">۵۰۰ / ۰</p></div>
                    </p></label></div>
            <div>
                <div class="text-body-1 color-n-700 d-flex ai-center mb-2"><p>پیوست </p>
                    <div class="pointer">
                        <div class="d-flex mr-1" data-testid="icon-wrapper">
                            <svg style="width: 16px; height: 16px; fill: var(--color-icon-low-emphasis);">
                                <use class="disable-events" xlink:href="#question"></use>
                            </svg>
                        </div>
                    </div>
                </div>
                <p class="text-body-2 color-n-500"></p>
                <div class="d-flex ai-center mb-4">
                    <div class="d-flex"><label class="d-flex">
                            <div class="radius-md d-flex flex-column jc-center ai-center FilesUploader__label-VQo2bY FilesUploader__label--primary-upDiCy"
                                 style="width: 120px; height: 120px;"><label
                                        class="relative d-flex ai-center user-select-none btn-wc51H8 text-button-2 btn--medium-WIacIB btn--text-se4oQM btn--primary-uiqWij radius Button__medium-gIvke_ Button__textPrimary-IWW5Sd FilesUploader__button-OiRDH5 Button-MNNP44"
                                        data-testid="button-wrapper">
                                    <div class="d-flex ai-center jc-center relative grow-1">
                                        <div class="d-flex" data-testid="icon-wrapper">
                                            <svg style="width: 24px; height: 24px; fill: var(--color-icon-high-emphasis);">
                                                <use class="disable-events" xlink:href="#add"></use>
                                            </svg>
                                        </div>
                                        <input type="file"
                                               accept=".xls,.xlsx,.mp4,.mov,.avi,.mpeg,.m4v,.wmv,.mpg,.jpeg,.gif,.png"
                                               class="d-none" name="attachments" multiple=""></div>
                                </label>
                                <p class="text-caption-strong align-center  color-brand-primary-500">بارگذاری</p></div>
                        </label></div>
                    <div class="color-n-500 mr-4"><p>شرایط فایل:</p>
                        <ul class="text-caption UnorderedList-gxEUdJ UnorderedList__withBullet--md-_R5lVr UnorderedList__withBullet-yZQFBT UnorderedList__disc-XqyU5z mt-3">
                            <li><p class="mr-1 mb-1">حجم کمتر از 6 مگابایت</p></li>
                            <li><span class="mr-1 mb-1">فرمت  xls, xlsx, mp4, mov,</span>
                                <div class="relative mb-1"><span
                                            class="mr-1 pointer CreationFileUploaderTooltip__tooltipText--default-QJ_h2P">و ۸ آیتم دیگر</span>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="pos-relative">
                    <div id="imagesLoadingSection" style="display: none;">
                        <ul id="imagesUploadList"></ul>
                    </div>
                    <div id="imagesSection" style="display: none;">
                        <ul id="imagesContainer"></ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>