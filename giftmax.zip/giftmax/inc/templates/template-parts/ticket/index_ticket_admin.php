<?php
use Giftmax\Modules\Db;

$id = get_query_var('id');
if($id){
    $ids = $id * 5 /10;
    $GETid =$ids;
    $db = Db::getLnstance();
    global $wpdb;
    global $wp;
    $user = wp_get_current_user();
    if ($GETid <= 0) {
        echo 'Invalid ticket ID.';
        exit;
    }

    $records = $db->query("SELECT t1.* FROM {$wpdb->prefix}ticket t1 WHERE t1.ticketId = :ticketId", array(
        'ticketId' => $GETid,
    ));
    $replies = $db->query("SELECT t2.* FROM {$wpdb->prefix}ticket t1 LEFT JOIN {$wpdb->prefix}ticket t2 ON t1.ticketId = t2.rep_Id WHERE t1.ticketId = :ticketId", array(
        'ticketId' => $GETid,
    ));
    ?>
    <input hidden="" name="id" value="<?=$id?>">
    <?php
    if(!IsMobile()){
        ?>
        <main class="c-content-layout Container-_0348a Container__desktop-_1c9a5">
            <main class="c-content-layout Container-_0348a Container__desktop-_1c9a5">
                <section class="d-flex ai-center mt-6 mb-3">
                    <h1 class="text-h5 color-text-heading">جزئیات درخواست</h1>
                    <span class="color-text-heading text-h5 mx-1">|</span>
                    <p class="text-body-2 color-text-low-emphasis">جزئیات درخواست خود را اینجا مشاهده کنید</p>
                </section>
                <div class="d-flex gap-x-4">
                    <div class="p-3 h-fit-content w-25 shrink-0 radius-lg bg-white border-complete">
                        <div class="pb-4 border-b">
                            <p class="text-body-2 color-n-600">عنوان درخواست</p>
                            <p class="text-subtitle-strong color-n-700"><?=$records[0]['Issue']?></p>
                        </div>
                        <div class="d-flex mt-4 pb-4 border-b">
                            <div class="w-50 shrink-0 border-l pl-3">
                                <p class="text-body-2 color-n-600">شماره درخواست</p>
                                <p class="text-subtitle-strong color-n-700">S-<?=$records[0]['ticketId']?></p>
                            </div>
                            <div class="w-50 shrink-0 pr-8"><p class="text-body-2 color-n-600">وضعیت</p>
                                <div class="text-subtitle-strong color-n-700">
                                    <?php
                                    if ($records[0]['condition'] == 0){
                                        $cls = 'Badge__info-st92ed';
                                        $nm = "جدید";
                                    }elseif ($records[0]['condition'] == 1){
                                        $cls = 'Badge__info-16f59';
                                        $nm = "درحال بررسی";
                                    }elseif ($records[0]['condition'] == 2){
                                        $cls = 'Badge__warning-MfubDgd';
                                        $nm = "در انتظار جزئیات";
                                    }elseif ($records[0]['condition'] == 3){
                                        $cls = 'Badge__success-AVxEpg';
                                        $nm = "حل شده";
                                    }elseif ($records[0]['condition'] == 4){
                                        $cls = 'Badge__neutral-XFzczo';
                                        $nm = "بسته شده";
                                    }
                                    ?>
                                    <div class="d-inline-flex ai-center <?=$cls?> text-no-wrap Badge-vPRt_1 Badge--medium-SregFw px-3 text-body2-strong"
                                         style="background-color: var(--color-undefined); color: var(--color-undefined);">
                                        <?=$nm?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php
                        if (is_numeric($records[0]['categoryId'])) {
                            $categorys = $db->query("SELECT * FROM  `{$wpdb->prefix}ticketing_category` WHERE `categoryId`=:id", array(
                                'id' => $records[0]['categoryId'],
                            ));
                            if (!empty($categorys[0]['subset'])) {
                                $subsets = $db->query("SELECT * FROM  `{$wpdb->prefix}ticketing_category` WHERE `categoryId`=:subset", array(
                                    'subset' => $categorys[0]['subset'],
                                ));
                            }
                        }else{
                            $categoryId = explode('|',decrypt_data($records[0]['categoryId']));
                            $categorys = [['name'=>"سفارش #".$categoryId[0]]];
                            $subsets = [['name'=>"سفارشات"]];
                        }
                        ?>
                        <?php
                        if (!empty($subsets[0]['name'])){
                            $gclas = "border-l";
                        }
                        ?>
                        <div class="d-flex mt-4 pb-4 border-b">
                            <div class="w-50 shrink-0 <?=$gclas?> pl-3"><p class="text-body-2 color-n-600">موضوع</p>
                                <p class="text-subtitle-strong color-n-700"><?=$categorys[0]['name']?></p></div>
                            <?php
                            if (!empty($subsets[0]['name'])){
                                ?>
                                <div class="w-50 shrink-0 pr-8"><p class="text-body-2 color-n-600">دسته&zwnj;بندی</p>
                                    <p class="text-subtitle-strong color-n-700"><?=$subsets[0]['name']?></p></div>
                            <?php }?>
                        </div>
                        <div class="d-flex mt-4 pb-4 border-b">
                            <?php $times = $db->query("SELECT t1.*, t2.*
FROM {$wpdb->prefix}ticket t1
LEFT JOIN {$wpdb->prefix}ticket t2 ON t1.ticketId = t2.rep_Id
WHERE t1.ticketId = :ticketId
ORDER BY t1.time DESC
LIMIT 1;",array('ticketId'=>$GETid)); ?>
                            <div class="w-50 shrink-0 border-l pl-3"><p class="text-body-2 color-n-600">آخرین به&zwnj;روزرسانی</p>
                                <p class="text-subtitle-strong color-n-700"><?=$times[0]['time'] ? gjdate($times[0]['time'],"d M Y، H:i") : ''?></p></div>
                            <div class="w-50 shrink-0 pr-8"><p class="text-body-2 color-n-600">تاریخ ثبت</p>
                                <p class="text-subtitle-strong color-n-700"><?=gjdate($records[0]['time'],"d M Y، H:i")?></p></div>
                        </div>
                        <?php
                        $userData = get_userdata($records[0]['userId']);
                        ?>
                        <div class="d-flex mt-4 pb-4">
                            <div class="w-50 shrink-0 border-l pl-3">
                                <p class="text-body-2 color-n-600">نام و نام خانوادگی</p>
                                <p class="text-subtitle-strong color-n-700">
                                    <?="$userData->first_name $userData->last_name"?>
                                </p>
                            </div>
                            <div class="w-50 shrink-0 pr-8">
                                <p class="text-body-2 color-n-600">شماره تلفن&zwnj;</p>
                                <p class="text-subtitle-strong color-n-700"><?=$userData->user_login?></p>
                            </div>
                        </div>
                    </div>
                    <div class="bg-white radius-lg p-5 grow-1 w-min-0 border-complete">
                        <div class="flex flex-col justify-between h-full">
                            <div>
                                <a href="<?=home_url( '/ticket' )?>" class="d-flex ai-center gap-x-2 border-b pb-6">
                                    <div class="d-flex pointer" data-testid="icon-wrapper">
                                        <svg style="width: 24px; height: 24px; fill: var(--color-icon-high-emphasis);">
                                            <use class="disable-events" xlink:href="#arrowBack"></use>
                                        </svg>
                                    </div>
                                    <p class="text-h5 color-n-700">پشتیبانی</p>
                                </a>
                                <div class="my-5 gap-y-5" style=" max-height: 42vh; overflow: auto; ">
                                    <?php
                                    if ($records === null) {
                                        echo 'No main record found.';
                                    } else {
                                        foreach ($records as $record) {
                                            ?>
                                            <div>
                                                <div class="d-flex jc-end gap-x-3 ai-end mb-3">
                                                    <div>
                                                        <div class="w-100 w-50-lg bg-n-100 py-2 px-4 color-n-600 text-subtitle radius-md whitespace-pre-line overflow-wrap-break"><?=$record['requestText']?>
                                                        </div>
                                                        <div class="d-flex flex-wrap">
                                                            <?php
                                                            if (!empty($record['attachment'])) {
                                                                $files = explode("|", $record['attachment']);
                                                                foreach ($files as $file) {
                                                                    $url_file_query = $db->query('SELECT * FROM ' . $wpdb->prefix . 'image WHERE `code` = :Id', array(
                                                                        'Id' => $file
                                                                    ));
                                                                    if (!empty($url_file_query)) {
                                                                        $file_url = $url_file_query[0]['url'];
                                                                        ?>
                                                                        <a href="<?=home_url('/') . rawurlencode($file_url) ?>" download="" target="_blank" rel="noreferrer">
                                                                            <div class="px-2 py-3 bg-primary-shade-8 radius-md color-brand-primary-700 text-subtitle pos-relative d-flex ai-center gap-x-2 DetailsUploadedFile__file-sc7oX8 pointer mt-2 ml-2">
                                                                                <div class="d-flex" data-testid="icon-wrapper">
                                                                                    <svg style="width: 24px; height: 24px; fill: var(--color-icon-primary);">
                                                                                        <use class="disable-events" xlink:href="#uploadExcel2"></use>
                                                                                    </svg>
                                                                                </div>
                                                                                <p class="ellipsis"><?= htmlspecialchars($file_url) ?></p>
                                                                            </div>
                                                                        </a>
                                                                        <?php
                                                                    }
                                                                }
                                                            }
                                                            ?>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <?php
                                        }
                                    }

                                    if ($replies === null) {
                                        echo 'No replies found.';
                                    } else {
                                        foreach ($replies as $reply) {
                                            if ($reply['ticketId'] !== null) {

                                                if ($reply['userId'] == $user->ID){
                                                    $classuser = "d-flex gap-x-3 ai-end mb-3";
                                                    $classtext = "w-50-lg bg-brand-primary-700 py-2 px-4 color-n-000 text-subtitle radius-md whitespace-pre-line overflow-wrap-break";
                                                }else{
                                                    $classuser = "d-flex jc-end gap-x-3 ai-end mb-3";
                                                    $classtext = "w-100 w-50-lg bg-n-100 py-2 px-4 color-n-600 text-subtitle radius-md whitespace-pre-line overflow-wrap-break";
                                                }
                                                ?>
                                                <div>
                                                    <div class="<?=$classuser?>">
                                                        <?php if ($reply['userId'] == $user->ID){?>
                                                            <div>
                                                                <div class="<?=$classtext?>"><?=$reply['requestText']?></div>
                                                                <div class="d-flex flex-wrap">
                                                                    <?php
                                                                    if (!empty($reply['attachment'])) {
                                                                        $files = explode("|", $reply['attachment']);
                                                                        foreach ($files as $file) {
                                                                            $url_file_query = $db->query('SELECT * FROM ' . $wpdb->prefix . 'image WHERE `code` = :Id', array(
                                                                                'Id' => $file
                                                                            ));
                                                                            if (!empty($url_file_query)) {
                                                                                $file_url = $url_file_query[0]['url'];
                                                                                ?>
                                                                                <a href="<?=home_url('/') . rawurlencode($file_url) ?>" download="" target="_blank" rel="noreferrer">
                                                                                    <div class="px-2 py-3 bg-primary-shade-8 radius-md color-brand-primary-700 text-subtitle pos-relative d-flex ai-center gap-x-2 DetailsUploadedFile__file-sc7oX8 pointer mt-2 ml-2">
                                                                                        <div class="d-flex" data-testid="icon-wrapper">
                                                                                            <svg style="width: 24px; height: 24px; fill: var(--color-icon-primary);">
                                                                                                <use class="disable-events" xlink:href="#uploadExcel2"></use>
                                                                                            </svg>
                                                                                        </div>
                                                                                        <p class="ellipsis"><?= htmlspecialchars($file_url) ?></p>
                                                                                    </div>
                                                                                </a>
                                                                                <?php
                                                                            }
                                                                        }
                                                                    }
                                                                    ?>
                                                                </div>
                                                            </div>
                                                        <?php }else{?>
                                                            <div>
                                                                <div class="<?=$classtext?>"><?=$reply['requestText']?></div>
                                                                <div class="d-flex flex-wrap">
                                                                    <?php
                                                                    if (!empty($reply['attachment'])) {
                                                                        $files = explode("|", $reply['attachment']);
                                                                        foreach ($files as $file) {
                                                                            $url_file_query = $db->query('SELECT * FROM ' . $wpdb->prefix . 'image WHERE `code` = :Id', array(
                                                                                'Id' => $file
                                                                            ));
                                                                            if (!empty($url_file_query)) {
                                                                                $file_url = $url_file_query[0]['url'];
                                                                                ?>
                                                                                <a href="<?=home_url('/') . rawurlencode($file_url) ?>" download="" target="_blank" rel="noreferrer">
                                                                                    <div class="px-2 py-3 bg-primary-shade-8 radius-md color-brand-primary-700 text-subtitle pos-relative d-flex ai-center gap-x-2 DetailsUploadedFile__file-sc7oX8 pointer mt-2 ml-2">
                                                                                        <div class="d-flex" data-testid="icon-wrapper">
                                                                                            <svg style="width: 24px; height: 24px; fill: var(--color-icon-primary);">
                                                                                                <use class="disable-events" xlink:href="#uploadExcel2"></use>
                                                                                            </svg>
                                                                                        </div>
                                                                                        <p class="ellipsis"><?= htmlspecialchars($file_url) ?></p>
                                                                                    </div>
                                                                                </a>
                                                                                <?php
                                                                            }
                                                                        }
                                                                    }
                                                                    ?>
                                                                </div>
                                                            </div>
                                                        <?php }?>
                                                    </div>
                                                </div>
                                                <?php
                                            }
                                        }
                                    }
                                    ?>

                                </div>
                            </div>
                            <div class="pt-4 border-t">
                                <form><label
                                            class="FormComponentFrame-sy77JE FormComponentFrame--normal-Tol9_4 w-100 DetailsTextField--border-CfkHHc"
                                            style="height: 64px;">
                                        <div class="FormComponentFrame__input-container-fArle6 px-2 d-flex ai-center DetailsTextField__input-gb43Kr">
                                            <section class="grow-1 text-body-2-c"><input class="px-2 TextField__input-xuVYYy text-subtitle w-100 TextField-cJQfI5 TextField--primary-cAI5H3"
                                                                                         type="text" name="body" placeholder="متن درخواست" maxlength="500" value="">
                                            </section>
                                            <div>
                                                <div class="d-flex gap-x-2">
                                                    <div>
                                                        <button class="relative d-flex ai-center user-select-none btn-wc51H8 text-button-1 btn--large-Gj4EdP btn--outlined-I96mhk btn--primary-uiqWij btn--icon-ZPHT4g radius Button__large-Zq9sTh Button__outlinedPrimary-V1OV6N Button__prependIcon-hh7768 Button-ufp13"
                                                                data-testid="button-wrapper">
                                                            <div class="d-flex ai-center jc-center relative grow-1">
                                                                <div class="d-flex px-1" data-testid="icon-wrapper">
                                                                    <svg data-testid="button-prepend-icon"
                                                                         style="width: 24px; height: 24px; fill: var(--color-icon-primary);">
                                                                        <use class="disable-events" xlink:href="#attach"></use>
                                                                    </svg>
                                                                </div>
                                                            </div>
                                                        </button>
                                                        <input type="file" hidden=""></div>
                                                    <button class="relative d-flex ai-center user-select-none btn-wc51H8 text-button-1 btn--large-Gj4EdP btn--primary-uiqWij radius Button__large-Zq9sTh Button__filledPrimary-OvgwGb Button__prependIcon-hh7768 Button-st95"
                                                            data-testid="button-wrapper">
                                                        <div class="d-flex ai-center jc-center relative grow-1">
                                                            <div class="d-flex ml-2" data-testid="icon-wrapper">
                                                                <svg data-testid="button-prepend-icon"
                                                                     style="width: 24px; height: 24px; fill: var(--color-icon-white);">
                                                                    <use class="disable-events" xlink:href="#submit"></use>
                                                                </svg>
                                                            </div>
                                                            ارسال
                                                        </div>
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    </label></form>
                                <p class="align-left color-n-500 text-caption-strong">۵۰۰ / ۰</p>
                                <?php
                                if ( in_array( 'administrator', (array) $user->roles ) ) {
                                    ?>
                                    <label for="status">وضعیت:</label>
                                    <select id="status" name="status">
                                        <option value="1">در حال بررسی</option>
                                        <option value="2">در انتظار جزئیات

                                        </option>
                                        <option value="3">حل شده

                                        </option>
                                        <option value="4">بسته شده

                                        </option>

                                    </select>
                                    <?php
                                }
                                ?>
                            </div>
                        </div>
                    </div>
                </div>
                <div>

                </div>
            </main>
        </main>

        <?php
    }
    else{
        $categorys = $db->query("SELECT * FROM  `{$wpdb->prefix}ticketing_category` WHERE `categoryId`=:id", array(
            'id' => $records[0]['categoryId'],
        ));
        if (is_numeric($records[0]['categoryId'])) {
            $categorys = $db->query("SELECT * FROM  `{$wpdb->prefix}ticketing_category` WHERE `categoryId`=:id", array(
                    'id' => $records[0]['categoryId'],
            ));
            if (!empty($categorys[0]['subset'])) {
                $subsets = $db->query("SELECT * FROM  `{$wpdb->prefix}ticketing_category` WHERE `categoryId`=:subset", array(
                        'subset' => $categorys[0]['subset'],
                ));
            }
        }else{
            $categoryId = explode('|',decrypt_data($records[0]['categoryId']));
            $categorys = [['name'=>"سفارش #".$categoryId[0]]];
            $subsets = [['name'=>"سفارشات"]];
        }
        $times = $db->query("SELECT t1.*, t2.*
FROM {$wpdb->prefix}ticket t1
LEFT JOIN {$wpdb->prefix}ticket t2 ON t1.ticketId = t2.rep_Id
WHERE t1.ticketId = :ticketId
ORDER BY t1.time DESC
LIMIT 1;",array('ticketId'=>$GETid));
        $userData = get_userdata($records[0]['userId']);
        $processedData[] = ['record' => $records,'rtimes'=>$records[0]['time'] ? gjdate($records[0]['time'],"d M Y، H:i") : '', 'subsets' => $subsets, 'category' => $categorys,'times'=>$times[0]['time'] ? gjdate($times[0]['time'],"d M Y، H:i") : '','fullName'=>$userData->first_name . ' ' . $userData->last_name,'phoneNumber'=>$userData->user_login];
        $jsonData = json_encode($processedData, JSON_UNESCAPED_UNICODE);
        ?>
        <main class="Container-ir55aD Container__mobile-RpCEHF">
        <script id="script-TS8">
            jQuery(function($){
                window.initializeScripts(<?php echo json_encode($jsonData); ?>);
            })
        </script>
        <style>
            .FilterChips__cardBodyDesktop-FZT9Y2{
                max-height: 430px;
            }
        </style>
        <div>
        <div class="CommonHeader-Jfqu94 pos-sticky top-0 d-flex jc-between ai-center px-5 py-3 bg-white z-1">
            <div class="d-flex ai-center">
                <button onclick="window.location.href='<?=home_url( '/ticket' )?>'" class="relative d-flex ai-center user-select-none btn-wc51H8 text-button-2 btn--text-se4oQM btn--primary-uiqWij btn--icon-ZPHT4g radius Button__medium-gIvke_ Button__textPrimary-IWW5Sd Button__prependIcon-hh7768 IconButton__button-RRc2H_ Button-MNNP44"
                        data-testid="button-wrapper" type="button">
                    <div class="d-flex ai-center jc-center relative grow-1">
                        <div class="d-flex IconButton__prependIcon-mxVR2M p-2" data-testid="icon-wrapper">
                            <svg data-testid="button-prepend-icon"
                                 style="width: 24px; height: 24px; fill: var(--color-icon-neutral-000);">
                                <use class="disable-events" xlink:href="#arrowBack"></use>
                            </svg>
                        </div>
                    </div>
                </button>
                <p class="mr-4 text-h4">جزئیات درخواست</p></div>
            <div></div>
        </div>
        <div class="mt-5 bg-white" style="padding-bottom: 20px;">
            <div class="d-flex ai-center jc-between pr-5 py-5 border-b"><p class="text-h5 color-900">پشتیبانی</p>
                <button class="relative d-flex ai-center user-select-none btn-wc51H8 text-button-2 btn--text-se4oQM btn--primary-uiqWij radius Button__medium-gIvke_ Button__textPrimary-IWW5Sd Button__appendIcon-U8Sah0 Button-TS8" data-testid="button-wrapper">
                    <div class="d-flex ai-center jc-center relative grow-1">جزئیات بیشتر
                        <div class="d-flex mr-2" data-testid="icon-wrapper">
                            <svg data-testid="button-append-icon"
                                 style="width: 24px; height: 24px; fill: var(--color-icon-primary);">
                                <use class="disable-events" xlink:href="#chevronLeft2"></use>
                            </svg>
                        </div>
                    </div>
                </button>
            </div>
            <div class="px-3 mt-5" style="max-height: 80vh;overflow: auto;">
                <?php
                if ($records === null) {
                    echo 'No main record found.';
                } else {
                    foreach ($records as $record) {
                        ?>
                        <div>
                            <div class="d-flex jc-end gap-x-3 ai-end mb-3">
                                <div>
                                    <div class="w-100 w-50-lg bg-n-100 py-2 px-4 color-n-600 text-subtitle radius-md whitespace-pre-line overflow-wrap-break"><?=$record['requestText']?>
                                    </div>
                                    <div class="d-flex flex-wrap">
                                        <?php
                                        if (!empty($record['attachment'])) {
                                            $files = explode("|", $record['attachment']);
                                            foreach ($files as $file) {
                                                $url_file_query = $db->query('SELECT * FROM ' . $wpdb->prefix . 'image WHERE `code` = :Id', array(
                                                    'Id' => $file
                                                ));
                                                if (!empty($url_file_query)) {
                                                    $file_url = $url_file_query[0]['url'];
                                                    ?>
                                                    <a href="<?=home_url('/') . rawurlencode($file_url) ?>" download="" target="_blank" rel="noreferrer">
                                                        <div class="px-2 py-3 bg-primary-shade-8 radius-md color-brand-primary-700 text-subtitle pos-relative d-flex ai-center gap-x-2 DetailsUploadedFile__file-sc7oX8 pointer mt-2 ml-2">
                                                            <div class="d-flex" data-testid="icon-wrapper">
                                                                <svg style="width: 24px; height: 24px; fill: var(--color-icon-primary);">
                                                                    <use class="disable-events" xlink:href="#uploadExcel2"></use>
                                                                </svg>
                                                            </div>
                                                            <p class="ellipsis"><?= htmlspecialchars($file_url) ?></p>
                                                        </div>
                                                    </a>
                                                    <?php
                                                }
                                            }
                                        }
                                        ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php
                    }
                }

                if ($replies === null) {
                    echo 'No replies found.';
                } else {
                    foreach ($replies as $reply) {
                        if ($reply['ticketId'] !== null) {

                            if ($reply['userId'] == $user->ID){
                                $classuser = "d-flex gap-x-3 ai-end mb-3";
                                $classtext = "w-50-lg bg-brand-primary-700 py-2 px-4 color-n-000 text-subtitle radius-md whitespace-pre-line overflow-wrap-break";
                            }else{
                                $classuser = "d-flex jc-end gap-x-3 ai-end mb-3";
                                $classtext = "w-100 w-50-lg bg-n-100 py-2 px-4 color-n-600 text-subtitle radius-md whitespace-pre-line overflow-wrap-break";
                            }
                            ?>
                            <div>
                                <div class="<?=$classuser?>">
                                    <?php if ($reply['userId'] == $user->ID){?>
                                        <div>
                                            <div class="<?=$classtext?>"><?=$reply['requestText']?></div>
                                            <div class="d-flex flex-wrap">
                                                <?php
                                                if (!empty($reply['attachment'])) {
                                                    $files = explode("|", $reply['attachment']);
                                                    foreach ($files as $file) {
                                                        $url_file_query = $db->query('SELECT * FROM ' . $wpdb->prefix . 'image WHERE `code` = :Id', array(
                                                            'Id' => $file
                                                        ));
                                                        if (!empty($url_file_query)) {
                                                            $file_url = $url_file_query[0]['url'];
                                                            ?>
                                                            <a href="<?=home_url('/') . rawurlencode($file_url) ?>" download="" target="_blank" rel="noreferrer">
                                                                <div class="px-2 py-3 bg-primary-shade-8 radius-md color-brand-primary-700 text-subtitle pos-relative d-flex ai-center gap-x-2 DetailsUploadedFile__file-sc7oX8 pointer mt-2 ml-2">
                                                                    <div class="d-flex" data-testid="icon-wrapper">
                                                                        <svg style="width: 24px; height: 24px; fill: var(--color-icon-primary);">
                                                                            <use class="disable-events" xlink:href="#uploadExcel2"></use>
                                                                        </svg>
                                                                    </div>
                                                                    <p class="ellipsis"><?= htmlspecialchars($file_url) ?></p>
                                                                </div>
                                                            </a>
                                                            <?php
                                                        }
                                                    }
                                                }
                                                ?>
                                            </div>
                                        </div>
                                    <?php }else{?>
                                        <div>
                                            <div class="<?=$classtext?>"><?=$reply['requestText']?></div>
                                            <div class="d-flex flex-wrap">
                                                <?php
                                                if (!empty($reply['attachment'])) {
                                                    $files = explode("|", $reply['attachment']);
                                                    foreach ($files as $file) {
                                                        $url_file_query = $db->query('SELECT * FROM ' . $wpdb->prefix . 'image WHERE `code` = :Id', array(
                                                            'Id' => $file
                                                        ));
                                                        if (!empty($url_file_query)) {
                                                            $file_url = $url_file_query[0]['url'];
                                                            ?>
                                                            <a href="<?=home_url('/') . rawurlencode($file_url) ?>" download="" target="_blank" rel="noreferrer">
                                                                <div class="px-2 py-3 bg-primary-shade-8 radius-md color-brand-primary-700 text-subtitle pos-relative d-flex ai-center gap-x-2 DetailsUploadedFile__file-sc7oX8 pointer mt-2 ml-2">
                                                                    <div class="d-flex" data-testid="icon-wrapper">
                                                                        <svg style="width: 24px; height: 24px; fill: var(--color-icon-primary);">
                                                                            <use class="disable-events" xlink:href="#uploadExcel2"></use>
                                                                        </svg>
                                                                    </div>
                                                                    <p class="ellipsis"><?= htmlspecialchars($file_url) ?></p>
                                                                </div>
                                                            </a>
                                                            <?php
                                                        }
                                                    }
                                                }
                                                ?>
                                            </div>
                                        </div>
                                    <?php }?>
                                </div>
                            </div>
                            <?php
                        }
                    }
                }
                ?>
            </div>
        </div>
        <?php
        if($records[0]['condition'] != 4){
            ?>
            <div class="pt-4 border-t p-3 bg-white">
                <form><label
                            class="FormComponentFrame-sy77JE FormComponentFrame--normal-Tol9_4 w-100 DetailsTextField--border-CfkHHc"
                            style="height: 64px;">
                        <div class="FormComponentFrame__input-container-fArle6 px-2 d-flex ai-center DetailsTextField__input-gb43Kr">
                            <section class="grow-1 text-body-2-c"><input class="px-2 TextField__input-xuVYYy text-subtitle w-100 TextField-cJQfI5 TextField--primary-cAI5H3"
                                                                         type="text" name="body" placeholder="متن درخواست" maxlength="500" value="">
                            </section>
                            <div>
                                <div class="d-flex gap-x-2">
                                    <div>
                                        <button class="relative d-flex ai-center user-select-none btn-wc51H8 text-button-1 btn--large-Gj4EdP btn--outlined-I96mhk btn--primary-uiqWij btn--icon-ZPHT4g radius Button__large-Zq9sTh Button__outlinedPrimary-V1OV6N Button__prependIcon-hh7768 Button-ufp13"
                                                data-testid="button-wrapper">
                                            <div class="d-flex ai-center jc-center relative grow-1">
                                                <div class="d-flex px-1" data-testid="icon-wrapper">
                                                    <svg data-testid="button-prepend-icon"
                                                         style="width: 24px; height: 24px; fill: var(--color-icon-primary);">
                                                        <use class="disable-events" xlink:href="#attach"></use>
                                                    </svg>
                                                </div>
                                            </div>
                                        </button>
                                        <input type="file" hidden=""></div>
                                    <button class="relative d-flex ai-center user-select-none btn-wc51H8 text-button-1 btn--large-Gj4EdP btn--primary-uiqWij radius Button__large-Zq9sTh Button__filledPrimary-OvgwGb Button__prependIcon-hh7768 Button-st95"
                                            data-testid="button-wrapper">
                                        <div class="d-flex ai-center jc-center relative grow-1">
                                            <div class="d-flex ml-2" data-testid="icon-wrapper">
                                                <svg data-testid="button-prepend-icon"
                                                     style="width: 24px; height: 24px; fill: var(--color-icon-white);">
                                                    <use class="disable-events" xlink:href="#submit"></use>
                                                </svg>
                                            </div>
                                            ارسال
                                        </div>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </label></form>
                <p class="align-left color-n-500 text-caption-strong">۵۰۰ / ۰</p>
                <?php
                if ( in_array( 'administrator', (array) $user->roles ) ) {
                    ?>
                    <label for="status">وضعیت:</label>
                    <select id="status" name="status">
                        <option value="1">در حال بررسی</option>
                        <option value="2">در انتظار جزئیات

                        </option>
                        <option value="3">حل شده

                        </option>
                        <option value="4">بسته شده

                        </option>

                    </select>
                    <?php
                }
                ?>
            </div>
            <?php
        }else{
            ?>
            <div class="border-t py-3 pos-fixed bottom-0 left-0 bg-white px-5 z-11 w-100">
                <div class="radius Hint__iconStart-bpg5ZO" data-testid="hint-wrapper">
                    <div class="d-flex ai-center">
                        <div class="d-flex Hint__titleSlot-yPP6H0" data-testid="icon-wrapper">
                            <svg style="width: 24px; height: 24px; fill: var(--color-icon-neutral-hint);">
                                <use class="disable-events" xlink:href="#info"></use>
                            </svg>
                        </div>
                        <span class="mr-2 text-body-1 color-600">فرایند این درخواست به پایان رسیده. اگر درخواست دیگری دارید، دوباره درخواست ثبت کنید</span>
                    </div>
                </div>
            </div>
            </div>
            </main>
            <?php
        }
    }
}
?>
<div id="modal-root"><div class="absolute"></div></div>
<div id="popper-root"><div class="absolute"><div id="snackbar-container" class="pos-fixed d-flex flex-column my-3 px-4 jc-center Snackbar__container-_86cf8 bottom-0 left-1/2 -translate-x-1/2 z-999999" style="left: 50%; transform: translateX(-50%); width: 320px;"></div></div></div>
