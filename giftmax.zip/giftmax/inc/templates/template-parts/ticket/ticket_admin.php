<?php
function countStatus($status)
{
    $db = \Giftmax\modules\Db::getLnstance();
    global $wpdb;
    $user = wp_get_current_user();
    $records = $db->query("SELECT COUNT(*) as count FROM  {$wpdb->prefix}ticket WHERE `condition`=$status ");
    return $records[0]['count'];
}
if(!IsMobile()){
    ?>
    <main class="Container-_0348a container-2xl-w mx-auto">
            <section class="d-flex ai-center mt-6 mb-3"><h1 class="text-h5 color-text-heading">درخواست&zwnj;های شما</h1><span
                        class="color-text-heading text-h5 mx-1">|</span>
                <p class="text-body-2 color-text-low-emphasis">اینجا می&zwnj;توانید همه درخواست&zwnj;های پشتیبانی خود را ببینید</p>
            </section>
            <div class="bg-n-000 radius-md py-4 pr-6 px-6-lg mb-4-lg mt-8-lg">
                <p class="text-body-1 color-text-heading" style="margin-bottom: 5px !important;">وضعیت درخواست&zwnj;های شما</p>
                <div class="d-grid gap-x-3" style="grid-template-columns: repeat(7, 1fr);">
                    <div class="border rounded-full px-4 py-3 d-flex jc-between ai-center TicketStatus__box-DPr7o0">
                        <div class="d-flex ai-center gap-x-2">
                            <div class="rounded-circle p-1 shrink-0 TicketStatus__icon--primary-cZbGbT">
                                <div class="d-flex" data-testid="icon-wrapper">
                                    <svg style="width: 24px; height: 24px; fill: var(--color-icon-primary);">
                                        <use class="disable-events" xlink:href="#discount"></use>
                                    </svg>
                                </div>
                            </div>
                            <div class="pl-3"><p class="text-body1-strong compact color-text-heading whitespace-nowrap">جدید</p>
                                <p class="text-caption-strong compact mt-1 TicketStatus__text--primary-_tF1Uz"><?=countStatus(0)?> عدد</p></div>
                        </div>
                    </div>
                    <div class="border rounded-full px-4 py-3 d-flex jc-between ai-center TicketStatus__box-DPr7o0">
                        <div class="d-flex ai-center gap-x-2">
                            <div class="rounded-circle p-1 shrink-0 TicketStatus__icon--secondary-UaV53P">
                                <div class="d-flex" data-testid="icon-wrapper">
                                    <svg style="width: 24px; height: 24px; fill: var(--color-icon-secondary);">
                                        <use class="disable-events" xlink:href="#discount"></use>
                                    </svg>
                                </div>
                            </div>
                            <div class="pl-3"><p class="text-body1-strong compact color-text-heading whitespace-nowrap">در حال
                                    بررسی </p>
                                <p class="text-caption-strong compact mt-1 TicketStatus__text--secondary-VGBgYW"><?=countStatus(1)?> عدد</p></div>
                        </div>
                    </div>
                    <div class="border rounded-full px-4 py-3 d-flex jc-between ai-center TicketStatus__box-DPr7o0">
                        <div class="d-flex ai-center gap-x-2">
                            <div class="rounded-circle p-1 shrink-0 TicketStatus__icon--warning-R7aJKw">
                                <div class="d-flex" data-testid="icon-wrapper">
                                    <svg style="width: 24px; height: 24px; fill: var(--color-icon-warning);">
                                        <use class="disable-events" xlink:href="#discount"></use>
                                    </svg>
                                </div>
                            </div>
                            <div class="pl-3"><p class="text-body1-strong compact color-text-heading whitespace-nowrap">در انتظار
                                    جزئیات</p>
                                <p class="text-caption-strong compact mt-1 TicketStatus__text--warning-uS8Lmo"><?=countStatus(2)?> عدد</p></div>
                        </div>
                    </div>
                    <div class="border rounded-full px-4 py-3 d-flex jc-between ai-center TicketStatus__box-DPr7o0">
                        <div class="d-flex ai-center gap-x-2">
                            <div class="rounded-circle p-1 shrink-0 TicketStatus__icon--success-ewM8LZ">
                                <div class="d-flex" data-testid="icon-wrapper">
                                    <svg style="width: 24px; height: 24px; fill: var(--color-icon-success);">
                                        <use class="disable-events" xlink:href="#discount"></use>
                                    </svg>
                                </div>
                            </div>
                            <div class="pl-3"><p class="text-body1-strong compact color-text-heading whitespace-nowrap">حل شده</p>
                                <p class="text-caption-strong compact mt-1 TicketStatus__text--success-v67u62"><?=countStatus(3)?> عدد</p></div>
                        </div>
                    </div>
                    <div class="border rounded-full px-4 py-3 d-flex jc-between ai-center TicketStatus__box-DPr7o0 ml-6 ml-0-lg">
                        <div class="d-flex ai-center gap-x-2">
                            <div class="rounded-circle p-1 shrink-0 TicketStatus__icon--high-emphasis-UuuZGu">
                                <div class="d-flex" data-testid="icon-wrapper">
                                    <svg style="width: 24px; height: 24px; fill: var(--color-icon-high-emphasis);">
                                        <use class="disable-events" xlink:href="#discount"></use>
                                    </svg>
                                </div>
                            </div>
                            <div class="pl-3"><p class="text-body1-strong compact color-text-heading whitespace-nowrap">بسته شده</p>
                                <p class="text-caption-strong compact mt-1 TicketStatus__text--high-emphasis-2_Dt_F"><?=countStatus(4)?> عدد</p></div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="">
                <div class="TableCard__desktop-VytQYw">
                    <section class="TableCard--filterMobile-wBInUm TableCard--filterMobile--space-NeTjOU">
                        <form>
                        </form>
                    </section>
                    <div class="d-flex ai-center flex-wrap w-100 TableHeadAction--desktop-kkHIe5 mb-4">
                        <div class="d-flex flex-1 gap-x-4 ai-center"><a>
                                <button class="relative d-flex ai-center user-select-none btn-wc51H8 text-button-2 btn--medium-WIacIB btn--primary-uiqWij radius Button__medium-gIvke_ Button__filledPrimary-OvgwGb Button__prependIcon-hh7768 Button-ADC" data-testid="button-wrapper">
                                    <div class="d-flex ai-center jc-center relative grow-1">
                                        <div class="d-flex ml-2" data-testid="icon-wrapper">
                                            <svg data-testid="button-prepend-icon"
                                                 style="width: 24px; height: 24px; fill: var(--color-icon-white);">
                                                <use class="disable-events" xlink:href="#addInput"></use>
                                            </svg>
                                        </div>
                                        اضافه کردن دسته بندی
                                    </div>
                                </button>
                            </a></div>
                        <div class="Container-A34iFV d-flex ai-center jc-end ">
                            <?php
                            $db = \Giftmax\modules\Db::getLnstance();
                            global $wpdb;
                            $user = wp_get_current_user();
                            $records = $db->query("SELECT * FROM  {$wpdb->prefix}ticket WHERE rep_Id IS NULL ORDER BY `ticketId` DESC LIMIT 0, 10");
                            if (!empty($records)){
                                $pageCount = $db->query("SELECT COUNT(*) AS total FROM  {$wpdb->prefix}ticket WHERE rep_Id IS NULL");
                                $count = $pageCount[0]['total'];
                            }else{
                                $count = 0;
                            }
                            ?>
                            <div><span class="pl-1 color-text-low-emphasis text-body-1">تعداد نتایج:</span><span
                                        class="color-text-high-emphasis text-body1-strong"><?=$count?></span></div>
                            <span class="Pipe-WoSKRy mx-3"></span>
                        </div>
                    </div>
                    <?php
                    if (!empty($records)){
                        ?>
                        <section class="p-5 TableCard--bodyMobile-tDS3OZ">
                            <div class="d-flex jc-between ai-center mb-4 TableHeadAction--mobile-tuX2bW"><p
                                        class="color-n-500 text-body1-strong">لیست درخواست&zwnj;ها</p>
                                <p class="color-n-500 text-body-2"><?=$count?> عدد</p></div>
                            <section class="mb-10 mb-0-lg">
                                <section class="ai-center py-2 px-4 Container-urgKXv " style="grid-template-columns: 0.4fr 0.8fr 1.3fr 1.3fr 0.6fr 0.8fr 0.7fr 0.7fr;">
                                    <div class="text-body1-strong pr-2 pl-2 color-n-700 d-flex flex-column ai-start jc-center">
                                        ردیف
                                    </div>
                                    <div class="text-body1-strong pr-2 pl-2 color-n-700 d-flex flex-column ai-start jc-center">
                                        شماره درخواست
                                    </div>
                                    <div class="text-body1-strong pr-2 pl-2 color-n-700 d-flex flex-column ai-start jc-center">
                                        عنوان
                                    </div>
                                    <div class="text-body1-strong pr-2 pl-2 color-n-700 d-flex flex-column ai-start jc-center">
                                        موضوع درخواست
                                    </div>
                                    <div class="text-body1-strong pr-2 pl-2 color-n-700 d-flex flex-column ai-start jc-center">
                                        تاریخ ثبت
                                    </div>
                                    <div class="text-body1-strong pr-2 pl-2 color-n-700 d-flex flex-column ai-start jc-center">
                                        آخرین به&zwnj;روزرسانی
                                    </div>
                                    <div class="text-body1-strong pr-2 pl-2 color-n-700 d-flex flex-column ai-start jc-center">
                                        وضعیت درخواست
                                    </div>
                                    <div class="text-body1-strong pr-2 pl-2 color-n-700 d-flex flex-column ai-start jc-center"></div>
                                </section>
                                <div>
                                    <section>
                                        <?php
                                        foreach ($records as $key=>$record){
                                            if (is_numeric($record['categoryId'])) {
                                                $categorys = $db->query("SELECT * FROM  `{$wpdb->prefix}ticketing_category` WHERE `categoryId`=:id", array(
                                                    'id' => $record['categoryId'],
                                                ));
                                            }else{
                                                $categoryId = explode('|',decrypt_data($record['categoryId']));
                                                $categorys = [['name'=>"سفارش #".$categoryId[0]]];
                                            }
                                            ?>

                                            <section
                                                    class="TableRowContainer__normal-Uv6APM py-2 px-4 my-3 d-grid TableRowDesktop-xIiuFo rounded-full">
                                                <div class="d-grid py-1"
                                                     style="grid-template-columns: 0.4fr 0.8fr 1.3fr 1.3fr 0.6fr 0.8fr 0.7fr 0.7fr;">
                                                    <div class="pr-2 pl-2 text-body-1 d-flex ai-center color-text-high-emphasis mt-1 gap-x-2">
                                                        <div class="pr-2 pl-2 text-body-1 d-flex ai-center color-text-high-emphasis color-text-low-emphasis">
                                                            <?=$key+1?>
                                                        </div>
                                                    </div>
                                                    <div class="pr-2 pl-2 text-body-1 d-flex ai-center color-text-high-emphasis">
                                                        S-<?=$record['ticketId']?>
                                                    </div>
                                                    <div class="pr-2 pl-2 text-body-1 d-flex ai-center color-text-high-emphasis ellipsis-1">
                                                        <?=$record['Issue']?>
                                                    </div>
                                                    <div class="pr-2 pl-2 text-body-1 d-flex ai-center color-text-high-emphasis">
                                                        <?=$categorys[0]['name']?>
                                                    </div>
                                                    <div class="pr-2 pl-2 text-body-1 d-flex ai-center color-text-high-emphasis">
                                                        <?=gjdate($record['time'],"Y-m-d")?>
                                                    </div>
                                                    <?php $times = $db->query("SELECT t1.*, t2.*
FROM {$wpdb->prefix}ticket t1
LEFT JOIN {$wpdb->prefix}ticket t2 ON t1.ticketId = t2.rep_Id
WHERE t1.ticketId = :ticketId
ORDER BY t1.time DESC
LIMIT 1;",array('ticketId'=>$record['ticketId'])); ?>
                                                    <div class="pr-2 pl-2 text-body-1 d-flex ai-center color-text-high-emphasis">
                                                        <?=!empty($times[0]['time']) ? gjdate($times[0]['time'],"H:i - Y-m-d") : "-"?>
                                                    </div>
                                                    <div class="pr-2 pl-2 text-body-1 d-flex ai-center color-text-high-emphasis">
                                                        <?php
                                                        if ($record['condition'] == 0){
                                                            $cls = 'Badge__info-st92ed';
                                                            $nm = "جدید";
                                                        }elseif ($record['condition'] == 1){
                                                            $cls = 'Badge__info-16f59';
                                                            $nm = "درحال بررسی";
                                                        }elseif ($record['condition'] == 2){
                                                            $cls = 'Badge__warning-MfubDgd';
                                                            $nm = "در انتظار جزئیات";
                                                        }elseif ($record['condition'] == 3){
                                                            $cls = 'Badge__success-AVxEpg';
                                                            $nm = "حل شده";
                                                        }elseif ($record['condition'] == 4){
                                                            $cls = 'Badge__neutral-XFzczo';
                                                            $nm = "بسته شده";
                                                        }
                                                        ?>
                                                        <div class="d-inline-flex ai-center <?=$cls?> text-no-wrap Badge-vPRt_1 Badge--medium-SregFw px-3 text-body2-strong"
                                                             style="background-color: var(--color-undefined); color: var(--color-undefined);">
                                                            <?=$nm?>
                                                        </div>
                                                    </div>
                                                    <div class="pr-2 pl-2 text-body-1 d-flex ai-center color-text-high-emphasis justify-end">
                                                        <?php $gid = ($record['ticketId']) * 10 / 5?>
                                                        <a
                                                                href="<?=esc_url( get_permalink() )?>id/<?=$gid?>">
                                                            <button class="relative d-flex ai-center user-select-none btn-wc51H8 text-button-2 btn--outlined-I96mhk btn--primary-uiqWij rounded-full Button__medium-gIvke_ Button__outlinedPrimary-V1OV6N Button-MNNP44"
                                                                    data-testid="button-wrapper">
                                                                <div class="d-flex ai-center jc-center relative grow-1">مشاهده
                                                                    تیکت
                                                                </div>
                                                            </button>
                                                        </a></div>
                                                </div>
                                            </section>
                                            <?php
                                        }
                                echo '<div class="flex justify-end"><div class="v10__Pagination">';
                                for ($i = 1; $i <= 3; $i++) {
                                    if ($i < 1){
                                        continue;
                                    }
                                    if ($i>ceil($count/10)){continue;}
                                    if (1 == $i){
                                        echo '<button class="v10__Pagination-item Button-np52 active">' . $i . '</button>';
                                    }else {
                                        echo '<button class="v10__Pagination-item Button-np52" data-page="' . $i . '">' . $i . '</button>';
                                    }
                                }
                                echo '</div></div> ';
                                ?>
                                    </section>
                                </div>
                            </section>
                        </section>
                        <?php
                    }else{
                        ?>
                        <section class="p-5 TableCard--bodyMobile-tDS3OZ">
                            <div class="d-flex ai-center jc-center align-center w-100 h-100">
                                <div class="py-4 d-flex flex-column jc-center ai-center EmptyState__desktopContainer-ggZkIg">
                                    <div class="d-flex jc-center mb-3" data-testid="empty-src">
                                        <div data-testid="image-wrapper" style="width: 200px; height: 150px;"><img class="w-100"
                                                                                                                   src="<?=get_template_directory_uri()?>/assets/img/ticket_img.png"
                                                                                                                   width="200"
                                                                                                                   height="150"
                                                                                                                   data-testid="image-defaultImage"
                                                                                                                   style="object-fit: contain;">
                                        </div>
                                    </div>
                                    <div class="text-h5 color-900">نتیجه&zwnj;ای پیدا نکردیم...</div>
                                    <div class="text-caption-strong color-500" data-testid="empty-description">
                                        <div>فیلترها را تغییر دهید و دوباره امتحان کنید</div>
                                    </div>
                                </div>
                            </div>
                        </section>
                    <?php }?>
                </div>
            </div>
            <div></div>
        </main>
    <?php
}else{
    ?>
    <div class="bg-dark ">
        <main class="Container-ir55aD Container__mobile-RpCEHF">
            <div class="bg-n-000 radius-md py-4 pr-6 px-6-lg mb-4-lg mt-8-lg">
                <p class="text-body-1 color-text-heading" style="margin-bottom: 20px !important;">وضعیت درخواست&zwnj;های شما</p>
                <div class="d-grid gap-x-3 overflow-x-scroll" style="grid-template-columns: repeat(5, 1fr);">
                    <div class="border rounded-full px-4 py-3 d-flex jc-between ai-center TicketStatus__box-DPr7o0 mr-0">
                        <div class="d-flex ai-center gap-x-2">
                            <div class="rounded-circle p-1 shrink-0 TicketStatus__icon--primary-cZbGbT">
                                <div class="d-flex" data-testid="icon-wrapper">
                                    <svg style="width: 24px; height: 24px; fill: var(--color-icon-primary);">
                                        <use class="disable-events" xlink:href="#discount"></use>
                                    </svg>
                                </div>
                            </div>
                            <div class="pl-3"><p class="text-body1-strong compact color-text-heading whitespace-nowrap">جدید</p>
                                <p class="text-caption-strong compact mt-1 TicketStatus__text--primary-_tF1Uz"><?=countStatus(0)?> عدد</p></div>
                        </div>
                    </div>
                    <div class="border rounded-full px-4 py-3 d-flex jc-between ai-center TicketStatus__box-DPr7o0 mr-0">
                        <div class="d-flex ai-center gap-x-2">
                            <div class="rounded-circle p-1 shrink-0 TicketStatus__icon--secondary-UaV53P">
                                <div class="d-flex" data-testid="icon-wrapper">
                                    <svg style="width: 24px; height: 24px; fill: var(--color-icon-secondary);">
                                        <use class="disable-events" xlink:href="#discount"></use>
                                    </svg>
                                </div>
                            </div>
                            <div class="pl-3"><p class="text-body1-strong compact color-text-heading whitespace-nowrap">در حال
                                    بررسی </p>
                                <p class="text-caption-strong compact mt-1 TicketStatus__text--secondary-VGBgYW"><?=countStatus(1)?> عدد</p></div>
                        </div>
                    </div>
                    <div class="border rounded-full px-4 py-3 d-flex jc-between ai-center TicketStatus__box-DPr7o0 mr-0">
                        <div class="d-flex ai-center gap-x-2">
                            <div class="rounded-circle p-1 shrink-0 TicketStatus__icon--warning-R7aJKw">
                                <div class="d-flex" data-testid="icon-wrapper">
                                    <svg style="width: 24px; height: 24px; fill: var(--color-icon-warning);">
                                        <use class="disable-events" xlink:href="#discount"></use>
                                    </svg>
                                </div>
                            </div>
                            <div class="pl-3"><p class="text-body1-strong compact color-text-heading whitespace-nowrap">در انتظار
                                    جزئیات</p>
                                <p class="text-caption-strong compact mt-1 TicketStatus__text--warning-uS8Lmo"><?=countStatus(2)?> عدد</p></div>
                        </div>
                    </div>
                    <div class="border rounded-full px-4 py-3 d-flex jc-between ai-center TicketStatus__box-DPr7o0 mr-0">
                        <div class="d-flex ai-center gap-x-2">
                            <div class="rounded-circle p-1 shrink-0 TicketStatus__icon--success-ewM8LZ">
                                <div class="d-flex" data-testid="icon-wrapper">
                                    <svg style="width: 24px; height: 24px; fill: var(--color-icon-success);">
                                        <use class="disable-events" xlink:href="#discount"></use>
                                    </svg>
                                </div>
                            </div>
                            <div class="pl-3"><p class="text-body1-strong compact color-text-heading whitespace-nowrap">حل شده</p>
                                <p class="text-caption-strong compact mt-1 TicketStatus__text--success-v67u62"><?=countStatus(3)?> عدد</p></div>
                        </div>
                    </div>
                    <div class="border rounded-full px-4 py-3 d-flex jc-between ai-center TicketStatus__box-DPr7o0 mr-0">
                        <div class="d-flex ai-center gap-x-2">
                            <div class="rounded-circle p-1 shrink-0 TicketStatus__icon--high-emphasis-UuuZGu">
                                <div class="d-flex" data-testid="icon-wrapper">
                                    <svg style="width: 24px; height: 24px; fill: var(--color-icon-high-emphasis);">
                                        <use class="disable-events" xlink:href="#discount"></use>
                                    </svg>
                                </div>
                            </div>
                            <div class="pl-3"><p class="text-body1-strong compact color-text-heading whitespace-nowrap">بسته شده</p>
                                <p class="text-caption-strong compact mt-1 TicketStatus__text--high-emphasis-2_Dt_F"><?=countStatus(4)?> عدد</p></div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="">
                <div class="">
                    <div class="TableViewHeaderMobile-Wh3CDn">
                        <div class="TableViewHeaderMobile__topBar-yWFB0r">
                            <div class="d-flex ai-center">
                                <button class="relative d-flex ai-center user-select-none btn-wc51H8 text-button-2 btn--text-se4oQM btn--primary-uiqWij radius Button__medium-gIvke_ Button__textPrimary-IWW5Sd TableViewHeaderMobile__mobileHeaderButton-FyC_Lk ml-6 Button-MNNP44"
                                        data-testid="button-wrapper">
                                    <div class="d-flex ai-center jc-center relative grow-1">
                                        <div class="d-flex" data-testid="icon-wrapper">
                                            <svg style="width: 24px; height: 24px; fill: var(--color-icon-high-emphasis);">
                                                <use class="disable-events" xlink:href="#arrowBack"></use>
                                            </svg>
                                        </div>
                                    </div>
                                </button>
                                <div><h4 class="text-h4 color-text-heading">درخواست&zwnj;های شما</h4></div>
                            </div>
                        </div>
                    </div>
                    <section class="TableCard--filterMobile-wBInUm TableCard--filterMobile--space-NeTjOU">
                        <form>
                        </form>
                    </section>
                    <section class="p-5 TableCard--bodyMobile-tDS3OZ">
                        <?php
                        $db = \Giftmax\modules\Db::getLnstance();
                        global $wpdb;
                        $user = wp_get_current_user();
                        $records = $db->query("SELECT * FROM  {$wpdb->prefix}ticket WHERE rep_Id IS NULL");
                        if (!empty($records)){
                            $count = count($records);
                        }else{
                            $count = 0;
                        }
                        ?>
                        <div class="d-flex jc-between ai-center mb-4 TableHeadAction--mobile-tuX2bW"><p
                                    class="color-n-500 text-body1-strong">لیست درخواست&zwnj;ها</p>
                            <p class="color-n-500 text-body-2"><?=$count?> عدد</p></div>
                        <section class="mb-10 mb-0-lg">
                            <section>
                                <?php
                                if (!empty($records)){

                                    foreach ($records as $key=>$record){
                                        if (is_numeric($record['categoryId'])) {
                                            $categorys = $db->query("SELECT * FROM  `{$wpdb->prefix}ticketing_category` WHERE `categoryId`=:id", array(
                                                'id' => $record['categoryId'],
                                            ));
                                        }else{
                                            $categoryId = explode('|',decrypt_data($record['categoryId']));
                                            $categorys = [['name'=>"سفارش #".$categoryId[0]]];
                                        }
                                        ?>
                                        <section class="TableRowContainer__normal-Uv6APM p-2 bg-light mb-4 TableRowMobile-wVIgBd">
                                            <div class="d-flex mb-2 jc-between TableRowMobile__topRow-l_js3c">
                                                <div class="d-flex jc-start">
                                                    <div class="d-flex">
                                                        <div class="ml-4 d-flex flex-1 flex-column overflow-hidden"><p
                                                                    class="d-flex ai-center jc-center text-body1-strong flex-1 TableRowMobile__header_title-fz6jz7">
                                                                <?=$record['Issue']?></p>
                                                            <div class="d-flex flex-wrap">
                                                                <div class="px-2 ml-1 mb-2 TableRowMobile-wVIgBd CellBadges__dkp-rm1Qo8">
                                                                    <p class="text-caption-strong">S-<?=$record['ticketId']?></p></div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <?php $gid = ($record['ticketId']) * 10 / 5?>
                                                <a href="<?=esc_url( get_permalink() )?>id/<?=$gid?>" class="relative d-flex ai-center user-select-none btn-wc51H8 text-button-2 btn--text-se4oQM btn--primary-uiqWij radius Button__medium-gIvke_ Button__textPrimary-IWW5Sd shrink-0 TableRowMobile__showMoreButton-_DH4FY Button-MNNP44"
                                                   data-testid="button-wrapper">
                                                    <div class="d-flex ai-center jc-center relative grow-1">
                                                        <div class="d-flex pointer TableRowMobile__icon-MaCk71"
                                                             data-testid="icon-wrapper">
                                                            <svg style="width: 24px; height: 24px; fill: var(--color-icon-high-emphasis);">
                                                                <use class="disable-events" xlink:href="#arrowLeft"></use>
                                                            </svg>
                                                        </div>
                                                    </div>
                                                </a>
                                            </div>
                                            <div class="text-body-2 d-flex ai-center mb-2"><p
                                                        class="color-text-low-emphasis text-body-2 ml-2">موضوع:</p><span
                                                        class="color-text-high-emphasis text-body2-strong"><?=$categorys[0]['name']?></span>
                                            </div>
                                            <div class="text-body-2 d-flex ai-center mb-2"><p
                                                        class="color-text-low-emphasis text-body-2 ml-2">تاریخ ثبت:</p><span
                                                        class="color-text-high-emphasis text-body2-strong"><?=gjdate($record['time'],"d M Y")?></span>
                                            </div>
                                            <?php $times = $db->query("SELECT t1.*, t2.*
FROM {$wpdb->prefix}ticket t1
LEFT JOIN {$wpdb->prefix}ticket t2 ON t1.ticketId = t2.rep_Id
WHERE t1.ticketId = :ticketId
ORDER BY t1.time DESC
LIMIT 1;",array('ticketId'=>$record['ticketId'])); ?>
                                            <div class="text-body-2 d-flex ai-center mb-2"><p
                                                        class="color-text-low-emphasis text-body-2 ml-2">آخرین به&zwnj;روزرسانی:</p>
                                                <span class="color-text-high-emphasis text-body2-strong">
                                                    <?=!empty($times[0]['time']) ? gjdate($times[0]['time'],"d M Y - H:i") : "-"?>
                                                </span>
                                            </div>
                                            <div class="text-body-2 d-flex ai-center">
                                                <?php
                                                if ($record['condition'] == 0){
                                                    $cls = 'Badge__info-st92ed';
                                                    $nm = "جدید";
                                                }elseif ($record['condition'] == 1){
                                                    $cls = 'Badge__info-16f59';
                                                    $nm = "درحال بررسی";
                                                }elseif ($record['condition'] == 2){
                                                    $cls = 'Badge__warning-MfubDgd';
                                                    $nm = "در انتظار جزئیات";
                                                }elseif ($record['condition'] == 3){
                                                    $cls = 'Badge__success-AVxEpg';
                                                    $nm = "حل شده";
                                                }elseif ($record['condition'] == 4){
                                                    $cls = 'Badge__neutral-XFzczo';
                                                    $nm = "بسته شده";
                                                }
                                                ?>
                                                <div class="d-inline-flex ai-center <?=$cls?> text-no-wrap Badge-vPRt_1 Badge--medium-SregFw px-3 text-body2-strong"
                                                     style="background-color: var(--color-undefined); color: var(--color-undefined);">
                                                    <?=$nm?>
                                                </div>
                                            </div>
                                        </section>
                                        <?php
                                    }
                                }else{
                                    ?>
                                    <section class="p-5 TableCard--bodyMobile-tDS3OZ">
                                        <div class="d-flex ai-center jc-center align-center w-100 h-100">
                                            <div class="py-4 d-flex flex-column jc-center ai-center EmptyState__desktopContainer-ggZkIg">
                                                <div class="d-flex jc-center mb-3" data-testid="empty-src">
                                                    <div data-testid="image-wrapper" style="width: 200px; height: 150px;"><img class="w-100"
                                                                                                                               src="<?=get_template_directory_uri()?>/assets/img/ticket_img.png"
                                                                                                                               width="200"
                                                                                                                               height="150"
                                                                                                                               data-testid="image-defaultImage"
                                                                                                                               style="object-fit: contain;">
                                                    </div>
                                                </div>
                                                <div class="text-h5 color-900">نتیجه&zwnj;ای پیدا نکردیم...</div>
                                                <div class="text-caption-strong color-500" data-testid="empty-description">
                                                    <div>فیلترها را تغییر دهید و دوباره امتحان کنید</div>
                                                </div>
                                            </div>
                                        </div>
                                    </section>
                                    <?php
                                }
                                ?>
                            </section>
                        </section>
                    </section>
                    <div class="pos-fixed bottom-62 shadow-dropdown-reverse left-0 right-0 z-11 bg-n-000 p-5 shadow-1-top">
                        <a>
                            <button class="relative d-flex ai-center user-select-none btn-wc51H8 text-button-1 btn--large-Gj4EdP btn--primary-uiqWij radius Button__large-Zq9sTh Button__filledPrimary-OvgwGb Button__prependIcon-hh7768 w-100 Button-MNNP44 Button-ADC" data-testid="button-wrapper">
                                <div class="d-flex ai-center jc-center relative grow-1">
                                    <div class="d-flex ml-2" data-testid="icon-wrapper">
                                        <svg data-testid="button-prepend-icon" style="width: 24px; height: 24px; fill: var(--color-icon-white);">
                                            <use class="disable-events" xlink:href="#addInput"></use>
                                        </svg>
                                    </div>
                                    اضافه کردن دسته بندی
                                </div>
                            </button>
                        </a>
                    </div>
                </div>
            </div></main>
    </div>
    <?php
}
?>
<div id="modal-root"><div class="absolute"></div></div>
<div id="popper-root"><div class="absolute"><div id="snackbar-container" class="pos-fixed d-flex flex-column my-3 px-4 jc-center Snackbar__container-_86cf8 bottom-0 left-1/2 -translate-x-1/2 z-9999999" style="left: 50%; transform: translateX(-50%); width: 320px;"></div></div></div>
<script>
    $(function (){
        $(document).on('click',".Button-ADC[data-testid=\"button-wrapper\"]",function (){
            uikit__collections_Popup("انتخاب دسته بندی","<div class=\"d-flex flex-column gap-y-5 mt-5\"> <div> <div class=\"text-body-1 color-n-700 d-flex ai-center jc-between\"><p>عنوان دسته بندی<span class=\"color-hint-text-error\">*</span></p></div> <p class=\"text-body-2 color-n-500\"></p><label class=\"FormComponentFrame-sy77JE FormComponentFrame--normal-Tol9_4 w-100\"> <div class=\"FormComponentFrame__input-container-fArle6 px-2 d-flex ai-center\"> <section class=\"grow-1 text-body-2-c\"><input class=\"px-2 TextField__input-xuVYYy text-subtitle w-100 TextField-cJQfI5 TextField--primary-cAI5H3\" type=\"text\" name=\"title\" value=\"\"></section> <div></div> </div> </label></div>  </div> <div class=\"d-flex flex-column gap-y-5 mt-5\"> <div> <div class=\"text-body-1 color-n-700 d-flex ai-center jc-between\"><p>دسته اصلی<span class=\"color-hint-text-error\">*</span></p></div> <p class=\"text-body-2 color-n-500\"></p><label class=\"FormComponentFrame-sy77JE FormComponentFrame--normal-Tol9_4 w-100\"> <div class=\"FormComponentFrame__input-container-fArle6 px-2 d-flex ai-center\"> <section class=\"grow-1 text-body-2-c\"><input class=\"px-2 TextField__input-xuVYYy text-subtitle w-100 TextField-cJQfI5 TextField--primary-cAI5H3\" type=\"text\" name=\"main\" placeholder=\"خدمات\"></section> <div></div> </div> </label><div id=\"c-category\"> </div></div>  </div>","","","<div class=\"ModalComponent__footerContainer-rb1vEj\"><div class=\"ProfileModal__footer-IVQdrc\"> <button class=\"relative d-flex ai-center user-select-none btn-wc51H8 text-button-2 btn--primary-uiqWij radius Button__medium-gIvke_ Button__filledPrimary-OvgwGb ProfileBase__button-jvi4aR ProfileBase__button__modal-O3kjhU Button-NCD45\" data-testid=\"button-wrapper\" type=\"button\"><div class=\"d-flex ai-center jc-center relative grow-1\">ادامه</div></button></div> </div>")
            let timer = null;

            $("input[name='main']").on('input', function () {
                const query = $(this).val().trim();

                clearTimeout(timer);

                timer = setTimeout(() => {
                    if (query.length > 0) {
                        SAJ('main',{ q: query},function (res){
                            let container = document.querySelector('#c-category');
                            container.innerHTML = res.html;
                        })
                    }
                }, 500);
            });
            return false;
        });
        $(document).on('click', '.Button-NCD45', function (e) {
            e.preventDefault();
            const formData = b();
            SAJ('category',formData,function (res){
                if (res.status == 'ok') {
                    const container = document.querySelector(".ModalComponent__root-YwCAMP.ModalComponent__root--desktop-JzGyNl.ModalComponent__animation-JkgpfL.ModalComponent__root--open-i5pSf7.ModalComponent__root--open__desktop-x1XDzU");
                    $(".ModalComponent__content-XqD1rL.ModalComponent__animation-JkgpfL.ModalComponent__content--desktop-o5IbOt.ModalComponent__content--border-md-4G9biy.overflow-auto").css('transform', 'translateY(400%)');

                    setTimeout(function () {
                        container.remove();
                        document.body.classList.toggle("lock-body-scroll");
                    }, 100);
                }else {
                    uikit__collections_error('این دسته بندی قبلا ثبت شده است!');
                }
            })
        });
    })
</script>