    <?php
    if (!empty($records)) {?>
            <?php
            foreach ($records as $i => $record) {
                ?>
                <div class="c-category__body">
                <div class="b-category bills_number">
                    <span class="c-number"><?=$i+1?></span></div>
                <div class="b-category bills_name">
                    <div class="c-color "><?=$record['name']?></div>
                </div>
                <div class="b-category purchase_date">
                    <div class="c-color "></div>
                </div>
                <div class="b-category bills_view">
                    <div class="c-view Button-SC92" data-id="<?=$record['categoryId']?>">انتخاب</div>
                </div>
                </div>
            <?php }?>
        <?php
    } else {
        ?>
        <p class="c-color">دسته بندی پیدا نشد!!!</p>
        <?php
    }
    ?>
