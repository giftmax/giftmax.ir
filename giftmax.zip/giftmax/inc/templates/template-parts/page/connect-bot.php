<?php
function aleatError()
{
    echo '<div class="container-xs-w mx-auto mt-32" style=" border: 1px solid #E5E7EB; border-radius: 16px; padding: 32px; ">

        <div class="flex align-items-center justify-center">
            <div>
                <svg fill="none" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" width="70"><g stroke-linecap="round" stroke-width="1.5" clip-path="url(\'/callback/invoice/cab0d458-2c37-419f-98a7-1f9505554cbd?platform=ANDROID#ebclip0_1582_114562\')"><path stroke="#ff4f00" stroke-linejoin="round" d="M9 9l6 6m0-6l-6 6M9 9l1.586 1.586a2 2 0 002.828 0L15 9M9 15l1.586-1.586a2 2 0 000-2.828L9 9" style="
    stroke: #df2040 !important;
    stroke-width: 1px !important;
"></path><path stroke="#ff4f00" stroke-linejoin="round" d="M9 15l1.586-1.586a2 2 0 012.828 0L15 15" style="
    stroke: #df2040 !important;
    stroke-width: 1px !important;
"></path><path stroke="#ff4f00" stroke-linejoin="round" d="M15 15l-1.586-1.586a2 2 0 010-2.828L15 9" style="
    stroke: #df2040 !important;
    stroke-width: 1px !important;
"></path><path stroke="#0095da" d="M12 20a8 8 0 100-16 8 8 0 000 16z" style="
    stroke: #df2040 !important;
    stroke-width: 1px !important;
"></path></g><defs><clipPath id="ebclip0_1582_114562"><path fill="#fff" d="M0 0h24v24H0z"></path></defs></svg>
            </div>
        </div>
        <div class="flex justify-center">
            <div style=" font-size: 16px; font-weight: 600; line-height: 32px; ">خطا در اتصال</div>
        </div>
    </div>';
}

if (!isset($_GET['token'])) {
    aleatError();
}else{
    $token_raw = substr($_SERVER['REQUEST_URI'], strpos($_SERVER['REQUEST_URI'], 'token=') + 6);
    $token = decrypt_data($token_raw);
    $token = explode('|',$token);
    if (count($token) != 4) {
        aleatError();
    }else{
        $target_timestamp = $token[2];
        $now_timestamp = strtotime(date("Y-m-d H:i:s"));
        $time_diff = $now_timestamp - $target_timestamp;
        $max_valid_seconds = 300;
        if ($time_diff >= 0 && $time_diff >= $max_valid_seconds) {
            aleatError();
        }elseif ($token[3] == 'rubika' || $token[3] == 'bale'){
            global $wpdb;
            $db = \Giftmax\Modules\Db::getLnstance();
            $userId = get_current_user_id();
            $ConnectUser = \Giftmax\Modules\UserModel::table("bot_platform","userId",$userId,'platform_name',$token[3]);
            if ($token[3] == 'rubika') {
                $bot = "روبیکا";
                $iconPlatform = 'f-rubika.png';
                $records = $db->first("SELECT meta_value FROM `{$wpdb->prefix}setting` WHERE `meta_key`=:key",array('key'=>'َApiKeyRubika'));
                if (!empty($records) && empty($ConnectUser)){
                    $tokenBot = $records['meta_value'];
                    $url = "https://botapi.rubika.ir/v3/{$tokenBot}/sendMessage";
                    $sendData = [
                        "chat_id" => $token[0],
                        "text" => "ربات متصل شد",
                    ];
                    $ch = curl_init();
                    curl_setopt($ch, CURLOPT_URL, $url);
                    curl_setopt($ch, CURLOPT_POST, true);
                    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                    curl_setopt($ch, CURLOPT_HTTPHEADER, [
                        'Content-Type: application/json'
                    ]);
                    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($sendData));

                    $response = curl_exec($ch);
                    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
                    $curlError = curl_error($ch);
                    curl_close($ch);
                }
            }elseif ($token[3] == 'bale') {
                $bot = "بله";
                $iconPlatform = 'f-bale.png';
                $records = $db->first("SELECT meta_value FROM `{$wpdb->prefix}setting` WHERE `meta_key`=:key",array('key'=>'َApiKey'));
                if (!empty($records) && empty($ConnectUser)){
                    $tokenBot = $records['meta_value'];
                    $sendData = [
                        "chat_id" => $token[0],
                        "text" => "ربات متصل شد",
                    ];
                    $api = 'sendMessage';
                    $url = 'https://tapi.bale.ai/bot' . $tokenBot . '/' . $api;
                    $ch = curl_init();
                    curl_setopt($ch, CURLOPT_URL, $url);
                    curl_setopt($ch, CURLOPT_HTTPHEADER, array("Content-Type: application/json"));
                    curl_setopt($ch, CURLOPT_POST, 1);
                    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($sendData));
                    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
                    $response = curl_exec($ch);
                    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
                    curl_close($ch);
                }
            }
            if (empty($ConnectUser)) {
                $db->query("INSERT INTO `{$wpdb->prefix}bot_platform` (userId,chat_id,sender_id, platform_name) VALUES (:userId,:chatId,:senderId, :platformName)",array(
                    'userId' => $userId,
                    'chatId' => $token[0],
                    'senderId' => $token[1],
                    'platformName' => $token[3]
                ));
            }
            ?>
            <div class="container-xs-w mx-auto mt-32" style=" border: 1px solid #E5E7EB; border-radius: 16px; padding: 32px; ">

                <div class="flex justify-center">
                    <div style=" font-size: 16px; font-weight: 600; line-height: 32px; ">اتصال سایت به ربات <?=$bot?></div>
                </div>
                <div class="flex align-items-center justify-center" style="margin-top: 13px">
                    <div style=" width: 40px; height: 40px; border: 1px solid #d6d6d6; display: flex; align-items: center; justify-content: center; border-radius: 999px; ">
                        <img style="height: 25px; width: 25px;color: #7f7f7f;" src="<?=get_template_directory_uri() . '/assets/img/' .$iconPlatform?>">
                    </div>
                    <div style="width: 110px;height: 1px;border: 1px dashed #d6d6d6;position: relative">
                        <div style=" position: absolute; top: -12px; left: 46px; background-color: #FFF; "><svg fill="none" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" width="24" style=" "> <path stroke="#ff4f00" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M17 8l-5.565 6L9 11.375" style=" stroke: #39ac65 !important; "></path> </svg></div>
                    </div>
                    <div style="width: 40px; height: 40px; border: 1px solid #d6d6d6; display: flex; align-items: center; justify-content: center; border-radius: 999px;">
                        <img src="<?=get_template_directory_uri()?>/assets/img/logo_connect.png" width="28">
                    </div>
                </div>
            </div>
            <?php
        }
    }
}