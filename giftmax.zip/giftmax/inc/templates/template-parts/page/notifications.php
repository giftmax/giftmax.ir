<main class="mx-auto Container-_0348a container-2xl-w">
<div class="breakpoint">
    <section class="d-flex ai-center pt-8 mb-3"><h1 class="text-h5 color-text-heading">اعلان ها</h1><span
                class="color-text-heading text-h5 mx-1">|</span>
        <p class="text-body-2 color-text-low-emphasis">اینجا می‌توانید اعلان‌های گیفت مکس را ببینید</p>
    </section>
    <div class="">
        <div class="TableCard__desktop-VytQYw">
            <?php

            use Giftmax\Modules\Db;

            $user = wp_get_current_user();
            $user_id = (int) $user->ID;
            global $wpdb;
            $db = Db::getLnstance();
            $records_count = $db->first("SELECT COUNT(*) AS total FROM `{$wpdb->prefix}notifications` n WHERE n.`is_active`=1 AND (n.`userId` IS NULL OR n.`userId`=0 OR n.`userId`=:user_id)", array('user_id' => $user_id));
            $total_notifications = !empty($records_count) ? (int) $records_count['total'] : 0;
            ?>
            <div class="d-flex ai-center flex-wrap w-100 TableHeadAction--desktop-kkHIe5">
                <div class="d-flex flex-1 pb-5"></div>
                <div class="Container-A34iFV d-flex ai-center jc-end ">
                    <div><span class="pl-1 color-text-low-emphasis text-body-1">تعداد نتایج:</span><span
                                class="color-text-high-emphasis text-body1-strong"><?=$total_notifications?></span></div>
                </div>
            </div>
            <section class="p-5 TableCard--bodyMobile-tDS3OZ">
                <div class="d-flex jc-between ai-center mb-4 TableHeadAction--mobile-tuX2bW">
                    <div class="d-flex jc-between ai-center w-100"><p class="text-body1-strong"><?=$total_notifications?> اعلان&zwnj;</p>
                    </div>
                </div>
                <section>
                    <div>
                        <section>
                            <?php
                            $db = Db::getLnstance();
                            global $wpdb;
                            $records = $db->query("SELECT n.*,r.* FROM `{$wpdb->prefix}notifications` n LEFT JOIN `{$wpdb->prefix}notification_reads` r ON r.`notification_id` = n.`Id` AND r.`user_id` = :user_id WHERE n.`is_active`=1 AND (n.`userId` IS NULL OR n.`userId`=0 OR n.`userId`=:user_id) ORDER BY n.`Id` DESC LIMIT 0,10", array('user_id' => $user_id));
                            if (!empty($records)){
                                $recordsCount = $db->query("SELECT COUNT(*) AS total FROM `{$wpdb->prefix}notifications` n LEFT JOIN `{$wpdb->prefix}notification_reads` r ON r.`notification_id` = n.`Id` AND r.`user_id` = :user_id WHERE n.`is_active`=1 AND (n.`userId` IS NULL OR n.`userId`=0 OR n.`userId`=:user_id)", array('user_id' => $user_id))[0]['total'];
                                $pageCount = ceil($recordsCount/10);
                                foreach ($records as $record){
                                    if (empty($record['notification_id'])){
                                    ?>
                                    <section
                                            class="TableRowContainer__normal-Uv6APM py-2 px-4 my-3 d-grid ai-center NotificationCard__tableRow-opMsDI TableRowDesktop-xIiuFo radius-md">
                                        <div class="NotificationCard__title-GEjaN6 d-flex flex-row">
                                            <div class="d-flex flex-row">
                                                <div class="d-flex ml-5" data-testid="icon-wrapper">
                                                    <svg style="width: 24px; height: 24px; fill: var(--color-icon-high-emphasis);">
                                                        <use class="disable-events" xlink:href="#notificationBell"></use>
                                                    </svg>
                                                </div>
                                            </div>
                                            <div class="grow-1"></div>
                                            <div class="color-n-500 text-body-1 dir-ltr"><?=gjdate($record['created_at'])?></div></div>
                                        <div class="d-flex flex-row jc-center"><p class="text-body1-strong color-n-700"><?=esc_html($record['title'])?></p>
                                            <div class="grow-1"></div>
                                            <button class="relative d-flex ai-center user-select-none btn-wc51H8 text-button-2 btn--text-se4oQM btn--primary-uiqWij radius Button__medium-gIvke_ Button__textPrimary-IWW5Sd AccordionButton--commonClasses-Qnp0XR Button-rn45"
                                                    data-testid="button-wrapper" data-id="<?=esc_attr($record['Id'])?>">
                                                <div class="d-flex ai-center jc-center relative grow-1">
                                                    <div class="d-flex AccordionButton--expandIcon-P1W7MA"
                                                         data-testid="icon-wrapper">
                                                        <svg style="width: 24px; height: 24px; fill: var(--color-icon-high-emphasis);">
                                                            <use class="disable-events" xlink:href="#expandLess"></use>
                                                        </svg>
                                                    </div>
                                                </div>
                                            </button>
                                        </div>
                                        <div class="Accordion-bhT9dH Accordion__exit-F8WmEG Accordion__exitActive-HuOwrM">
                                            <div>
                                                <div class="text-body-1 color-text-low-emphasis "><?=wp_kses_post($record['body'])?></div>
                                            </div>
                                        </div>
                                    </section>
                                    <?php
                                }else{
                                ?>
                                    <section
                                            class="TableRowContainer__visited-TUSUSu py-2 px-4 my-3 d-grid ai-center NotificationCard__tableRow-opMsDI TableRowDesktop-xIiuFo radius-md">
                                        <div class="NotificationCard__title-GEjaN6 d-flex flex-row">
                                            <div class="d-flex flex-row">
                                                <div class="d-flex ml-5" data-testid="icon-wrapper">
                                                    <svg style="width: 24px; height: 24px; fill: var(--color-icon-high-emphasis);">
                                                        <use class="disable-events" xlink:href="#notificationBellRead"></use>
                                                    </svg>
                                                </div>
                                            </div>
                                            <div class="grow-1"></div>
                                            <div class="color-n-500 text-body-1 dir-ltr"><?=gjdate($record['created_at'])?></div></div>
                                        <div class="d-flex flex-row jc-center"><p class="text-body1-strong color-n-700"><?=esc_html($record['title'])?></p>
                                            <div class="grow-1"></div>
                                            <button class="relative d-flex ai-center user-select-none btn-wc51H8 text-button-2 btn--text-se4oQM btn--primary-uiqWij radius Button__medium-gIvke_ Button__textPrimary-IWW5Sd AccordionButton--commonClasses-Qnp0XR Button-rn45"
                                                    data-testid="button-wrapper">
                                                <div class="d-flex ai-center jc-center relative grow-1">
                                                    <div class="d-flex AccordionButton--expandIcon-P1W7MA"
                                                         data-testid="icon-wrapper">
                                                        <svg style="width: 24px; height: 24px; fill: var(--color-icon-high-emphasis);">
                                                            <use class="disable-events" xlink:href="#expandLess"></use>
                                                        </svg>
                                                    </div>
                                                </div>
                                            </button>
                                        </div>
                                        <div class="Accordion-bhT9dH Accordion__exit-F8WmEG Accordion__exitActive-HuOwrM">
                                            <div>
                                                <div class="text-body-1 color-text-low-emphasis "><?=wp_kses_post($record['body'])?></div>
                                            </div>
                                        </div>
                                    </section>
                                    <?php

                                    }
                                }
                                echo '<div class="flex justify-end"><div class="v10__Pagination">';
                                for ($i = 1; $i <= 3; $i++) {
                                    if ($i < 1){
                                        continue;
                                    }
                                    if ($i>$pageCount){continue;}
                                    if (1 == $i){
                                        echo '<button class="v10__Pagination-item Button-np51 active">' . $i . '</button>';
                                    }else {
                                        echo '<button class="v10__Pagination-item Button-np51" data-page="' . $i . '">' . $i . '</button>';
                                    }
                                }
                                echo '</div></div> ';
                            }else{
                                ?>
                                <section class="p-5 TableCard--bodyMobile-tDS3OZ">
                                    <div class="d-flex ai-center jc-center align-center w-100 h-100">
                                        <div class="py-4 d-flex flex-column jc-center ai-center EmptyState__desktopContainer-ggZkIg">
                                            <div class="d-flex jc-center mb-3" data-testid="empty-src">
                                                <div data-testid="image-wrapper" style="width: 200px; height: 150px;">
                                                    <img class="w-100"
                                                         src="<?=get_template_directory_uri()?>/assets/img/ticket_img.png"
                                                         width="200"
                                                         height="150"
                                                         data-testid="image-defaultImage"
                                                         style="object-fit: contain;">
                                                </div>
                                            </div>
                                            <div class="text-h5 color-900">نتیجه&zwnj;ای پیدا نکردیم...</div>
                                            <div class="text-caption-strong color-500" data-testid="empty-description">
                                                <div>فیلترها را تغییر دهید و دوباره امتحان کنید</div>
                                            </div>
                                        </div>
                                    </div>
                                </section>
                                <?php
                            }

                            ?>
                        </section>
                    </div>
                </section>
            </section>
        </div>
    </div>
    <div></div>
</div>
</main>
