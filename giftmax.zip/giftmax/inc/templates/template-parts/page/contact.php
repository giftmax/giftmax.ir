<section class="container-xl-w mx-auto contact-us mt-62">
    <div class="row g-4 align-items-center flex-lg-row flex-column-reverse">
        <div class="col-lg-4">
            <div class="box rounded-4 d-block bg-white p-lg-4 p-3 position-relative">
                <form action="">
                    <div class="row g-3 form-elements">
                        <div class="col-lg-12 col-sm-6">
                            <div class="form-group">
                                <input type="text" id="name" placeholder="نام و نام خانوادگی" class="w-100 border-0 text-dark rounded-3 fw-medium ps-3">
                            </div>
                        </div>
                        <div class="col-lg-12 col-sm-6">
                            <div class="form-group">
                                <input type="text" id="email" placeholder="آدرس ایمیل شما" class="w-100 border-0 text-dark rounded-3 fw-medium ps-3">
                            </div>
                        </div>
                        <div class="col-lg-12 col-sm-6">
                            <div class="form-group">
                                <input type="text" id="subject" placeholder="موضوع پیام شما" class="w-100 border-0 text-dark rounded-3 fw-medium ps-3">
                            </div>
                        </div>
                        <div class="col-lg-12 col-sm-12">
                            <div class="form-group">
                                <textarea id="text" placeholder="متن پیام شما..." class="w-100 border-0 text-dark rounded-3 fw-medium p-3"></textarea>
                            </div>
                        </div>
                        <div class="col-lg-12 col-sm-12">
                            <div class="form-group">
                                <button type="button" id="contactSubmit" class="btn btn-submit fw-bold text-white w-100 Button-csu56">ارسال پیام</button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        <div class="col-lg-8">
            <div class="box blue-theme bg-primary shadow-none rounded-4 position-relative px-lg-4 py-lg-5 px-3 py-3" <?=!isMobile() ? 'style=" padding: 31px !important; "': ''?>>
                <div class="header-section mb-3">
                    <div class="title text-light fw-medium d-flex align-items-center">
                        <i class="icon-smileys text-white opacity-50 me-lg-3 me-2"></i>
                        <h1 class="text-white d-block fw-bold me-lg-3">
                            تماس با فروشگاه گیفت مکس
                        </h1>
                    </div>

                </div>
                <p class="text text-white opacity-75 d-block fw-medium mb-lg-4 mb-3 pb-lg-2">
                    اگر ایده، پیشنهاد یا انتقادی در مورد فروشگاه گیفت مکس دارید، از طریق راه&zwnj;های ارتباطی زیر یا از طریق فرم روبرو، با ما در تماس باشید.
                </p>
                <ul class="nav nav-info flex-column">
                    <li class="nav-item text-white d-flex align-items-sm-center align-items-start fw-medium mb-3rem">
                        <div class="icon rounded-3 d-flex align-items-center justify-content-center me-sm-3 me-2">
                            <i class="icon-phone-ring"></i>
                        </div>
                        <div>
                            <div class="small-theme opacity-75 mb-1">
                                شماره تماس
                            </div>
                            <div class="d-flex align-items-center">
                                <p><br></p>
                                <p><?=\Giftmax\Modules\UserModel::setting("tel") == 'true' ? \Giftmax\Modules\UserModel::settingValue("tel") : '-'?></p>
                            </div>
                        </div>
                    </li>

                    <li class="nav-item text-white d-flex align-items-sm-center align-items-start fw-medium mb-3rem">
                        <div class="icon rounded-3 d-flex align-items-center justify-content-center me-sm-3 me-2">
                            <i class="icon-message"></i>
                        </div>
                        <div>
                            <div class="small-theme opacity-75 mb-1">
                                پست الکترونیک
                            </div>
                            <div class="d-flex align-items-center">
                                <p><br>
                                </p>
                                <p>iran3dmax [@] gmail.com  – giftmax [@] bertinamail.com</p>
                                <p></p>
                            </div>
                        </div>
                    </li>
                    <?php
                    if (\Giftmax\Modules\UserModel::setting("telegram") == 'true'){
                    ?>
                    <li class="nav-item text-white d-flex align-items-sm-center align-items-start fw-medium mb-3rem">
                        <div class="icon rounded-3 d-flex align-items-center justify-content-center me-sm-3 me-2">
                            <i class="icon-telegram"></i>
                        </div>
                        <div>
                            <div class="small-theme opacity-75 mb-1">
                                ارتباط در تلگرام
                            </div>
                            <div class="d-flex align-items-center">
                                <p><br>
                                </p>
                                <p><?=\Giftmax\Modules\UserModel::settingValue("telegram")?></p>
                                <p></p>
                            </div>
                        </div>
                    </li>
                    <?php
                    }
                    ?>
                </ul>

                <img src="<?=get_template_directory_uri()?>/assets/img/contact-us.webp" alt="contact" class="img position-absolute bottom-0 end-0 d-lg-block d-none">
            </div>
        </div>
    </div>
</section>