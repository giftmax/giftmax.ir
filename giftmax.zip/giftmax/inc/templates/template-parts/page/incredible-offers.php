<?php
$now = time();
wp_reset_postdata();

?>
<div>
    <section class="container-2xl-w mx-auto mt-32 nav__box">
        <nav class="rad-breadcrumb rad-woo-bread">
            <a class="kp-pl" href="<?=home_url()?>">  صفحه اصلی  </a>
            <span class="sep">
                <svg xmlns="http://www.w3.org/2000/svg" width="1" height="24" viewBox="0 0 1 24" stroke="currentcolor">
                    <line x1="0.5" y1="2.18557e-08" x2="0.499999" y2="24"></line>
                </svg>
            </span>
            <span class="kp-pn">پیشنهاد شگفت انگیز</span>
        </nav>
    </section>
    <?php
    $args = [
        'post_type'      => 'product',
        'posts_per_page' => -1,
        'meta_query'     => [
            'relation' => 'AND',

            [
                'key'     => '_sale_price',
                'value'   => 0,
                'compare' => '>',
                'type'    => 'NUMERIC',
            ]
        ],
    ];

    $query = new \WP_Query($args);
    if ($query->have_posts()) {
        ?>
        <section class="container-xl-w mx-auto mt-18">
            <div class="act-new-service-carousel-1st" id="LoadCategory">
                <div class="act-new-service-carousel-head d-flex align-items-center justify-content-between">
                    <svg xmlns="http://www.w3.org/2000/svg" width="1281" height="75" viewBox="0 0 1281 75" fill="none" class="act-new-service-carousel-head-svg">
                        <path d="M1280.47 0.5H1000.91C986.771 0.5 979.703 0.5 973.764 2.99163C969.027 4.9789 964.838 8.07733 961.551 12.025C957.43 16.9747 955.361 23.7331 951.224 37.25C947.086 50.7669 945.017 57.5253 940.896 62.475C937.609 66.4227 933.42 69.5211 928.683 71.5084C922.744 74 915.676 74 901.54 74H412.882C399.847 74 393.329 74 387.813 71.8926C382.12 69.7177 377.167 65.9625 373.536 61.0686C370.017 56.3267 368.257 50.0512 364.737 37.5C361.217 24.9488 359.457 18.6733 355.938 13.9314C352.307 9.0375 347.353 5.2823 341.661 3.10737C336.145 1 329.627 1 316.592 1H0" stroke="url(#paint0_linear_29_20094)"></path>
                        <defs>
                            <linearGradient id="paint0_linear_29_20094" x1="29.4736" y1="0.500002" x2="1213.79" y2="-28.0511" gradientUnits="userSpaceOnUse">
                                <stop stop-color="#0B61FF" stop-opacity="0"></stop>
                                <stop offset="0.5" stop-color="#0B61FF"></stop>
                                <stop offset="1" stop-color="#0B61FF" stop-opacity="0"></stop>
                            </linearGradient>
                        </defs>
                    </svg>
                    <div class="act-our-services-carousel-head-title">
                        <div class="act-our-services-carousel-head-title-divs">
                            <div class="act-our-services-carousel-head-title-div1"></div>
                            <div class="act-our-services-carousel-head-title-div2"></div>
                        </div>
                        <div class="act-our-services-carousel-head-title-content">
                            <h5>
                            </h5><h5>از تخفیف <strong>جا نمونی</strong></h5>
                            <p>NO DISCOUNT</p>
                        </div>
                    </div>
                    <div class="act-new-service-carousel-head-content">

                        <div class="act-new-service-carousel-buttons">
                            <div class="act-percent-but-r act-percent-but act-carousel-but" tabindex="0" role="button" aria-label="Previous slide" aria-controls="swiper-wrapper-5a458f817b4750df" aria-disabled="false">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="currentcolor">
                                    <path d="M14.4301 18.8201C14.2401 18.8201 14.0501 18.7501 13.9001 18.6001C13.6101 18.3101 13.6101 17.8301 13.9001 17.5401L19.4401 12.0001L13.9001 6.46012C13.6101 6.17012 13.6101 5.69012 13.9001 5.40012C14.1901 5.11012 14.6701 5.11012 14.9601 5.40012L21.0301 11.4701C21.3201 11.7601 21.3201 12.2401 21.0301 12.5301L14.9601 18.6001C14.8101 18.7501 14.6201 18.8201 14.4301 18.8201Z"></path>
                                    <path d="M20.33 12.75H3.5C3.09 12.75 2.75 12.41 2.75 12C2.75 11.59 3.09 11.25 3.5 11.25L20.33 11.25C20.74 11.25 21.08 11.59 21.08 12C21.08 12.41 20.74 12.75 20.33 12.75Z"></path>
                                </svg>
                            </div>
                            <div class="act-percent-but-l act-percent-but act-carousel-but swiper-button-disabled" tabindex="-1" role="button" aria-label="Next slide" aria-controls="swiper-wrapper-5a458f817b4750df" aria-disabled="true">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="currentcolor">
                                    <path d="M9.56988 5.17988C9.75988 5.17988 9.94988 5.24988 10.0999 5.39988C10.3899 5.68988 10.3899 6.16988 10.0999 6.45988L4.55988 11.9999L10.0999 17.5399C10.3899 17.8299 10.3899 18.3099 10.0999 18.5999C9.80988 18.8899 9.32988 18.8899 9.03988 18.5999L2.96988 12.5299C2.67988 12.2399 2.67988 11.7599 2.96988 11.4699L9.03988 5.39988C9.18988 5.24988 9.37988 5.17988 9.56988 5.17988Z"></path>
                                    <path d="M3.67 11.25H20.5C20.91 11.25 21.25 11.59 21.25 12C21.25 12.41 20.91 12.75 20.5 12.75L3.67 12.75C3.26 12.75 2.92 12.41 2.92 12C2.92 11.59 3.26 11.25 3.67 11.25Z"></path>
                                </svg>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="swiper percent-box-swiper">
                    <div class="swiper-wrapper" >
                        <?php
                        while ($query->have_posts()): $query->the_post();
                            $product = wc_get_product(get_the_ID());
                            $delivery = get_post_meta($product->get_id(), 'delivery', true);
                            $pa =  ((isset($delivery['two']) && $delivery['two'] == 'on') || product_available($product->get_id()));
                            if (!$pa){
                                continue;
                            }
                            $regular = $product->get_regular_price();
                            $sale    = $product->get_sale_price();

                            $discount = round((($regular - $sale) / $regular) * 100);
                            $img = get_the_post_thumbnail_url(get_the_ID(), 'product_discount');
                            $title = get_the_title();
                            $settings = get_post_meta(get_the_ID(), 'giftmax_box_setting', true);
                            $date_from = $product->get_date_on_sale_from();
                            $date_to   = $product->get_date_on_sale_to();
                            if ($product->is_on_sale() && ($date_from || $date_to)) {
                                $sale_to = $product->get_date_on_sale_to();
                                $sale_to_ts = $sale_to ? $sale_to->getTimestamp() : null;
                            }else{
                                $sale_to_ts = null;
                            }
                            $tooltip = isset($delivery['description']) ? $delivery['description'] : '';
                            ?>
                            <div class="swiper-slide">
                                <div class="act-percent-card">
                                    <div class="flex flex-col">
                                        <div class="relative">
                                            <div class="act-new-service-card-inner-top">
                                                <a href="<?=get_permalink()?>">
                                                    <div class="flex dj45fd">
                                                        <?php
                                                        $tooltip = isset($delivery['description']) ? $delivery['description'] : '';
                                                        ?>
                                                        <div class="act-product-option-box__nw <?=isset($delivery['two']) && $delivery['two'] == 'on' ? 'pre-sale wiki wiki__holder js-dk-wiki-trigger' : 'same-day'?>" <?=isset($delivery['two']) && $delivery['two'] == 'on' ? 'data-tooltip="'. $tooltip .'"' :''?>><?=isset($delivery['two']) && $delivery['two'] == 'on' ? 'پیش فروش' : 'تحویل آنی'?></div>
                                                        <div class="purchaseScore wiki wiki__holder js-dk-wiki-trigger" data-tooltip="با خرید این گیفت کارت <?=empty($settings[0]['purchaseScore']) ?0: $settings[0]['purchaseScore']?> امتیاز دریافت میکنید">
                                                            <i class="icon-star"></i>
                                                            <?=empty($settings[0]['purchaseScore']) ?0: $settings[0]['purchaseScore']?>
                                                        </div>
                                                        <?php
                                                        if (!empty($settings[0]['label']) && $settings[0]['label'] != ''){?>
                                                            <div class="label-fjd84">
                                                                <img src="<?=empty($settings[0]['label']) ?'': $settings[0]['label']?>" class="logo_label">
                                                                <p class="label_title"><?=empty($settings[0]['label_title']) ?'': $settings[0]['label_title']?></p>
                                                            </div>
                                                            <?php
                                                        }
                                                        ?>
                                                    </div>
                                                    <div class="act-new-service-card-inner-top-img-box relative aib36">
                                                        <img loading="lazy" decoding="async" width="32" height="33" src="<?=$img?>" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="">
                                                    </div>
                                                </a>
                                            </div>
                                            <?php
                                            if (!empty($settings[0]['logo_region'])){
                                                ?>
                                                <div class="logo_region">
                                                    <img src="<?=empty($settings[0]['logo_region']) ?: get_template_directory_uri() . '/assets/flag/' . $settings[0]['logo_region'] . '.svg'?>">
                                                </div>
                                                <?php
                                            }
                                            ?>
                                            <div class="act-product-price-off-percent">  <?=get_discount_percent($product)?> ٪       </div>
                                        </div>
                                        <div class="act-bar-left">
                                            <div class="flex justify-between">
                                                <a href="<?=get_permalink()?>">
                                                    <h4 class="ellipsis lg:w-80"><?=get_the_title()?></h4>
                                                </a>                                                <?php
                                                $giftmax_is_user_logged_in = is_user_logged_in();
                                                $giftmax_wishlist_ids = $giftmax_is_user_logged_in ? giftmax_get_user_wishlist_product_ids() : [];
                                                if ($giftmax_is_user_logged_in){
                                                    $is_in_wishlist = in_array((int) $product->get_id(), $giftmax_wishlist_ids, true); ?>
                                                    <button class="add-to__favorites Button-alu84 <?=$is_in_wishlist ? 'is-active' : ''?>" data-product-id="<?=esc_attr($product->get_id())?>" style="width: 28px;height: 28px;border-radius: 7px">
                                                        <svg viewBox="0 0 24 24" style="width: 64%;">
                                                            <path d="M12.62 20.81C12.28 20.93 11.72 20.93 11.38 20.81C8.48 19.82 2 15.69 2 8.68998C2 5.59998 4.49 3.09998 7.56 3.09998C9.38 3.09998 10.99 3.97998 12 5.33998C13.01 3.97998 14.63 3.09998 16.44 3.09998C19.51 3.09998 22 5.59998 22 8.68998C22 15.69 15.52 19.82 12.62 20.81Z" fill="<?=$is_in_wishlist ? '#ef4444' : 'none'?>" stroke="<?=$is_in_wishlist ? '#ef4444' : 'inherit'?>" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                                                        </svg>
                                                    </button>
                                                    <?php
                                                }
                                                ?>
                                            </div>
                                            <div class="flex justify-between mb-1 kef4e">
                                                <?php
                                                if (!is_null($sale_to_ts)){
                                                    ?>
                                                    <img class="inline-block lg:w-40" src="<?=get_template_directory_uri()?>/assets/img/svg/IncredibleOffer.svg" alt="" title="" style="object-fit: contain;">
                                                    <div class="text-primary-700 text-body2-strong" style="display:block;"><i class="icon-clock mr-1"></i><span class="style_ProductPromotionTimeline__timer__zS6ZA"><?= date('Y-m-d H:i:s', $sale_to_ts); ?></span></div>

                                                    <?php
                                                }else{ ?>
                                                    <img class="inline-block lg:w-40" src="<?=get_template_directory_uri()?>/assets/img/svg/Offer.svg" alt="" title="" style="object-fit: contain;">

                                                    <?php
                                                }
                                                ?>
                                            </div>

                                            <div class="flex justify-between w-full">
                                                <?php
                                                if (isset($delivery['two']) && $delivery['two'] == 'on' || product_available($product->get_id())){?>
                                                    <button data-product-id="<?=$product->get_id()?>" class="act-percent-card-buy-box-but Button-aca49 pointer" type="button">
                                                        افزودن به سبد خرید
                                                    </button>
                                                <?php }else{
                                                    echo '<div class="inaJSDge8" style="height: 30px">ناموجود</div>';
                                                }?>
                                                <div class="act-product-price-box">
                                                    <div class="act-product-price bpt">
                                                        <div id="priceValue" data-id="<?=$product->get_id()?>" data-target="<?=payment_usd($product->is_on_sale() ? $sale :$regular)?>"><?=number_format_usd($sale)?></div>
                                                        <span>تومان</span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endwhile; ?>
                    </div>
                    <span class="swiper-notification" aria-live="assertive" aria-atomic="true"></span>
                </div>
            </div>
        </section>
        <?php
    }
    $db = \Giftmax\modules\Db::getLnstance();
    global $wpdb;

    $records = $db->first("SELECT meta_value FROM `{$wpdb->prefix}setting` WHERE `meta_key` = :key", ['key' => 'tab']);
    if (!empty($records) && !empty($records['meta_value'])){
        ?>
        <section class="container-xl-w mx-auto mt-32">
            <div class="act-new-service-carousel-1st">
                <div class="act-new-service-carousel-head d-flex align-items-center justify-content-between">
                    <svg xmlns="http://www.w3.org/2000/svg" width="1281" height="75" viewBox="0 0 1281 75" fill="none" class="act-new-service-carousel-head-svg">
                        <path d="M1280.47 0.5H1000.91C986.771 0.5 979.703 0.5 973.764 2.99163C969.027 4.9789 964.838 8.07733 961.551 12.025C957.43 16.9747 955.361 23.7331 951.224 37.25C947.086 50.7669 945.017 57.5253 940.896 62.475C937.609 66.4227 933.42 69.5211 928.683 71.5084C922.744 74 915.676 74 901.54 74H412.882C399.847 74 393.329 74 387.813 71.8926C382.12 69.7177 377.167 65.9625 373.536 61.0686C370.017 56.3267 368.257 50.0512 364.737 37.5C361.217 24.9488 359.457 18.6733 355.938 13.9314C352.307 9.0375 347.353 5.2823 341.661 3.10737C336.145 1 329.627 1 316.592 1H0" stroke="url(#paint0_linear_29_20094)"></path>
                        <defs>
                            <linearGradient id="paint0_linear_29_20094" x1="29.4736" y1="0.500002" x2="1213.79" y2="-28.0511" gradientUnits="userSpaceOnUse">
                                <stop stop-color="#0B61FF" stop-opacity="0"></stop>
                                <stop offset="0.5" stop-color="#0B61FF"></stop>
                                <stop offset="1" stop-color="#0B61FF" stop-opacity="0"></stop>
                            </linearGradient>
                        </defs>
                    </svg>
                    <div class="act-our-services-carousel-head-title">
                        <div class="act-our-services-carousel-head-title-divs">
                            <div class="act-our-services-carousel-head-title-div1"></div>
                            <div class="act-our-services-carousel-head-title-div2"></div>
                        </div>
                        <div class="act-our-services-carousel-head-title-content">
                            <h5>خرید <strong>سریع</strong> </h5>
                            <p>QUICK PURCHASE</p>
                        </div>
                    </div>
                </div>
                <?php
                $tabs = [];

                if (!empty($records) && !empty($records['meta_value'])) {

                    $array = json_decode($records['meta_value'], true);

                    if (!empty($array)) {

                        foreach ($array as $tab_key => $item) {

                            $tabs[$tab_key] = [
                                'name'  => $item['name'],
                                'ids'   => !empty($item['value']) ? explode(',', $item['value']) : []
                            ];
                        }
                    }
                }
                ?>
                <div class="card-settings">
                    <div class="card-settings__tabs">
                        <?php
                        $first = true;

                        foreach ($tabs as $key => $item): ?>
                            <button
                                class="card-settings__tab <?= $first ? 'card-settings__tab--active' : '' ?>"
                                data-tab="<?= esc_attr($key) ?>">
                                <?= esc_html($item['name']) ?>
                            </button>
                            <?php
                            $first = false;
                        endforeach;
                        ?>
                    </div>
                    <div class="card-settings__loading">
                        <span class="card-settings__spinner"></span>
                        <span>در حال بارگذاری...</span>
                    </div>
                    <div class="card-settings__panel">
                        <div class="flex">
                            <div class="card-settings__content">
                                <div class="card-settings__field card-settings__field--wide">
                                    <label>نوع کارت</label>
                                    <div>
                                        <select class="js-example-basic-single select2-hidden-accessible" name="cardType" id="cardType"></select>
                                    </div>
                                </div>
                                <div class="card-settings__field">
                                    <label>ریجن کارت</label>
                                    <div>
                                        <select class="js-example-basic-single select2-hidden-accessible" id="cardRegion"></select>
                                    </div>
                                </div>
                                <div class="card-settings__field">
                                    <label>میزان اعتبار</label>
                                    <div>
                                        <select class="js-example-basic-single select2-hidden-accessible" id="cardAmount"></select>
                                    </div>
                                </div>
                            </div>

                            <div id="finalPrice">
                                <label>قیمت محصول</label>
                                <strong>-</strong>
                            </div>
                        </div>
                        <div class="card-settings__actions" id="card-settings__actions">
                        </div>
                    </div>
                </div>
                <?php
                $products_data = [];

                $products = wc_get_products([
                    'status' => 'publish',
                    'stock_status' => 'instock',
                    'limit'  => -1,
                ]);

                foreach ($products as $product) {
                    if (!$product->is_in_stock()) continue;
                    $delivery = get_post_meta($product->get_id(), 'delivery', true);
                    $is_presale = isset($delivery['two']) && $delivery['two'] == 'on';
                    if (!$is_presale && function_exists('product_available') && !product_available($product->get_id())) continue;
                    $pid = $product->get_id();
                    $cats = wp_get_post_terms($pid, 'product_cat');
                    if (empty($cats)) continue;
                    $product_cat_ids = [];
                    $category_label = '';
                    foreach ($cats as $cat) {
                        $product_cat_ids[] = $cat->term_id;
                        if ($category_label === '') {
                            $category_label = $cat->name;
                        }
                    }
                    $category_key = sanitize_title($category_label);

                    $current_tab = null;
                    foreach ($tabs as $t_key => $tab) {
                        $intersected_ids = array_intersect($product_cat_ids, $tab['ids']);
                        if (!empty($intersected_ids)) {
                            $current_tab = $t_key;
                            break;
                        }
                    }
                    $settings = get_post_meta($pid, 'giftmax_box_setting', true);
                    if (empty($settings[0]['region'])) continue;

                    $region = $settings[0]['logo_region'];

                    $products_data[$current_tab][$category_key]['label'] = $category_label;
                    $products_data[$current_tab][$category_key]['regions_meta'][$region] = regionPersian($region);
                    $products_data[$current_tab][$category_key]['regions'][$region][] = [
                        'id'    => $pid,
                        'title' => $product->get_name(),
                        'price' => number_format_usd($product->get_price()),
                    ];
                }
                ?>
                <script>
                    window.PRODUCTS = <?= json_encode($products_data, JSON_UNESCAPED_UNICODE); ?>;
                </script>
            </div>

        </section>

        <?php
    }
    ?>
    <section class="container-2xl-w mx-auto mt-32">
        <div class="act-new-service-carousel-1st" style="gap: 13px">
            <div class="act-new-service-carousel-head d-flex align-items-center justify-content-between">
                <svg xmlns="http://www.w3.org/2000/svg" width="1281" height="75" viewBox="0 0 1281 75" fill="none" class="act-new-service-carousel-head-svg">
                    <path d="M1280.47 0.5H1000.91C986.771 0.5 979.703 0.5 973.764 2.99163C969.027 4.9789 964.838 8.07733 961.551 12.025C957.43 16.9747 955.361 23.7331 951.224 37.25C947.086 50.7669 945.017 57.5253 940.896 62.475C937.609 66.4227 933.42 69.5211 928.683 71.5084C922.744 74 915.676 74 901.54 74H412.882C399.847 74 393.329 74 387.813 71.8926C382.12 69.7177 377.167 65.9625 373.536 61.0686C370.017 56.3267 368.257 50.0512 364.737 37.5C361.217 24.9488 359.457 18.6733 355.938 13.9314C352.307 9.0375 347.353 5.2823 341.661 3.10737C336.145 1 329.627 1 316.592 1H0" stroke="url(#paint0_linear_29_20094)"></path>
                    <defs>
                        <linearGradient id="paint0_linear_29_20094" x1="29.4736" y1="0.500002" x2="1213.79" y2="-28.0511" gradientUnits="userSpaceOnUse">
                            <stop stop-color="#0B61FF" stop-opacity="0"></stop>
                            <stop offset="0.5" stop-color="#0B61FF"></stop>
                            <stop offset="1" stop-color="#0B61FF" stop-opacity="0"></stop>
                        </linearGradient>
                    </defs>
                </svg>
                <div class="act-our-services-carousel-head-title">
                    <div class="act-our-services-carousel-head-title-divs">
                        <div class="act-our-services-carousel-head-title-div1"></div>
                        <div class="act-our-services-carousel-head-title-div2"></div>
                    </div>
                    <div class="act-our-services-carousel-head-title-content">
                        <h5> <strong>محصولات</strong> </h5>
                        <p>PRODUCTS</p>
                    </div>
                </div>
            </div>
            <div class="w-full">
                <div class="flex flex-col overflow-hidden">
                    <div class="flex">
                        <div class="act-shop-products-grid" style="position: relative;">
                            <?php
                            $giftmax_is_user_logged_in = is_user_logged_in();
                            $giftmax_wishlist_ids = $giftmax_is_user_logged_in ? giftmax_get_user_wishlist_product_ids() : [];
                            $paged = 1;
                            if (!empty( $_GET['page'])) {
                                $paged = $_GET['page'];
                            }
                                $args = array(
                                    'post_type' => 'product',
                                    'posts_per_page' => -1,
                                    'paged'          => $paged,
                                    'meta_query' => [
                                        [
                                            'key'     => 'giftmax_box_setting',
                                            'compare' => 'EXISTS'
                                        ],
                                        'relation' => 'AND',
                                        [
                                            'key'     => '_sale_price',
                                            'value'   => 0,
                                            'compare' => '>',
                                            'type'    => 'NUMERIC',
                                        ],
                                        [
                                            'relation' => 'OR',
                                            [
                                                'key'     => '_sale_price_dates_from',
                                                'compare' => 'NOT EXISTS',
                                            ],
                                            [
                                                'key'     => '_sale_price_dates_from',
                                                'value'   => $now,
                                                'compare' => '<=',
                                                'type'    => 'NUMERIC',
                                            ],
                                        ],

                                        [
                                            'key'     => '_sale_price_dates_to',
                                            'value'   => $now,
                                            'compare' => '>=',
                                            'type'    => 'NUMERIC',
                                        ],
                                    ]
                                );
                            $home_coupon_objects = [];
                            $home_coupon_ids = get_posts([
                                'post_type'      => 'shop_coupon',
                                'post_status'    => 'publish',
                                'numberposts'    => -1,
                                'fields'         => 'ids',
                            ]);

                            if (!empty($home_coupon_ids)) {
                                foreach ($home_coupon_ids as $home_coupon_id) {
                                    $home_coupon_objects[] = new \WC_Coupon($home_coupon_id);
                                }
                            }
                            $query = new WP_Query($args);
                            if ($query->have_posts()) {
                                while ($query->have_posts()) { $query->the_post(); global $product;
                                    $regular = $product->get_regular_price();
                                    $sale    = $product->get_sale_price();
                                    $final_price = $product->is_on_sale() && $sale > 0 ? $sale : $regular;
                                    $img = get_the_post_thumbnail_url(get_the_ID(), 'product_discount');
                                    $settings = get_post_meta($product->get_id(), 'giftmax_box_setting', true);
                                    $img = get_the_post_thumbnail_url(get_the_ID(), 'product_discount');
                                    $delivery = get_post_meta($product->get_id(), 'delivery', true);
                                    $sale_to = $product->get_date_on_sale_to();
                                    $sale_to_ts = $sale_to ? $sale_to->getTimestamp() : null;
                                    $matched_coupon_code = '';

                                    if (!empty($home_coupon_objects)) {
                                        foreach ($home_coupon_objects as $home_coupon_obj) {
                                            $expires_at = $home_coupon_obj->get_date_expires();

                                            if ($expires_at && $expires_at->getTimestamp() < current_time('timestamp')) {
                                                continue;
                                            }

                                            if ($home_coupon_obj->is_valid_for_product($product)) {
                                                $matched_coupon_code = $home_coupon_obj->get_code();
                                                break;
                                            }
                                        }
                                    }
                                    ?>
                                    <div class="act-new-service-card">
                                        <?php if (!empty($matched_coupon_code) && !isMobile()) { ?>
                                            <div class="act-new-service-card-discount Button-sc91" data-product-id="<?=esc_attr($product->get_id())?>">
                                                <div class="anScr"></div>
                                                <div class="anSct">مشاهده کد تخفیف</div>
                                                <div class="anScl"></div>
                                            </div>
                                        <?php } ?>
                                        <div class="act-new-service-card-inner">
                                            <div <?=isset($delivery['two']) && $delivery['two'] == 'on' || product_available($product->get_id()) ?'':'class="NdhJD5"'?>>
                                                <div class="act-new-service-card-inner-top">
                                                    <a href="<?=get_permalink()?>">
                                                        <div class="act-new-service-card-inner-top-img-box relative">
                                                            <img loading="lazy" decoding="async" width="32" height="33" src="<?=$img?>" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="">
                                                            <?php
                                                            if (!empty($settings[0]['logo_region'])){
                                                                ?>
                                                                <div class="logo_region">
                                                                    <img src="<?=empty($settings[0]['logo_region']) ?: get_template_directory_uri() . '/assets/flag/' . $settings[0]['logo_region'] . '.svg'?>">
                                                                </div>
                                                                <?php
                                                            }
                                                            $date_from = $product->get_date_on_sale_from();
                                                            $date_to   = $product->get_date_on_sale_to();
                                                            if ($product->is_on_sale() & ($date_from || $date_to)){                                                ?>
                                                                <div class="logo_detail" style="top: 7px;right: 7px;background-color: transparent;">
                                                                    <img width="33" height="29" src="<?=get_template_directory_uri()?>/assets/img/svg/Amazings.svg">
                                                                </div>
                                                                <?php
                                                            } elseif ($product->is_on_sale()){
                                                                ?>
                                                                <div class="logo_detail" style="top: 7px;right: 7px;">
                                                                    <img src="<?=get_template_directory_uri()?>/assets/img/svg/percent.svg">
                                                                </div>
                                                                <?php
                                                            }
                                                            ?>
                                                        </div>
                                                    </a>
                                                    <div class="act-new-service-card-inner-top-txt-box">
                                                        <a href="<?=get_permalink()?>">
                                                            <h4 class="act-product-title ellipsis-2"><?=get_the_title()?></h4>
                                                            <?php
                                                            if(!empty($settings[0]['sub_head'])) echo "<p class='act-product-title-en'>" . $settings[0]['sub_head'] . "</p>";
                                                            ?>
                                                        </a>
                                                        <div class="flex justify-between">
                                                            <div class="flex">
                                                                <?php
                                                                $tooltip = isset($delivery['description']) ? $delivery['description'] : '';
                                                                ?>
                                                                <div class="act-product-option-box__nw <?=isset($delivery['two']) && $delivery['two'] == 'on' ? 'pre-sale wiki wiki__holder js-dk-wiki-trigger' : 'same-day'?>" <?=isset($delivery['two']) && $delivery['two'] == 'on' ? 'data-tooltip="'. $tooltip .'"' :''?>><?=isset($delivery['two']) && $delivery['two'] == 'on' ? 'پیش فروش' : 'تحویل آنی'?></div>
                                                                <div class="purchaseScore wiki wiki__holder js-dk-wiki-trigger" data-tooltip="با خرید این گیفت کارت <?=empty($settings[0]['purchaseScore']) ?0: $settings[0]['purchaseScore']?> امتیاز دریافت میکنید">
                                                                    <i class="icon-star"></i><?=empty($settings[0]['purchaseScore']) ?0: $settings[0]['purchaseScore']?></div>
                                                            </div>
                                                            <?php
                                                            if ($giftmax_is_user_logged_in){
                                                                $is_in_wishlist = in_array((int) $product->get_id(), $giftmax_wishlist_ids, true); ?>
                                                                <button class="add-to__favorites Button-alu84 <?=$is_in_wishlist ? 'is-active' : ''?>" data-product-id="<?=esc_attr($product->get_id())?>" data-auth="<?=$giftmax_is_user_logged_in ? '1' : '0'?>" style="width: 28px;height: 28px;border-radius: 7px">
                                                                    <svg viewBox="0 0 24 24" style="width: 64%;">
                                                                        <path d="M12.62 20.81C12.28 20.93 11.72 20.93 11.38 20.81C8.48 19.82 2 15.69 2 8.68998C2 5.59998 4.49 3.09998 7.56 3.09998C9.38 3.09998 10.99 3.97998 12 5.33998C13.01 3.97998 14.63 3.09998 16.44 3.09998C19.51 3.09998 22 5.59998 22 8.68998C22 15.69 15.52 19.82 12.62 20.81Z" fill="<?=$is_in_wishlist ? '#ef4444' : 'none'?>" stroke="<?=$is_in_wishlist ? '#ef4444' : 'inherit'?>" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                                                                    </svg>
                                                                </button>
                                                                <?php
                                                            }
                                                            ?>
                                                        </div>
                                                        <?php if (!empty($matched_coupon_code) && isMobile()) { ?>
                                                            <div class="act-new-service-card-discount Button-sc91" data-product-id="<?=esc_attr($product->get_id())?>">
                                                                مشاهده کد تخفیف
                                                            </div>
                                                        <?php }else{ ?>
                                                            <p class="act-product-txt"><?=empty($settings[0]['description_short']) ?'': $settings[0]['description_short']?></p>
                                                            <?php
                                                        }
                                                        ?>                                            <?php
                                                        if (!empty($settings[0]['label']) && $settings[0]['label'] != ''){?>
                                                            <div class="label-fjd84">
                                                                <img src="<?=empty($settings[0]['label']) ?'': $settings[0]['label']?>" class="logo_label">
                                                                <p class="label_title"><?=empty($settings[0]['label_title']) ?'': $settings[0]['label_title']?></p>
                                                            </div>
                                                            <?php
                                                        }
                                                        ?>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="act-hor-bor"></div>
                                            <div>
                                                <?php
                                                if(!empty($matched_coupon_code)){
                                                    $usage_limit  = (int) $home_coupon_obj->get_usage_limit();
                                                    $usage_count  = (int) $home_coupon_obj->get_usage_count();

                                                    $remaining_uses = $usage_limit > 0
                                                        ? max( 0, $usage_limit - $usage_count )
                                                        : __( 'نامحدود', 'textdomain' );
                                                    ?>
                                                    <div class="">
                                                        <div class="relative bg-neutral-100 style_ProductPromotionTimeline__progress__JnKWE">
                                                            <div class="absolute bg-primary-700 h-full left-0 top-0 style_ProductPromotionTimeline--active__oYyta" style="width: <?=($home_coupon_obj->get_usage_count()/($home_coupon_obj->get_usage_count()+$remaining_uses))*100?>%;"></div>
                                                        </div>
                                                        <div class="whitespace-nowrap flex justify-between pt-1">
                                                            <div class=""><span class="text-primary-700 text-body-strong ml-1"><?=($home_coupon_obj->get_usage_count()/($home_coupon_obj->get_usage_count()+$remaining_uses))*100?>%</span><span class="text-neutral-500 text-caption">فروش رفته</span></div>
                                                            <?php
                                                            if ($home_coupon_obj->get_date_expires()){
                                                                ?>
                                                                <div class="text-primary-700 text-body2-strong style_ProductPromotionTimeline__timer__zS6ZA"><?= $home_coupon_obj->get_date_expires() ? $home_coupon_obj->get_date_expires()->date_i18n( 'Y-m-d H:i:s' ) : 'بدون تاریخ انقضا'?></div>
                                                                <?php
                                                            }else{?>
                                                                <div class="text-primary-700 text-body2-strong style_ProductPromotionTimeline__timer__zS6ZA"></div>
                                                            <?php }
                                                            ?>
                                                        </div>
                                                    </div>
                                                    <?php
                                                }
                                                ?>
                                                <div class="act-product-card-footer">
                                                    <a href="<?=the_permalink()?>" class="act-special-carousel-card-buy-box-option">جزئیات</a>
                                                    <div class="act-product-price-box">
                                                        <?php
                                                        if ( $sale && $regular > $sale ) {?>
                                                            <div class="act-product-price-box-top">
                                                                <div class="act-product-price-off-price"><?=number_format_usd($regular)?></div>
                                                                <div class="act-product-price-off-percent">  <?=get_discount_percent($product)?> ٪       </div>


                                                            </div>
                                                            <?php
                                                        }
                                                        ?>
                                                        <div class="act-product-price<?=$product->is_on_sale() ? ' bpt' : ''?>">
                                                            <?php
                                                            if($final_price > 0){?>
                                                                <div id="priceValue" data-id="<?=$product->get_id()?>" data-target="<?=payment_usd($product->is_on_sale() ? $sale :$regular)?>"><?=number_format_usd($product->is_on_sale() ? $sale : $regular)?></div>
                                                                <span>تومان</span>
                                                                <?php
                                                            }else{
                                                                ?>
                                                                <div class="act-product-price-free">رایگان</div>
                                                                <?php
                                                            }
                                                            ?>
                                                        </div>
                                                    </div>
                                                </div>
                                                <?php
                                                if (isset($delivery['two']) && $delivery['two'] == 'on' || product_available($product->get_id())){?>
                                                    <button type="button" class="act-special-carousel-card-buy-box-but Button-aca49 pointer" data-product-id="<?=$product->get_id()?>">
                                                        <svg xmlns="http://www.w3.org/2000/svg" width="26" height="26" viewBox="0 0 26 26" fill="currentcolor">
                                                            <path d="M17.875 9.34916C17.4308 9.34916 17.0625 8.98083 17.0625 8.53666V7.04166C17.0625 5.90416 16.575 4.79916 15.73 4.03C14.8742 3.25 13.7692 2.8925 12.5992 3.00083C10.6492 3.185 8.9375 5.17833 8.9375 7.25833V8.30916C8.9375 8.75333 8.56917 9.12166 8.125 9.12166C7.68083 9.12166 7.3125 8.75333 7.3125 8.30916V7.2475C7.3125 4.33333 9.66333 1.64666 12.4475 1.37583C14.0725 1.22417 15.6325 1.73333 16.8242 2.8275C18.005 3.9 18.6875 5.43833 18.6875 7.04166V8.53666C18.6875 8.98083 18.3192 9.34916 17.875 9.34916Z"></path>
                                                            <path d="M16.2498 24.6457H9.7498C4.7448 24.6457 3.81314 22.3165 3.5748 20.0523L2.7623 13.5632C2.64314 12.3932 2.5998 10.714 3.7373 9.45734C4.7123 8.374 6.32647 7.854 8.66647 7.854H17.3331C19.684 7.854 21.2981 8.38484 22.2623 9.45734C23.389 10.714 23.3565 12.3932 23.2373 13.5415L22.4248 20.0523C22.1865 22.3165 21.2548 24.6457 16.2498 24.6457ZM8.66647 9.479C6.83564 9.479 5.57897 9.8365 4.9398 10.5515C4.40897 11.1365 4.23564 12.0357 4.37647 13.379L5.18897 19.8682C5.37314 21.6015 5.8498 23.0315 9.7498 23.0315H16.2498C20.1498 23.0315 20.6265 21.6123 20.8106 19.8898L21.6231 13.379C21.764 12.0573 21.5906 11.1582 21.0598 10.5623C20.4206 9.8365 19.164 9.479 17.3331 9.479H8.66647Z"></path>
                                                            <path d="M16.7045 14.2458C16.0979 14.2458 15.6104 13.7583 15.6104 13.1624C15.6104 12.5666 16.0979 12.0791 16.6937 12.0791C17.2895 12.0791 17.777 12.5666 17.777 13.1624C17.777 13.7583 17.3004 14.2458 16.7045 14.2458Z"></path>
                                                            <path d="M9.12151 14.2458C8.51484 14.2458 8.02734 13.7583 8.02734 13.1624C8.02734 12.5666 8.51484 12.0791 9.11068 12.0791C9.70651 12.0791 10.194 12.5666 10.194 13.1624C10.194 13.7583 9.71734 14.2458 9.12151 14.2458Z"></path>
                                                        </svg>
                                                        افزودن به سبد خرید
                                                    </button>
                                                    <?php
                                                }else{
                                                    echo '<div class="inaJSDge8">ناموجود</div>';
                                                }
                                                ?>
                                            </div>
                                        </div>
                                    </div>
                                    <?php
                                }
                            }else{
                                echo "محصولی موجود نمیباشد";
                            }
                            ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>
