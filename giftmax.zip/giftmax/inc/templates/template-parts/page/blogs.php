<main>
    <section class="container-2xl-w mx-auto mt-32 nav__box">
        <nav class="rad-breadcrumb rad-woo-bread">
            <a class="kp-pl" href="<?=home_url()?>">  صفحه اصلی  </a>
            <span class="sep">
                <svg xmlns="http://www.w3.org/2000/svg" width="1" height="24" viewBox="0 0 1 24" stroke="currentcolor">
                    <line x1="0.5" y1="2.18557e-08" x2="0.499999" y2="24"></line>
                </svg>
            </span>
            <span class="kp-pn">آرشیو مقالات</span>
        </nav>
    </section>
    <section class="container-2xl-w mx-auto">
        <div class="flex">
            <div class="act-filter-box-1st">
                <svg xmlns="http://www.w3.org/2000/svg" fill="rgb(255, 255, 255)" viewBox="0 0 307.1503759398496 146.304" width="100%" height="146.304" class="act-filter-box-1st-bg">
                    <mask fill="white" id="path-1-inside-1_2005_10357">
                        <path d="M306 77C306 63.7452 295.255 53 282 53H209.738C202.332 53 195.341 49.5807 190.794 43.7347L163.984 9.26532C159.437 3.41931 152.446 0 145.039 0H24C10.7452 0 0 10.7452 0 24V552C0 565.255 10.7452 576 24 576H282C295.255 576 306 565.255 306 552V77Z"></path>
                    </mask>
                    <path d="M306 77C306 63.7452 295.255 53 282 53H209.738C202.332 53 195.341 49.5807 190.794 43.7347L163.984 9.26532C159.437 3.41931 152.446 0 145.039 0H24C10.7452 0 0 10.7452 0 24V552C0 565.255 10.7452 576 24 576H282C295.255 576 306 565.255 306 552V77Z"></path>
                    <path mask="url(#path-1-inside-1_2005_10357)" fill="rgba(11, 21, 48, 0.06)" class="act-filter-box-1st-bg-border" d="M163.984 9.26532L164.773 8.65138L163.984 9.26532ZM190.794 43.7347L190.004 44.3486L190.794 43.7347ZM282 53V54H209.738V53V52H282V53ZM190.794 43.7347L190.004 44.3486L163.194 9.87927L163.984 9.26532L164.773 8.65138L191.583 43.1207L190.794 43.7347ZM145.039 0V1H24V0V-1H145.039V0ZM0 24H1V552H0H-1V24H0ZM24 576V575H282V576V577H24V576ZM306 552H305V77H306H307V552H306ZM282 576V575C294.703 575 305 564.703 305 552H306H307C307 565.807 295.807 577 282 577V576ZM0 552H1C1 564.703 11.2975 575 24 575V576V577C10.1929 577 -1 565.807 -1 552H0ZM24 0V1C11.2974 1 1 11.2975 1 24H0H-1C-1 10.1929 10.1929 -1 24 -1V0ZM163.984 9.26532L163.194 9.87927C158.837 4.27683 152.137 1 145.039 1V0V-1C152.754 -1 160.037 2.56178 164.773 8.65138L163.984 9.26532ZM209.738 53V54C202.023 54 194.741 50.4382 190.004 44.3486L190.794 43.7347L191.583 43.1207C195.94 48.7232 202.64 52 209.738 52V53ZM282 53V52C295.807 52 307 63.1929 307 77H306H305C305 64.2974 294.703 54 282 54V53Z"></path>
                </svg>
                <div class="act-filter-box-head d-flex align-items-center justify-content-between w-100">
                    <div class="act-filter-box-head-text">
                        <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 32 32" fill="none"><path d="M21.0666 2.94633C20.5199 2.39967 19.5732 2.773 19.5732 3.533V8.18633C19.5732 10.133 21.2266 11.7463 23.2399 11.7463C24.5066 11.7597 26.2666 11.7597 27.7732 11.7597C28.5332 11.7597 28.9332 10.8663 28.3999 10.333C26.4799 8.39966 23.0399 4.91967 21.0666 2.94633Z" fill="url(#paint0_linear_828_5348)"></path><path d="M27.333 13.587H23.4797C20.3197 13.587 17.7463 11.0137 17.7463 7.85366V4.00033C17.7463 3.26699 17.1463 2.66699 16.413 2.66699H10.7597C6.65301 2.66699 3.33301 5.33366 3.33301 10.0937V21.907C3.33301 26.667 6.65301 29.3337 10.7597 29.3337H21.2397C25.3463 29.3337 28.6663 26.667 28.6663 21.907V14.9203C28.6663 14.187 28.0663 13.587 27.333 13.587ZM15.333 23.667H9.99967C9.45301 23.667 8.99967 23.2137 8.99967 22.667C8.99967 22.1203 9.45301 21.667 9.99967 21.667H15.333C15.8797 21.667 16.333 22.1203 16.333 22.667C16.333 23.2137 15.8797 23.667 15.333 23.667ZM17.9997 18.3337H9.99967C9.45301 18.3337 8.99967 17.8803 8.99967 17.3337C8.99967 16.787 9.45301 16.3337 9.99967 16.3337H17.9997C18.5463 16.3337 18.9997 16.787 18.9997 17.3337C18.9997 17.8803 18.5463 18.3337 17.9997 18.3337Z" fill="url(#paint1_linear_828_5348)"></path><defs><linearGradient id="paint0_linear_828_5348" x1="24.1086" y1="-9.60002" x2="24.1086" y2="9.86943" gradientUnits="userSpaceOnUse"><stop stop-color="#00D1B2"></stop><stop offset="1" stop-color="#F5F9FF"></stop></linearGradient><linearGradient id="paint1_linear_828_5348" x1="15.9997" y1="-33.4441" x2="15.9997" y2="23.7781" gradientUnits="userSpaceOnUse"><stop stop-color="#00D1B2"></stop><stop offset="1" stop-color="#F5F9FF"></stop></linearGradient></defs></svg><p>مقــــالات</p>                </div>
                </div>
                <?php
                $cat_args = [
                'orderby'    => 'name',
                'order'      => 'ASC',
                'hide_empty' => false,  // حتی دسته‌های خالی هم نمایش داده شوند
                ];

                $categories = get_categories( $cat_args );
                ?>

                <div class="act-filter-box-main">
                    <div class="act-filter-box-main-label">
                        <h2 class="act-filter-box-main-label-title">دسته بندی ها</h2>
                    </div>

                    <div class="act-filter-box-main-blogs-filter-wrapper">

                        <?php foreach ( $categories as $cat ) : ?>
                            <?php
                            $cat_link = get_category_link( $cat->term_id );
                            $cat_name = esc_html( $cat->name );
                            $cat_count = $cat->count;
                            ?>
                            <a class="act-catagory-card pointer B-item__blog" href="<?php echo esc_url( $cat_link ); ?>">
                                <div class="act-catagory-card-inner">
                                    <div class="act-catagory-card-name">
                                        <div class="act-our-services-carousel-head-title-divs">
                                            <div class="act-our-services-carousel-head-title-div1" style="height: 15px;  margin-bottom: 4px;"></div>
                                            <div class="act-our-services-carousel-head-title-div2" style=" height: 12px;"></div>
                                        </div>
                                        <div class="act-catagory-name-text">
                                            <strong><?=$cat->name?></strong>
                                            <p><?=$cat_name?></p>
                                        </div>
                                    </div>
                                    <div class="act-catagory-card-blog">
                                        <span><strong><?=$cat_count?></strong> مطلب </span>
                                    </div>
                                </div>
                            </a>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
            <div class="flex flex-col gap-6" style="margin-right: 13px;width: 100%;">
                <div class="act-archive-blogs-1st">

                    <?php
                    global $wp_query;

                    $paged = (get_query_var('paged') ? get_query_var('paged') : 1);

                    $args = array(
                        'post_type' => 'post',
                        'posts_per_page' => 16,
                        'paged'          => $paged,
                    );
                    /*$args = array(
                        'post_type' => 'post',
                        'posts_per_page' => 8,
                        'paged'          => $paged,
                        'tax_query' => array(
                            array(
                                'taxonomy' => 'post_cat',
                                'field'    => 'term_id',
                                'terms'    => $current_cat->term_id,
                            ),
                        ),
                    );*/
                    $query = new WP_Query($args);
                    ?>
                    <div class="act-archive-blogs-main d-grid act-cols-3">
                        <?php
                        if ($query->have_posts()) {
                            while ($query->have_posts()) { $query->the_post();
                        ?>
                        <a href="<?=get_permalink()?>" class="act-archive-blogs-card act-bg-hover">
                            <div class="act-archive-blogs-card-inner act-bg-hover-inner">
                                <div class="act-blog-card-img-box-label"><?=get_the_category()[0]->name?></div>

                                <img class="act-archive-blogs-card-img" src="<?=get_the_post_thumbnail_url()?>" alt="<?=get_the_title()?>">

                                <h4 class="act-product-title act-2line"><?=get_the_title()?></h4>

                                <p class="act-blog-card-text act-2line"><?=get_the_excerpt()?></p>

                                <div class="act-blog-card-footer d-flex align-items-center justify-content-between md:border-t-[1px] md:border-t-[#EDEEF2] pts-4">
                                    <div class="act-blog-card-footer-read-time">
                                        <div class="flex align-items-center ml-1"><i class="icon-eye"></i><p><?= view_giftmax(get_the_ID())?></p></div><div class="flex align-items-center"><i class="icon-clock"></i><?=gjdate(get_the_date('Y-m-d'),"d M Y")?></div><div class="flex align-items-center"><i class="icon-user"></i><?=giftmax_get_author_full_name()?></div></div>
                                </div>

                            </div>
                        </a>
                        <?php
                            }
                        }
                        ?>
                    </div>
                    <?php
                    $total_pages = $query->max_num_pages;

                    if ( $total_pages > 1 ) :
                        $current_page = max(1, $paged);
                        ?>
                        <div class="navigation pagination act-shop-pagination">
                            <div class="navigation pagination act-shop-pagination">
                                <div class="nav-links">

                                    <?php
                                    echo paginate_links( array(
                                        'base'      => get_pagenum_link(1) . '%_%',   // لینک پایه برای صفحه‌ی اول
                                        'format'    => 'page/%#%/',                  // در pretty permalinks
                                        'current'   => $paged,                        // صفحه‌ی فعلی
                                        'total'     => $query->max_num_pages,         // تعداد صفحات کل
                                        'prev_next' => true,
                                        'prev_text' => __('« پیشین', 'textdomain'),
                                        'next_text' => __('بعدی »', 'textdomain'),
                                    ) );

                                    ?>

                                </div>

                                <div class="act-vb"></div>

                                <div class="act-pagination-arrows">
                                    <!-- Prev -->
                                    <?php if ( $current_page > 1 ) : ?>
                                    <a class="prev page-numbers" href="<?php echo get_pagenum_link($current_page - 1); ?>">
                                        <?php else : ?>
                                        <a class="prev page-numbers act-disabled" href="#">
                                            <?php endif; ?>
                                            <!-- SVG Prev -->
                                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="currentColor">
                                                <path d="M12.0253 15.6833C11.8669 15.6833 11.7086 15.625 11.5836 15.5C11.3419 15.2583 11.3419 14.8583 11.5836 14.6166L16.2003 9.99998L11.5836 5.38331C11.3419 5.14164 11.3419 4.74164 11.5836 4.49998C11.8253 4.25831 12.2253 4.25831 12.4669 4.49998L17.5253 9.55831C17.7669 9.79998 17.7669 10.2 17.5253 10.4416L12.4669 15.5C12.3419 15.625 12.1836 15.6833 12.0253 15.6833Z"/>
                                                <path d="M16.942 10.625H2.91699C2.57533 10.625 2.29199 10.3417 2.29199 10C2.29199 9.65833 2.57533 9.375 2.91699 9.375H16.942C17.2837 9.375 17.567 9.65833 17.567 10C17.567 10.3417 17.2837 10.625 16.942 10.625Z"/>
                                            </svg>
                                        </a>

                                        <!-- Next -->
                                        <?php if ( $current_page < $total_pages ) : ?>
                                        <a class="next page-numbers" href="<?php echo get_pagenum_link($current_page + 1); ?>">
                                            <?php else : ?>
                                            <a class="next page-numbers act-disabled" href="#">
                                                <?php endif; ?>
                                                <!-- SVG Next -->
                                                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="currentColor">
                                                    <path d="M7.97474 4.31669C8.13307 4.31669 8.29141 4.37502 8.41641 4.50002C8.65807 4.74169 8.65807 5.14169 8.41641 5.38336L3.79974 10L8.41641 14.6167C8.65807 14.8584 8.65807 15.2584 8.41641 15.5C8.17474 15.7417 7.77474 15.7417 7.53307 15.5L2.47474 10.4417C2.23307 10.2 2.23307 9.80002 2.47474 9.55836L7.53307 4.50002C7.65807 4.37502 7.81641 4.31669 7.97474 4.31669Z"/>
                                                    <path d="M3.05801 9.375L17.083 9.375C17.4247 9.375 17.708 9.65833 17.708 10C17.708 10.3417 17.4247 10.625 17.083 10.625L3.05801 10.625C2.71634 10.625 2.43301 10.3417 2.43301 10C2.43301 9.65833 2.71634 9.375 3.05801 9.375Z"/>
                                                </svg>
                                            </a>
                                </div>
                            </div>
                        </div>
                    <?php endif; wp_reset_postdata(); ?>
                </div>
            </div>
        </div>
    </section>
</main>
