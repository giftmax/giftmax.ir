<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>حساب کاربری | گیفت مکس دیجیتال</title>
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link
            href="https://fonts.googleapis.com/css2?family=Vazirmatn:wght@300;400;500;600;700;800&display=swap"
            rel="stylesheet"
    />
    <link rel="stylesheet" href="assets/css/cart.css" />
</head>
<body>
<header class="site-header">
    <div class="site-header__bar">
        <div class="container">
            <div class="site-header__support">
                <span>پشتیبانی ۲۴ ساعته | فعال‌سازی آنی</span>
                <a href="tel:02175390" class="link">۰۲۱-۷۵۳۹۰</a>
            </div>
            <div class="site-header__auth">
                <a href="account.html" class="btn btn--ghost">پنل کاربری</a>
                <a href="cart.php" class="btn btn--gradient">سبد خرید</a>
            </div>
        </div>
    </div>
    <div class="site-header__main">
        <div class="container">
            <button type="button" class="menu-toggle" id="menuToggle" aria-label="باز کردن منو">
                <span></span>
                <span></span>
                <span></span>
            </button>
            <a class="brand" href="index.php#top">
                <span class="brand__icon">🎁</span>
                <span class="brand__text">
              <strong>گیفت مکس دیجیتال</strong>
              <small>فروشگاه گیفت کارت اپل و سرویس‌های بین‌المللی</small>
            </span>
            </a>
            <nav class="primary-nav" id="primaryNav">
                <a href="index.php#overview">معرفی محصول</a>
                <a href="index.php#benefits">مزایا</a>
                <a href="index.php#guide">راهنمای فعال‌سازی</a>
                <a href="index.php#bundles">محصولات مرتبط</a>
                <a href="index.php#faq">سؤالات متداول</a>
                <a href="index.php#support">پشتیبانی</a>
            </nav>
            <div class="site-header__search">
                <button type="button" class="search-toggle" id="searchToggle" aria-label="جستجو">
                    <span class="icon-search"></span>
                    <span>جستجو</span>
                </button>
                <div class="search-panel" id="searchPanel">
                    <input type="text" placeholder="نام محصول یا ریجن مورد نظر را وارد کنید" />
                    <button type="button" class="btn btn--gradient">جستجو</button>
                </div>
            </div>
        </div>
    </div>
    <div class="mobile-nav" id="mobileNav">
        <a href="index.php#overview">معرفی محصول</a>
        <a href="index.php#benefits">مزایا</a>
        <a href="index.php#guide">راهنمای فعال‌سازی</a>
        <a href="index.php#bundles">محصولات مرتبط</a>
        <a href="index.php#faq">سؤالات متداول</a>
        <a href="index.php#support">پشتیبانی</a>
    </div>
</header>

<main class="account-page">
    <section class="account-hero">
        <div class="container">
            <nav aria-label="مسیر دسترسی" class="breadcrumbs">
                <ol>
                    <li><a href="index.php">خانه</a></li>
                    <li aria-current="page">حساب کاربری</li>
                </ol>
            </nav>
            <div class="account-hero__content">
                <div class="account-hero__profile">
                    <div class="account-avatar" aria-hidden="true">م</div>
                    <div>
                        <h1>سلام، محمدرضا عزیز! 👋</h1>
                        <p>
                            خوش آمدید به پنل کاربری گیفت مکس دیجیتال. وضعیت حساب، سفارش‌ها و پشتیبانی خود را در یک نگاه
                            مدیریت کنید.
                        </p>
                        <div class="account-hero__badges">
                            <span class="account-badge"><span class="icon-star"></span> عضویت طلایی</span>
                            <span class="account-badge"><span class="icon-shield"></span> احراز هویت شده</span>
                            <span class="account-badge"><span class="icon-gift"></span> ۳ کد فعال</span>
                        </div>
                    </div>
                </div>
                <div class="account-hero__stats">
                    <div>
                        <span>اعتبار کیف پول</span>
                        <strong>۱,۴۵۰,۰۰۰ تومان</strong>
                        <small>آخرین بروزرسانی: ۵ دقیقه پیش</small>
                    </div>
                    <div>
                        <span>امتیاز وفاداری</span>
                        <strong>۲,۸۴۰ امتیاز</strong>
                        <small>قابل تبدیل به ۲۸۴,۰۰۰ تومان</small>
                    </div>
                    <div>
                        <span>در حال پردازش</span>
                        <strong>۲ سفارش</strong>
                        <small>تحویل حداکثر تا ۱۵ دقیقه آینده</small>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="account-shell">
        <div class="container account-shell__layout">
            <aside class="account-sidebar" aria-label="منوی حساب کاربری">
                <div class="account-sidebar__card">
                    <div class="account-sidebar__header">
                        <div class="account-avatar account-avatar--sm" aria-hidden="true">م</div>
                        <div>
                            <strong>محمدرضا رستگار</strong>
                            <span>شماره کاربری: GMX-45821</span>
                        </div>
                    </div>
                    <div class="account-progress">
                        <div class="account-progress__label">
                            <span>درصد تکمیل پروفایل</span>
                            <span>۸۰٪</span>
                        </div>
                        <div class="progress-bar">
                            <span style="width: 80%"></span>
                        </div>
                        <button type="button" class="btn btn--outline btn--block" data-panel-trigger="settings">تکمیل اطلاعات</button>
                    </div>
                </div>

                <nav class="account-nav" role="tablist">
                    <button
                            type="button"
                            class="account-nav__item active"
                            data-panel="dashboard"
                            role="tab"
                            aria-controls="panel-dashboard"
                            aria-selected="true"
                    >
                        <span class="icon-home"></span>
                        داشبورد
                    </button>
                    <button
                            type="button"
                            class="account-nav__item"
                            data-panel="orders"
                            role="tab"
                            aria-controls="panel-orders"
                            aria-selected="false"
                    >
                        <span class="icon-bag"></span>
                        سفارش‌های من
                    </button>
                    <button
                            type="button"
                            class="account-nav__item"
                            data-panel="deliveries"
                            role="tab"
                            aria-controls="panel-deliveries"
                            aria-selected="false"
                    >
                        <span class="icon-code"></span>
                        کدهای تحویل‌شده
                    </button>
                    <button
                            type="button"
                            class="account-nav__item"
                            data-panel="wallet"
                            role="tab"
                            aria-controls="panel-wallet"
                            aria-selected="false"
                    >
                        <span class="icon-wallet"></span>
                        کیف پول و امتیاز
                    </button>
                    <button
                            type="button"
                            class="account-nav__item"
                            data-panel="support"
                            role="tab"
                            aria-controls="panel-support"
                            aria-selected="false"
                    >
                        <span class="icon-support"></span>
                        درخواست‌های پشتیبانی
                    </button>
                    <button
                            type="button"
                            class="account-nav__item"
                            data-panel="affiliate"
                            role="tab"
                            aria-controls="panel-affiliate"
                            aria-selected="false"
                    >
                        <span class="icon-megaphone"></span>
                        همکاری در فروش
                    </button>
                    <button
                            type="button"
                            class="account-nav__item"
                            data-panel="settings"
                            role="tab"
                            aria-controls="panel-settings"
                            aria-selected="false"
                    >
                        <span class="icon-settings"></span>
                        تنظیمات حساب
                    </button>
                    <button
                            type="button"
                            class="account-nav__item"
                            data-panel="security"
                            role="tab"
                            aria-controls="panel-security"
                            aria-selected="false"
                    >
                        <span class="icon-lock"></span>
                        امنیت و ورود
                    </button>
                    <button
                            type="button"
                            class="account-nav__item"
                            data-panel="notifications"
                            role="tab"
                            aria-controls="panel-notifications"
                            aria-selected="false"
                    >
                        <span class="icon-bell"></span>
                        اطلاع‌رسانی‌ها
                    </button>
                </nav>

                <div class="account-sidebar__card">
                    <h3>نیاز به کمک دارید؟</h3>
                    <p>تیم پشتیبانی ما به صورت ۲۴/۷ آماده پاسخگویی است.</p>
                    <div class="account-sidebar__actions">
                        <a href="tel:02175390" class="btn btn--gradient">تماس با پشتیبانی</a>
                        <button type="button" class="btn btn--outline" data-panel-trigger="support">ارسال تیکت</button>
                    </div>
                </div>
            </aside>

            <div class="account-content">
                <div
                        class="account-panel active"
                        id="panel-dashboard"
                        data-panel="dashboard"
                        role="tabpanel"
                        aria-hidden="false"
                        tabindex="0"
                >
                    <header class="account-panel__header">
                        <div>
                            <h2>داشبورد</h2>
                            <p>عملکرد کلی حساب، وضعیت سفارش‌ها و میانبرهای کاربردی در یک نگاه.</p>
                        </div>
                        <a href="index.php#bundles" class="btn btn--gradient">خرید گیفت کارت جدید</a>
                    </header>

                    <div class="account-grid">
                        <article class="account-card account-card--stat">
                            <span class="account-card__icon icon-bolt"></span>
                            <div class="account-card__body">
                                <h3>تحویل آنی</h3>
                                <p>میانگین زمان تحویل ۵ دقیقه است. ۹۵٪ سفارش‌ها در کمتر از ۳ دقیقه تحویل شدند.</p>
                            </div>
                        </article>
                        <article class="account-card account-card--stat">
                            <span class="account-card__icon icon-wallet"></span>
                            <div class="account-card__body">
                                <h3>وضعیت اعتبار</h3>
                                <p>موجودی کیف پول شما برای خرید ۲ گیفت کارت ۵۰ دلاری کافی است.</p>
                            </div>
                            <button type="button" class="account-card__action" data-panel-trigger="wallet">مدیریت کیف پول</button>
                        </article>
                        <article class="account-card account-card--stat">
                            <span class="account-card__icon icon-support"></span>
                            <div class="account-card__body">
                                <h3>تیکت‌های باز</h3>
                                <p>۲ درخواست در انتظار پاسخ شماست. لطفاً وضعیت را بررسی کنید.</p>
                            </div>
                            <button type="button" class="account-card__action" data-panel-trigger="support">مشاهده درخواست‌ها</button>
                        </article>
                        <article class="account-card account-card--stat">
                            <span class="account-card__icon icon-megaphone"></span>
                            <div class="account-card__body">
                                <h3>پیشنهاد عضویت سازمانی</h3>
                                <p>با خرید تجمیعی ماهانه بالای ۱۵ میلیون تومان، از تخفیف سازمانی بهره‌مند شوید.</p>
                            </div>
                            <a class="account-card__action" href="#support">درخواست مشاوره</a>
                        </article>
                    </div>

                    <div class="account-panel__section">
                        <header>
                            <h3>میانبرهای سریع</h3>
                            <p>برای انجام سریع‌ترین عملیات از میانبرهای زیر استفاده کنید.</p>
                        </header>
                        <div class="quick-actions">
                            <button type="button" class="quick-actions__item" data-panel-trigger="orders">
                                <span class="icon-bag"></span>
                                <div>
                                    <strong>پیگیری سفارش</strong>
                                    <small>وضعیت لحظه‌ای سفارش‌های اخیر</small>
                                </div>
                            </button>
                            <button type="button" class="quick-actions__item" data-panel-trigger="deliveries">
                                <span class="icon-code"></span>
                                <div>
                                    <strong>دریافت کد مجدد</strong>
                                    <small>نمایش آخرین کدهای تحویل‌شده</small>
                                </div>
                            </button>
                            <button type="button" class="quick-actions__item" data-panel-trigger="wallet">
                                <span class="icon-wallet"></span>
                                <div>
                                    <strong>شارژ کیف پول</strong>
                                    <small>پرداخت امن و فوری</small>
                                </div>
                            </button>
                            <button type="button" class="quick-actions__item" data-panel-trigger="affiliate">
                                <span class="icon-megaphone"></span>
                                <div>
                                    <strong>لینک دعوت</strong>
                                    <small>دریافت کمیسیون معرفی دوستان</small>
                                </div>
                            </button>
                        </div>
                    </div>
                </div>

                <div
                        class="account-panel"
                        id="panel-orders"
                        data-panel="orders"
                        role="tabpanel"
                        aria-hidden="true"
                        tabindex="0"
                        hidden
                >
                    <header class="account-panel__header">
                        <div>
                            <h2>سفارش‌های من</h2>
                            <p>تمام خریدهای شما به تفکیک وضعیت، کد و تاریخ تحویل.</p>
                        </div>
                        <button type="button" class="btn btn--outline">دانلود گزارش اکسل</button>
                    </header>
                    <div class="filter-chips" role="toolbar" aria-label="فیلتر سفارش‌ها">
                        <button type="button" class="chip active">همه سفارش‌ها</button>
                        <button type="button" class="chip">در انتظار پرداخت</button>
                        <button type="button" class="chip">در حال پردازش</button>
                        <button type="button" class="chip">تحویل شده</button>
                        <button type="button" class="chip">لغو شده</button>
                    </div>
                    <div class="data-card">
                        <table class="data-table">
                            <thead>
                            <tr>
                                <th>کد سفارش</th>
                                <th>محصول</th>
                                <th>تاریخ</th>
                                <th>مبلغ</th>
                                <th>وضعیت</th>
                                <th>اقدامات</th>
                            </tr>
                            </thead>
                            <tbody>
                            <tr>
                                <td>#GMX-98452</td>
                                <td>گیفت کارت اپل ۵۰ دلاری آمریکا</td>
                                <td>۲۳ اردیبهشت ۱۴۰۳</td>
                                <td>۱,۹۵۰,۰۰۰ تومان</td>
                                <td><span class="status-pill status-pill--processing">در حال پردازش</span></td>
                                <td><button type="button" class="link" data-panel-trigger="deliveries">نمایش کد</button></td>
                            </tr>
                            <tr>
                                <td>#GMX-97213</td>
                                <td>گیفت کارت آیتونز ۲۵ دلاری</td>
                                <td>۲۰ اردیبهشت ۱۴۰۳</td>
                                <td>۹۸۰,۰۰۰ تومان</td>
                                <td><span class="status-pill status-pill--completed">تحویل شده</span></td>
                                <td><button type="button" class="link" data-panel-trigger="support">گزارش مشکل</button></td>
                            </tr>
                            <tr>
                                <td>#GMX-96388</td>
                                <td>اشتراک Apple Music سه ماهه</td>
                                <td>۱۶ اردیبهشت ۱۴۰۳</td>
                                <td>۶۹۰,۰۰۰ تومان</td>
                                <td><span class="status-pill status-pill--completed">تحویل شده</span></td>
                                <td><button type="button" class="link" data-panel-trigger="deliveries">دانلود فاکتور</button></td>
                            </tr>
                            <tr>
                                <td>#GMX-95410</td>
                                <td>گیفت کارت استیم ۲۰ دلاری</td>
                                <td>۱۰ اردیبهشت ۱۴۰۳</td>
                                <td>۸۹۰,۰۰۰ تومان</td>
                                <td><span class="status-pill status-pill--refunded">بازگشت وجه</span></td>
                                <td><button type="button" class="link" data-panel-trigger="support">گزارش پشتیبانی</button></td>
                            </tr>
                            </tbody>
                        </table>
                    </div>
                </div>

                <div
                        class="account-panel"
                        id="panel-deliveries"
                        data-panel="deliveries"
                        role="tabpanel"
                        aria-hidden="true"
                        tabindex="0"
                        hidden
                >
                    <header class="account-panel__header">
                        <div>
                            <h2>کدهای تحویل‌شده</h2>
                            <p>کدهای گیفت کارت فعال‌شده و وضعیت ریدیم برای هر سفارش.</p>
                        </div>
                        <button type="button" class="btn btn--outline">دانلود همه کدها</button>
                    </header>
                    <div class="delivery-grid">
                        <article class="delivery-card">
                            <header>
                                <span class="badge badge--success">فعال شده</span>
                                <time datetime="2024-05-20">۲۰ اردیبهشت ۱۴۰۳</time>
                            </header>
                            <h3>Apple Gift Card 25$ United States</h3>
                            <p>کد ریدیم: <strong>APPL-7K9Q-4XSF-AL9P</strong></p>
                            <footer>
                                <button type="button" class="btn btn--outline">کپی کد</button>
                                <button type="button" class="link">آموزش ریدیم</button>
                            </footer>
                        </article>
                        <article class="delivery-card">
                            <header>
                                <span class="badge badge--pending">در انتظار ریدیم</span>
                                <time datetime="2024-05-23">۲۳ اردیبهشت ۱۴۰۳</time>
                            </header>
                            <h3>Apple Music Subscription 3 Months</h3>
                            <p>کد ریدیم: <strong>MSIC-8AS2-JWQ9-ZX3P</strong></p>
                            <footer>
                                <button type="button" class="btn btn--gradient">تأیید مصرف</button>
                                <button type="button" class="link" data-panel-trigger="support">نیاز به کمک دارم</button>
                            </footer>
                        </article>
                        <article class="delivery-card">
                            <header>
                                <span class="badge badge--expired">منقضی شده</span>
                                <time datetime="2024-04-12">۲۳ فروردین ۱۴۰۳</time>
                            </header>
                            <h3>Steam Wallet Code 20$</h3>
                            <p>کد ریدیم: <strong>STEA-5LPO-3NKH-FF21</strong></p>
                            <footer>
                                <button type="button" class="btn btn--outline">درخواست بررسی</button>
                                <button type="button" class="link">راهنمای تمدید</button>
                            </footer>
                        </article>
                    </div>
                </div>

                <div
                        class="account-panel"
                        id="panel-wallet"
                        data-panel="wallet"
                        role="tabpanel"
                        aria-hidden="true"
                        tabindex="0"
                        hidden
                >
                    <header class="account-panel__header">
                        <div>
                            <h2>کیف پول و امتیاز</h2>
                            <p>مدیریت تراکنش‌های مالی، شارژ حساب و امتیازهای وفاداری.</p>
                        </div>
                        <button type="button" class="btn btn--gradient">افزایش موجودی</button>
                    </header>

                    <div class="wallet-grid">
                        <div class="wallet-card">
                            <div>
                                <span>موجودی قابل برداشت</span>
                                <strong>۱,۴۵۰,۰۰۰ تومان</strong>
                            </div>
                            <button type="button" class="btn btn--outline">درخواست تسویه</button>
                        </div>
                        <div class="wallet-card">
                            <div>
                                <span>امتیاز وفاداری</span>
                                <strong>۲,۸۴۰ امتیاز</strong>
                                <small>هر ۱۰۰ امتیاز = ۱۰,۰۰۰ تومان</small>
                            </div>
                            <button type="button" class="btn btn--outline">تبدیل به اعتبار</button>
                        </div>
                        <div class="wallet-card wallet-card--gradient">
                            <div>
                                <span>اشتراک طلایی</span>
                                <strong>اعتبار تا ۳۰ خرداد ۱۴۰۳</strong>
                                <small>۱۰٪ تخفیف ثابت + پشتیبانی اختصاصی</small>
                            </div>
                            <button type="button" class="btn btn--ghost">تمدید اشتراک</button>
                        </div>
                    </div>

                    <div class="account-panel__section">
                        <header>
                            <h3>گردش حساب</h3>
                            <p>تاریخچه آخرین تراکنش‌های کیف پول و امتیاز.</p>
                        </header>
                        <div class="data-card">
                            <table class="data-table data-table--compact">
                                <thead>
                                <tr>
                                    <th>تاریخ</th>
                                    <th>شرح تراکنش</th>
                                    <th>نوع</th>
                                    <th>مبلغ / امتیاز</th>
                                    <th>وضعیت</th>
                                </tr>
                                </thead>
                                <tbody>
                                <tr>
                                    <td>۲۳ اردیبهشت ۱۴۰۳</td>
                                    <td>بازگشت وجه سفارش #GMX-95410</td>
                                    <td>واریز</td>
                                    <td>۸۹۰,۰۰۰ تومان</td>
                                    <td><span class="status-pill status-pill--completed">تسویه شد</span></td>
                                </tr>
                                <tr>
                                    <td>۲۰ اردیبهشت ۱۴۰۳</td>
                                    <td>دریافت امتیاز خرید</td>
                                    <td>امتیاز</td>
                                    <td>+۲۶۰ امتیاز</td>
                                    <td><span class="status-pill status-pill--completed">ثبت شد</span></td>
                                </tr>
                                <tr>
                                    <td>۱۷ اردیبهشت ۱۴۰۳</td>
                                    <td>تسویه به کارت بانکی</td>
                                    <td>برداشت</td>
                                    <td>-۱,۲۰۰,۰۰۰ تومان</td>
                                    <td><span class="status-pill status-pill--processing">در انتظار</span></td>
                                </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <div
                        class="account-panel"
                        id="panel-support"
                        data-panel="support"
                        role="tabpanel"
                        aria-hidden="true"
                        tabindex="0"
                        hidden
                >
                    <header class="account-panel__header">
                        <div>
                            <h2>درخواست‌های پشتیبانی</h2>
                            <p>پیگیری سریع تیکت‌ها، چت و تماس‌های ثبت‌شده.</p>
                        </div>
                        <button type="button" class="btn btn--gradient">ایجاد درخواست جدید</button>
                    </header>
                    <div class="support-timeline">
                        <article>
                            <span class="support-timeline__status badge badge--success">پاسخ داده شد</span>
                            <div>
                                <h3>مشکل فعال‌سازی گیفت کارت اپل ۲۵ دلاری</h3>
                                <p>آخرین پاسخ از پشتیبان (سارا محمدی) در ساعت ۰۹:۴۵ ارسال شد. لطفاً نتیجه را اعلام کنید.</p>
                                <footer>
                                    <span>کد پیگیری: SUP-10324</span>
                                    <button type="button" class="link">مشاهده مکالمه</button>
                                </footer>
                            </div>
                        </article>
                        <article>
                            <span class="support-timeline__status badge badge--pending">در انتظار پاسخ</span>
                            <div>
                                <h3>درخواست فاکتور رسمی</h3>
                                <p>برای سفارش سازمانی نیاز به صدور فاکتور رسمی دارید. کارشناس مالی در حال بررسی است.</p>
                                <footer>
                                    <span>کد پیگیری: SUP-10310</span>
                                    <button type="button" class="link">ارسال پیام</button>
                                </footer>
                            </div>
                        </article>
                        <article>
                            <span class="support-timeline__status badge badge--info">بسته شد</span>
                            <div>
                                <h3>راهنمای تغییر ریجن اپل آیدی</h3>
                                <p>راهنمای کامل به ایمیل شما ارسال شد. در صورت نیاز تیکت جدید ثبت کنید.</p>
                                <footer>
                                    <span>کد پیگیری: SUP-10282</span>
                                    <button type="button" class="link">بازگشایی تیکت</button>
                                </footer>
                            </div>
                        </article>
                    </div>
                </div>

                <div
                        class="account-panel"
                        id="panel-affiliate"
                        data-panel="affiliate"
                        role="tabpanel"
                        aria-hidden="true"
                        tabindex="0"
                        hidden
                >
                    <header class="account-panel__header">
                        <div>
                            <h2>همکاری در فروش</h2>
                            <p>کسب درآمد از معرفی دوستان و مشتریان سازمانی.</p>
                        </div>
                        <button type="button" class="btn btn--outline">مشاهده قوانین</button>
                    </header>

                    <div class="affiliate-grid">
                        <div class="affiliate-card">
                            <span>کمیسیون تأیید شده</span>
                            <strong>۳,۴۵۰,۰۰۰ تومان</strong>
                            <small>۴ پرداخت موفق در این ماه</small>
                        </div>
                        <div class="affiliate-card">
                            <span>لینک اختصاصی شما</span>
                            <div class="affiliate-card__link">
                                <code>https://giftmax.ir/?ref=GMX45821</code>
                                <button type="button" class="btn btn--outline">کپی لینک</button>
                            </div>
                        </div>
                        <div class="affiliate-card">
                            <span>مشتریان فعال</span>
                            <strong>۱۸ نفر</strong>
                            <small>۳ مشتری جدید در هفته گذشته</small>
                        </div>
                    </div>

                    <div class="account-panel__section">
                        <header>
                            <h3>پیشنهادهای آماده ارسال</h3>
                            <p>قالب پیام و بنر برای اشتراک‌گذاری در شبکه‌های اجتماعی.</p>
                        </header>
                        <div class="promo-banners">
                            <article>
                                <h4>تخفیف ویژه اپل آیدی</h4>
                                <p>با کد دعوت شما، مشتریان جدید ۵٪ تخفیف دریافت می‌کنند.</p>
                                <button type="button" class="btn btn--gradient">دانلود بنر</button>
                            </article>
                            <article>
                                <h4>پیشنهاد گیفت کارت استیم</h4>
                                <p>به گیمرها معرفی کنید و ۷٪ کمیسیون از هر خرید دریافت کنید.</p>
                                <button type="button" class="btn btn--outline">کپی متن</button>
                            </article>
                        </div>
                    </div>
                </div>

                <div
                        class="account-panel"
                        id="panel-settings"
                        data-panel="settings"
                        role="tabpanel"
                        aria-hidden="true"
                        tabindex="0"
                        hidden
                >
                    <header class="account-panel__header">
                        <div>
                            <h2>تنظیمات حساب</h2>
                            <p>اطلاعات شخصی، آدرس‌ها و ترجیحات خود را بروز کنید.</p>
                        </div>
                        <button type="button" class="btn btn--gradient">ذخیره تغییرات</button>
                    </header>

                    <form class="account-form">
                        <div class="form-grid">
                            <label>
                                <span>نام و نام خانوادگی</span>
                                <input type="text" value="محمدرضا رستگار" />
                            </label>
                            <label>
                                <span>شماره موبایل</span>
                                <input type="tel" value="۰۹۱۲۳۴۵۶۷۸۹" />
                            </label>
                            <label>
                                <span>ایمیل</span>
                                <input type="email" value="m.rostegar@example.com" />
                            </label>
                            <label>
                                <span>شماره ملی</span>
                                <input type="text" value="۰۰۴۵۸۹۷۶۴۵" />
                            </label>
                        </div>
                        <div class="form-grid">
                            <label>
                                <span>استان</span>
                                <input type="text" value="تهران" />
                            </label>
                            <label>
                                <span>شهر</span>
                                <input type="text" value="تهران" />
                            </label>
                            <label class="form-grid__full">
                                <span>آدرس کامل</span>
                                <input type="text" value="خیابان شریعتی، بالاتر از سه راه طالقانی، پلاک ۱۱۲" />
                            </label>
                        </div>
                        <div class="form-grid form-grid--split">
                            <label>
                                <span>روش پرداخت پیش‌فرض</span>
                                <select>
                                    <option>درگاه بانکی (شتاب)</option>
                                    <option>کیف پول</option>
                                    <option>پرداخت سازمانی</option>
                                </select>
                            </label>
                            <label>
                                <span>زبان اطلاع‌رسانی</span>
                                <select>
                                    <option>فارسی</option>
                                    <option>انگلیسی</option>
                                </select>
                            </label>
                        </div>
                    </form>
                </div>

                <div
                        class="account-panel"
                        id="panel-security"
                        data-panel="security"
                        role="tabpanel"
                        aria-hidden="true"
                        tabindex="0"
                        hidden
                >
                    <header class="account-panel__header">
                        <div>
                            <h2>امنیت و ورود</h2>
                            <p>کنترل ورودها، دستگاه‌های فعال و فعال‌سازی ورود دو مرحله‌ای.</p>
                        </div>
                        <button type="button" class="btn btn--outline">خروج از همه دستگاه‌ها</button>
                    </header>

                    <div class="security-grid">
                        <div class="security-card">
                            <div>
                                <h3>ورود دو مرحله‌ای</h3>
                                <p>با فعال‌سازی ۲FA امنیت حساب خود را افزایش دهید.</p>
                            </div>
                            <label class="switch">
                                <input type="checkbox" checked />
                                <span class="switch__slider"></span>
                            </label>
                        </div>
                        <div class="security-card">
                            <div>
                                <h3>دستگاه‌های فعال</h3>
                                <p>۲ دستگاه فعال: iPhone 15 Pro، MacBook Pro (Safari).</p>
                            </div>
                            <button type="button" class="btn btn--outline">مدیریت دستگاه‌ها</button>
                        </div>
                    </div>

                    <div class="account-panel__section">
                        <header>
                            <h3>تاریخچه ورود</h3>
                            <p>بررسی سریع آخرین فعالیت‌های حساب کاربری.</p>
                        </header>
                        <div class="data-card">
                            <table class="data-table data-table--compact">
                                <thead>
                                <tr>
                                    <th>تاریخ و ساعت</th>
                                    <th>دستگاه</th>
                                    <th>آی‌پی</th>
                                    <th>وضعیت</th>
                                    <th>اقدام</th>
                                </tr>
                                </thead>
                                <tbody>
                                <tr>
                                    <td>۲۴ اردیبهشت ۱۴۰۳ - ۰۹:۴۲</td>
                                    <td>iPhone 15 Pro (iOS)</td>
                                    <td>185.25.74.102</td>
                                    <td><span class="status-pill status-pill--completed">موفق</span></td>
                                    <td><button type="button" class="link">خروج از دستگاه</button></td>
                                </tr>
                                <tr>
                                    <td>۲۳ اردیبهشت ۱۴۰۳ - ۲۱:۱۷</td>
                                    <td>MacBook Pro (Safari)</td>
                                    <td>178.45.12.66</td>
                                    <td><span class="status-pill status-pill--completed">موفق</span></td>
                                    <td><button type="button" class="link">خروج از دستگاه</button></td>
                                </tr>
                                <tr>
                                    <td>۲۲ اردیبهشت ۱۴۰۳ - ۰۸:۰۵</td>
                                    <td>Windows 11 (Chrome)</td>
                                    <td>91.98.152.12</td>
                                    <td><span class="status-pill status-pill--refunded">نا موفق</span></td>
                                    <td><button type="button" class="link">گزارش امنیتی</button></td>
                                </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <div
                        class="account-panel"
                        id="panel-notifications"
                        data-panel="notifications"
                        role="tabpanel"
                        aria-hidden="true"
                        tabindex="0"
                        hidden
                >
                    <header class="account-panel__header">
                        <div>
                            <h2>اطلاع‌رسانی‌ها</h2>
                            <p>نوع پیام‌های دریافتی را برای ایمیل، پیامک و اعلان لحظه‌ای مدیریت کنید.</p>
                        </div>
                        <button type="button" class="btn btn--gradient">ذخیره تنظیمات</button>
                    </header>

                    <div class="notification-groups">
                        <section>
                            <header>
                                <h3>سفارش‌ها و مالی</h3>
                                <p>وضعیت سفارش‌ها، فاکتورها و تراکنش‌های شما.</p>
                            </header>
                            <label class="notification-row">
                                <div>
                                    <strong>تأیید سفارش جدید</strong>
                                    <small>وقتی سفارشی ثبت یا پرداخت می‌شود.</small>
                                </div>
                                <label class="switch">
                                    <input type="checkbox" checked />
                                    <span class="switch__slider"></span>
                                </label>
                            </label>
                            <label class="notification-row">
                                <div>
                                    <strong>اخطار تأخیر در تحویل</strong>
                                    <small>در صورت تأخیر احتمالی در ارسال کد.</small>
                                </div>
                                <label class="switch">
                                    <input type="checkbox" checked />
                                    <span class="switch__slider"></span>
                                </label>
                            </label>
                            <label class="notification-row">
                                <div>
                                    <strong>رسید پرداخت و فاکتور</strong>
                                    <small>ارسال خودکار رسید به ایمیل شما.</small>
                                </div>
                                <label class="switch">
                                    <input type="checkbox" />
                                    <span class="switch__slider"></span>
                                </label>
                            </label>
                        </section>
                        <section>
                            <header>
                                <h3>بازاریابی و پیشنهادها</h3>
                                <p>خبرنامه، تخفیف‌های ویژه و کمپین‌های وفاداری.</p>
                            </header>
                            <label class="notification-row">
                                <div>
                                    <strong>پیشنهادهای اختصاصی</strong>
                                    <small>تخفیف‌های شخصی‌سازی‌شده بر اساس خریدهای اخیر.</small>
                                </div>
                                <label class="switch">
                                    <input type="checkbox" checked />
                                    <span class="switch__slider"></span>
                                </label>
                            </label>
                            <label class="notification-row">
                                <div>
                                    <strong>برنامه همکاری در فروش</strong>
                                    <small>اطلاع از تسویه حساب کمیسیون‌ها.</small>
                                </div>
                                <label class="switch">
                                    <input type="checkbox" checked />
                                    <span class="switch__slider"></span>
                                </label>
                            </label>
                            <label class="notification-row">
                                <div>
                                    <strong>اخبار و به‌روزرسانی‌ها</strong>
                                    <small>اطلاع از محصولات و سرویس‌های جدید.</small>
                                </div>
                                <label class="switch">
                                    <input type="checkbox" />
                                    <span class="switch__slider"></span>
                                </label>
                            </label>
                        </section>
                    </div>
                </div>
            </div>
        </div>
    </section>
</main>

<footer class="site-footer">
    <div class="container site-footer__grid">
        <div class="site-footer__brand">
            <span class="brand__icon">🎁</span>
            <div>
                <strong>گیفت مکس دیجیتال</strong>
                <p>مرجع تخصصی خرید گیفت کارت‌های اپل، پلی‌استیشن، ایکس‌باکس و سرویس‌های بین‌المللی با تحویل فوری.</p>
            </div>
            <form class="newsletter">
                <label for="newsletterEmail">برای اطلاع از تخفیف‌ها ایمیل خود را وارد کنید</label>
                <div class="newsletter__field">
                    <input id="newsletterEmail" type="email" placeholder="ایمیل شما" />
                    <button type="submit" class="btn btn--gradient">ثبت</button>
                </div>
            </form>
        </div>
        <div class="site-footer__links">
            <div>
                <h3>دسته‌بندی سریع</h3>
                <ul>
                    <li><a href="index.php#overview">گیفت کارت اپل</a></li>
                    <li><a href="index.php#bundles">گیفت کارت پلی‌استیشن</a></li>
                    <li><a href="index.php#bundles">گیفت کارت آمازون</a></li>
                    <li><a href="index.php#bundles">گیفت کارت استیم</a></li>
                </ul>
            </div>
            <div>
                <h3>راهنمای سریع</h3>
                <ul>
                    <li><a href="index.php#guide">آموزش ریدیم</a></li>
                    <li><a href="index.php#faq">خطاهای متداول</a></li>
                    <li><a href="index.php#support">پشتیبانی سازمانی</a></li>
                    <li><a href="#">قوانین و مقررات</a></li>
                </ul>
            </div>
            <div>
                <h3>ارتباط با ما</h3>
                <ul>
                    <li><a href="tel:02175390">۰۲۱-۷۵۳۹۰</a></li>
                    <li><a href="mailto:support@giftmaxdigital.ir">support@giftmaxdigital.ir</a></li>
                    <li>تهران، خیابان شریعتی، دفتر مرکزی گیفت مکس</li>
                </ul>
            </div>
        </div>
    </div>
    <div class="site-footer__bottom">
        <div class="container">
            <span>© ۱۴۰۳ گیفت مکس دیجیتال - تمامی حقوق محفوظ است.</span>
            <div class="footer-socials">
                <a href="#" aria-label="اینستاگرام">📸</a>
                <a href="#" aria-label="تلگرام">✈️</a>
                <a href="#" aria-label="توئیتر">🐦</a>
            </div>
        </div>
    </div>
</footer>

<script src="assets/js/cart.js"></script>
</body>
</html>