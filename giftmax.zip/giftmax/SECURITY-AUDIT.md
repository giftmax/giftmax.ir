# Giftmax security / architecture audit

## Changes applied

- Removed `.idea/` from the distributable package. It contained server/SSH deployment metadata.
- Replaced the custom `str_replace()` SQL parameter interpolation with real `mysqli` prepared statements.
- DB errors are logged server-side instead of being returned through `die()`.
- Added transaction helpers to the DB layer.
- Added `BaseModel` as the target abstraction for database access.
- Fixed `VerifyModel` to use the actual `documents` table used by the current API.
- Removed the debug `echo/var_dump/exit` from `VerifyUser::documentInfoApiFunction()`.
- Added ownership checks to the order/card flows.
- Restricted `card-otp` to the authenticated owner.
- Added basic validation for document type, document payload and landline phone.
- Replaced `rand()` in `generateHash()` with `random_bytes()`.
- Removed hard-coded Jibit/Zohal/IPPanel/Avanak credentials from the source.
- Removed full Jibit API response logging.
- Added cURL connect/request timeouts.
- Removed duplicate `new Payment()` initialization.

## High / critical issues that still need a migration

### 1. Encryption keys were hard-coded in the source
The old `encrypt_data()` scheme used a static key and static IV. The patch no longer stores those values in source, but existing encrypted data requires the old key material.

**Before deploying:** put the existing production values into `wp-config.php` (or environment variables), then plan a migration to a random per-installation key and authenticated encryption (AES-256-GCM or libsodium).

Do not rotate the key blindly: existing encrypted national IDs, cards, phone numbers and other records will become undecryptable.

### 2. Sensitive secrets must be rotated
The uploaded source contained live-looking third-party credentials. Assume they are compromised because source code was copied/shared.

Rotate:
- Jibit API credentials
- Zohal token
- IPPanel token
- Avanak token
- any payment gateway credentials that have ever been committed to this project

### 3. Payment / wallet logic needs transactional hardening
Wallet balance and points are financial state. Reads followed by writes can race under concurrent requests.

The points-to-wallet conversion in `Profile.php` should be moved into a model/service transaction using:
- `BEGIN`
- `SELECT ... FOR UPDATE`
- atomic balance/points update
- transaction record insert
- `COMMIT`

Rollback on every exception.

### 4. License reservation must be atomic
Licence reservation/release logic should use an atomic state transition such as:

`UPDATE wp_product_licences SET licence_status='reserved', ... WHERE licence_id=? AND licence_status='available'`

Then verify `affected_rows === 1`.

Do not rely on a preceding SELECT to prove availability.

## REST/API issues to review

### Missing rate limits
OTP, login, password reset, card verification and external-service endpoints need per-IP + per-account throttling.

At minimum:
- OTP send: strict short-window limit
- OTP verify: strict attempt limit
- login/password reset: brute-force protection
- card verification: strict limit
- admin SMS send: admin-only plus operational rate limits

### Input validation
Several controllers still read `$_POST` directly. Prefer `$request->get_param()` / `$request->get_json_params()` and validate every field against an explicit schema.

### REST permissions
Do not use `__return_true` for an endpoint unless it is intentionally public. Every endpoint that touches user/account/payment state should have an explicit permission callback.

### CSRF / REST authentication
For cookie-authenticated WordPress REST requests, ensure the frontend sends the WordPress REST nonce. Do not create a custom authentication mechanism that bypasses WordPress's cookie/nonce checks.

## Database design issues

- Add foreign keys where practical for `user_id`, `product_id`, `order_id`, etc.
- Make `user_id` unique in `wallet` and `user_points` if there must be one row per user.
- Use `DECIMAL` consistently for money; avoid `DOUBLE` for payment amounts.
- `reserved_at` is currently an `INT` in `product_licences`; use `DATETIME`/`TIMESTAMP`.
- Add unique constraints to settings where `meta_key` is logically unique.
- Avoid nullable IDs where the relationship is mandatory.
- Add indexes based on actual query plans, especially for campaign/recipient, wallet and licence queries.

## Architecture target

REST controllers (`app/webservice/method/*`)
→ validate/authenticate request
→ call domain model/service
→ model performs all SQL
→ controller returns `WP_REST_Response`

New code should not instantiate `Db` or write SQL inside `webservice/method/*`.

The current patch centralizes the DB connection and gives you `BaseModel`, but the existing large controllers still contain legacy SQL. Those controllers should be migrated domain-by-domain rather than doing a blind automated rewrite.

## Deployment checklist

1. Rotate exposed API/payment credentials.
2. Configure secrets in `wp-config.php` or environment variables.
3. Back up the database.
4. Test login/OTP/payment/wallet/licence flows on staging.
5. Run PHP syntax checks.
6. Enable HTTPS only.
7. Disable PHP error display in production:
   `display_errors=Off`
   `log_errors=On`
8. Restrict filesystem permissions and prevent directory listing.
9. Never deploy `.idea/`, backups, `.env`, SQL dumps or credentials.
