<?php
namespace Giftmax;


use Giftmax\model\SiteModel;
use Giftmax\model\UserModel;
use Giftmax\modules\Db;

get_header();
?>
<main>
    <script type="text/javascript">
        var ajaxurl = "<?php echo admin_url('admin-ajax.php'); ?>";
    </script>
    <?php
    $giftmax_is_user_logged_in = is_user_logged_in();
    $giftmax_wishlist_ids = $giftmax_is_user_logged_in ? giftmax_get_user_wishlist_product_ids() : [];
    $db = \Giftmax\modules\Db::getLnstance();
    global $wpdb;
    $records = $db->first("SELECT meta_value FROM `{$wpdb->prefix}setting` WHERE `meta_key`=:key",array('key'=>'slider'));
    $args = [
            'post_type'      => 'product',
            'posts_per_page' => -1,
            'meta_query'     => [
                    'relation' => 'AND',

                    [
                            'key'     => '_sale_price',
                            'value'   => 0,
                            'compare' => '>',
                            'type'    => 'NUMERIC',
                    ],

                    [
                            'key'     => '_sale_price_dates_from',
                            'compare' => 'NOT EXISTS',
                    ],

                    [
                            'key'     => '_sale_price_dates_to',
                            'compare' => 'NOT EXISTS',
                    ],
            ],
    ];

    $query = new \WP_Query($args);
    if(!empty($records) || $query->have_posts()){
        $usdTime = get_option('giftmax_usd_rate_updated');
        $nextUpdate = date('Y-m-d H:i:s', strtotime($usdTime . ' +15 minutes'));
        $usd = get_option('giftmax_usd_rate');
        ?>
        <section class="container-xl-w mx-auto relative slider_h" style="height: 445px;">
            <div class="act-main-banner-1st">
                <?php
                if (isMobile()){
                    ?>
                    <div class="bar-box_v10">
                        <p class="text-white">نرخ فعلی :<?=$usd?> تومان </p>
                        <p class="text-white">بروزرسانی بعدی قیمت:<span class="style_ProductPromotionTimeline__timer__home"><?=$nextUpdate?></span></p>
                    </div>
                    <?php
                } else{
                    ?>
                    <div class="V10-vdjks45">
                        <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 18 18" fill="currentcolor"><path d="M9 12.5625C8.7 12.5625 8.4 12.54 8.115 12.4875C6.525 12.255 5.0775 11.34 4.1625 9.9825C3.525 9.0225 3.1875 7.905 3.1875 6.75C3.1875 3.5475 5.7975 0.9375 9 0.9375C12.2025 0.9375 14.8125 3.5475 14.8125 6.75C14.8125 7.905 14.475 9.0225 13.8375 9.9825C12.915 11.3475 11.4675 12.255 9.8625 12.495C9.6 12.54 9.3 12.5625 9 12.5625ZM9 2.0625C6.4125 2.0625 4.3125 4.1625 4.3125 6.75C4.3125 7.6875 4.5825 8.5875 5.0925 9.3525C5.835 10.4475 6.9975 11.1825 8.2875 11.37C8.7675 11.4525 9.24 11.4525 9.6825 11.37C10.995 11.1825 12.1575 10.44 12.9 9.34499C13.41 8.57999 13.68 7.67999 13.68 6.74249C13.6875 4.16249 11.5875 2.0625 9 2.0625Z"></path><path d="M4.85249 16.9425C4.74749 16.9425 4.64999 16.9275 4.54499 16.905C4.05749 16.7925 3.68249 16.4175 3.56999 15.93L3.30749 14.8275C3.29249 14.76 3.23999 14.7075 3.16499 14.685L1.92749 14.3925C1.46249 14.28 1.09499 13.935 0.967485 13.4775C0.839985 13.02 0.967485 12.525 1.30499 12.1875L4.22999 9.26248C4.34999 9.14248 4.51499 9.08248 4.67999 9.09748C4.84499 9.11248 4.99499 9.20247 5.09249 9.34497C5.83499 10.44 6.99749 11.1825 8.29499 11.37C8.77499 11.4525 9.24749 11.4525 9.68999 11.37C11.0025 11.1825 12.165 10.44 12.9075 9.34497C12.9975 9.20247 13.155 9.11248 13.32 9.09748C13.485 9.08248 13.65 9.14248 13.77 9.26248L16.695 12.1875C17.0325 12.525 17.16 13.02 17.0325 13.4775C16.905 13.935 16.53 14.2875 16.0725 14.3925L14.835 14.685C14.7675 14.7 14.715 14.7525 14.6925 14.8275L14.43 15.93C14.3175 16.4175 13.9425 16.7925 13.455 16.905C12.9675 17.025 12.465 16.8525 12.15 16.47L8.99999 12.8475L5.84999 16.4775C5.59499 16.7775 5.23499 16.9425 4.85249 16.9425ZM4.56749 10.5225L2.09999 12.99C2.03249 13.0575 2.03999 13.1325 2.05499 13.1775C2.06249 13.215 2.09999 13.29 2.18999 13.305L3.42749 13.5975C3.91499 13.71 4.28999 14.085 4.40249 14.5725L4.66499 15.675C4.68749 15.7725 4.76249 15.8025 4.80749 15.8175C4.85249 15.825 4.92749 15.8325 4.99499 15.7575L7.86749 12.45C6.59249 12.2025 5.42249 11.52 4.56749 10.5225ZM10.1325 12.4425L13.005 15.7425C13.0725 15.825 13.155 15.825 13.2 15.81C13.245 15.8025 13.3125 15.765 13.3425 15.6675L13.605 14.565C13.7175 14.0775 14.0925 13.7025 14.58 13.59L15.8175 13.2975C15.9075 13.275 15.945 13.2075 15.9525 13.17C15.9675 13.1325 15.975 13.05 15.9075 12.9825L13.44 10.515C12.5775 11.5125 11.415 12.195 10.1325 12.4425Z"></path><path d="M10.4174 9.66745C10.2224 9.66745 9.98986 9.61494 9.71236 9.44994L8.99986 9.02244L8.28736 9.44244C7.63486 9.83244 7.20736 9.60744 7.04986 9.49494C6.89236 9.38244 6.55486 9.04494 6.72736 8.30244L6.90736 7.52995L6.30736 6.97493C5.97736 6.64493 5.85736 6.24744 5.96986 5.88744C6.08236 5.52744 6.41236 5.27243 6.87736 5.19743L7.67986 5.06244L8.06236 4.22244C8.27986 3.79494 8.61736 3.55493 8.99986 3.55493C9.38236 3.55493 9.72736 3.80245 9.93736 4.22995L10.3799 5.11494L11.1224 5.20494C11.5799 5.27994 11.9099 5.53493 12.0299 5.89493C12.1424 6.25493 12.0224 6.65244 11.6924 6.98244L11.0699 7.60495L11.2649 8.30244C11.4374 9.04494 11.0999 9.38244 10.9424 9.49494C10.8599 9.56244 10.6799 9.66745 10.4174 9.66745ZM7.20736 6.29245L7.72486 6.80993C7.96486 7.04993 8.08486 7.45494 8.00986 7.78494L7.86736 8.38493L8.46736 8.03243C8.78986 7.84493 9.22486 7.84493 9.53986 8.03243L10.1399 8.38493L10.0049 7.78494C9.92986 7.44744 10.0424 7.04993 10.2824 6.80993L10.7999 6.29245L10.1474 6.17993C9.83236 6.12743 9.51736 5.89495 9.37486 5.60995L8.99986 4.87494L8.62486 5.62494C8.48986 5.90244 8.17486 6.14245 7.85986 6.19495L7.20736 6.29245Z"></path></svg>
                        <div class="flex justify-between align-items-center">
                            <?php

                            ?>
                            <p class="">قیمت محصولات بر اساس نرخ لحظه‌ای دلار (<?=$usd?> تومان) بروزرسانی می‌شود. بروزرسانی بعدی تا <span class="style_ProductPromotionTimeline__timer__home"><?=$nextUpdate?></span> دیگر انجام خواهد شد.</p>
                            <?php
                            ?>
                        </div>
                    </div>
                    <?php
                }
                ?>
                <img fetchpriority="high" src="<?=get_template_directory_uri()?>/assets/img/Frame-1261156338.png" class="act-main-banner-img">
                <div class="act-main-banner-content-box">
                    <div class="<?=$query->have_posts() ? 'act-main-banner-content-box-right' : 'w-full'?>">
                        <?php
                        if(!empty($records)){
                            $records = json_decode($records['meta_value'],true);
                            ?>
                            <div class="banner-section main-banner pt-0 position-relative">
                                <div class="header-section absolute-bar position-absolute d-flex align-items-center justify-content-between w-fit">
                                    <div class="swiper-pagination swiper-pagination-banner position-relative w-fit d-flex me-4"></div>
                                    <div class="swiper-navigation d-flex align-items-center rounded-2 position-relative">
                                        <div class="btn p-0 swiper-button-prev-banner d-flex align-items-center justify-content-center border-0">
                                            <i class="icon-right-arrow text-light"></i>
                                        </div>
                                        <div class="btn p-0 swiper-button-next-banner d-flex align-items-center justify-content-center border-0">
                                            <i class="icon-left-arrow text-light"></i>
                                        </div>
                                    </div>
                                </div>
                                <div class="swiper-container swiper-banner overflow-hidden">
                                    <div class="swiper-wrapper">
                                        <?php
                                        foreach ($records as $record){?>
                                            <div class="swiper-slide pb-4" style="padding-right: 15px; padding-left: 15px">
                                                <div class="item position-relative rounded-4" style="background: linear-gradient(180deg, <?=$record['color']['one']?> 0%, <?=$record['color']['two']?> 100%); box-shadow: 0 10px 20px 0 #1621af45">
                                                    <div class="row position-relative h-100 flex-xl-row flex-column align-items-lg-end justify-content-lg-center align-items-center justify-content-center">
                                                        <article class="col-12 align-self-center">
                                                            <div class="label d-block w-fit fw-medium text-white py-2 px-3 border-radius-14 mx-auto mx-xl-0"><?=$record['description']?></div>
                                                            <div class="title position-relative d-block fw-wblack text-white text-xl-start text-center mb-1"><?=$record['title']?></div>
                                                            <a href="<?=$record['button']['link']?>" class="more fw-semibold yellow-theme w-fit py-xl-3 py-2 px-3 d-flex align-items-center rounded-2 mx-xl-0 mx-auto" style="background-color: #ffffff; color: #000000">
                                                                <?=$record['button']['title']?>
                                                            </a>
                                                        </article>
                                                        <img width="622" height="518" src="<?=$record['img']?>" class="d-block ms-auto" sizes="(max-width: 622px) 100vw, 622px">
                                                    </div>
                                                </div>
                                            </div>
                                            <?php
                                        }
                                        ?>
                                    </div>
                                    <span class="swiper-notification" aria-live="assertive" aria-atomic="true"></span>
                                </div>
                            </div>
                            <?php
                        }
                        ?>
                    </div>
                    <?php
                    if ($query->have_posts()){
                        ?>
                        <div class="act-main-banner-content-box-left">
                            <div class="relative">
                                <div class="act-main-banner-content-box-carousel-head-text">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 18 18" fill="currentcolor">
                                        <path d="M13.2451 17.0025C12.8476 17.0025 12.3376 16.875 11.7001 16.5L9.45759 15.1725C9.22509 15.0375 8.77509 15.0375 8.55009 15.1725L6.30009 16.5C4.97259 17.2875 4.19259 16.9725 3.84009 16.7175C3.49509 16.4625 2.95509 15.81 3.30759 14.31L3.84009 12.0075C3.90009 11.7675 3.78009 11.355 3.60009 11.175L1.74009 9.31499C0.810088 8.38499 0.885088 7.58999 1.01259 7.19999C1.14009 6.80999 1.54509 6.11999 2.83509 5.90249L5.22759 5.50499C5.45259 5.46749 5.77509 5.22749 5.87259 5.02499L7.20009 2.37749C7.80009 1.16999 8.58759 0.98999 9.00009 0.98999C9.41259 0.98999 10.2001 1.16999 10.8001 2.37749L12.1201 5.01749C12.2251 5.21999 12.5476 5.45999 12.7726 5.49749L15.1651 5.89499C16.4626 6.11249 16.8676 6.80249 16.9876 7.19249C17.1076 7.58249 17.1826 8.37749 16.2601 9.30749L14.4001 11.175C14.2201 11.355 14.1076 11.76 14.1601 12.0075L14.6926 14.31C15.0376 15.81 14.5051 16.4625 14.1601 16.7175C13.9726 16.8525 13.6726 17.0025 13.2451 17.0025ZM9.00009 13.9425C9.36759 13.9425 9.73509 14.0325 10.0276 14.205L12.2701 15.5325C12.9226 15.9225 13.3351 15.9225 13.4926 15.81C13.6501 15.6975 13.7626 15.3 13.5976 14.565L13.0651 12.2625C12.9226 11.64 13.1551 10.8375 13.6051 10.38L15.4651 8.51999C15.8326 8.15249 15.9976 7.79249 15.9226 7.54499C15.8401 7.29749 15.4951 7.09499 14.9851 7.01249L12.5926 6.61499C12.0151 6.51749 11.3851 6.05249 11.1226 5.52749L9.80259 2.88749C9.56259 2.40749 9.26259 2.12249 9.00009 2.12249C8.73759 2.12249 8.43759 2.40749 8.20509 2.88749L6.87759 5.52749C6.61509 6.05249 5.98509 6.51749 5.40759 6.61499L3.02259 7.01249C2.51259 7.09499 2.16759 7.29749 2.08509 7.54499C2.00259 7.79249 2.17509 8.15999 2.54259 8.51999L4.40259 10.38C4.85259 10.83 5.08509 11.64 4.94259 12.2625L4.41009 14.565C4.23759 15.3075 4.35759 15.6975 4.51509 15.81C4.67259 15.9225 5.07759 15.915 5.73759 15.5325L7.98009 14.205C8.26509 14.0325 8.63259 13.9425 9.00009 13.9425Z"></path>
                                    </svg>
                                    محصولات داری تخفیف
                                </div>
                                <div class="act-main-banner-content-box-carousel">
                                    <div class="act-main-banner-content-box-carousel-head">
                                        <div class="act-main-banner-content-box-carousel-head-buts">
                                            <div class="act-carousel-but act-main-banner-content-box-carousel-head-but-prev" tabindex="0" role="button" aria-label="Previous slide" aria-controls="swiper-wrapper-42d110487fefb6851" aria-disabled="false">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="currentcolor"><path d="M12.0253 15.6833C11.8669 15.6833 11.7086 15.625 11.5836 15.5C11.3419 15.2583 11.3419 14.8583 11.5836 14.6166L16.2003 9.99998L11.5836 5.38331C11.3419 5.14164 11.3419 4.74164 11.5836 4.49998C11.8253 4.25831 12.2253 4.25831 12.4669 4.49998L17.5253 9.55831C17.7669 9.79998 17.7669 10.2 17.5253 10.4416L12.4669 15.5C12.3419 15.625 12.1836 15.6833 12.0253 15.6833Z"></path><path d="M16.942 10.625H2.91699C2.57533 10.625 2.29199 10.3417 2.29199 10C2.29199 9.65833 2.57533 9.375 2.91699 9.375H16.942C17.2837 9.375 17.567 9.65833 17.567 10C17.567 10.3417 17.2837 10.625 16.942 10.625Z"></path></svg>
                                            </div>
                                            <div class="act-carousel-but act-main-banner-content-box-carousel-head-but-next swiper-button-disabled" tabindex="-1" role="button" aria-label="Next slide" aria-controls="swiper-wrapper-42d110487fefb6851" aria-disabled="true">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="currentcolor"><path d="M7.97474 4.31669C8.13307 4.31669 8.29141 4.37502 8.41641 4.50002C8.65807 4.74169 8.65807 5.14169 8.41641 5.38336L3.79974 10L8.41641 14.6167C8.65807 14.8584 8.65807 15.2584 8.41641 15.5C8.17474 15.7417 7.77474 15.7417 7.53307 15.5L2.47474 10.4417C2.23307 10.2 2.23307 9.80002 2.47474 9.55836L7.53307 4.50002C7.65807 4.37502 7.81641 4.31669 7.97474 4.31669Z"></path><path d="M3.05801 9.375L17.083 9.375C17.4247 9.375 17.708 9.65833 17.708 10C17.708 10.3417 17.4247 10.625 17.083 10.625L3.05801 10.625C2.71634 10.625 2.43301 10.3417 2.43301 10C2.43301 9.65833 2.71634 9.375 3.05801 9.375Z"></path></svg>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="act-main-banner-content-box-carousel-main swiper swiper-initialized swiper-horizontal swiper-rtl swiper-backface-hidden">
                                        <div class="swiper-wrapper">
                                            <?php while ($query->have_posts()): $query->the_post();

                                                $product = wc_get_product(get_the_ID());
                                                $regular = $product->get_regular_price();
                                                $sale    = $product->get_sale_price();

                                                if (!$sale || $sale >= $regular) continue;

                                                $discount = round((($regular - $sale) / $regular) * 100);
                                                $img = get_the_post_thumbnail_url(get_the_ID(), 'product_discount');
                                                $title = get_the_title();
                                                $settings = get_post_meta($product->get_id(), 'giftmax_box_setting', true);
                                                $delivery = get_post_meta($product->get_id(), 'delivery', true);

                                                ?>
                                                <div class="swiper-slide">
                                                    <div class="act-main-banner-content-box-carousel-card">
                                                        <div <?=isset($delivery['two']) && $delivery['two'] == 'on' || product_available($product->get_id()) ?'class="relative"':'class="NdhJD5 relative"'?>>
                                                            <div class="act-product-card-top" data-product-id="<?=$product->get_id()?>">
                                                                <a class="act-product-img-box" href="<?=get_permalink()?>">
                                                                    <div class="relative">
                                                                        <img src="<?=$img?>" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="<?=get_the_title()?>">
                                                                        <?php
                                                                        if (!empty($settings[0]['logo_region'])){
                                                                            ?>
                                                                            <div class="p-logo__region">
                                                                                <img src="<?=empty($settings[0]['logo_region']) ?: get_template_directory_uri() . '/assets/flag/' . $settings[0]['logo_region'] . '.svg'?>">
                                                                            </div>
                                                                            <?php
                                                                        }
                                                                        ?>
                                                                    </div>
                                                                </a>
                                                                <div class="act-product-text-box">
                                                                    <a href="<?=get_permalink()?>">
                                                                        <h4 class="act-product-title"> <?=$title?> </h4>
                                                                        <?php
                                                                        if(!empty($settings[0]['sub_head'])) echo "<p class='act-product-title-en'>" . $settings[0]['sub_head'] . "</p>";
                                                                        ?>
                                                                    </a>
                                                                    <p class="act-product-text"><?=empty($settings[0]['description_short']) ? '' : $settings[0]['description_short']?></p>
                                                                </div>
                                                            </div>
                                                            <div class="act-hor-bor act-hor-bor-first"></div>
                                                            <div class="act-product-attr-box">
                                                                <?php
                                                                if (!empty($settings[0]['region'])){
                                                                    ?>
                                                                    <div class="act-product-attr-card"><?=$settings[0]['region']?></div>
                                                                    <?php
                                                                }?>
                                                                <div class="act-product-attr-card <?=isset($delivery['two']) && $delivery['two'] == 'on' ? 'pre-sale' : 'same-day'?>"><?=isset($delivery['two']) && $delivery['two'] == 'on' ? 'پیش فروش' : 'تحویل آنی'?></div>
                                                                <div class="act-product-attr-card__purchaseScore wiki wiki__holder js-dk-wiki-trigger" data-tooltip="با خرید این گیفت کارت <?=empty($settings[0]['purchaseScore']) ?0: $settings[0]['purchaseScore']?> امتیاز دریافت میکنید"><i class="icon-star"></i><?=empty($settings[0]['purchaseScore']) ?0: $settings[0]['purchaseScore']?></div>
                                                                <?php
                                                                if (!empty($settings[0]['label']) && $settings[0]['label'] != ''){?>
                                                                    <div class="label-fjd84">
                                                                        <img src="<?=empty($settings[0]['label']) ?'': $settings[0]['label']?>" class="logo_label">
                                                                        <p class="label_title"><?=empty($settings[0]['label_title']) ? '' : $settings[0]['label_title']?></p>
                                                                    </div>
                                                                    <?php
                                                                }
                                                                ?>
                                                            </div>
                                                        </div>

                                                        <div class="act-hor-bor act-hor-bor-last"></div>
                                                        <div class="act-product-card-footer">
                                                            <div class="flex justify-between items-center">
                                                                <?php
                                                                if (isset($delivery['two']) && $delivery['two'] == 'on' || product_available($product->get_id())){
                                                                    if (SiteModel::setting("buy") === true){
                                                                        ?>
                                                                        <button type="button" class="act-special-carousel-card-buy-box-but Button-aca48 DJJrjd4 pointer" data-product-id="<?=$product->get_id()?>">
                                                                            <svg xmlns="http://www.w3.org/2000/svg" width="26" height="26" viewBox="0 0 26 26" fill="currentcolor">
                                                                                <path d="M17.875 9.34916C17.4308 9.34916 17.0625 8.98083 17.0625 8.53666V7.04166C17.0625 5.90416 16.575 4.79916 15.73 4.03C14.8742 3.25 13.7692 2.8925 12.5992 3.00083C10.6492 3.185 8.9375 5.17833 8.9375 7.25833V8.30916C8.9375 8.75333 8.56917 9.12166 8.125 9.12166C7.68083 9.12166 7.3125 8.75333 7.3125 8.30916V7.2475C7.3125 4.33333 9.66333 1.64666 12.4475 1.37583C14.0725 1.22417 15.6325 1.73333 16.8242 2.8275C18.005 3.9 18.6875 5.43833 18.6875 7.04166V8.53666C18.6875 8.98083 18.3192 9.34916 17.875 9.34916Z"></path>
                                                                                <path d="M16.2498 24.6457H9.7498C4.7448 24.6457 3.81314 22.3165 3.5748 20.0523L2.7623 13.5632C2.64314 12.3932 2.5998 10.714 3.7373 9.45734C4.7123 8.374 6.32647 7.854 8.66647 7.854H17.3331C19.684 7.854 21.2981 8.38484 22.2623 9.45734C23.389 10.714 23.3565 12.3932 23.2373 13.5415L22.4248 20.0523C22.1865 22.3165 21.2548 24.6457 16.2498 24.6457ZM8.66647 9.479C6.83564 9.479 5.57897 9.8365 4.9398 10.5515C4.40897 11.1365 4.23564 12.0357 4.37647 13.379L5.18897 19.8682C5.37314 21.6015 5.8498 23.0315 9.7498 23.0315H16.2498C20.1498 23.0315 20.6265 21.6123 20.8106 19.8898L21.6231 13.379C21.764 12.0573 21.5906 11.1582 21.0598 10.5623C20.4206 9.8365 19.164 9.479 17.3331 9.479H8.66647Z"></path>
                                                                                <path d="M16.7045 14.2458C16.0979 14.2458 15.6104 13.7583 15.6104 13.1624C15.6104 12.5666 16.0979 12.0791 16.6937 12.0791C17.2895 12.0791 17.777 12.5666 17.777 13.1624C17.777 13.7583 17.3004 14.2458 16.7045 14.2458Z"></path>
                                                                                <path d="M9.12151 14.2458C8.51484 14.2458 8.02734 13.7583 8.02734 13.1624C8.02734 12.5666 8.51484 12.0791 9.11068 12.0791C9.70651 12.0791 10.194 12.5666 10.194 13.1624C10.194 13.7583 9.71734 14.2458 9.12151 14.2458Z"></path>
                                                                            </svg>
                                                                            افزودن به سبد خرید
                                                                        </button>
                                                                        <?php
                                                                    }
                                                                }else{
                                                                    echo '<div class="inaJSDge8">ناموجود</div>';
                                                                }?>
                                                                <a href="<?=the_permalink()?>" class="act-special-carousel-card-buy-box-option" style="margin-right: 5px">جزئیات</a>
                                                            </div>
                                                            <div class="act-product-price-box">
                                                                <div class="act-product-price-box-top">
                                                                    <div class="act-product-price-off-price">
                                                                        <?=number_format_usd($regular)?>
                                                                    </div>
                                                                    <div class="act-product-price-off-percent">
                                                                        <?=get_discount_percent($product)?> ٪
                                                                    </div>
                                                                </div>
                                                                <div class="act-product-price bpt"><div id="priceValue" data-id="<?=$product->get_id()?>" data-target="<?=$product->is_on_sale() ? $sale :$regular?>"><?=number_format_usd($sale)?></div><span>تومان</span></div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php endwhile; ?>
                                            <?php wp_reset_postdata(); ?>

                                        </div>
                                        <span class="swiper-notification" aria-live="assertive" aria-atomic="true"></span></div>

                                </div>
                                <div class="act-main-banner-content-box-carousel-mobile-buts">
                                    <div class="act-carousel-but act-main-banner-content-box-carousel-head-but-prev" tabindex="0" role="button" aria-label="Previous slide" aria-controls="swiper-wrapper-42d110487fefb6851" aria-disabled="false">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="currentcolor">
                                            <path d="M12.0253 15.6833C11.8669 15.6833 11.7086 15.625 11.5836 15.5C11.3419 15.2583 11.3419 14.8583 11.5836 14.6166L16.2003 9.99998L11.5836 5.38331C11.3419 5.14164 11.3419 4.74164 11.5836 4.49998C11.8253 4.25831 12.2253 4.25831 12.4669 4.49998L17.5253 9.55831C17.7669 9.79998 17.7669 10.2 17.5253 10.4416L12.4669 15.5C12.3419 15.625 12.1836 15.6833 12.0253 15.6833Z"></path>
                                            <path d="M16.942 10.625H2.91699C2.57533 10.625 2.29199 10.3417 2.29199 10C2.29199 9.65833 2.57533 9.375 2.91699 9.375H16.942C17.2837 9.375 17.567 9.65833 17.567 10C17.567 10.3417 17.2837 10.625 16.942 10.625Z"></path>
                                        </svg>
                                    </div>
                                    <div class="act-carousel-but act-main-banner-content-box-carousel-head-but-next swiper-button-disabled" tabindex="-1" role="button" aria-label="Next slide" aria-controls="swiper-wrapper-42d110487fefb6851" aria-disabled="true">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="currentcolor">
                                            <path d="M7.97474 4.31669C8.13307 4.31669 8.29141 4.37502 8.41641 4.50002C8.65807 4.74169 8.65807 5.14169 8.41641 5.38336L3.79974 10L8.41641 14.6167C8.65807 14.8584 8.65807 15.2584 8.41641 15.5C8.17474 15.7417 7.77474 15.7417 7.53307 15.5L2.47474 10.4417C2.23307 10.2 2.23307 9.80002 2.47474 9.55836L7.53307 4.50002C7.65807 4.37502 7.81641 4.31669 7.97474 4.31669Z"></path>
                                            <path d="M3.05801 9.375L17.083 9.375C17.4247 9.375 17.708 9.65833 17.708 10C17.708 10.3417 17.4247 10.625 17.083 10.625L3.05801 10.625C2.71634 10.625 2.43301 10.3417 2.43301 10C2.43301 9.65833 2.71634 9.375 3.05801 9.375Z"></path>
                                        </svg>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php
                    }
                    ?>
                </div>

                <div class="act-main-banner-content-scroll-down">
                    <p>Scroll Down</p>
                    <div class="position-relative">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="currentcolor">
                            <path d="M3.21712 11.8726L11.4671 20.1226C11.5368 20.1929 11.6198 20.2487 11.7112 20.2868C11.8026 20.3249 11.9006 20.3445 11.9996 20.3445C12.0986 20.3445 12.1967 20.3249 12.2881 20.2868C12.3794 20.2487 12.4624 20.1929 12.5321 20.1226L20.7821 11.8726C20.9218 11.7321 21.0002 11.542 21.0002 11.3439C21.0002 11.1457 20.9218 10.9556 20.7821 10.8151C20.7124 10.7448 20.6294 10.689 20.5381 10.6509C20.4467 10.6129 20.3486 10.5933 20.2496 10.5933C20.1506 10.5933 20.0526 10.6129 19.9612 10.6509C19.8698 10.689 19.7868 10.7448 19.7171 10.8151L11.9996 18.5326L4.28212 10.8151C4.2124 10.7448 4.12945 10.689 4.03805 10.6509C3.94666 10.6129 3.84863 10.5933 3.74962 10.5933C3.65061 10.5933 3.55258 10.6129 3.46119 10.6509C3.36979 10.689 3.28684 10.7448 3.21712 10.8151C3.07743 10.9556 2.99902 11.1457 2.99902 11.3439C2.99902 11.542 3.07743 11.7321 3.21712 11.8726Z"></path>
                            <path d="M11.4671 13.1851C11.5368 13.2554 11.6198 13.3112 11.7112 13.3493C11.8026 13.3874 11.9006 13.407 11.9996 13.407C12.0986 13.407 12.1967 13.3874 12.2881 13.3493C12.3794 13.3112 12.4624 13.2554 12.5321 13.1851L20.7821 4.93511C20.9218 4.79459 21.0002 4.6045 21.0002 4.40636C21.0002 4.20822 20.9218 4.01813 20.7821 3.87761C20.7124 3.80731 20.6294 3.75152 20.5381 3.71344C20.4467 3.67537 20.3486 3.65576 20.2496 3.65576C20.1506 3.65576 20.0526 3.67537 19.9612 3.71344C19.8698 3.75152 19.7868 3.80731 19.7171 3.87761L11.9996 11.5951L4.28212 3.87761C4.2124 3.80731 4.12945 3.75152 4.03805 3.71344C3.94666 3.67537 3.84863 3.65576 3.74962 3.65576C3.65061 3.65576 3.55258 3.67537 3.46119 3.71344C3.36979 3.75152 3.28684 3.80731 3.21712 3.87761C3.07743 4.01813 2.99902 4.20822 2.99902 4.40636C2.99902 4.6045 3.07743 4.79459 3.21712 4.93511L11.4671 13.1851Z" fill-opacity="0.4"></path>
                        </svg>
                        <svg xmlns="http://www.w3.org/2000/svg" width="18" height="10" viewBox="0 0 18 10" fill="currentcolor" class="act-main-banner-content-scroll-down-animate">
                            <path d="M0.218095 1.27935L8.46809 9.52935C8.53782 9.59964 8.62077 9.65544 8.71216 9.69352C8.80356 9.73159 8.90159 9.7512 9.00059 9.7512C9.0996 9.7512 9.19763 9.73159 9.28903 9.69352C9.38042 9.65544 9.46337 9.59964 9.53309 9.52935L17.7831 1.27935C17.9228 1.13883 18.0012 0.948738 18.0012 0.750599C18.0012 0.552459 17.9228 0.362371 17.7831 0.221849C17.7134 0.151552 17.6304 0.0957569 17.539 0.0576804C17.4476 0.0196039 17.3496 0 17.2506 0C17.1516 0 17.0536 0.0196039 16.9622 0.0576804C16.8708 0.0957569 16.7878 0.151552 16.7181 0.221849L9.00059 7.93935L1.28309 0.221849C1.21337 0.151552 1.13042 0.0957569 1.03903 0.0576804C0.947633 0.0196039 0.849603 0 0.750595 0C0.651586 0 0.553556 0.0196039 0.462162 0.0576804C0.370768 0.0957569 0.287817 0.151552 0.218095 0.221849C0.0784063 0.362371 0 0.552459 0 0.750599C0 0.948738 0.0784063 1.13883 0.218095 1.27935Z"></path>
                        </svg>
                    </div>
                </div>


            </div>
        </section>
        <?php
    }
    $db = \Giftmax\modules\Db::getLnstance();
    global $wpdb;

    $records = $db->first("SELECT meta_value FROM `{$wpdb->prefix}setting` WHERE `meta_key` = :key", ['key' => 'tab']);
    if (!empty($records) && !empty($records['meta_value'])){
        ?>
        <section class="container-xl-w mx-auto">
            <div class="act-new-service-carousel-1st">
                <div class="act-new-service-carousel-head d-flex align-items-center justify-content-between">
                    <svg xmlns="http://www.w3.org/2000/svg" width="1281" height="75" viewBox="0 0 1281 75" fill="none" class="act-new-service-carousel-head-svg">
                        <path d="M1280.47 0.5H1000.91C986.771 0.5 979.703 0.5 973.764 2.99163C969.027 4.9789 964.838 8.07733 961.551 12.025C957.43 16.9747 955.361 23.7331 951.224 37.25C947.086 50.7669 945.017 57.5253 940.896 62.475C937.609 66.4227 933.42 69.5211 928.683 71.5084C922.744 74 915.676 74 901.54 74H412.882C399.847 74 393.329 74 387.813 71.8926C382.12 69.7177 377.167 65.9625 373.536 61.0686C370.017 56.3267 368.257 50.0512 364.737 37.5C361.217 24.9488 359.457 18.6733 355.938 13.9314C352.307 9.0375 347.353 5.2823 341.661 3.10737C336.145 1 329.627 1 316.592 1H0" stroke="url(#paint0_linear_29_20094)"></path>
                        <defs>
                            <linearGradient id="paint0_linear_29_20094" x1="29.4736" y1="0.500002" x2="1213.79" y2="-28.0511" gradientUnits="userSpaceOnUse">
                                <stop stop-color="#0B61FF" stop-opacity="0"></stop>
                                <stop offset="0.5" stop-color="#0B61FF"></stop>
                                <stop offset="1" stop-color="#0B61FF" stop-opacity="0"></stop>
                            </linearGradient>
                        </defs>
                    </svg>
                    <div class="act-our-services-carousel-head-title">
                        <div class="act-our-services-carousel-head-title-divs">
                            <div class="act-our-services-carousel-head-title-div1"></div>
                            <div class="act-our-services-carousel-head-title-div2"></div>
                        </div>
                        <div class="act-our-services-carousel-head-title-content">
                            <h5>خرید <strong>سریع</strong> </h5>
                            <p>QUICK PURCHASE</p>
                        </div>
                    </div>
                </div>
                <?php
                $tabs = [];

                if (!empty($records) && !empty($records['meta_value'])) {

                    $array = json_decode($records['meta_value'], true);

                    if (!empty($array)) {

                        foreach ($array as $tab_key => $item) {

                            $tabs[$tab_key] = [
                                    'name'  => $item['name'],
                                    'ids'   => !empty($item['value']) ? explode(',', $item['value']) : []
                            ];
                        }
                    }
                }
                ?>
                <div class="card-settings">
                    <div class="card-settings__tabs">
                        <?php
                        $first = true;

                        foreach ($tabs as $key => $item): ?>
                            <button
                                    class="card-settings__tab <?= $first ? 'card-settings__tab--active' : '' ?>"
                                    data-tab="<?= esc_attr($key) ?>">
                                <?= esc_html($item['name']) ?>
                            </button>
                            <?php
                            $first = false;
                        endforeach;
                        ?>
                    </div>
                    <div class="card-settings__loading">
                        <span class="card-settings__spinner"></span>
                        <span>در حال بارگذاری...</span>
                    </div>
                    <div class="card-settings__panel">
                        <div class="flex">
                            <div class="card-settings__content">
                                <div class="card-settings__field card-settings__field--wide">
                                    <label>نوع کارت</label>
                                    <div>
                                        <select class="js-example-basic-single select2-hidden-accessible" name="cardType" id="cardType"></select>
                                    </div>
                                </div>
                                <div class="card-settings__field">
                                    <label>ریجن کارت</label>
                                    <div>
                                        <select class="js-example-basic-single select2-hidden-accessible" id="cardRegion"></select>
                                    </div>
                                </div>
                                <div class="card-settings__field">
                                    <label>میزان اعتبار</label>
                                    <div>
                                        <select class="js-example-basic-single select2-hidden-accessible" id="cardAmount"></select>
                                    </div>
                                </div>
                            </div>

                            <div id="finalPrice">
                                <label>قیمت محصول</label>
                                <strong>-</strong>
                            </div>
                        </div>
                        <div class="card-settings__actions" id="card-settings__actions">
                        </div>
                    </div>
                </div>
                <?php
                $products_data = [];

                foreach ($tabs as $t_key => $tab) {

                    $products = wc_get_products([
                            'status' => 'publish',
                            'limit'  => -1,

                            'tax_query' => [
                                    [
                                            'taxonomy' => 'product_cat',
                                            'field'    => 'term_id',
                                            'terms'    => $tab['ids'],
                                    ]
                            ],
                            'meta_query' => [
                                    'relation' => 'OR',

                                    [
                                            'key'     => 'giftmax_setting_order',
                                            'compare' => 'EXISTS',
                                            'type'    => 'NUMERIC',
                                    ],

                                    [
                                            'key'     => 'giftmax_setting_order',
                                            'compare' => 'NOT EXISTS',
                                    ],
                            ],

                            'orderby' => [
                                    'meta_value_num' => 'ASC',
                                    'date'           => 'DESC',
                            ],
                            'order' => 'ASC',
                    ]);


                    foreach ($products as $product) {

                        $delivery = get_post_meta($product->get_id(), 'delivery', true);
                        $is_presale = isset($delivery['two']) && $delivery['two'] == 'on';

                        if (!$is_presale && function_exists('product_available') && !product_available($product->get_id())) {
                            continue;
                        }

                        $pid = $product->get_id();

                        $cats = wp_get_post_terms($pid, 'product_cat');

                        $settings = get_post_meta($pid, 'giftmax_box_setting', true);
                        if (empty($settings[0]['logo_region'])) {
                            continue;
                        }

                        $region = $settings[0]['logo_region'];

                        foreach ($cats as $cat) {

                            if (!in_array($cat->term_id, $tab['ids'])) {
                                continue;
                            }

                            $category_key = sanitize_title($cat->name);

                            $products_data[$t_key][$category_key]['label'] = $cat->name;
                            $products_data[$t_key][$category_key]['regions_meta'][$region] = regionPersian($region);

                            $products_data[$t_key][$category_key]['regions'][$region][] = [
                                    'id'    => $pid,
                                    'title' => $product->get_name(),
                                    'price' => number_format_usd($product->get_price()),
                            ];
                        }
                    }
                }
                ?>
                <script>
                    window.PRODUCTS = <?= json_encode($products_data, JSON_UNESCAPED_UNICODE); ?>;
                </script>
            </div>

        </section>

        <?php
    }
    $home_coupon_objects = [];
    $home_coupon_ids = get_posts([
            'post_type'      => 'shop_coupon',
            'post_status'    => 'publish',
            'numberposts'    => -1,
            'fields'         => 'ids',
    ]);

    if (!empty($home_coupon_ids)) {
        foreach ($home_coupon_ids as $home_coupon_id) {
            $home_coupon_objects[] = new \WC_Coupon($home_coupon_id);
        }
    }
    $now = time();

    $all_categories = get_terms([
            'taxonomy'   => 'product_cat',
            'hide_empty' => true,
    ]);

    $categories = [];
    foreach ($all_categories as $cat) {
        $check = new \WP_Query([
                'post_type'      => 'product',
                'posts_per_page' => -1,
                'fields'         => 'ids',
                'tax_query'      => [
                        [
                                'taxonomy' => 'product_cat',
                                'field'    => 'term_id',
                                'terms'    => $cat->term_id,
                        ],
                ],
                'meta_query' => [
                        'relation' => 'AND',
                        [
                                'key'     => '_sale_price',
                                'value'   => 0,
                                'compare' => '>',
                                'type'    => 'NUMERIC',
                        ],
                        [
                                'relation' => 'OR',
                                [
                                        'key'     => '_sale_price_dates_from',
                                        'compare' => 'NOT EXISTS',
                                ],
                                [
                                        'key'     => '_sale_price_dates_from',
                                        'value'   => $now,
                                        'compare' => '<=',
                                        'type'    => 'NUMERIC',
                                ],
                        ],

                        [
                                'key'     => '_sale_price_dates_to',
                                'value'   => $now,
                                'compare' => '>=',
                                'type'    => 'NUMERIC',
                        ],
                ],
        ]);
        if ($check->have_posts()) {
            $max_discount_percentage = 0;
            $max_discount_product_id = 0;

            foreach ($check->posts as $product_id) {
                $regular_price = (float) get_post_meta($product_id, '_regular_price', true);
                $sale_price = (float) get_post_meta($product_id, '_sale_price', true);

                if ($regular_price > 0) {
                    $discount_percentage = (($regular_price - $sale_price) / $regular_price) * 100;

                    if ($discount_percentage > $max_discount_percentage) {
                        $max_discount_percentage = $discount_percentage;
                        $max_discount_product_id = $product_id;
                    }
                }
            }

            $categories[] = [
                    'term'                  => $cat,
                    'count'                 => $check->found_posts,
                    'max_discount_percent'  => round($max_discount_percentage, 2),
                    'max_discount_product'  => $max_discount_product_id,
            ];
        }

        wp_reset_postdata();
    }
    if(!empty($categories)){
        ?>
        <section class="container-xl-w mx-auto">
            <div class="act-special-carousel-1st">
                <div class="act-our-services-carousel-head d-flex align-items-center justify-content-between act-special-carousel-head">
                    <svg xmlns="http://www.w3.org/2000/svg" width="1281" height="75" viewBox="0 0 1281 75" fill="none" class="act-our-special-carousel-head-svg">
                        <path d="M1280.47 0.5H1046.91C1032.77 0.5 1025.7 0.5 1019.76 2.99163C1015.03 4.9789 1010.84 8.07733 1007.55 12.025C1003.43 16.9747 1001.36 23.7331 997.224 37.25C993.086 50.7669 991.017 57.5253 986.896 62.475C983.609 66.4227 979.42 69.5211 974.683 71.5084C968.744 74 961.676 74 947.54 74H534.882C521.847 74 515.329 74 509.813 71.8926C504.12 69.7177 499.167 65.9625 495.536 61.0686C492.017 56.3267 490.257 50.0512 486.737 37.5C483.217 24.9488 481.457 18.6733 477.938 13.9314C474.307 9.0375 469.353 5.2823 463.661 3.10737C458.145 1 451.627 1 438.592 1H0" stroke="url(#paint0_linear_29_19963)"></path>
                        <defs>
                            <linearGradient id="paint0_linear_29_19963" x1="29.4736" y1="0.500002" x2="1213.79" y2="-28.0511" gradientUnits="userSpaceOnUse">
                                <stop stop-color="#0B61FF" stop-opacity="0"></stop>
                                <stop offset="0.5" stop-color="#0B61FF"></stop>
                                <stop offset="1" stop-color="#0B61FF" stop-opacity="0"></stop>
                            </linearGradient>
                        </defs>
                    </svg>
                    <div class="act-our-services-carousel-head-title">
                        <div class="act-our-services-carousel-head-title-divs">
                            <div class="act-our-services-carousel-head-title-div1"></div>
                            <div class="act-our-services-carousel-head-title-div2"></div>
                        </div>
                        <div class="act-our-services-carousel-head-title-content">
                            <div class="act-our-services-carousel-head-title-content"><h5>تخفیفات <strong> شگـــــــفت انگیز </strong></h5><p>SALE PRODUCTS</p></div>                    </div>
                    </div>
                    <div class="act-special-carousel-head-buts">
                        <div class="act-special-carousel-head-nav-buts">
                            <div class="act-carousel-but act-special-carousel-head-nav-buts-prev swiper-button-disabled" tabindex="-1" role="button" aria-label="Previous slide" aria-controls="swiper-wrapper-d729d82cbdf1da810" aria-disabled="true">
                                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="currentcolor">
                                    <path d="M12.0253 15.6833C11.8669 15.6833 11.7086 15.625 11.5836 15.5C11.3419 15.2583 11.3419 14.8583 11.5836 14.6166L16.2003 9.99998L11.5836 5.38331C11.3419 5.14164 11.3419 4.74164 11.5836 4.49998C11.8253 4.25831 12.2253 4.25831 12.4669 4.49998L17.5253 9.55831C17.7669 9.79998 17.7669 10.2 17.5253 10.4416L12.4669 15.5C12.3419 15.625 12.1836 15.6833 12.0253 15.6833Z"></path>
                                    <path d="M16.942 10.625H2.91699C2.57533 10.625 2.29199 10.3417 2.29199 10C2.29199 9.65833 2.57533 9.375 2.91699 9.375H16.942C17.2837 9.375 17.567 9.65833 17.567 10C17.567 10.3417 17.2837 10.625 16.942 10.625Z"></path>
                                </svg>
                            </div>
                            <div class="act-carousel-but act-special-carousel-head-nav-buts-next" tabindex="0" role="button" aria-label="Next slide" aria-controls="swiper-wrapper-d729d82cbdf1da810" aria-disabled="false">
                                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="currentcolor">
                                    <path d="M7.97474 4.31669C8.13307 4.31669 8.29141 4.37502 8.41641 4.50002C8.65807 4.74169 8.65807 5.14169 8.41641 5.38336L3.79974 10L8.41641 14.6167C8.65807 14.8584 8.65807 15.2584 8.41641 15.5C8.17474 15.7417 7.77474 15.7417 7.53307 15.5L2.47474 10.4417C2.23307 10.2 2.23307 9.80002 2.47474 9.55836L7.53307 4.50002C7.65807 4.37502 7.81641 4.31669 7.97474 4.31669Z"></path>
                                    <path d="M3.05801 9.375L17.083 9.375C17.4247 9.375 17.708 9.65833 17.708 10C17.708 10.3417 17.4247 10.625 17.083 10.625L3.05801 10.625C2.71634 10.625 2.43301 10.3417 2.43301 10C2.43301 9.65833 2.71634 9.375 3.05801 9.375Z"></path>
                                </svg>
                            </div>
                        </div>


                    </div>


                </div>

                <div class="act-special-carousel-main">
                    <div class="act-special-carousel-main-list">
                        <div class="act-special-carousel-main-list-prev swiper-button-disabled">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="currentcolor" stroke="currentcolor">
                                <path d="M19.6279 8.65771C19.7865 8.4996 20.0535 8.49934 20.2119 8.65771C20.3703 8.81611 20.37 9.08312 20.2119 9.2417L13.6914 15.7622C13.2268 16.2267 12.6136 16.4633 12 16.4634C11.3862 16.4634 10.7723 16.2269 10.3076 15.7622L3.78711 9.2417C3.629 9.08311 3.62872 8.81611 3.78711 8.65771C3.9455 8.49932 4.21251 8.49961 4.37109 8.65771L10.8916 15.1782C11.503 15.7896 12.496 15.7896 13.1074 15.1782L19.6279 8.65771Z" stroke-width="0.673278"></path>
                            </svg>
                        </div>
                        <div class="act-special-carousel-main-list-next">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="currentcolor" stroke="currentcolor">
                                <path d="M19.6279 8.65771C19.7865 8.4996 20.0535 8.49934 20.2119 8.65771C20.3703 8.81611 20.37 9.08312 20.2119 9.2417L13.6914 15.7622C13.2268 16.2267 12.6136 16.4633 12 16.4634C11.3862 16.4634 10.7723 16.2269 10.3076 15.7622L3.78711 9.2417C3.629 9.08311 3.62872 8.81611 3.78711 8.65771C3.9455 8.49932 4.21251 8.49961 4.37109 8.65771L10.8916 15.1782C11.503 15.7896 12.496 15.7896 13.1074 15.1782L19.6279 8.65771Z" stroke-width="0.673278"></path>
                            </svg>
                        </div>
                        <div class="swiper act-special-carousel-main-list-carousel">
                            <div class="swiper-wrapper">
                                <?php foreach ($categories as $index => $item):
                                    $cat = $item['term'];
                                    $max_discount_percent = $item['max_discount_percent'];
                                    $max_discount_product = $item['max_discount_product'];
                                    $discount_count = $item['count'];
                                    ?>
                                    <div class="swiper-slide w-auto" style="margin-bottom:8px;">
                                        <button type="button" class="act-special-carousel-main-list-carousel-item <?= $index === 0 ? 'active' : '' ?>" data-cat="<?= esc_attr($cat->slug) ?>">
                                            <div class="act-catagory-card-inner align-items-center">
                                                <div class="act-catagory-card-name">
                                                    <div class="act-our-services-carousel-head-title-divs">
                                                        <div class="act-our-services-carousel-head-title-div1" style= "height: 15px;  margin-bottom: 4px;"></div>
                                                        <div class="act-our-services-carousel-head-title-div2" style=" height: 12px;"></div>
                                                    </div>
                                                    <div class="act-catagory-name-text">
                                                        <strong class="ellipsis"><?php echo esc_html($cat->name); ?></strong>
                                                        <p><?=giftmax_get_term_english_name($cat)?></p>
                                                    </div>
                                                </div>
                                                <div class="act-catagory-card-product">
                                                    <span><strong><?=$discount_count ?></strong> محصول</span>
                                                </div>
                                                <div class="flex flex-col relative">
                                                    <a class="text-[9px]" style=" background-color: #000000; color: #FFF; padding: 2px 0; margin-bottom: 1px; border-radius: 6px; " href="<?=get_permalink($max_discount_product)?>">مشاهده محصول</a>
                                                    <div class="act-product-price-off-percent" style="border-radius: 8px !important;width: 41px !important;height: 23px !important;"><?=$max_discount_percent?>%</div>
                                                </div>
                                        </button>
                                    </div>

                                <?php endforeach; ?>
                            </div>
                            <span class="swiper-notification" aria-live="assertive" aria-atomic="true"></span></div>
                    </div>
                    <div class="act-special-carousel-main-carousels-list">

                        <?php foreach ($categories as $index => $item):
                            $cat = $item['term'];
                            ?>

                            <div class="act-special-carousel-main-carousel-box <?= $index === 0 ? 'active' : '' ?>" data-cat="<?= esc_attr($cat->slug) ?>">

                                <div class="swiper act-special-carousel-main-carousel swiper-rtl swiper-free-mode">
                                    <div class="swiper-wrapper">

                                        <?php
                                        $products = new \WP_Query([
                                                'post_type'      => 'product',
                                                'posts_per_page' => 6,
                                                'tax_query'      => [
                                                        [
                                                                'taxonomy' => 'product_cat',
                                                                'field'    => 'slug',
                                                                'terms'    => $cat->slug,
                                                        ],
                                                ],
                                                'meta_query' => [
                                                        'relation' => 'AND',
                                                        [
                                                                'key'     => '_sale_price',
                                                                'value'   => 0,
                                                                'compare' => '>',
                                                                'type'    => 'NUMERIC',
                                                        ],
                                                        [
                                                                'relation' => 'OR',
                                                                [
                                                                        'key'     => '_sale_price_dates_from',
                                                                        'compare' => 'NOT EXISTS',
                                                                ],
                                                                [
                                                                        'key'     => '_sale_price_dates_from',
                                                                        'value'   => $now,
                                                                        'compare' => '<=',
                                                                        'type'    => 'NUMERIC',
                                                                ],
                                                        ],

                                                        [
                                                                'key'     => '_sale_price_dates_to',
                                                                'value'   => $now,
                                                                'compare' => '>=',
                                                                'type'    => 'NUMERIC',
                                                        ],
                                                ],
                                        ]);
                                        if ($products->have_posts()):
                                            while ($products->have_posts()):
                                                $products->the_post();
                                                global $product;
                                                $regular = (float) $product->get_regular_price();
                                                $sale    = (float) $product->get_sale_price();

                                                $discount_percent = ($regular > 0 && $sale > 0)
                                                        ? round((($regular - $sale) / $regular) * 100)
                                                        : 0;
                                                $sale_to = $product->get_date_on_sale_to();
                                                $sale_to_ts = $sale_to ? $sale_to->getTimestamp() : null;
                                                $img = get_the_post_thumbnail_url(get_the_ID(), 'product_discount');
                                                $settings = get_post_meta($product->get_id(), 'giftmax_box_setting', true);
                                                $delivery = get_post_meta($product->get_id(), 'delivery', true);
                                                if (!empty($home_coupon_objects)) {
                                                    foreach ($home_coupon_objects as $home_coupon_obj) {
                                                        $expires_at = $home_coupon_obj->get_date_expires();

                                                        if ($expires_at && $expires_at->getTimestamp() < current_time('timestamp')) {
                                                            continue;
                                                        }

                                                        if ($home_coupon_obj->is_valid_for_product($product)) {
                                                            $matched_coupon_code = $home_coupon_obj->get_code();
                                                            break;
                                                        }
                                                    }
                                                }
                                                ?>
                                                <div class="swiper-slide">
                                                    <div class="act-percent-card">
                                                        <div class="flex flex-col bg-white relative z-1">
                                                            <div class="relative">
                                                                <div class="act-new-service-card-inner-top">
                                                                    <a href="<?=get_permalink()?>">
                                                                        <div class="flex dj45fd">
                                                                            <?php
                                                                            $tooltip = isset($delivery['description']) ? $delivery['description'] : '';
                                                                            ?>
                                                                            <div class="act-product-option-box__nw <?=isset($delivery['two']) && $delivery['two'] == 'on' ? 'pre-sale wiki wiki__holder js-dk-wiki-trigger' : 'same-day'?>" <?=isset($delivery['two']) && $delivery['two'] == 'on' ? 'data-tooltip="'. $tooltip .'"' :''?>><?=isset($delivery['two']) && $delivery['two'] == 'on' ? 'پیش فروش' : 'تحویل آنی'?></div>
                                                                            <div class="purchaseScore wiki wiki__holder js-dk-wiki-trigger" data-tooltip="با خرید این گیفت کارت <?=empty($settings[0]['purchaseScore']) ?0: $settings[0]['purchaseScore']?> امتیاز دریافت میکنید">
                                                                                <i class="icon-star"></i>
                                                                                <?=empty($settings[0]['purchaseScore']) ?0: $settings[0]['purchaseScore']?>
                                                                            </div>
                                                                            <?php
                                                                            if (!empty($matched_coupon_code)) { ?>
                                                                                <div class="act-special-carousel-card-discount Button-sc91" data-product-id="<?=esc_attr($product->get_id())?>">
                                                                                    کد تخفیف
                                                                                </div>
                                                                            <?php } elseif (!empty($settings[0]['label']) && $settings[0]['label'] != ''){?>
                                                                                <div class="label-fjd84">
                                                                                    <img src="<?=empty($settings[0]['label']) ?'': $settings[0]['label']?>" class="logo_label">
                                                                                    <p class="label_title"><?=empty($settings[0]['label_title']) ?'': $settings[0]['label_title']?></p>
                                                                                </div>
                                                                                <?php
                                                                            }
                                                                            ?>
                                                                        </div>
                                                                        <div class="act-new-service-card-inner-top-img-box relative aib36">
                                                                            <img src="<?=$img?>" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="<?=get_the_title()?>">
                                                                        </div>
                                                                    </a>
                                                                </div>
                                                                <?php
                                                                if (!empty($settings[0]['logo_region'])){
                                                                    ?>
                                                                    <div class="logo_region">
                                                                        <img src="<?=empty($settings[0]['logo_region']) ?: get_template_directory_uri() . '/assets/flag/' . $settings[0]['logo_region'] . '.svg'?>">
                                                                    </div>
                                                                    <?php
                                                                }
                                                                ?>
                                                                <div class="act-product-price-off-percent">  <?=get_discount_percent($product)?> ٪       </div>
                                                            </div>
                                                            <div class="act-bar-left">
                                                                <div class="flex justify-between">
                                                                    <a class="lg:w-80" href="<?=get_permalink()?>"><h4 class="ellipsis"><?=get_the_title()?></h4></a>
                                                                    <?php
                                                                    $giftmax_is_user_logged_in = is_user_logged_in();
                                                                    $giftmax_wishlist_ids = $giftmax_is_user_logged_in ? giftmax_get_user_wishlist_product_ids() : [];
                                                                    if ($giftmax_is_user_logged_in){
                                                                        $is_in_wishlist = in_array((int) $product->get_id(), $giftmax_wishlist_ids, true); ?>
                                                                        <button class="add-to__favorites Button-alu84 <?=$is_in_wishlist ? 'is-active' : ''?>" data-product-id="<?=esc_attr($product->get_id())?>" style="width: 28px;height: 28px;border-radius: 7px">
                                                                            <svg viewBox="0 0 24 24" style="width: 64%;">
                                                                                <path d="M12.62 20.81C12.28 20.93 11.72 20.93 11.38 20.81C8.48 19.82 2 15.69 2 8.68998C2 5.59998 4.49 3.09998 7.56 3.09998C9.38 3.09998 10.99 3.97998 12 5.33998C13.01 3.97998 14.63 3.09998 16.44 3.09998C19.51 3.09998 22 5.59998 22 8.68998C22 15.69 15.52 19.82 12.62 20.81Z" fill="<?=$is_in_wishlist ? '#ef4444' : 'none'?>" stroke="<?=$is_in_wishlist ? '#ef4444' : 'inherit'?>" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                                                                            </svg>
                                                                        </button>
                                                                        <?php
                                                                    }
                                                                    ?>
                                                                </div>
                                                                <?php
                                                                if(!empty($settings[0]['sub_head']) && !isMobile()) echo "<p class='act-product-title-en mb-1'>" . $settings[0]['sub_head'] . "</p>";
                                                                ?>
                                                                <div class="flex justify-between mb-1 kef4e">
                                                                    <?php
                                                                    if (!is_null($sale_to_ts)){
                                                                        ?>
                                                                        <img class="inline-block lg:w-30" src="<?=get_template_directory_uri()?>/assets/img/svg/IncredibleOffer.svg" alt="" title="" style="object-fit: contain;">
                                                                        <div class="text-primary-700 text-body2-strong" style="display:block;"><i class="icon-clock mr-1"></i><span class="style_ProductPromotionTimeline__timer__zS6ZA"><?= date('Y-m-d H:i:s', $sale_to_ts); ?></span></div>

                                                                        <?php
                                                                    }else{ ?>
                                                                        <img class="inline-block lg:w-30" src="<?=get_template_directory_uri()?>/assets/img/svg/Offer.svg" alt="" title="" style="object-fit: contain;">

                                                                        <?php
                                                                    }
                                                                    ?>
                                                                </div>

                                                                <div class="flex justify-between w-full">
                                                                    <?php
                                                                    if (isset($delivery['two']) && $delivery['two'] == 'on' || product_available($product->get_id())){
                                                                        if (\Giftmax\model\SiteModel::setting("buy") === true){
                                                                            ?>

                                                                            <button data-product-id="<?=$product->get_id()?>" class="act-percent-card-buy-box-but Button-aca48 pointer" type="button">
                                                                                افزودن به سبد خرید
                                                                            </button>
                                                                            <?php
                                                                        }else{?>
                                                                            <button type="button" class="btn-buy-disable3" >خرید از سایت غیرفعال هست</button>
                                                                            <?php
                                                                        }
                                                                    }else{
                                                                        echo '<div class="inaJSDge8" style="height: 30px">ناموجود</div>';
                                                                    }?>
                                                                    <div class="act-product-price-box">
                                                                        <div class="act-product-price bpt">
                                                                            <div id="priceValue" data-id="<?=$product->get_id()?>" data-target="<?=$product->is_on_sale() ? $sale :$regular?>"><?=number_format_usd($sale)?></div>
                                                                            <span>تومان</span>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>

                                            <?php
                                            endwhile;
                                            wp_reset_postdata();
                                        endif;
                                        ?>

                                    </div>
                                </div>
                            </div>

                        <?php endforeach; ?>
                        <a class="w-full md:w-10 h-full flex justify-between lg:flex-col gap-3 pt-5 pb-3 dsjr6" href="/incredible-offers/">
                            <div class="flex lg:flex-col justify-center items-center gap-2">
                                <?php
                                if (isMobile()){
                                    ?>
                                    <div class="order-2 lg:order-1" style="width: 108px; height: 20px; line-height: 0;">
                                        <img class="w-full inline-block" src="<?=get_template_directory_uri()?>/assets/img/svg/e0c05f5d.svg" width="108" height="20" alt="شگفت انگیز" title="" style="object-fit: contain;">
                                    </div>
                                    <?php
                                }else{
                                    ?>
                                    <div class="order-2 lg:order-1 gf1" style="width: 88px; height: 88px; line-height: 0;">
                                        <img class="w-full inline-block" src="<?=get_template_directory_uri()?>/assets/img/svg/Amazingsw.svg" width="88" height="88" alt="شگفت انگیز" title="" style="object-fit: contain;">
                                    </div>
                                    <div class="h-6"></div>
                                    <?php
                                }
                                ?>
                                <div class="order-1 lg:order-3 flex justify-center<?=isMobile() ? '' : ' gf2'?>" aria-hidden="false" aria-label="شگفت انگیز"
                                     style="line-height: 0;">
                                    <img class="w-full inline-block"
                                         src="<?=get_template_directory_uri()?>/assets/img/svg/timer.svg" alt="شگفت انگیز" title=""
                                         style="object-fit: contain;<?=isMobile() ? 'width: 20px;' : 'width: 45px;'?>">
                                </div>
                            </div>
                            <div class="flex justify-center items-center text-button-2 text-white">
                                مشاهده همه
                                <div class="flex" aria-hidden="false">
                                    <svg style="width: 18px; height: 18px; fill: #FFF;">
                                        <use xlink:href="#chevronLeft"></use>
                                    </svg>
                                </div>
                            </div>
                        </a>
                    </div>
                </div>
            </div>
        </section>
        <?php
    }
    ?>
    <section class="container-xl-w mx-auto mt-18">
        <div class="act-parent-catagory">
            <div class="act-catagory-title">
                <div class="act-catagory-title-right">
                    <div class="act-catagory-title-right-hand act-catagory-title-right-hand-1"></div>
                    <div class="act-catagory-title-right-hand act-catagory-title-right-hand-2"></div>
                    <div class="act-catagory-title-right-hand act-catagory-title-right-hand-3"></div>
                </div>
                <div class="act-catagory-title-main">
                    <div class="act-catagory-title-text">
                        <strong>دســــــته بندی</strong>
                        <h5>محــــصولات</h5>
                    </div>
                    <a href="<?=home_url('/shop')?>" class="act-catagory-title-see-more">
                        مشاهده همه                            <svg xmlns="http://www.w3.org/2000/svg" width="34" height="34" viewBox="0 0 34 34" fill="currentcolor"><path d="M10.43 20.0749C10.5644 20.2093 10.7482 20.2941 10.9604 20.2941C11.3705 20.2941 11.7099 19.9547 11.7099 19.5446L11.7099 11.7098L19.5446 11.7098C19.9548 11.7098 20.2942 11.3704 20.2942 10.9603C20.2942 10.5502 19.9548 10.2108 19.5446 10.2108L10.9604 10.2108C10.5502 10.2108 10.2108 10.5502 10.2108 10.9603L10.2108 19.5446C10.2108 19.7567 10.2957 19.9406 10.43 20.0749Z"></path><path d="M10.5501 11.6105L22.4507 23.5111C22.7406 23.8011 23.2215 23.8011 23.5114 23.5111C23.8013 23.2212 23.8013 22.7404 23.5114 22.4505L11.6108 10.5499C11.3209 10.26 10.84 10.26 10.5501 10.5499C10.2602 10.8398 10.2602 11.3206 10.5501 11.6105Z"></path></svg>                        </a>
                </div>
            </div>

            <div class="act-product-swiper">
                <?php

                $categories = get_terms(array(
                        'taxonomy'   => 'product_cat',
                        'hide_empty' => false,
                ));
                if (!empty($categories) && !is_wp_error($categories)) :
                    ?>
                    <div class="flex fhDG1">
                        <?php foreach ($categories as $category) :
                            if ($category->count == 0) continue;
                            ?>
                            <div>
                                <button type="button" data-category-id="<?=esc_attr($category->term_id)?>" class="act-catagory-card pointer Category-al74">
                                    <div class="act-catagory-card-inner">
                                        <div class="act-catagory-card-name">
                                            <div class="act-our-services-carousel-head-title-divs">
                                                <div class="act-our-services-carousel-head-title-div1" style= "height: 15px;  margin-bottom: 4px;"></div>
                                                <div class="act-our-services-carousel-head-title-div2" style=" height: 12px;"></div>
                                            </div>
                                            <div class="act-catagory-name-text" style="width: 78%">
                                                <strong class="ellipsis-1"><?php echo esc_html($category->name); ?></strong>
                                                <p class="ellipsis-1"><?=giftmax_get_term_english_name($category)?></p>
                                            </div>
                                        </div>
                                        <div class="act-catagory-card-product">
                                            <span><strong><?php echo esc_html($category->count); ?></strong> محصول</span>
                                        </div>
                                        <div style="display: flex;position: relative;">
                                                    <span class="KLTNA4eI5h" style="">
                                                        <img class="w-full h-full" src="<?=get_template_directory_uri()?>/assets/img/img100000.png" alt="img">
                                                    </span>
                                            <span class="cu0aLp8G0w" style="">
                                                        <img class="w-full h-full" src="<?=get_template_directory_uri()?>/assets/img/img100000.png" alt="img">
                                                    </span>
                                            <div class="thumbnail-img">
                                                <img class="w-full h-full" src="<?=get_template_directory_uri()?>/assets/img/img100000.png" alt="img">
                                            </div>
                                            <div class="icon-cat">
                                                <?php
                                                $thumbnail_id = get_term_meta($category->term_id, 'thumbnail_id', true);
                                                if ($thumbnail_id) {
                                                    $image = wp_get_attachment_url($thumbnail_id);
                                                    echo '<img src="' . esc_url($image) . '" alt="' . esc_attr($category->name) . '">';
                                                } else {
                                                    ?>
                                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentcolor">
                                                        <path d="M17.2487 15.9994V8.00055C17.2487 7.31144 16.688 6.75072 15.9989 6.75072H8.00155C7.31244 6.75072 6.75172 7.31144 6.75172 8.00055V15.9994C6.75172 16.6885 7.31244 17.2492 8.00155 17.2492H15.9989C16.688 17.2492 17.2487 16.6885 17.2487 15.9994ZM7.25164 15.9994V8.00055C7.25164 7.58702 7.58802 7.25065 8.00155 7.25065H15.9989C16.4125 7.25065 16.7488 7.58702 16.7488 8.00055V15.9994C16.7488 16.4129 16.4125 16.7493 15.9989 16.7493H8.00155C7.58802 16.7493 7.25164 16.4129 7.25164 15.9994ZM11.1446 9.35641C10.156 9.35641 9.35188 10.1606 9.35188 11.149V14.3936C9.35188 14.5317 9.46367 14.6436 9.60186 14.6436C9.74005 14.6436 9.85184 14.5317 9.85184 14.3936V12.5081H12.4374V14.3937C12.4374 14.4265 12.4439 14.459 12.4564 14.4894C12.469 14.5197 12.4874 14.5473 12.5106 14.5705C12.5338 14.5937 12.5614 14.6121 12.5917 14.6247C12.6221 14.6372 12.6546 14.6437 12.6874 14.6437C12.7202 14.6437 12.7527 14.6372 12.7831 14.6247C12.8134 14.6121 12.841 14.5937 12.8642 14.5705C12.8874 14.5473 12.9058 14.5197 12.9184 14.4894C12.9309 14.459 12.9374 14.4265 12.9374 14.3937V11.1491C12.9373 10.1606 12.1332 9.35641 11.1446 9.35641ZM12.4374 12.0081H9.85184V11.149C9.85184 10.4362 10.4318 9.85633 11.1446 9.85633C11.8574 9.85633 12.4374 10.4362 12.4374 11.149V12.0081H12.4374ZM14.6485 9.6064V14.3937C14.6485 14.5317 14.5367 14.6437 14.3985 14.6437C14.2603 14.6437 14.1485 14.5317 14.1485 14.3937V9.6064C14.1485 9.46835 14.2603 9.35641 14.3985 9.35641C14.5367 9.35641 14.6485 9.46835 14.6485 9.6064ZM16.9558 6.18185C16.9886 6.18186 17.0211 6.17539 17.0515 6.16283C17.0818 6.15027 17.1094 6.13186 17.1326 6.10864C17.1558 6.08543 17.1742 6.05787 17.1868 6.02754C17.1993 5.99721 17.2058 5.96469 17.2058 5.93186V4.54132L18.2005 3.54658C18.2474 3.49971 18.2737 3.43615 18.2737 3.36986V1.86349H18.3472C18.6821 1.86349 18.9548 1.59105 18.9548 1.25618V0.609021C18.9548 0.2741 18.6821 0.00170898 18.3472 0.00170898H17.7001C17.3652 0.00170898 17.0928 0.274146 17.0928 0.609021V1.25613C17.0928 1.59105 17.3652 1.86344 17.7001 1.86344H17.7738V3.26632L16.7791 4.26105C16.7322 4.30793 16.7059 4.37149 16.7059 4.43777V5.93182C16.7058 5.96465 16.7123 5.99716 16.7249 6.02749C16.7374 6.05783 16.7558 6.08539 16.779 6.10861C16.8022 6.13183 16.8298 6.15025 16.8601 6.16282C16.8905 6.17538 16.923 6.18185 16.9558 6.18185ZM17.7001 1.36357C17.6716 1.36354 17.6443 1.35222 17.6242 1.33209C17.604 1.31195 17.5927 1.28465 17.5927 1.25618V0.609021C17.5927 0.580547 17.604 0.553246 17.6242 0.533112C17.6443 0.512978 17.6716 0.501656 17.7001 0.501631H18.3472C18.3757 0.501643 18.403 0.512953 18.4232 0.533081C18.4434 0.55321 18.4548 0.580518 18.4549 0.609021V1.25613C18.4548 1.28464 18.4434 1.31195 18.4232 1.33208C18.403 1.35222 18.3757 1.36352 18.3472 1.36352L17.7001 1.36357ZM13.4453 6.18185C13.4782 6.18186 13.5107 6.17539 13.541 6.16283C13.5713 6.15027 13.5989 6.13186 13.6221 6.10864C13.6453 6.08543 13.6637 6.05787 13.6763 6.02754C13.6889 5.99721 13.6953 5.96469 13.6953 5.93186V4.52032L14.4379 3.51874C14.4697 3.4756 14.4869 3.42342 14.4869 3.36982V1.86349H14.5604C14.8954 1.86349 15.1678 1.59105 15.1678 1.25618V0.609021C15.1678 0.2741 14.8953 0.00170898 14.5604 0.00170898H13.9133C13.5784 0.00170898 13.306 0.274146 13.306 0.609021V1.25613C13.306 1.59105 13.5785 1.86344 13.9133 1.86344H13.9871V3.28732L13.2445 4.2889C13.2127 4.33204 13.1955 4.38422 13.1954 4.43782V5.93186C13.1954 5.96469 13.2019 5.9972 13.2144 6.02754C13.227 6.05787 13.2454 6.08544 13.2686 6.10865C13.2918 6.13187 13.3193 6.15028 13.3497 6.16284C13.38 6.1754 13.4125 6.18186 13.4453 6.18185ZM13.9133 1.36357C13.8848 1.36354 13.8575 1.35222 13.8374 1.33209C13.8172 1.31195 13.8059 1.28465 13.8059 1.25618V0.609021C13.8059 0.580547 13.8172 0.553246 13.8374 0.533112C13.8575 0.512978 13.8848 0.501656 13.9133 0.501631H14.5604C14.5889 0.501656 14.6162 0.512978 14.6363 0.533112C14.6564 0.553246 14.6678 0.580547 14.6678 0.609021V1.25613C14.6678 1.28461 14.6564 1.31191 14.6363 1.33204C14.6162 1.35217 14.5889 1.3635 14.5604 1.36352L13.9133 1.36357ZM12.2861 6.18185C12.2532 6.18186 12.2207 6.17539 12.1904 6.16283C12.1601 6.15027 12.1325 6.13186 12.1093 6.10864C12.0861 6.08543 12.0677 6.05787 12.0551 6.02754C12.0425 5.99721 12.0361 5.96469 12.0361 5.93186V4.47199C12.0361 4.43916 12.0425 4.40665 12.0551 4.37632C12.0677 4.34599 12.0861 4.31843 12.1093 4.29521C12.1325 4.272 12.1601 4.25358 12.1904 4.24102C12.2207 4.22846 12.2532 4.222 12.2861 4.22201C12.3189 4.222 12.3514 4.22846 12.3817 4.24102C12.4121 4.25358 12.4396 4.272 12.4628 4.29521C12.4861 4.31843 12.5045 4.34599 12.517 4.37632C12.5296 4.40665 12.5361 4.43916 12.536 4.47199V5.93186C12.5361 5.96469 12.5296 5.99721 12.517 6.02754C12.5045 6.05787 12.4861 6.08543 12.4628 6.10864C12.4396 6.13186 12.4121 6.15027 12.3817 6.16283C12.3514 6.17539 12.3189 6.18186 12.2861 6.18185ZM10.2763 6.17074C10.3092 6.17075 10.3417 6.16428 10.372 6.15172C10.4023 6.13916 10.4299 6.12075 10.4531 6.09754C10.4763 6.07432 10.4948 6.04676 10.5073 6.01643C10.5199 5.9861 10.5263 5.95359 10.5263 5.92076V4.50129L11.4384 3.42382L11.4534 3.43882C11.6759 3.66087 12.0378 3.6611 12.2604 3.43868L12.671 3.0281C12.8938 2.80563 12.8941 2.44493 12.6708 2.2211L12.26 1.81076C12.0373 1.58815 11.6756 1.58815 11.453 1.81076L11.0424 2.22124C10.82 2.44362 10.82 2.80563 11.0426 3.02824L11.0835 3.06916L10.0855 4.2483C10.0473 4.29348 10.0264 4.35068 10.0264 4.40979V5.9208C10.0264 5.95363 10.0329 5.98613 10.0454 6.01646C10.058 6.04679 10.0764 6.07435 10.0996 6.09756C10.1228 6.12077 10.1504 6.13918 10.1807 6.15174C10.211 6.1643 10.2435 6.17075 10.2763 6.17074ZM11.3958 2.57468L11.8064 2.16419C11.8197 2.15096 11.8377 2.14354 11.8565 2.14356C11.8752 2.14359 11.8932 2.15106 11.9065 2.16433L12.3173 2.57468C12.3449 2.60252 12.345 2.64719 12.3175 2.67452V2.67466L11.9069 3.08515C11.8936 3.09838 11.8757 3.10581 11.8569 3.10581C11.8381 3.10581 11.8202 3.09838 11.8069 3.08515L11.396 2.67466C11.3828 2.66142 11.3753 2.64346 11.3753 2.62472C11.3752 2.60597 11.3826 2.58798 11.3958 2.57468ZM5.65325 1.86349H5.7267V3.36986C5.7267 3.43615 5.75305 3.49971 5.79992 3.54658L6.79466 4.54132V5.93186C6.79466 6.06991 6.90645 6.18185 7.04464 6.18185C7.18283 6.18185 7.29462 6.06991 7.29462 5.93186V4.43782C7.29462 4.37154 7.26828 4.30797 7.22141 4.2611L6.22662 3.26637V1.86349H6.30036C6.63528 1.86349 6.90767 1.59105 6.90767 1.25618V0.609021C6.90767 0.2741 6.63523 0.00170898 6.30036 0.00170898H5.65325C5.31833 0.00170898 5.04594 0.274146 5.04594 0.609021V1.25613C5.04589 1.59105 5.31833 1.86349 5.65325 1.86349ZM5.54581 0.609021C5.54584 0.580547 5.55716 0.553246 5.57729 0.533112C5.59743 0.512978 5.62473 0.501656 5.6532 0.501631H6.30031C6.32879 0.501656 6.35609 0.512978 6.37622 0.533112C6.39636 0.553246 6.40768 0.580547 6.4077 0.609021V1.25613C6.40768 1.28461 6.39636 1.31191 6.37622 1.33204C6.35609 1.35217 6.32879 1.3635 6.30031 1.36352H5.6532C5.62473 1.3635 5.59743 1.35217 5.57729 1.33204C5.55716 1.31191 5.54584 1.28461 5.54581 1.25613V0.609021ZM8.33694 3.65304H8.41039V5.93186C8.41039 5.96469 8.41685 5.99721 8.42941 6.02754C8.44197 6.05787 8.46038 6.08543 8.4836 6.10864C8.50681 6.13186 8.53437 6.15027 8.5647 6.16283C8.59504 6.17539 8.62754 6.18186 8.66037 6.18185C8.6932 6.18186 8.72571 6.17539 8.75605 6.16283C8.78638 6.15027 8.81394 6.13186 8.83715 6.10864C8.86037 6.08543 8.87878 6.05787 8.89134 6.02754C8.9039 5.99721 8.91037 5.96469 8.91036 5.93186V3.65304H8.98409C9.31902 3.65304 9.59141 3.38051 9.59141 3.04558V2.39857C9.59141 2.06365 9.31897 1.79112 8.98409 1.79112H8.33694C8.00202 1.79112 7.72962 2.06365 7.72962 2.39857V3.04558C7.72958 3.38051 8.00202 3.65304 8.33694 3.65304ZM8.2295 2.39857C8.2295 2.37007 8.24081 2.34274 8.26095 2.32258C8.28108 2.30242 8.3084 2.29107 8.33689 2.29104H8.984C9.0125 2.29106 9.03982 2.3024 9.05996 2.32257C9.0801 2.34273 9.0914 2.37007 9.09139 2.39857V3.04558C9.09139 3.07408 9.08008 3.10141 9.05995 3.12157C9.03981 3.14173 9.0125 3.15308 8.984 3.15312H8.33694C8.30844 3.15308 8.28113 3.14173 8.26099 3.12157C8.24086 3.10141 8.22955 3.07408 8.22955 3.04558V2.39857H8.2295ZM15.0113 3.09757V3.53257C15.0113 3.79169 15.2141 4.00235 15.469 4.01946V5.93191C15.469 6.06996 15.5808 6.1819 15.719 6.1819C15.8571 6.1819 15.9689 6.06996 15.9689 5.93191V4.01946C16.2238 4.00235 16.4266 3.79169 16.4266 3.53257V3.09757C16.4266 2.82733 16.2067 2.6074 15.9365 2.6074H15.5015C15.2312 2.6074 15.0113 2.82733 15.0113 3.09757ZM15.9269 3.10732L15.9364 3.52277L15.5112 3.53252L15.5014 3.10727L15.9269 3.10732ZM7.04464 17.8181C7.01181 17.8181 6.9793 17.8246 6.94897 17.8371C6.91864 17.8497 6.89108 17.8681 6.86786 17.8913C6.84465 17.9145 6.82623 17.9421 6.81367 17.9724C6.80111 18.0027 6.79465 18.0353 6.79466 18.0681V19.4586L5.79992 20.4534C5.75305 20.5002 5.7267 20.5638 5.7267 20.6301V22.1365H5.65325C5.31833 22.1365 5.04566 22.4089 5.04566 22.7438V23.3909C5.04566 23.7258 5.31833 23.9982 5.65325 23.9982H6.30036C6.63528 23.9982 6.90767 23.7258 6.90767 23.3909V22.7438C6.90767 22.4088 6.63523 22.1365 6.30036 22.1365H6.22662V20.7336L7.22136 19.7388C7.26823 19.692 7.29458 19.6284 7.29458 19.5621V18.0681C7.29459 18.0353 7.28813 18.0027 7.27558 17.9724C7.26302 17.9421 7.24461 17.9145 7.2214 17.8913C7.19819 17.8681 7.17064 17.8497 7.14031 17.8371C7.10998 17.8246 7.07747 17.8181 7.04464 17.8181ZM6.30036 22.6364C6.32883 22.6364 6.35613 22.6477 6.37627 22.6679C6.3964 22.688 6.40772 22.7153 6.40775 22.7438V23.3909C6.40772 23.4194 6.3964 23.4467 6.37627 23.4668C6.35613 23.4869 6.32883 23.4982 6.30036 23.4983H5.65325C5.62475 23.4983 5.59741 23.487 5.57723 23.4668C5.55705 23.4467 5.54566 23.4194 5.54558 23.3909V22.7438C5.54565 22.7153 5.55703 22.688 5.57721 22.6678C5.5974 22.6477 5.62474 22.6364 5.65325 22.6364H6.30036ZM10.5551 17.8181C10.5223 17.8181 10.4898 17.8246 10.4594 17.8371C10.4291 17.8497 10.4015 17.8681 10.3783 17.8913C10.3551 17.9145 10.3367 17.9421 10.3241 17.9724C10.3116 18.0027 10.3051 18.0353 10.3051 18.0681V19.4796L9.56258 20.4812C9.53076 20.5244 9.51357 20.5765 9.5135 20.6301V22.1365H9.44005C9.10512 22.1365 8.83273 22.4089 8.83273 22.7438V23.3909C8.83273 23.7258 9.10517 23.9982 9.44005 23.9982H10.0872C10.4221 23.9982 10.6945 23.7258 10.6945 23.3909V22.7438C10.6945 22.4089 10.422 22.1365 10.0872 22.1365H10.0134V20.7126L10.756 19.7111C10.7878 19.6679 10.805 19.6157 10.805 19.5621V18.0681C10.8051 18.0353 10.7986 18.0027 10.7861 17.9724C10.7735 17.9421 10.7551 17.9145 10.7319 17.8913C10.7087 17.8681 10.6811 17.8497 10.6508 17.8371C10.6204 17.8245 10.5879 17.8181 10.5551 17.8181ZM10.0872 22.6364C10.1156 22.6364 10.1429 22.6477 10.1631 22.6679C10.1832 22.688 10.1945 22.7153 10.1945 22.7438V23.3909C10.1945 23.4194 10.1832 23.4467 10.1631 23.4668C10.1429 23.4869 10.1156 23.4982 10.0872 23.4983H9.44005C9.41157 23.4982 9.38427 23.4869 9.36414 23.4668C9.344 23.4467 9.33268 23.4194 9.33266 23.3909V22.7438C9.33268 22.7153 9.344 22.688 9.36414 22.6679C9.38427 22.6477 9.41157 22.6364 9.44005 22.6364H10.0872ZM11.7144 17.8181C11.7472 17.8181 11.7797 17.8246 11.81 17.8371C11.8404 17.8497 11.8679 17.8681 11.8912 17.8913C11.9144 17.9145 11.9328 17.9421 11.9453 17.9724C11.9579 18.0027 11.9644 18.0353 11.9644 18.0681V19.528C11.9644 19.666 11.8526 19.7779 11.7144 19.7779C11.5762 19.7779 11.4644 19.666 11.4644 19.528V18.0681C11.4644 18.0353 11.4708 18.0027 11.4834 17.9724C11.496 17.9421 11.5144 17.9145 11.5376 17.8913C11.5608 17.8681 11.5884 17.8497 11.6187 17.8371C11.649 17.8246 11.6815 17.8181 11.7144 17.8181ZM13.7241 17.8292C13.6913 17.8292 13.6588 17.8357 13.6284 17.8482C13.5981 17.8608 13.5705 17.8792 13.5473 17.9024C13.5241 17.9256 13.5057 17.9532 13.4931 17.9835C13.4806 18.0139 13.4741 18.0464 13.4741 18.0792V19.4987L12.5619 20.5763L12.547 20.5614C12.3244 20.3388 11.9626 20.3388 11.74 20.5614L11.3294 20.9719C11.107 21.1943 11.107 21.5563 11.3296 21.7789L11.7404 22.1892C11.9628 22.4116 12.3248 22.4118 12.5474 22.1892L12.958 21.7788C13.1804 21.5564 13.1804 21.1944 12.9578 20.9718L12.9168 20.9309L13.9149 19.7517C13.953 19.7066 13.974 19.6494 13.974 19.5903V18.0792C13.974 18.0464 13.9676 18.0139 13.955 17.9835C13.9425 17.9532 13.924 17.9256 13.9008 17.9024C13.8776 17.8792 13.8501 17.8608 13.8198 17.8482C13.7894 17.8357 13.7569 17.8292 13.7241 17.8292ZM12.6046 21.4253L12.194 21.8358C12.1875 21.8423 12.1797 21.8475 12.1711 21.8511C12.1625 21.8547 12.1533 21.8565 12.144 21.8565C12.1347 21.8565 12.1255 21.8546 12.1169 21.851C12.1083 21.8474 12.1005 21.8422 12.094 21.8356L11.6832 21.4253C11.6699 21.412 11.6624 21.3941 11.6624 21.3753C11.6623 21.3566 11.6697 21.3386 11.6829 21.3253L12.0935 20.9148C12.1001 20.9082 12.1079 20.903 12.1165 20.8995C12.1251 20.8959 12.1343 20.8941 12.1436 20.8941C12.1529 20.8941 12.1621 20.896 12.1707 20.8995C12.1792 20.9031 12.187 20.9083 12.1936 20.9149L12.6044 21.3253C12.6177 21.3385 12.6251 21.3565 12.6252 21.3752C12.6252 21.394 12.6178 21.412 12.6046 21.4253ZM18.3472 22.1365H18.2737V20.6301C18.2737 20.5638 18.2474 20.5002 18.2005 20.4534L17.2058 19.4586V18.0681C17.2058 17.93 17.094 17.8181 16.9558 17.8181C16.8176 17.8181 16.7058 17.93 16.7058 18.0681V19.5621C16.7058 19.6284 16.7322 19.692 16.779 19.7388L17.7738 20.7336V22.1365H17.7C17.3651 22.1365 17.0927 22.4089 17.0927 22.7438V23.3909C17.0927 23.7258 17.3652 23.9982 17.7 23.9982H18.3471C18.6821 23.9982 18.9545 23.7258 18.9545 23.3909V22.7438C18.9545 22.4089 18.6821 22.1365 18.3472 22.1365ZM18.4546 23.3909C18.4546 23.4194 18.4433 23.4467 18.4231 23.4668C18.403 23.487 18.3757 23.4983 18.3472 23.4983H17.7001C17.6717 23.4983 17.6444 23.487 17.6242 23.4668C17.6041 23.4467 17.5928 23.4194 17.5927 23.3909V22.7438C17.5928 22.7153 17.6041 22.688 17.6242 22.6679C17.6444 22.6478 17.6717 22.6365 17.7001 22.6364H18.3472C18.3757 22.6365 18.403 22.6478 18.4231 22.6679C18.4433 22.688 18.4546 22.7153 18.4546 22.7438V23.3909ZM15.6635 20.3469H15.59V18.0681C15.59 17.93 15.4782 17.8181 15.34 17.8181C15.2018 17.8181 15.09 17.93 15.09 18.0681V20.3469H15.0163C14.6814 20.3469 14.409 20.6194 14.409 20.9544V21.6014C14.409 21.9363 14.6814 22.2088 15.0163 22.2088H15.6634C15.9983 22.2088 16.2707 21.9363 16.2707 21.6014V20.9544C16.2709 20.6194 15.9984 20.3469 15.6635 20.3469ZM15.7709 21.6014C15.7709 21.6299 15.7596 21.6572 15.7395 21.6774C15.7194 21.6975 15.692 21.7089 15.6635 21.7089H15.0164C14.9879 21.7089 14.9606 21.6975 14.9405 21.6774C14.9204 21.6572 14.909 21.6299 14.909 21.6014V20.9544C14.909 20.9259 14.9204 20.8985 14.9405 20.8784C14.9606 20.8582 14.9879 20.8469 15.0164 20.8468H15.6635C15.692 20.8469 15.7194 20.8582 15.7395 20.8784C15.7596 20.8985 15.7709 20.9259 15.7709 20.9544V21.6014ZM8.98916 20.9024V20.4674C8.98916 20.2083 8.78633 19.9976 8.53147 19.9805V18.0681C8.53147 17.93 8.41967 17.8181 8.28148 17.8181C8.1433 17.8181 8.0315 17.93 8.0315 18.0681V19.9805C7.77664 19.9976 7.57381 20.2083 7.57381 20.4674V20.9024C7.57381 21.1726 7.79375 21.3926 8.06398 21.3926H8.49898C8.76922 21.3926 8.98916 21.1726 8.98916 20.9024ZM8.07355 20.8926L8.06403 20.4772L8.48928 20.4674L8.49903 20.8927H8.07355V20.8926ZM18.0684 15.9686H19.9808C19.9979 16.2235 20.2086 16.4263 20.4677 16.4263H20.9025C21.1727 16.4263 21.3927 16.2064 21.3927 15.9362V15.5013C21.3927 15.2311 21.1727 15.0111 20.9025 15.0111H20.4677C20.2086 15.0111 19.998 15.2139 19.9808 15.4687H18.0684C18.0356 15.4687 18.003 15.4752 17.9727 15.4878C17.9424 15.5003 17.9148 15.5187 17.8916 15.542C17.8448 15.5888 17.8184 15.6524 17.8184 15.7187C17.8184 15.785 17.8448 15.8486 17.8917 15.8955C17.9385 15.9423 18.0021 15.9687 18.0684 15.9686ZM20.8927 15.5013V15.9266L20.4775 15.9362L20.4678 15.5111L20.8927 15.5013ZM19.5282 12.0359C19.6663 12.0359 19.7782 12.1478 19.7782 12.2859C19.7782 12.4239 19.6664 12.5359 19.5282 12.5359H18.0685C17.9303 12.5359 17.8185 12.4239 17.8185 12.2859C17.8185 12.1478 17.9303 12.0359 18.0685 12.0359H19.5282ZM23.3912 5.04555H22.7441C22.4091 5.04555 22.1368 5.31799 22.1368 5.65287V5.72646H20.6304C20.564 5.72646 20.5005 5.7528 20.4537 5.79968L19.4589 6.79441H18.0685C17.9303 6.79441 17.8185 6.90635 17.8185 7.0444C17.8185 7.18244 17.9303 7.29438 18.0685 7.29438H19.5624C19.6288 7.29438 19.6923 7.26804 19.7391 7.22116L20.7339 6.22643H22.1368V6.30002C22.1368 6.63494 22.4092 6.90733 22.7441 6.90733H23.3912C23.7261 6.90733 23.9985 6.6349 23.9985 6.30002V5.65291C23.9985 5.31794 23.7261 5.04555 23.3912 5.04555ZM23.4986 6.29997C23.4985 6.32845 23.4872 6.35575 23.4671 6.37588C23.4469 6.39602 23.4196 6.40734 23.3912 6.40736H22.7441C22.7156 6.40734 22.6883 6.39602 22.6682 6.37588C22.648 6.35575 22.6367 6.32845 22.6367 6.29997V5.65287C22.6367 5.62439 22.648 5.59709 22.6682 5.57696C22.6883 5.55682 22.7156 5.5455 22.7441 5.54547H23.3912C23.4196 5.5455 23.4469 5.55682 23.4671 5.57696C23.4872 5.59709 23.4985 5.62439 23.4986 5.65287V6.29997ZM21.6016 7.72933H20.9545C20.6196 7.72933 20.3472 8.00177 20.3472 8.33665V8.41024H18.0685C17.9303 8.41024 17.8185 8.52218 17.8185 8.66022C17.8185 8.79827 17.9303 8.91021 18.0685 8.91021H20.3472V8.9838C20.3472 9.31872 20.6196 9.59111 20.9545 9.59111H21.6016C21.9365 9.59111 22.2089 9.31868 22.2089 8.9838V8.33669C22.2089 8.00177 21.9365 7.72933 21.6016 7.72933ZM21.709 8.9838C21.709 9.01228 21.6977 9.03958 21.6775 9.05971C21.6574 9.07985 21.6301 9.09117 21.6016 9.09119H20.9545C20.926 9.09117 20.8987 9.07985 20.8786 9.05971C20.8585 9.03958 20.8472 9.01228 20.8471 8.9838V8.33669C20.8472 8.30822 20.8585 8.28092 20.8786 8.26078C20.8987 8.24065 20.926 8.22933 20.9545 8.2293H21.6016C21.6301 8.22933 21.6574 8.24065 21.6775 8.26078C21.6977 8.28092 21.709 8.30822 21.709 8.33669V8.9838ZM23.3912 13.3057H22.7441C22.4091 13.3057 22.1368 13.5781 22.1368 13.913V13.9866H20.7129L19.7113 13.2443C19.6682 13.2123 19.616 13.1951 19.5624 13.1951H18.0685C17.9303 13.1951 17.8185 13.307 17.8185 13.4451C17.8185 13.5831 17.9303 13.6951 18.0685 13.6951H19.4799L20.4815 14.4374C20.5245 14.4693 20.5767 14.4866 20.6304 14.4866H22.1368V14.5601C22.1368 14.8951 22.4092 15.1675 22.7441 15.1675H23.3912C23.7261 15.1675 23.9985 14.895 23.9985 14.5601V13.913C23.9985 13.5781 23.7261 13.3057 23.3912 13.3057ZM23.4986 14.5601C23.4985 14.5886 23.4872 14.6159 23.4671 14.6361C23.4469 14.6562 23.4196 14.6675 23.3912 14.6675H22.7441C22.7156 14.6675 22.6883 14.6562 22.6682 14.6361C22.648 14.6159 22.6367 14.5886 22.6367 14.5601V13.913C22.6367 13.8846 22.648 13.8573 22.6682 13.8371C22.6883 13.817 22.7156 13.8057 22.7441 13.8056H23.3912C23.4196 13.8057 23.4469 13.817 23.4671 13.8371C23.4872 13.8573 23.4985 13.8846 23.4986 13.913V14.5601ZM23.3912 17.0926H22.7441C22.4091 17.0926 22.1368 17.3651 22.1368 17.6999V17.7735H20.7339L19.7391 16.7788C19.6923 16.7319 19.6288 16.7056 19.5624 16.7056H18.0685C17.9303 16.7056 17.8185 16.8175 17.8185 16.9556C17.8185 17.0936 17.9303 17.2055 18.0685 17.2055H19.4589L20.4537 18.2003C20.5005 18.2471 20.564 18.2735 20.6304 18.2735H22.1368V18.3471C22.1368 18.682 22.4092 18.9544 22.7441 18.9544H23.3912C23.7261 18.9544 23.9985 18.682 23.9985 18.3471V17.7C23.9985 17.3651 23.7261 17.0926 23.3912 17.0926ZM23.4986 18.3471C23.4985 18.3756 23.4872 18.4029 23.4671 18.423C23.4469 18.4431 23.4196 18.4545 23.3912 18.4545H22.7441C22.7156 18.4545 22.6883 18.4431 22.6682 18.423C22.648 18.4029 22.6367 18.3756 22.6367 18.3471V17.7C22.6367 17.6715 22.648 17.6442 22.6682 17.6241C22.6883 17.6039 22.7156 17.5926 22.7441 17.5926H23.3912C23.4196 17.5926 23.4469 17.6039 23.4671 17.6241C23.4872 17.6442 23.4985 17.6715 23.4986 17.7V18.3471ZM21.7789 12.6705L22.1894 12.2597C22.412 12.0372 22.412 11.6752 22.1894 11.4527L21.7789 11.0422C21.5567 10.8197 21.1947 10.8198 20.9721 11.0424L20.9312 11.0833L19.752 10.0852C19.7069 10.047 19.6496 10.026 19.5905 10.026H18.0794C17.9412 10.026 17.8295 10.138 17.8295 10.276C17.8295 10.4141 17.9412 10.526 18.0794 10.526H19.4989L20.5766 11.4383L20.5615 11.4534C20.3388 11.6757 20.3379 12.0367 20.5615 12.2603L20.972 12.6709V12.671C21.1952 12.8935 21.5572 12.8927 21.7789 12.6705ZM20.915 11.9066C20.9084 11.9 20.9031 11.8923 20.8996 11.8837C20.896 11.8751 20.8942 11.8659 20.8942 11.8566C20.8942 11.8473 20.896 11.8381 20.8996 11.8295C20.9031 11.821 20.9084 11.8132 20.915 11.8066L21.3255 11.3958C21.3388 11.3826 21.3567 11.3752 21.3754 11.3751C21.3941 11.3751 21.4121 11.3825 21.4254 11.3957L21.836 11.8061C21.8492 11.8194 21.8566 11.8374 21.8566 11.8562C21.8566 11.8749 21.8492 11.8929 21.836 11.9062L21.4254 12.3172C21.4121 12.3303 21.3942 12.3377 21.3755 12.3377C21.3568 12.3378 21.3389 12.3304 21.3255 12.3173L20.915 11.9066ZM6.18195 16.9556C6.18196 16.9227 6.1755 16.8902 6.16294 16.8599C6.15038 16.8295 6.13196 16.802 6.10875 16.7788C6.08553 16.7556 6.05797 16.7371 6.02764 16.7246C5.99731 16.712 5.9648 16.7056 5.93197 16.7056H4.43806C4.37169 16.7056 4.30822 16.7319 4.26134 16.7788L3.26661 17.7736H1.86373V17.7C1.86373 17.3651 1.5913 17.0925 1.25642 17.0925H0.609266C0.274344 17.0925 0.00195312 17.3651 0.00195312 17.7V18.3471C0.00195312 18.682 0.274391 18.9544 0.609266 18.9544H1.25637C1.5913 18.9544 1.86369 18.682 1.86369 18.3471V18.2735H3.37006C3.43644 18.2735 3.49991 18.2471 3.54678 18.2003L4.54152 17.2055H5.93192C5.96476 17.2055 5.99727 17.1991 6.02761 17.1865C6.05795 17.174 6.08551 17.1556 6.10873 17.1324C6.13195 17.1091 6.15037 17.0816 6.16293 17.0512C6.1755 17.0209 6.18196 16.9884 6.18195 16.9556ZM1.36381 18.3471C1.36379 18.3756 1.35247 18.4029 1.33233 18.423C1.3122 18.4431 1.2849 18.4545 1.25642 18.4545H0.609266C0.580791 18.4545 0.553491 18.4431 0.533356 18.423C0.513222 18.4029 0.5019 18.3756 0.501875 18.3471V17.7C0.501875 17.6715 0.513185 17.6441 0.53332 17.624C0.553456 17.6038 0.580771 17.5925 0.609266 17.5924H1.25637C1.28487 17.5925 1.31218 17.6038 1.33232 17.624C1.35246 17.6441 1.36377 17.6715 1.36377 17.7L1.36381 18.3471ZM5.93202 8.0313H4.01956C4.00245 7.77644 3.7918 7.57362 3.53267 7.57362H3.09791C2.82767 7.57362 2.60773 7.79355 2.60773 8.06379V8.49865C2.60773 8.76888 2.82767 8.98882 3.09791 8.98882H3.53267C3.79175 8.98882 4.00241 8.78604 4.01956 8.53122H5.93202C5.99831 8.53122 6.06189 8.50489 6.10876 8.45801C6.15564 8.41114 6.18198 8.34756 6.18198 8.28126C6.18198 8.21497 6.15564 8.15139 6.10876 8.10451C6.06189 8.05764 5.99831 8.0313 5.93202 8.0313ZM3.1077 8.49865V8.0733L3.52292 8.06379L3.53267 8.4889L3.1077 8.49865ZM6.18195 11.7141C6.18196 11.747 6.1755 11.7795 6.16294 11.8098C6.15038 11.8401 6.13196 11.8677 6.10875 11.8909C6.08553 11.9141 6.05797 11.9325 6.02764 11.9451C5.99731 11.9577 5.9648 11.9641 5.93197 11.9641H4.47223C4.33409 11.9641 4.22225 11.8522 4.22225 11.7141C4.22225 11.5761 4.33405 11.4641 4.47223 11.4641H5.93197C5.9648 11.4641 5.99731 11.4706 6.02764 11.4832C6.05797 11.4957 6.08553 11.5141 6.10875 11.5374C6.13196 11.5606 6.15038 11.5881 6.16294 11.6185C6.1755 11.6488 6.18196 11.6813 6.18195 11.7141ZM2.39881 16.2706H3.04592C3.38084 16.2706 3.65323 15.9982 3.65323 15.6633V15.5897H5.93197C6.07011 15.5897 6.18195 15.4778 6.18195 15.3397C6.18195 15.2017 6.07016 15.0897 5.93197 15.0897H3.65328V15.0161C3.65328 14.6812 3.38084 14.4088 3.04597 14.4088H2.39881C2.06389 14.4088 1.7915 14.6813 1.7915 15.0161V15.6633C1.7915 15.9982 2.06389 16.2706 2.39881 16.2706ZM2.29142 15.0161C2.29145 14.9877 2.30277 14.9604 2.3229 14.9402C2.34304 14.9201 2.37034 14.9088 2.39881 14.9088H3.04592C3.0744 14.9088 3.1017 14.9201 3.12183 14.9402C3.14197 14.9604 3.15329 14.9877 3.15331 15.0161V15.6633C3.15329 15.6917 3.14197 15.719 3.12183 15.7392C3.1017 15.7593 3.0744 15.7706 3.04592 15.7706H2.39881C2.37034 15.7706 2.34304 15.7593 2.3229 15.7392C2.30277 15.719 2.29145 15.6917 2.29142 15.6633V15.0161ZM0.609266 10.6943H1.25637C1.5913 10.6943 1.86369 10.4218 1.86369 10.087V10.0134H3.28756L4.28914 10.7557C4.33222 10.7876 4.38443 10.8049 4.43806 10.8048H5.93197C6.07011 10.8048 6.18195 10.6929 6.18195 10.5549C6.18195 10.4168 6.07016 10.3049 5.93197 10.3049H4.52056L3.51898 9.56257C3.4759 9.53062 3.42369 9.51338 3.37006 9.5134H1.86373V9.4398C1.86373 9.10488 1.5913 8.83249 1.25642 8.83249H0.609266C0.274344 8.83249 0.00195312 9.10493 0.00195312 9.4398V10.0869C0.00195312 10.4218 0.274344 10.6943 0.609266 10.6943ZM0.501875 9.4398C0.5019 9.41133 0.513222 9.38403 0.533356 9.36389C0.553491 9.34376 0.580791 9.33244 0.609266 9.33241H1.25637C1.28485 9.33244 1.31215 9.34376 1.33228 9.36389C1.35242 9.38403 1.36374 9.41133 1.36377 9.4398V10.0869C1.36374 10.1154 1.35242 10.1427 1.33228 10.1628C1.31215 10.183 1.28485 10.1943 1.25637 10.1943H0.609266C0.580791 10.1943 0.553491 10.183 0.533356 10.1628C0.513222 10.1427 0.5019 10.1154 0.501875 10.0869V9.4398ZM0.609266 6.90733H1.25637C1.5913 6.90733 1.86369 6.6349 1.86369 6.30002V6.22643H3.26656L4.2613 7.22116C4.30817 7.26804 4.37164 7.29438 4.43802 7.29438H5.93192C6.07006 7.29438 6.18191 7.18244 6.18191 7.0444C6.18191 6.90635 6.07011 6.79441 5.93192 6.79441H4.54156L3.54683 5.79968C3.49995 5.7528 3.43648 5.72646 3.37011 5.72646H1.86373V5.65287C1.86373 5.31794 1.5913 5.04555 1.25642 5.04555H0.609266C0.274344 5.04555 0.00195312 5.31799 0.00195312 5.65287V6.29997C0.00195312 6.6349 0.274344 6.90733 0.609266 6.90733ZM0.501875 5.65287C0.5019 5.62439 0.513222 5.59709 0.533356 5.57696C0.553491 5.55682 0.580791 5.5455 0.609266 5.54547H1.25637C1.28485 5.5455 1.31215 5.55682 1.33228 5.57696C1.35242 5.59709 1.36374 5.62439 1.36377 5.65287V6.29997C1.36374 6.32845 1.35242 6.35575 1.33228 6.37588C1.31215 6.39602 1.28485 6.40734 1.25637 6.40736H0.609266C0.580791 6.40734 0.553491 6.39602 0.533356 6.37588C0.513222 6.35575 0.5019 6.32845 0.501875 6.29997V5.65287ZM2.22158 11.3294L1.811 11.7402C1.58839 11.9628 1.58839 12.3248 1.811 12.5472L2.22158 12.9577C2.44222 13.1786 2.80447 13.1815 3.02834 12.9576L3.06927 12.9167L4.24841 13.9147C4.29358 13.9529 4.35082 13.9739 4.40998 13.9739H5.921C6.05914 13.9739 6.17098 13.862 6.17098 13.7239C6.17098 13.5859 6.05919 13.474 5.921 13.474H4.50153L3.42387 12.5617L3.43897 12.5466C3.66162 12.3242 3.66256 11.9633 3.43897 11.7397L3.02834 11.3292V11.3291C2.80573 11.1068 2.44372 11.1069 2.22158 11.3294ZM3.08548 12.0934C3.09207 12.0999 3.0973 12.1077 3.10087 12.1163C3.10444 12.1249 3.10628 12.1341 3.10628 12.1433C3.10628 12.1526 3.10444 12.1618 3.10087 12.1704C3.0973 12.179 3.09207 12.1868 3.08548 12.1933L2.67491 12.6041C2.66166 12.6174 2.64372 12.6248 2.62501 12.6248C2.60631 12.6248 2.58835 12.6175 2.57506 12.6043L2.16448 12.1938C2.15125 12.1805 2.14382 12.1625 2.14382 12.1438C2.14382 12.125 2.15125 12.107 2.16448 12.0937L2.57506 11.6828C2.58832 11.6696 2.60625 11.6622 2.62496 11.6621C2.64366 11.6621 2.66161 11.6695 2.67491 11.6826L3.08548 12.0934Z" fill="url(#paint0_linear_29_19228_4)"></path><defs><linearGradient id="paint0_linear_29_19228_4" x1="12" y1="0" x2="12" y2="24" gradientUnits="userSpaceOnUse"><stop class="act-cat-svg-stop-col-1"></stop><stop class="act-cat-svg-stop-col-2" offset="1"></stop></linearGradient></defs>
                                                    </svg>
                                                <?php } ?>
                                            </div>
                                        </div>
                                </button>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </section>
    <?php
    $args = [
            'post_type'      => 'product',
            'posts_per_page' => -1,
            'tax_query' => [
                    [
                            'taxonomy' => 'product_cat',
                            'field'    => 'slug',
                            'terms'    => 'playstation-giftcard',
                    ]
            ],
            'meta_query' => [
                    'relation' => 'OR',
                    [
                            'key'     => 'giftmax_setting_order',
                            'compare' => 'EXISTS',
                            'type'    => 'NUMERIC',
                    ],

                    [
                            'key'     => 'giftmax_setting_order',
                            'compare' => 'NOT EXISTS',
                    ],
            ],

            'orderby' => [
                    'meta_value_num' => 'ASC',
                    'date'           => 'DESC',
            ],
            'order'          => 'ASE',
    ];
    $region_args = [
            'post_type'      => 'product',
            'posts_per_page' => -1,
            'fields'         => 'ids',
            'tax_query' => [
                    [
                            'taxonomy' => 'product_cat',
                            'field'    => 'slug',
                            'terms'    => 'playstation-giftcard',
                    ]
            ],
            'orderby'        => 'date',
            'order'          => 'DESC',
            'meta_query' => [
                    [
                            'key'     => 'giftmax_box_setting',
                            'compare' => 'EXISTS'
                    ]
            ]
    ];

    $region_query = new \WP_Query($region_args);

    $regions = [];

    foreach ($region_query->posts as $pid) {
        $settings = get_post_meta($pid, 'giftmax_box_setting', true);
        if (!empty($settings[0]['logo_region'])) {
            $regions[] = $settings[0]['logo_region'];
        }
    }

    $regions = array_unique($regions);
    $query = new \WP_Query($args);
    if($query->have_posts()){
        ?>
        <section class="container-xl-w mx-auto mt-18">
            <div class="act-new-service-carousel-1st" id="LoadCategory">
                <div class="act-new-service-carousel-head d-flex align-items-center justify-content-between">
                    <svg xmlns="http://www.w3.org/2000/svg" width="1281" height="75" viewBox="0 0 1281 75" fill="none" class="act-new-service-carousel-head-svg">
                        <path d="M1280.47 0.5H1000.91C986.771 0.5 979.703 0.5 973.764 2.99163C969.027 4.9789 964.838 8.07733 961.551 12.025C957.43 16.9747 955.361 23.7331 951.224 37.25C947.086 50.7669 945.017 57.5253 940.896 62.475C937.609 66.4227 933.42 69.5211 928.683 71.5084C922.744 74 915.676 74 901.54 74H412.882C399.847 74 393.329 74 387.813 71.8926C382.12 69.7177 377.167 65.9625 373.536 61.0686C370.017 56.3267 368.257 50.0512 364.737 37.5C361.217 24.9488 359.457 18.6733 355.938 13.9314C352.307 9.0375 347.353 5.2823 341.661 3.10737C336.145 1 329.627 1 316.592 1H0" stroke="url(#paint0_linear_29_20094)"></path>
                        <defs>
                            <linearGradient id="paint0_linear_29_20094" x1="29.4736" y1="0.500002" x2="1213.79" y2="-28.0511" gradientUnits="userSpaceOnUse">
                                <stop stop-color="#0B61FF" stop-opacity="0"></stop>
                                <stop offset="0.5" stop-color="#0B61FF"></stop>
                                <stop offset="1" stop-color="#0B61FF" stop-opacity="0"></stop>
                            </linearGradient>
                        </defs>
                    </svg>
                    <div class="act-our-services-carousel-head-title">
                        <div class="act-our-services-carousel-head-title-divs">
                            <div class="act-our-services-carousel-head-title-div1"></div>
                            <div class="act-our-services-carousel-head-title-div2"></div>
                        </div>
                        <div class="act-our-services-carousel-head-title-content">
                            <h5></h5>
                            <h5>گیفت کارت <strong>پلی استیشن </strong></h5>
                            <p>GIFT CARD PLAYSTATION </p>
                        </div>
                    </div>
                    <div class="act-new-service-carousel-head-content">

                        <a class="act-link-but" href="<?=home_url('/shop')?>" rel="nofollow">
                            مشاهده بیشتر                    <svg xmlns="http://www.w3.org/2000/svg" width="34" height="34" viewBox="0 0 34 34" fill="currentcolor">
                                <path d="M20.0744 10.4295C20.2088 10.5639 20.2936 10.7477 20.2936 10.9599C20.2936 11.37 19.9542 11.7094 19.5441 11.7094L11.7094 11.7094L11.7094 19.5442C11.7094 19.9543 11.3699 20.2937 10.9598 20.2937C10.5497 20.2937 10.2103 19.9543 10.2103 19.5442L10.2103 10.9599C10.2103 10.5498 10.5497 10.2103 10.9598 10.2103L19.5441 10.2103C19.7562 10.2103 19.9401 10.2952 20.0744 10.4295Z"></path>
                                <path d="M11.611 10.5501L23.5116 22.4507C23.8015 22.7406 23.8015 23.2215 23.5116 23.5114C23.2217 23.8013 22.7409 23.8013 22.451 23.5114L10.5504 11.6108C10.2605 11.3209 10.2605 10.84 10.5504 10.5501C10.8403 10.2602 11.3211 10.2602 11.611 10.5501Z"></path>
                            </svg>

                        </a>
                    </div>
                </div>
                <div class="w-full">
                    <?php
                    if (!isMobile()){?>
                        <div class="flex overflow-hidden mb-20">
                            <div class="flex justify-between lg:w-20 md:w-11">
                                <div class="act-our-services-carousel-head-title">
                                    <div class="act-our-services-carousel-head-title-divs">
                                        <div class="act-our-services-carousel-head-title-div1 tsc54b"></div>
                                    </div>
                                    <div class="act-our-services-carousel-head-title-content">
                                        <h5>انتخاب <strong>کشور</strong> </h5>
                                        <p class="tsc54">SELECT REGION</p>
                                    </div>
                                </div>
                            </div>
                            <div class="swiper c-box__ceWU4d">
                                <div class="swiper-wrapper">
                                    <div data-id="" class="act-catagory-card swiper-slide pointer button-cc45 active" style="width: 75px !important;">
                                        <div class="act-catagory-card-inner">
                                            <div class="act-catagory-card-name">
                                                <div class="act-our-services-carousel-head-title-divs">
                                                    <div class="act-our-services-carousel-head-title-div1" style="height: 15px;  margin-bottom: 4px;"></div>
                                                    <div class="act-our-services-carousel-head-title-div2" style=" height: 12px;"></div>
                                                </div>
                                                <div class="act-catagory-name-text">
                                                    <strong>همه</strong>
                                                    <p>All</p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <?php
                                    foreach ($regions as $region){
                                        ?>
                                        <div data-id="<?=$region?>" class="act-catagory-card swiper-slide pointer button-cc45">
                                            <div class="act-catagory-card-inner">
                                                <div class="act-catagory-card-name">
                                                    <div class="act-our-services-carousel-head-title-divs">
                                                        <div class="act-our-services-carousel-head-title-div1" style="height: 15px;  margin-bottom: 4px;"></div>
                                                        <div class="act-our-services-carousel-head-title-div2" style=" height: 12px;"></div>
                                                    </div>
                                                    <div class="act-catagory-name-text">
                                                        <strong><?=regionPersian($region) ?></strong>
                                                        <p><?=$region?></p>
                                                    </div>
                                                </div>
                                                <div class="act-catagory-card-img">
                                                    <img src="<?=get_template_directory_uri() . '/assets/flag/' .$region . '.svg'?>">
                                                </div>
                                            </div>
                                        </div>
                                        <?php
                                    }
                                    ?>
                                </div>
                                <div class="swiper-navigation-region w-full absolute">
                                    <div class="swiper-button-region swiper-button-prev-region">
                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                                            <path d="M13.583 12l-4.293 4.293 1.414 1.414 5-5c0.39-0.391 0.39-1.024 0-1.414l-5-5-1.414 1.414 4.293 4.293z"></path>
                                        </svg>
                                    </div>
                                    <div class="swiper-button-region swiper-button-next-region">
                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                                            <path d="M10.414 12l4.293 4.293-1.414 1.414-5-5c-0.391-0.391-0.391-1.024 0-1.414l5-5 1.414 1.414-4.293 4.293z"></path>
                                        </svg>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php }else{?>
                        <div class="flex flex-col overflow-hidden mb-20">
                            <div class="flex justify-between mb-20">
                                <div class="act-our-services-carousel-head-title">
                                    <div class="act-our-services-carousel-head-title-divs"></div>
                                    <div class="act-our-services-carousel-head-title-content">
                                        <h5>انتخاب <strong>کشور</strong> </h5>
                                        <p class="tsc54">SELECT REGION</p>
                                    </div>
                                </div>
                                <div class="swiper-navigation-region gap-2">
                                    <div class="swiper-button-region swiper-button-prev-region">
                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                                            <path d="M13.583 12l-4.293 4.293 1.414 1.414 5-5c0.39-0.391 0.39-1.024 0-1.414l-5-5-1.414 1.414 4.293 4.293z"></path>
                                        </svg>
                                    </div>
                                    <div class="swiper-button-region swiper-button-next-region">
                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                                            <path d="M10.414 12l4.293 4.293-1.414 1.414-5-5c-0.391-0.391-0.391-1.024 0-1.414l5-5 1.414 1.414-4.293 4.293z"></path>
                                        </svg>
                                    </div>
                                </div>

                            </div>
                            <div class="swiper c-box__ceWU4d">
                                <div class="swiper-wrapper">
                                    <div data-id="" class="act-catagory-card swiper-slide pointer button-cc45 active" style="width: 75px !important;">
                                        <div class="act-catagory-card-inner">
                                            <div class="act-catagory-card-name">
                                                <div class="act-our-services-carousel-head-title-divs">
                                                    <div class="act-our-services-carousel-head-title-div1" style="height: 15px;  margin-bottom: 4px;"></div>
                                                    <div class="act-our-services-carousel-head-title-div2" style=" height: 12px;"></div>
                                                </div>
                                                <div class="act-catagory-name-text">
                                                    <strong>همه</strong>
                                                    <p>All</p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <?php
                                    foreach ($regions as $region){
                                        ?>
                                        <div data-id="<?=$region?>" class="act-catagory-card swiper-slide pointer button-cc45">
                                            <div class="act-catagory-card-inner">
                                                <div class="act-catagory-card-name">
                                                    <div class="act-our-services-carousel-head-title-divs">
                                                        <div class="act-our-services-carousel-head-title-div1" style="height: 15px;  margin-bottom: 4px;"></div>
                                                        <div class="act-our-services-carousel-head-title-div2" style=" height: 12px;"></div>
                                                    </div>
                                                    <div class="act-catagory-name-text">
                                                        <strong><?=regionPersian($region) ?></strong>
                                                        <p><?=$region?></p>
                                                    </div>
                                                </div>
                                                <div class="act-catagory-card-img">
                                                    <img src="<?=get_template_directory_uri() . '/assets/flag/' .$region . '.svg'?>">
                                                </div>
                                            </div>
                                        </div>
                                        <?php
                                    }
                                    ?>
                                </div>
                            </div>
                        </div>
                    <?php }
                    ?>
                    <div class="flex fhDGSJDF justify-start">
                        <?php
                        while ($query->have_posts()) : $query->the_post(); global $product;
                            $regular = $product->get_regular_price();
                            $sale    = $product->get_sale_price();
                            $final_price = $product->is_on_sale() && $sale > 0 ? $sale : $regular;
                            $img = get_the_post_thumbnail_url(get_the_ID(), 'product_discount');
                            $settings = get_post_meta($product->get_id(), 'giftmax_box_setting', true);
                            $delivery = get_post_meta($product->get_id(), 'delivery', true);
                            $matched_coupon_code = '';

                            if (!empty($home_coupon_objects)) {
                                foreach ($home_coupon_objects as $home_coupon_obj) {
                                    $expires_at = $home_coupon_obj->get_date_expires();

                                    if ($expires_at && $expires_at->getTimestamp() < current_time('timestamp')) {
                                        continue;
                                    }

                                    if ($home_coupon_obj->is_valid_for_product($product)) {
                                        $matched_coupon_code = $home_coupon_obj->get_code();
                                        break;
                                    }
                                }
                            }
                            ?>
                            <div>
                                <div class="act-new-service-card <?=!empty($matched_coupon_code) ? 'has-discount' : ''?>">
                                    <?php if (!empty($matched_coupon_code) && !isMobile()) { ?>
                                        <div class="act-new-service-card-discount Button-sc91" data-product-id="<?=esc_attr($product->get_id())?>">
                                            <div class="anScr"></div>
                                            <div class="anSct">مشاهده کد تخفیف</div>
                                            <div class="anScl"></div>
                                        </div>
                                    <?php } ?>
                                    <div class="act-new-service-card-inner">
                                        <div <?=isset($delivery['two']) && $delivery['two'] == 'on' || product_available($product->get_id()) ?'':'class="NdhJD5"'?>>
                                            <div class="act-new-service-card-inner-top">
                                                <a href="<?=get_permalink()?>">
                                                    <div class="act-new-service-card-inner-top-img-box relative">
                                                        <img src="<?=$img?>" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="<?=get_the_title()?>">
                                                        <?php
                                                        if (!empty($settings[0]['logo_region'])){
                                                            ?>
                                                            <div class="logo_region">
                                                                <img src="<?=empty($settings[0]['logo_region']) ?: get_template_directory_uri() . '/assets/flag/' . $settings[0]['logo_region'] . '.svg'?>">
                                                            </div>
                                                            <?php
                                                        }
                                                        $date_from = $product->get_date_on_sale_from();
                                                        $date_to   = $product->get_date_on_sale_to();
                                                        if ($product->is_on_sale() & ($date_from || $date_to)){
                                                            ?>
                                                            <div class="logo_detail" style="top: 7px;right: 7px;background-color: transparent;">
                                                                <img src="<?=get_template_directory_uri()?>/assets/img/svg/Amazings.svg">
                                                            </div>
                                                            <?php
                                                        } elseif ($product->is_on_sale()){
                                                            ?>
                                                            <div class="logo_detail" style="top: 7px;right: 7px;">
                                                                <img src="<?=get_template_directory_uri()?>/assets/img/svg/percent.svg">
                                                            </div>
                                                            <?php
                                                        }
                                                        ?>
                                                    </div>
                                                </a>
                                                <div class="act-new-service-card-inner-top-txt-box" <?=!empty($settings[0]['label']) && $settings[0]['label'] != '' ? 'style="gap:2px"' : ''?>>
                                                    <a href="<?=get_permalink()?>">
                                                        <h4 class="act-product-title"><?=get_the_title()?></h4>
                                                        <?php
                                                        if(!empty($settings[0]['sub_head']) && !isMobile()) echo "<p class='act-product-title-en'>" . $settings[0]['sub_head'] . "</p>";
                                                        ?>
                                                    </a>
                                                    <div class="flex justify-between">
                                                        <div class="flex">
                                                            <?php
                                                            $tooltip = isset($delivery['description']) ? $delivery['description'] : '';
                                                            ?>
                                                            <div class="act-product-option-box__nw <?=isset($delivery['two']) && $delivery['two'] == 'on' ? 'pre-sale wiki wiki__holder js-dk-wiki-trigger' : 'same-day'?>" <?=isset($delivery['two']) && $delivery['two'] == 'on' ? 'data-tooltip="'. $tooltip .'"' :''?>><?=isset($delivery['two']) && $delivery['two'] == 'on' ? 'پیش فروش' : 'تحویل آنی'?></div>
                                                            <div class="purchaseScore wiki wiki__holder js-dk-wiki-trigger" data-tooltip="با خرید این گیفت کارت <?=empty($settings[0]['purchaseScore']) ?0: $settings[0]['purchaseScore']?> امتیاز دریافت میکنید">
                                                                <i class="icon-star"></i>
                                                                <?=empty($settings[0]['purchaseScore']) ?0: $settings[0]['purchaseScore']?>
                                                            </div>
                                                        </div>
                                                        <?php
                                                        if($giftmax_is_user_logged_in){
                                                            $is_in_wishlist = in_array((int) $product->get_id(), $giftmax_wishlist_ids, true); ?>
                                                            <button class="add-to__favorites Button-alu84 <?=$is_in_wishlist ? 'is-active' : ''?>" data-product-id="<?=esc_attr($product->get_id())?>" data-auth="<?=$giftmax_is_user_logged_in ? '1' : '0'?>" style="width: 28px;height: 28px;border-radius: 7px">
                                                                <svg viewBox="0 0 24 24" style="width: 64%;">
                                                                    <path d="M12.62 20.81C12.28 20.93 11.72 20.93 11.38 20.81C8.48 19.82 2 15.69 2 8.68998C2 5.59998 4.49 3.09998 7.56 3.09998C9.38 3.09998 10.99 3.97998 12 5.33998C13.01 3.97998 14.63 3.09998 16.44 3.09998C19.51 3.09998 22 5.59998 22 8.68998C22 15.69 15.52 19.82 12.62 20.81Z" fill="<?=$is_in_wishlist ? '#ef4444' : 'none'?>" stroke="<?=$is_in_wishlist ? '#ef4444' : 'inherit'?>" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                                                                </svg>
                                                            </button>
                                                            <?php
                                                        }
                                                        ?>
                                                    </div>
                                                    <?php if (!empty($matched_coupon_code) && isMobile()) { ?>
                                                        <div class="act-new-service-card-discount Button-sc91" data-product-id="<?=esc_attr($product->get_id())?>">
                                                            مشاهده کد تخفیف
                                                        </div>
                                                    <?php }else{ ?>
                                                        <p class="act-product-txt"><?=empty($settings[0]['description_short']) ?'': $settings[0]['description_short']?></p>
                                                        <?php
                                                    }
                                                    ?>
                                                    <?php
                                                    if (!empty($settings[0]['label']) && $settings[0]['label'] != ''){?>
                                                        <div class="label-fjd84">
                                                            <img src="<?=empty($settings[0]['label']) ?'': $settings[0]['label']?>" class="logo_label">
                                                            <p class="label_title"><?=empty($settings[0]['label_title']) ?'': $settings[0]['label_title']?></p>
                                                        </div>
                                                        <?php
                                                    }
                                                    ?>

                                                </div>
                                            </div>
                                        </div>
                                        <?php
                                        $date_from = $product->get_date_on_sale_from();
                                        $date_to   = $product->get_date_on_sale_to();
                                        if ($product->is_on_sale() & ($date_from || $date_to)) {
                                            $sale_from_ts = $date_from ? $date_from->getTimestamp() : null;
                                            $sale_to_ts   = $date_to ? $date_to->getTimestamp() : null;
                                            if ($sale_from_ts && $sale_to_ts) {
                                                $now_ts = time();
                                                $total_duration = $sale_to_ts - $sale_from_ts;
                                                $elapsed = $now_ts - $sale_from_ts;

                                                $progress_percent = max(0, min(100, ($elapsed / $total_duration) * 100));
                                            } else {
                                                $progress_percent = 0;
                                            }
                                        }else{
                                            $sale_to_ts = null;
                                        }
                                        if (!$sale_to_ts){
                                            ?>
                                            <div class="act-hor-bor"></div>
                                            <?php
                                        }else{
                                            ?>
                                            <div class="flex justify-between flex-col">
                                                <div class="relative bg-neutral-100 style_ProductPromotionTimeline__progress__JnKWE" style="">
                                                    <div class="absolute bg-primary-700 h-full left-0 top-0 style_ProductPromotionTimeline--active__oYyta" style="width: <?=$progress_percent?>%;"></div>
                                                </div>
                                                <span class="text-primary-700 text-body2-strong style_ProductPromotionTimeline__timer__zS6ZA1 text-left"><?= date('Y-m-d H:i:s', $sale_to_ts); ?></span>

                                            </div>
                                            <?php
                                        }
                                        ?>
                                        <div>
                                            <?php
                                            if(!empty($matched_coupon_code)){
                                                $usage_limit  = (int) $home_coupon_obj->get_usage_limit();
                                                $usage_count  = (int) $home_coupon_obj->get_usage_count();

                                                $remaining_uses = $usage_limit > 0
                                                        ? max( 0, $usage_limit - $usage_count )
                                                        : __( 'نامحدود', 'textdomain' );
                                                ?>
                                                <div class="">
                                                    <div class="relative bg-neutral-100 style_ProductPromotionTimeline__progress__JnKWE">
                                                        <div class="absolute bg-primary-700 h-full left-0 top-0 style_ProductPromotionTimeline--active__oYyta" style="width: <?=($home_coupon_obj->get_usage_count()/($home_coupon_obj->get_usage_count()+$remaining_uses))*100?>%;"></div>
                                                    </div>
                                                    <div class="whitespace-nowrap flex justify-between pt-1">
                                                        <div class=""><span class="text-primary-700 text-body-strong ml-1"><?=($home_coupon_obj->get_usage_count()/($home_coupon_obj->get_usage_count()+$remaining_uses))*100?>%</span><span class="text-neutral-500 text-caption">فروش رفته</span></div>
                                                        <?php
                                                        if ($home_coupon_obj->get_date_expires()){
                                                            ?>
                                                            <div class="text-primary-700 text-body2-strong style_ProductPromotionTimeline__timer__zS6ZA"><?= $home_coupon_obj->get_date_expires() ? $home_coupon_obj->get_date_expires()->date_i18n( 'Y-m-d H:i:s' ) : 'بدون تاریخ انقضا'?></div>
                                                            <?php
                                                        }else{?>
                                                            <div class="text-primary-700 text-body2-strong style_ProductPromotionTimeline__timer__zS6ZA"></div>
                                                        <?php }
                                                        ?>
                                                    </div>
                                                </div>
                                                <?php
                                            }
                                            ?>
                                            <div class="act-product-card-footer">
                                                <a href="<?=get_the_permalink()?>" class="act-special-carousel-card-buy-box-option">جزئیات</a>
                                                <div class="act-product-price-box">
                                                    <?php
                                                    if ( $product->is_on_sale() ) {?>
                                                        <div class="act-product-price-box-top">
                                                            <div class="act-product-price-off-price"><?=number_format_usd($regular)?></div>
                                                            <div class="act-product-price-off-percent">  <?=get_discount_percent($product)?> ٪       </div>


                                                        </div>
                                                        <?php
                                                    }
                                                    ?>
                                                    <div class="act-product-price<?=$product->is_on_sale() ? ' bpt' : ''?>">
                                                        <?php
                                                        if($final_price > 0){?>
                                                            <div id="priceValue" data-id="<?=$product->get_id()?>" data-target="<?=$product->is_on_sale() ? $sale :$regular?>"><?=number_format_usd($product->is_on_sale() ? $sale : $regular)?></div><span>تومان</span>
                                                            <?php
                                                        }else{
                                                            ?>
                                                            <div class="act-product-price-free">رایگان</div>
                                                            <?php
                                                        }
                                                        ?>
                                                    </div>
                                                </div>
                                            </div>
                                            <?php
                                            if (isset($delivery['two']) && $delivery['two'] == 'on' || product_available($product->get_id())){
                                                if (SiteModel::setting("buy") === true){
                                                    ?>
                                                    <button type="button" class="act-special-carousel-card-buy-box-but Button-aca48 pointer" data-product-id="<?=$product->get_id()?>">
                                                        <svg xmlns="http://www.w3.org/2000/svg" width="26" height="26" viewBox="0 0 26 26" fill="currentcolor">
                                                            <path d="M17.875 9.34916C17.4308 9.34916 17.0625 8.98083 17.0625 8.53666V7.04166C17.0625 5.90416 16.575 4.79916 15.73 4.03C14.8742 3.25 13.7692 2.8925 12.5992 3.00083C10.6492 3.185 8.9375 5.17833 8.9375 7.25833V8.30916C8.9375 8.75333 8.56917 9.12166 8.125 9.12166C7.68083 9.12166 7.3125 8.75333 7.3125 8.30916V7.2475C7.3125 4.33333 9.66333 1.64666 12.4475 1.37583C14.0725 1.22417 15.6325 1.73333 16.8242 2.8275C18.005 3.9 18.6875 5.43833 18.6875 7.04166V8.53666C18.6875 8.98083 18.3192 9.34916 17.875 9.34916Z"></path>
                                                            <path d="M16.2498 24.6457H9.7498C4.7448 24.6457 3.81314 22.3165 3.5748 20.0523L2.7623 13.5632C2.64314 12.3932 2.5998 10.714 3.7373 9.45734C4.7123 8.374 6.32647 7.854 8.66647 7.854H17.3331C19.684 7.854 21.2981 8.38484 22.2623 9.45734C23.389 10.714 23.3565 12.3932 23.2373 13.5415L22.4248 20.0523C22.1865 22.3165 21.2548 24.6457 16.2498 24.6457ZM8.66647 9.479C6.83564 9.479 5.57897 9.8365 4.9398 10.5515C4.40897 11.1365 4.23564 12.0357 4.37647 13.379L5.18897 19.8682C5.37314 21.6015 5.8498 23.0315 9.7498 23.0315H16.2498C20.1498 23.0315 20.6265 21.6123 20.8106 19.8898L21.6231 13.379C21.764 12.0573 21.5906 11.1582 21.0598 10.5623C20.4206 9.8365 19.164 9.479 17.3331 9.479H8.66647Z"></path>
                                                            <path d="M16.7045 14.2458C16.0979 14.2458 15.6104 13.7583 15.6104 13.1624C15.6104 12.5666 16.0979 12.0791 16.6937 12.0791C17.2895 12.0791 17.777 12.5666 17.777 13.1624C17.777 13.7583 17.3004 14.2458 16.7045 14.2458Z"></path>
                                                            <path d="M9.12151 14.2458C8.51484 14.2458 8.02734 13.7583 8.02734 13.1624C8.02734 12.5666 8.51484 12.0791 9.11068 12.0791C9.70651 12.0791 10.194 12.5666 10.194 13.1624C10.194 13.7583 9.71734 14.2458 9.12151 14.2458Z"></path>
                                                        </svg>
                                                        افزودن به سبد خرید
                                                    </button>
                                                    <?php
                                                }else{?>
                                                    <button type="button" class="btn btn-buy-disable mb-2" >خرید از سایت غیرفعال هست</button>
                                                    <?php
                                                }
                                            }else{
                                                echo '<div class="inaJSDge8">ناموجود</div>';
                                            }
                                            ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endwhile; ?>
                    </div>
                    <span class="swiper-notification" aria-live="assertive" aria-atomic="true"></span>
                </div>
            </div>
        </section>
        <?php
    }?>
    <section class="container-xl-w mx-auto <?=WC()->cart &&  WC()->cart->get_cart() ? 'mt-18' : ''?>">
        <div class="act-new-service-carousel-1st" id="user-cart">
            <?php
            if (WC()->cart &&  WC()->cart->get_cart()){
            ?>
            <div class="act-new-service-carousel-head d-flex align-items-center justify-content-between">
                <svg xmlns="http://www.w3.org/2000/svg" width="1281" height="75" viewBox="0 0 1281 75" fill="none" class="act-new-service-carousel-head-svg">
                    <path d="M1280.47 0.5H1000.91C986.771 0.5 979.703 0.5 973.764 2.99163C969.027 4.9789 964.838 8.07733 961.551 12.025C957.43 16.9747 955.361 23.7331 951.224 37.25C947.086 50.7669 945.017 57.5253 940.896 62.475C937.609 66.4227 933.42 69.5211 928.683 71.5084C922.744 74 915.676 74 901.54 74H412.882C399.847 74 393.329 74 387.813 71.8926C382.12 69.7177 377.167 65.9625 373.536 61.0686C370.017 56.3267 368.257 50.0512 364.737 37.5C361.217 24.9488 359.457 18.6733 355.938 13.9314C352.307 9.0375 347.353 5.2823 341.661 3.10737C336.145 1 329.627 1 316.592 1H0" stroke="url(#paint0_linear_29_20094)"></path>
                    <defs>
                        <linearGradient id="paint0_linear_29_20094" x1="29.4736" y1="0.500002" x2="1213.79" y2="-28.0511" gradientUnits="userSpaceOnUse">
                            <stop stop-color="#0B61FF" stop-opacity="0"></stop>
                            <stop offset="0.5" stop-color="#0B61FF"></stop>
                            <stop offset="1" stop-color="#0B61FF" stop-opacity="0"></stop>
                        </linearGradient>
                    </defs>
                </svg>
                <div class="act-our-services-carousel-head-title">
                    <div class="act-our-services-carousel-head-title-divs">
                        <div class="act-our-services-carousel-head-title-div1"></div>
                        <div class="act-our-services-carousel-head-title-div2"></div>
                    </div>
                    <div class="act-our-services-carousel-head-title-content">
                        <h5>سبد <strong>خرید</strong> شمـــــا</h5>
                        <p>YOUR SHOPPING CART</p>
                    </div>
                </div>
            </div>
            <div class="<?=WC()->cart &&  WC()->cart->get_cart() && is_user_logged_in() ? 'cart-preview__grid cart-preview__grid--board ' : ''?> cart-panel ">
                <?php

                if (WC()->cart &&  WC()->cart->get_cart() && is_user_logged_in()){

                    $cart_items = WC()->cart->get_cart();
                    ?>
                    <div class="flex flex-col lg:w-70 justify-between md:h-stretch">
                        <div class="flex md:h-416">
                            <div class="cart-panel--list">
                                <div>
                                    <div class="flex justify-between">
                                        <div class="act-our-services-carousel-head-title">
                                            <div class="act-our-services-carousel-head-title-divs">
                                                <div class="act-our-services-carousel-head-title-div1 tsc54b"></div>
                                            </div>
                                            <div class="act-our-services-carousel-head-title-content">
                                                <h5>سبد <strong>خرید</strong></h5>
                                                <p class="tsc54">SHOPPING CART</p>
                                            </div>
                                        </div>
                                        <span class="SJf5GS"><?= ( WC()->cart ) ? WC()->cart->get_cart_contents_count() : 0?></span>
                                    </div>
                                    <div class="cart-list">
                                        <?php
                                        if(!isMobile()){
                                            ?>
                                            <table class="cart-table">
                                                <thead><tr><th>محصول</th><th>تعداد</th><th>قیمت واحد</th><th>جمع کل</th></tr></thead>
                                                <tbody>
                                                <?php
                                                foreach ( $cart_items as $cart_item_key => $cart_item ) {

                                                    $product = $cart_item['data']; // آبجکت محصول
                                                    $product_id = $product->get_id();
                                                    $name = $product->get_name();
                                                    $quantity = $cart_item['quantity'];
                                                    $regular_price = $product->get_regular_price();
                                                    $sale_price = $product->get_sale_price();
                                                    $price = $product->get_price(); // قیمت نهایی
                                                    $subtotal = $cart_item['line_subtotal']; // جمع جزء
                                                    $total = $cart_item['line_total']; // جمع با تخفیف
                                                    $thumbnail = $product->get_image(); // تصویر محصول (HTML)
                                                    $permalink = $product->get_permalink();


                                                    ?>
                                                    <tr data-mini-item="<?=$cart_item_key?>">
                                                        <td>
                                                            <div class="flex">
                                                                <div class="self-center">
                                                                    <a class="font-size-14 text-dark font-bold tracking-tight leading-xs" href="<?=$permalink?>"><?=$name?></a></div>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="rounded bg-light flex flex-row-reverse transition-opacity h-40 w-112">
                                                                <button type="button" class="pl-6 mini-quantity__btn" data-mini-decrease="">
                                                                    <?php
                                                                    if ($quantity == 1){
                                                                        ?>
                                                                        <i class="icon-delete text-xs text-red-dark text-opacity-90 bg-white shadow-sm block text-center rounded-sm w-28 h-28 !leading-[28px]"></i>
                                                                        <?php
                                                                    }else{
                                                                        ?>
                                                                        <i class="icon-minus text-[9px] text-gray pt-1 bg-white shadow-sm block text-center rounded-sm w-28 h-28 !leading-[28px]"></i>

                                                                        <?php
                                                                    }
                                                                    ?>
                                                                </button>
                                                                <div class="grow text-center flex flex-col justify-center leading-1">
                                                                    <div class="pt-2 text-dark font-bold tracking-tighter text-sm after:loading after:border-blue transition-colors after:text-3xs" data-mini-qty><?=$quantity?></div>
                                                                </div>
                                                                <button type="button" class="pr-6 mini-quantity__btn" data-mini-increase="">
                                                                    <i class="bg-white shadow-sm text-gray rounded-sm icon-plus text-[9px] block text-center pt-1 w-28 h-28 !leading-[28px]"></i>
                                                                </button>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="leading-1 pt-2 grow">
                                                                <?php
                                                                if ($product->is_on_sale()){
                                                                    ?>
                                                                    <span class="ml-6 font-size-13 text-sm font-bold text-red opacity-85 tracking-tighter mb-2 block line-through"><?=number_format_usd($regular_price)?></span>
                                                                    <?php
                                                                }
                                                                ?>
                                                                <div class="text-2xs font-size-13 text-gray font-medium tracking-tight"><span
                                                                            class="text-lg font-bold text-dark tracking-tighter pt-2 inline-block"><?=number_format_usd($product->is_on_sale() ? $sale_price : $regular_price)?></span>
                                                                    تومان
                                                                </div>
                                                            </div>
                                                        </td>
                                                        <?php
                                                        $regular_price = (float) $product->get_regular_price();
                                                        $quantity      = (int)  $cart_item['quantity'];

                                                        $price_original_total = $regular_price * $quantity;
                                                        $price_final_total    = $cart_item['line_total'];
                                                        ?>
                                                        <td>
                                                            <div class="leading-1 pt-2 grow">
                                                                <?php
                                                                if ( $price_original_total > $price_final_total ) { ?>
                                                                    <span class="ml-6 font-size-13text-sm font-bold text-red opacity-85 tracking-tighter mb-2 block line-through"><?=number_format_usd($price_original_total)?></span>
                                                                    <?php
                                                                }
                                                                ?>
                                                                <div class="text-2xs text-gray font-medium tracking-tight"><span
                                                                            class="font-size-13 text-lg font-bold text-dark tracking-tighter pt-2 inline-block"><?=number_format_usd($price_final_total)?></span>
                                                                    تومان
                                                                </div>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                    <?php
                                                }
                                                ?>
                                                </tbody>
                                            </table>
                                            <?php
                                        }else{
                                            ?>
                                            <?php
                                            foreach ( $cart_items as $cart_item_key => $cart_item ) {

                                                $product = $cart_item['data'];
                                                $name = $product->get_name();
                                                $permalink = $product->get_permalink();
                                                $thumbnail = $product->get_image(); // تصویر محصول (HTML)

                                                ?>
                                                <div class="p-20 border-b border-gray-300 last:!border-b-0" data-mini-item="<?=$cart_item_key?>">
                                                    <div class="flex">
                                                        <div class="pt-4 self-center grow pl-12">
                                                            <a class="text-normal text-dark font-bold tracking-tight leading-xs block" href="<?=$permalink?>"><?=$name?></a>
                                                            <div class="leading-xs mt-6 space-y-5"></div>
                                                        </div>
                                                        <a class="shrink-0" href="<?=$permalink?>">
                                                            <div class="relative">
                                                                <img alt="<?=$name?>" loading="lazy" width="72" height="72" decoding="async" data-nimg="1" class="shrink-0 rounded block w-60" src="<?=wp_get_attachment_image_url($product->get_image_id(),'product_discount')?>" style="color: transparent;">
                                                            </div>
                                                        </a>
                                                    </div>
                                                    <div class="flex items-start mt-12">
                                                        <div class="leading-1 pt-2 grow self-center">
                                                            <?php
                                                            $regular_price = (float) $product->get_regular_price();
                                                            $quantity      = (int)  $cart_item['quantity'];

                                                            $price_original_total = $regular_price * $quantity;
                                                            $price_final_total    = $cart_item['line_total'];
                                                            ?>
                                                            <div class="leading-1 pt-2 grow">
                                                                <?php
                                                                if ( $price_original_total > $price_final_total ) { ?>
                                                                    <span class="ml-6 font-size-13text-sm font-bold text-red opacity-85 tracking-tighter mb-2 block line-through"><?=number_format_usd($price_original_total)?></span>
                                                                    <?php
                                                                }
                                                                ?>
                                                                <div class="text-2xs text-gray font-medium tracking-tight"><span
                                                                            class="font-size-13 text-lg font-bold text-dark tracking-tighter pt-2 inline-block"><?=number_format_usd($price_final_total)?></span>
                                                                    تومان
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="rounded bg-light flex flex-row-reverse transition-opacity h-40 lg:w-60">
                                                            <button type="button" class="pl-6 mini-quantity__btn" data-mini-decrease="">
                                                                <?php
                                                                if ($quantity == 1){
                                                                    ?>
                                                                    <i class="icon-delete text-xs text-red-dark text-opacity-90 bg-white shadow-sm block text-center rounded-sm w-28 h-28 !leading-[28px]"></i>
                                                                    <?php
                                                                }else{
                                                                    ?>
                                                                    <i class="icon-minus text-[9px] text-gray pt-1 bg-white shadow-sm block text-center rounded-sm w-28 h-28 !leading-[28px]"></i>

                                                                    <?php
                                                                }
                                                                ?>
                                                            </button>
                                                            <div class="grow text-center flex flex-col justify-center leading-1">
                                                                <div class="pt-2 text-dark font-bold tracking-tighter text-sm after:loading after:border-blue transition-colors after:text-3xs" data-mini-qty><?=$quantity?></div>
                                                            </div>
                                                            <button type="button" class="pr-6 mini-quantity__btn" data-mini-increase="">
                                                                <i class="bg-white shadow-sm text-gray rounded-sm icon-plus text-[9px] block text-center pt-1 w-28 h-28 !leading-[28px]"></i>
                                                            </button>
                                                        </div>
                                                    </div>
                                                </div>
                                                <?php
                                            }
                                            ?>
                                            <?php
                                        }
                                        ?>
                                    </div>
                                </div>
                                <div>
                                    <div class="flex justify-between<?=!isMobile() ? '' : ' flex-col'?>">
                                        <?php
                                        $total_points = 0;

                                        foreach ( WC()->cart->get_cart() as $cart_item_key => $cart_item ) {

                                            $product  = $cart_item['data'];
                                            $quantity = $cart_item['quantity'];

                                            $settings = get_post_meta($product->get_id(), 'giftmax_box_setting', true);

                                            $item_points = empty($settings[0]['purchaseScore']) ? 0 : $settings[0]['purchaseScore'];

                                            $line_points = $item_points * $quantity;

                                            WC()->cart->cart_contents[ $cart_item_key ]['points'] = $line_points;

                                            $total_points += $line_points;
                                        }

                                        WC()->session->set( 'total_cart_points', $total_points );
                                        if (!isMobile()){
                                            ?>
                                            <div class="cart-timer" role="status">
                                                <p class="eyebrow font-size-13">مهلت تکمیل خرید</p>
                                                <h3 class="cart-timer__value" data-cart-timer=""></h3>
                                            </div>
                                            <div class="cart__purchaseScore">
                                                <i class="icon-star"></i>
                                                شما بابت این خرید <strong class="font-bold" id="total_points"><?=number_format($total_points)?> امتیاز</strong> دریافت میکنید!
                                            </div>
                                            <?php
                                        }else{?>
                                            <div class="tracking-tight alert text-xs font-normal rounded-none px-16 lg:px-28 py-8 lg:py-12 flex items-center border-y border-dashed lg:mt-20 timerBox justify-between" style="background: linear-gradient(135deg, rgba(99, 102, 241, 0.08), rgba(139, 92, 246, 0.15)); border-color: rgb(203, 181, 255);">
                                                <p class="eyebrow font-size-13">مهلت تکمیل خرید</p>
                                                <h3 class="cart-timer__value" data-cart-timer=""></h3>
                                            </div>
                                            <div class="tracking-tight alert alert-primary bg-primary bg-opacity-[0.12] text-xs font-normal rounded-none px-16 lg:px-28 py-8 lg:py-12 flex items-center border-y border-primary border-dashed border-opacity-50 lg:mt-20 pointBox"><i class="icon-star text-[#D19411] text-xs ml-8 -mr-2"></i>
                                                <div class="grow pst-4 flex align-items-center">شما بابت این خرید <strong class="font-bold"><?=number_format($total_points)?></strong> دریافت میکنید!</div>
                                            </div>
                                            <?php
                                        }
                                        ?>
                                    </div>
                                </div>
                            </div>
                            <div class="cart-panel--invoice">
                                <div class="act-our-services-carousel-head-title">
                                    <div class="act-our-services-carousel-head-title-divs">
                                        <div class="act-our-services-carousel-head-title-div1 tsc54b"></div>
                                    </div>
                                    <div class="act-our-services-carousel-head-title-content">
                                        <h5>احراز <strong>هویت</strong> </h5>
                                        <p class="tsc54">IDENTITY VERIFICATION</p>
                                    </div>
                                </div>
                                <?php
                                $user = wp_get_current_user();
                                $u = SiteModel::table('user_identity','user_id',$user->ID);
                                $isVip = (isset($u['account_type']) && $u['account_type'] === 'vip');
                                ?>
                                <div class="profile-content">
                                    <div class="profile-section-container">
                                        <div class="profile-section c-box__info <?=$isVip ? 'w-full' : ''?>">
                                            <div>IP<span><?=giftmax_get_user_ip()?></span></div>
                                            <?php
                                            ?>
                                            <div>
                                                شماره تلفن
                                                <span><?=$user->user_login?></span>
                                            </div>
                                            <div>
                                                تلفن ثابت
                                                <?php
                                                if (!empty($u['landline_phone'])){
                                                    ?>
                                                    <span><?=decrypt_data($u['landline_phone'])?></span>
                                                    <?php
                                                }else{?>
                                                    <div class="Button-lp56">تایید تلفن ثابت</div>
                                                    <?php
                                                }
                                                ?>
                                            </div>
                                            <div>کدملی<span><?=!empty($u['national_id_enc']) ? decrypt_data($u['national_id_enc']) : ''?></span></div>
                                            <div>تاریخ تولد<span><?=!empty($u['birth_date_enc']) ? decrypt_data($u['birth_date_enc']) : ''?></span></div>
                                            <div>سطح اکانت
                                                <?php
                                                if (isset($u['account_type']) && $u['account_type'] == 'vip'){
                                                    ?>
                                                    <span style="
    background-color: #ff9100;
    color: #FFF;
    padding: 0 10px;
    border-radius: 8px;
">ویژه</span>
                                                    <?php
                                                }else{?>
                                                    <span style="background-color: #ff0000; color: #FFF; padding: 3px; border-radius: 8px; font-size: 12px; line-height: 1; display: flex; align-items: center;">معمولی</span>
                                                <?php }
                                                ?>
                                            </div>
                                        </div>
                                    </div>

                                    <script>
                                        window.vip = <?= $isVip ? 1 : 0; ?>;
                                    </script>
                                    <?php
                                    global $wpdb;
                                    $db = \Giftmax\modules\Db::getLnstance();
                                    $records = $db->first("SELECT * FROM `{$wpdb->prefix}setting` WHERE `meta_key`='stp'");
                                    if (!empty($records)){
                                        $record = json_decode($records['meta_value'], true);
                                        if ($isVip){
                                            ?>
                                            <div class="profile-section-container">
                                                <div class="profile-section px-[16px]">
                                                    <div class="flex justify-between">
                                                        <div class="flex justify-between lg:w-64">
                                                            <h5>امتیاز وفاداری </h5>
                                                            <p class="wejF5 profile-bpp"><?=number_format(UserModel::points())?></p>
                                                        </div>
                                                        <button class="Button-cc65 sdJHS56">
                                                            تبدیل به اعتبار
                                                        </button>
                                                    </div>
                                                </div>
                                                <p class="profile-text-info"><?='هر' . number_format($record[0]['points']) . ' امتیاز معادل است با' . number_format($record[0]['toman'])?></p>
                                            </div>

                                            <div class="profile-section-container mt-3">
                                                <div class="profile-section px-[16px]" style="margin-bottom: 0">
                                                    <div class="flex justify-between align-items-center">
                                                        <div class="flex flex-col">
                                                            <h5>کیف پول</h5>
                                                        </div>
                                                        <button class="Button-oc64 sdJHS56">
                                                            افزایش
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                            <?php
                                        }else{
                                            ?>
                                            <div class="flex justify-between profile-section-container xs:flex-col">
                                                <?php
                                                if (isMobile()){?>
                                                    <div class="w-full">
                                                        <div class="profile-section px-[10px]">
                                                            <div class="flex justify-between">
                                                                <div class="flex justify-between" style="width: 68%">
                                                                    <h5>امتیاز </h5>
                                                                    <p class="wejF5 profile-bpp" style="border-radius: 999px"><?=number_format(UserModel::points())?></p>
                                                                </div>
                                                                <button class="Button-cc65 sdJHS56">
                                                                    تبدیل به اعتبار
                                                                </button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="w-full">
                                                        <div class="profile-section px-[10px]">
                                                            <div class="flex justify-between align-items-center">
                                                                <div class="flex flex-col">
                                                                    <h5>کیف پول</h5>
                                                                </div>
                                                                <button class="Button-oc64 sdJHS56">
                                                                    افزایش
                                                                </button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                <?php }else{?>
                                                    <div class="lg:w-60">
                                                        <div class="profile-section px-[10px]">
                                                            <div class="flex justify-between">
                                                                <div class="flex justify-between lg:w-50">
                                                                    <h5>امتیاز </h5>
                                                                    <p class="wejF5 profile-bpp"><?=number_format(UserModel::points())?></p>
                                                                </div>
                                                                <button class="Button-cc65 sdJHS56">
                                                                    تبدیل به اعتبار
                                                                </button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="lg:w-40 mr-1">
                                                        <div class="profile-section px-[10px]">
                                                            <div class="flex justify-between align-items-center">
                                                                <div class="flex flex-col">
                                                                    <h5>کیف پول</h5>
                                                                </div>
                                                                <button class="Button-oc64 sdJHS56">
                                                                    افزایش
                                                                </button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                <?php }
                                                ?>
                                            </div>
                                            <div class="profile-section-container">
                                                <p class="profile-text-info"><?='هر' . number_format($record[0]['points']) . ' امتیاز معادل است با' . number_format($record[0]['toman'])?></p>
                                            </div>
                                            <?php
                                        }
                                    }
                                    if (!$isVip){
                                        $db = Db::getLnstance();
                                        global $wpdb;
                                        $cards = $db->query(
                                                "SELECT * FROM `{$wpdb->prefix}user_bank_cards` WHERE `user_id` = :user_id AND `is_active`=1",
                                                array('user_id' => $user->ID)
                                        );
                                        ?>
                                        <div class="profile-section-container">
                                            <div class="card-grid card-grid--swiper profile-section" style="margin-bottom: 0">
                                                <div class="flex justify-between align-items-center">
                                                    <div class="profile-section-section-name">
                                                        <div class="flex justify-between gap-2">
                                                            <span>کارت های بانکی</span>
                                                            <?php
                                                            if (!empty($cards) && count($cards) !=0){
                                                                ?>
                                                                <p class="profile-bpp"><?=count($cards)?></p>
                                                                <?php
                                                            }else{
                                                                ?>
                                                                <p class="profile-bpp">0</p>
                                                                <?php
                                                            }
                                                            ?>
                                                        </div>
                                                    </div>
                                                    <button class="Button-ac45">افزودن</button>
                                                </div>
                                                <?php
                                                if (!empty($cards)) {
                                                    ?>
                                                    <div class="swiper bank-cards-swiper">
                                                        <div class="swiper-wrapper">
                                                            <?php foreach ($cards as $card) {
                                                                $cardNumber = rtrim(
                                                                        chunk_split(decrypt_data($card['card_number_enc']), 4, '-'),
                                                                        '-'
                                                                );
                                                                ?>
                                                                <div class="swiper-slide">
                                                                    <article class="bank-card">
                                                                        <div class="bank-card-content">
                                                                            <div class="flex justify-end align-items-center">
                                                                                <div class="bank-card__top">
                                                                                    <div class="bank-card__logo" aria-hidden="true">
                                                                                        <img loading="lazy" decoding="async" data-nimg="1" class="h-auto" src="<?=detectBankImage(decrypt_data($card['card_number_enc']))?>" style="color: transparent;width: 20px" data-booster-processed="true">
                                                                                    </div>
                                                                                </div>
                                                                                <div class="bank-card__number"><?=$cardNumber?></div>
                                                                            </div>
                                                                            <?php
                                                                            if (empty($card['phone'])){
                                                                                ?>
                                                                                <div class="flex justify-between align-items-center relative">
                                                                                    <div class="bank-card_user_status success">
                                                                                        تحت مالکیت شما
                                                                                    </div>
                                                                                    <div class="w-[50px] lottie-container absolute -right-50" data-lottie-url="<?=get_template_directory_uri()?>/assets/img/wsl/card-done.json"></div>
                                                                                </div>
                                                                                <?php
                                                                            }else{?>
                                                                                <div class="flex justify-between align-items-center relative">
                                                                                    <div class="bank-card_user_status danger">
                                                                                        مالک شما نیستید
                                                                                    </div>
                                                                                    <div class="w-[50px] lottie-container absolute -right-50" data-lottie-url="<?=get_template_directory_uri()?>/assets/img/wsl/card-error.json"></div>
                                                                                </div>
                                                                            <?php }
                                                                            ?>
                                                                        </div>
                                                                        <div class="V10-3-Bank">
                                                                            <?php
                                                                            $cardSetting = detectBankImageBg($cardNumber,'v1');
                                                                            if (empty($card['phone'])){
                                                                                $user = get_userdata($card['user_id']);
                                                                                $userdata = SiteModel::table('user_identity','user_id',$card['user_id']);
                                                                                ?>
                                                                                <span class="numberCard" style="bottom: <?=$cardSetting['positionText']?>px;<?=!is_null($cardSetting['color']) ? "color:" . $cardSetting['color'] : '' ?>"><?=$cardNumber?></span>
                                                                                <img alt="bank" loading="lazy" src="<?=$cardSetting['img']?>">
                                                                                <span class="number-user" style="bottom: <?=$cardSetting["Box"]["y"]?>px;color:<?=$cardSetting["Box"]["color"]?>"><?=$user->user_login?></span>
                                                                                <span class="birthday-user" style="bottom: <?=$cardSetting["Box"]["y"]?>px;color:<?=$cardSetting["Box"]["color"]?>"><?=decrypt_data($userdata['birth_date_enc'])?></span>
                                                                                <span class="national__code-user" style="bottom: <?=$cardSetting["Box"]["y"]?>px;color:<?=$cardSetting["Box"]["color"]?>"><?=decrypt_data($userdata['national_id_enc'])?></span>
                                                                                <span class="full__name-user" style="bottom: <?=$cardSetting["Box"]["y"]?>px;color:<?=$cardSetting["Box"]["color"]?>"><?=$user->first_name . ' ' . $user->last_name?></span>

                                                                                <?php
                                                                            }else{
                                                                                ?>
                                                                                <span class="numberCard" style="bottom: <?=$cardSetting['positionText']?>px;<?=$cardSetting != null ? "color:" . $cardSetting['color'] : '' ?>"><?=$cardNumber?></span>
                                                                                <span class="number-user" style="bottom: <?=$cardSetting["Box"]["y"]?>px;color:<?=$cardSetting["Box"]["color"]?>"><?=decrypt_data($card['phone'])?></span>
                                                                                <span class="birthday-user" style="bottom: <?=$cardSetting["Box"]["y"]?>px;color:<?=$cardSetting["Box"]["color"]?>"><?=decrypt_data($card['birth_date'])?></span>
                                                                                <span class="national__code-user" style="bottom: <?=$cardSetting["Box"]["y"]?>px;color:<?=$cardSetting["Box"]["color"]?>"><?=decrypt_data($card['national_code'])?></span>
                                                                                <span class="full__name-user" style="bottom: <?=$cardSetting["Box"]["y"]?>px;color:<?=$cardSetting["Box"]["color"]?>"><?=$card['first_name'] . ' ' . $card['last_name']?></span>
                                                                                <img alt="bank" loading="lazy" src="<?=$cardSetting['img']?>">
                                                                            <?php }
                                                                            ?>
                                                                        </div>
                                                                    </article>
                                                                </div>

                                                            <?php } ?>
                                                        </div>
                                                    </div>
                                                    <?php
                                                } else {
                                                    ?>
                                                    <div class="flex justify-center align-items-center px-[10px]">
                                                        <div class="lottie-container w-[50px]" data-lottie-url="<?=get_template_directory_uri()?>/assets/img/wsl/card.json"></div>
                                                        <div class="text-body2-strong text-[#027275]">کارت بانکی ثبت نشده</div>
                                                    </div>
                                                    <?php
                                                }
                                                ?>
                                            </div>
                                        </div>
                                        <?php
                                    }
                                    ?>
                                </div>
                            </div>
                        </div>
                        <div class="ktfb">
                            <h4>نکات مهم :</h4>
                            <p> 1.  سبد خرید شما تا زمانی که پرداخت نهایی انجام نشه، قطعی رزرو نشده.لطفاً تا ۵ دقیقه آینده سفارشتون رو تکمیل و پرداخت کنید، وگرنه آیتم‌های داخل سبد به صورت خودکار آزاد و حذف می‌شن.</p>
                            <p> 2. در صورت تکمیل سفارش و انجام فرایند احراز هویت و تحویل محصول خریداری شده ،فاکتور قابل عودت و برگشت به هیچ وجه ممکن نخواهد بود.</p>
                            <p>3. درصورت عودت هرگونه وجهی ، 10% ارزش افزوده از مبلغ واریزی کسر و باقیمانده مبلغ طی 24 ساعت کاری به همان کارت بانکی که خرید شده است عودت خواهد شد.</p>
                        </div>
                    </div>

                    <div class="cart-panel--payment lg:w-30 md:h-stretch">
                        <div class="act-our-services-carousel-head-title">
                            <div class="act-our-services-carousel-head-title-divs">
                                <div class="act-our-services-carousel-head-title-div1 tsc54b"></div>
                            </div>
                            <div class="act-our-services-carousel-head-title-content">
                                <h5><strong>پرداخت</strong> </h5>
                                <p class="tsc54">PAYMENT</p>
                            </div>
                        </div>
                        <div class="flex justify-between" style="margin: 21px 0">
                            <button class="payment active Button-pr44"><div>پرداخت ریالی</div></button>
                            <button class="payment Button-pu44"><div>پرداخت با رمز ارز ها</div></button>
                        </div>
                        <div class="invoice-board">
                            <div class="flex flex-col relative grow">
                                <div class="grow before:loading">
                                    <div class="space-y-10 lg:space-y-12 lg:sticky lg:top-28">
                                        <?php
                                        $cart_product_discount = 0;

                                        foreach ( WC()->cart->get_cart() as $cart_item ) {
                                            $product = $cart_item['data'];
                                            $qty     = (int) $cart_item['quantity'];
                                            $regular_price = (float) $product->get_regular_price();
                                            $line_total    = $cart_item['line_total'];

                                            $cart_product_discount += ($regular_price * $qty) - $line_total;
                                        }

                                        $total_discount        = $cart_product_discount;
                                        ?>
                                        <div class="flex items-center leading-xs"><span class="grow text-xs tracking-tight font-medium text-dark">قیمت کل</span>
                                            <div class="text-2xs text-gray font-medium tracking-tight" data-summary="subtotal">
                                                <span
                                                        class="text-larger font-bold text-dark tracking-tighter pt-2 inline-block"><?=number_format_usd(WC()->cart->get_subtotal()+$total_discount)?></span>
                                                تومان
                                            </div>
                                        </div>
                                        <div class="flex items-center leading-xs"><span
                                                    class="grow text-xs tracking-tight font-medium text-dark">تخفیف سبد خرید</span>
                                            <div class="text-2xs text-gray font-medium tracking-tight" data-summary="discount">
                                                <span class="text-larger font-bold text-red tracking-tighter pt-2 inline-block"><?= number_format_usd($total_discount) ?></span>
                                                تومان
                                            </div>
                                        </div>
                                        <div class="flex items-center leading-xs">
                                            <div class="grow">
                                                <span class="block text-xs tracking-tight font-medium text-dark">کد تخفیف</span>
                                            </div>
                                            <button type="button" class="btn !w-28 !text-5xs !text-green-dark !pt-2 !h-28 btn-white btn-icon icon-plus relative Button-cc59" aria-label="افزودن کد تخفیف"></button>
                                        </div>
                                        <div class="flex items-center leading-xs justify-between Box-cs65">
                                            <div class="flex flex-col">
                                                <span class="grow text-xs tracking-tight font-medium text-dark pt-1">استفاده از کیف پول</span>
                                                <span id="balance" class="grow text-xs tracking-tight font-medium text-dark pt-1 <?=empty(UserModel::wallet()) || !empty(UserModel::wallet()) && UserModel::wallet() ==0 ? 'hidden' : ''?>" style=" color: #a7a7a7; font-size: 12px; "><?=number_format(UserModel::wallet())?> تومان</span>
                                            </div>
                                            <div class="text-2xs text-gray font-medium tracking-tight">
                                                <label for="wallet" class="input-label start w40_1">
                                                    <span class="start-label"></span>
                                                    <?php
                                                    if (!empty(UserModel::wallet()) && UserModel::wallet() != 0){
                                                        ?>
                                                        <input id="wallet" type="checkbox" class="input" <?= WC()->session->get('use_wallet',true) ? 'checked' : ''?>>
                                                        <?php
                                                    }
                                                    ?>
                                                    <span class="input-check" style="<?=empty(UserModel::wallet()) || !empty(UserModel::wallet()) && UserModel::wallet() ==0 ? 'cursor: no-drop;' : ''?>"></span>
                                                </label>
                                            </div>
                                        </div>
                                        <div class="hr-p"></div>
                                        <div class="flex items-center leading-xs"><span
                                                    class="grow text-xs tracking-tight font-medium text-dark pt-1">مبلغ قابل پرداخت</span>
                                            <div class="text-2xs text-gray font-medium tracking-tight" data-summary="total">
                                                <span class="text-lg font-bold text-green-dark tracking-tighter pt-2 inline-block"><?=number_format_usd( WC()->cart->get_total('edit'))?></span>
                                                تومان
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="border rounded mt-14 lg:mt-16 gateway-row flex">
                                    <button type="button" class="border-l w-full text-right border-gray-300 last:!border-l-0 py-16 px-14 flex items-center Button-p4" data-gateway="zibal">
                                        <div class="pt-2 grow leading-1 tracking-tight">
                                            <span class="block text-xs text-dark font-bold">پرداخت آنلاین</span>
                                            <span class="block text-2xs font-normal text-dark mt-8">درگاه پرداخت زیبال</span>
                                        </div>
                                        <i class="w-20 h-20 text-center rounded-circle text-4xs pl-1 ml-4 !leading-[22px] icon-check transition-colors text-white bg-green bg-opacity-100"></i>
                                    </button>
                                    <button type="button" class="border-l w-full text-right border-gray-300 last:!border-l-0 py-16 px-14 flex items-center Button-p4" data-gateway="paystar">
                                        <div class="pt-2 grow leading-1 tracking-tight">
                                            <span class="block text-xs text-dark font-bold">پرداخت آنلاین</span>
                                            <span class="block text-2xs font-normal text-dark mt-8">درگاه پرداخت پی استار</span>
                                        </div>
                                        <i class="w-20 h-20 text-center rounded-circle bg-gray bg-opacity-15 text-4xs pl-1 ml-4 !leading-[22px] icon-check text-transparent transition-colors"></i>
                                    </button>
                                </div>
                                <div class="css-transition-opacity after:loading !absolute inset-x-0 inset-y-0 bg-white bg-opacity-50 is-loading after:border-gray after:border-opacity-75 after:h-24 after:w-24 after:border-[3px] z-10 rounded-bl-lg"></div>
                            </div>
                        </div>
                        <div class="swiper supported__brands hidden">
                            <div class="swiper-wrapper">
                                <div class="swiper-slide">
                                    <img alt="" loading="lazy" width="1000" height="120" decoding="async"
                                         data-nimg="1" class="block dark:hidden" style="color:transparent"
                                         src="<?=get_template_directory_uri()?>/assets/img/assets.jpeg"></div>
                                <div class="swiper-slide">
                                    <img alt="" loading="lazy" width="1000" height="120" decoding="async"
                                         data-nimg="1" class="block dark:hidden" style="color:transparent"
                                         src="<?=get_template_directory_uri()?>/assets/img/assets.jpeg"></div>
                                <div class="swiper-slide">
                                    <img alt="" loading="lazy" width="1000" height="120" decoding="async"
                                         data-nimg="1" class="block dark:hidden" style="color:transparent"
                                         src="<?=get_template_directory_uri()?>/assets/img/assets.jpeg"></div>
                                <div class="swiper-slide">
                                    <img alt="" loading="lazy" width="1000" height="120" decoding="async"
                                         data-nimg="1" class="block dark:hidden" style="color:transparent"
                                         src="<?=get_template_directory_uri()?>/assets/img/assets.jpeg"></div>
                            </div>
                        </div>
                        <button class="btn btn--gradient btn--block Button-pcu48">ثبت سفارش</button>
                        <p class="payment--alert">کاربر گرامی <?="$user->first_name $user->last_name"?> ، خواهشمند است در هنگام پرداخت دقت فرمایید؛ زیرا جنس و کد دریافتی تحت هیچ شرایطی قابل عودت نمی‌باشد.</p>
                    </div>
                    <?php
                }else{
                    if(!is_user_logged_in()){
                        echo "<div class='flex mx-auto'><span>برای دسترسی به سبد خرید لاگین کنید</span></div>";
                    }else if(empty(WC()->cart) || empty(WC()->cart->get_cart())){
                        echo "<div class='flex mx-auto'><span>سبد خرید شما خالی است</span></div>";
                    }
                }
                ?>
            </div>
        </div>
        <?php
        }
        ?>
    </section>
    <section class="container-xl-w mx-auto mt-18">
        <div class="act-blogs-1st">
            <div class="act-blogs-head d-flex align-items-center justify-content-between">
                <svg xmlns="http://www.w3.org/2000/svg" width="1281" height="75" viewBox="0 0 1281 75" fill="none" class="act-blogs-carousel-head-svg">
                    <path d="M1280.47 0.5H1112.91C1098.77 0.5 1091.7 0.5 1085.76 2.99163C1081.03 4.9789 1076.84 8.07733 1073.55 12.025C1069.43 16.9747 1067.36 23.7331 1063.22 37.25C1059.09 50.7669 1057.02 57.5253 1052.9 62.475C1049.61 66.4227 1045.42 69.5211 1040.68 71.5084C1034.74 74 1027.68 74 1013.54 74H654.882C641.847 74 635.329 74 629.813 71.8926C624.12 69.7177 619.167 65.9625 615.536 61.0686C612.017 56.3267 610.257 50.0512 606.737 37.5C603.217 24.9488 601.457 18.6733 597.938 13.9314C594.307 9.0375 589.353 5.2823 583.661 3.10737C578.145 1 571.627 1 558.592 1H0" stroke="url(#paint0_linear_29_19900)"></path>
                    <defs>
                        <linearGradient id="paint0_linear_29_19900" x1="29.4736" y1="0.5" x2="1213.79" y2="-28.0511" gradientUnits="userSpaceOnUse">
                            <stop stop-color="#0B61FF" stop-opacity="0"></stop>
                            <stop offset="0.5" stop-color="#0B61FF"></stop>
                            <stop offset="1" stop-color="#0B61FF" stop-opacity="0"></stop>
                        </linearGradient>
                    </defs>
                </svg>
                <div class="act-our-services-carousel-head-title">
                    <div class="act-our-services-carousel-head-title-divs">
                        <div class="act-our-services-carousel-head-title-div1"></div>
                        <div class="act-our-services-carousel-head-title-div2"></div>
                    </div>
                    <div class="act-our-services-carousel-head-title-content">
                        <div class="act-our-services-carousel-head-title-content-title"><h5>جدیدترین <strong>مقالات</strong></h5></div>
                        <p>LATEST BLOGS</p>
                    </div>
                </div>
                <div class="act-blogs-head-content">
                    <div class="act-blogs-head-content-text">
                        <p>با <strong>تازه&zwnj;ترین مقالات</strong> و نکات مفید دیجیتال و فناوری همراه ما باشید و دانش خود را به&zwnj;روز کنید</p>                    </div>
                    <div class="act-vb"></div>
                    <div class="act-blogs-head-content-box"><a href="<?=home_url('/blogs')?>" class="">
                            مشاهده بیشتر                            <svg xmlns="http://www.w3.org/2000/svg" width="34" height="34" viewBox="0 0 34 34" fill="currentcolor">
                                <path d="M20.0744 10.4295C20.2088 10.5639 20.2936 10.7477 20.2936 10.9599C20.2936 11.37 19.9542 11.7094 19.5441 11.7094L11.7094 11.7094L11.7094 19.5442C11.7094 19.9543 11.3699 20.2937 10.9598 20.2937C10.5497 20.2937 10.2103 19.9543 10.2103 19.5442L10.2103 10.9599C10.2103 10.5498 10.5497 10.2103 10.9598 10.2103L19.5441 10.2103C19.7562 10.2103 19.9401 10.2952 20.0744 10.4295Z"></path>
                                <path d="M11.611 10.5501L23.5116 22.4507C23.8015 22.7406 23.8015 23.2215 23.5116 23.5114C23.2217 23.8013 22.7409 23.8013 22.451 23.5114L10.5504 11.6108C10.2605 11.3209 10.2605 10.84 10.5504 10.5501C10.8403 10.2602 11.3211 10.2602 11.611 10.5501Z"></path>
                            </svg>
                        </a>
                        <div class="act-blogs-head-nav-buts">
                            <div class="act-carousel-but act-blogs-head-nav-buts-prev" tabindex="0" role="button" aria-label="Previous slide" aria-controls="swiper-wrapper-dfda266ed8783e9b" aria-disabled="false">
                                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="currentcolor">
                                    <path d="M12.0253 15.6833C11.8669 15.6833 11.7086 15.625 11.5836 15.5C11.3419 15.2583 11.3419 14.8583 11.5836 14.6166L16.2003 9.99998L11.5836 5.38331C11.3419 5.14164 11.3419 4.74164 11.5836 4.49998C11.8253 4.25831 12.2253 4.25831 12.4669 4.49998L17.5253 9.55831C17.7669 9.79998 17.7669 10.2 17.5253 10.4416L12.4669 15.5C12.3419 15.625 12.1836 15.6833 12.0253 15.6833Z"></path>
                                    <path d="M16.942 10.625H2.91699C2.57533 10.625 2.29199 10.3417 2.29199 10C2.29199 9.65833 2.57533 9.375 2.91699 9.375H16.942C17.2837 9.375 17.567 9.65833 17.567 10C17.567 10.3417 17.2837 10.625 16.942 10.625Z"></path>
                                </svg>
                            </div>
                            <div class="act-carousel-but act-blogs-head-nav-buts-next" tabindex="0" role="button" aria-label="Next slide" aria-controls="swiper-wrapper-dfda266ed8783e9b" aria-disabled="false">
                                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="currentcolor">
                                    <path d="M7.97474 4.31669C8.13307 4.31669 8.29141 4.37502 8.41641 4.50002C8.65807 4.74169 8.65807 5.14169 8.41641 5.38336L3.79974 10L8.41641 14.6167C8.65807 14.8584 8.65807 15.2584 8.41641 15.5C8.17474 15.7417 7.77474 15.7417 7.53307 15.5L2.47474 10.4417C2.23307 10.2 2.23307 9.80002 2.47474 9.55836L7.53307 4.50002C7.65807 4.37502 7.81641 4.31669 7.97474 4.31669Z"></path>
                                    <path d="M3.05801 9.375L17.083 9.375C17.4247 9.375 17.708 9.65833 17.708 10C17.708 10.3417 17.4247 10.625 17.083 10.625L3.05801 10.625C2.71634 10.625 2.43301 10.3417 2.43301 10C2.43301 9.65833 2.71634 9.375 3.05801 9.375Z"></path>
                                </svg>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php
            $posts_per_page = 6;
            $orderby        = 'date';
            $order          = 'DESC';

            $args = [
                    'posts_per_page' => $posts_per_page,
                    'orderby' => $orderby,
                    'order' => $order,
                    'no_found_rows' => true,
            ];
            $posts  = get_posts( $args );

            if ( ! empty( $posts ) ) : ?>
                <div class="act-blogs-main">
                    <?php
                    $db = Db::getLnstance();
                    global $wpdb;
                    $records = $db->first("SELECT * FROM `{$wpdb->prefix}setting` WHERE `meta_key`='category'");

                    if (!empty($records)){
                        $ids_string = $records['meta_value'];
                        $ids = array_map( 'intval', explode( ',', $ids_string ) );

                        $categories = get_categories( array(
                                'include'    => $ids,
                                'hide_empty' => false,
                        ) );

                        ob_start();

                        if ( ! empty( $categories ) ) {?>
                            <nav id="blog-categories" class="flex flex-wrap gap-4 py-4 nav_act-blogs-1st mb-3">
                                <div data-cat="" class="act-catagory-card pointer C-item__blog">
                                    <div class="act-catagory-card-inner">
                                        <div class="act-catagory-card-name">
                                            <div class="act-our-services-carousel-head-title-divs">
                                                <div class="act-our-services-carousel-head-title-div1" style="height: 15px;  margin-bottom: 4px;"></div>
                                                <div class="act-our-services-carousel-head-title-div2" style=" height: 12px;"></div>
                                            </div>
                                            <div class="act-catagory-name-text">
                                                <strong>همه</strong>
                                                <p>All</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php
                                foreach ( $categories as $cat ) { ?>
                                    <div data-cat="<?=$cat->slug?>" class="act-catagory-card pointer C-item__blog">
                                        <div class="act-catagory-card-inner">
                                            <div class="act-catagory-card-name">
                                                <div class="act-our-services-carousel-head-title-divs">
                                                    <div class="act-our-services-carousel-head-title-div1" style="height: 15px;  margin-bottom: 4px;"></div>
                                                    <div class="act-our-services-carousel-head-title-div2" style=" height: 12px;"></div>
                                                </div>
                                                <div class="act-catagory-name-text">
                                                    <strong><?=$cat->name?></strong>
                                                    <p><?=giftmax_get_term_english_name($cat)?></p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <?php
                                }
                                ?>
                            </nav>
                            <?php
                        }
                    }
                    ?>
                    <div class="act-blogs-carousel">
                        <div class="act-blogs-carousel-wrapper">
                            <?php
                            if (!empty($posts[0]->ID) || !empty($posts[1]->ID)){
                                $Post_right = array(
                                        empty($posts[0]->ID) ? 'no' : $posts[0]->ID,
                                        empty($posts[1]->ID) ? 'no' : $posts[1]->ID
                                )
                                ?>
                                <div class="act-blogs-first-box">
                                    <?php
                                    foreach ($Post_right as $item){
                                        if ($item == 'no'){
                                            continue;
                                        }
                                        ?>
                                        <div class="act-blog-first-card">
                                            <a href="<?=get_permalink($item)?>" class="act-blog-card">
                                                <div class="act-blog-card-inner">
                                                    <div class="act-blog-card-img-box">
                                                        <img decoding="async" src="<?=get_the_post_thumbnail_url($item)?>" alt="">
                                                        <span class="act-blog-card-img-box-label"><?=get_the_category($item)[0]->name?></span></div>
                                                    <div class="act-blog-card-content">
                                                        <h4 class="act-product-title"><?=get_the_title($item)?></h4>
                                                        <div class="act-blog-card-text"><?=get_the_excerpt($item)?></div>
                                                        <div class="act-blog-card-footer">
                                                            <div class="act-blog-card-footer-read-time"><div class="flex align-items-center ml-1"><i class="icon-eye"></i><p><?=view_giftmax($item)?></p></div><div class="flex align-items-center"><i class="icon-user"></i><?=giftmax_get_author_full_name(get_post_author_id($item))?></div><div class="flex align-items-center blog_clock-view"><i class="icon-clock"></i><?=gjdate(get_the_date('Y-m-d',$item),"d M Y")?></div></div>
                                                            <div class="act-blog-card-link">
                                                                <svg xmlns="http://www.w3.org/2000/svg" width="26" height="26" viewBox="0 0 26 26" fill="currentcolor">
                                                                    <path d="M15.0559 8.6175C14.9551 8.71827 14.8173 8.78191 14.6582 8.78191L8.7821 8.78191L8.7821 14.658C8.7821 14.9656 8.52755 15.2201 8.21996 15.2201C7.91236 15.2201 7.6578 14.9656 7.6578 14.658L7.6578 8.21976C7.6578 7.91216 7.91236 7.65761 8.21995 7.65761L14.6582 7.65761C14.9658 7.65761 15.2203 7.91216 15.2203 8.21976C15.2256 8.37355 15.1567 8.51674 15.0559 8.6175Z"></path>
                                                                    <path d="M17.6333 17.6332C17.4159 17.8506 17.0553 17.8506 16.8379 17.6332L7.9124 8.7077C7.69496 8.49027 7.69496 8.12964 7.9124 7.91221C8.12983 7.69477 8.49046 7.69477 8.70789 7.91221L17.6333 16.8377C17.8508 17.0551 17.8508 17.4157 17.6333 17.6332Z"></path>
                                                                </svg>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </a>
                                        </div>
                                        <?php
                                    }
                                    ?>
                                </div>
                                <?php
                            }
                            if (!empty($posts[2]->ID)){
                                ?>
                                <a href="<?=get_permalink($posts[2]->ID)?>" class="act-blog-card fDjf5">
                                    <div class="act-blog-card-inner">
                                        <div class="act-blog-card-img-box">
                                            <img decoding="async" src="<?=get_the_post_thumbnail_url($posts[2]->ID)?>" alt="">
                                            <span class="act-blog-card-img-box-label"><?=get_the_category($posts[2]->ID)[0]->name?></span>
                                        </div>
                                        <div class="act-blog-card-content">
                                            <h4 class="act-product-title"><?=get_the_title($posts[2]->ID)?></h4>
                                            <div class="act-blog-card-text"><?=get_the_excerpt($posts[2]->ID)?></div>
                                        </div>
                                        <div class="act-blog-card-footer">
                                            <div class="act-blog-card-footer-read-time"><div class="flex align-items-center ml-1"><i class="icon-eye"></i><p><?= view_giftmax($posts[2]->ID)?></p></div><div class="flex align-items-center"><i class="icon-user"></i><?=giftmax_get_author_full_name(get_post_author_id($posts[2]->ID))?></div><div class="flex align-items-center blog_clock-view"><i class="icon-clock"></i><?=gjdate(get_the_date('Y-m-d',$posts[2]->ID),"d M Y")?></div></div>
                                            <div class="act-blog-card-link">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="26" height="26" viewBox="0 0 26 26" fill="currentcolor">
                                                    <path d="M15.0559 8.6175C14.9551 8.71827 14.8173 8.78191 14.6582 8.78191L8.7821 8.78191L8.7821 14.658C8.7821 14.9656 8.52755 15.2201 8.21996 15.2201C7.91236 15.2201 7.6578 14.9656 7.6578 14.658L7.6578 8.21976C7.6578 7.91216 7.91236 7.65761 8.21995 7.65761L14.6582 7.65761C14.9658 7.65761 15.2203 7.91216 15.2203 8.21976C15.2256 8.37355 15.1567 8.51674 15.0559 8.6175Z"></path>
                                                    <path d="M17.6333 17.6332C17.4159 17.8506 17.0553 17.8506 16.8379 17.6332L7.9124 8.7077C7.69496 8.49027 7.69496 8.12964 7.9124 7.91221C8.12983 7.69477 8.49046 7.69477 8.70789 7.91221L17.6333 16.8377C17.8508 17.0551 17.8508 17.4157 17.6333 17.6332Z"></path>
                                                </svg>
                                            </div>
                                        </div>
                                    </div>
                                </a>
                                <?php
                            }
                            if (!empty($posts[3]->ID) || !empty($posts[4]->ID) || !empty($posts[5]->ID)){
                                $Post_left = array(
                                        empty($posts[3]->ID) ? 'no' : $posts[3]->ID,
                                        empty($posts[4]->ID) ? 'no' : $posts[4]->ID,
                                        empty($posts[5]->ID) ? 'no' : $posts[5]->ID
                                );
                                ?>
                                <div class="act-blogs-last-box">
                                    <?php
                                    foreach ($Post_left as $value) {
                                        if ($value == 'no'){
                                            continue;
                                        }
                                        ?>
                                        <div class="act-blog-last-card">
                                            <a href="<?=get_permalink($value)?>" class="act-blog-card">
                                                <div class="act-blog-card-inner">
                                                    <div class="act-blog-card-img-box">
                                                        <img decoding="async" src="<?=get_the_post_thumbnail_url($value)?>" alt="">
                                                    </div>
                                                    <div class="act-blog-card-content">
                                                        <h4 class="act-product-title"><?=get_the_title($value)?></h4>
                                                        <div class="act-blog-card-footer">

                                                            <div class="act-blog-card-footer-read-time"><div class="flex align-items-center ml-1"><i class="icon-eye"></i><p><?= view_giftmax($value)?></p></div><div class="flex align-items-center"><i class="icon-user"></i><?=giftmax_get_author_full_name(get_post_author_id($posts[2]->ID))?></div><div class="flex align-items-center blog_clock-view"><i class="icon-clock"></i><?=gjdate(get_the_date('Y-m-d',$posts[2]->ID),"d M Y")?></div></div>
                                                            <div class="act-blog-card-link">
                                                                <svg xmlns="http://www.w3.org/2000/svg" width="26" height="26" viewBox="0 0 26 26" fill="currentcolor">
                                                                    <path d="M15.0559 8.6175C14.9551 8.71827 14.8173 8.78191 14.6582 8.78191L8.7821 8.78191L8.7821 14.658C8.7821 14.9656 8.52755 15.2201 8.21996 15.2201C7.91236 15.2201 7.6578 14.9656 7.6578 14.658L7.6578 8.21976C7.6578 7.91216 7.91236 7.65761 8.21995 7.65761L14.6582 7.65761C14.9658 7.65761 15.2203 7.91216 15.2203 8.21976C15.2256 8.37355 15.1567 8.51674 15.0559 8.6175Z"></path>
                                                                    <path d="M17.6333 17.6332C17.4159 17.8506 17.0553 17.8506 16.8379 17.6332L7.9124 8.7077C7.69496 8.49027 7.69496 8.12964 7.9124 7.91221C8.12983 7.69477 8.49046 7.69477 8.70789 7.91221L17.6333 16.8377C17.8508 17.0551 17.8508 17.4157 17.6333 17.6332Z"></path>
                                                                </svg>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </a>
                                        </div>
                                        <?php
                                    }
                                    ?>
                                </div>
                                <?php
                            }
                            ?>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </section>
    <?php
    $db = Db::getLnstance();
    global $wpdb;
    $records = $db->first("SELECT meta_value FROM `{$wpdb->prefix}setting` WHERE `meta_key`=:key",array('key'=>'description'));
    if (!empty($records)){
        ?>
        <section class="container-xl-w mx-auto mt-18">
            <div class="act-comment-1st">
                <div class="act-blogs-head d-flex align-items-center justify-content-between">
                    <svg xmlns="http://www.w3.org/2000/svg" width="1281" height="75" viewBox="0 0 1281 75" fill="none" class="act-blogs-carousel-head-svg">
                        <path d="M1280.47 0.5H1112.91C1098.77 0.5 1091.7 0.5 1085.76 2.99163C1081.03 4.9789 1076.84 8.07733 1073.55 12.025C1069.43 16.9747 1067.36 23.7331 1063.22 37.25C1059.09 50.7669 1057.02 57.5253 1052.9 62.475C1049.61 66.4227 1045.42 69.5211 1040.68 71.5084C1034.74 74 1027.68 74 1013.54 74H654.882C641.847 74 635.329 74 629.813 71.8926C624.12 69.7177 619.167 65.9625 615.536 61.0686C612.017 56.3267 610.257 50.0512 606.737 37.5C603.217 24.9488 601.457 18.6733 597.938 13.9314C594.307 9.0375 589.353 5.2823 583.661 3.10737C578.145 1 571.627 1 558.592 1H0" stroke="url(#paint0_linear_29_19900)"></path>
                        <defs>
                            <linearGradient id="paint0_linear_29_19900" x1="29.4736" y1="0.5" x2="1213.79" y2="-28.0511" gradientUnits="userSpaceOnUse">
                                <stop stop-color="#0B61FF" stop-opacity="0"></stop>
                                <stop offset="0.5" stop-color="#0B61FF"></stop>
                                <stop offset="1" stop-color="#0B61FF" stop-opacity="0"></stop>
                            </linearGradient>
                        </defs>
                    </svg>
                    <div class="act-our-services-carousel-head-title">
                        <div class="act-our-services-carousel-head-title-divs">
                            <div class="act-our-services-carousel-head-title-div1"></div>
                            <div class="act-our-services-carousel-head-title-div2"></div>
                        </div>
                        <div class="act-our-services-carousel-head-title-content">
                            <div class="act-our-services-carousel-head-title-content-title"><h5>درباره <strong>ما</strong></h5></div>
                            <p class="act-our-services-carousel-head-title-content-text"></p><p>ABOUT WE</p><p></p>
                        </div>
                    </div>
                </div>
                <div class="act-comment-box swiper-backface-hidden">
                    <div class="act-comment-box-discription">
                        <div class="act-comment-box__din"><?=wp_kses_post($records['meta_value'])?></div>
                        <div class="act-comment-box-discription-quote">“</div>
                    </div>

                </div>
            </div>
        </section>
        <?php
    }
    ?>
    <section class="container-xl-w mx-auto mt-18">
        <div class="act-faq-1st">
            <svg xmlns="http://www.w3.org/2000/svg" fill="rgb(255, 255, 255)" viewBox="0 0 1280 145.75342465753423" width="100%" height="145.75342465753423" class="act-faq-svg-bg">
                <mask fill="white" id="path-1-inside-1_29_20278">
                    <path d="M1280 90C1280 76.7451 1269.25 66 1256 66H1026.74C1019.33 66 1012.34 62.5806 1007.79 56.7345L970.873 9.2655C966.326 3.41937 959.335 0 951.929 0H24C10.7451 0 0 10.7452 0 24V536C0 549.255 10.7452 560 24 560H1256C1269.25 560 1280 549.255 1280 536V90Z"></path>
                </mask>
                <path d="M1280 90C1280 76.7451 1269.25 66 1256 66H1026.74C1019.33 66 1012.34 62.5806 1007.79 56.7345L970.873 9.2655C966.326 3.41937 959.335 0 951.929 0H24C10.7451 0 0 10.7452 0 24V536C0 549.255 10.7452 560 24 560H1256C1269.25 560 1280 549.255 1280 536V90Z"></path>
                <path mask="url(#path-1-inside-1_29_20278)" class="act-faq-svg-border" fill="rgba(11, 21, 48, 0.06)" d="M970.873 9.2655L971.663 8.65155L970.873 9.2655ZM1007.79 56.7345L1007 57.3484L1007.79 56.7345ZM1256 66V67H1026.74V66V65H1256V66ZM1007.79 56.7345L1007 57.3484L970.084 9.87946L970.873 9.2655L971.663 8.65155L1008.58 56.1206L1007.79 56.7345ZM951.929 0V1H24V0V-1H951.929V0ZM0 24H1V536H0H-1V24H0ZM24 560V559H1256V560V561H24V560ZM1280 536H1279V90H1280H1281V536H1280ZM1256 560V559C1268.7 559 1279 548.703 1279 536H1280H1281C1281 549.807 1269.81 561 1256 561V560ZM0 536H1C1 548.703 11.2975 559 24 559V560V561C10.1929 561 -1 549.807 -1 536H0ZM24 0V1C11.2974 1 1 11.2974 1 24H0H-1C-1 10.1929 10.1929 -1 24 -1V0ZM970.873 9.2655L970.084 9.87946C965.727 4.27692 959.027 1 951.929 1V0V-1C959.644 -1 966.926 2.56189 971.663 8.65155L970.873 9.2655ZM1026.74 66V67C1019.02 67 1011.74 63.4381 1007 57.3484L1007.79 56.7345L1008.58 56.1206C1012.94 61.7231 1019.64 65 1026.74 65V66ZM1256 66V65C1269.81 65 1281 76.1929 1281 90H1280H1279C1279 77.2974 1268.7 67 1256 67V66Z"></path>
            </svg>

            <svg xmlns="http://www.w3.org/2000/svg" fill="rgb(255, 255, 255)" viewBox="0 0 362.94086021505376 104.868" width="100%" height="104.868" class="act-faq-svg-mobile-bg">
                <mask fill="white" id="path-1-inside-1_229_10798">
                    <path d="M361 80C361 66.7452 350.255 56 337 56H234.738C227.332 56 220.34 52.5807 215.794 46.7346L186.651 9.26538C182.104 3.41931 175.113 0 167.706 0H24C10.7452 0 0 10.7452 0 24V947C0 960.255 10.7452 971 24 971H337C350.255 971 361 960.255 361 947V80Z"></path>
                </mask>
                <path d="M361 80C361 66.7452 350.255 56 337 56H234.738C227.332 56 220.34 52.5807 215.794 46.7346L186.651 9.26538C182.104 3.41931 175.113 0 167.706 0H24C10.7452 0 0 10.7452 0 24V947C0 960.255 10.7452 971 24 971H337C350.255 971 361 960.255 361 947V80Z"></path>
                <path mask="url(#path-1-inside-1_229_10798)" class="act-faq-svg-mob-border" fill="rgba(11, 21, 48, 0.06)" d="M186.651 9.26538L187.44 8.65143L186.651 9.26538ZM215.794 46.7346L215.004 47.3485L215.794 46.7346ZM337 56V57H234.738V56V55H337V56ZM215.794 46.7346L215.004 47.3485L185.861 9.87933L186.651 9.26538L187.44 8.65143L216.583 46.1207L215.794 46.7346ZM167.706 0V1H24V0V-1H167.706V0ZM0 24H1V947H0H-1V24H0ZM24 971V970H337V971V972H24V971ZM361 947H360V80H361H362V947H361ZM337 971V970C349.703 970 360 959.703 360 947H361H362C362 960.807 350.807 972 337 972V971ZM0 947H1C1 959.703 11.2975 970 24 970V971V972C10.1929 972 -1 960.807 -1 947H0ZM24 0V1C11.2975 1 1 11.2974 1 24H0H-1C-1 10.1929 10.1929 -1 24 -1V0ZM186.651 9.26538L185.861 9.87933C181.504 4.27686 174.804 1 167.706 1V0V-1C175.421 -1 182.704 2.56183 187.44 8.65143L186.651 9.26538ZM234.738 56V57C227.023 57 219.741 53.4382 215.004 47.3485L215.794 46.7346L216.583 46.1207C220.94 51.7231 227.64 55 234.738 55V56ZM337 56V55C350.807 55 362 66.1929 362 80H361H360C360 67.2974 349.703 57 337 57V56Z"></path>
            </svg>

            <div class="act-faq-head">
                <h4 class="act-faq-head-title">
                    <p>سوالات <strong>متــــــــداول</strong></p>      </h4>
                <a href="#" class="act-faq-but">
                    مشاهده بیشتر    <svg xmlns="http://www.w3.org/2000/svg" width="34" height="34" viewBox="0 0 34 34" fill="currentcolor">
                        <path d="M20.0746 10.4298C20.2089 10.5642 20.2938 10.748 20.2938 10.9602C20.2938 11.3703 19.9544 11.7097 19.5442 11.7097L11.7095 11.7097L11.7095 19.5444C11.7095 19.9546 11.3701 20.294 10.96 20.294C10.5498 20.294 10.2104 19.9546 10.2104 19.5444L10.2104 10.9602C10.2104 10.55 10.5498 10.2106 10.96 10.2106L19.5442 10.2106C19.7564 10.2106 19.9402 10.2955 20.0746 10.4298Z"></path>
                        <path d="M11.6112 10.5504L23.5118 22.451C23.8017 22.7409 23.8017 23.2217 23.5118 23.5117C23.2219 23.8016 22.741 23.8016 22.4511 23.5117L10.5505 11.6111C10.2606 11.3211 10.2606 10.8403 10.5505 10.5504C10.8404 10.2605 11.3213 10.2605 11.6112 10.5504Z"></path>
                    </svg>
                </a>
            </div>
            <div class="act-faq-main">
                <?php
                $db = \Giftmax\modules\Db::getLnstance();
                global $wpdb;

                $result = $db->first("SELECT meta_value FROM `{$wpdb->prefix}setting` WHERE meta_key = :key", ['key' => 'faq']);
                if (!empty($result)){
                    $records = json_decode($result['meta_value'], true);

                    $perCol = ceil(count($records)/2);
                    ?>

                    <?php foreach (array_chunk($records, $perCol) as $col): ?>
                        <div class="act-faq-main-col">

                            <?php foreach ($col as $record): ?>
                                <?php
                                static $i = 1;
                                ?>
                                <div class="act-faq-item">

                                    <div class="act-questions collapsed"
                                         data-bs-toggle="collapse"
                                         data-bs-target="#act-faq-<?= $i ?>"
                                         aria-expanded="false"
                                         type="button"
                                         aria-controls="act-faq-<?= $i ?>">

                                        <p><?= esc_html($record['question']) ?></p>

                                        <div class="act-questions-flash">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="currentcolor"><path d="M15.0579 11.3998C14.8996 11.3998 14.7413 11.4581 14.6163 11.5831L9.99961 16.1998L5.38294 11.5831C5.14128 11.3415 4.74128 11.3415 4.49961 11.5831C4.25794 11.8248 4.25794 12.2248 4.49961 12.4665L9.55794 17.5248C9.79961 17.7665 10.1996 17.7665 10.4413 17.5248L15.4996 12.4665C15.7413 12.2248 15.7413 11.8248 15.4996 11.5831C15.3829 11.4581 15.2163 11.3998 15.0579 11.3998Z"></path><path d="M10 2.29141C9.65833 2.29141 9.375 2.57474 9.375 2.91641V16.9414C9.375 17.2831 9.65833 17.5664 10 17.5664C10.3417 17.5664 10.625 17.2831 10.625 16.9414V2.91641C10.625 2.57474 10.3417 2.29141 10 2.29141Z"></path></svg>
                                        </div>
                                    </div>

                                    <div class="act-answer collapse <?= $i == 1 ? 'show' : '' ?>" id="act-faq-<?= $i ?>">
                                        <div class="act-answer-content">
                                            <p><?= nl2br(esc_html($record['answer'])) ?></p>
                                        </div>
                                    </div>

                                </div>
                                <?php $i++; ?>
                            <?php endforeach; ?>

                        </div>
                    <?php endforeach;
                }
                ?>
            </div>
        </div>
    </section>
</main>
<?php get_footer(); ?>

